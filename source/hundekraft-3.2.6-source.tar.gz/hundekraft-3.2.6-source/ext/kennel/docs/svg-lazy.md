# Lazy SVG screens (design, 2026-11-04)

Scope since the owner's review of the first results (2026-11-04): sequencer type pages too (`kn_seq.c`, finger page
as fallback), with the same proof.

Owner decisions (interview 2026-11-04): parse a plugin page's SVG when it is first shown and free it again later;
keep the most recently shown documents up to a byte cap; a first show may take up to about 100 ms; the source stays
the plugin file on NAND; all engine and FX pages, proved in stages; catalog `screen_bytes` stays each plugin's
measured document cost and the budget counts the resident cap instead of the sum; done = native heap and capture
proof below, the unit check recorded separately afterwards.

## Today
`screens_ctor_hook` (dispatcher.c) builds one screen object per engine (`eng_scr[e]`, slot 0x14) and per FX
(`fx_scr[e]`, slot 0x0B). `screens_load_hook` (boot) calls R246's `svg_load` 0x01A503D8 on every one and then the
plugin's `init`. `svg_load` reads the whole file from YAFFS (`svg_parse_file` 0x019FB458) and parses it into the TE
heap; the document stays there until power-off. All files: 2,435,352 bytes of parsed documents, room 3,744.

## Mechanism
- **Construct as today, load on show.** Boot still constructs every engine/FX screen object (cheap, arena) but
  parses none. `eng_ready` / `fx_ready` split into *built* (object exists, may be swapped into the slot) and
  *loaded* (document parsed, `init` run). `synth_screen_select` and the FX selection swap in a built object whatever
  its load state; they stay on the input thread and never parse.
- **Parse on the Gfx thread.** `kn_screens_frame` already copies the 68 slots for each frame. Before drawing, for
  each slot holding a lazy object with no document: `svg_load`, then the plugin's `init`, for every lazy object the frame shows (an engine and an FX page can both be new in one frame). If
  `svg_load` returns no document, that frame's copy shows the stock page (iter / filter) and the object stays failed
  until reboot. R246's loader reports a parse failure itself and goes on with no document, so a file that breaks its
  parser at runtime behaves as it would at boot: kennel's loader SVG check keeps such files out, and a registered page
  can only fail this way if its file left the NAND after boot.
- **Free with the document's own destructor.** R246's loader teardown (0x01A50394) deletes a document through its
  virtual slot vt+0x8/+0xC with R1 = 3. Kennel calls that for an evicted document, then clears the loader's and the
  screen's document words and the *loaded* flag. Step 0 below proves natively that this returns the whole tree to
  the TE heap; if it does not, lazy loading stays parse-on-show only and the budget keeps summing (owner told).
- **Eviction: LRU under a byte cap.** Each parse records its cost (TE used after `init` minus before). After a
  frame, while the resident lazy documents exceed `KN_SVG_CAP` (400 KiB), free the least recently drawn one that
  is not in this frame or the previous one. "Shown" means in the frame's table (all 68 slots, visible or
  not), so the current engine, FX and sequencer pages are never freed. With S = the heaviest page of each kind
  together, the resident total is at most max(cap, S) + S: a switch brings a new set before the old one may go.
- **Things that hold on to a document:**
  - `kn_artcache.c` keys its two entries on the document pointer: freeing a document drops its entries first (a new
    document at the same address would otherwise replay old pixels).
  - `kn_screens.c` `previous_docs`: the freed document is removed there too (no reset on a freed pointer).
  - Plugin node pointers (SVG_FIND results) go stale on free; `init` runs again on every parse and refreshes them.
    Each plugin is audited for `init` work that must not repeat (text objects constructed again, arena allocations)
    and for node access outside Gfx `update`/`init` (key or knob handlers that touch nodes); those get a guard or
    stay eager.
- **Eager switch for measurement.** A core word (`kn_svg_eager`, set by the measurement tool through the emulator
  at boot) makes boot parse everything as today, so `screen_memory_measure.py` keeps measuring each document at
  boot, and the cycle test can compare.
- Feature pages (quad LFO, clock pages, drum synth, sampler+, tape view) stay eager; sequencer type pages joined after
  the first results (top of this file).

## Budget
`runtime.screen_memory` and `app.js screenMemory`: `need = base + eager pages + min(Σ chosen engine/FX/sequencer screens,
max(cap, S) + S) + presets + worst_screen`, S = the heaviest chosen engine, FX and sequencer page together. `screen_bytes` and the record keep their meaning (one document's
cost). `test_screen_memory.py`'s room and heaviest asserts change with the new formula.

## Steps and proof
0. Native probe: boot, show Oxbow, free it with the destructor, TE used back to the pre-parse level (± 16); show it
   again, same cost. Measure first-show time (guest cycles) for c64arp, oxbow, stutter, eva, wavetable.
1. Mechanism with Oxbow, EVA, Nostromo, Pew lazy (outside the static-art cache contract); host fake-core test for
   select / parse / fail / evict order.
2. All engine and FX pages, the cached ones (MBIRA, HAIL, STUTTER, C64arp, Warble, JUNI...) with native primary,
   secondary, live and repeated/evicted-page captures against eager captures.
3. Proof: TE used after boot and peak, before and after, one all-files boot; cycle test (ten heavy pages shown
   twice, used returns to its level); first-show latency per heavy plugin (report any over 100 ms); goldens;
   `screen_memory_measure.py --check`; one `make -C synth_sdk/harness check` on the final head.

## Results (2026-11-04, emulator, all files; OP1-Emulator `run/svg-lazy-2026-11-04/`)
| | eager (main 22ab140) | lazy |
|---|---|---|
| TE used after boot | 7,165,992 | 5,021,928 |
| TE peak over the run (9 heavy pages, twice) | 8,255,416 | 6,624,872 |
| last page (Warble), round 1 / round 2 | 7,070,568 / 7,070,568 | 5,257,448 / 5,257,448 |
- Step 0 passed: the destructor returns the whole tree. After the eager poke (all 2,144,408 bytes of engine and FX
  documents parsed) and its release (41 frees), TE use is back at 5,257,448 to the byte.
- First show: 5.2..12.4 M emulator cycles (Outatime, HollowSaint about 5.2 M; Oxbow, Nostromo about 12.2 M), about
  13..31 ms at 400 MHz. That is under the 100 ms limit; the unit's NAND timing is not measured.
- Captures (`compare-r2.png`): MBIRA, Outatime and HollowSaint are identical to the eager build on both rounds.
  On Stutter, HAIL, Warble, Nostromo, EVA and Oxbow only the moving parts differ (reel, drops and wire, reels and
  wave, ship, stars), as much as the eager build differs from itself between rounds. Nostromo's typed readout starts
  over after a re-parse.
- Budget (engine and FX pages): with `lazy_cap` 409,600 the all-files configuration's room goes from 3,744 to
  1,384,968 bytes on paper.

## Results with sequencer pages (677a2a4; `probe-lazy2`, `probe-base2`, `probe-cycles`)
| | eager (main 22ab140) | lazy |
|---|---|---|
| TE used after boot | 7,165,992 | 4,767,856 |
| TE peak over the run (12 pages, twice) | 8,256,312 | 6,240,560 |
- Three eager load / release cycles: 7,001,704 / 7,001,768 / 7,001,768 loaded, 5,000,512 released each time.
- C64arp's first show is the longest: 14.1 M emulator cycles (about 35 ms at 400 MHz). Composer and Euclid take
  0.1..0.2 M.
- C64arp, Composer, Euclid and MBIRA are pixel-identical to the eager build on both rounds.
- Budget: S = Oxbow + Stutter + C64arp = 598,952 > the cap, so the bound is 2 S; the all-files room goes from 3,744
  to 1,196,464 bytes on paper.
- `screen_memory_measure.py --check` on this firmware, through the eager poke: every plugin agrees within 16 bytes
  except Amp (67,648 against the catalog's 67,672; same file, its last raw reading was 67,656).
