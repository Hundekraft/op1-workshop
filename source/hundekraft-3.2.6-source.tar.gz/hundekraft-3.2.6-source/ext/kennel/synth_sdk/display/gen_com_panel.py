#!/usr/bin/env python3
"""COM panel polylines for kennel/kn_ccmap.c (kn_cc_com_draw): the stock opset border with its left edge at x 194
and the stock MIDI / CH label strokes translated by -46 (op1r 49-51 com_panel_edit's geometry; numbers are the
stock path data, printed as Q10 op1_pt tables). Run and paste the output over pn_border_* / pn_label_*.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE)."""
def path(d):
    import re
    tok = re.findall(r'[MmCcHhVvLlZz]|-?\d*\.?\d+(?:e-?\d+)?', d)
    i = 0; x = y = 0; out = []; cur = []; cmd = None
    def num():
        nonlocal i; v = float(tok[i]); i += 1; return v
    while i < len(tok):
        if tok[i].isalpha(): cmd = tok[i]; i += 1
        if cmd in 'Mm':
            if cur: out.append(cur)
            a, b = num(), num(); x, y = (a, b) if cmd == 'M' else (x + a, y + b); cur = [(x, y)]; cmd = 'L' if cmd == 'M' else 'l'
        elif cmd in 'Cc':
            p = [num() for _ in range(6)]
            if cmd == 'c': p = [p[0] + x, p[1] + y, p[2] + x, p[3] + y, p[4] + x, p[5] + y]
            x0, y0 = x, y
            for k in range(1, 5):
                t = k / 4; u = 1 - t
                cur.append((u**3*x0 + 3*u*u*t*p[0] + 3*u*t*t*p[2] + t**3*p[4], u**3*y0 + 3*u*u*t*p[1] + 3*u*t*t*p[3] + t**3*p[5]))
            x, y = p[4], p[5]
        elif cmd in 'Hh': a = num(); x = a if cmd == 'H' else x + a; cur.append((x, y))
        elif cmd in 'Vv': a = num(); y = a if cmd == 'V' else y + a; cur.append((x, y))
        elif cmd in 'Ll': a, b = num(), num(); x, y = (a, b) if cmd == 'L' else (x + a, y + b); cur.append((x, y))
        elif cmd in 'Zz': cur.append(cur[0])
    if cur: out.append(cur)
    return out
DX = -46
border = path('M291.934,112.865c0,1.572-1.188,2.767-2.666,2.767H196.666c-1.476,0-2.666-1.192-2.666-2.666V5.521c0-1.473,1.19-2.667,2.666-2.667h92.601c1.475,0,2.666,1.195,2.666,2.567V112.865')
label = []
label += [[(246.266, 23.062), (246.266, 15.788), (246.629, 15.788), (248.266, 20.15), (248.629, 20.15), (250.266, 15.788), (250.629, 15.788), (250.629, 23.062)]]
label += [[(252.812, 15.788), (252.812, 23.062)], [(260.812, 15.788), (260.812, 23.062)]]
label += path('M256.812,23.062c1.004,0,1.812-0.815,1.812-1.82v-3.637c0-1.006-0.812-1.818-1.812-1.818h-1.819v7.275H256.812z')
label += path('M250.779,31.139c0,1.01-0.812,1.828-1.818,1.828c-1.003,0-1.812-0.818-1.812-1.828v-3.652c0-1.008,0.812-1.82,1.812-1.82c1.006,0,1.818,0.812,1.818,1.82')
label += [[(252.234, 25.665), (252.234, 32.967)], [(255.871, 25.665), (255.871, 32.967)], [(252.234, 29.312), (255.873, 29.312)]]
label = [[(x + DX, y) for x, y in pl] for pl in label]
def emit(name, pls):
    pts = []; idx = []
    for pl in pls: idx.append(len(pts)); pts += pl
    idx.append(len(pts))
    print(f'static const op1_pt {name}_pt[{len(pts)}] = {{')
    line = '   '
    for x, y in pts:
        s = f' {{ {round(x * 1024)}, {round(y * 1024)} }},'
        if len(line) + len(s) > 116: print(line); line = '   '
        line += s
    print(line + ' };')
    print(f'static const uint8_t {name}_at[{len(idx)}] = {{ ' + ', '.join(map(str, idx)) + ' };')
emit('pn_border', border); emit('pn_label', label)
print('// extents', min(x for pl in border for x, _ in pl), max(y for pl in border for _, y in pl), min(x for pl in label for x, _ in pl), max(x for pl in label for x, _ in pl))
