/* Stock Tombola in short physics steps (kennel/kn_tombola.c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_TOMBOLA_H
#define KN_TOMBOLA_H
#define KN_TOMBOLA_STEP 26        /* ticks per advance: a normal frame (23..25 at 30 fps) is one stock advance */
#define KN_TOMBOLA_MAX  102       /* R246's clamp in tombola_player_advance (0x66) */
void kn_tombola_advance(void *player, int ticks);   /* Tombola player vtable 0x01911E04 slot 6 (advance) */
#endif
