/*
 * MIDI CC channels (from op1r 49-51 midi/ccmap.c): the KEYS group (keys and encoders) and the PARAM group
 * (kennel/kn_mx.c) each on a channel of their own, set in COM's OP-1 tab with Shift held (Shift + green KEYS CH,
 * Shift + white PARAM CH, Shift + red FEEDBACK), plus feedback out.
 * - RX (kn_cc_rx, from du_rx_poll for every USB-MIDI packet, after the features' midi_raw and before the stock
 *   parser): a CC on the PARAM channel with a PARAM number -> kn_mx_cc; on the KEYS channel: CC 5-52 = key code + 5
 *   (value >= 64 press), CC 102-105 = encoders, relative (1..63 up, 65..127 down). Taken packets get CIN 0, which the
 *   stock parser skips (so midi_in and the stock CC table don't see them either). The rest (notes, MIDI LFO CC 1-4,
 *   ...) stays stock, on the OP-1 channel. A CC a feature took (op1_midi_take_cc) is never a key or an encoder.
 *   The PARAM channel is checked first: with PARAM = KEYS channel, a PARAM number is a parameter.
 * - Keys go into the KeyHandler queue (s_key_queue, as the key-scan ISR) and encoder ticks into the accumulators
 *   0x01DD5250 (interrupts off), then the KeyHandler wakes (0x019C2F04). While the SysEx update prompt is up MIDI
 *   presses nothing (only a physical T1 confirms an update).
 * - Feedback (FEEDBACK on): physical key presses / encoder turns -> the same CCs on the KEYS channel (events that came
 *   from MIDI are counted and not echoed); PARAM: every 16 sequencer ticks (~23 ms) the targets are read
 *   (kn_mx_read) and changed values sent on the PARAM channel, at most 8 a time (a received value updates "last"
 *   first: no echo). All sending happens on the sequencer thread (du_rx_poll), through op1_midi_send.
 * Settings (core settings service, op1rsettings rows): ccmap.keych 0 = same as the OP-1 channel (default, kennel's
 * behaviour before), 1..16, 17 off; ccmap.parch 1..16, 17 off (default off); ccmap.fb 0 / 1 (default 0).
 * The COM panel: com_controller's knob slot (vtable 0x0190F6EC + 0x2C = 0x0190F718, stock 0x01962D30) and ComScreen's
 * update slot (vtable 0x0190F734 + 0x1C = 0x0190F750, stock 0x019655E0) come here (make_firmware.py DATA_PATCHES);
 * the update draws the 46 px wider panel in code over the stock one (com.svg is never edited).
 * Ported from op1r-src e8cce4f (op1r 49-51) midi/ccmap.c, GPL, pcppcp and contributors (PROVENANCE.md). Kennel
 * changes: kennel's settings service and MIDI send, op1_midi_take_cc respected, the key push shared with kn_midi.c.
 * Copyright (C) 2026 Hundekraft, pcppcp and op1r-src contributors.
 * GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "kn_mx.h"

#define CH_OFF 17
volatile uint8_t kn_cc_keych = 0, kn_cc_parch = CH_OFF, kn_cc_fb = 0;
int kn_cc_taken(int cc);                                   /* kennel/kn_midi.c (op1_midi_take_cc) */

#ifdef OP1_HOST
extern int host_op_ch, host_prompt, host_push_ok;
extern void host_key(int code, int down), host_ticks(int knob, int ticks), host_tx(uint32_t pk);
#define OP_CH           host_op_ch
#define PROMPT_ACTIVE() host_prompt
#define PUSH_KEY(c, d)  (host_push_ok ? (host_key((c), (d)), 1) : 0)
#define ADD_TICKS(k, t) host_ticks((k), (t))
#define WAKE()
static void TX(uint32_t p) { host_tx(p); }
#else
#define OP_CH           (*(volatile int *)0x01AADB20)            /* stock RX / TX channel 0..15 */
extern int du_prompt_active(void);
int kn_kq_push(int code, int down);                              /* kennel/kn_midi.c: push + KeyHandler wake */
#define PROMPT_ACTIVE() du_prompt_active()
#define PUSH_KEY(c, d)  kn_kq_push((c), (d))
#define WAKE()          ((void (*)(void))0x019C2F04)()            /* KeyHandler::signal */
static uint32_t irq_off(void) { uint32_t m; __asm__ volatile ("cli %0;" : "=d"(m)); return m; }
static void irq_on(uint32_t m) { __asm__ volatile ("sti %0;" : : "d"(m)); }
static void ADD_TICKS(int k, int t)
{
    uint32_t m = irq_off();
    ((volatile int32_t *)0x01DD5250)[k] += t;
    irq_on(m);
}
static void TX(uint32_t p)
{
    uint8_t msg[3] = { (uint8_t)(p >> 8), (uint8_t)(p >> 16), (uint8_t)(p >> 24) };
    op1_midi_send(msg, 3);
}
#endif

static const uint8_t key_ok[48] = {                  /* key codes reachable over MIDI (no keyboard keys) */
    1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,                 /* help metro synth drum tape mixer T1-T4 lift drop scissors */
    1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,                 /* 1..5, sequencer */
    0,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1};                /* rec play stop left right shift, mic com, 6..8 */
static uint8_t key_down[48];                         /* MIDI key state (only changes are injected) */
static volatile uint8_t inj_key[48];                 /* injected key events not seen by the feedback yet */
static volatile int16_t inj_tick[4];                 /* injected encoder ticks not seen by the feedback yet */

int kn_cc_keys_channel(void) { return kn_cc_keych == 0 ? (OP_CH & 15) : kn_cc_keych <= 16 ? kn_cc_keych - 1 : -1; }
int kn_cc_params_channel(void) { return kn_cc_parch >= 1 && kn_cc_parch <= 16 ? kn_cc_parch - 1 : -1; }

static uint8_t last[KN_MX_N];                        /* PARAM feedback: last value sent / received, 0xFF = none */
static uint8_t last_init;

/* ---- RX ---- */
void kn_cc_rx(volatile uint8_t *pk)
{
    if ((pk[0] & 0xF0) == 0xF0) return;              /* posted by a feature (op1_midi_rx_post, cable 15), not USB */
    if ((pk[0] & 15) != 0xB || (pk[1] & 0xF0) != 0xB0) return;
    int ch = pk[1] & 15, cc = pk[2] & 127, v = pk[3] & 127;
    if (ch == kn_cc_params_channel()) {
        int id = kn_mx_index(cc);
        if (id >= 0) {
            kn_mx_cc(cc, v);
            if (last_init) last[id] = (uint8_t)v;       /* no echo */
            pk[0] &= 0xF0;
            return;
        }
    }
    if (ch != kn_cc_keys_channel() || kn_cc_taken(cc)) return;
    int knob = cc - 102, code = cc - 5;
    if (knob >= 0 && knob < 4) {
        pk[0] &= 0xF0;
        if (!(v & 63)) return;                          /* 0 / 64: no movement */
        int t = (v < 64 ? v : v - 128) * 2;             /* 1 detent = 2 ticks */
        ADD_TICKS(knob, t); inj_tick[knob] = (int16_t)(inj_tick[knob] + t);
        WAKE();
        return;
    }
    if (code < 0 || code >= 48 || !key_ok[code]) return;
    pk[0] &= 0xF0;
    int down = v >= 64;
    if (key_down[code] == down || PROMPT_ACTIVE()) return;   /* only physical keys confirm an update */
    inj_key[code]++;                                 /* before the push: the KeyHandler may run at once */
    if (!PUSH_KEY(code, down)) { inj_key[code]--; return; }   /* queue full: dropped, state unchanged (kennel) */
    key_down[code] = (uint8_t)down;
}

/* ---- feedback from the KeyHandler thread: a small ring, sent on the sequencer thread ---- */
static volatile uint32_t fq[32];
static volatile uint32_t fq_w, fq_r;
static void fq_put(int cc, int v) { if (fq_w - fq_r < 32) { fq[fq_w & 31] = (uint32_t)(cc | v << 8); fq_w++; } }

void kn_cc_fb_key(int code, int pressed)              /* key_event_hook (KeyHandler) */
{
    if (code < 0 || code >= 48 || !key_ok[code]) return;
    if (inj_key[code]) { inj_key[code]--; return; }  /* came from MIDI */
    if (!kn_cc_fb || kn_cc_keys_channel() < 0) return;
    fq_put(code + 5, pressed ? 127 : 0);
}

void kn_cc_fb_knob(int knob, int delta)               /* knob_event_hook (KeyHandler): delta = ticks << 9 */
{
    static int32_t rem[4];
    if (knob < 0 || knob > 3) return;
    int t = delta / 512, i = inj_tick[knob];
    if (i && (i > 0) == (t > 0)) {                     /* MIDI ticks first */
        int use = (i > 0 ? (t < i ? t : i) : (t > i ? t : i));
        inj_tick[knob] = (int16_t)(i - use); t -= use;
    }
    if (!t || !kn_cc_fb || kn_cc_keys_channel() < 0) return;
    rem[knob] += t;
    int det = rem[knob] / 2;
    if (!det) return;
    rem[knob] -= det * 2;
    if (det > 63) det = 63; else if (det < -63) det = -63;
    fq_put(102 + knob, det > 0 ? det : 128 + det);
}

static void send_cc(int ch, int cc, int v) { TX(0x0Bu | (uint32_t)(0xB0 | ch) << 8 | (uint32_t)cc << 16 | (uint32_t)(v & 127) << 24); }

void kn_cc_tx_poll(void)                              /* du_rx_poll, every sequencer tick */
{
    int kc = kn_cc_keys_channel();
    while (fq_r != fq_w) {
        uint32_t e = fq[fq_r & 31]; fq_r++;
        if (kc >= 0) send_cc(kc, (int)(e & 127), (int)(e >> 8 & 127));
    }
    static uint32_t tick;
    if (++tick & 15) return;
    int pc = kn_cc_params_channel();
    if (!kn_cc_fb || pc < 0) { last_init = 0; return; }
    if (!last_init) { for (int i = 0; i < KN_MX_N; i++) last[i] = 0xFF; last_init = 1; }   /* (re)enabled: send all */
    int sent = 0;
    for (int id = 0; id < KN_MX_N && sent < 8; id++) {   /* at most 8 messages per 23 ms */
        int v = kn_mx_read(id);
        if (v < 0 || v == last[id]) continue;
        last[id] = (uint8_t)v;
        send_cc(pc, kn_mx_cc_of(id), v);
        sent++;
    }
}

/* ---- COM, OP-1 tab, Shift held: Shift + green / white / red ---- */
static const uint8_t key_order[18] = { CH_OFF, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
static int key_pos(int v) { for (int i = 0; i < 18; i++) if (key_order[i] == v) return i; return 1; }

void kn_cc_turn(int idx, int delta)                   /* KeyHandler: idx 5 / 6 / 7 = Shift + green / white / red */
{
    static int32_t acc[3];
    int i = idx - 5;
    if (i < 0 || i > 2) return;
    if ((acc[i] > 0 && delta < 0) || (acc[i] < 0 && delta > 0)) acc[i] = 0;
    acc[i] += delta;
    int st = acc[i] / 2048; if (!st) return;          /* a detent = 2 events of 1024 */
    acc[i] = 0;
    if (i == 0) {                                     /* KEYS: OFF, OP, 1..16 */
        int p = key_pos(kn_cc_keych) + st; p = p < 0 ? 0 : p > 17 ? 17 : p;
        if (key_order[p] != kn_cc_keych) { kn_cc_keych = key_order[p]; op1_setting_set("ccmap", "keych", kn_cc_keych); }
    } else if (i == 1) {                              /* PARAM: OFF, 1..16 */
        int p = (kn_cc_parch == CH_OFF ? 0 : kn_cc_parch) + st; p = p < 0 ? 0 : p > 16 ? 16 : p;
        int v = p ? p : CH_OFF;
        if (v != kn_cc_parch) { kn_cc_parch = (uint8_t)v; op1_setting_set("ccmap", "parch", v); }
    } else {                                          /* FEEDBACK: right on, left off */
        int v = st > 0;
        if (v != kn_cc_fb) { kn_cc_fb = (uint8_t)v; op1_setting_set("ccmap", "fb", v); }
    }
}

void kn_cc_load(void)                                 /* boot (dispatcher.c screens_load_hook) */
{
    int v = op1_setting_get("ccmap", "keych", 0); kn_cc_keych = (uint8_t)(v >= 0 && v <= CH_OFF ? v : 0);
    v = op1_setting_get("ccmap", "parch", CH_OFF); kn_cc_parch = (uint8_t)(v >= 1 && v <= CH_OFF ? v : CH_OFF);
    v = op1_setting_get("ccmap", "fb", 0); kn_cc_fb = (uint8_t)(v == 1);
}

/* value texts, as drawn ("op" = same as the OP-1 channel; the font draws lowercase as capitals) */
static char *put2(char *p, int v) { *p++ = (char)('0' + v / 10); *p++ = (char)('0' + v % 10); return p; }
void kn_cc_text(int row, char *s)
{
    int v = row == 0 ? kn_cc_keych : row == 1 ? kn_cc_parch : kn_cc_fb;
    if (row == 2) { s[0] = 'o'; s[1] = v ? 'n' : 'f'; s[2] = v ? 0 : 'f'; s[3] = 0; return; }
    if (v == CH_OFF) { s[0] = 'o'; s[1] = 'f'; s[2] = 'f'; s[3] = 0; return; }
    if (v == 0) { s[0] = 'o'; s[1] = 'p'; s[2] = 0; return; }
    *put2(s, v) = 0;
}

#ifndef OP1_HOST
void kn_cc_com_knob(void *self, int idx, int16_t *delta)  /* com_controller vtable +0x2C (slot 0x0190F718) */
{
    if (*(volatile int *)0x01AAA784 == 0 && idx >= 5 && idx <= 7) { kn_cc_turn(idx, *delta); return; }   /* OP-1 tab */
    ((void (*)(void *, int, int16_t *))0x01962D30)(self, idx, delta);
}

/* the MIDI CH panel (Shift held, OP-1 tab), widened in code: R246's com.svg stays as it is (a core-only update over
 * SysEx can't change a stock file), and this draws over its "opset" panel after the stock update. The panel's left
 * part (x 195..264, the border's y range) is blanked, then the border is drawn again with its left edge at
 * x 194 instead of 238.784 (the stock path, corners as 4 lines each), the stock MIDI / CH label strokes 46 px left at
 * x 200.3 (the stock strokes, translated), and three rows of stock text objects below. The stock value (opmidich,
 * right edge x 279.8) and the border's right edge are R246's own and stay. Everything stays inside the stock panel's
 * y range 2.1..116.4 (above the tab boxes; no OLED bottom-margin change). Polylines from the stock path data by
 * display/gen_com_panel.py (op1r 49-51 com_panel_edit's geometry).
 * Our rows follow the stock row's geometry at a 26 px pitch: label two lines (tops 15.8 / 25.7 + 26 r, 7.3 px tall),
 * value right aligned (top 16.1 + 26 r, 17.2 px tall). Text objects: y argument = first pixel row + CC_DY, left x =
 * first column - CC_DX (upstream's measurements on screenshots). 0x01BAB014 = the screen's shown tab (0x019655E0 reads
 * [0x01BAB018 - 4] against 0 for the first tab box's visibility). */
static const op1_pt pn_border_pt[21] = {
    { 298940, 115574 }, { 298727, 116696 }, { 298143, 117594 }, { 297275, 118191 }, { 296210, 118407 },
    { 201386, 118407 }, { 200322, 118193 }, { 199454, 117608 }, { 198870, 116741 }, { 198656, 115677 },
    { 198656, 5654 }, { 198870, 4590 }, { 199454, 3722 }, { 200322, 3137 }, { 201386, 2922 }, { 296209, 2922 },
    { 297273, 3136 }, { 298141, 3710 }, { 298725, 4548 }, { 298939, 5551 }, { 298939, 115574 }, };
static const uint8_t pn_border_at[2] = { 0, 21 };
static const op1_pt pn_label_pt[50] = {
    { 205072, 23615 }, { 205072, 16167 }, { 205444, 16167 }, { 207120, 20634 }, { 207492, 20634 },
    { 209168, 16167 }, { 209540, 16167 }, { 209540, 23615 }, { 211775, 16167 }, { 211775, 23615 },
    { 219967, 16167 }, { 219967, 23615 }, { 215871, 23615 }, { 216595, 23469 }, { 217185, 23070 },
    { 217582, 22477 }, { 217727, 21752 }, { 217727, 18028 }, { 217581, 17302 }, { 217183, 16710 },
    { 216593, 16312 }, { 215871, 16166 }, { 214009, 16166 }, { 214009, 23615 }, { 215871, 23615 },
    { 215871, 23615 }, { 209694, 31886 }, { 209548, 32615 }, { 209149, 33210 }, { 208558, 33611 },
    { 207832, 33758 }, { 207109, 33611 }, { 206519, 33210 }, { 206122, 32615 }, { 205977, 31886 },
    { 205977, 28147 }, { 206122, 27420 }, { 206520, 26828 }, { 207110, 26429 }, { 207832, 26283 },
    { 208558, 26429 }, { 209149, 26828 }, { 209548, 27420 }, { 209694, 28147 }, { 211184, 26281 },
    { 211184, 33758 }, { 214908, 26281 }, { 214908, 33758 }, { 211184, 30015 }, { 214910, 30015 }, };
static const uint8_t pn_label_at[9] = { 0, 8, 10, 12, 26, 44, 46, 48, 50 };
static const uint8_t pn_line[4] = { 0x38, 0x35, 0x72, 0xFF }, pn_black[4] = { 0, 0, 0, 0xFF };   /* border #383572 */
static void pn_poly(void *r, const op1_pt *pt, const uint8_t *at, int n, const uint8_t *c)
{
    for (int i = 0; i < n; i++) for (int k = at[i]; k + 1 < at[i + 1]; k++) op1_raster_line(r, &pt[k], &pt[k + 1], 1536, c);
}
#define CC_LX    200.3                                /* label column (the stock label's left edge) */
#define CC_VX    279.8                                /* value right edge (the stock value's) */
#define CC_PITCH 26
#define CC_DY    1                                    /* text y argument below the first pixel row */
#define CC_DX    (-0.8)                               /* labels came out 1 screen px left of the stock label */
#define CC_VDX   (-0.8)                               /* values 1 screen px right of the stock value */
#define QF(x)    ((int32_t)((x) * 1024))
static uint32_t txt[6][OP1_TEXT_SIZE / 4], val[3][OP1_TEXT_SIZE / 4];
static char shown[3][4];
static uint8_t txt_ok;
static const int32_t ident[9] = { 1024, 0, 0, 0, 1024, 0, 0, 0, 1024 };
static const uint8_t lilac[4] = { 0x55, 0x53, 0x80, 0xFF }, vcol[3][4] = { { 0x00, 0xED, 0x95, 0xFF },   /* stock label #555380 */
                                  { 0xFF, 0xFF, 0xFF, 0xFF }, { 0xFF, 0x3A, 0x5D, 0xFF } };
static const char *const lab[3][2] = { { "keys", "ch" }, { "param", "ch" }, { "feed", "back" } };
#define TEXT_CTOR(o, x, y, sz, c, al) ((void *(*)(void *, int32_t, int32_t, int32_t, const uint8_t *, int32_t))0x01A61904)((o), (x), (y), (sz), (c), (al))

void kn_cc_com_draw(void *scr, int dt)                 /* ComScreen vtable update (slot 0x0190F750) */
{
    ((void (*)(void *, int))0x019655E0)(scr, dt);
    if (*(volatile int *)0x01BAB014 != 0 || !*(volatile uint8_t *)0x01DD7F78) return;   /* OP-1 tab, Shift held */
    if (!txt_ok) {
        for (int r = 0; r < 3; r++) {
            int y = (int)(15.8 + CC_PITCH * (r + 1) + 0.5) + CC_DY, y2 = (int)(25.7 + CC_PITCH * (r + 1) + 0.5) + CC_DY;
            TEXT_CTOR(txt[2 * r], QF(CC_LX - CC_DX), y, 7, lilac, 0); op1_text_set(txt[2 * r], lab[r][0]);
            TEXT_CTOR(txt[2 * r + 1], QF(CC_LX - CC_DX), y2, 7, lilac, 0); op1_text_set(txt[2 * r + 1], lab[r][1]);
            TEXT_CTOR(val[r], QF(CC_VX + CC_VDX), (int)(16.1 + CC_PITCH * (r + 1) - 0.7), 17, vcol[r], 2);   /* (1.5 screen px up, measured) */
        }
        txt_ok = 1;
    }
    void *r = op1_raster();
    for (int x = 195 * 2; x <= 264 * 2; x++) {                /* blank x 195..264 (the stock value starts at 267), y 2.9..115.6
                                                                 * (the border, redrawn next): strips 0.5 px apart */
        op1_pt a = { x * 512, OP1_Q10(2.9) }, b = { x * 512, OP1_Q10(115.6) };
        op1_raster_line(r, &a, &b, 2048, pn_black);
    }
    pn_poly(r, pn_border_pt, pn_border_at, 1, pn_line);
    pn_poly(r, pn_label_pt, pn_label_at, 8, lilac);
    for (int i = 0; i < 3; i++) {
        char s[4]; kn_cc_text(i, s);
        int k = 0; while (k < 4 && s[k] == shown[i][k] && s[k]) k++;
        if (k < 4 && s[k] != shown[i][k]) { op1_text_set(val[i], s); for (k = 0; k < 4; k++) shown[i][k] = s[k]; }
        op1_text_draw(txt[2 * i], r, ident); op1_text_draw(txt[2 * i + 1], r, ident); op1_text_draw(val[i], r, ident);
    }
}
#endif
