/* MIDI parameter CCs on the PARAM channel (kennel/kn_mx.c, from op1r 49-51 midi/mx.h): sound / FX / LFO / mixer
 * targets, a target id = group base + knob.
 * Copyright (C) 2026 Hundekraft, pcppcp and op1r-src contributors. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE
 * and NOTICE). */
#ifndef KN_MX_H
#define KN_MX_H
#include <stdint.h>

enum { KN_MX_SE, KN_MX_SV, KN_MX_SL, KN_MX_SF, KN_MX_DE, KN_MX_DP, KN_MX_DF, KN_MX_DL, KN_MX_DV, KN_MX_MF,
       KN_MX_VOL, KN_MX_PAN, KN_MX_MUTE, KN_MX_AUX, KN_MX_TAPE, KN_MX_NG };
#define KN_MX_N 74                                /* targets */

int kn_mx_index(int cc);                          /* CC -> target id, -1: not a PARAM CC */
int kn_mx_cc_of(int id);                          /* target id -> CC, -1: no such id */
int kn_mx_group(int id, int *knob);               /* target id -> group (knob within it), -1: no such id */
int kn_mx_scale(const int16_t *rg, int v);        /* 0..127 over [min, max] */
int kn_mx_unscale(const int16_t *rg, int w);      /* word -> 0..127 (the inverse, rounded) */
int kn_mx_cc(int cc, int v);                      /* any thread; 1 if a PARAM CC (stored, applied on the KeyHandler) */
void kn_mx_apply(void);                           /* KeyHandler thread (kn_param_key) */
int kn_mx_read(int id);                           /* current value 0..127 of a target, -1: not there now (feedback) */
#endif
