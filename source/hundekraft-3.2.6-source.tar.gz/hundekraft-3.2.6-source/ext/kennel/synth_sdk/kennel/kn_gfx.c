/*
 * R246's Gfx frame, from kennel's side (ARCHITECTURE.md "Gfx frames: frame skip and the frame governor").
 *
 * R246 (Gfx_thread::Run 0x019AB880): the display ISR hands over the back buffer (display_frame_manager toggles
 * disp_buffer_toggle 0x01DE6106 between 0x02000000 and 0x03000000, sets disp_draw_busy and posts Gfx_sem); Gfx runs
 * gfx_render_frame -> screens_update (0x01A3BB20: screen requests, resets, dt, raster_begin_frame = the MDMA0 clear,
 * every visible screen's update, player_manager_advance, knob_touched_clear), flushes the buffer's cache lines,
 * presents it (display_present_buffer: the TE ISR copies it to the panel's GRAM) and clears disp_draw_busy.
 *
 * Two hooks here:
 *   0x01A3BBE0  screens_update's CALL raster_begin_frame -> kn_gfx_frame (hook.S): the frame's start (screens/guiskip.c
 *               gs_frame: a record or a render frame) and the update loop, or nothing (a frame the governor skips),
 *               then back to 0x01A3BC02 (player_manager_advance, knob_touched_clear run every frame).
 *   0x019AB8C8  Gfx_thread::Run's CALL of the flush -> kn_gfx_finish: flush + invalidate and present, or, for a
 *               governed frame, nothing: the toggle goes back so the next frame gets this same (undrawn) buffer
 *               again, and the panel keeps the last presented frame. A governed frame never reaches the panel.
 *
 * The exact frame skip is op1r's (screens/guiskip.c, op1r-src 59): every drawn frame runs the screens' updates; in a
 * record frame R246's drawing calls only feed a hash and nothing is rasterised, and a frame renders when the hash
 * changed. Record frames are presented like render frames (the buffer still holds the same picture).
 *
 * The frame governor (load-aware, all pages, stock ones too): kn_gfx_block (audio callback, every block) keeps the
 * worst whole-callback cycles of two buckets of KN_GOV_BUCKET blocks; the recent worst is the larger of the two (the
 * last 0.25..0.5 s). At or over KN_GOV_HI_PCT of the measured block the level goes up at once to 1 (a drawn frame
 * at most every KN_GOV_GAP1 blocks, 15 fps), and, if KN_GOV_MAX_LEVEL allows (it is 1: 15 fps is the floor), to 2 (KN_GOV_GAP2, 10 fps) when a whole window at level 1
 * is still high; a full KN_GOV_DOWN_BLOCKS under KN_GOV_LO_PCT takes one level back. A governed frame is skipped whole (no
 * update, no clear, no drawing, no present, the same back buffer next time), so every drawn frame is a full one. The gaps are by time (frame_counter), not frame counts: a skipped frame is quick, and R246's Gfx loop then
 * runs once per display interrupt (~12 blocks; a frame draws up to KN_GOV_EARLY before its gap). Input does not override the cadence (heavy turning would lift the bound).
 * R246's per-frame work after the update loop (player_manager_advance: Tombola's world step with this frame's ticks,
 * the sequencers; knob_touched_clear) runs on every frame, skipped or not, so Tombola's steps stay frame-sized
 * (ARCHITECTURE.md "Tombola steps"); the screens' updates get the skipped frames' ticks added on the next drawn frame
 * (at most KN_GOV_DT_MAX), as after one slow frame. op1_gfx_heavy() tells plugins the governor is on (level > 0),
 * so they can drop optional effects.
 *
 * Framebuffer lines: the buffers are cacheable write-through pages. Lines the raster read stay in the D-cache while
 * MDMA0 clears the buffer under them two frames later; the flush therefore also invalidates (R246's mode 1,
 * flushinv: same loop), since the static-art decode no longer rewrites black pixels (kn_artcache.c).
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (LICENSE, NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")
#include <stdint.h>
#include "kn_gfx.h"
#include "kn_gs.h"
#include "kn_tc.h"
#include "../kn_mem.h"                               /* kn_hot, kn_audio_text: the governor's per-block window */

#ifdef OP1_HOST
void host_gfx_flush(uint32_t buf, uint32_t end, int inv);
void host_gfx_present(uint32_t buf);
void host_gfx_begin(void *raster);
uint32_t host_gfx_word(uint32_t addr);           /* the R246 words read below, by address */
uint8_t host_gfx_toggle;
#define CACHE_FLUSH  host_gfx_flush
#define PRESENT      host_gfx_present
#define GS_FRAME     host_gfx_begin
#define WORD(a)      host_gfx_word(a)
#define TOGGLE       host_gfx_toggle
uint32_t host_gfx_touched;
#define TOUCHED      host_gfx_touched
#define BYTE(a)      (host_gfx_word(a) & 0xFFu)
int host_gfx_tc_end(uint32_t buf);
#define TC_END       host_gfx_tc_end
#define TC_BUILD     0
#else
#define CACHE_FLUSH  ((void (*)(uint32_t, uint32_t, int))0x01AA185C)   /* 0 flush, 1 flush + invalidate */
#define PRESENT      ((void (*)(uint32_t))0x01A2FB18)                  /* display_present_buffer */
#define GS_FRAME     gs_frame                                          /* screens/guiskip.c */
#define WORD(a)      (*(volatile uint32_t *)(a))
#define TOGGLE       (*(volatile uint8_t *)0x01DE6106)                 /* disp_buffer_toggle: 1 = 0x02000000 handed */
#define TOUCHED      (*(volatile uint32_t *)0x01DD7F74)                /* knob_touched[4]: set by a turn, cleared each frame */
#define BYTE(a)      (*(volatile uint8_t *)(a))
#define TC_END       tc_frame_end                                      /* screens/tapecache.c */
#define TC_BUILD     kn_tc_build
#endif
#define TE_COUNT      0x018B64B4u                    /* disp_te_edge_count: TE edges since the last DMA frame start */
#define FRAMES_START  0x018B64A8u                    /* disp_frames_started */
#define HW_VARIANT    0xFF906A54u                    /* hardware_variant: non-zero = a gpio panel (TE interrupt) */
#define CUR_SCREEN_ID 0x018B65C8u
#define FRAME_COUNTER 0xFF8016E0u                    /* one per audio block */
#define TARGET        0x01D08520u                    /* gfx_target_buffer: the buffer this frame draws into */
#define BUF_A         0x02000000u
#define BUF_B         0x03000000u

volatile uint32_t kn_gfx_stats[2];                   /* frames with updates, frames the governor skipped */
volatile uint32_t kn_gfx_gov = 1;                    /* 0: the governor off (A/B, emulator / debugger poke) */
volatile uint32_t kn_gfx_gov_hi, kn_gfx_gov_lo;      /* thresholds in cycles; 0 = KN_GOV_HI_PCT / _LO_PCT of the block */
volatile uint32_t kn_gfx_gov_stats[4];               /* frames skipped by the governor, level ups, level downs, worst seen */
volatile uint32_t kn_gfx_level;                      /* 0 every frame, 1 every second, 2 every third (op1_gfx_heavy) */
uint8_t kn_gfx_skipped;                              /* this frame (kn_core.c's overlays and kn_gfx_finish read it) */

static uint32_t shown;                               /* the buffer presented last */

/* ---- steady pacing (gpio panels; ARCHITECTURE.md "Gfx frames: steady pacing") ----
 * R246's TE ISR counts edges since the last DMA frame start (disp_te_edge_count); from the second on it runs the frame
 * manager on every edge, which hands the back buffer to Gfx when the last draw is done, and on the same edge starts a
 * DMA frame when one was published. A frame the panel shows therefore goes out max(2, edge at present + 1) edges
 * after the last one: a draw that finishes around one 33 ms slot alternates 30 / 20 fps, around two 20 / 15.
 * kn_gfx_pace = the edges a frame should take (2 = 30 fps, 3 = 20, 4 = 15): a drawn frame that would go out sooner
 * is held (flushed, not presented), and the next hand-outs (quick frames, the governor's skip) present it on the
 * edge before its slot. The pace goes one edge slower when KN_PACE_UP_OVER of the last 16 measured frames overran it
 * at 30 fps (KN_PACE_UP_OVER_SLOW at 20: 15 fps costs more), and one edge faster when none of the last
 * KN_PACE_DOWN_WIN would have overrun the faster pace. Measured frames: those handed out on a DMA edge (edge count 0). The governor's rate
 * (level 1: 15 fps = 4 edges, level 2: 10 fps = 6) is held the same way when it is the lower one, so a governed page
 * also runs even (its block gaps only decide which hand-outs draw). A screen change starts again at 30 fps. */
volatile uint32_t kn_gfx_pace = 2;                   /* edges per frame now (2..KN_PACE_MAX) */
volatile uint32_t kn_gfx_pace_on = 1;                /* 0: off (poke, A/B) */
volatile uint32_t kn_gfx_pace_stats[6];              /* held frames, ups, downs, overruns, measured frames, presented from a hold */
static struct {
    uint32_t held, start_fs, hist, hist_fast, screen;
    uint8_t start_te, measured, nhist;
} pace;
static int pace_ok(void) { return kn_gfx_pace_on && BYTE(HW_VARIANT) != 0; }
/* the edges a frame takes now: the pace, or the governor's rate when that is lower (15 fps: 4 edges, 10 fps: 6) */
static uint32_t pace_edges(void)
{
    uint32_t n = kn_gfx_pace, g = kn_gfx_level ? (kn_gfx_level >= 2 ? 6u : 4u) : 0u;
    return g > n ? g : n;
}
static void pace_reset(void) { kn_gfx_pace = 2; pace.hist = pace.hist_fast = 0; pace.nhist = 0; }
/* a drawn frame's end: measure it, then 1 = hold it (do not present yet) */
static uint32_t bits(uint32_t h) { uint32_t n = 0; for (; h; h &= h - 1) n++; return n; }
static int pace_finish(void)
{
    if (!pace_ok()) { pace_reset(); return 0; }
    uint32_t te = WORD(TE_COUNT), n = kn_gfx_pace;
    if (pace.measured && WORD(FRAMES_START) == pace.start_fs && !TC_BUILD) {   /* a cache build is a one-off */
        int over = te >= n, over_fast = te + 1u >= n;                          /* would overrun one edge less */
        kn_gfx_pace_stats[4]++;
        if (over) kn_gfx_pace_stats[3]++;
        pace.hist = (pace.hist << 1) | (uint32_t)over;
        pace.hist_fast = (pace.hist_fast << 1) | (uint32_t)over_fast;
        if (pace.nhist < 32) pace.nhist++;
        uint32_t up = n == 2 ? KN_PACE_UP_OVER : KN_PACE_UP_OVER_SLOW;
        if (n < KN_PACE_MAX && pace.nhist >= KN_PACE_UP_OVER && bits(pace.hist & 0xFFFFu) >= up) {
            kn_gfx_pace = n + 1; pace.hist = pace.hist_fast = 0; pace.nhist = 0; kn_gfx_pace_stats[1]++;
        } else if (n > 2 && pace.nhist >= KN_PACE_DOWN_WIN && !(pace.hist_fast & 0xFFFFFFFFu)) {
            kn_gfx_pace = n - 1; pace.hist = pace.hist_fast = 0; pace.nhist = 0; kn_gfx_pace_stats[2]++;
        }
    }
    pace.measured = 0;
    n = pace_edges();
    /* presented now it goes out on edge max(2, te + 1); hold it while that is before edge n */
    if (n <= 2 || te + 1u >= n) return 0;
    kn_gfx_pace_stats[0]++;
    return 1;
}

/* ---- the governor's input: the audio callback's whole cycles, worst per bucket (audio side, every block) ---- */
uint32_t kn_gov_win[2] kn_hot;                       /* [0] the current bucket's worst, [1] the last full bucket's */
uint32_t kn_gov_hot[2] kn_hot;                       /* blocks at or over kn_gov_hi_cy: [0] this bucket, [1] the last */
volatile uint32_t kn_gov_hi_cy kn_hot;              /* the high threshold in cycles, set by gov_update every frame (0: not yet) */
static uint32_t gov_n kn_hot;
kn_audio_text void kn_gfx_block(uint32_t used)
{
    if (used > kn_gov_win[0]) kn_gov_win[0] = used;
    if (kn_gov_hi_cy && used >= kn_gov_hi_cy) kn_gov_hot[0]++;
    if (++gov_n >= KN_GOV_BUCKET) {
        gov_n = 0; kn_gov_win[1] = kn_gov_win[0]; kn_gov_win[0] = 0; kn_gov_hot[1] = kn_gov_hot[0]; kn_gov_hot[0] = 0;
    }
}
uint32_t kn_audio_block_cycles(void);                /* kennel/kn_input.c (the harness defines its own) */
static struct {
    uint32_t since, low_since, last_draw, pend_dt, touched;
    uint8_t low;
} gov;
/* Gfx thread, once a frame: the level from the recent worst block and how many blocks were high (a level up needs
 * both: KN_GOV_HOT_BLOCKS high blocks in a bucket, so one spike, such as an FX preview while scrolling a list, never
 * drops the frame rate) */
static void gov_update(uint32_t fc)
{
    if (!kn_gfx_gov) { kn_gfx_level = 0; gov.low = 0; return; }
    uint32_t b = kn_audio_block_cycles();
    uint32_t hi = kn_gfx_gov_hi ? kn_gfx_gov_hi : b / 100u * KN_GOV_HI_PCT;
    uint32_t lo = kn_gfx_gov_lo ? kn_gfx_gov_lo : b / 100u * KN_GOV_LO_PCT;
    kn_gov_hi_cy = hi;
    uint32_t w = kn_gov_win[0], w1 = kn_gov_win[1];  /* [0] first: a bucket change between the reads loses nothing */
    uint32_t h = kn_gov_hot[0], h1 = kn_gov_hot[1];
    if (w1 > w) w = w1;
    if (h1 > h) h = h1;
    if (w > kn_gfx_gov_stats[3]) kn_gfx_gov_stats[3] = w;
    uint32_t lv = kn_gfx_level;
    if (w >= hi && h >= KN_GOV_HOT_BLOCKS) {         /* sustained: an eighth of a bucket's blocks high */
        gov.low = 0;
        /* up at once from full rate; a further level only when a whole window at this level is still high */
        if (lv < KN_GOV_MAX_LEVEL && (lv == 0 || fc - gov.since >= KN_GOV_UP_BLOCKS)) {
            kn_gfx_level = lv + 1; gov.since = fc; kn_gfx_gov_stats[1]++;
        }
    } else if (w < lo) {
        if (!gov.low) { gov.low = 1; gov.low_since = fc; }
        else if (lv && fc - gov.low_since >= KN_GOV_DOWN_BLOCKS) {
            kn_gfx_level = lv - 1; gov.since = fc; gov.low_since = fc; kn_gfx_gov_stats[2]++;
        }
    } else gov.low = 0;                              /* between, or a short spike: keep the level (hysteresis) */
}
/* 1: the governor skips this frame. By time, not by count: R246's Gfx loop runs once per display interrupt when a
 * frame is quick (a skipped one), so frame counts are not a rate. A frame draws once the gap since the last drawn
 * frame is within KN_GOV_EARLY (one display interrupt) of the level's gap, 46 blocks (15 fps) or 69 (10 fps): with
 * the loop at the display rate no gap passes the level's. */
static int gov_skip(uint32_t fc)
{
    uint32_t lv = kn_gfx_level;
    if (!lv) return 0;
    uint32_t gap = lv >= 2 ? KN_GOV_GAP2 : KN_GOV_GAP1;
    return fc - gov.last_draw + KN_GOV_EARLY < gap;
}
#ifdef OP1_HOST
int host_gfx_visible(uint8_t *scr, int cur);        /* the vtable calls, without R246's 32-bit layout */
void host_gfx_update(uint8_t *scr, int dt);
#define visible host_gfx_visible
#define update  host_gfx_update
#else
typedef int (*visible_fn)(void *, int);
typedef void (*update_fn)(void *, int);
static int visible(uint8_t *scr, int cur)
{
    const uint8_t *vt = *(const uint8_t *const *)(scr + 0xC);
    return ((visible_fn)*(void *const *)(vt + 0x14))(scr + *(const int16_t *)(vt + 0x10), cur);
}
static void update(uint8_t *scr, int dt)
{
    const uint8_t *vt = *(const uint8_t *const *)(scr + 0xC);
    ((update_fn)*(void *const *)(vt + 0x1C))(scr + *(const int16_t *)(vt + 0x18), dt);
}
#endif

/* 1: the buffer handed over is the other one, and the toggle says so: a skip can give it back */
static int buffer_ok(void)
{
    uint32_t t = WORD(TARGET);
    return (t == BUF_A || t == BUF_B) && t != shown && shown && (TOGGLE != 0) == (t == BUF_A);
}

/* screens_update 0x01A3BBE0 (hook.S kn_gfx_frame_stub): raster = the screen state's raster, dt = the frame's ticks */
/* a frame that draws nothing (governed, or a pacing hand-out): the panel keeps its frame, the screens' updates get
 * this frame's ticks and turns on the next drawn frame */
static void skip_frame(int dt)
{
    /* knob_touched (R246 0x01DD7F74, four bytes): stock screens read it in their update (knob_touched_get) and
     * knob_touched_clear runs after this hook on every frame, governed or not: a turn in a governed frame is kept here
     * and given back to the next drawn frame's updates */
    gov.touched |= TOUCHED;
    kn_gfx_skipped = 1; kn_gfx_stats[1]++;
    gov.pend_dt += (uint32_t)(dt > 0 ? dt : 0);
}
void kn_gfx_frame(void *raster, uint8_t **table, int dt)
{
    uint32_t fc = WORD(FRAME_COUNTER);
    gov_update(fc);
    uint32_t id = WORD(CUR_SCREEN_ID);
    if (id != pace.screen) { pace.screen = id; pace_reset(); }
    if (pace.held) {                                 /* a held frame: presented on the edge before its slot */
        uint32_t t = WORD(TARGET), te = WORD(TE_COUNT);
        if (t == pace.held || !pace_ok() || te + 1u >= pace_edges()) {
            PRESENT(pace.held); shown = pace.held; kn_gfx_pace_stats[5]++;
            int same = t == pace.held;
            pace.held = 0;
            if (same) {                              /* (not seen) the held buffer handed out again: draw into it */
                kn_gfx_stats[0]++;
                goto draw;
            }
        }
        skip_frame(dt); kn_gfx_skipped = 2;          /* 2: the toggle goes back (kn_gfx_finish), the same buffer next */
        return;
    }
    if (gov_skip(fc) && buffer_ok()) {
        skip_frame(dt); kn_gfx_gov_stats[0]++;
        return;
    }
    kn_gfx_stats[0]++;
draw:;
    /* drawn: the screens' updates get the governed frames' ticks too (R7, the players' ticks, stays this frame's) */
    uint32_t udt = (uint32_t)(dt > 0 ? dt : 0) + gov.pend_dt;
    if (udt > KN_GOV_DT_MAX) udt = KN_GOV_DT_MAX;
    if (dt > 0) dt = (int)udt;
    gov.pend_dt = 0; gov.last_draw = fc;
    if (gov.touched) { TOUCHED |= gov.touched; gov.touched = 0; }
    kn_gfx_skipped = 0;
    pace.start_te = (uint8_t)WORD(TE_COUNT); pace.start_fs = WORD(FRAMES_START);
    pace.measured = pace.start_te == 0;              /* handed out on a DMA edge: its draw time is a slot's */
    GS_FRAME(raster);                                /* record or render (screens/guiskip.c): R246's clear in a render */
    for (int i = 0; i < KN_GFX_SLOTS; i++) {         /* as R246's loop 0x01A3BBE8..0x01A3BC00 */
        uint8_t *scr = table[i];
        if (visible(scr, (int)WORD(CUR_SCREEN_ID))) update(scr, dt);
    }
}

/* Gfx_thread::Run 0x019AB8C8 (hook.S kn_gfx_finish_stub): R0 the buffer, R1 its end */
void kn_gfx_finish(uint32_t buf, uint32_t end)
{
    if (kn_gfx_skipped) {
        kn_gfx_skipped = 0;
        TOGGLE = (uint8_t)!TOGGLE;                   /* disp_draw_busy is still set: the ISR does not touch it */
        return;
    }
    if (TC_END(buf)) {                               /* the tape cache could not make this frame exact: not shown */
        pace.measured = 0;
        TOGGLE = (uint8_t)!TOGGLE;
        return;
    }
    CACHE_FLUSH(buf, end, 1);
    if (pace_finish()) { pace.held = buf; return; }
    PRESENT(buf);
    shown = buf;
}

/* ---- the plugin API (op1_plugin.h) ---- */
int op1_gfx_heavy(void) { return (int)kn_gfx_level; }
