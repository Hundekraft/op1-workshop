/* Bounded, Gfx-only cache of native RGB565 static SVG prefixes. The original renderer supplies every pixel;
 * no geometry, anti-aliasing, cap or paint-order approximation. Parsed trees remain owned by R246.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission (LICENSE, NOTICE). */
#pragma GCC optimize("no-tree-loop-distribute-patterns")
#include <stdint.h>
/* Row-aware codec: framebuffer padding is never sampled or overwritten. A zero result means overflow. */
uint32_t kn_artcache_encode(uint32_t *out,uint32_t cap,const uint16_t *fb,uint32_t w,uint32_t h,uint32_t stride)
{
    uint32_t used=0,n=0;uint16_t color=fb[0];
    for(uint32_t y=0;y<h;y++)for(uint32_t x=0;x<w;x++){
        uint16_t c=fb[y*stride+x];
        if(c==color && n<65535u)n++;
        else {if(used==cap)return 0;out[used++]=(n<<16)|color;color=c;n=1;}
    }
    if(used==cap)return 0;
    out[used++]=(n<<16)|color;return used;
}
/* Every pixel, as before 2026-11-09: kept for the A/B poke kn_artcache_full (emulator / debugger only). */
void kn_artcache_decode_all(const uint32_t *in,uint32_t used,uint16_t *fb,uint32_t w,uint32_t stride)
{
    uint32_t x=0;uint16_t *row=fb;
    for(uint32_t i=0;i<used;i++){
        uint32_t run=in[i],n=run>>16;uint16_t color=(uint16_t)run;
        while(n){
            uint32_t count=n<w-x?n:w-x;n-=count;
            uint16_t *p=row+x,*last=p+count;x+=count;
            while(p<last)*p++=color;
            if(x==w){x=0;row+=stride;}
        }
    }
}
/* Onto a raster that is already black (R246's frame clear, fb_clear_mdma, ran just before the screens draw): black
 * runs are only skipped, the others written as pixel pairs. The raster is a write-through page, so each store goes
 * to SDRAM; a mostly black screen costs a few thousand stores instead of 79,200. Same pixels as decode_all on a
 * black raster; nothing may be drawn before the cached layer (docs/screen-art.md). */
typedef uint32_t __attribute__((may_alias)) kn_pair;
void kn_artcache_decode(const uint32_t *in,uint32_t used,uint16_t *fb,uint32_t w,uint32_t stride)
{
    uint32_t x=0;uint16_t *row=fb;
    for(uint32_t i=0;i<used;i++){
        uint32_t run=in[i],n=run>>16;uint16_t color=(uint16_t)run;
        if(!color){x+=n;while(x>=w){x-=w;row+=stride;}continue;}
        uint32_t pair=color|(uint32_t)color<<16;
        while(n){
            uint32_t count=n<w-x?n:w-x;n-=count;
            uint16_t *p=row+x;x+=count;
            if(((uintptr_t)p&2u)){*p++=color;count--;}
            kn_pair *q=(kn_pair *)p;
            for(;count>=2;count-=2)*q++=pair;
            if(count)*(uint16_t *)q=color;
            if(x==w){x=0;row+=stride;}
        }
    }
}
#ifndef OP1_HOST
#include "../op1_plugin.h"
#include "kn_screens.h"
#include "../kn_mem.h"
#include "kn_gs.h"
#define CACHE_WORDS (KN_ARTCACHE_BYTES / 2u / 4u)
typedef struct { void *doc, *boundary; uint32_t used, age, gen; uint32_t *runs; } art_entry;
static art_entry entries[2];
static uint32_t age, gen;
volatile uint32_t kn_artcache_stats[3]; /* hits, misses, last encoded bytes; emulator/debugger only */
uint32_t kn_artcache_bytes;             /* arena bytes the cache took this boot (0: no user, or no room) */
volatile uint32_t kn_artcache_full;     /* 1: write every pixel as before 2026-11-09 (A/B poke; emulator/debugger only) */
extern volatile uint32_t kn_next, kn_arena_hi;
void *kn_alloc(uint32_t);
/* Allocation happens once, after all plugins load, before Gfx starts, and only when something can use it: a loaded
 * file that imports op1_screen_draw_cached (users, kn_boot.c) or compiled-in code that calls it
 * (kn_artcache_builtin, make_firmware.py's engines_table.c). Without the cache op1_screen_draw_cached draws
 * normally; a full arena likewise simply disables caching. */
extern const uint8_t kn_artcache_builtin;
void kn_artcache_init(int users)
{
    if(!users && !kn_artcache_builtin)return;
    if(kn_next>kn_arena_hi-KN_ARTCACHE_BYTES-KN_ARTCACHE_HEADROOM)return;
    uint32_t *p=kn_alloc(2u*CACHE_WORDS*4u);
    if(p){entries[0].runs=p;entries[1].runs=p+CACHE_WORDS;kn_artcache_bytes=2u*CACHE_WORDS*4u;}
}
/* kn_screens.c frees lazy documents: their entries go first, or a new document at the same address would replay them */
void kn_artcache_forget(void *doc)
{
    for(int i=0;i<2;i++)if(entries[i].doc==doc){entries[i].doc=0;entries[i].used=0;entries[i].age=0;}
}
static void reset(void *doc)
{
    uint8_t *v=*(uint8_t **)((uint8_t *)doc+0x54);
    ((void(*)(void *))*(void **)(v+0x7c))((uint8_t *)doc+*(int16_t *)(v+0x78));
}
/* Group::draw reads its matrix, child vector and visibility only. Copy that group header on the Gfx
 * stack so input-side lookup always sees the complete immutable parsed tree, even during a cache miss. */
static void draw_range(void *doc,void **begin,void **end,int dt)
{
    uint32_t copy[0x58/4];
    for(unsigned i=0;i<0x58/4;i++)copy[i]=((const uint32_t *)doc)[i];
    copy[0x44/4]=(uint32_t)begin;copy[0x48/4]=(uint32_t)end;
    /* Document::draw at0x01976560 sets R1=this before Group::draw. Keep that ORIGINAL document context:
     * it owns the colour/style vectors beyond the group header. The fourth argument is the native raster. */
    (void)dt;
    ((void(*)(void *,void *,const void *,void *))0x019eb818)(copy,doc,(const void *)0x01b60fd8,op1_raster());
}
/* op1_screen_cached_extra: the plugin's own static drawing for the next op1_screen_draw_cached call (one call) */
static void (*cached_extra)(void *scr);
void op1_screen_cached_extra(void (*fn)(void *scr)) { cached_extra = fn; }
/* Opt-in contract: a static, always-visible top-level prefix, drawn first onto the cleared native raster.
 * first_live is the first top-level child after that prefix, or NULL for an entirely static document.
 * This implementation deliberately falls back on non-default panels; it never guesses their row layout. */
void op1_screen_draw_cached(void *scr,int dt,void *first_live)
{
    uint32_t *r=op1_raster();
    void *doc=*(void **)scr;
    void (*xf)(void *)=cached_extra;cached_extra=0;   /* extra static drawing: with the prefix, or after a plain draw */
#define PLAIN() do{op1_screen_draw(scr,dt);if(xf)xf(scr);return;}while(0)
    if(!entries[0].runs || !doc || !*(volatile uint32_t *)0x01b60ffc || r[1]!=198 || r[2]!=512 || r[3]!=400)PLAIN();
    /* Document::draw is the verified 26-byte forwarder to Group::draw. */
    uint8_t *vt=*(uint8_t **)((uint8_t *)doc+0x54);
    if(*(uint32_t *)(vt+0x14)!=0x01976560u || *(int16_t *)(vt+0x10)!=0)PLAIN();
    void **begin=*(void ***)((uint8_t *)doc+0x44), **end=*(void ***)((uint8_t *)doc+0x48), **stop=end;
    if(first_live){for(stop=begin;stop<end && *stop!=first_live;stop++);if(stop==end)PLAIN();}
    if(stop==begin || end-begin>1024)PLAIN();
    /* Prefix nodes may not be transformed/recoloured/hidden by callers. All mutable nodes belong to the suffix. */
    art_entry *e=0;for(int i=0;i<2;i++)if(entries[i].doc==doc && entries[i].boundary==first_live)e=&entries[i];
    uint16_t *fb=(uint16_t *)(uintptr_t)r[0];
    /* The frame skip (screens/guiskip.c) hashes R246's drawing calls; the restored pixels below bypass them, so the
     * prefix is hashed as (document, boundary, which encoding) on a hit and a miss alike, and its own drawing (a miss)
     * is not. A record frame rasterises nothing: no decode (it would only fill the scratch buffer) and no encode (the
     * scratch would hold no prefix); a miss there is marked so the frame differs, and the next render frame encodes. */
    int rec=kn_gs_recording();
    if(e){
        if(!e->used)PLAIN(); /* an oversized prefix retains normal SVG caching */
        kn_artcache_stats[0]++;
        op1_screen_hash(scr,(uint32_t)doc);op1_screen_hash(scr,(uint32_t)first_live);op1_screen_hash(scr,e->gen);
        if(rec){}
        else if(kn_artcache_full)kn_artcache_decode_all(e->runs,e->used,fb,198,256);
        else kn_artcache_decode(e->runs,e->used,fb,198,256);
    }else if(rec){
        op1_screen_hash(scr,(uint32_t)doc);op1_screen_hash(scr,0xA27C0DEu);   /* not cached yet: the next frame renders */
        if(xf)xf(scr);
        e=0;
    }else{
        e=entries[0].age<=entries[1].age?&entries[0]:&entries[1];e->doc=0;e->used=0;
        int was=kn_gs_nohash(1);
        draw_range(doc,begin,stop,dt);
        if(xf)xf(scr);                                   /* the plugin's static drawing joins the captured pixels */
        kn_gs_nohash(was);
        e->used=kn_artcache_encode(e->runs,CACHE_WORDS,fb,198,400,256);
        e->doc=doc;e->boundary=first_live;e->gen=++gen;
        op1_screen_hash(scr,(uint32_t)doc);op1_screen_hash(scr,(uint32_t)first_live);op1_screen_hash(scr,e->gen);
        kn_artcache_stats[1]++;kn_artcache_stats[2]=e->used*4u;
        /* Release the hundreds of per-shape raster chunks; the bitmap owns the static pixels now. */
        if(e->used)reset(doc);
        else { e->doc=doc;e->boundary=first_live; }
    }
    if(e)e->age=++age;
    if(stop!=end){
        draw_range(doc,stop,end,dt);
    }
#undef PLAIN
}

#endif
