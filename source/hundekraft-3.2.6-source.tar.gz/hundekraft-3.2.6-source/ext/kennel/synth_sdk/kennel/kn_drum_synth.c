/* Shared native drum-synth routing; no instrument DSP or fixed instrument memory.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "../op1_feature_drum_synth.h"
#include "../kn_mem.h"                 /* kn_audio_text */
#include "../op1_synth.h"
#include "kn_shed.h"
#define MAX_DRUM_SYNTHS 4
static const op1_drum_synth_t *providers[MAX_DRUM_SYNTHS];
static unsigned count kn_hot;
static uint8_t muted[MAX_DRUM_SYNTHS];
static uint32_t block_cycles[MAX_DRUM_SYNTHS];
static uint16_t overload_strikes[MAX_DRUM_SYNTHS];
volatile uint32_t kn_ds_stack_fault;
static int stack_warning;
void *kn_ds_stack_top[4];
extern int kn_feature_count(void);
extern int kn_feature_initializing;
extern const op1_feature_t *kn_feature_at(int);
extern const char *const kn_drum_synth_names[];
extern const char *const kn_drum_synth_state_keys[];
static int equal(const char *a,const char *b){if(!a||!b)return 0;for(unsigned i=0;i<16;i++){if(a[i]!=b[i])return 0;if(!a[i])return 1;}return 0;}
int kn_ds_name(const char *s,uint32_t len){if(!s||!len||len>15)return 0;for(unsigned i=0;kn_drum_synth_names[i];i++){const char *n=kn_drum_synth_names[i];unsigned k=0;while(k<len&&s[k]==n[k]&&n[k])k++;if(k==len&&!n[k])return 1;}return 0;}
static const op1_drum_synth_t *asset_owner[MAX_DRUM_SYNTHS];
static char asset_path[MAX_DRUM_SYNTHS][48];
void kn_ds_asset(const op1_drum_synth_t *d,const char *path){
 if(!d||!path)return;
 unsigned len=0;while(len<48&&path[len])len++;if(len==48)return;
 for(unsigned i=0;i<MAX_DRUM_SYNTHS;i++)if(!asset_owner[i]||asset_owner[i]==d){
  asset_owner[i]=d;for(unsigned j=0;j<=len;j++)asset_path[i][j]=path[j];return;
 }
}
const char *op1_drum_synth_svg(const char *name){
 for(unsigned i=0;i<count;i++)if(equal(providers[i]->name,name))
  for(unsigned j=0;j<MAX_DRUM_SYNTHS;j++)if(asset_owner[j]==providers[i])return asset_path[j];
 return 0;
}
int op1_drum_synth_register(const op1_drum_synth_t *d){
 int declared=0;for(int i=0;i<kn_feature_count();i++)if(kn_feature_at(i)->drum_synth==d)declared=1;
 if(!kn_feature_initializing||!declared||!d||d->api!=OP1_DRUM_SYNTH_API||d->size!=sizeof(*d)||!d->name||!d->name[0]||!d->state_key||!d->type||!d->factory||!d->route||!d->trigger||!d->render||!d->status||!d->release||count==MAX_DRUM_SYNTHS)return -1;
 for(unsigned i=0;i<count;i++)if(equal(d->name,providers[i]->name))return -1;
 if(!kn_ds_stack_top[0]){
  unsigned char *p=op1_alloc(4*(4096+32));if(!p)return -1;
  for(unsigned i=0;i<4;i++){uint32_t *guard=(uint32_t *)(p+i*(4096+32));*guard=0x4453594e;kn_ds_stack_top[i]=(unsigned char *)guard+16+4096;}
 }
 providers[count++]=d;return 0;
}
static int stacks_ok(void){for(unsigned i=0;i<4;i++)if(kn_ds_stack_top[i]&&*(volatile uint32_t *)((unsigned char *)kn_ds_stack_top[i]-4096-16)!=0x4453594e){kn_ds_stack_fault|=1u<<i;return 0;}return 1;}
kn_audio_text void kn_ds_audio_begin(void){for(unsigned i=0;i<count;i++)block_cycles[i]=0;}
/* Overload: the whole callback over the measured block (kn_audio_block_cycles(): 580,499 cycles on the unit,
 * 1,160,997 in the emulator) for KN_BYPASS_BLOCKS callbacks in a row, each with this provider at least a quarter of
 * it, mutes the provider (kn_shed.h kn_overrun_tick, the engine bypass's count). The engine bypass keeps its own
 * count, so both can fire in the same callback. */
kn_audio_text void kn_ds_audio_end(uint32_t used){for(unsigned i=0;i<count;i++){
 if(muted[i])continue;
 if(block_cycles[i]<used/4){overload_strikes[i]=0;continue;}
 if(kn_overrun_tick(&overload_strikes[i],used)){muted[i]=1;if(providers[i]->reset)providers[i]->reset();op1_toast("Drum synth muted: overload");}
}}
static unsigned index_of(const op1_drum_synth_t *d){for(unsigned i=0;i<count;i++)if(providers[i]==d)return i;return 0;}
static const op1_drum_synth_t *routed(const void *p){for(unsigned i=0;i<count;i++)if(providers[i]->route(p))return providers[i];
 return 0;}
#define STOCK(addr,type) ((type)(addr))
#ifdef OP1_HOST
uint32_t kn_ds_host_render_cycles;                  /* host tests: what one provider render costs */
#define KN_DS_ELAPSED(t) ((void)(t),kn_ds_host_render_cycles)
#else
#define KN_DS_ELAPSED(t) (op1_cycles()-(t))
#endif
static const op1_drum_synth_t *json_owner(const void *json){
 const void *v=STOCK(0x019BEB70,const void *(*)(const void *,const char *))(json,"type");
 if(!v||((const unsigned char *)v)[8]!=4)return 0;
 const char *name=*(const char *const *)v;
 for(unsigned i=0;i<count;i++)if(equal(name,providers[i]->name))return providers[i];
 return 0;
}
static void *patch(unsigned slot){return (void *)(uintptr_t)(0x01DDD9ACu+(slot&7)*0x38);}
static const op1_drum_synth_t *current(void){return !count?0:json_owner(patch(*(volatile uint32_t *)0xFF8016D8));}
uint32_t kn_ds_type(const void *s,uint32_t caller,const void *patch){
 typedef struct{uint32_t alloc;union{char buf[16];const char *ptr;}u;uint32_t size,cap;} name_string;
 const name_string *name=s;const char *text=name->cap>15?name->u.ptr:name->u.buf;
 uint32_t result=op1_drum_synth_stock_type(s);
 for(unsigned i=0;i<count;i++){
  uint32_t value=providers[i]->type(s,caller,patch);
  if(name->size<=15&&equal(text,providers[i]->name))result=value;
 }
 return result;
}
uint32_t kn_ds_factory(uint32_t type){const op1_drum_synth_t *d=count?json_owner(patch(*(volatile uint32_t *)0x01AAAC10)):0;return d?d->factory(type):STOCK(0x01A1B9C0,uint32_t (*)(uint32_t,void **,uint32_t))(type,(void **)0x01AAAD30,*(volatile uint32_t *)0x01AAAC10);}
uint32_t kn_ds_route(const void *p){return routed(p)!=0;}
uint32_t kn_ds_trigger(void *p,const int16_t *w){const op1_drum_synth_t *d=routed(p);return d?(muted[index_of(d)]||!stacks_ok()?0:d->trigger(p,w)):STOCK(0x01970DE6,uint32_t (*)(void *,const int16_t *))(p,w);}
uint32_t kn_ds_render(void *p,int16_t *o,const int16_t *w){
 uint32_t t=op1_cycles(),r;const op1_drum_synth_t *d=routed(p);unsigned i=index_of(d);
 if(d&&(muted[i]||!stacks_ok())){for(unsigned n=0;n<128;n++)o[n]=0;return 0;}
 r=d?d->render(p,o,w):STOCK(0x01970EE8,uint32_t (*)(void *,int16_t *,const int16_t *))(p,o,w);
 uint32_t elapsed=KN_DS_ELAPSED(t);sm_cy[SMC_DRUM]+=elapsed;
 if(d)block_cycles[i]=elapsed>0xffffffffu-block_cycles[i]?0xffffffffu:block_cycles[i]+elapsed;
 if(!stacks_ok()){for(unsigned n=0;n<128;n++)o[n]=0;for(i=0;i<count;i++)muted[i]=1;}
 return r;
}
uint32_t kn_ds_status(const void *p){const op1_drum_synth_t *d=routed(p);return d?((muted[index_of(d)]||!stacks_ok())?0:d->status(p)):STOCK(0x01970E5C,uint32_t (*)(const void *))(p);}
uint32_t kn_ds_release(void *p,const int16_t *w){const op1_drum_synth_t *d=routed(p);return d?(!stacks_ok()?0:d->release(p,w)):STOCK(0x01970E7E,uint32_t (*)(void *,const int16_t *))(p,w);}
void kn_ds_ctor(void){for(unsigned i=0;i<count;i++)if(providers[i]->screen_ctor)providers[i]->screen_ctor();}
void kn_ds_load(void *table){for(unsigned i=0;i<count;i++)if(providers[i]->screen_load)providers[i]->screen_load(table);}
uint32_t kn_ds_screen(void){const op1_drum_synth_t *d=current();for(unsigned i=0;i<count;i++)if(providers[i]!=d&&providers[i]->screen_select)providers[i]->screen_select();return d&&d->screen_select?d->screen_select():0x11;}
int kn_ds_key(int code,int down){for(unsigned i=0;i<count;i++)if(providers[i]->key&&providers[i]->key(code,down))return 1;return 0;}
int kn_ds_knob(int knob,const int16_t *delta){for(unsigned i=0;i<count;i++)if(providers[i]->knob&&providers[i]->knob(knob,delta))return 1;return 0;}
uint32_t kn_ds_json_equal(const void *a,const void *b){uint32_t r=STOCK(0x019BDEA4,uint32_t (*)(const void *,const void *))(a,b);for(unsigned i=0;i<count&&!r;i++)if(providers[i]->json_equal)r=providers[i]->json_equal(a,b);
 if(!r&&a&&b&&((const unsigned char *)a)[8]==4&&((const unsigned char *)b)[8]==4){
  const char *name=*(const char *const *)a,*lit=*(const char *const *)b;
  if(equal(lit,"dbox")){unsigned n=0;while(n<16&&name[n])n++;r=kn_ds_name(name,n);}
 }
 return r;}
uint32_t kn_ds_preset_query(void *out,void *db,const char *table){/* Every drum synth shares the same browser cap; first provider owns its filter. */for(unsigned i=0;i<count;i++)if(providers[i]->preset_query)return providers[i]->preset_query(out,db,table);char query[256];unsigned n=0;const char *prefix="drum_presets WHERE folder NOT IN ('";
 while(*prefix)query[n++]=*prefix++;
 for(unsigned i=0;kn_drum_synth_names[i];i++){const char *p=kn_drum_synth_names[i];while(*p&&n<sizeof(query)-6)query[n++]=*p++;query[n++]='\'';query[n++]=',';query[n++]='\'';}
 query[n++]='\'';query[n++]=')';query[n]=0;
 return STOCK(0x0196FE8C,uint32_t (*)(void *,void *,const char *))(out,db,query);
}
static volatile unsigned type_change_depth;
static volatile uint32_t save_epoch[8];
uint32_t op1_drum_synth_save_epoch(unsigned slot){
 if(slot>=8||type_change_depth||save_epoch[slot]==0xffffffffu)return 0;
 return save_epoch[slot]+1;
}
static void type_begin(unsigned slot){
 type_change_depth++;
 if(slot<8&&save_epoch[slot]!=0xffffffffu)save_epoch[slot]++;
}
void kn_ds_type_changing(void *json){
 unsigned slot=8;
 for(unsigned i=0;i<8;i++)if(json==patch(i)){slot=i;break;}
 type_begin(slot);
 if(!json)return;
 for(unsigned i=0;kn_drum_synth_state_keys[i];i++){
  uint32_t removed[4];
  STOCK(0x019BEE88,void (*)(void *,void *,const char *))(json,removed,kn_drum_synth_state_keys[i]);
  STOCK(0x019BDD18,void (*)(void *,int))(removed,2);
 }
}
void kn_ds_type_changed(void){if(type_change_depth)type_change_depth--;}
uint32_t kn_ds_preset_copy(void *out,uint32_t slot,const void *json){
 type_begin(slot);
 const op1_drum_synth_t *d=json_owner(json);
 uint32_t r=d&&d->preset_copy?d->preset_copy(out,slot,json):STOCK(0x01A04C48,uint32_t (*)(void *,uint32_t,const void *))(out,slot,json);
 kn_ds_type_changed();return r;
}
uint32_t kn_ds_snapshot_read(void *out,uint32_t slot){const op1_drum_synth_t *d=json_owner(patch(slot));if(d&&d->snapshot_read)return d->snapshot_read(out,slot);STOCK(0x01995BAC,void (*)(void *,uint32_t))(out,slot);return 0;}
void kn_ds_snapshot_save(uint32_t slot,const void *s){const op1_drum_synth_t *d=json_owner(patch(slot));if(d&&d->snapshot_save)d->snapshot_save(slot,s);else STOCK(0x01995C88,void (*)(uint32_t,const void *))(slot,s);}
uint32_t kn_ds_normalize(void *json,uint32_t mode){
 /* Some native snapshot paths assign directly, without preset_copy. */
 for(unsigned i=0;i<8;i++)if(json==patch(i)&&save_epoch[i]!=0xffffffffu){save_epoch[i]++;break;}
 const op1_drum_synth_t *d=json_owner(json);if(d&&d->normalize)return d->normalize(json,mode);
 const void *vtype=STOCK(0x019BEB70,const void *(*)(const void *,const char *))(json,"type");
 if(!vtype||((const unsigned char *)vtype)[8]!=4)return op1_drum_synth_stock_normalize(json,mode);
 const char *name=*(const char *const *)vtype;unsigned len=0;while(len<16&&name[len])len++;
 if(!kn_ds_name(name,len))return op1_drum_synth_stock_normalize(json,mode);
 /* Preserve recognized opaque state even with its provider absent. No schema
  * interpretation here: the reinstalled provider must validate before use. */
 uint32_t saved[MAX_DRUM_SYNTHS][4];unsigned n=0;
 for(unsigned i=0;i<MAX_DRUM_SYNTHS*4;i++)((volatile uint32_t *)saved)[i]=0;
 for(;n<MAX_DRUM_SYNTHS&&kn_drum_synth_state_keys[n];n++){
  const void *v=STOCK(0x019BEB70,const void *(*)(const void *,const char *))(json,kn_drum_synth_state_keys[n]);
  if(v&&(uintptr_t)v!=0x01DD4FE4u)STOCK(0x019BDDC0,void *(*)(void *,const void *))(saved[n],v);
 }
 uint32_t r=op1_drum_synth_stock_normalize(json,mode);
 for(unsigned i=0;i<n;i++){
  if(!r&&((unsigned char *)saved[i])[8]){void *v=STOCK(0x019BFEB4,void *(*)(void *,const char *))(json,kn_drum_synth_state_keys[i]);STOCK(0x019BDDC0,void *(*)(void *,const void *))(v,saved[i]);}
  STOCK(0x019BDD18,void (*)(void *,int))(saved[i],2);
 }
 return r;
}
/* R246's background file worker (BgFileWorker, priority below OP_Main) runs jobs that serialize a live slot patch
 * with jsoncpp: the slot save (0x01940574, UPDATE drum_slots/synth_slots), two other patch jobs and the type jobs
 * (dp_type_job, sp_type_job). OP_Main can preempt such a job inside the writer. If the main loop then replaces
 * that patch's JSON (a provider publishing its working save), the writer walks freed nodes and R246 stops at
 * json_value.cpp:1029 (rc-3.1 beta, Gin). While a job runs, provider services are not called and providers
 * must not modify live patch JSON (op1_drum_synth_patch_busy). Only the worker thread changes the count. */
static volatile uint32_t stock_patch_jobs;
uint32_t op1_drum_synth_patch_busy(void){return stock_patch_jobs;}
void kn_ds_patch_job_begin(void){stock_patch_jobs++;}
void kn_ds_patch_job_end(void){if(stock_patch_jobs)stock_patch_jobs--;}
#ifdef OP1_HOST
void kn_ds_host_stock_job(uint32_t addr,void *job);
#define STOCK_JOB(addr,job) kn_ds_host_stock_job(addr,job)
#else
#define STOCK_JOB(addr,job) STOCK(addr,void (*)(void *))(job)
#endif
static void patch_job(uint32_t addr,void *job){kn_ds_patch_job_begin();STOCK_JOB(addr,job);kn_ds_patch_job_end();}
void kn_ds_slot_save_job(void *job){patch_job(0x01940574u,job);}   /* job vtable 0x0190F4AC run */
void kn_ds_patch_job_a(void *job){patch_job(0x0193F578u,job);}     /* job vtable 0x0190F2F4 run */
void kn_ds_patch_job_b(void *job){patch_job(0x019407DCu,job);}     /* job vtable 0x0190F3A4 run */
void kn_ds_service(void){if(type_change_depth||stock_patch_jobs)return;if(kn_ds_stack_fault&&!stack_warning){stack_warning=1;for(unsigned i=0;i<count;i++)muted[i]=1;op1_toast("Drum synth stack fault");}for(unsigned i=0;i<count;i++)if(providers[i]->service)providers[i]->service();}
void kn_ds_reset(void){for(unsigned i=0;i<count;i++)if(providers[i]->reset)providers[i]->reset();}

void kn_drum_synth_finish(void){
 for(unsigned i=0;kn_drum_synth_names[i];i++){
  int found=0;for(unsigned j=0;j<count;j++)if(equal(providers[j]->name,kn_drum_synth_names[i]))found=1;
  if(found)continue;
  char sql[96];const char *prefix="DELETE FROM drum_types WHERE type='";unsigned n=0;
  while(*prefix)sql[n++]=*prefix++;
  const char *name=kn_drum_synth_names[i];while(*name&&n<sizeof(sql)-3)sql[n++]=*name++;
  sql[n++]='\'';sql[n]=0;
#ifndef OP1_HOST
  /* only when the row is there: the same WHERE as a SELECT (no write transaction on every boot) */
  char sel[96];const char *sp="SELECT id FROM drum_types WHERE type='";unsigned k=0;while(*sp)sel[k++]=*sp++;
  for(unsigned m=sizeof "DELETE FROM drum_types WHERE type='"-1;m<=n&&k<sizeof(sel)-1;m++)sel[k++]=sql[m];
  sel[k]=0;
  void *fdb=STOCK(0x0196DD38,void *(*)(void))();
  if(op1_db_has(fdb,sel))op1_db_write(fdb,sql);
#endif
 }
}
