/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#ifndef KN_CORE_ROWS_H
#define KN_CORE_ROWS_H
/* Our rows in content/op1_factory.db, kept right by the core at boot (synth_sdk/core_rows.json lists them):
 * ensure a row when its plugin or slot is there, remove the rows of our types whose plugin is not registered.
 * "Ours" = a type name the core was built with (make_firmware.core_owned: kn_own_synth / _fx / _seq, drum+, quad)
 * or a row the core inserted itself (marked in kennel_owned, as kn_seq_rows.h marks kennel_seq_owned). Stock rows
 * and rows we don't own are never touched. Every write runs only after a has() SELECT says it would change
 * something, so a boot with nothing to change writes nothing (op1r 46 3f733a8's pattern). A failing statement only
 * leaves its row as it was: exec's result is not acted on.
 * noinline: keep the SQL helpers out of kn_boot.c's large body (the Blackfin GCC 13.3 tail-drop anomaly,
 * kn_seq_rows.h; ARCHITECTURE.md "Boot writes only when needed"). */
typedef int (*kn_cr_exec_t)(void *db, const char *sql);         /* op1_db_write */
typedef int (*kn_cr_has_t)(void *db, const char *select);       /* op1_db_has */

static char *kn_cr_cat(char *d, const char *s) { while (*s) *d++ = *s++; *d = 0; return d; }
static char *kn_cr_num(char *d, int v)
{
    char t[12]; int n = 0;
    if (v < 0) { *d++ = '-'; v = -v; }
    do t[n++] = (char)('0' + v % 10); while (v /= 10);
    while (n) *d++ = t[--n];
    *d = 0;
    return d;
}
/* a type name we put in SQL: 1..15 of a-z 0-9 space _ + - (in a room, juni chorus, drum+); no quote */
static int kn_cr_name(const char *s)
{
    unsigned n = 0;
    if (!s) return 0;
    for (; s[n]; n++)
        if (n >= 15 || !((s[n] >= 'a' && s[n] <= 'z') || (s[n] >= '0' && s[n] <= '9') || s[n] == ' ' || s[n] == '_'
                         || s[n] == '+' || s[n] == '-')) return 0;
    return n > 0;
}
static int kn_cr_eq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
static int kn_cr_in(const char *name, const char *const *list, unsigned n)
{
    for (unsigned i = 0; i < n; i++) if (list[i] && kn_cr_eq(list[i], name)) return 1;
    return 0;
}

#define KN_CR_SQL 1400                                          /* 63 registered names x 18 + the statement */
#define KN_CR_MARKS "kennel_owned"
static __attribute__((noinline)) void kn_cr_marks_table(void *db, kn_cr_exec_t exec, kn_cr_has_t has)
{
    if (!has(db, "SELECT name FROM sqlite_master WHERE type='table' AND name='" KN_CR_MARKS "'"))
        exec(db, "CREATE TABLE IF NOT EXISTS " KN_CR_MARKS " (tbl TEXT NOT NULL, type TEXT NOT NULL, PRIMARY KEY (tbl, type))");
}
/* mark a row the core just inserted (row_ensure): cleanup may remove it once its plugin is gone */
static __attribute__((noinline)) void kn_cr_mark(void *db, const char *tbl, const char *type, kn_cr_exec_t exec, kn_cr_has_t has)
{
    if (!kn_cr_name(type)) return;
    kn_cr_marks_table(db, exec, has);
    char sql[128], *o = kn_cr_cat(sql, "INSERT OR IGNORE INTO " KN_CR_MARKS " VALUES ('");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, tbl), "','"), type); kn_cr_cat(o, "')");
    exec(db, sql);
}

/* the row of `type` in tbl (id, type, default_params; params 0: a table without them, seq_types) when there is
 * none: at id `pref` if that is free (pref > 0), else after the highest id */
static __attribute__((noinline)) void kn_cr_ensure(void *db, const char *tbl, const char *type, const char *params, int pref,
                                                   kn_cr_exec_t exec, kn_cr_has_t has)
{
    if (!kn_cr_name(type)) return;
    char sql[320], *o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "SELECT id FROM "), tbl), " WHERE type='");
    kn_cr_cat(kn_cr_cat(o, type), "'");
    if (has(db, sql)) return;
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "INSERT INTO "), tbl), " SELECT ");
    if (pref > 0) {
        o = kn_cr_num(kn_cr_cat(kn_cr_cat(kn_cr_cat(o, "CASE WHEN EXISTS (SELECT 1 FROM "), tbl), " WHERE id="), pref);
        o = kn_cr_num(kn_cr_cat(kn_cr_cat(kn_cr_cat(o, ") THEN (SELECT MAX(id)+1 FROM "), tbl), ") ELSE "), pref);
        o = kn_cr_cat(o, " END");
    } else
        o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, "(SELECT COALESCE(MAX(id),0)+1 FROM "), tbl), ")");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, ",'"), type), "'");
    if (params) o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, ",'"), params), "'");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, " WHERE NOT EXISTS (SELECT 1 FROM "), tbl), " WHERE type='");
    kn_cr_cat(kn_cr_cat(o, type), "')");
    exec(db, sql);
}
/* keep an existing row's default_params at `params` (the filter row: a core patch or plugin-only update never sends
 * op1_factory.db, so a unit keeps the row an older core wrote; owner 2026-11-10: a fresh FILTER pick starts at
 * kennel's defaults). R246 reads default_params only for a fresh pick; saved sounds keep their own words. Writes only
 * when the row differs. */
static __attribute__((noinline)) void kn_cr_params(void *db, const char *tbl, const char *type, const char *params,
                                                   kn_cr_exec_t exec, kn_cr_has_t has)
{
    if (!kn_cr_name(type) || !params) return;
    char sql[320], *o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "SELECT id FROM "), tbl), " WHERE type='");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, type), "' AND default_params<>'"), params);
    kn_cr_cat(o, "'");
    if (!has(db, sql)) return;
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "UPDATE "), tbl), " SET default_params='");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, params), "' WHERE type='"), type);
    kn_cr_cat(o, "'");
    exec(db, sql);
}

/* the row of `type` at exactly `id` (drum+: OP1_DRUM_TYPE_ID, compiled into kn_drum.c and dp_fw.c). When a row we own
 * (movable: their ids carry no meaning, e.g. gin, resolved by name) holds that id, it moves to the end first. A
 * row of `type` at another id, or a foreign row at `id`, is left alone: nothing is inserted then. */
static __attribute__((noinline)) void kn_cr_ensure_at(void *db, const char *tbl, const char *type, const char *params, int id,
                                                      const char *const *movable, kn_cr_exec_t exec, kn_cr_has_t has)
{
    if (!kn_cr_name(type)) return;
    char sql[320], idt[12], *o;
    kn_cr_num(idt, id);
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "SELECT id FROM "), tbl), " WHERE type='");
    kn_cr_cat(kn_cr_cat(o, type), "'");
    if (has(db, sql)) return;
    char in[160], *p = kn_cr_cat(in, "('");
    for (unsigned i = 0; movable && movable[i]; i++)
        if (kn_cr_name(movable[i]) && !kn_cr_eq(movable[i], type)) p = kn_cr_cat(kn_cr_cat(p, movable[i]), "','");
    kn_cr_cat(p, "')");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "SELECT id FROM "), tbl), " WHERE id=");
    kn_cr_cat(kn_cr_cat(kn_cr_cat(o, idt), " AND type IN "), in);
    if (has(db, sql)) {
        o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "UPDATE "), tbl), " SET id=(SELECT MAX(id)+1 FROM ");
        o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, tbl), ") WHERE id="), idt);
        kn_cr_cat(kn_cr_cat(o, " AND type IN "), in);
        exec(db, sql);
    }
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "INSERT INTO "), tbl), " SELECT ");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(kn_cr_cat(o, idt), ",'"), type), "'");
    if (params) o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, ",'"), params), "'");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, " WHERE NOT EXISTS (SELECT 1 FROM "), tbl), " WHERE id=");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, idt), " OR type='"), type);
    kn_cr_cat(o, "')");
    exec(db, sql);
}

/* remove the rows in tbl of our types that are not registered now: own (0-terminated, the names the core was built
 * with) and, when marks, the rows marked in kennel_owned. reg: the registered names of this kind (n of them). */
static __attribute__((noinline)) void kn_cr_cleanup(void *db, const char *tbl, const char *const *own, const char *const *reg,
                                                    unsigned n, int marks, kn_cr_exec_t exec, kn_cr_has_t has)
{
    char sql[KN_CR_SQL], *o, *w;
    /* our built-in names that are not registered: one statement per 32 names */
    for (unsigned i = 0; own && own[i];) {
        unsigned k = 0;
        w = kn_cr_cat(sql + 32, " WHERE type IN ('");
        for (; own[i] && k < 32; i++)
            if (kn_cr_name(own[i]) && !kn_cr_in(own[i], reg, n)) { w = kn_cr_cat(kn_cr_cat(w, own[i]), "','"); k++; }
        if (!k) continue;
        kn_cr_cat(w, "')");
        char head[48];                                          /* "SELECT type FROM tbl" / "DELETE FROM tbl", */
        o = kn_cr_cat(kn_cr_cat(head, "SELECT type FROM "), tbl);   /* right-aligned against the WHERE at +32 */
        unsigned hl = (unsigned)(o - head);
        if (hl > 32) return;
        for (unsigned j = 0; j < hl; j++) sql[32 - hl + j] = head[j];
        if (!has(db, sql + 32 - hl)) continue;
        o = kn_cr_cat(kn_cr_cat(head, "DELETE FROM "), tbl);
        hl = (unsigned)(o - head);
        for (unsigned j = 0; j < hl; j++) sql[32 - hl + j] = head[j];
        exec(db, sql + 32 - hl);
    }
    if (!marks) return;
    /* rows the core inserted: marked, and their type not registered (or the mark outlived its row) */
    if (!has(db, "SELECT name FROM sqlite_master WHERE type='table' AND name='" KN_CR_MARKS "'")) return;
    char list[KN_CR_SQL - 300], *l = kn_cr_cat(list, "('");
    for (unsigned i = 0; i < n; i++) {
        if (!kn_cr_name(reg[i])) continue;                      /* (never marked: kn_cr_mark checks the same) */
        if ((unsigned)(l - list) + 20 >= sizeof list) return;   /* can't list them all: remove nothing */
        l = kn_cr_cat(kn_cr_cat(l, reg[i]), "','");
    }
    kn_cr_cat(l, "')");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "SELECT type FROM " KN_CR_MARKS " WHERE tbl='"), tbl), "' AND (type NOT IN ");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, list), " OR type NOT IN (SELECT type FROM "), tbl);
    kn_cr_cat(o, "))");
    if (!has(db, sql)) return;
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "DELETE FROM "), tbl), " WHERE type IN (SELECT type FROM " KN_CR_MARKS " WHERE tbl='");
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(o, tbl), "') AND type NOT IN "), list);
    exec(db, sql);
    o = kn_cr_cat(kn_cr_cat(kn_cr_cat(sql, "DELETE FROM " KN_CR_MARKS " WHERE tbl='"), tbl), "' AND type NOT IN (SELECT type FROM ");
    kn_cr_cat(kn_cr_cat(o, tbl), ")");
    exec(db, sql);
}

/* the boot pass after every plugin and feature registered (kn_boot.c kn_rows_finish fills it) */
typedef struct {
    const char *iter, *filter, *quad;                           /* default_params of the always / quad rows */
    int filter_id;                                              /* filter's id when free (patch_db: 2) */
    const char *const *own_synth, *const *own_fx, *const *own_seq;   /* make_firmware.core_owned */
    const char *const *synth, *const *fx, *const *seq;          /* registered names */
    unsigned n_synth, n_fx, n_seq;
    const char *drum;                                           /* the registered drum type (drum+), or 0 */
    const char *const *lfo;                                     /* the registered LFO types' names (quad, pond) */
    unsigned n_lfo;
    const char *pond;                                           /* default_params of the pond row */
} kn_cr_boot_t;
static __attribute__((noinline)) void kn_cr_finish(void *db, const kn_cr_boot_t *b, kn_cr_exec_t exec, kn_cr_has_t has)
{
    static const char *const own_drum[] = { "drum+", 0 }, *const own_lfo[] = { "quad", "pond", 0 };   /* (gin: kn_drum_synth_finish) */
    kn_cr_ensure(db, "synth_types", "iter", b->iter, 0, exec, has);              /* the plugins' hosts: always */
    kn_cr_ensure(db, "fx_types", "filter", b->filter, b->filter_id, exec, has);
    kn_cr_params(db, "fx_types", "filter", b->filter, exec, has);                  /* its defaults kept current */
    kn_cr_cleanup(db, "synth_types", b->own_synth, b->synth, b->n_synth, 1, exec, has);
    kn_cr_cleanup(db, "fx_types", b->own_fx, b->fx, b->n_fx, 1, exec, has);
    kn_cr_cleanup(db, "seq_types", b->own_seq, b->seq, b->n_seq, 0, exec, has);     /* marks: kn_seq_rows_cleanup */
    kn_cr_cleanup(db, "drum_types", own_drum, &b->drum, b->drum ? 1 : 0, 0, exec, has);
    for (unsigned i = 0; i < b->n_lfo; i++) {                    /* quad first (id 8), then pond (9) */
        if (kn_cr_eq(b->lfo[i], "quad")) kn_cr_ensure(db, "lfo_types", "quad", b->quad, 0, exec, has);
    }
    for (unsigned i = 0; i < b->n_lfo; i++) {
        if (kn_cr_eq(b->lfo[i], "pond")) kn_cr_ensure(db, "lfo_types", "pond", b->pond, 0, exec, has);
    }
    kn_cr_cleanup(db, "lfo_types", own_lfo, b->lfo, b->n_lfo, 0, exec, has);
}
#endif
