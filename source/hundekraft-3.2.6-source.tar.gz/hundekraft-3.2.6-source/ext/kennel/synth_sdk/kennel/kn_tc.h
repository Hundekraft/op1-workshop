/* The tape screen's static layer cache (screens/tapecache.c, ARCHITECTURE.md "Gfx frames: the tape cache").
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (LICENSE, NOTICE). */
#ifndef KN_TC_H
#define KN_TC_H
#include <stdint.h>

#define KN_TC_SCREEN     0x15u                 /* R246's tape screen id (current_screen_id 0x018B65C8) */
#define KN_TC_OPS        768                   /* drawing calls logged per frame (the tape page draws ~200..400) */
#define KN_TC_RAS        512                   /* rasterizers tracked by their points (open addressing) */
#define KN_TC_REPAIR     8                     /* repair rectangles per frame (then merged) */
#define KN_TC_VOL_FRAMES 90u                   /* a shape that went missing: not cached for 3 s (then 6, 12 .. 48 s) */
#define KN_TC_QUIET      2u                    /* a shape's rasterizer without new points this many frames: cacheable */
#define KN_TC_BUILD_GAP  15u                   /* frames at least between two cache builds .. */
#define KN_TC_MISS_AREA  3000u                 /* .. unless forced: still draws outside the cache cover this many pixels */
#define KN_TC_MISS_CY    60000u                /* .. or cost this many cycles (a frame at 30 fps has 13 M) .. */
#define KN_TC_MISS_RUN   15u                   /* .. for this many frames in a row: build again */
#define KN_TC_VERIFY_N   4u                    /* GS_VERIFY builds: every 4th restore frame is checked against a full render */

/* counters (emulator / debugger by symbol): see screens/tapecache.c */
struct kn_tc_stat_t {
    uint32_t frames, off, builds, restores, hits, moving, repairs, drops,
             verified, stale, stale_bytes, stale_first, verify_na, overflow, foreign, aborted,
             build_l, repair_ops, missed, volatile_marks;
};
extern struct kn_tc_stat_t kn_tc_stat;
extern volatile uint32_t kn_tc_on;              /* 0: off (poke, A/B: stock drawing) */
extern uint8_t kn_tc_build;                     /* this frame builds the cache (kn_gfx.c: not a pacing overrun) */
extern volatile uint32_t kn_tc_main;            /* 1: draws on the main rasterizer (lines, paths) may be cached too */

/* kinds of drawing call */
#define KN_TC_SWEEP  1                          /* agg_sweep_scanlines 0xFFA055B4 (shapes, lines) */
#define KN_TC_GLYPH  2                          /* the text sweep 0xFFA0894C (one glyph, with an offset) */

void kn_tc_init(void);                          /* boot (kn_gs_init): the cache from heap 0 */
int tc_frame_start(void *raster, void *buf);    /* a render frame's start: 1 = the buffer is prepared (no clear) */
int tc_frame_end(uint32_t buf);                 /* before the flush (kn_gfx_finish): 1 = drop this frame */
void tc_point(const void *ras, int x, int y);   /* every move_to / line_to (frame skip's gs_point) */
int tc_draw(int kind, void *ras, void *rend, const uint8_t *color, int dx, int dy);   /* 1 = done (drawn or skipped) */
void tc_misc(void);                             /* dim_all / dotted_hline: written straight into the raster */
void tc_foreign(void);                          /* pixels written past the hooked calls (op1_screen_hash, DNA) */
#endif
