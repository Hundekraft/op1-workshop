/* Gfx frames: frame skip (screens/guiskip.c) and the frame governor (kennel/kn_gfx.c, ARCHITECTURE.md "Gfx frames").
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (LICENSE, NOTICE). */
#ifndef KN_GFX_H
#define KN_GFX_H
#include <stdint.h>

#define KN_GFX_SLOTS       0x44                /* R246's screen table */
/* the frame governor (kennel/kn_gfx.c): constants; kn_gfx_gov_hi / _lo (cycles) override the percentages */
#define KN_GOV_HI_PCT      92                  /* recent worst callback at or over this % of the block: a level up */
#define KN_GOV_LO_PCT      80                  /* under this for KN_GOV_DOWN_BLOCKS: a level down */
#define KN_GOV_BUCKET      173u                /* blocks per bucket: the recent worst spans the last 173..346 (0.25..0.5 s) */
#define KN_GOV_HOT_BLOCKS  22u                 /* blocks at or over KN_GOV_HI_PCT in one bucket (an eighth) before a level up:
                                                * sustained load, not one spike (a preview, a patch load; owner 2026-11-10) */
#define KN_GOV_UP_BLOCKS   346u                /* a whole window at a level, still high, before the next level */
#define KN_GOV_DOWN_BLOCKS 345u                /* 0.5 s under KN_GOV_LO_PCT per level back (was 1 s until 2026-11-10) */
#define KN_GOV_MAX_LEVEL   1u                  /* the floor: 15 fps (owner 2026-11-09: gentle governor) */
#define KN_GOV_GAP1        46u                 /* level 1: blocks between drawn frames (67 ms, 15 fps) */
#define KN_GOV_GAP2        69u                 /* level 2: 100 ms, 10 fps */
#define KN_GOV_EARLY       12u                 /* a frame draws this early (one display interrupt: R246's loop when it skips) */
#define KN_GOV_DT_MAX      102u                /* ticks a screen update gets at most (R246's own Tombola clamp) */
/* steady pacing (kennel/kn_gfx.c, gpio panels): a frame goes to the panel every kn_gfx_pace TE edges (2 = 30 fps,
 * 3 = 20, 4 = 15) instead of whenever the draw finished */
#define KN_PACE_MAX        4u                  /* the slowest pace: 15 fps (the governor's floor) */
#define KN_PACE_UP_OVER    3u                  /* of the last 16 measured frames, this many overran 30 fps: 20 fps */
#define KN_PACE_UP_OVER_SLOW 6u                /* .. this many overran 20 fps: 15 fps */
#define KN_PACE_DOWN_WIN   32u                 /* none of the last 32 would have overrun one edge less: one edge faster */

extern volatile uint32_t kn_gfx_stats[2];
extern uint8_t kn_gfx_skipped;
extern volatile uint32_t kn_gfx_gov, kn_gfx_gov_hi, kn_gfx_gov_lo, kn_gfx_gov_stats[4], kn_gfx_level;
extern uint32_t kn_gov_win[2], kn_gov_hot[2];
extern volatile uint32_t kn_gov_hi_cy;
extern volatile uint32_t kn_gfx_pace, kn_gfx_pace_on, kn_gfx_pace_stats[6];
void kn_gfx_block(uint32_t used);                           /* audio callback, every block (dispatcher.c kn_audio_end) */
int op1_gfx_heavy(void);
void kn_gfx_frame(void *raster, uint8_t **table, int dt);   /* hook 0x01A3BBE0 */
void kn_gfx_finish(uint32_t buf, uint32_t end);             /* hook 0x019AB8C8 */
#endif
