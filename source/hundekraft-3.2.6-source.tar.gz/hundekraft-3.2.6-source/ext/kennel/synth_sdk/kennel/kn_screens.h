/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (LICENSE, NOTICE). */
#ifndef KN_SCREENS_H
#define KN_SCREENS_H

#include <stdint.h>

#define KN_SCREEN_SLOTS 0x44

/* Gfx thread only. Draw a stable frame table and retire displaced documents' drawing caches.
 * The requested table and parsed documents retain their existing ownership/lifetime. */
void kn_screens_frame(void *requested);

/* A page id shared by several objects (the FX page 0x0B: the stock filter, the generic FX page, every plugin FX's own)
 * follows its owner's state at the frame boundary, before kn_screens_frame copies the table: when `id` is the current
 * screen, the table holds one of the owner's objects (ours) and the owner says which object it wants (want, 0: leave
 * it), table[id] = want. Returns 1 when it swapped. Gfx thread, just before kn_screens_frame. */
int kn_screens_follow(void **table, int id, int current, void *want, int (*ours)(const void *));

/* Lazy documents (engine, FX and sequencer type pages, docs/svg-lazy.md). Registered once on the main thread before
 * Gfx starts: the screen object (word 0 the parsed document, 0 until shown; word 2 R246's SVG loader), its init and the page
 * shown in its place while it can't be parsed. kn_screens_frame parses a registered object the first time a frame
 * shows it and runs init; after the frame it frees the least recently drawn documents (not drawn in this frame or
 * the one before) while the resident ones pass KN_SVG_CAP. kn_svg_eager (a debugger poke) loads every registered
 * document at the next frame and stops freeing: screen_memory_measure.py reads each cost as at boot. */
#define KN_LAZY_MAX 160                       /* 64 engines, 64 FX, 16 sequencer types, room to spare */
#define KN_SVG_CAP  (400u * 1024u)
int kn_lazy_add(void *screen, void (*init)(void *), void *fallback);   /* 1 registered, 0 table full */
extern volatile uint32_t kn_svg_eager;
extern volatile uint32_t kn_lazy_stats[6];   /* resident bytes, parses, frees, failed, last parse cycles, max cycles */

#endif
