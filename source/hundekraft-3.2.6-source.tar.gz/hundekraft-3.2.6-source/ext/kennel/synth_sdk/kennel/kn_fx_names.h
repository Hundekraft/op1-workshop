/*
 * Which saved FX names load as the "filter" FX slot (type 5): every non-empty name that is not a stock FX. Pure, so
 * the host test (harness/fx_name_test.c) runs the same code as dispatcher.c fx_name_eq.
 * Stock names: R246's own fx_types name table (8 entries next to the "unknown fx mode" asserts of fx_bypass.cpp,
 * order = type id 0..7). A custom FX, a renamed one ("sitting") or one whose plugin file is missing loads as filter;
 * fx_patch_type_hook then picks the plugin by name, or the stock filter when none is loaded. An empty name is not
 * matched (kn_patch_safe.c resets the FX).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_FX_NAMES_H
#define KN_FX_NAMES_H
#include <stdint.h>

static const char *const kn_stock_fx_names[] = { "delay", "grid", "punch", "phone", "spring", "filter", "nitro", "cwo",
                                                 0 };

/* p[0..n) (not 0-terminated) equals the C string s */
static inline int kn_fx_name_is(const char *p, uint32_t n, const char *s)
{
    uint32_t i = 0;
    for (; i < n; i++) if (p[i] != s[i] || !s[i]) return 0;
    return s[n] == 0;
}

static inline int kn_fx_name_to_filter(const char *p, uint32_t n)
{
    if (!n) return 0;
    for (const char *const *s = kn_stock_fx_names; *s; s++)
        if (kn_fx_name_is(p, n, *s)) return 0;          /* a stock FX: its own entry matches */
    return 1;
}
/* The master FX's name for the FX list's opening row. R246 keeps the master FX as an enum (master_fx_type) and saves its
 * type name from that, so every plugin FX there reads back as "filter" (the list's opening row is SELECT id FROM
 * fx_types WHERE type = <that name>: it opened on FILTER). A plugin is known by the selector word of the master's fx
 * params (0xFF8016C4 word 4 = OP1_ENGINE_MAGIC + n) while the type is the filter's (5). Returns the plugin's name, or 0
 * to leave R246's own. names[n - 1] is the order's name (0 or "" when unused), loaded[n] is nonzero when the FX is here. */
static inline const char *kn_master_list_name(int type, int selector, int magic, const char *const *names,
                                             const void *const *loaded, int count)
{
    int n = selector - magic;
    if (type != 5 || n < 1 || n >= count || !loaded[n] || !names[n - 1] || !names[n - 1][0]) return 0;
    for (int i = 0; i < 16; i++) if (!names[n - 1][i]) return names[n - 1];        /* short enough for the inline string */
    return 0;
}
#endif
