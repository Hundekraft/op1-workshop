/* The audio thread's per-block lists, built once at the end of the loader (kn_features_finish / kn_tape_finish) and
 * kept in kn_hot lines (kn_mem.h): the features' clock ticks (kennel/kn_features.c, read by kn_core.c
 * kn_features_tick) and the tape hooks' block calls (kennel/kn_tape.c ci_metro_render). OP1-Emulator
 * docs/idle-cpu-analysis-2026-11-07.md proposal 2: one or two lines a block instead of every feature's struct.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_TICKS_H
#define KN_TICKS_H
#include "../op1_plugin.h"
#define KN_TICKS_MAX 48                         /* kn_features.c KN_FEATURES_MAX */
struct kn_tick_list {
    uint32_t ready;                             /* 0 until built: kn_features_tick walks the registry as before */
    uint32_t n;
    void (*fn[KN_TICKS_MAX])(const op1_beat_t *beat);
};
extern struct kn_tick_list kn_ticks;
#endif
