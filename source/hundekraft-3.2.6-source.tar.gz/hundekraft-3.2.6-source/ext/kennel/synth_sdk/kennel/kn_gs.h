/* The exact frame skip (screens/guiskip.c, from op1r-src 59) as the core sees it (ARCHITECTURE.md "Gfx frames").
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (LICENSE, NOTICE). */
#ifndef KN_GS_H
#define KN_GS_H
#include <stdint.h>
#include "../kn_mem.h"                           /* KN_GS_REGION_BYTES */

struct gs_stat_t { uint32_t ticks, renders, records, changes, skipped_pts, skipped_sweeps, skipped_text, skipped_misc,
                   verified, stale, stale_bytes, stale_first; };
struct gs_rg_stat_t { uint32_t frames, statics, full_copies, restores; };
extern struct gs_stat_t gs_stat;                 /* emulator / debugger: by symbol */
extern struct gs_rg_stat_t gs_rg_stat;
extern volatile uint8_t gs_off;                  /* 1: never record (poke, A/B) */

void gs_frame(void *raster);                     /* kennel/kn_gfx.c: a drawn frame's start (record or render) */
int kn_gs_recording(void);                       /* 1: this frame only hashes (nothing reaches the display buffer) */
int kn_gs_nohash(int on);                        /* draws that follow are not hashed (on = 1); returns the old state */
void kn_gs_init(int region_users);
void gs_buf_invalid(const void *buf);            /* a drawn buffer not presented: render into it next time */
uint8_t *kn_gs_scratch(void);                    /* the scratch buffer (0 without frame skip) */              /* boot: the scratch buffer; the region cache when a file imports op1_screen_regions */
#endif
