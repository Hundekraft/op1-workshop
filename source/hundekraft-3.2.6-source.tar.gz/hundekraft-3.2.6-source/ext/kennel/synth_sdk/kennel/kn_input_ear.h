/* What an input engine (VOX, SNAP, Amp) listens to, by R246's input mode (0xFF8010B0), and which tape tracks the Ear
 * feed leaves out. Pure functions: kennel/kn_input.c uses them on the audio thread, harness/fxroute_test.c tests them.
 * R246's Ear (mode 1, source 4) does not put the master into input_mono_buf (that keeps the codec's RX); it overwrites
 * mix_bus with the master after the output stage, for the sampler and the tape record stage (OP1-Emulator
 * docs/firmware/audio-graph.md, output stage step 9). An input engine runs before that, so in Ear it takes the tape's
 * pre-fader mix instead (screens/fxroute.c fr_tape_feed, the same track outs as op1_sc_source TAPE).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_INPUT_EAR_H
#define KN_INPUT_EAR_H
#include <stdint.h>

enum { KN_FEED_SILENCE, KN_FEED_INPUT, KN_FEED_TAPE };

/* mode 0: the input block (when R246 has one); 1 (Ear): the tape; anything else (2: input off): silence. A muting
 * input observer (line clock) silences every source. */
static inline int kn_input_feed(uint32_t mode, int has_input, int mute)
{
    if (mute) return KN_FEED_SILENCE;
    if (mode == 0) return has_input ? KN_FEED_INPUT : KN_FEED_SILENCE;
    return mode == 1 ? KN_FEED_TAPE : KN_FEED_SILENCE;
}

/* tracks (bit t) the tape feed leaves out: the selected track while the tape is armed (state 3, 6) or recording
 * (run 1). The record stage adds the take into that track behind the playhead, so it would reach the engine again
 * one tape pass later (a loop) and be recorded on top of itself; leaving it out while armed too means a punch-in
 * doesn't change the feed mid-pass. state 0x018C17D4, run 0xFF802960, track 0xFF802964 (docs/firmware/tape.md). */
static inline unsigned kn_ear_skip(uint32_t state, uint32_t run, uint32_t track)
{
    if (track > 3) return 0;
    return (run == 1 || state == 3 || state == 6) ? 1u << track : 0;
}
#endif
