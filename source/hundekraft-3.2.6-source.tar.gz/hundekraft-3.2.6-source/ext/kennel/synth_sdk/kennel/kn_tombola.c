/*
 * Stock Tombola in short physics steps (2026-11-06, ARCHITECTURE.md "Tombola steps").
 *
 * R246 steps Tombola's ball world from the Gfx thread: screens_update (0x01A3BB20) hands the frame's tick count
 * (frame_counter 0xFF8016E0, one tick per audio block, 689 a second) to the page player's advance slot, and
 * tombola_player_advance (0x01A65BBC) runs one World::Step of min(ticks, 102) * 64 (16.16 seconds), skipping frames
 * under 10 ticks. A normal frame is 23..25 ticks. The hexagon is a dynamic body on a joint and balls are not
 * bullets, so there is no continuous collision between them: one long frame (a heavy page, a page switch that
 * redraws everything, a first parse) moves balls and walls far enough in one step that a ball passes through a
 * wall. It falls out of the hexagon, FUN_01a64c3a removes it past |10.0|, and once all are gone Tombola is silent.
 * Measured on op1emu: frames forced to 54..102 ticks lose every ball within 20..60 frames; 24-tick frames lose none.
 *
 * The advance slot of Tombola's player vtable (0x01911E04, slot 6) points here instead (make_firmware.py SLOTS). A
 * frame up to KN_TOMBOLA_STEP ticks goes to R246 unchanged; a longer one (clamped to R246's 102) is split into
 * equal advances of at most KN_TOMBOLA_STEP ticks, each a whole stock advance (step, ball positions, note on / off
 * timers), so the physics runs as in a normal frame and the notes' timing adds up to the same ticks.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "kn_tombola.h"

#ifdef OP1_HOST
void host_tombola_advance(void *player, int ticks);
#define TOMBOLA_ADVANCE host_tombola_advance
#else
#define TOMBOLA_ADVANCE ((void (*)(void *, int))0x01A65BBC)   /* tombola_player_advance(player, ticks) */
#endif

void kn_tombola_advance(void *player, int ticks)
{
    if (ticks <= KN_TOMBOLA_STEP) { TOMBOLA_ADVANCE(player, ticks); return; }
    if (ticks > KN_TOMBOLA_MAX) ticks = KN_TOMBOLA_MAX;          /* R246's own clamp: time past it is dropped */
    int n = 1, part;
    while (n * KN_TOMBOLA_STEP < ticks) n++;                       /* at most 4 advances (Gfx thread, not audio) */
    for (int i = 0; i < n; i++) {
        part = ticks / n + (i < ticks % n);                        /* >= 13: every part steps (R246 skips < 10) */
        TOMBOLA_ADVANCE(player, part);
    }
}
