/* eng_push.h: encoder pushes on an engine screen whose blue and green share one page 2 (VOX, SNAP; owner 2026-11-08).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 *
 * The plugin API gives an engine only the core's page flags (op1_eng_page, toggled on a push of a knob whose press is
 * OP1_PRESS_PAGE or _PAGE_STEPS), so the screen turns them into these, once a frame before it draws:
 *   - blue or green: page 2 for both knobs (the strip shows both values); either push again brings both back
 *   - white or red (press OP1_PRESS_PAGE): the knob's value back to the engine's default, page 1 stays
 * White and red share page word 7, which these engines use for the hidden preset trim: a turn that reaches word 7 in
 * the frame before the screen takes the push is undone (word 7 goes back to what the screen last saw). The words are
 * saved as the core saves its own knob writes (the patch's knob setter, 0x01A00D14).
 * Include after op1_plugin.h; call eng_push(&state, slot, defaults) at the start of the screen's update. */
#ifndef HK_ENG_PUSH_H
#define HK_ENG_PUSH_H
#ifndef OP1_HOST
#define ENG_PUSH_SET_KNOBS(slot, w) \
    ((void (*)(void *, const int16_t *))0x01A00D14)((void *)(0x01DDD7E8 + ((slot) & 7) * 0x38), (w))
#else
#define ENG_PUSH_SET_KNOBS(slot, w) ((void)(slot), (void)(w))
#endif
typedef struct { uint8_t linked, seen; int16_t w7; } eng_push_t;
static void eng_push(eng_push_t *st, int slot, const int16_t defaults[4])
{
    int16_t *w = (int16_t *)op1_synth_knobs(slot);
    const int a = op1_eng_page[0] != 0, b = op1_eng_page[1] != 0;
    if (a != st->linked || b != st->linked) {          /* a push on one of them (or the core cleared both) */
        const int on = a != st->linked ? a : b;
        op1_eng_page[0] = op1_eng_page[1] = (uint8_t)on;
        st->linked = (uint8_t)on;
    }
    int changed = 0;
    for (int k = 2; k < 4; k++)
        if (op1_eng_page[k]) {
            op1_eng_page[k] = 0;
            if (st->seen) w[7] = st->w7;
            w[k] = defaults[k];
            changed = 1;
        }
    if (changed) ENG_PUSH_SET_KNOBS(slot, w);
    st->w7 = w[7]; st->seen = 1;
}
#endif
