/* Continuous selected-input synth extension. GPL-3.0-or-later with OP-1 firmware permission.
 * A .knl synth with input_engine:true extends its unchanged 16-byte voice prefix.
 * Old cores reject the new flag before executing it. No fake note or per-voice processing.
 */
#ifndef OP1_INPUT_H
#define OP1_INPUT_H
#include "op1_plugin.h"
typedef struct {
    op1_engine_t voice; /* silent ordinary voice callbacks; keyboard never gates the input */
    void (*reset)(int slot, uint32_t rate); /* audio thread: slot -1 deactivates; discard DSP/capture epoch */
    void (*process)(const int16_t *input, int16_t *output, const int16_t *params, uint32_t rate);
    void (*service)(void); /* main loop: bounded nonblocking work, optional */
    const op1_screen_t *tuner; /* optional T2 replacement, same lifetime as the plugin */
} op1_input_engine_t;
int op1_input_tuner_active(void); /* cheap audio/main/Gfx query; only this engine’s T2 */
/* INPUT GAIN of the selected source, -12..+24 dB (0 default): kennel trims the input before process() by it (kennel
 * settings "input.gain.<source>", blue on an input engine's T2 page turns it). For a T2 page to show; any thread. */
#ifdef OP1_HOST
__attribute__((weak)) int op1_host_input_gain_db;
static inline int op1_input_gain_db(void) { return op1_host_input_gain_db; }
#else
int op1_input_gain_db(void);
#endif

/* Input observer (kennel/kn_input.c), for features that read the input jack (line clock). Called on the audio thread
 * once per 64-sample block in every play mode, before the synth bus high-pass: `in` is R246's selected input for the
 * block (input_mono_buf 0xFF800CB4, 64 mono samples, read only) or 0 when the block has none; `source` is
 * core_input_source (0 mic, 1 line, 2 radio, 3 USB audio); `jack` is 1 while a line-in cable is in (0x018B621C);
 * `rate` is the measured block rate (22050 or 44100). Return 1 to keep this block's dry input out of the monitor and
 * the tape (an input engine such as Amp then gets silence). Integers only, short. One observer: register at
 * OP1_EV_REGISTER or OP1_EV_BOOT_DONE; 0 ok, -1 another one has it; fn 0 removes it. */
typedef int (*op1_input_observer_fn)(const int16_t *in, int source, int jack, uint32_t rate);
int op1_input_observe(op1_input_observer_fn fn);
#ifndef OP1_HOST
typedef char op1_input_size[(sizeof(op1_input_engine_t)==32)?1:-1];
#endif
#endif
