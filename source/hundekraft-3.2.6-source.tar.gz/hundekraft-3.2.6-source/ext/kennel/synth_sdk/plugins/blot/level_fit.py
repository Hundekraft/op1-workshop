#!/usr/bin/env python3
"""Fit blot's make-up gain table (level_table.json -> gen_tables.py -> blot_tables.h ac_mk): saved blot sounds keep the
level they had before the Open303 ladder (owner, 2026-11-06).

    python3 synth_sdk/plugins/blot/level_fit.py [--check]     (needs a host C compiler and git; ~2 min)

The reference is blot before the ladder (kennel 0aac8a6, git show), this tree's blot.c the new one, both built for the
host with OP1_HOST (as harness/blot_test.c) into a temporary folder, one note held 1 s at velocity 127 (the keys' accent),
the RMS after the first 40 calls. Nodes: 8 note planes (inc0 = 2^(20 + n), 21.5 Hz x 2^n), resonance r = 0, 8192,
16384, 24576, 32767 (knob words through ac_rsk), cutoff octaves 0 .. 9; env mod 0 and 18000 (BLOT_FIT_EM), decay 9000,
saw, drive 1x. Four rounds: each node's gain times 10^(-mean error / 20). --check: also the validation grid (5 notes x 4 cutoffs x 3 resonances
x env mod 0 / 18000 x saw / square x drive 1x / 2x, plus the review patches) against the written table.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE)."""
import itertools, json, os, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
SDK = HERE.parents[1]
OLD = '0aac8a6'
PROBE = r'''
#include "plugins/blot/blot.c"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
uint8_t host_shift; int16_t host_sine[8192]; int32_t host_pitch_inc[128]; uint8_t host_voice_mem[6 * 0x24]; int16_t host_voice_vel[6]; int16_t host_voice_env[128];
int16_t host_knobs[8][8]; int host_slot; const uint8_t *host_sample_buffer[8];
int16_t host_fx_knobs[3][8]; int16_t host_fx_meter[3]; void *host_fx_scratch[3];
volatile uint8_t op1_fx_page[3][4]; volatile uint8_t op1_eng_page[4];
void *host_find_node(void *s, const char *id) { (void)s; (void)id; return 0; }
void host_node_set_transform(void *n, const int32_t *m) { (void)n; (void)m; }
void host_node_set_visible(void *n, int on) { (void)n; (void)on; }
uint8_t *host_node_rgba(void *s, const char *id, int f) { static uint8_t c[4]; (void)s; (void)id; (void)f; return c; }
void host_screen_draw(void *s, int dt) { (void)s; (void)dt; }
void *host_raster(void) { return 0; }
void host_raster_line(void *r, const void *a, const void *b, int32_t w, const uint8_t *c) { (void)r; (void)a; (void)b; (void)w; (void)c; }
void *host_text_ctor(void *o, int32_t x, int32_t y, int32_t s, const uint8_t *c) { (void)x; (void)y; (void)s; (void)c; return o; }
void host_text_set(void *t, const char *s) { (void)t; (void)s; }
void host_text_draw(void *t, void *r, const int32_t *m) { (void)t; (void)r; (void)m; }
#ifdef BLOT_MK_FIT
int16_t ac_mk_fit[8][5][10];
#endif
int main(int argc, char **argv)
{
    (void)argc;
#ifdef BLOT_MK_FIT
    FILE *f = fopen(getenv("MKT"), "r"); for (int i = 0; i < 400; i++) { int v; if (fscanf(f, "%d", &v) != 1) return 1; ((int16_t *)ac_mk_fit)[i] = (int16_t)v; } fclose(f);
#endif
    const double hz = atof(argv[1]); const int vel = atoi(argv[2]);
    int16_t k[8] = { (int16_t)atoi(argv[3]), (int16_t)atoi(argv[4]), (int16_t)atoi(argv[5]), (int16_t)atoi(argv[6]), 0x5301,
                     (int16_t)atoi(argv[7]), (int16_t)atoi(argv[8]), (int16_t)atoi(argv[9]) };
    for (int i = 0; i < 8192; i++) host_sine[i] = (int16_t)lrint(32767.0 * sin(2 * M_PI * i / 8192.0));
    for (int i = 0; i < 128; i++) host_pitch_inc[i] = (int32_t)lrint(4294967296.0 * hz / 88200);
    memset(host_voice_mem, 0, sizeof host_voice_mem); host_voice_vel[0] = (int16_t)(vel << 8);
    void *V = host_voice_mem; ENGINE_blot.note_on(V, k);
    int16_t out[128]; double s2 = 0; int pk = 0; long n = 0;
    for (int b = 0; b < 88200 / 128; b++) {
        ENGINE_blot.render(V, out, k);
        if (b < 40) continue;
        for (int i = 0; i < 128; i++) { s2 += (double)out[i] * out[i]; if (abs(out[i]) > pk) pk = abs(out[i]); n++; }
    }
    printf("%.3f %.3f\n", 10 * log10(s2 / n / 32768.0 / 32768.0 + 1e-20), 20 * log10(pk / 32768.0 + 1e-9));
    return 0;
}
'''
RSK = [0, 5896, 10783, 14836, 18195, 20980, 23289, 25203, 26789, 28105, 29196, 30100, 30849, 31471, 31986, 32413, 32767]
RG = [0, 8192, 16384, 24576, 32767]
NOTES = [2 ** (14 + sh) * 88200 / 2 ** 32 for sh in range(6, 14)]
EM = [int(x) for x in os.environ.get('BLOT_FIT_EM', '0,18000').split(',')]   # env mod settings per node
CUT = [min(32767, round(k * 4096 * 32768 / 36864)) for k in range(10)]


def rknob(r):
    for d in range(16):
        if RSK[d + 1] >= r:
            return min(32767, int(round((d + (r - RSK[d]) / (RSK[d + 1] - RSK[d])) * 2048)))
    return 32767


def build(work):
    cc = os.environ.get('CC', 'cc')
    for name, files in (('old', {f: subprocess.run(['git', '-C', str(SDK), 'show', f'{OLD}:synth_sdk/plugins/blot/{f}'],
                                                   capture_output=True, text=True, check=True).stdout
                                 for f in ('blot.c', 'blot_tables.h')}),
                        ('new', {f: (HERE / f).read_text() for f in ('blot.c', 'blot_tables.h')})):
        d = work / name / 'plugins' / 'blot'
        d.mkdir(parents=True)
        for f, t in files.items():
            (d / f).write_text(t)
        (work / name / 'probe.c').write_text(PROBE)
        subprocess.run([cc, '-O2', '-w', '-DOP1_HOST', *(['-DBLOT_MK_FIT'] if name == 'new' else []), f'-I{work / name}',
                        f'-I{SDK}', str(work / name / 'probe.c'), '-lm', '-o', str(work / name / 'probe')], check=True)
    return work / 'old' / 'probe', work / 'new' / 'probe'


def run(exe, a, env=None):
    o = subprocess.run([str(exe), *map(str, a)], capture_output=True, text=True, env=env, check=True).stdout.split()
    return float(o[0]), float(o[1])


def write_t(path, T):
    path.write_text(' '.join(str(T[n][ri][k]) for n in range(8) for ri in range(5) for k in range(10)))


def main():
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        old, new = build(work)
        tf = work / 'T.txt'
        env = dict(os.environ, MKT=str(tf))
        pool = ThreadPoolExecutor(os.cpu_count() or 4)
        if '--check' not in sys.argv:
            cells = [(n, ri, k, (hz, 127, c, rknob(r), em, 9000, 0, 0, 0)) for n, hz in enumerate(NOTES)
                     for ri, r in enumerate(RG) for k, c in enumerate(CUT) for em in EM]
            ref = list(pool.map(lambda c: run(old, c[3])[0], cells))
            T = [[[4096] * 10 for _ in RG] for _ in NOTES]
            for it in range(4):
                write_t(tf, T)
                got = list(pool.map(lambda c: run(new, c[3], env)[0], cells))
                err = [g - r for g, r in zip(got, ref)]
                node = {}
                for (n, ri, k, _), e in zip(cells, err):
                    node.setdefault((n, ri, k), []).append(e)
                for (n, ri, k), es in node.items():           # a node's correction: the mean over its env mod settings
                    T[n][ri][k] = max(1024, min(32767, int(round(T[n][ri][k] * 10 ** (-sum(es) / len(es) / 20)))))
                print(f'round {it}: nodes |error| max {max(map(abs, err)):.2f} dB, mean {sum(map(abs, err)) / len(err):.2f}')
            (HERE / 'level_table.json').write_text(json.dumps(T) + '\n')
        T = json.loads((HERE / 'level_table.json').read_text())
        write_t(tf, T)
        cases = [(hz, 127, c, rs, em, 9000, wv, 20000, dr) for hz, c, rs, em, wv, dr in
                 itertools.product([41.2, 55, 110, 220, 440], [3000, 9000, 18000, 26000], [0, 22000, 32767], [0, 18000],
                                   [0, 32767], [0, 16000])]
        cases += [(hz, 127, *p) for hz in (55, 110, 261.6) for p in ((9000, 22000, 18000, 9000, 0, 0, 0),
                  (6000, 30000, 26000, 6000, 0, 20000, 0), (12000, 15000, 12000, 25000, 32767, 20000, 12000))]
        o = list(pool.map(lambda a: run(old, a), cases))
        n = list(pool.map(lambda a: run(new, a, env), cases))
        d = [b[0] - a[0] for a, b in zip(o, n)]
        print(f'validation: {len(cases)} cases, RMS difference mean {sum(d) / len(d):+.2f} dB, within 1 dB {sum(abs(x) <= 1 for x in d)},'
              f' within 2 dB {sum(abs(x) <= 2 for x in d)}, max {max(map(abs, d)):.1f}; peaks max old {max(a[1] for a in o):.2f}'
              f' new {max(b[1] for b in n):.2f} dBFS')
        for a, x, y in list(zip(cases, o, n))[-9:]:
            print(f'  patch {a}: old {x[0]:.1f} dB RMS / {x[1]:.1f} peak, new {y[0]:.1f} / {y[1]:.1f}')


if __name__ == '__main__':
    main()
