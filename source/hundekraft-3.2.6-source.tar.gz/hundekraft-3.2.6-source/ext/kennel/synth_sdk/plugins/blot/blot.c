/* "blot" (BLOT) - a TB-303 style synth: saw / square into a resonant 4-pole low-pass whose stages load
 * each other, a feedback high-pass that keeps the bass under the resonance, a decaying filter envelope and accent.
 *   knob 0 (blue)  : cutoff, 30 Hz .. 15 kHz        page 2 (press): waveform, saw .. square
 *   knob 1 (green) : resonance (squelch)             page 2 (press): accent amount
 *   knob 2 (white) : envelope mod, 0 .. 5 octaves    page 2 (press): drive
 *   knob 3 (red)   : decay, 40 .. 640 ms (time constant)
 * (op1r 48 reaches the three second values with Shift + turn; kennel has no Shift API, so they sit on the usual
 * press page of blue / green / white: words 5, 6, 7, the same words and the same DSP.)
 * Accent: notes with velocity >= 100 sweep the filter further (+ accent x 2 octaves), decay faster (about a third of the
 * decay knob's time, 42 .. 230 ms) and play louder.
 * Slide: the OP-1's own portamento (mono / legato play mode); the pitch increments already include the glide.
 * Filter: the TB-303 mode of Open303's TeeBeeFilter (Robin Schmidt, MIT License, (c) 2009 Robin Schmidt, rs-met.com): the
 * coefficients b0 (rational) and k (polynomial) of the cutoff, the stage updates, the 150 Hz feedback high-pass and the
 * gain g; the tables are made by gen_tables.py. Added here: a soft clip in the feedback, 32-bit states, the output stage.
 *   y0 = in - hp(k y4);  y1 += 2 b0 (y0 - y1 + y2);  y2 += b0 (y1 - 2 y2 + y3);  y3 += b0 (y2 - 2 y3 + y4);  y4 += b0 (y3 - 2 y4)
 * Cost: the oscillator is a hand-written Blackfin pass (blot_dsp.S); the ladder is C (2 multiplies per 32 x 16 bit
 * product, 4 stages + high-pass + feedback + output per sample); the envelope and the coefficients every 8 samples.
 * Copyright (C) 2026 pcppcp. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "op1_plugin.h"
#include "blot_tables.h"
#ifdef BLOT_MK_FIT                                                      /* level_fit.py: the table read at run time */
extern int16_t ac_mk_fit[8][5][10];
#define ac_mk ac_mk_fit
#endif

typedef struct {
    uint32_t vtable;            /* +0x00 firmware-owned, never written */
    uint32_t ph;                /* oscillator phase (2^32 = one cycle) */
    int32_t  y[4];              /* ladder stages y1 .. y4, Q20 (1.0 = 2^20) */
    int32_t  env;               /* filter envelope, Q24 */
    int32_t  hp;                /* feedback high-pass state, Q20 */
    uint8_t  gate, acc;         /* key held (screen), accented note */
    uint16_t tag;               /* kennel: AC_TAG once blot has rendered this voice object (its states are blot's) */
} ac_voice_t;
typedef char ac_size_check[sizeof(ac_voice_t) <= OP1_VOICE_SIZE ? 1 : -1];

#define AC_ACCENT_VEL (100 * 258)   /* op1_voice_vel_gain of velocity 100 */
#define AC_ACCENT_TAU(t) (30 + (((t) * 5) >> 4))   /* ms: an accented note's decay follows the knob's: 42 .. 230 ms (about 55 ms at the default) */
#define AC_HP_C 693                 /* feedback high-pass, Q16: c / (1 + c), c = 2 pi 150 Hz / 88200 (op1r: 1371 at 44.1 kHz) */
#define AC_R_MAX 32440              /* resonance cap, Q15 (0.99) */
#define AC_STATE_MAX (1 << 23)      /* clamp for a state left by another engine: 8x full scale (blot itself stays below 6.4x; was 128x) */
/* kennel 2026-11-06: a voice object another engine used last still holds that engine's bytes where blot keeps its
 * ladder and high-pass states. Clamped (to 128x full scale) they railed the ladder for 30 .. 60 ms: the first note
 * after a switch to blot was a click, then a stuck DC level (silence after R246's voice chain), then the note
 * (emulator, OP1-Emulator run/sine-blot-2026-11-06). The old blot clamped to 1x and so recovered at once. So the
 * render starts a voice object from rest (ladder and high-pass 0, as a voice blot has never used holds them from
 * boot) when it lacks blot's tag or holds a state beyond AC_STATE_MAX (8x full scale; blot's own stay below 6.4x),
 * and tags it; blot's own states are kept from note to note (legato) as before. */
#define AC_TAG 0xB107

static volatile int16_t ac_level[OP1_VOICES];  /* filter envelope per voice, Q15 (screen) */

static void ac_note_on(void *self, const int16_t *params)
{
    ac_voice_t *v = (ac_voice_t *)self;
    (void)params;
    v->env = 1 << 24;           /* phase and filter run on (no click, as the 303's free-running oscillator) */
    v->gate = 1;
}
static void ac_note_off(void *self) { ((ac_voice_t *)self)->gate = 0; }

static inline int32_t clip(int32_t x, int32_t m) { return x > m ? m : (x < -m ? -m : x); }
static inline int32_t soft(int32_t x)    /* x - x^3 / 3 on +-32767: +-21845 at the ends, slope 0 there */
{
    x = clip(x, 32767);
    int32_t x2 = (x * x) >> 15;
    return x - ((((x2 * x) >> 15) * 10923) >> 15);
}
/* d c / 65536 for a 32-bit d and a 16-bit unsigned c, exact (floor), in two 16-bit products */
static inline int32_t mq16(int32_t d, uint32_t c)
{
    return (d >> 16) * (int32_t)c + (int32_t)((((uint32_t)d & 0xFFFFu) * c) >> 16);
}

/* ---- the sample loop, two passes: the oscillator (osc >> 1 into out[], blot_dsp.S or the C below), then the ladder
 * and the output stage in place (C). The coefficients per 8 samples (b0, k, g) and the gains are worked out per block.
 * bl_blk keeps blot's layout up to w: blot_dsp.S reads p, inc, out, wave, rinv, sh and w by offset. */
typedef struct {
    uint32_t p;                 /*  0 oscillator phase (in / out) */
    int32_t  y[4];              /*  4 ladder stages y1 .. y4, Q20 (in / out) */
    const int32_t *inc;         /* 20 OP1_PITCH_INC */
    int16_t *out;               /* 24 */
    int32_t  k;                 /* 28 (unused) */
    int32_t  wave;              /* 32 saw .. square, Q15 (0: the 2nd saw is skipped) */
    int32_t  cd;                /* 36 (unused) */
    int32_t  gain;              /* 40 output gain, Q15 */
    int32_t  rinv;              /* 44 polyBLEP reciprocal, 16384 .. 32768 */
    int32_t  sh;                /* 48 its shift */
    int16_t  g[16];             /* 52 (unused) */
    uint32_t w;                 /* 84 fast path (blot_dsp.S): both polyBLEP terms are 0 and the clip idle while the phase
                                 *    is >= w from a wrap; 0: no fast path (high notes) */
    int32_t  hp;                /* 88 feedback high-pass state, Q20 (in / out) */
    int32_t  rec[16][3];        /* 92 kennel: the coefficients per 8 samples: k = kp r (Q8), {2 b0 : b0} (b0 the stage
                                 *    coefficient, Q16), gg = g x drive (Q12, <= 65535); bl_ladder reads them in a circle */
    int32_t  ring[7];           /* 284 kennel: bl_ladder's per-sample constants, read in a circle: 65535, {gain : 693},
                                 *     {-32767 : 10923}, 64, {-32767 : 10923}, {gain : 693}, -65535 */
    int32_t  env;               /* 312 kennel, bl_groups: the filter envelope, Q24 (in / out) */
    int32_t  gk[12];            /* 316 bl_groups' per-block constants, read in a circle once per group: dstep >> 3, em,
                                 *     base, the cutoff cap, 511, r, 15421, 4096, 32768 + r, drive, 65535, 4095 */
    int32_t  mk[10];            /* 364 the make-up gain row of this block over the cutoff octaves, Q12 */
    const uint16_t *kp, *b0;    /* 404, 408 ac_kp, ac_b0 */
} bl_blk;
#ifdef __bfin__
_Static_assert(__builtin_offsetof(bl_blk, inc) == 20 && __builtin_offsetof(bl_blk, wave) == 32 && __builtin_offsetof(bl_blk, rinv) == 44 &&
               __builtin_offsetof(bl_blk, w) == 84 && __builtin_offsetof(bl_blk, hp) == 88 &&
               __builtin_offsetof(bl_blk, rec) == 92 && __builtin_offsetof(bl_blk, ring) == 284 &&
               __builtin_offsetof(bl_blk, env) == 312 && __builtin_offsetof(bl_blk, gk) == 316 &&
               __builtin_offsetof(bl_blk, mk) == 364 && __builtin_offsetof(bl_blk, kp) == 404, "bl_blk layout (blot_dsp.S)");
#endif

/* q / di in Q15 (rinv = 2^29 / (di >> sh) of the block's first increment), capped at 32767; the operand is capped at
 * 16 bits, which changes nothing: from 65535 on the fraction is past the cap anyway (rinv >= 16384) */
static inline int32_t bl_frac(uint32_t q, int sh, uint32_t rinv)
{
    uint32_t a = q >> sh; if (a > 65535u) a = 65535u;
    uint32_t t = (a * rinv) >> 14;
    return t > 32767u ? 32767 : (int32_t)t;
}
/* a saw at phase q with both polyBLEP halves, branch-free: after a wrap + (1 - q / di)^2, before one
 * - (1 - (2^32 - q) / di)^2; away from a wrap both fractions are capped and both terms are 0 ((32768 - 32767)^2 >> 15) */
static inline int32_t bl_saw(uint32_t q, int sh, uint32_t rinv)
{
    int32_t x = (int32_t)(q ^ 0x80000000u) >> 16;                       /* (q >> 16) - 32768 */
    int32_t e = 32768 - bl_frac(q, sh, rinv), t = 32768 - bl_frac(0u - q, sh, rinv);
    x += ((e * e) >> 15) - ((t * t) >> 15);
    return clip(x, 32767);
}

#if defined(__bfin__) && !defined(BLOT_C_REF)
void bl_osc(bl_blk *b);                                                 /* blot_dsp.S */
#else
static void bl_osc(bl_blk *b)
{
    uint32_t p = b->p;
    const int32_t sh = b->sh, wave = b->wave;
    const uint32_t rinv = (uint32_t)b->rinv;
    for (int n = 0; n < OP1_BLOCK; n++) {
        p += (uint32_t)b->inc[n];
        int32_t osc = bl_saw(p, sh, rinv);
        if (wave) osc -= (bl_saw(p + 0x80000000u, sh, rinv) * wave) >> 15;   /* saw .. square */
        b->out[n] = (int16_t)(osc >> 1);                                /* +-32767 */
    }
    b->p = p;
}
#endif

#if defined(__bfin__) && !defined(BLOT_C_REF)
void bl_ladder(bl_blk *b);                                              /* blot_dsp.S (kennel), bit for bit the C below */
#else
/* the ladder and the output stage, in place on out[] (the oscillator's osc >> 1, +-16383; 1.0 = 32768 = 2^20 in a state) */
static void bl_ladder(bl_blk *b)
{
    int32_t y1 = b->y[0], y2 = b->y[1], y3 = b->y[2], y4 = b->y[3], hp = b->hp;
    const int32_t gain = b->gain;
    for (int j = 0; j < OP1_BLOCK / 8; j++) {
        const uint32_t c1 = (uint32_t)b->rec[j][1] & 0xFFFFu, c2 = (uint32_t)b->rec[j][1] >> 16;
        const int32_t kq = b->rec[j][0], gg = b->rec[j][2];
        for (int i = 0; i < 8; i++) {
            const int n = j * 8 + i;
            /* feedback k y4 (in Q20: 16-bit units << 5), high-passed, soft clipped at +-2.0 */
            int32_t s4 = clip(y4 >> 5, 65535);
            int32_t o = ((s4 * kq) >> 3) - hp;
            hp += mq16(o, AC_HP_C);
            int32_t u = (int32_t)b->out[n] * 32 - soft(clip(o >> 6, 32767)) * 64;
            y1 += mq16(u - y1 + y2, c2);
            y2 += mq16(y1 - 2 * y2 + y3, c1);
            y3 += mq16(y2 - 2 * y3 + y4, c1);
            y4 += mq16(y3 - 2 * y4, c1);
            /* output: g y4 (the filter's 2 g y4 at half level) x drive, soft clipped */
            int32_t v = clip(y4 >> 5, 32767);
            int32_t q = soft((v * gg) >> 12);
            q = clip(q + (q >> 1), 32767);                              /* soft() peaks at +-21846: +-32769 here */
            b->out[n] = (int16_t)((q * gain) >> 15);
        }
    }
    b->y[0] = y1; b->y[1] = y2; b->y[2] = y3; b->y[3] = y4; b->hp = hp;
}
#endif

#if defined(__bfin__) && !defined(BLOT_C_REF)
void bl_groups(bl_blk *b);                                              /* blot_dsp.S (kennel), bit for bit the C below */
#else
/* the envelope and the coefficients every 8 samples, into rec[] (kennel: out of ac_render for blot_dsp.S); b->gk[] holds
 * the block's values */
static void bl_groups(bl_blk *b)
{
    const int32_t *k = b->gk, *mk = b->mk;
    const int32_t ds = k[0], em = k[1], base = k[2], r = k[5], drive = k[9];
    int32_t env = b->env;
    for (int j = 0; j < OP1_BLOCK / 8; j++) {
        env -= (env >> 12) * ds >> 9;
        int32_t o = base + ((env >> 9) * em >> 15);                     /* env Q15 x em (<= 7 octaves) */
        if (o > (AC_G_N - 1) * 512 - 1) o = (AC_G_N - 1) * 512 - 1;
        int32_t i = o >> 9, f = o & 511;
        int32_t kp = b->kp[i] + (((b->kp[i + 1] - b->kp[i]) * f) >> 9);     /* Q8 */
        const uint32_t b0 = (uint32_t)(b->b0[i] + (((b->b0[i + 1] - b->b0[i]) * f) >> 9));
        int32_t *q = b->rec[j];
        q[0] = (kp * r) >> 15;                                          /* k = kp r */
        q[1] = (int32_t)(b0 << 17 | b0);                                /* {2 b0 : b0} */
        int32_t g = (kp * 15421) >> 14;                                 /* kp / 17, Q12 */
        g = (((g - 4096) * r) >> 15) + 4096;                            /* (g - 1) r + 1 */
        g = (g * (32768 + r)) >> 15;                                    /* x (1 + r) */
        g = (g * drive) >> 12;
        g = g > 65535 ? 65535 : g;
        const int32_t oc = o < 0 ? 0 : o, ko = oc >> 12, mg = mk[ko] + (((mk[ko + 1] - mk[ko]) * (oc & 4095)) >> 12);   /* make-up, Q12 */
        g = (g * mg) >> 12;
        q[2] = g > 65535 ? 65535 : g;
    }
    b->env = env;
}
#endif

static bl_blk bl_b;                                                     /* the audio thread only, one voice at a time */

/* kennel 2026-11-06 (CPU): op1_voice_index without its division for the six voice objects ((36 k + rem) 7282 >> 18 =
 * k for offsets below 2304), and per voice the last block's divisions (dstep by tau, rinv / sh / w by inc0): the same
 * numbers, computed again only when tau or the pitch changes */
static inline unsigned bl_vindex(const void *self)
{
    const uint32_t off = (uint32_t)((uintptr_t)self - (uintptr_t)OP1_VOICE_BASE);
    return off < 2304u ? (off * 7282u) >> 18 : (unsigned)op1_voice_index(self);
}
static struct { int32_t tau, dstep; uint32_t inc0, w; int32_t sh, rinv; } bl_cache[OP1_VOICES];

static void ac_render(void *self, int16_t *out, const int16_t *params)
{
    ac_voice_t *v = (ac_voice_t *)self;
    const int32_t *inc = OP1_PITCH_INC;
    const unsigned vi = bl_vindex(self);
    int32_t vg = OP1_VOICE_VEL[vi] >> 8;                                /* op1_voice_vel_gain */
    vg = vg > 0 && vg <= 127 ? vg * 258 : 32767;
    v->acc = vg >= AC_ACCENT_VEL;
    int32_t acc = v->acc ? (params[6] > 0 ? params[6] : 20000) : 0;   /* accent amount, Q15 (word 0: a new sound) */

    /* per block: cutoff / env mod in Q12 octaves, resonance, decay step, waveform, gains */
    bl_blk *b = &bl_b;
    int32_t base = (params[0] * (9 * 4096)) >> 15;                      /* 30 Hz .. 15 kHz */
    int32_t em = ((params[2] * (5 * 4096)) >> 15) + ((acc * (2 * 4096)) >> 15);
    int32_t rk = params[1] < 0 ? 0 : params[1], rd = rk >> 11, rf = rk & 2047;
    int32_t r = ac_rsk[rd] + (((ac_rsk[rd + (rd < 16)] - ac_rsk[rd]) * rf) >> 11);   /* resonance, Q15 */
    if (r > AC_R_MAX) r = AC_R_MAX;
    int32_t kd = params[3] < 0 ? 0 : params[3] >> 11, kf = params[3] < 0 ? 0 : params[3] & 2047;
    int32_t tau = ac_tau_ms[kd] + (((ac_tau_ms[kd + (kd < 16)] - ac_tau_ms[kd]) * kf) >> 11);
    if (v->acc) tau = AC_ACCENT_TAU(tau);
    int32_t dstep;                                                      /* 8 / (88.2 tau) per 8 samples at 88.2 kHz, Q24 */
    if (vi < OP1_VOICES && bl_cache[vi].tau == tau) dstep = bl_cache[vi].dstep;
    else {
        dstep = (int32_t)(1342177280 / (882 * tau));
        if (vi < OP1_VOICES) { bl_cache[vi].tau = tau; bl_cache[vi].dstep = dstep; }
    }
    b->wave = params[5] > 0 ? params[5] : 0;                            /* saw .. square, Q15 */
    int32_t drive = 4096 + ((params[7] > 0 ? params[7] : 0) >> 2);      /* 1x .. 3x, Q12 */
    b->gain = 19661 + ((acc * 13106) >> 15);                            /* 0.6, accent up to 1.0 */
    uint32_t big = 0;                                                   /* a state blot never reaches: not blot's */
    for (int i = 0; i < 4; i++) big |= (uint32_t)v->y[i] + (uint32_t)AC_STATE_MAX > 2u * AC_STATE_MAX;
    big |= (uint32_t)v->hp + (uint32_t)AC_STATE_MAX > 2u * AC_STATE_MAX;
    if (v->tag != AC_TAG || big) {                                      /* another engine's bytes: start at rest */
        v->y[0] = v->y[1] = v->y[2] = v->y[3] = 0; v->hp = 0; v->tag = AC_TAG;
    }
    b->hp = clip(v->hp, AC_STATE_MAX);

    /* polyBLEP fraction t = p / inc in Q15 without a per-sample division: rinv from this block's first inc */
    uint32_t inc0 = (uint32_t)inc[0] < 16384u ? 16384u : (uint32_t)inc[0];
    int sh;
    if (vi < OP1_VOICES && bl_cache[vi].inc0 == inc0) { sh = bl_cache[vi].sh; b->sh = sh; b->rinv = bl_cache[vi].rinv; b->w = bl_cache[vi].w; }
    else {
        sh = 0;
        while ((inc0 >> sh) >= 32768u) sh++;
        b->sh = sh;
        b->rinv = (int32_t)((1u << 29) / (inc0 >> sh));                     /* 16384 .. 32768 */
        /* kennel 2026-11-06: from w = (m + 2) << sh away from a wrap frac() is capped (m = inc0 >> sh, 16384 .. 32767;
         * q >= w: a = q >> sh >= m + 2, a rinv >= (m + 2)(2^29 / m - 1) = 2^29 + 2^30 / m - m - 2 >= 2^29 + 32768 - 32769
         * >= 2^29 - 16384 = 32767 << 14; or the 65535 cap); w >= 65536: x = -32768 only for q < 65536. w <= inc0 + 2^16 <
         * 2^30 keeps the square's two wrap windows apart (blot_dsp.S). Was 2 inc0 up to inc0 < 2^28: about half the
         * near-wrap samples now take the fast path, and notes up to inc0 < 2^30 - 2^16 have one; the same numbers */
        b->w = inc0 < (1u << 30) - 65536u ? ((((inc0 >> sh) + 2u) << sh) > 65536u ? ((inc0 >> sh) + 2u) << sh : 65536u) : 0;
        if (vi < OP1_VOICES) { bl_cache[vi].inc0 = inc0; bl_cache[vi].sh = sh; bl_cache[vi].rinv = b->rinv; bl_cache[vi].w = b->w; }
    }

    /* the voice object keeps the previous engine's bytes (note_on keeps the filter for legato): clamp the states to
     * their range, else the ladder runs away */
    b->p = v->ph;
    for (int i = 0; i < 4; i++) b->y[i] = clip(v->y[i], AC_STATE_MAX);
    int32_t env = v->env < 0 ? 0 : (v->env > (1 << 24) ? 1 << 24 : v->env);
    /* kennel 2026-11-06, make-up gain (the owner: saved blot sounds keep the level they had before the Open303 ladder):
     * ac_mk, fitted by level_fit.py, over the note (8 octave planes from inc0's shift: 21.5 Hz x 2^n), the resonance
     * (5 points) and the cutoff octave (10); this block's rows over the cutoff octaves it can reach (the envelope only
     * falls within a block, so base .. the cutoff at its start), interpolated in note and resonance; per 8 samples the
     * row interpolated at the cutoff multiplies g before the output stage's soft clip (peaks stay bounded) */
    int32_t *mk = b->mk;
    {
        int32_t ni = sh - 6, nf = (int32_t)((inc0 >> sh) - 16384u) >> 6;
        if (ni < 0) { ni = 0; nf = 0; }
        if (ni > 7) { ni = 7; nf = 0; }
        const int32_t n2 = ni + (ni < 7), ri = r >> 13, rf = r & 8191;
        const int32_t omax = (AC_G_N - 1) * 512 - 1, o0 = base + ((env >> 9) * em >> 15);
        const int32_t lo = base < o0 ? base : o0, hi = base < o0 ? o0 : base;
        const int32_t k0 = lo < 0 ? 0 : (lo > omax ? omax : lo) >> 12, k1 = (hi < 0 ? 0 : (hi > omax ? omax : hi) >> 12) + 1;
        for (int k = k0; k <= k1; k++) {
            const int32_t a = (ac_mk[ni][ri][k] * (8192 - rf) + ac_mk[ni][ri + 1][k] * rf) >> 13;
            const int32_t c = (ac_mk[n2][ri][k] * (8192 - rf) + ac_mk[n2][ri + 1][k] * rf) >> 13;
            mk[k] = a + (((c - a) * nf) >> 8);
        }
    }
    {
        int32_t *k = b->gk;
        k[0] = dstep >> 3; k[1] = em; k[2] = base; k[3] = (AC_G_N - 1) * 512 - 1; k[4] = 511; k[5] = r; k[6] = 15421;
        k[7] = 4096; k[8] = 32768 + r; k[9] = drive; k[10] = 65535; k[11] = 4095;
        b->env = env; b->kp = ac_kp; b->b0 = ac_b0;
    }
    bl_groups(b);
    env = b->env;
    {
        const int32_t gk = (int32_t)((uint32_t)b->gain << 16 | AC_HP_C), sk = (int32_t)(0x80010000u | 10923u);
        int32_t *k = b->ring;
        k[0] = 65535; k[1] = gk; k[2] = sk; k[3] = 64; k[4] = sk; k[5] = gk; k[6] = -65535;
    }
    b->inc = inc; b->out = out;
    bl_osc(b);
    bl_ladder(b);
    v->ph = b->p; for (int i = 0; i < 4; i++) v->y[i] = b->y[i];
    v->hp = b->hp;
    v->env = env;
    if (vi < OP1_VOICES) ac_level[vi] = (int16_t)(env >> 9);          /* (a voice object outside the 6: no screen) */
}

const op1_engine_t ENGINE_blot = { ac_note_on, ac_render, ac_note_off,
                                   { OP1_PRESS_PAGE, OP1_PRESS_PAGE, OP1_PRESS_PAGE, OP1_PRESS_NONE } };

/* ======================= screen (GUI thread) =======================
 * An acid house smiley in lines, standing still (blot.svg is empty), and dddd's bottom row. Each knob changes one part,
 * drawn in its colour:
 *   blue   cutoff     the eyes: sleepy slits .. wide open
 *   green  resonance  the smile: flat .. a big grin, dimples at the top
 *   white  env mod    the mouth opens with each note (env mod x the filter envelope) and closes with it
 *   red    decay      drips below the face (the melting smiley): longer with the decay
 *   page 2 of white (drive): the face outline wiggles (8 bumps, 0 .. +-3 px), standing still
 *   accent            a wink; idle: a blink now and then
 * Bottom row: cutoff (Hz), resonance, env mod, decay (ms); a knob on page 2 shows its second value instead: blue wave,
 * green accent, white drive. ~70 lines. */
#include "op1_synth.h"
#define Q(v) ((v) << 10)
#define TS 12
#define FX  160                 /* face centre and radius, px */
#define FY  50
#define FR  34
static const uint8_t c_blue[4] = { 0x4D, 0x9E, 0xFF, 0xFF }, c_green[4] = { 0x00, 0xED, 0x95, 0xFF },
                     c_white[4] = { 0xFF, 0xFF, 0xFF, 0xFF }, c_red[4] = { 0xFF, 0x3A, 0x5D, 0xFF },
                     c_face[4] = { 0xDF, 0xD9, 0xFF, 0xFF };
static const uint8_t *const col4[4] = { c_blue, c_green, c_white, c_red };
enum { TX_LAB, TX_VAL = 4, TX_N = 8 };
static uint32_t tx[TX_N][OP1_TEXT_SIZE / 4];
static char shown[TX_N][14];
static uint8_t tx_made;
static int32_t sm_open, sm_wink, sm_t, sm_lv;   /* mouth (Q15, eased), wink frames left, frame count, level seen */

static void ln(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, const uint8_t *c)   /* Q10 */
{
    if (x0 == x1 && y0 == y1) return;
    op1_pt a = { x0, y0 }, b = { x1, y1 };
    op1_raster_line(r, &a, &b, w, c);
}
static void txt(void *r, int i, const char *s)
{
    static const int32_t ident[9] = { 1024, 0, 0, 0, 1024, 0, 0, 0, 1024 };
    int same = 1;
    for (int j = 0; j < 14; j++) { if (shown[i][j] != s[j]) { same = 0; break; } if (!s[j]) break; }
    if (!same) { op1_text_set(tx[i], s); int j = 0; for (; j < 13 && s[j]; j++) shown[i][j] = s[j]; shown[i][j] = 0; }
    op1_text_draw(tx[i], r, ident);
}
static char *put(char *p, const char *s) { while (*s) *p++ = *s++; *p = 0; return p; }
static char *num(char *p, int32_t x) { char t[8]; int n = 0; do t[n++] = (char)('0' + x % 10); while ((x /= 10)); while (n) *p++ = t[--n]; *p = 0; return p; }
static void pct(char *p, int32_t v) { put(num(p, (v * 100 + 16383) >> 15), "%"); }
/* an ellipse (Q10 centre, px radii) of n segments from angle a0 to a1 (8192 a turn) */
static void arc(void *r, int32_t cx, int32_t cy, int32_t rx, int32_t ry, int n, int32_t a0, int32_t a1, int32_t w, const uint8_t *c)
{
    int32_t px = 0, py = 0;
    for (int i = 0; i <= n; i++) {
        int32_t a = a0 + (a1 - a0) * i / n;
        int32_t x = cx + Q(rx) * OP1_SINE_TABLE[(a + 2048) & 8191] / 32768, y = cy + Q(ry) * OP1_SINE_TABLE[a & 8191] / 32768;
        if (i) ln(r, px, py, x, y, w, c);
        px = x; py = y;
    }
}

#define FACE_N 64               /* outline segments: 8 per bump, the wiggle stays smooth */
/* the outline's point at angle a (8192 a turn), Q10; wg = wiggle depth, Q10 px (8 bumps) */
static op1_pt face_pt(int32_t a, int32_t wg)
{
    int32_t rr = Q(FR) + wg * OP1_SINE_TABLE[(a * 8) & 8191] / 32768;
    op1_pt p = { Q(FX) + rr * OP1_SINE_TABLE[(a + 2048) & 8191] / 32768, Q(FY) + rr * OP1_SINE_TABLE[a & 8191] / 32768 };
    return p;
}

static void ac_screen_init(void *scr) { (void)scr; }

static void ac_screen_update(void *scr, int dt)
{
    int slot = OP1_SCREEN_SLOT & 7;
    int16_t k[4];
    op1_synth_knobs_live(slot, k);
    const int16_t *w = op1_synth_knobs(slot);
    for (int i = 0; i < 4; i++) if (k[i] < 0) k[i] = 0;
    if (!tx_made) {
        for (int i = 0; i < 4; i++) {
            op1_text_ctor(tx[TX_LAB + i], Q(8 + 78 * i), 114, TS, col4[i]);
            op1_text_ctor(tx[TX_VAL + i], Q(8 + 78 * i), 127, TS, c_white);
        }
        tx_made = 1;
    }
    int32_t lv = 0, acc = 0;                                     /* the loudest held voice's filter envelope */
    for (int i = 0; i < OP1_VOICES; i++) {
        const ac_voice_t *v = (const ac_voice_t *)OP1_VOICE(i);
        if (v->gate && ac_level[i] > lv) { lv = ac_level[i]; acc = v->acc; }
    }
    if (acc && lv > sm_lv + 8192) sm_wink = 12;                  /* an accented note: wink */
    sm_lv = lv; sm_t++;
    int32_t open = lv * k[2] >> 15;                              /* the mouth: env mod x the envelope, eased */
    sm_open += (open - sm_open) >> 1;
    op1_screen_draw(scr, dt);
    void *r = op1_raster();

    /* the face: a circle, wiggling with the drive (Shift + white) */
    int32_t wg = Q(3) * (w[7] > 0 ? w[7] : 0) >> 15;
    for (int j = 0; j < FACE_N; j++) {
        op1_pt a = face_pt(j * 8192 / FACE_N, wg), b = face_pt((j + 1) * 8192 / FACE_N, wg);
        ln(r, a.x, a.y, b.x, b.y, 0x700, c_face);
    }
    /* eyes (blue): height with the cutoff; a blink every ~4 s, the left eye winks on an accent */
    int32_t eh = 1 + (k[0] * 7 >> 15), blink = (sm_t % 240) >= 235;
    for (int e = 0; e < 2; e++) {
        int32_t ex = Q(FX - 12 + 24 * e), ey = Q(FY - 10);
        if (blink || (e == 0 && sm_wink)) ln(r, ex - Q(4), ey, ex + Q(4), ey, 0x700, c_blue);
        else arc(r, ex, ey, 4, eh, 10, 0, 8192, 0x700, c_blue);
    }
    if (sm_wink) sm_wink--;
    /* smile (green): a parabola, deeper with the resonance; dimples at the ends from 60 % */
    int32_t depth = Q(2) + (Q(12) * k[1] >> 15), half = Q(19), my = Q(FY + 8);
    /* the lip: depth + opening <= 23 px below the smile's corners, so it stays inside the face (r 34, corners at
     * +-19 px, 8 px below the centre: at the middle 8 + 23 = 31 < 34 - 3, at +-half way 8 + 17 < 32.6 - 3) */
    int32_t px = 0, py = 0, qx = 0, qy = 0, mo = (Q(23) - wg - depth) * sm_open >> 15;   /* (the wiggle reaches in) */
    for (int i = 0; i <= 10; i++) {
        int32_t u = (i - 5) * 6554;                              /* -1 .. 1, Q15 */
        int32_t x = Q(FX) + (half * u >> 15), y = my + depth - (int32_t)((int64_t)depth * u * u >> 30);
        int32_t yl = y + (int32_t)((int64_t)mo * (32768 - (int32_t)((int64_t)u * u >> 15)) >> 15);   /* the lower lip */
        if (i) {
            ln(r, px, py, x, y, 0x700, c_green);
            if (mo > Q(1)) ln(r, qx, qy, x, yl, 0x700, c_white);
        }
        px = x; py = y; qx = x; qy = yl;
    }
    if (k[1] > 19661)
        for (int e = -1; e <= 1; e += 2) ln(r, Q(FX) + e * half, my, Q(FX) + e * (half + Q(3)), my - Q(3), 0x600, c_green);
    /* drips (red): from the chin, longer with the decay */
    static const int8_t dx[3] = { -10, 2, 11 }, dl[3] = { 6, 10, 8 };
    for (int i = 0; i < 3; i++) {
        /* start on the drawn outline (wiggle included): where its lower half crosses x, + half the line width */
        int32_t x = Q(FX + dx[i]), y0 = Q(FY + FR);
        for (int j = 0; j < FACE_N; j++) {
            op1_pt a = face_pt(j * 8192 / FACE_N, wg), b = face_pt((j + 1) * 8192 / FACE_N, wg);
            if (a.y > Q(FY) && b.y > Q(FY) && ((a.x <= x && x <= b.x) || (b.x <= x && x <= a.x)) && a.x != b.x) {
                y0 = a.y + (b.y - a.y) * (x - a.x) / (b.x - a.x); break;   /* <= 38k x 5k (Q10): 32 bit */
            }
        }
        y0 += 0x700 / 2;
        int32_t len = Q(2) + (Q(dl[i]) * k[3] >> 15) * 2;
        ln(r, x, y0, x, y0 + len, 0x600, c_red);
        ln(r, x - OP1_Q10(1.5), y0 + len, x + OP1_Q10(1.5), y0 + len, 0x900, c_red);    /* the drop: two crossing lines */
        ln(r, x, y0 + len - OP1_Q10(1.5), x, y0 + len + OP1_Q10(1.5), 0x900, c_red);
    }

    /* the bottom row */
    for (int i = 0; i < 4; i++) ln(r, Q(8 + 78 * i), Q(110), Q(78 + 78 * i), Q(110), 0x800, col4[i]);
    char v[16];
    /* cutoff: 30 Hz x 2^(9 k / 32768), 2^frac ~ 1 + f (0.657 + 0.343 f) */
    if (op1_eng_page[0]) {
        int32_t w5 = w[5] > 0 ? w[5] : 0;
        txt(r, TX_LAB, "wave"); if (w5 < 328) put(v, "saw"); else if (w5 > 32440) put(v, "square"); else pct(v, w5); txt(r, TX_VAL, v);
    } else {
        int32_t o = k[0] * 9, oi = o >> 15, of = o & 32767;
        int32_t hz = (30 << oi) * (32768 + (int32_t)(((int64_t)of * (21529 + (11239 * of >> 15))) >> 15)) >> 15;
        if (hz < 1000) put(num(v, hz), "hz"); else { char *p = num(v, hz / 1000); p = put(p, "."); put(num(p, hz / 100 % 10), "khz"); }   /* lower case: the OP-1 font has another H */
        txt(r, TX_LAB, "cutoff"); txt(r, TX_VAL, v);
    }
    if (op1_eng_page[1]) { txt(r, TX_LAB + 1, "accent"); pct(v, w[6] > 0 ? w[6] : 20000); }
    else { txt(r, TX_LAB + 1, "reso"); pct(v, k[1]); }
    txt(r, TX_VAL + 1, v);
    if (op1_eng_page[2]) {
        int32_t w7 = w[7] > 0 ? w[7] : 0;
        int32_t d = 10 + (w7 * 20 >> 15); char *p = put(v, "x"); p = num(p, d / 10); p = put(p, "."); num(p, d % 10);   /* drive x1.0 .. x3.0 */
        txt(r, TX_LAB + 2, "drive");
    } else { txt(r, TX_LAB + 2, "env mod"); pct(v, k[2]); }
    txt(r, TX_VAL + 2, v);
    txt(r, TX_LAB + 3, "decay");
    int32_t kd = k[3] >> 11, kf = k[3] & 2047;
    put(num(v, ac_tau_ms[kd] + (((ac_tau_ms[kd + (kd < 16)] - ac_tau_ms[kd]) * kf) >> 11)), "ms");
    txt(r, TX_VAL + 3, v);
}

const op1_screen_t SCREEN_blot = { ac_screen_init, ac_screen_update };
