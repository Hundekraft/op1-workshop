/* Clouds' Blackfin kernels (clouds_dsp.S) against copies of clouds_dsp.c's C loops on bcore (kern_check.py), on
 * random inputs over the whole range the C allows: buffer words over all of int16 with runs of -32768 / 32767,
 * phases and increments from pitch -24 to +24 semitones (whole-octave steps and fractional ones), gains at both ends
 * of 0 .. 23170, chunk lengths 1 .. 64. Prints "KERN ok blocks=N" or the first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdint.h>
void t2_write(const char *, int);
uint32_t t2_r246_calls[2];
void cl_grain(int32_t *o, const int16_t *base, int32_t ph, int32_t inc, int32_t g0, int32_t dg, int m);
typedef struct { const int32_t *sl; uint32_t f, d; int32_t n; } cl_mix_t;
void cl_mix(int16_t *output, const int16_t *input, const int32_t *w, const cl_mix_t *a);
int32_t cl_norm(int32_t *out, int32_t g, int32_t gn, int n);
void cl_diffuse(int32_t *io, int32_t *db, int32_t wp, int32_t amount, int n);
typedef struct { int16_t *rb; int32_t wp0, cnt; int32_t *io; int32_t i0, f0, i9, f9, lp1, lp2, wo, lp4, time, amount; } cl_rev_t;
void cl_reverb(cl_rev_t *a);
int cl_seed(uint32_t *st, int cnt, uint32_t thr, int32_t space, int det);
void cl_rec(int16_t *dst, const int16_t *src, int n);
#include "clouds_tables.h"

static unsigned blocks, bad;
static char line[160];
static int n;
static void put(const char *p) { while (*p) line[n++] = *p++; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = '0' + v % 10; while (v /= 10); put(b + i); }
static uint32_t rng = 12345;
static uint32_t rnd(void) { rng = rng * 1664525u + 1013904223u; return rng; }
static int16_t rnd16(void) { return (int16_t)(rnd() >> 16); }
static void fail(const char *what, unsigned k) { if (!bad) { bad = 1; put("KERN differ "); put(what); put(" case="); num(k); put("\n"); } }

/* clouds_dsp.c fg_rcp */
static const int16_t rcp[65] = { 0, 32767, 16384, 10923, 8192, 6554, 5461, 4681, 4096, 3641, 3277, 2979, 2731, 2521, 2341, 2185, 2048, 1928, 1820, 1725, 1638, 1560, 1489, 1425, 1365, 1311, 1260, 1214, 1170, 1130, 1092, 1057, 1024, 993, 964, 936, 910, 886, 862, 840, 819, 799, 780, 762, 745, 728, 712, 697, 683, 669, 655, 643, 630, 618, 607, 596, 585, 575, 565, 555, 546, 537, 529, 520, 512 };

static int16_t buf[4096 + 16];
static int32_t oa[72], ob[72];

static void grain_ref(int32_t *o, const int16_t *base, int32_t ph, int32_t inc, int32_t gn, int32_t dg, int m)
{
    for (int j = 0; j < m; j++) {                       /* grain_overlap_add's no-wrap chunk loop */
        const int16_t *r = base + (ph >> 16);
        const int32_t sm = r[0] + (((r[1] - r[0]) * (int32_t)(((uint32_t)ph & 65535) >> 1)) >> 15);
        *o++ += (sm * gn) >> 15;
        gn += dg;
        ph += inc;
    }
}

static void grains(void)
{
    static const int32_t incs[] = { 65536, 131072, 262144, 16384, 32768, 98304 };
    for (unsigned k = 0; k < 20000 && !bad; k++) {
        if (k % 200 == 0)
            for (int i = 0; i < 4096 + 16; i++) {
                uint32_t r = rnd();
                buf[i] = (k / 200) & 1 && (r & 3) == 0 ? ((r & 4) ? 32767 : -32768) : (int16_t)(r >> 16);
            }
        const int m = 1 + (int)(rnd() % 64);
        int32_t inc;
        uint32_t c = rnd() % 8;
        if (c < 3) inc = incs[rnd() % 6];
        else inc = 16384 + (int32_t)(rnd() % (262144 - 16384 + 1));
        int32_t ph = (int32_t)(rnd() % 2000u) << 16;
        if (c != 0) ph += (int32_t)(rnd() & 65535);
        const int32_t g0 = (k & 7) == 0 ? 0 : (k & 7) == 1 ? 23170 : (int32_t)(rnd() % 23171);
        const int32_t g1 = (k & 15) == 2 ? 0 : (k & 15) == 3 ? 23170 : (int32_t)(rnd() % 23171);
        const int32_t dg = ((g1 - g0) * rcp[m]) >> 15;
        for (int i = 0; i < 72; i++) oa[i] = ob[i] = (int32_t)rnd() >> 8;
        cl_grain(oa + 2, buf + 8, ph, inc, g0, dg, m);
        grain_ref(ob + 2, buf + 8, ph, inc, g0, dg, m);
        blocks++;
        for (int i = 0; i < 72; i++) if (oa[i] != ob[i]) { fail("cl_grain", k); break; }
    }
}

static int32_t clip16(int32_t x) { return x < -32768 ? -32768 : (x > 32767 ? 32767 : x); }
static void mix_ref(int16_t *output, const int16_t *input, const int32_t *out, int32_t fi, int32_t fo, int32_t dfi, int32_t dfo, int n)
{
    const int32_t *const sl = cl_soft_limit;           /* clouds_process's CLOUDS_BLOCK_MIX loop */
    for (int i = 0; i < n; i++) {
        fi += dfi; fo += dfo;
        const int32_t w = out[i];
        int32_t x = ((input[i] * fo) >> 15) + (w >> 15) * fi + (((w & 32767) * fi) >> 15);
        int32_t y;
        if (x <= -8 * 32768) y = sl[0];
        else if (x >= 8 * 32768 - 1) y = sl[4096];
        else {
            const int32_t u = x + 8 * 32768, k = u >> 7;
            y = sl[k] + (((sl[k + 1] - sl[k]) * (u & 127)) >> 7);
        }
        output[i] = (int16_t)clip16(y);
    }
}
static int16_t mo[2][72], min_[64];
static int32_t mw[64];
static void mixes(void)
{
    for (unsigned k = 0; k < 20000 && !bad; k++) {
        const int n = k & 1 ? 64 : 1 + (int)(rnd() % 64);
        const int32_t fi0 = k % 5 == 0 ? 0 : k % 5 == 1 ? 39322 : (int32_t)(rnd() % 39323);
        const int32_t fi1 = k % 7 == 0 ? 0 : k % 7 == 1 ? 39322 : (int32_t)(rnd() % 39323);
        const int32_t fo0 = k % 3 == 0 ? 32767 : (int32_t)(rnd() % 32768), fo1 = k % 11 == 0 ? 0 : (int32_t)(rnd() % 32768);
        const int32_t dfi = (fi1 - fi0) / n, dfo = (fo1 - fo0) / n;
        const int sh = (int)(k % 13);                    /* w from small to beyond the limiter (2^9 .. 2^21) */
        for (int i = 0; i < 64; i++) { min_[i] = rnd16(); mw[i] = (int32_t)rnd() >> (10 + (sh < 10 ? sh : 10)); }
        if (k % 17 == 0) for (int i = 0; i < 64; i++) mw[i] = (int32_t)(rnd() & 1 ? 1 : -1) << 21;
        for (int i = 0; i < 72; i++) mo[0][i] = mo[1][i] = (int16_t)i;
        const cl_mix_t a = { cl_soft_limit + 2048, (uint32_t)fi0 << 16 | (uint16_t)fo0, (uint32_t)dfi << 16 | (uint16_t)dfo, n };
        cl_mix(mo[0] + 4, min_, mw, &a);
        mix_ref(mo[1] + 4, min_, mw, fi0, fo0, dfi, dfo, n);
        blocks++;
        for (int i = 0; i < 72; i++) if (mo[0][i] != mo[1][i]) { fail("cl_mix", k); break; }
    }
}

static int32_t mulq15(int32_t a, int32_t b)          /* clouds_dsp.c */
{
    if (((uint32_t)b + 65536u) > 131072u) { const int32_t t = a; a = b; b = t; }
    return (int32_t)((uint32_t)(a >> 15) * (uint32_t)b + (uint32_t)(((a & 32767) * b) >> 15));
}
static int32_t nw[2][72];
static void norms(void)
{
    for (unsigned k = 0; k < 20000 && !bad; k++) {
        const int n = k & 1 ? 64 : 1 + (int)(rnd() % 64);
        int32_t g = k % 5 == 0 ? 1 : k % 5 == 1 ? 65535 : 1 + (int32_t)(rnd() % 65535);
        const int32_t gn = k % 7 == 0 ? 1 : k % 7 == 1 ? 65535 : k % 7 == 2 ? g + (int32_t)(rnd() % 200) - 100 : 1 + (int32_t)(rnd() % 65535);
        if (gn < 1 || gn > 65535) continue;
        const int sh = (int)(k % 12);                    /* out up to 2^21 (24 grains at full gain) */
        for (int i = 0; i < 72; i++) nw[0][i] = nw[1][i] = (int32_t)rnd() >> (10 + sh);
        if (k % 13 == 0) for (int i = 0; i < 72; i++) nw[0][i] = nw[1][i] = rnd() & 1 ? 1 << 21 : -(1 << 21);
        const int32_t ga = cl_norm(nw[0] + 4, g, gn, n);
        for (int t = 0; t < n; t++) { g += ((gn - g) * 328) >> 15; nw[1][4 + t] = mulq15(nw[1][4 + t], g); }
        blocks++;
        if (ga != g) fail("cl_norm gain", k);
        for (int i = 0; i < 72; i++) if (nw[0][i] != nw[1][i]) { fail("cl_norm", k); break; }
    }
}

static int32_t dbuf[2][2048], dio[2][72];
static void diffuse_ref(int32_t *io, int32_t *db, int32_t wp, int32_t amount, int n)   /* clouds_dsp.c diffuser() */
{
#define K58(a) (((a) * 5) >> 3)
    for (int t = 0; t < n; t++) {
        if (--wp < 0) wp += 2048;
        int32_t acc = io[t], prev;
        prev = db[(wp + 125) & 2047]; acc += K58(prev); db[wp & 2047] = acc;         acc = K58(-acc) + prev;
        prev = db[(wp + 306) & 2047]; acc += K58(prev); db[(wp + 127) & 2047] = acc; acc = K58(-acc) + prev;
        prev = db[(wp + 576) & 2047]; acc += K58(prev); db[(wp + 308) & 2047] = acc; acc = K58(-acc) + prev;
        prev = db[(wp + 1021) & 2047]; acc += K58(prev); db[(wp + 578) & 2047] = acc; acc = K58(-acc) + prev;
        io[t] += mulq15(amount, acc - io[t]);
    }
#undef K58
}
static void diffuses(void)
{
    for (unsigned k = 0; k < 3000 && !bad; k++) {
        const int sh = (int)(k % 9);
        if (k % 50 == 0) for (int i = 0; i < 2048; i++) dbuf[0][i] = dbuf[1][i] = (int32_t)rnd() >> (9 + sh);
        const int n = k & 1 ? 64 : 1 + (int)(rnd() % 64);
        const int32_t wp = (int32_t)(rnd() % 2048);
        const int32_t amount = k % 5 == 0 ? 32767 : k % 5 == 1 ? 1 : 1 + (int32_t)(rnd() % 32767);
        for (int i = 0; i < 72; i++) dio[0][i] = dio[1][i] = (int32_t)rnd() >> (10 + sh);
        cl_diffuse(dio[0] + 4, dbuf[0], wp, amount, n);
        diffuse_ref(dio[1] + 4, dbuf[1], (wp + 1) & 2047, amount, n);
        blocks++;
        for (int i = 0; i < 72; i++) if (dio[0][i] != dio[1][i]) { fail("cl_diffuse", k); break; }
        for (int i = 0; i < 2048; i++) if (dbuf[0][i] != dbuf[1][i]) { fail("cl_diffuse ring", k); break; }
    }
}

/* clouds_dsp.c reverb_quarter's pass, the LFO offsets held (the C steps the LFOs between cl_reverb calls) */
enum { QB0 = 0, QB1 = 29, QB2 = 71, QB3 = 132, QB4 = 233, QB5 = 647, QB6 = 1158, QB7 = 2012, QB8 = 2491, QB9 = 2908,
       QT0 = 27, QT1 = 69, QT2 = 130, QT3 = 231, QT4 = 645, QT5 = 1156, QT6 = 2010, QT7 = 2489, QT8 = 2906 };
#define QN 4096
static inline int32_t rv_dec(int16_t v) { return (int32_t)v * 8; }
static inline int16_t rv_enc(int32_t v) { return (int16_t)clip16(v / 8); }
#define VK(v, k) (((int32_t)(v) * (k)) >> 12)
#define QRD(o) q[o]
#define QWR(o, x) do { const int32_t i_ = (wp + (o)) & (QN - 1); const int16_t v_ = rv_enc(x); rb[i_] = v_; rb[i_ + QN] = v_; } while (0)
#define MQ(a, b) (((a) >> 15) * (b) + ((((a) & 32767) * (b)) >> 15))
static inline int32_t qinterp(const int16_t *q, int32_t base, int32_t off_q16)
{
    const int16_t *r = q + base + (off_q16 >> 16);
    const int32_t f = off_q16 & 65535, a = rv_dec(r[0]), d = rv_dec(r[1]) - a;
    return a + (((d * (f >> 8)) + ((d * (f & 255)) >> 8)) >> 8);
}
static void reverb_ref(int16_t *rb, int32_t *io, int32_t wp, int cnt, int32_t off0, int32_t off9, int32_t *lp1p, int32_t *lp2p,
                       int32_t *wop, int32_t lp4, int32_t time, int32_t amount)
{
    const int32_t kap = 22938, gain = 6554;
    int32_t lp1 = *lp1p, lp2 = *lp2p, wo = *wop;
    wp = (wp + 1) & (QN - 1);
    for (int t = 0; t < 4 * cnt; t += 4) {
        if (--wp < 0) wp += QN;
        const int16_t *const q = rb + wp;
        int32_t acc, prev, apout, wet;
        int16_t v;
        acc = qinterp(q, QB0, off0);
        QWR(QB0 + 25, acc);
        acc = MQ((io[t] + io[t + 1] + io[t + 2] + io[t + 3]) >> 1, gain);
        v = QRD(QT0); prev = rv_dec(v); acc += VK(v, kap); QWR(QB0, acc); acc = MQ(acc, -kap) + prev;
        v = QRD(QT1); prev = rv_dec(v); acc += VK(v, kap); QWR(QB1, acc); acc = MQ(acc, -kap) + prev;
        v = QRD(QT2); prev = rv_dec(v); acc += VK(v, kap); QWR(QB2, acc); acc = MQ(acc, -kap) + prev;
        v = QRD(QT3); prev = rv_dec(v); acc += VK(v, kap); QWR(QB3, acc); acc = MQ(acc, -kap) + prev;
        apout = acc;
        acc = apout + MQ(qinterp(q, QB9, off9), time);
        lp1 += MQ(acc - lp1, lp4); acc = lp1;
        v = QRD(QT4); prev = rv_dec(v); acc += VK(v, -kap); QWR(QB4, acc); acc = MQ(acc, kap) + prev;
        v = QRD(QT5); prev = rv_dec(v); acc += VK(v, kap);  QWR(QB5, acc); acc = MQ(acc, -kap) + prev;
        QWR(QB6, acc); acc *= 2;
        wet = acc;
        acc = apout + VK(QRD(QT6), time);
        lp2 += MQ(acc - lp2, lp4); acc = lp2;
        v = QRD(QT7); prev = rv_dec(v); acc += VK(v, kap);  QWR(QB7, acc); acc = MQ(acc, -kap) + prev;
        v = QRD(QT8); prev = rv_dec(v); acc += VK(v, -kap); QWR(QB8, acc); acc = MQ(acc, kap) + prev;
        QWR(QB9, acc);
        const int32_t dw = (wet - wo) >> 2;
        io[t] += MQ(wo + dw - io[t], amount);
        io[t + 1] += MQ(wo + 2 * dw - io[t + 1], amount);
        io[t + 2] += MQ(wet - dw - io[t + 2], amount);
        io[t + 3] += MQ(wet - io[t + 3], amount);
        wo = wet;
    }
    *lp1p = lp1; *lp2p = lp2; *wop = wo;
}
static int16_t rvb[2][16384 + 64];
static int32_t rio[2][72];
static void reverbs(void)
{
    for (unsigned k = 0; k < 1500 && !bad; k++) {
        if (k % 100 == 0)                                /* the mirrored ring (equal copies), loud or full scale */
            for (int i = 0; i < QN; i++) {
                const uint32_t r = rnd();
                const int16_t v = (k / 100) % 3 == 1 && (r & 3) == 0 ? ((r & 4) ? 32767 : -32768) : (int16_t)(r >> (16 + (k / 100) % 3 * 2));
                rvb[0][i] = rvb[0][i + QN] = rvb[1][i] = rvb[1][i + QN] = v;
            }
        const int cnt = 1 + (int)(rnd() % 16);
        const int32_t wp0 = k % 4 == 0 ? (int32_t)(rnd() % 40) : k % 4 == 1 ? 4095 - (int32_t)(rnd() % 40) : (int32_t)(rnd() % QN);
        const int32_t l0 = k % 9 == 0 ? 0 : k % 9 == 1 ? 32768 : (int32_t)(rnd() % 32769);
        const int32_t l1 = k % 7 == 0 ? 0 : k % 7 == 1 ? 32768 : (int32_t)(rnd() % 32769);
        const int32_t off0 = (5 << 15) + 30 * l0, off9 = (1159 << 16) + 50 * l1;
        const int32_t time = 11469 + (int32_t)(rnd() % 20644), amount = (int32_t)(rnd() % 17695), lp4 = k % 5 ? 31930 : (int32_t)(rnd() % 32768);
        const int sh = (int)(k % 11);
        for (int i = 0; i < 72; i++) rio[0][i] = rio[1][i] = (int32_t)rnd() >> (9 + sh);
        int32_t lp1 = (int32_t)rnd() >> (10 + sh), lp2 = (int32_t)rnd() >> (10 + sh), wo = (int32_t)rnd() >> (10 + sh);
        cl_rev_t a = { rvb[0], wp0, cnt, rio[0] + 4, QB0 + (off0 >> 16), off0 & 65535, QB9 + (off9 >> 16), off9 & 65535,
                       lp1, lp2, wo, lp4, time, amount };
        cl_reverb(&a);
        reverb_ref(rvb[1], rio[1] + 4, wp0, cnt, off0, off9, &lp1, &lp2, &wo, lp4, time, amount);
        blocks++;
        if (a.lp1 != lp1 || a.lp2 != lp2 || a.wo != wo) fail("cl_reverb state", k);
        for (int i = 0; i < 72; i++) if (rio[0][i] != rio[1][i]) { fail("cl_reverb io", k); break; }
        for (int i = 0; i < 16384 + 64; i++) if (rvb[0][i] != rvb[1][i]) { fail("cl_reverb ring", k); break; }
    }
}

static void seeds(void)
{
    for (unsigned k = 0; k < 20000 && !bad; k++) {
        const int cnt = (int)(rnd() % 66);
        const uint32_t thr = k % 4 == 0 ? 0 : k % 4 == 1 ? 0xFFFFFFFFu : rnd() >> (rnd() % 32);
        const int32_t space = k % 3 == 0 ? (int32_t)(rnd() % 20000) : (int32_t)rnd();
        const int det = (int)(k & 1);
        uint32_t st[2] = { rnd(), k % 5 == 0 ? 0x7FFFFF00u + (rnd() & 255) : rnd() % 3 ? (uint32_t)(-256000 + (int32_t)(rnd() % 300000)) : rnd() };
        uint32_t rng = st[0];
        int32_t ph = (int32_t)st[1];
        int i = 0;
        for (; i < cnt; i++) {                           /* play_granular's tests, trigger off, not every sample */
            ph = (int32_t)((uint32_t)ph + 256u);
            rng = rng * 1664525u + 1013904223u;
            if (rng < thr || (det && ph >= space)) break;
        }
        const int r = cl_seed(st, cnt, thr, space, det);
        blocks++;
        if (r != i || st[0] != rng || st[1] != (uint32_t)ph) fail("cl_seed", k);
    }
}

static int16_t rsrc[72], rdst[2][72];
static void recs(void)
{
    for (unsigned k = 0; k < 4000 && !bad; k++) {
        const int n = 1 + (int)(rnd() % 64), o = (int)(k & 3);
        for (int i = 0; i < 72; i++) { rsrc[i] = k % 7 == 0 ? (rnd() & 1 ? 32767 : -32768) : rnd16(); rdst[0][i] = rdst[1][i] = (int16_t)i; }
        cl_rec(rdst[0] + o, rsrc + (k >> 2 & 1), n);
        for (int i = 0; i < n; i++) rdst[1][o + i] = (int16_t)clip16((rsrc[(k >> 2 & 1) + i] * 32767) >> 15);   /* buf_write_fade */
        blocks++;
        for (int i = 0; i < 72; i++) if (rdst[0][i] != rdst[1][i]) { fail("cl_rec", k); break; }
    }
}

int main(void)
{
    grains();
    mixes();
    norms();
    diffuses();
    reverbs();
    seeds();
    recs();
    if (!bad) { put("KERN ok blocks="); num(blocks); put("\n"); }
    t2_write(line, n);
    return 0;
}
