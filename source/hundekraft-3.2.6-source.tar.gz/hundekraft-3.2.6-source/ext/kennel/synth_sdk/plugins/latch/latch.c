/* latch: keep synth keyboard notes sounding after the keys come up, for drones. A feature plugin (docs/feature-hooks.md
 * "latch"): the red encoder push on the synth envelope page (T2, screen 0x16, no Shift) turns it on and off. Which kind
 * it turns on, LATCH or HOLD, is chosen on the same page with Shift held (screen 40, the scale view): the green push
 * switches it, and a green lane at the bottom shows it (tester request 2026-11-10: one push for on / off). The kind is
 * saved (latch.kind, 0 LATCH / 1 HOLD); on / off is not.
 *
 * While LATCH or HOLD is on, the input filter takes the key-up of a keyboard key that played a synth note, so VoiceCtl
 * never gets the note off; the note input observer remembers the op1_note every key-down produced (also while off, so
 * keys held when it is turned on are latched when they come up). LATCH: a new chord replaces the held notes. HOLD: new
 * notes add to them; when the play mode's voices are full (poly 6, else 1) the oldest held note goes first; a held key
 * pressed again releases just that note (its press and release are taken). Switching the kind while it is on keeps
 * the held notes (in LATCH, the next key after all are up replaces them). Turning
 * it off, STOP, a sound key, the DRUM key, a slot or mode change release them with op1_key_up (the observers, the note
 * pipeline and the MIDI note-off, as the stock key-up would have).
 *
 * R246 details (Ghidra on R246, docs/feature-hooks.md "latch"):
 *   - a keyboard press goes to FUN_019ac0b0: if no sequencer player takes the key, it panics when the key's
 *     "sounding" byte 0x01AAD488[index] is already set (global_controller.cpp:240), sets it and plays the note
 *     (index + 0x35 + 12 * synth octave, velocity 0x7F, send_midi 1) through VoiceCtl key_down. The key-up
 *     (FUN_019ac2f8) clears that byte and plays the note off. A swallowed key-up must clear the byte here, or the
 *     next press of that key halts the OP-1.
 *   - a key a sequencer player took is not in that byte (it is in the player's key list): its key-up always goes on
 *     to the stock code, so a running sequencer gets its own key-ups and nothing is latched.
 * Keyboard notes only: MIDI in and sequencer notes never pass the input filter.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../../op1_feature.h"
#include "../../screens/stroke_font.h"

#ifdef OP1_HOST /* harness/latch_fc_test.c: R246's bytes as host data */
extern uint8_t host_key_sounding[24];
extern int32_t host_drum_bank, host_synth_oct, host_mode;
extern int host_t2_stock;
extern int host_play_mode;
#define KEY_SOUNDING(i) (host_key_sounding[i])
#define DRUM_BANK()     (host_drum_bank)
#define SYNTH_OCTAVE()  (host_synth_oct)
#define CUR_MODE()      (host_mode)
#define T2_STOCK()      (host_t2_stock)
#define PLAY_MODE()     (host_play_mode)
extern uint8_t host_shift;
#define SHIFT()         (host_shift)
#else
#define KEY_SOUNDING(i) (((volatile uint8_t *)0x01AAD488)[i])                  /* global controller, per key index */
#define DRUM_BANK()     (*(volatile int *)0x01DE4C40 == 1)                      /* page_pos_is_drum */
#define SYNTH_OCTAVE()  (((const volatile int *)0x01DFE4E0)[*(volatile int *)0xFF8016D4 & 7])
#define CUR_MODE()      (*(volatile int *)0xFF907D58)                           /* ModeSwitcher: synth 0 */
/* the synth T2 page shows the stock ADSR screen object (vtable at +0xC), not sampler+'s own T2 page */
#define ADSR_VT 0x0190EA14u                                     /* measured natively, 3.1.4 rc2 */
#define T2_STOCK()      ({ const uint32_t *o = ((const uint32_t *const *)0x01DF4E54)[0x16]; o && o[3] == ADSR_VT; })
/* play mode of the current synth slot as VoiceCtl reads it (kennel/kn_shed.c): adsr word 4 >> 12, 0 poly, 1 mono,
 * 2 legato, 3 unison (OP1-Emulator docs/firmware/audio-graph.md "Voice allocation") */
#define PLAY_MODE()     (((const volatile int16_t *)(0x01B60EF0 + (*(volatile uint32_t *)0xFF8016D4 & 7) * 16))[4] >> 12)
#define SHIFT()         (*(volatile uint8_t *)0x01DD7F78)                       /* as scale.c's SC_SHIFT */
#endif

#define SCREEN_T2  0x16
#define SCREEN_T2_SHIFT 40      /* synth T2 with Shift held (playmode.svg; scale's view) */
#define KEY_RED    0x3E
#define KEY_GREEN  0x3C         /* encoder pushes are keys 0x3B..0x3E */
#define KEY_STOP   0x23
#define KEY_DRUM   0x03

enum { OFF, LATCH, HOLD };              /* mode: not saved, OFF at boot */
static uint8_t kind = LATCH;            /* what the red push turns on: LATCH or HOLD (saved as latch.kind) */
enum { NONE, DOWN, LATCHED, DROP };     /* DROP: a held key pressed again in HOLD, its press and release are taken */
static uint8_t mode, state[24];
static op1_note note[24];
static uint32_t age[24], ages;          /* press order of the notes, for HOLD's oldest */
static uint32_t down;                    /* keyboard keys physically down (any mode) */
static int pending = -1, expected;       /* the key whose note the next note_in down should be */
static uint8_t red_taken, green_taken;

/* KeyHandler key code -> keyboard index 0..23 (note_key_index 0x019C3322), -1 for other keys */
static int key_index(int code)
{
    static const int8_t idx[0x36] = {
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  1,  3,  5,      /* 0x00..0x0F: f3# g3# a3# */
        -1, -1, -1, -1, -1, -1, 10, 13, 15, 17, 20, 22,  7,  9, 11, 12,      /* 0x10..0x1F */
         8, -1, -1, -1, -1, -1, -1,  0,  2,  4,  6, -1, -1, -1, -1, -1,      /* 0x20..0x2F */
        14, 16, 18, 19, 21, 23 };                                            /* 0x30..0x35 */
    return code >= 0 && code < 0x36 ? idx[code] : -1;
}
static int sound_key(int code) { return (code >= 0x2D && code <= 0x2F) || (code >= 0x10 && code <= 0x14); }

static void release(int i)
{
    if (state[i] == LATCHED) {
        state[i] = NONE;
        if (!DRUM_BANK()) { op1_note n = note[i]; n.velocity = 0x40; op1_key_up(&n); }  /* as the stock key-up */
    }
}
static int any_latched(void) { for (int i = 0; i < 24; i++) if (state[i] == LATCHED) return 1; return 0; }
static void release_all(void) { for (int i = 0; i < 24; i++) release(i); }
static void forget(void) { for (int i = 0; i < 24; i++) if (state[i] == LATCHED) state[i] = NONE; }

/* voices the play mode can sound at once: poly 6; mono, legato and unison one note (unison puts all six on it).
 * Counted in keyboard keys: a chord stage that makes several voices of a key is not counted (R246 steals as in stock) */
static int voices(void) { return PLAY_MODE() == 0 ? 6 : 1; }
/* HOLD, before key i plays: release the oldest held notes until it fits. Keys still down are never released */
static void make_room(int i)
{
    int n = 0;
    for (int j = 0; j < 24; j++) n += j != i && (state[j] == LATCHED || state[j] == DOWN);
    while (n >= voices()) {
        int old = -1;
        for (int j = 0; j < 24; j++)
            if (j != i && state[j] == LATCHED && (old < 0 || (int32_t)(age[j] - age[old]) < 0)) old = j;
        if (old < 0) break;
        release(old); n--;
    }
}

static void toggle(void)
{
    mode = mode == OFF ? kind : OFF;
    if (mode == OFF) release_all();       /* keys still down keep their DOWN: they go up the stock way */
    op1_toast(mode == LATCH ? "latch on" : mode == HOLD ? "latch hold" : "latch off");
}
static void next_kind(void)               /* Shift + green push: the held notes stay when it is on */
{
    kind = kind == LATCH ? HOLD : LATCH;
    op1_setting_set("latch", "kind", kind == HOLD);
    if (mode != OFF) mode = kind;
    op1_toast(kind == HOLD ? "latch mode hold" : "latch mode latch");
}

static int input(const op1_input *in)
{
    if (in->type != OP1_IN_KEY) return 0;
    int code = in->code, i = key_index(code);
    pending = -1;
    if (i >= 0) {
        uint32_t bit = 1u << i;
        if (in->pressed) {
            uint32_t was = down;
            down |= bit;
            if (DRUM_BANK()) return 0;
            if (mode == HOLD && state[i] == LATCHED) { release(i); state[i] = DROP; return 1; }   /* just this note off */
            if (mode == LATCH) {
                if (!was && any_latched()) release_all();  /* first key after all were up: a new chord */
                release(i);                                /* a latched key again: R246 ignores a held note */
            } else if (mode == HOLD) make_room(i);
            state[i] = NONE;                               /* tracked in every mode: turning it on latches it */
            pending = i; expected = i + 0x35 + 12 * SYNTH_OCTAVE();
            return 0;
        }
        down &= ~bit;
        if (state[i] == DROP) { state[i] = NONE; return 1; }   /* the stock code never saw its press */
        if (state[i] != DOWN) return 0;
        state[i] = NONE;
        if (mode == OFF || DRUM_BANK() || !KEY_SOUNDING(i)) return 0;   /* a player's key, or the stock code's */
        KEY_SOUNDING(i) = 0;                               /* what the stock key-up would clear: the next press is safe */
        state[i] = LATCHED;
        return 1;
    }
    if (code == KEY_RED && in->mode == 0 && in->screen == SCREEN_T2 && !in->shift && T2_STOCK()) {
        if (in->pressed) { red_taken = 1; toggle(); return 1; }
    }
    if (code == KEY_RED && !in->pressed && red_taken) { red_taken = 0; return 1; }
    if (code == KEY_GREEN && in->mode == 0 && in->screen == SCREEN_T2_SHIFT && in->shift && T2_STOCK()) {
        if (in->pressed) { green_taken = 1; next_kind(); return 1; }
    }
    if (code == KEY_GREEN && !in->pressed && green_taken) { green_taken = 0; return 1; }
    if (in->pressed && (code == KEY_STOP || code == KEY_DRUM || sound_key(code))) release_all();   /* before the bank
                                                                     * or slot changes: the note offs go to this synth */
    return 0;
}

static void note_down(const op1_note *n, int param)
{
    (void)param;
    if (pending < 0) return;
    if (n->note == expected) { note[pending] = *n; state[pending] = DOWN; age[pending] = ++ages; }
    pending = -1;
}
static const op1_note_input observe = { .down = note_down };

static void event(int id, int32_t arg)
{
    (void)arg;
    if (id == OP1_EV_BOOT_DONE) kind = op1_setting_get("latch", "kind", 0) == 1 ? HOLD : LATCH;
    if (id == OP1_EV_NOTES_RESET) forget();               /* the stock voice reset has silenced them */
    if (id == OP1_EV_SLOT || (id == OP1_EV_MODE && DRUM_BANK())) { if (DRUM_BANK()) forget(); else release_all(); }
}

/* Keyboard strip in the top margin (owner-approved art run/screens-2026-11-03/latch.svg): 24 thin lines, one per
 * keyboard key, black keys shorter; navy when free, pink when latched; then "LATCH n" or "HOLD n". Every line is at most 9 px
 * (R246's rasterizer keeps a buffer the size of the longest line ever drawn). Integers only. */
#define STRIP_X 64    /* strip x 64..133, text to x 182: the left half of the top margin. Right of it the stock FX name box (T3, x 257..312)
                        * and REACTOR's vessel (x 187..261, from y 2) are in the way; FREQ on T3 ends at x 44 */
#define STRIP_DX 3
/* The kind on synth T2 with Shift held, in the green lane of scale's view (scale.c: title at x 8, KEY under white at
 * x 200, SCALE under red at x 268; the green lane x 120 is free): the kind in green capitals (9 px, y 116..125, ends
 * left of KEY's ring at x 164), the grey label MODE under it (7 px capitals, y 130..137, as scale's labels). */
#define KIND_X 101                       /* scale's lane text x: lane x 120 - 19 */
static void kind_lane(void *r)
{
    static const uint8_t green[4] = { 0x00, 0xed, 0x95, 255 }, grey[4] = { 0x7c, 0x79, 0x90, 255 };
    sf_text(r, OP1_Q10(KIND_X), OP1_Q10(116), 1536, kind == HOLD ? "HOLD" : "LATCH", 0x600, green);
    sf_text(r, OP1_Q10(KIND_X), OP1_Q10(130), 1229, "MODE", 0x600, grey);
}
static void overlay(void *r, int32_t screen)
{
    static const uint8_t navy[4] = { 0x38, 0x35, 0x72, 255 }, pink[4] = { 0xff, 0x90, 0xa7, 255 };
    if (screen == SCREEN_T2_SHIFT && SHIFT() && CUR_MODE() == 0 && T2_STOCK()) kind_lane(r);
    if (mode == OFF || CUR_MODE() != 0) return;            /* synth mode only */
    int n = 0;
    for (int i = 0; i < 24; i++) n += state[i] == LATCHED;
    for (int pass = 0; pass < 2; pass++)                   /* free keys first, so a latched line is never hidden */
        for (int i = 0; i < 24; i++) {
            int lit = state[i] == LATCHED, k = i % 12, black = k == 1 || k == 3 || k == 5 || k == 8 || k == 10;
            if (lit != pass) continue;
            int32_t x = OP1_Q10(STRIP_X + STRIP_DX * i);
            sf_line(r, x, OP1_Q10(4), x, OP1_Q10(black ? 9 : 13), 1536, lit ? pink : navy);
        }
    int32_t x = sf_text(r, OP1_Q10(STRIP_X + STRIP_DX * 23 + 6), OP1_Q10(5), OP1_Q10(1), mode == HOLD ? "HOLD" : "LATCH",
                        OP1_Q10(1), pink);
    if (n > 0) {
        char d[3] = { 0, 0, 0 };
        if (n >= 10) { d[0] = (char)('0' + n / 10); d[1] = (char)('0' + n % 10); } else d[0] = (char)('0' + n);
        sf_text(r, x + OP1_Q10(3), OP1_Q10(5), OP1_Q10(1), d, OP1_Q10(1), pink);
    }
}

static const char *const claims[] = { "key:synth:t2+orange", "key:synth:shift+t2+green", 0 };
const op1_feature_t FEATURE_latch = { .api = OP1_FEATURE_API, .priority = 950, .name = "latch", .input = input,
    .note_in = &observe, .event = event, .overlay = overlay, .claims = claims };
