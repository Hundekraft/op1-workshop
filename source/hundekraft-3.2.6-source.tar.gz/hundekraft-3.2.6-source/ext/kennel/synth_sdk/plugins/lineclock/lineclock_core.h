/* line clock core: pulse detector and the clock spreader, no R246 access (host-tested by harness/lineclock_test.c).
 *
 * The detector is Pulse Sync's (pulse_core.h, Pulse Sync 0.1.3, esc.pulsesync), ported with the author's consent
 * (owner, 2026-11-03): one chosen edge per pulse, re-armed below a quarter of the threshold, then blanked for 2 ms.
 * Pulse Sync: Copyright (C) 2026 Volker Junginger (ESC_CODE), https://github.com/VolkerJunginger/OP-1/tree/pulse-sync,
 * GPL-3.0-or-later.
 *
 * What kennel adds: PPQ 24 / 4 / 2 / 1. At 24 PPQ every pulse is one MIDI clock (F8). At 4, 2 and 1 PPQ a pulse is 6, 12
 * or 24 clocks: the first goes out at the pulse, the rest are spread evenly over the measured pulse period, at most one per
 * 64-sample block, so R246's clock-in path (4 pending ticks per F8, one tick per block, tempo from every 24 clocks)
 * sees an even clock, not bursts. If a pulse comes before all of the previous one's clocks went out (the master sped
 * up), the missing ones follow one per block, so the beat count stays locked to the master. Before the second pulse
 * the period is guessed from the OP-1's current tempo. Auto start / stop: START (FA) before the first clock, STOP (FC)
 * after a gap of 4 pulse periods (0.3 s .. 3 s; 3 s before a second pulse has measured the period).
 * Integers only; one division per pulse, none per sample.
 * Copyright (C) 2026 Volker Junginger (ESC_CODE), Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission
 * (see LICENSE and NOTICE).
 */
#ifndef LINECLOCK_CORE_H
#define LINECLOCK_CORE_H
#include <stdint.h>

/* ---- Pulse Sync's detector (pulse_core.h), blank scaled to the block rate ---- */
struct pulse_detector { unsigned armed, blank; };
static void pulse_reset(struct pulse_detector *d) { d->armed = 0; d->blank = 0; }
static unsigned pulse_sample(struct pulse_detector *d, int sample, unsigned threshold, unsigned negative, unsigned blank)
{
    int x = negative ? -sample : sample;
    if (d->blank) --d->blank;
    if (x <= (int)(threshold / 4u)) d->armed = 1;
    if (d->armed && x >= (int)threshold) {
        d->armed = 0;
        if (!d->blank) {
            d->blank = blank;                   /* 2 ms */
            return 1;
        }
    }
    return 0;
}

/* ---- the clock spreader ---- */
#define LC_OUT_MAX 6
typedef struct {
    uint8_t ppq;                /* 24, 4, 2 or 1 (0: off) */
    uint8_t autostart;          /* 1: FA on the first pulse, FC after a gap */
    uint8_t falling;            /* 1: the falling edge counts */
    uint16_t threshold;         /* 64..16000 */
} lc_cfg;

typedef struct {
    struct pulse_detector det;
    uint32_t now;               /* samples, start of the current block */
    uint32_t last;              /* sample of the last pulse */
    uint32_t period;            /* samples between the last two pulses (0: unknown) */
    uint32_t interval;          /* period / clocks per pulse, Q8 samples */
    uint32_t acc;               /* time since the last scheduled clock, Q8 samples */
    uint32_t timeout;           /* samples without a pulse until the clock counts as stopped */
    uint8_t n, sent, owed, running, have;
    uint8_t measured;           /* 1 once a gap between two pulses gave the period (else it is a guess) */
    /* counters (read by the screen and the native check) */
    uint32_t pulses, clocks, starts, stops, extra_edges, max_out;
    uint16_t peak;              /* largest |sample| of the last block with input */
} lc_state;

static void lc_reset(lc_state *s)
{
    pulse_reset(&s->det);
    s->running = 0; s->have = 0; s->sent = 0; s->owed = 0; s->period = 0; s->interval = 0; s->acc = 0; s->measured = 0;
}

static uint32_t lc_clamp(uint32_t v, uint32_t lo, uint32_t hi) { return v < lo ? lo : v > hi ? hi : v; }

/* one 64-sample block. in: the input (0: none this block); detect: count pulses in it (switched on, line in);
 * beat_len: the OP-1's beat length in 1/16384 samples at 44.1 kHz (op1_beat_t.len; <= 0: unknown); rate: block
 * rate. Writes the real-time bytes to post into out (LC_OUT_MAX) and returns their count. */
static int lc_block(lc_state *s, const lc_cfg *c, const int16_t *in, int detect, int32_t beat_len, uint32_t rate,
                    uint8_t *out)
{
    int k = 0, hit = -1;
    uint32_t n = c->ppq == 4 ? 6u : c->ppq == 2 ? 12u : c->ppq == 1 ? 24u : 1u;
    s->n = (uint8_t)n;
    if (s->sent > n) s->sent = (uint8_t)n;                          /* PPQ changed while running */
    if (in) {
        unsigned peak = 0, blank = rate / 500u;
        for (int i = 0; i < 64; i++) {
            int x = in[i];
            unsigned m = (unsigned)(x < 0 ? -x : x);
            if (m > peak) peak = m;
            if (detect && pulse_sample(&s->det, x, c->threshold, c->falling, blank)) {
                if (hit < 0) hit = i; else s->extra_edges++;
            }
        }
        s->peak = (uint16_t)(peak > 65535u ? 65535u : peak);
    }
    uint32_t end = s->now + 64u;
    if (hit >= 0) {
        uint32_t t = s->now + (uint32_t)hit, gap = t - s->last;
        s->pulses++;
        if (!s->running || !s->have || gap > s->timeout) {          /* a new start */
            if (c->autostart) out[k++] = 0xFA, s->starts++;
            s->running = 1; s->owed = 0; s->measured = 0;
            s->period = beat_len > 0 && c->ppq ? (uint32_t)(beat_len >> 14) * (rate / 100u) / 441u / c->ppq : 0;
        } else {
            uint32_t missing = n - s->sent + s->owed;
            s->owed = (uint8_t)(missing > n ? n : missing);
            s->period = gap; s->measured = 1;
        }
        out[k++] = 0xF8; s->clocks++;
        s->sent = 1; s->last = t; s->have = 1;
        s->interval = s->period ? (s->period << 8) / n : 0;
        s->acc = (end - t) << 8;
        /* the stop gap: 4 measured periods (0.3 .. 3 s). Before the second pulse the period is only the OP-1's own tempo's
           guess: wait 3 s then (2026-11-08: a 1-pulse-a-beat clock with RATE 24 timed out on every pulse, a start and a
           stop each time, so R246 never measured a tempo) */
        s->timeout = s->measured ? lc_clamp(s->period * 4u, rate * 3u / 10u, rate * 3u) : rate * 3u;
    } else if (s->running) {
        s->acc += 64u << 8;
    }
    if (s->running) {
        if (s->owed) { out[k++] = 0xF8; s->clocks++; s->owed--; }
        if (s->sent < n && s->interval && s->acc >= s->interval) {
            out[k++] = 0xF8; s->clocks++; s->sent++; s->acc -= s->interval;
        }
        if (end - s->last > s->timeout) {                             /* the master stopped */
            if (c->autostart) out[k++] = 0xFC, s->stops++;
            s->running = 0; s->sent = 0; s->owed = 0;
        }
    }
    s->now = end;
    if ((uint32_t)k > s->max_out) s->max_out = (uint32_t)k;
    return k;
}

/* the observer's return: keep this block's line input out of the monitor, the tape and input engines only while a
   clock is actually coming in (2026-11-08: it muted line in whenever RATE was on and sync followed MIDI, so VOX / SNAP /
   Amp got silence on line with no clock plugged in; a user found SNAP silent on line). The first pulse's block is
   heard; from the next block on the clicks are not. */
static inline int lc_mute(int live, int line, const lc_state *s) { return live && line && s->running; }

/* switched off or the clock path went away while running: 1 if a STOP should go out (auto start / stop) */
static int lc_stop(lc_state *s, const lc_cfg *c)
{
    int fc = s->running && c->autostart;
    if (fc) s->stops++;
    s->running = 0; s->sent = 0; s->owed = 0;
    return fc;
}

/* tempo the pulses give, in tenths of a BPM (0: not known yet) */
static uint32_t lc_bpm10(const lc_state *s, uint32_t rate, uint32_t ppq)
{
    if (!s->period || !ppq || !s->have || !s->measured) return 0;   /* the guess is the OP-1's own tempo: not shown */
    return (rate * 600u) / (s->period * ppq);
}
#endif
