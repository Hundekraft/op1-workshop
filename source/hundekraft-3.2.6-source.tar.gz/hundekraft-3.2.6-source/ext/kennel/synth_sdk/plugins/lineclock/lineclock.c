/* line clock: follow a pulse clock on the line-in jack (feature plugin, kind 3).
 *
 * A port of Pulse Sync 0.1.3 (esc.pulsesync, an Opus plugin by ESC_CODE: https://github.com/VolkerJunginger/OP-1/tree/
 * pulse-sync/Pulse-Sync), ported into kennel under kennel's terms with the author's consent (owner, 2026-11-03).
 * Pulse Sync's design, kept here: read R246's selected input block (input_mono_buf, 64 samples) every audio block, find
 * one edge per pulse (lineclock_core.h), turn each pulse into a MIDI clock in R246's MIDI receive ring, so the stock
 * clock-in path ("sync" on the tempo screen) does the rest, and keep the clicks out of the dry input monitor.
 * kennel's version: the core services (op1_input_observe, op1_midi_rx_post, op1_midi_usb_clocks) instead of Opus
 * hooks; 24 / 4 / 2 PPQ with the clocks of 4 and 2 PPQ spread over the pulse period; auto start / stop; it stands
 * back while a USB MIDI clock is running; the settings live on the tempo screen with Shift held.
 *
 * Runs only when: switched on (a PPQ chosen; RATE is off until set, 2026-11-08), the tempo screen's sync mode follows MIDI clock (modes 2 / 4: 0x018C1870),
 * the input is line in (core_input_source 1, or a line cable in and the source is not radio / USB), and no USB clock
 * came in during the last second. While pulses come in (the clock runs) the dry input is muted (the clicks are neither
 * heard nor recorded; Amp, VOX and SNAP get silence); with no clock plugged in, line in passes as usual.
 *
 * Controls, tempo screen with Shift held; each column of the panel is set by the encoder of its colour. Stock uses Shift +
 * blue and Shift + green turns there, so the turns of those two are left alone; their pushes are free (no case in
 * R246's tempo key handler 0x01A5EC30 or the global Shift handler): blue push RATE off / 24 / 4 / 2 / 1 PPQ, green push
 * START auto / manual, white turn LEVEL (threshold), red push or turn EDGE rise / fall. Settings "lineclock.ppq",
 * ".auto", ".edge", ".level" (op1rsettings).
 *
 * Copyright (C) 2026 Volker Junginger (ESC_CODE), Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission
 * (see LICENSE and NOTICE).
 */
#include "../../op1_synth.h"
#include "../../op1_feature.h"
#include "../../op1_feature_midi.h"
#include "../../op1_input.h"
#include "../../screens/stroke_font.h"
#include "lineclock_core.h"

#define SYNC_MODE   (*(volatile int32_t *)0x018C1870)       /* tempo screen sync: 2 / 4 follow MIDI clock */
#define SHIFT_HELD  (*(volatile uint8_t *)0x01DD7F78)
#define TEMPO_SCREEN 34                                     /* tempo.svg (docs/firmware/ui.md) */

static const uint8_t ppq_val[5] = { 0, 24, 4, 2, 1 };   /* RATE: off, 24, 4, 2, 1 PPQ (1 added 2026-11-08: Pamela's x1) */
#define PPQ() (set_ppq < 5 ? ppq_val[set_ppq] : 0)
static const uint16_t level_val[8] = { 128, 256, 512, 1024, 2048, 4096, 8192, 16000 };
static volatile uint8_t set_ppq = 0, set_auto = 1, set_edge, set_level = 3;   /* indexes; defaults RATE off (2026-11-08; 24 PPQ before), auto, up, 1024 */
static volatile uint8_t stop_req;                           /* switched off while running: one STOP from the audio side */

/* audio-thread state */
static lc_state st;
static uint8_t was_on, cfg_edge, cfg_level;
static uint32_t usb_seen, usb_quiet;                        /* blocks left until the USB clock counts as gone */
/* what the screen shows (written by the audio thread) */
enum { LC_OFF, LC_NO_SYNC, LC_NO_LINE, LC_USB, LC_WAIT, LC_FOLLOW };
static volatile uint8_t show_state;
static volatile uint32_t show_rate = 44100;
/* native check: cycles of the observer, posts that did not fit the queue */
volatile uint32_t lc_cyc_max, lc_cyc_sum, lc_calls, lc_post_fail;

static int observer(const int16_t *in, int source, int jack, uint32_t rate)
{
    uint32_t t0 = op1_cycles();
    lc_cfg c = { PPQ(), set_auto, set_edge, level_val[set_level & 7] };
    int on = c.ppq != 0, follow = SYNC_MODE == 2 || SYNC_MODE == 4;
    int line = source == 1 || (jack && source != 2 && source != 3);
    uint32_t u = op1_midi_usb_clocks();
    if (u != usb_seen) { usb_seen = u; usb_quiet = rate / 64u; } else if (usb_quiet) usb_quiet--;
    uint8_t out[LC_OUT_MAX];
    int k = 0;
    if (stop_req) { stop_req = 0; if (follow && !usb_quiet && lc_stop(&st, &c)) out[k++] = 0xFC; }
    if (on && (c.falling != cfg_edge || set_level != cfg_level)) { pulse_reset(&st.det); cfg_edge = c.falling; cfg_level = set_level; }
    int live = on && follow && !usb_quiet;
    if (!live) {
        if (st.running) lc_stop(&st, &c);                   /* sync mode changed or a USB clock: no STOP from us */
        st.have = 0;
    } else {
        if (!was_on) lc_reset(&st);
        op1_beat_t b;
        op1_beat_clock(&b);
        k += lc_block(&st, &c, in, line, b.len, rate, out + k);
    }
    was_on = (uint8_t)live;
    for (int i = 0; i < k; i++) if (op1_midi_rx_post(out[i])) lc_post_fail++;
    show_rate = rate;
    show_state = !on ? LC_OFF : !follow ? LC_NO_SYNC : usb_quiet ? LC_USB : !line ? LC_NO_LINE : st.running ? LC_FOLLOW : LC_WAIT;
    uint32_t d = op1_cycles() - t0;
    lc_calls++; lc_cyc_sum += d; if (d > lc_cyc_max) lc_cyc_max = d;
    return lc_mute(live, line, &st);                        /* while pulses come in: the clicks out of the monitor and the tape */
}

/* ---- settings ---- */
static void save(void)
{
    op1_setting_set("lineclock", "ppq", set_ppq);
    op1_setting_set("lineclock", "auto", set_auto);
    op1_setting_set("lineclock", "edge", set_edge);
    op1_setting_set("lineclock", "level", set_level);
}
static int32_t acc[2];
static int step(int i, int delta)                           /* one step per detent (1024) */
{
    if ((acc[i] > 0 && delta < 0) || (acc[i] < 0 && delta > 0)) acc[i] = 0;
    acc[i] += delta;
    if (acc[i] > -1024 && acc[i] < 1024) return 0;
    int s = acc[i] > 0 ? 1 : -1;
    acc[i] = 0;
    return s;
}
static int lc_input(const op1_input *in)
{
    if (in->screen != TEMPO_SCREEN || !in->shift) return 0;
    if (in->type == OP1_IN_KNOB && (in->code == 2 || in->code == 3)) {
        int s = step(in->code - 2, in->delta);
        if (s && in->code == 2) {                           /* white turn: LEVEL */
            int v = set_level + s;
            if (v >= 0 && v <= 7) { set_level = (uint8_t)v; save(); }
        } else if (s && set_edge != (s > 0)) {              /* red turn: EDGE (clockwise falls) */
            set_edge = s > 0; save();
        }
        return 1;
    }
    if (in->type == OP1_IN_KEY && (in->code == 0x3B || in->code == 0x3C || in->code == 0x3E)) {
        if (in->pressed) {
            if (in->code == 0x3B) {                         /* blue push: RATE off -> 24 -> 4 -> 2 -> 1 -> off */
                int v = (set_ppq + 1) % 5;
                if (!v) stop_req = 1;
                set_ppq = (uint8_t)v;
            } else if (in->code == 0x3C) set_auto = !set_auto;   /* green push: START */
            else set_edge = !set_edge;                      /* red push: EDGE */
            save();
        }
        return 1;                                           /* the release too */
    }
    return 0;
}

/* ---- the panel over the tempo screen while Shift is held (Gfx thread) ----
 * Owner-approved mockup 2026-11-03 (320 x 160), lifted so the labels end at y 130: LINE CLOCK and the state at the
 * top, the tempo (or the one missing step) with the PULSE lamp and the four BEAT dots, the INPUT bar with the red
 * TRIGGER mark, then four columns, one per encoder (blue RATE, green START, white LEVEL, red EDGE).
 * Opaque: black rows over the whole screen. Every line is at most 32 px long (see hline). */
static const uint8_t c_white[4] = { 0xFF, 0xFF, 0xFF, 0xFF }, c_red[4] = { 0xFF, 0x3A, 0x5D, 0xFF },
                     c_grey[4] = { 0x65, 0x65, 0x79, 0xFF }, c_green[4] = { 0x00, 0xED, 0x95, 0xFF },
                     c_blue[4] = { 0x69, 0x8E, 0xFF, 0xFF }, c_track[4] = { 0x38, 0x35, 0x72, 0xFF },
                     c_black[4] = { 0, 0, 0, 0xFF };
static char *num(char *p, uint32_t v) { char t[10]; int n = 0; do t[n++] = (char)('0' + v % 10); while (v /= 10); while (n) *p++ = t[--n]; *p = 0; return p; }
static char *cat(char *p, const char *s) { while (*s) *p++ = *s++; *p = 0; return p; }
/* A horizontal line in pieces of at most 32 px. R246's line rasterizer keeps a TE heap buffer sized to the longest line
 * it has drawn and never gives it back (measured natively 2026-11-03: one 320 px line, thin or 12 px wide, +9,408 bytes;
 * 160 px +3,664; 80 px +792; 40 px +408; a 50 px vertical line 0). In pieces the panel costs a few hundred bytes. */
static void hline(void *r, int x0, int x1, int y, int32_t w, const uint8_t *c)
{
    for (int x = x0; x < x1; x += 32)
        sf_line(r, OP1_Q10(x), OP1_Q10(y), OP1_Q10(x + 32 < x1 ? x + 32 : x1), OP1_Q10(y), w, c);
}
/* scales (px per grid unit, Q10): the stroke font is 4 x 6 units, 6 units per character */
#define SC_TEMPO 3584                                       /* 3.5: 21 px digits */
#define SC_MSG   2048                                       /* 2.0: 12 px capitals */
#define SC_VAL   1792                                       /* 1.75 */
#define SC_MID   1434                                       /* 1.4 */
#define SC_TOP   1229                                       /* 1.2 */
#define SC_LBL   1024                                       /* 1.0: 6 px */
static int txt(void *r, int x, int y, int32_t s, const char *t, const uint8_t *c)
{
    return sf_text(r, OP1_Q10(x), OP1_Q10(y), s, t, s >= 3000 ? 0x900 : s >= 1800 ? 0x700 : 0x500, c) >> 10;
}
static int twid(const char *t, int32_t s)                   /* ink width in px */
{
    int32_t w = -2 * s;
    for (; *t; t++) w += (*t == '1' || *t == '.' ? 4 : 6) * s;
    return (int)(w >> 10);
}
static int isq(int v) { int r = 0; while ((r + 1) * (r + 1) <= v) r++; return r; }
static void disc(void *r, int cx, int cy, int rad, const uint8_t *c)   /* filled: rows of at most 2 * rad + 1 px */
{
    for (int dy = -rad; dy <= rad; dy++) {
        int hw = isq(rad * rad + rad - dy * dy);
        sf_line(r, OP1_Q10(cx - hw), OP1_Q10(cy + dy), OP1_Q10(cx + hw), OP1_Q10(cy + dy), 0x680, c);
    }
}
static void ring(void *r, int cx, int cy, int rad, const uint8_t *c)   /* 12 segments, 1.5 px */
{
    static const int16_t cs[13] = { 256, 222, 128, 0, -128, -222, -256, -222, -128, 0, 128, 222, 256 },
                         sn[13] = { 0, 128, 222, 256, 222, 128, 0, -128, -222, -256, -222, -128, 0 };
    for (int i = 0; i < 12; i++)
        sf_line(r, OP1_Q10(cx) + rad * cs[i] * 4, OP1_Q10(cy) + rad * sn[i] * 4,
                OP1_Q10(cx) + rad * cs[i + 1] * 4, OP1_Q10(cy) + rad * sn[i + 1] * 4, 0x600, c);
}
/* input level to a bar position, 0..300 px: 33 px per octave from 64 to 32768, so the eight LEVELs sit evenly */
static int mpos(uint32_t v)
{
    if (v < 64) return 0;
    int e = 6;
    while (e < 15 && (v >> (e + 1))) e++;
    int p = (e - 6) * 33 + (int)((((v - (1u << e)) << 5) >> e) * 33 >> 5);
    return p > 300 ? 300 : p;
}
static uint32_t lvl_hold, run_base;                                   /* the bar's peak hold (Gfx only) */

static void lc_overlay(void *r, int32_t screen)
{
    if (screen != TEMPO_SCREEN || !SHIFT_HELD) return;
    for (int y = 4; y <= 156; y += 8)                       /* opaque: black over the whole screen, wide lines are capped */
        hline(r, 0, 320, y, OP1_Q10(12), c_black);
    char t[24], *p;
    int sstate = show_state, ready = sstate == LC_FOLLOW || sstate == LC_WAIT;
    uint32_t th = level_val[set_level & 7];

    /* top line */
    static const char *const word[6] = { "OFF", "NOT READY", "NOT READY", "USB CLOCK", "WAITING", "FOLLOWING" };
    txt(r, 10, 6, SC_TOP, "LINE CLOCK", c_grey);
    txt(r, 310 - twid(word[sstate], SC_TOP), 6, SC_TOP, word[sstate],
        sstate == LC_FOLLOW ? c_green : sstate == LC_NO_SYNC || sstate == LC_NO_LINE ? c_red : sstate == LC_OFF ? c_grey : c_white);

    if (ready) {
        /* the tempo, BPM, PULSE lamp and BEAT dots */
        uint32_t b = sstate == LC_FOLLOW ? lc_bpm10(&st, show_rate, PPQ()) : 0;
        if (b) { p = num(t, b / 10); *p++ = '.'; num(p, b % 10); } else cat(t, "---.-");
        int x = txt(r, 10, 24, SC_TEMPO, t, b ? c_green : c_grey);
        txt(r, x + 4, 37, SC_MID, "BPM", c_grey);
        uint32_t hold = show_rate * 3u / 50u;               /* lit for 60 ms, or half a pulse when the pulses come faster */
        if (st.period && hold > st.period / 2) hold = st.period / 2;
        if (sstate == LC_FOLLOW && st.have && st.now - st.last < hold) disc(r, 190, 34, 8, c_green);
        else ring(r, 190, 34, 8, c_grey);
        txt(r, 176, 48, SC_LBL, "PULSE", c_grey);
        uint32_t beat = 4u;                                 /* 24 clocks a beat, counted from the clock's start (seen while it was stopped) */
        if (!st.running) run_base = st.clocks;
        if (sstate == LC_FOLLOW) beat = st.clocks == run_base ? 0u : ((st.clocks - run_base - 1u) / 24u) & 3u;
        for (int i = 0; i < 4; i++) {
            if ((uint32_t)i == beat) disc(r, 226 + 20 * i, 34, 5, c_white);
            else ring(r, 226 + 20 * i, 34, 5, c_grey);
        }
        txt(r, 221, 48, SC_LBL, "BEAT", c_grey);
    } else {
        /* the one missing step, then a hint */
        static const char *const msg[6] = { "TURN RATE ON", "SET SYNC TO MIDI IN", "PLUG INTO LINE IN", "USB CLOCK IS LEADING", "", "" };
        txt(r, 10, 24, SC_MSG, msg[sstate], c_white);
        const char *hint = sstate == LC_NO_SYNC ? "TEMPO SCREEN, TURN" : sstate == LC_OFF ? "PUSH" : 0;   /* (drawn while Shift is held) */
        if (hint) {
            int x = txt(r, 10, 44, SC_MID, hint, c_grey);
            disc(r, x + 8, 48, 4, sstate == LC_NO_SYNC ? c_green : c_blue);
        }
    }

    /* input level against the threshold: the bar, the red TRIGGER mark; only measured while the clock is live */
    uint32_t pk = ready ? st.peak : 0;
    lvl_hold = pk >= lvl_hold ? pk : lvl_hold - (lvl_hold >> 3) - (lvl_hold ? 1 : 0);
    int bx = 10 + mpos(lvl_hold), tx = 10 + mpos(th);
    hline(r, 10, 310, 70, OP1_Q10(5), c_track);
    if (bx > 10) hline(r, 10, bx, 70, OP1_Q10(5), lvl_hold >= th ? c_green : c_grey);
    sf_line(r, OP1_Q10(tx), OP1_Q10(62), OP1_Q10(tx), OP1_Q10(78), 0x800, c_red);
    txt(r, 10, 82, SC_LBL, "INPUT", c_grey);
    txt(r, tx - 8 > 48 ? tx - 8 : 48, 82, SC_LBL, "TRIGGER", c_red);

    /* four columns under the encoders: blue RATE, green START, white LEVEL, red EDGE */
    hline(r, 8, 312, 100, 0x400, c_track);
    p = t; if (set_ppq) cat(num(p, PPQ()), " PPQ"); else cat(p, "OFF");
    txt(r, 10, 108, SC_VAL, t, c_blue);
    txt(r, 90, 108, SC_VAL, set_auto ? "AUTO" : "MANUAL", c_green);
    p = cat(t, "LVL "); num(p, (uint32_t)set_level + 1u);
    txt(r, 170, 108, SC_VAL, t, c_white);
    txt(r, 250, 108, SC_VAL, set_edge ? "FALL" : "RISE", c_red);
    txt(r, 10, 124, SC_LBL, "RATE", c_grey);
    txt(r, 90, 124, SC_LBL, "START", c_grey);
    txt(r, 170, 124, SC_LBL, "LEVEL", c_grey);
    txt(r, 250, 124, SC_LBL, "EDGE", c_grey);
}

static void lc_event(int id, int32_t arg)
{
    (void)arg;
    if (id != OP1_EV_BOOT_DONE) return;
    int v = op1_setting_get("lineclock", "ppq", 0); set_ppq = (uint8_t)(v >= 0 && v <= 4 ? v : 0);   /* no row: off */
    set_auto = op1_setting_get("lineclock", "auto", 1) != 0;
    set_edge = op1_setting_get("lineclock", "edge", 0) != 0;
    v = op1_setting_get("lineclock", "level", 3); set_level = (uint8_t)(v >= 0 && v <= 7 ? v : 3);
    if (op1_input_observe(observer)) op1_toast("line clock: input taken");
}

static const char *const lc_claims[] = { "key:tempo:shift+blue-push", "key:tempo:shift+green-push", "key:tempo:shift+white", "key:tempo:shift+red",
                                     "input:observer", 0 };
const op1_feature_t FEATURE_lineclock = { .api = OP1_FEATURE_API, .priority = 1000, .name = "lineclock",
                                          .event = lc_event, .input = lc_input, .overlay = lc_overlay,
                                          .claims = lc_claims };
