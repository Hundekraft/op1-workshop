/* HOLD sequencer model (hold_model.h). No libc, no division per tick; ticks come from the player (audio thread).
 *
 * The pattern has 1..16 steps of 1/16, each up to four notes. While it runs, the pattern keys held at a step's start
 * (or pressed during it) become that step's notes; a note still held from the step before is tied to it (it sounds
 * on, not again), so a key held over four steps is one long note. With no key down the pattern plays what it has.
 * Keys below the break point transpose the pattern while held.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "hold_model.h"

void hold_clear(hold_state *s)
{
    for (int i = 0; i < HOLD_STEPS; i++) hold_erase(s, i);
}
void hold_erase(hold_state *s, int step)
{
    if ((unsigned)step >= HOLD_STEPS) return;
    for (int k = 0; k < HOLD_POLY; k++) s->cfg.note[step][k] = -1;
    s->cfg.tie[step] = 0;
    s->changed = 1;
}
void hold_init(hold_state *s)
{
    uint8_t *b = (uint8_t *)s;
    for (unsigned i = 0; i < sizeof *s; i++) b[i] = 0;
    s->cfg.length = 16; s->cfg.keep = 1;
    hold_clear(s);
    s->changed = 0; s->low = -1; s->halted = 1;
    for (int i = 0; i < 24; i++) s->keynote[i] = -1;
    for (int k = 0; k < HOLD_POLY; k++) { s->id[k] = -1; s->pitch[k] = -1; }
}
int hold_empty(const hold_state *s)
{
    for (int i = 0; i < s->cfg.length; i++) if (s->cfg.note[i][0] >= 0) return 0;
    return 1;
}
int hold_shift(const hold_state *s)
{
    return s->cfg.transpose + (s->low >= 0 && s->cfg.split ? s->low - s->cfg.split : 0);
}
void hold_release(hold_state *s)
{
    for (int k = 0; k < HOLD_POLY; k++) if (s->id[k] >= 0) { hold_note_off(s->id[k]); s->id[k] = -1; s->pitch[k] = -1; }
}
void hold_quiet(hold_state *s)
{
    hold_release(s);
    s->held = 0; s->low = -1; s->recording = 0;
    for (int i = 0; i < 24; i++) s->keynote[i] = -1;
}
void hold_stop(hold_state *s)
{
    hold_quiet(s);
    s->started = 0; s->step = 0; s->elapsed = 0; s->halted = 1;
}
void hold_play(hold_state *s, int on)
{
    if (on) s->halted = 0;
    else hold_stop(s);
}

/* the held pattern keys into step st (poly: lowest four; mono: the last pressed); tie: notes held since the step
 * before stay tied to it */
static void write_step(hold_state *s, int st, int tie)
{
    hold_config *c = &s->cfg;
    int prev = st ? st - 1 : c->length - 1, n = 0;
    int8_t notes[HOLD_POLY];
    if (c->mono) {
        int key = (s->held >> s->last) & 1 ? s->last : -1;
        for (int i = 23; key < 0 && i >= 0; i--) if ((s->held >> i) & 1) key = i;
        if (key >= 0 && s->keynote[key] >= 0) notes[n++] = s->keynote[key];
    } else {
        for (int i = 0; i < 24 && n < HOLD_POLY; i++)
            if ((s->held >> i) & 1 && s->keynote[i] >= 0) notes[n++] = s->keynote[i];
    }
    uint8_t t = 0;
    for (int k = 0; k < HOLD_POLY; k++) {
        int8_t v = k < n ? notes[k] : -1;
        if (v >= 0 && tie)
            for (int j = 0; j < HOLD_POLY; j++) if (c->note[prev][j] == v) t |= (uint8_t)(1u << k);
        c->note[st][k] = v;
    }
    c->tie[st] = t;
    s->changed = 1;
}

/* make the sounding notes match step st: a note on in the step and tied (or `keep`: already sounding) goes on
 * sounding, the others go off, the step's other notes start */
static void sync(hold_state *s, int mode, int st, int keep)
{
    const hold_config *c = &s->cfg;
    int sh = hold_shift(s);
    uint8_t used = 0;
    for (int k = 0; k < HOLD_POLY; k++) {
        if (s->id[k] < 0) continue;
        int stay = -1;
        for (int j = 0; j < HOLD_POLY; j++)
            if (c->note[st][j] >= 0 && c->note[st][j] + sh == s->pitch[k] && (keep || ((c->tie[st] >> j) & 1)) &&
                !((used >> j) & 1)) { stay = j; break; }
        if (stay >= 0) used |= (uint8_t)(1u << stay);
        else { hold_note_off(s->id[k]); s->id[k] = -1; s->pitch[k] = -1; }
    }
    for (int j = 0; j < HOLD_POLY; j++) {
        int p = c->note[st][j] + sh;
        if (c->note[st][j] < 0 || ((used >> j) & 1) || p < 0 || p > 127) continue;
        for (int k = 0; k < HOLD_POLY; k++) if (s->id[k] < 0) {
            s->id[k] = (int16_t)hold_note_on(mode, p, j ? 96 : 112);
            s->pitch[k] = (int8_t)(s->id[k] >= 0 ? p : -1);
            break;
        }
    }
}

void hold_key(hold_state *s, int mode, int key, int note, int down)
{
    if ((unsigned)key >= 24) return;
    hold_config *c = &s->cfg;
    if (c->split && key < c->split) {                     /* below the break point: transpose while held */
        if (down) { s->low = (int8_t)key; s->halted = 0; } else if (s->low == key) s->low = -1;
        if (s->started) sync(s, mode, s->step, 0);
        return;
    }
    if (down) {
        int first = !s->held;
        s->halted = 0;
        s->held |= 1u << key; s->keynote[key] = (int8_t)(note < 0 ? 0 : note > 127 ? 127 : note); s->last = (uint8_t)key;
        if (s->started) { write_step(s, s->step, !first && s->recording); s->recording = 1; sync(s, mode, s->step, 1); }
    } else {
        s->held &= ~(1u << key); s->keynote[key] = -1;
        if (!s->held) s->recording = 0;
    }
}

static int step_ticks(const hold_state *s)
{
    int sw = (s->cfg.swing * 103) >> 10;                  /* swing 100 -> 10 ticks of 24, no division */
    return HOLD_TICKS + ((s->step & 1) ? -sw : sw);
}

void hold_tick(hold_state *s, int mode)
{
    hold_config *c = &s->cfg;
    int run = !s->halted && (s->held || s->low >= 0 || (c->keep && !hold_empty(s)));
    if (!run) {
        if (s->started) { hold_release(s); s->started = 0; s->step = 0; s->elapsed = 0; s->recording = 0; }
        return;
    }
    if (s->started) {
        if (++s->elapsed < step_ticks(s)) return;
        s->elapsed = 0;
        s->step = (uint8_t)(s->step + 1 >= c->length ? 0 : s->step + 1);
    } else { s->started = 1; s->step = 0; s->elapsed = 0; }
    if (s->held) { write_step(s, s->step, s->recording); s->recording = 1; }
    else s->recording = 0;
    sync(s, mode, s->step, 0);
}

int hold_serialize(const hold_state *s, int *v, int cap)
{
    const hold_config *c = &s->cfg;
    if (cap < HOLD_WORDS) return 0;
    int head[8] = { 1, c->length, c->swing, c->mono, c->keep, c->split, c->transpose + 24, 0 };
    for (int i = 0; i < 8; i++) v[i] = head[i];
    int *p = v + 8;
    for (int i = 0; i < HOLD_STEPS; i++) {
        for (int k = 0; k < HOLD_POLY; k++) *p++ = c->note[i][k] + 1;
        *p++ = c->tie[i];
    }
    return HOLD_WORDS;
}
int hold_parse(hold_state *s, const int *v, int n)
{
    if (n < HOLD_WORDS || v[0] != 1 || v[1] < 1 || v[1] > HOLD_STEPS || v[2] < 0 || v[2] > 100 || (unsigned)v[3] > 1 ||
        (unsigned)v[4] > 1 || v[5] < 0 || v[5] > 23 || v[6] < 0 || v[6] > 48) return 0;
    const int *p = v + 8;
    for (int i = 0; i < HOLD_STEPS * (HOLD_POLY + 1); i++)
        if (p[i] < 0 || p[i] > ((i % (HOLD_POLY + 1)) == HOLD_POLY ? 15 : 128)) return 0;
    hold_stop(s);
    hold_config *c = &s->cfg;
    c->length = (uint8_t)v[1]; c->swing = (uint8_t)v[2]; c->mono = (uint8_t)v[3]; c->keep = (uint8_t)v[4];
    c->split = (uint8_t)v[5]; c->transpose = (int8_t)(v[6] - 24);
    for (int i = 0; i < HOLD_STEPS; i++) {
        for (int k = 0; k < HOLD_POLY; k++) c->note[i][k] = (int8_t)(*p++ - 1);
        c->tie[i] = (uint8_t)*p++;
    }
    if (s->cursor >= c->length) s->cursor = 0;
    s->changed = 0;
    return 1;
}
