/* HOLD: a sequencer type (op1_feature_seq.h) after the OP-1 Field's HOLD. Hold keys while it runs and they become
 * the pattern's notes (several keys = a chord, one after another = a line, a key held over steps = a long note).
 * Encoders: blue cursor, green swing, white length, orange transpose. Shift: blue break point (keys below it
 * transpose the pattern while held), green mono / poly, white erases steps at the cursor, orange pattern hold (on:
 * the pattern plays on with no key down). Blue push starts or halts it, orange push clears the pattern. Synth and
 * drum keep their own pattern.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../op1_feature_seq.h"
#include "../../op1_synth.h"
#include "../../seq/seq_text.h"
#include "hold_model.h"
static hold_state bank[2];
static uint8_t loaded;
static int accum[2][8];
#ifdef OP1_HOST /* harness/hold_fc_test.c: R246's bank, Shift and keyboard octaves as host data */
extern int32_t host_bank, host_drum_oct, host_synth_oct; extern uint8_t host_shift;
#define MODE() (host_bank == 1)
#define SHIFT() (host_shift)
#define OCTAVE(m) ((m) ? host_drum_oct : host_synth_oct)
#else
#define MODE() (*(volatile int *)0x01DE4C40 == 1)
#define SHIFT() (*(volatile uint8_t *)0x01DD7F78)
#define OCTAVE(m) (((const int *)((m) ? 0x01DFE500 : 0x01DFE4E0))[*(volatile int *)((m) ? 0xFF8016D8 : 0xFF8016D4) & 7])
#endif
static int clamp(int x, int lo, int hi) { return x < lo ? lo : x > hi ? hi : x; }
/* a drum note's key is its pad under the current drum octave (kn_seq.c: midi = key + 0x35) */
int hold_note_on(int mode, int note, int vel)
{
    return op1_seq_note_on(mode, note, mode ? note - 0x35 - 12 * OCTAVE(1) : 0, vel);
}
void hold_note_off(int id) { op1_seq_note_off(id); }

static int serialize(int m, char *out, int n) { int v[HOLD_WORDS]; return sq_join(out, n, v, hold_serialize(&bank[m], v, HOLD_WORDS)); }
static int parse(int m, const char *text, int len) { int v[HOLD_WORDS]; int n = sq_split(text, len, v, HOLD_WORDS); return hold_parse(&bank[m], v, n); }
static char sql[720];
static sq_store_t store = { .name = "holdseq", .ser = serialize, .parse = parse, .sql = sql, .cap = sizeof sql, .maxlen = 560 };
static void initialize(void) { if (loaded) return; hold_init(&bank[0]); hold_init(&bank[1]); loaded = 1; sq_store_load(&store); }

static void turn(int m, int knob, int delta, int shift)
{
    if ((unsigned)m > 1 || (unsigned)knob > 3) return;
    initialize();
    hold_state *s = &bank[m]; hold_config *c = &s->cfg;
    int *a = &accum[m][knob + (shift ? 4 : 0)]; *a += delta; int d = *a / 1024; *a -= d * 1024;
    if (!d) return;
    if (!shift) {
        if (knob == 0) s->cursor = (uint8_t)clamp(s->cursor + d, 0, c->length - 1);
        if (knob == 1) c->swing = (uint8_t)clamp(c->swing + d * 5, 0, 100);
        if (knob == 2) { c->length = (uint8_t)clamp(c->length + d, 1, HOLD_STEPS);
                         if (s->cursor >= c->length) s->cursor = (uint8_t)(c->length - 1);
                         if (s->step >= c->length) s->step = (uint8_t)(c->length - 1); }
        if (knob == 3) c->transpose = (int8_t)clamp(c->transpose + d, -24, 24);
    } else {
        if (knob == 0) c->split = (uint8_t)clamp(c->split + d, 0, 23);
        if (knob == 1) c->mono = d > 0;
        if (knob == 2) for (int i = 0; i < (d < 0 ? -d : d); i++) {   /* erase where the cursor is, then move */
            hold_erase(s, s->cursor);
            s->cursor = (uint8_t)clamp(s->cursor + (d > 0 ? 1 : -1), 0, c->length - 1);
        }
        if (knob == 3) c->keep = d > 0;
    }
    s->changed = 1;
}
static void press(int m, int knob, int shift)
{
    (void)shift;
    if ((unsigned)m > 1) return;
    initialize();
    if (knob == 0) hold_play(&bank[m], bank[m].halted);
    if (knob == 3) { hold_clear(&bank[m]); hold_release(&bank[m]); op1_toast("pattern cleared"); }
}
static int down(void *self, int key)
{
    (void)self;
    if ((unsigned)key >= 24) return 0;
    uint32_t caller = OP1_SEQ_CALLER();                                 /* keyboard or USB MIDI */
    int m = MODE(); initialize();
    hold_key(&bank[m], m, key, op1_seq_key_note(m, key, OCTAVE(m), caller), 1);
    return 1;
}
static int up(void *self, int key)
{
    (void)self;
    for (int m = 0; m < 2; m++) {
        hold_state *s = &bank[m];
        if ((unsigned)key < 24 && (((s->held >> key) & 1) || s->low == key)) hold_key(s, m, key, 0, 0);
    }
    return 1;
}
static int nop(void *self) { (void)self; return 0; }
/* R246 calls the player's stop and reset on SEQ off and on every synth <-> drum switch (TRAIL's trace): notes off and
 * keys forgotten (R246 may not deliver their key_up); a playing pattern goes on when its mode is back (R246 ticks only
 * the current mode's player). STOP halts both. */
static void stop(void *self) { (void)self; hold_quiet(&bank[0]); hold_quiet(&bank[1]); }
static void reset(void *self) { (void)self; hold_quiet(&bank[MODE()]); }
static void tick(void *self, int counter) { (void)self; (void)counter; int m = MODE(); hold_tick(&bank[m], m); }
static const uintptr_t vt[16] = { 0, 0, 0, (uintptr_t)nop, 0, (uintptr_t)down, 0, (uintptr_t)up, 0, (uintptr_t)reset, 0,
                                  (uintptr_t)tick, 0, (uintptr_t)nop, 0, (uintptr_t)stop };
static struct { const uintptr_t *vt; uint32_t pad[7]; } player = { vt, { 0 } };
static void *get_player(void) { initialize(); return &player; }
static void midi_start(void) { for (int m = 0; m < 2; m++) { hold_release(&bank[m]); bank[m].started = 0; } }
static int input(const op1_input *in)
{
    if (loaded && in->type == OP1_IN_KEY && in->pressed && in->code == 0x23) { hold_stop(&bank[0]); hold_stop(&bank[1]); }
    return 0;
}
static void event(int id, int32_t arg)
{
    (void)arg;
    if (!loaded) return;
    if (id == OP1_EV_NOTES_RESET) { for (int m = 0; m < 2; m++) for (int k = 0; k < HOLD_POLY; k++) bank[m].id[k] = -1; }
    if (id == OP1_EV_SLOT) hold_release(&bank[0]);
    if (id == OP1_EV_DISK) { hold_stop(&bank[0]); hold_stop(&bank[1]); }
    if (id == OP1_EV_SERVICE) {                         /* only the main loop tells the saver (never the tick) */
        int changed = 0;
        for (int m = 0; m < 2; m++) if (bank[m].changed) { bank[m].changed = 0; changed = 1; }
        if (changed) sq_store_dirty(&store);
    }
}

/* ---- screen: the step ring (owner-approved art in the root project), drawn in code
 * on an empty SVG. 16 step positions round (160, 84), step 0 at the top, clockwise; steps past the length are left
 * out. One ring per note slot, outer to inner (mono: one): a dim track where the slot is empty, a thick arc in the
 * ring's colour over a note's steps, joined across a tie, so a note sounding through all 16 steps is a closed circle.
 * Ticks outside, the cursor's in blue; a red hand to the playing step. The centre shows the transposition (with a
 * low key held below the split, the sum) and the split note. Corners: title, play state; STEP, LEN, SWING in their
 * encoders' colours, with Shift the shifted functions in the same places. Screen memory: R246's line rasterizer
 * keeps a TE heap buffer as wide as the widest line it has drawn (lineclock.c), so every line here spans at most
 * ~16 px: arcs are chords of a quarter step (6 px at r 62, 7 with the overlap), the hand is four pieces. Integers only: a 128-entry sine
 * table, points in Q10. Bottom text ink ends at y 138 (docs/screen-art.md); the ring's bottom reaches y 147 and the
 * ticks y 157 (the cursor's), as the approved art has them. */
static const uint8_t white[4] = { 0xFF, 0xFF, 0xFF, 0xFF }, blue[4] = { 0x69, 0x8E, 0xFF, 0xFF },
    green[4] = { 0x00, 0xED, 0x95, 0xFF }, red[4] = { 0xFF, 0x3A, 0x5D, 0xFF }, pink[4] = { 0xFF, 0x6E, 0x9E, 0xFF },
    grey[4] = { 0x65, 0x65, 0x79, 0xFF }, track[4] = { 0x1D, 0x20, 0x40, 0xFF };
#define CX 160
#define CY 84
#define T_CORNER 1331                                   /* 8 px capitals */
#define T_SHIFT 2048                                    /* 12 px */
#define T_SPLIT 1536                                    /* 9 px */
static const int16_t sin128[128] = {   /* round(1024 sin(2 pi k / 128)) */
    0, 50, 100, 150, 200, 249, 297, 345, 392, 438, 483, 526, 569, 610, 650, 688,
    724, 759, 792, 822, 851, 878, 903, 926, 946, 964, 980, 993, 1004, 1013, 1019, 1023,
    1024, 1023, 1019, 1013, 1004, 993, 980, 964, 946, 926, 903, 878, 851, 822, 792, 759,
    724, 688, 650, 610, 569, 526, 483, 438, 392, 345, 297, 249, 200, 150, 100, 50,
    0, -50, -100, -150, -200, -249, -297, -345, -392, -438, -483, -526, -569, -610, -650, -688,
    -724, -759, -792, -822, -851, -878, -903, -926, -946, -964, -980, -993, -1004, -1013, -1019, -1023,
    -1024, -1023, -1019, -1013, -1004, -993, -980, -964, -946, -926, -903, -878, -851, -822, -792, -759,
    -724, -688, -650, -610, -569, -526, -483, -438, -392, -345, -297, -249, -200, -150, -100, -50 };
static void text(void *r, int x, int y, int scale, const char *s, const uint8_t *c) { sq_text(r, OP1_Q10(x), OP1_Q10(y), scale, s, scale * 3 / 4, c); }
static int width(const char *s, int scale) { int u = 0; for (; *s; s++) u += *s == '1' || *s == '.' ? 4 : 6; return u ? (u - 2) * scale / 1024 : 0; }
/* point p (0..127, 2.8125 degrees apart, 0 at the top, clockwise; a step is 8) on radius rad, in Q10 */
static int32_t px(int rad, int p) { return OP1_Q10(CX) + rad * sin128[p & 127]; }
static int32_t py(int rad, int p) { return OP1_Q10(CY) - rad * sin128[(p + 32) & 127]; }
/* step i of a ring as four chords (a 128-sided circle: smooth at 6 px, every chord about 7 px, so the rasterizer's
 * line buffer stays small). Butt caps leave a notch where two chords meet, so every chord runs 1/8 of its length on
 * past a joined end (under its neighbour); trimmed ends (a note that is not tied on) stop 3/8 of a chord, 3/32 of
 * the step, short of the edge, as before */
static void chord(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int cut0, int cut1, int32_t w, const uint8_t *c)
{
    int32_t dx = x1 - x0, dy = y1 - y0;
    if (cut0) { x0 += (dx * 3) >> 3; y0 += (dy * 3) >> 3; } else { x0 -= dx >> 3; y0 -= dy >> 3; }
    if (cut1) { x1 -= (dx * 3) >> 3; y1 -= (dy * 3) >> 3; } else { x1 += dx >> 3; y1 += dy >> 3; }
    sq_line(r, x0, y0, x1, y1, w, c);
}
static void arc(void *r, int rad, int i, int open0, int open1, int32_t w, const uint8_t *c)
{
    for (int q = 0; q < 4; q++)
        chord(r, px(rad, 8 * i + 2 * q), py(rad, 8 * i + 2 * q), px(rad, 8 * i + 2 * q + 2), py(rad, 8 * i + 2 * q + 2),
              q == 0 && open0, q == 3 && open1, w, c);
}
/* radial line at point p from radius r0 to r1 */
static void ray(void *r, int p, int r0, int r1, int32_t w, const uint8_t *c) { sq_line(r, px(r0, p), py(r0, p), px(r1, p), py(r1, p), w, c); }
/* slot k of step i continues the same note from the step before (wrapping at the length) */
static int joined(const hold_config *c, int i, int k)
{
    int prev = i ? i - 1 : c->length - 1;
    return c->note[i][k] >= 0 && ((c->tie[i] >> k) & 1) && c->note[prev][k] == c->note[i][k];
}
static void name(char *out, int note)                   /* MIDI note -> "C4", "F#3" */
{
    static const char *const n[12] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    int o = note / 12 - 1;
    char *p = sq_cat(out, n[note % 12]);
    if (o < 0) { sq_cat(p, "-1"); return; }
    sq_num(p, (uint32_t)o, 1);
}
static void signed_num(char *out, int v) { char *p = out; if (v > 0) p = sq_cat(p, "+"); if (v < 0) { p = sq_cat(p, "-"); v = -v; } sq_num(p, (uint32_t)v, 1); }
static void right(void *r, int y, const char *s, const uint8_t *c) { text(r, 310 - width(s, T_CORNER), y, T_CORNER, s, c); }
static void screen_init(void *scr) { (void)scr; }
static void screen_update(void *scr, int dt)
{
    op1_screen_draw_cached(scr, dt, 0);
    void *r = op1_raster(); int m = MODE(); initialize();
    hold_state *s = &bank[m]; hold_config *c = &s->cfg;
    int sh = SHIFT() != 0, len = c->length, rings = 1;
    if (!c->mono) {                                     /* three rings, a fourth when a step uses its fourth slot */
        rings = 3;
        for (int i = 0; i < len; i++) if (c->note[i][3] >= 0) rings = 4;
    }
    static const uint8_t *const ring_color[4] = { green, blue, white, pink };
    for (int k = 0; k < rings; k++) {
        int rad = 62 - 12 * k;
        for (int i = 0; i < len; i++) {
            if (c->note[i][k] < 0) { arc(r, rad, i, 0, 0, OP1_Q10(6), track); continue; }
            int next = i + 1 < len ? i + 1 : 0;
            arc(r, rad, i, !joined(c, i, k), !joined(c, next, k), OP1_Q10(6), ring_color[k]);
        }
    }
    for (int i = 0; i < len; i++)                       /* ticks at the step centres */
        if (i == s->cursor) ray(r, 8 * i + 4, 66, 73, OP1_Q10(2), blue);
        else ray(r, 8 * i + 4, 67, 70, 1229, grey);
    if (s->started) {                                   /* the hand, in pieces of 16 px or less, and its dot */
        int p = 8 * s->step + 4;
        for (int q = 0; q < 4; q++) ray(r, p, q * 31 / 2, (q + 1) * 31 / 2, OP1_Q10(2), red);
        sq_dot(r, px(62, p), py(62, p), OP1_Q10(8), red);
    }
    char val[24];
    signed_num(val, hold_shift(s));                     /* centre: transposition, the split note below */
    text(r, CX - width(val, T_SHIFT) / 2, c->split ? 72 : 78, T_SHIFT, val, white);
    if (c->split) { name(val, c->split + 0x35 + 12 * OCTAVE(m)); text(r, CX - width(val, T_SPLIT) / 2, 88, T_SPLIT, val, grey); }
    text(r, 10, 10, T_CORNER, "HOLD", grey);
    if (!sh) {
        right(r, 10, s->held ? "REC" : s->started ? "PLAY" : "STOP", red);
        char *p = sq_cat(val, "LEN "); sq_num(p, (uint32_t)len, 1); right(r, 115, val, white);
        p = sq_cat(val, "SWING "); sq_num(p, c->swing, 1); right(r, 129, val, green);
        p = sq_cat(val, "STEP "); sq_num(p, (uint32_t)(s->cursor + 1), 1); text(r, 10, 129, T_CORNER, val, blue);
    } else {
        right(r, 10, c->keep ? "HOLD ON" : "HOLD OFF", red);
        char *p = sq_cat(val, "ERASE "); sq_num(p, (uint32_t)(s->cursor + 1), 1); right(r, 115, val, white);
        right(r, 129, c->mono ? "MONO" : "POLY", green);
        p = sq_cat(val, "SPLIT ");
        if (c->split) name(p, c->split + 0x35 + 12 * OCTAVE(m)); else sq_cat(p, "OFF");
        text(r, 10, 129, T_CORNER, val, blue);
    }
}
const op1_screen_t SCREEN_hold = { screen_init, screen_update };
static const op1_seq_type_t type = { .name = "hold", .player = get_player, .svg = "hold.svg", .screen = &SCREEN_hold,
                                     .press = press, .turn = turn, .midi_start = midi_start };
const op1_feature_t FEATURE_hold = { .api = OP1_FEATURE_API, .priority = 1000, .name = "hold", .seq = &type,
                                     .input = input, .event = event };
