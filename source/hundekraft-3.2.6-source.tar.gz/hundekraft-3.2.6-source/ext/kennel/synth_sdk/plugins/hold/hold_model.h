/* HOLD sequencer model: a step pattern written by holding keys while it runs (after the OP-1 Field's HOLD).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HOLD_MODEL_H
#define HOLD_MODEL_H
#include <stdint.h>
#define HOLD_STEPS 16
#define HOLD_POLY 4
#define HOLD_TICKS 24                 /* 1/16 at 96 ticks per beat */
#define HOLD_WORDS (8 + HOLD_STEPS * (HOLD_POLY + 1))
typedef struct {
    uint8_t length;                   /* 1..16 steps */
    uint8_t swing;                    /* 0..100: odd steps start later */
    uint8_t mono;                     /* 1: one note per step (the last key pressed) */
    uint8_t keep;                     /* pattern hold: 1 plays on with no key down, 0 only while a key is down */
    uint8_t split;                    /* break point, keyboard index 0..23: keys below it transpose; 0 = no split */
    int8_t transpose;                 /* -24..24 semitones, added to every step */
    int8_t note[HOLD_STEPS][HOLD_POLY];   /* MIDI notes, -1 empty */
    uint8_t tie[HOLD_STEPS];          /* bit k: note k goes on from the step before (it was held across) */
} hold_config;
typedef struct {
    hold_config cfg;
    uint8_t step, cursor, started, changed, recording;
    uint8_t halted;                   /* stopped (STOP, the blue push, after loading): a key or the blue push starts it */
    uint16_t elapsed;
    uint32_t held;                    /* pattern keys down (above the split) */
    int8_t low;                       /* transposing key down (below the split), -1 none */
    uint8_t last;                     /* last pattern key pressed */
    int8_t keynote[24];               /* note each pattern key plays */
    int16_t id[HOLD_POLY];            /* notes sounding: sequencer note ids, -1 none */
    int8_t pitch[HOLD_POLY];          /* their pitch before transposition (to match a tie) */
} hold_state;
void hold_init(hold_state *s);
void hold_clear(hold_state *s);                   /* erase every step */
void hold_erase(hold_state *s, int step);
void hold_release(hold_state *s);                 /* notes off, play state kept */
void hold_stop(hold_state *s);                    /* halt: notes off, back to step 0, keys forgotten */
void hold_quiet(hold_state *s);                   /* notes off and keys forgotten, play state kept (player stop / reset) */
void hold_play(hold_state *s, int on);            /* the blue push: start or halt */
void hold_key(hold_state *s, int mode, int key, int note, int down);   /* a pattern key also writes the current step */
void hold_tick(hold_state *s, int mode);          /* 96 per beat */
int hold_shift(const hold_state *s);              /* semitones: transpose + the low key's distance from the split */
int hold_empty(const hold_state *s);
int hold_serialize(const hold_state *s, int *v, int cap);
int hold_parse(hold_state *s, const int *v, int n);
/* supplied by the player (hold.c) or a test */
int hold_note_on(int mode, int note, int vel);
void hold_note_off(int id);
#endif
