/* composer variety: how many distinct results the seeds give, per style and role (Mac only).
 *   cc -std=c11 -O2 -I.. variety.c ../composer_model.c ../composer_styles.c -o variety && ./variety [seeds]
 * Per style over seeds 1..N, section A pass 0 (and B for the progression): distinct progressions, distinct onset
 * patterns (rhythm), distinct event lists (rhythm + pitch), and for the lead distinct opening contours (the first 8
 * intervals). A low count means the seed barely changes that part.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../composer_model.h"

#define MAXS 2000
static uint32_t fnv(const void *d, size_t n, uint32_t h)
{
    const uint8_t *p = d;
    while (n--) h = (h ^ *p++) * 16777619u;
    return h;
}
static int distinct(uint32_t *v, int n)
{
    int k = 0;
    for (int i = 0; i < n; i++) {
        int seen = 0;
        for (int j = 0; j < i && !seen; j++) seen = v[j] == v[i];
        k += !seen;
    }
    return k;
}

int main(int argc, char **argv)
{
    int seeds = argc > 1 ? atoi(argv[1]) : 300;
    if (seeds > MAXS) seeds = MAXS;
    static uint32_t prog[MAXS], progb[MAXS], on[CM_ROLES][MAXS], all[CM_ROLES][MAXS], contour[MAXS];
    static cm_event ev[CM_MAX_EVENTS];
    printf("%-15s %5s %5s | %-11s %-11s %-11s %-11s | %s\n", "style", "progA", "progB", "lead r/all", "bass r/all",
           "arp r/all", "chords r/all", "lead contour");
    for (int st = 0; st < cm_nstyles; st++) {
        for (int s = 0; s < seeds; s++) {
            cm_config c; cm_plan p, q;
            cm_default(&c, st, (uint32_t)s + 1);
            cm_plan_section(&p, &c, 0); cm_plan_section(&q, &c, 1);
            prog[s] = fnv(p.chord, sizeof p.chord[0] * p.nchord, fnv(p.at, sizeof p.at, 2166136261u));
            progb[s] = fnv(q.chord, sizeof q.chord[0] * q.nchord, fnv(q.at, sizeof q.at, 2166136261u));
            for (int r = 0; r < CM_ROLES; r++) {
                int n = cm_compose(&p, &c, r, 0, ev, CM_MAX_EVENTS);
                uint32_t h = 2166136261u, a = 2166136261u;
                for (int i = 0; i < n; i++) { h = fnv(&ev[i].tick, 2, h); a = fnv(&ev[i], sizeof ev[i], a); }
                on[r][s] = h; all[r][s] = a;
                if (r == CM_LEAD) {
                    int8_t iv[8] = {0};
                    for (int i = 1; i < n && i <= 8; i++) iv[i - 1] = (int8_t)(ev[i].note - ev[i - 1].note);
                    contour[s] = fnv(iv, sizeof iv, 2166136261u);
                }
            }
        }
        printf("%-15s %5d %5d |", cm_styles[st].name, distinct(prog, seeds), distinct(progb, seeds));
        for (int r = 0; r < CM_ROLES; r++) printf(" %4d/%-6d", distinct(on[r], seeds), distinct(all[r], seeds));
        printf(" | %d\n", distinct(contour, seeds));
    }
    printf("(%d seeds, default settings)\n", seeds);
    return 0;
}
