/* composer: style tables, first batch (house/techno/trance, synthwave/pop, lo-fi/city pop, ambient/IDM).
 * Progressions: chord root in semitones above the key, quality, beats. Values are starting points to tune by ear
 * (docs/melody-sequencer-design-2026-10-31.md in the full project).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "composer_model.h"

#define END {0, 0, 0}
#define N(a) (uint8_t)(sizeof(a) / sizeof(a[0]))

/* deep house: Dorian, minor 9ths, syncopated stabs */
static const cm_chord dh1[] = {{0, Q_MIN9, 8}, {5, Q_MIN9, 8}, END};
static const cm_chord dh2[] = {{0, Q_MIN9, 4}, {10, Q_MAJ7, 4}, {8, Q_MAJ7, 4}, {7, Q_MIN7, 4}, END};
static const cm_chord dh3[] = {{0, Q_MIN11, 4}, {3, Q_MAJ7, 4}, {8, Q_MAJ7, 4}, {10, Q_7SUS, 4}, END};
static const cm_chord dh4[] = {{0, Q_MIN9, 4}, {8, Q_MAJ9, 4}, {3, Q_MAJ9, 4}, {10, Q_ADD9, 4}, END};
static const cm_chord *const dh_prog[] = {dh1, dh2, dh3, dh4};
static const uint8_t dh_form[] = {F_AAAB, F_LOOP, F_PERIOD};
static const char *const dh_lead[] = {
    "x-.x" "-.x-" "--.." "...." "x-.x" "-.x-" "x---" "....",
    "..x-" "..x-" ".x--" "...." "..x-" "..x-" "x---" "--..",
    "x--." "x-.x" "----" "...." "..x." "x-.x" "----" "...."};
static const char *const dh_bass[] = {"x.....x." "x....xx.", "x..x..x." "..x..x..", "..x...x." "..x...x."};
static const char *const dh_chords[] = {"..x...x." ".x....x.", "...x..x." "...x.x.."};

/* melodic techno: Aeolian, long lead notes over a rolling bass */
static const cm_chord mt1[] = {{0, Q_MIN, 4}, {8, Q_MAJ, 4}, {3, Q_MAJ, 4}, {10, Q_MAJ, 4}, END};
static const cm_chord mt2[] = {{0, Q_MIN, 4}, {10, Q_MAJ, 4}, {8, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord mt3[] = {{0, Q_MIN7, 8}, {8, Q_MAJ7, 8}, END};
static const cm_chord mt4[] = {{0, Q_MIN, 4}, {5, Q_MIN, 4}, {8, Q_MAJ, 4}, {7, Q_MIN, 4}, END};
static const cm_chord *const mt_prog[] = {mt1, mt2, mt3, mt4};
static const uint8_t mt_form[] = {F_AAAB, F_LOOP, F_SENTENCE};
static const char *const mt_lead[] = {
    "x---" "----" "x---" "--x-" "x---" "----" "x---" "....",
    "x--x" "--x-" "x---" "...." "x--x" "--x-" "x---" "----",
    "x-x-" "x-x-" "x---" "x---" "x-x-" "x-x-" "x---" "...."};
static const char *const mt_bass[] = {".xxx" ".xxx" ".xxx" ".xxx", "..x." "..x." "..x." "..x.", ".xx." ".xx." ".xx." ".x.x"};
static const char *const mt_chords[] = {"x---" "----" "----" "----"};

/* trance: Aeolian with a major V, 3-3-2 riffs, offbeat bass */
static const cm_chord tr1[] = {{0, Q_MIN, 4}, {8, Q_MAJ, 4}, {3, Q_MAJ, 4}, {10, Q_MAJ, 4}, END};
static const cm_chord tr2[] = {{0, Q_MIN, 4}, {8, Q_MAJ, 4}, {5, Q_MIN, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord tr3[] = {{8, Q_MAJ, 4}, {10, Q_MAJ, 4}, {0, Q_MIN, 8}, END};
static const cm_chord tr4[] = {{0, Q_MIN, 4}, {3, Q_MAJ, 4}, {10, Q_MAJ, 4}, {8, Q_MAJ, 4}, END};
static const cm_chord *const tr_prog[] = {tr1, tr2, tr3, tr4};
static const uint8_t tr_form[] = {F_AAAB, F_SENTENCE, F_PERIOD};
static const char *const tr_lead[] = {
    "x--x" "--x-" "x--x" "--x-" "x--x" "--x-" "x---" "x-x-",
    "x-xx" "-xx-" "x-xx" "-x.." "x-xx" "-xx-" "x---" "----",
    "x--x" "--x-" "--x-" "x-x-" "x--x" "--x-" "x---" "----"};
static const char *const tr_bass[] = {"..x." "..x." "..x." "..x.", ".xxx" ".xxx" ".xxx" ".xxx"};
static const char *const tr_chords[] = {"x---" "----" "----" "----", "..x-" "..x-" "..x-" "..x-"};

/* synthwave: Aeolian, driving 8ths, held b7 over i */
static const cm_chord sw1[] = {{8, Q_MAJ, 4}, {10, Q_MAJ, 4}, {0, Q_MIN, 8}, END};
static const cm_chord sw2[] = {{0, Q_MIN, 4}, {8, Q_MAJ, 4}, {3, Q_MAJ, 4}, {10, Q_MAJ, 4}, END};
static const cm_chord sw3[] = {{0, Q_MIN, 4}, {10, Q_MAJ, 4}, {8, Q_MAJ, 4}, {10, Q_MAJ, 4}, END};
static const cm_chord sw4[] = {{0, Q_MIN, 4}, {5, Q_MIN, 4}, {8, Q_MAJ, 4}, {10, Q_SUS4, 2}, {10, Q_MAJ, 2}, END};
static const cm_chord *const sw_prog[] = {sw1, sw2, sw3, sw4};
static const uint8_t sw_form[] = {F_AABA, F_PERIOD, F_SENTENCE};
static const char *const sw_lead[] = {
    "x---" "--x-" "x---" "x-x-" "x---" "----" "----" "....",
    "x-x-" "x---" "--x-" "x---" "x-x-" "x---" "x---" "....",
    "..x-" "x-x-" "x---" "--x-" "x---" "----" "x-x-" "...."};
static const char *const sw_bass[] = {"x.x." "x.x." "x.x." "x.x.", "x.xx" "x.xx" "x.xx" "x.xx", "xxxx" "xxxx" "xxxx" "xxxx"};
static const char *const sw_chords[] = {"x---" "----" "----" "----"};

/* pop: Ionian, I V vi IV family, anticipated downbeats */
static const cm_chord pp1[] = {{0, Q_MAJ, 4}, {7, Q_MAJ, 4}, {9, Q_MIN, 4}, {5, Q_MAJ, 4}, END};
static const cm_chord pp2[] = {{9, Q_MIN, 4}, {5, Q_MAJ, 4}, {0, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord pp3[] = {{0, Q_ADD9, 4}, {9, Q_MIN7, 4}, {5, Q_MAJ7, 4}, {7, Q_SUS4, 2}, {7, Q_MAJ, 2}, END};
static const cm_chord pp4[] = {{5, Q_MAJ, 4}, {0, Q_MAJ, 4}, {7, Q_MAJ, 4}, {9, Q_MIN, 4}, END};
static const cm_chord *const pp_prog[] = {pp1, pp2, pp3, pp4};
static const uint8_t pp_form[] = {F_PERIOD, F_AABA, F_SENTENCE};
static const char *const pp_lead[] = {
    "x-x-" "x-.x" "--x-" "...." "x-x-" "x-.x" "----" "....",
    "..xx" "x-x-" "x--x" "...." "..xx" "x-x-" "x---" "--..",
    "x.xx" ".x-." "x-x-" "--.." "x.xx" ".x-." "x---" "...."};
static const char *const pp_bass[] = {"x..." "..x." "x..." "..x.", "x..." "x..." "x..." "x.x."};
static const char *const pp_chords[] = {"x---" "..x-" "x---" "..x-", "x-.." "x-.x" "-.x." "x-.."};

/* lo-fi / jazz-hop: ii V I, 9ths, heavy swing */
static const cm_chord lf1[] = {{2, Q_MIN9, 4}, {7, Q_DOM9, 4}, {0, Q_MAJ9, 4}, {9, Q_MIN7, 4}, END};
static const cm_chord lf2[] = {{0, Q_MAJ7, 4}, {4, Q_MIN7, 4}, {9, Q_MIN7, 4}, {2, Q_MIN7, 2}, {7, Q_DOM7, 2}, END};
static const cm_chord lf3[] = {{5, Q_MAJ7, 4}, {4, Q_MIN7, 4}, {2, Q_MIN7, 4}, {0, Q_MAJ9, 4}, END};
static const cm_chord lf4[] = {{2, Q_MIN9, 8}, {0, Q_MAJ9, 8}, END};
static const cm_chord *const lf_prog[] = {lf1, lf2, lf3, lf4};
static const uint8_t lf_form[] = {F_LOOP, F_PERIOD, F_AAAB};
static const char *const lf_lead[] = {
    "x--." "..x-" "x-.." "...." "x--." "..x." "x---" "....",
    "..x." "x.x-" "--.." ".x.." "..x." "x.x-" "----" "....",
    "x.x." "x--." "..x-" "...." "x.x." "x---" "----" "...."};
static const char *const lf_bass[] = {"x--." "..x." "x-.." ".x..", "x--." "..x-" "..x-" "...."};
static const char *const lf_chords[] = {"x---" "-..." "..x-" "-...", "x---" "----" "..x-" "----"};

/* city pop: Ionian with 9ths and secondary dominants, pushed changes */
static const cm_chord cp1[] = {{5, Q_MAJ7, 4}, {4, Q_DOM7, 4}, {9, Q_MIN7, 2}, {7, Q_MIN7, 1}, {0, Q_DOM7, 1}, END};
static const cm_chord cp2[] = {{0, Q_MAJ7, 4}, {5, Q_MAJ7, 4}, {4, Q_MIN7, 4}, {9, Q_MIN7, 4}, END};
static const cm_chord cp3[] = {{2, Q_MIN7, 4}, {7, Q_7SUS, 4}, {0, Q_MAJ9, 8}, END};
static const cm_chord cp4[] = {{5, Q_MAJ9, 4}, {7, Q_DOM9, 4}, {4, Q_MIN7, 4}, {9, Q_MIN9, 4}, END};
static const cm_chord *const cp_prog[] = {cp1, cp2, cp3, cp4};
static const uint8_t cp_form[] = {F_PERIOD, F_SENTENCE, F_AABA};
static const char *const cp_lead[] = {
    "x-x." "x-x-" "--x." "x-.." "x-x." "x-x-" "x---" "....",
    "..x-" "x-x." "x-x-" "--.." "..x-" "x-x." "x---" "--..",
    "x.xx" "-.x-" "x--." "...." "x.xx" "-.x-" "x---" "...."};
static const char *const cp_bass[] = {"x.x." "..xx" "..x." "x.x.", "x..x" "..x." "x.x." ".x.x"};
static const char *const cp_chords[] = {"x-.." "x-.x" "..x-" ".x..", "x--." ".x.." "x--." ".x.."};

/* ambient: Lydian, long tones, colour tones need no resolution */
static const cm_chord am1[] = {{0, Q_MAJ7, 8}, {2, Q_MAJ, 8}, END};
static const cm_chord am2[] = {{0, Q_SUS2, 8}, {7, Q_SUS2, 8}, END};
static const cm_chord am3[] = {{0, Q_MAJ9, 8}, {9, Q_MIN7, 8}, {4, Q_MIN7, 8}, {2, Q_MAJ, 8}, END};
static const cm_chord *const am_prog[] = {am1, am2, am3};
static const uint8_t am_form[] = {F_PERIOD, F_AABA};
static const char *const am_lead[] = {
    "x---" "----" "----" "...." "..x-" "----" "x---" "----",
    "...." "x---" "----" "--x-" "----" "----" "...." "....",
    "x---" "----" "x---" "----" "x---" "----" "----" "...."};
static const char *const am_bass[] = {"x---" "----" "----" "----"};
static const char *const am_chords[] = {"x---" "----" "----" "----"};

/* IDM / BoC: Dorian, minor-major and mediant colours, broken rhythms */
static const cm_chord id1[] = {{0, Q_MIN9, 8}, {8, Q_MAJ7, 8}, END};
static const cm_chord id2[] = {{0, Q_MMAJ7, 8}, {10, Q_MAJ, 8}, END};
static const cm_chord id3[] = {{0, Q_MIN9, 4}, {3, Q_MAJ7, 4}, {10, Q_ADD9, 4}, {5, Q_MIN7, 4}, END};
static const cm_chord *const id_prog[] = {id1, id2, id3};
static const uint8_t id_form[] = {F_SENTENCE, F_AAAB, F_LOOP};
static const char *const id_lead[] = {
    "x..x" ".x.." "x--." "...." "x..x" ".x.." "x.x-" "....",
    "x-.x" "x..." ".x-x" "...." "x-.x" "x..." "x---" "....",
    "..x." "x..x" "..x." "x---" "..x." "x..x" "x---" "...."};
static const char *const id_bass[] = {"x..." "x..x" "..x." "....", "x..x" "...." "x.x." "...x"};
static const char *const id_chords[] = {"x---" "----" "x---" "----"};

/* the 2026-11-03 groups: their cells and progressions (each file also defines its rows' arrays) */
#include "styles_club.inc"
#include "styles_urban.inc"
#include "styles_jazz.inc"
#include "styles_screen.inc"
#include "styles_classical.inc"

#define STYLE(nm, bpm, key, mode, swing, pre, arp, pat, lm, bl, cm, g0, g1, g2, g3, col, fc, push, leap, bo, bf, bs, ba, bg, ac, song, names) \
    {nm, bpm, key, mode, swing, pre##_prog, N(pre##_prog), pre##_form, N(pre##_form), pre##_lead, N(pre##_lead),        \
     pre##_bass, N(pre##_bass), pre##_chords, N(pre##_chords), arp, pat, lm, bl, cm, {g0, g1, g2, g3}, col, fc, push,    \
     leap, bo, bf, bs, ba, bg, ac, song, names, 0}
/* a style whose lead is also played as a canon: `canon` bars later, an octave lower */
#define STYLE_C(nm, bpm, key, mode, swing, pre, arp, pat, lm, bl, cm, g0, g1, g2, g3, col, fc, push, leap, bo, bf, bs, ba, bg, ac, song, names, canon) \
    {nm, bpm, key, mode, swing, pre##_prog, N(pre##_prog), pre##_form, N(pre##_form), pre##_lead, N(pre##_lead),        \
     pre##_bass, N(pre##_bass), pre##_chords, N(pre##_chords), arp, pat, lm, bl, cm, {g0, g1, g2, g3}, col, fc, push,    \
     leap, bo, bf, bs, ba, bg, ac, song, names, canon}

const cm_style cm_styles[] = {
    STYLE("deep house", 122, 9, M_DOR, 56, dh, "x.x.x.x.x.x.x.x.", ARP_UPDOWN, 72, 33, 62, 85, 60, 50, 45, 3, 0, 30, 1, 30, 10, 15, 30, 0, 0, "AABBCABB", CM_DROP | CM_BREAK),
    STYLE("melodic techno", 124, 2, M_AEO, 50, mt, "xxxxxxxxxxxxxxxx", ARP_UP, 74, 28, 62, 95, 55, 45, 100, 2, 0, 0, 2, 10, 5, 0, 5, 0, 0, "AABBCBB", CM_DROP | CM_BREAK),
    STYLE("trance", 138, 9, M_AEO, 50, tr, "xxxxxxxxxxxxxxxx", ARP_PUMP, 76, 33, 64, 80, 50, 60, 100, 1, 0, 0, 3, 40, 5, 0, 0, 0, 0, "AABCBB", CM_DROP | CM_BREAK),
    STYLE("synthwave", 104, 4, M_AEO, 50, sw, "xxxxxxxxxxxxxxxx", ARP_UPDOWN, 74, 28, 62, 90, 70, 55, 100, 2, 0, 10, 2, 35, 10, 0, 10, 0, 0, "ABABCB", 0),
    STYLE("pop", 112, 0, M_ION, 50, pp, "x.x.x.x.x.x.x.x.", ARP_UP, 72, 33, 62, 85, 65, 50, 80, 1, 0, 35, 2, 20, 25, 0, 25, 0, 0, "AABABCBB", 0),
    STYLE("lo-fi", 82, 5, M_ION, 62, lf, "x..x..x.x..x..x.", ARP_UP, 72, 29, 60, 75, 70, 50, 85, 4, 1, 25, 1, 10, 25, 15, 35, 10, 0, "AABA", 0),
    STYLE("city pop", 108, 3, M_ION, 54, cp, "x.xx.x.xx.x.x.xx", ARP_ALBERTI, 74, 31, 62, 80, 55, 50, 60, 3, 1, 45, 3, 30, 15, 15, 40, 10, 0, "AABABCB", 0),
    STYLE("ambient", 70, 2, M_LYD, 50, am, "x...x...x...x...", ARP_UP, 76, 31, 60, 100, 100, 100, 100, 4, 1, 0, 2, 0, 15, 0, 0, 0, 0, "ABAC", 0),
    STYLE("idm", 96, 4, M_DOR, 56, id, "x.xxx..x.xx.x..x", ARP_CONVERGE, 74, 28, 60, 70, 60, 40, 95, 3, 1, 15, 3, 25, 20, 15, 15, 15, 0, "AABACB", CM_DROP | CM_BREAK),
    /* append only: the style index is saved with the song (composerseq), so a style never moves */
#include "styles_club_rows.inc"
#include "styles_urban_rows.inc"
#include "styles_jazz_rows.inc"
#include "styles_screen_rows.inc"
#include "styles_classical_rows.inc"
};
const int cm_nstyles = N(cm_styles);

const char *cm_section_name(int style, int section)
{
    static const char *const name[5] = {"VERSE", "CHORUS", "BRIDGE", "DROP", "BREAK"};
    int f = style >= 0 && style < cm_nstyles ? cm_styles[style].names : 0;
    if (section == 1 && f & CM_DROP) return name[3];
    if (section == 2 && f & CM_BREAK) return name[4];
    return name[section >= 0 && section <= 2 ? section : 0];
}
