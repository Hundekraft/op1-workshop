/* composer: Mac-side renderer for listening (not part of the plugin). Composes N sections of every role from one
 * song plan and writes, per style: <style>-<seed>.mid (one track per role + drums), <style>-<seed>.wav (lead, bass,
 * chords, drums) and <style>-<seed>-arp.wav (arp, bass, chords, drums), and prints musical statistics.
 * Build: cc -O2 -std=c11 -Wall -Wextra -I.. render.c ../composer_model.c ../composer_styles.c -lm -o render
 * Run:   ./render -o OUTDIR [-s STYLE|all] [-n SEED] [-p PASSES] [-m 0 loop | 1 song form (default) | 2 B | 3 C]
 * In song form each 8-bar pass is its section (A, B, C) with the section's plan; drums drop the kick in C.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "composer_model.h"

#define SR 44100
#define MAXN 4096
typedef struct { int tick, len, note, vel; } note;
typedef struct { note n[MAXN]; int count; } track;
/* the song being rendered: one plan per section, the section of each pass */
static cm_plan plans[3];
static uint8_t secs[64];
static const cm_plan *plan_at(int tick) { return &plans[secs[(tick / CM_SECTION_TICKS) & 63]]; }

/* ---- drums per style (host only): kick, snare, closed hat, open hat ---- */
static const char *drums[][4] = {
    {"x...x...x...x...", "....x.......x...", "x.x.x.x.x.x.x.x.", "..x...x...x...x."},
    {"x...x...x...x...", "....x.......x...", "xxxxxxxxxxxxxxxx", "..x...x...x...x."},
    {"x...x...x...x...", "....x.......x...", "xxxxxxxxxxxxxxxx", "..x...x...x...x."},
    {"x.......x.......", "....x.......x...", "x.x.x.x.x.x.x.x.", "................"},
    {"x.....x.x.......", "....x.......x...", "x.x.x.x.x.x.x.x.", "................"},
    {"x.....x...x.....", "....x.......x...", "x.x.x.x.x.x.x.x.", "................"},
    {"x.....x.x.....x.", "....x.......x...", "xxxxxxxxxxxxxxxx", "................"},
    {"................", "................", "................", "................"},
    {"x..x....x.x.....", "....x..x....x...", "x.xxx.x.x.xx.x.x", "................"},
#include "drums_club.inc"
#include "drums_urban.inc"
#include "drums_jazz.inc"
#include "drums_screen.inc"
};

/* ---- MIDI ---- */
static void put32(FILE *f, uint32_t v) { fputc(v >> 24, f); fputc(v >> 16 & 255, f); fputc(v >> 8 & 255, f); fputc(v & 255, f); }
static void putvar(unsigned char *b, int *o, uint32_t v)
{
    unsigned char t[5]; int n = 0;
    do { t[n++] = v & 127; v >>= 7; } while (v);
    while (n--) b[(*o)++] = (unsigned char)(t[n] | (n ? 128 : 0));
}
typedef struct { int t, on, note, vel; } mev;
static int mcmp(const void *a, const void *b)
{
    const mev *x = a, *y = b;
    return x->t != y->t ? x->t - y->t : x->on - y->on;
}
static void midi_track(FILE *f, const track *tr, int ch, int bpm)
{
    static mev ev[2 * MAXN]; static unsigned char buf[16 * MAXN + 64];
    int n = 0, o = 0, last = 0;
    for (int i = 0; i < tr->count; i++) {
        ev[n++] = (mev){tr->n[i].tick, 1, tr->n[i].note, tr->n[i].vel};
        ev[n++] = (mev){tr->n[i].tick + tr->n[i].len, 0, tr->n[i].note, 0};
    }
    qsort(ev, n, sizeof ev[0], mcmp);
    if (bpm) { uint32_t us = 60000000u / bpm; buf[o++] = 0; buf[o++] = 0xFF; buf[o++] = 0x51; buf[o++] = 3; buf[o++] = us >> 16; buf[o++] = us >> 8 & 255; buf[o++] = us & 255; }
    for (int i = 0; i < n; i++) {
        putvar(buf, &o, (uint32_t)(ev[i].t - last)); last = ev[i].t;
        buf[o++] = (unsigned char)((ev[i].on ? 0x90 : 0x80) | ch); buf[o++] = (unsigned char)ev[i].note; buf[o++] = (unsigned char)(ev[i].on ? ev[i].vel : 64);
    }
    buf[o++] = 0; buf[o++] = 0xFF; buf[o++] = 0x2F; buf[o++] = 0;
    fwrite("MTrk", 1, 4, f); put32(f, (uint32_t)o); fwrite(buf, 1, (size_t)o, f);
}

/* ---- a small synth ---- */
typedef struct { int role, note, on, off; float vel, ph[3], lp1, lp2, bp1, bp2; } voice;
static float noise(uint32_t *s) { *s = *s * 1664525u + 1013904223u; return (float)(int32_t)*s / 2147483648.0f; }
static float saw(float *ph, float inc) { *ph += inc; if (*ph >= 1) *ph -= 1; return 2 * *ph - 1; }
static float adsr(float t, float rel_t, float a, float d, float s, float r)
{
    float e = t < a ? t / a : s + (1 - s) * expf(-(t - a) / d);
    if (rel_t >= 0) e *= expf(-rel_t / r);
    return e;
}
static float hz(int n) { return 440.0f * powf(2.0f, (n - 69) / 12.0f); }

typedef struct { float *buf; int len, pos; float fb; } comb;
static float comb_run(comb *c, float x) { float y = c->buf[c->pos]; c->buf[c->pos] = x + y * c->fb; c->pos = (c->pos + 1) % c->len; return y; }

static void render(const char *path, track *roles, int nroles, const int *which, int nwhich, int style, int bars)
{
    const cm_style *st = &cm_styles[style];
    double spt = SR * 60.0 / (st->bpm * 96.0);
    int total = (int)(bars * 384 * spt) + SR * 3;
    float *L = calloc((size_t)total, sizeof(float)), *R = calloc((size_t)total, sizeof(float));
    float *send = calloc((size_t)total, sizeof(float));
    (void)nroles;
    for (int w = 0; w < nwhich; w++) {
        const track *tr = &roles[which[w]];
        int role = which[w];
        for (int i = 0; i < tr->count; i++) {
            const note *nt = &tr->n[i];
            int start = (int)(nt->tick * spt), dur = (int)(nt->len * spt);
            float rel = role == CM_CHORDS ? 0.35f : role == CM_LEAD ? 0.18f : role == CM_ARP ? 0.12f : 0.06f;
            int end = start + dur + (int)(rel * 5 * SR);
            if (end > total) end = total;
            voice v = {0}; v.vel = nt->vel / 127.0f;
            float f = hz(nt->note), pan = role == CM_CHORDS ? ((nt->note & 1) ? 0.3f : 0.7f) : role == CM_ARP ? 0.62f : 0.5f;
            for (int s = start; s < end; s++) {
                float t = (float)(s - start) / SR, rt = s >= start + dur ? (float)(s - start - dur) / SR : -1, x = 0, e;
                switch (role) {
                case CM_LEAD: {
                    float vib = t > 0.25f ? 1 + 0.003f * sinf(2 * 3.14159f * 5.2f * t) : 1;
                    e = adsr(t, rt, 0.004f, 0.25f, 0.7f, rel);
                    x = 0.5f * saw(&v.ph[0], f * vib * 1.0035f / SR) + 0.5f * saw(&v.ph[1], f * vib * 0.9965f / SR);
                    float cut = (700 + 4200 * e * v.vel) / SR * 6.28f; if (cut > 0.9f) cut = 0.9f;
                    v.lp1 += cut * (x - v.lp1); v.lp2 += cut * (v.lp1 - v.lp2); x = v.lp2 * e * 0.30f;
                    break;
                }
                case CM_BASS: {
                    e = adsr(t, rt, 0.002f, 0.18f, 0.75f, rel);
                    float env2 = expf(-t / 0.09f);
                    x = 0.6f * saw(&v.ph[0], f / SR) + 0.8f * sinf(6.28318f * (v.ph[1] += f / SR));
                    float cut = (180 + 1400 * env2 * v.vel) / SR * 6.28f;
                    v.lp1 += cut * (x - v.lp1); v.lp2 += cut * (v.lp1 - v.lp2); x = v.lp2 * e * 0.42f;
                    break;
                }
                case CM_CHORDS: {
                    e = adsr(t, rt, 0.02f, 0.5f, 0.6f, rel);
                    x = saw(&v.ph[0], f * 1.004f / SR) + saw(&v.ph[1], f * 0.996f / SR) + saw(&v.ph[2], f / SR);
                    float cut = 1600.0f / SR * 6.28f;
                    v.lp1 += cut * (x - v.lp1); v.lp2 += cut * (v.lp1 - v.lp2); x = v.lp2 * e * 0.07f * (0.6f + 0.4f * v.vel);
                    break;
                }
                default: {
                    e = adsr(t, rt, 0.002f, 0.16f, 0.15f, rel);
                    v.ph[0] += f / SR; if (v.ph[0] >= 1) v.ph[0] -= 1;
                    x = v.ph[0] < 0.3f ? 1 : -1;
                    float cut = (900 + 3000 * e) / SR * 6.28f;
                    v.lp1 += cut * (x - v.lp1); x = v.lp1 * e * 0.16f * v.vel;
                    break;
                }
                }
                L[s] += x * (1 - pan) * 2 * 0.7f; R[s] += x * pan * 2 * 0.7f;
                send[s] += x * (role == CM_BASS ? 0.05f : role == CM_LEAD ? 0.35f : 0.25f);
            }
        }
    }
    /* drums */
    uint32_t ns = 1;
    for (int b = 0; b < bars; b++)
        for (int k = 0; k < 16; k++)
            for (int lane = 0; lane < 4; lane++) {
                if (drums[style][lane][k] != 'x' || (secs[(b / CM_BARS) & 63] == 2 && lane != 2)) continue;
                double tick = (b * 16 + k) * 24 + ((k & 1) ? (st->swing - 50) * 48 / 100.0 : 0);
                int start = (int)(tick * spt), len = lane == 0 ? SR / 3 : lane == 1 ? SR / 4 : lane == 2 ? SR / 20 : SR / 5;
                float hp = 0, bp1 = 0, bp2 = 0, ph = 0;
                for (int s = start; s < start + len && s < total; s++) {
                    float t = (float)(s - start) / SR, x;
                    if (lane == 0) { ph += (48 + 110 * expf(-t / 0.035f)) / SR; x = sinf(6.28318f * ph) * expf(-t / 0.18f) * 0.9f; }
                    else if (lane == 1) {
                        float nz = noise(&ns); bp1 += 0.25f * (nz - bp1 - bp2 * 0.3f); bp2 += 0.25f * bp1;
                        x = (bp1 * 0.9f + 0.3f * sinf(6.28318f * 190 * t)) * expf(-t / 0.08f) * 0.5f;
                    } else { float nz = noise(&ns); hp = 0.6f * (hp + nz) - nz * 0.6f; hp = nz - hp; x = hp * expf(-t / (lane == 2 ? 0.012f : 0.09f)) * 0.08f; }
                    L[s] += x; R[s] += x; send[s] += x * (lane == 1 ? 0.2f : 0.02f);
                }
            }
    /* reverb: four combs and two allpasses per side */
    static const int cl[8] = {1557, 1617, 1491, 1422, 1580, 1640, 1514, 1445};
    comb cb[8];
    for (int i = 0; i < 8; i++) { cb[i].len = cl[i]; cb[i].pos = 0; cb[i].fb = 0.84f; cb[i].buf = calloc((size_t)cl[i], sizeof(float)); }
    float ap[2][2][600] = {{{0}}}; int app[2][2] = {{0}}; const int al[2] = {556, 441};
    float lpL = 0, lpR = 0;
    for (int s = 0; s < total; s++) {
        float in = send[s] * 0.25f, yl = 0, yr = 0;
        for (int i = 0; i < 4; i++) { yl += comb_run(&cb[i], in); yr += comb_run(&cb[i + 4], in); }
        for (int k = 0; k < 2; k++) {
            float *y = k ? &yr : &yl;
            for (int a = 0; a < 2; a++) {
                float bo = ap[k][a][app[k][a]], o = -*y + bo;
                ap[k][a][app[k][a]] = *y + bo * 0.5f; app[k][a] = (app[k][a] + 1) % al[a]; *y = o;
            }
        }
        lpL += 0.3f * (yl - lpL); lpR += 0.3f * (yr - lpR);
        L[s] += lpL * 0.6f; R[s] += lpR * 0.6f;
    }
    float peak = 1e-6f;
    for (int s = 0; s < total; s++) { L[s] = tanhf(L[s]); R[s] = tanhf(R[s]); if (fabsf(L[s]) > peak) peak = fabsf(L[s]); if (fabsf(R[s]) > peak) peak = fabsf(R[s]); }
    float g = 0.89f / peak;
    FILE *f = fopen(path, "wb");
    if (!f) { perror(path); exit(1); }
    uint32_t bytes = (uint32_t)total * 4;
    fwrite("RIFF", 1, 4, f); uint32_t v = 36 + bytes; fwrite(&v, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f);
    v = 16; fwrite(&v, 4, 1, f); uint16_t h = 1; fwrite(&h, 2, 1, f); h = 2; fwrite(&h, 2, 1, f);
    v = SR; fwrite(&v, 4, 1, f); v = SR * 4; fwrite(&v, 4, 1, f); h = 4; fwrite(&h, 2, 1, f); h = 16; fwrite(&h, 2, 1, f);
    fwrite("data", 1, 4, f); fwrite(&bytes, 4, 1, f);
    for (int s = 0; s < total; s++) { int16_t a = (int16_t)(L[s] * g * 32767), b = (int16_t)(R[s] * g * 32767); fwrite(&a, 2, 1, f); fwrite(&b, 2, 1, f); }
    fclose(f);
    for (int i = 0; i < 8; i++) free(cb[i].buf);
    free(L); free(R); free(send);
}

/* ---- statistics ---- */
static void stats(const char *name, const cm_config *c, const track *t)
{
    const track *ld = &t[CM_LEAD], *bs = &t[CM_BASS];
    int strong = 0, strong_ct = 0, all_ct = 0, hist[5] = {0}, lo = 128, hi = 0, run = 1, maxrun = 1, leaps = 0, rev = 0;
    for (int i = 0; i < ld->count; i++) {
        const cm_plan *p = plan_at(ld->n[i].tick);
        int step = (ld->n[i].tick / CM_TICKS) % CM_STEPS, ci = p->at[step], pc = (ld->n[i].note - c->key + 120) % 12;
        int ct = (cm_chord_tones(p, ci) >> pc) & 1, col = (cm_chord_colour(p, ci) >> pc) & 1;
        if (!(step & 3)) { strong++; strong_ct += ct; }
        all_ct += ct || col;
        if (ld->n[i].note < lo) lo = ld->n[i].note;
        if (ld->n[i].note > hi) hi = ld->n[i].note;
        if (i) {
            int iv = ld->n[i].note - ld->n[i - 1].note, a = abs(iv);
            hist[a == 0 ? 0 : a <= 2 ? 1 : a <= 4 ? 2 : a <= 7 ? 3 : 4]++;
            if (a == 0) { if (++run > maxrun) maxrun = run; } else run = 1;
            if (a >= 5 && i + 1 < ld->count) { leaps++; int nx = ld->n[i + 1].note - ld->n[i].note; rev += (nx > 0) != (iv > 0) && nx != 0; }
        }
    }
    int roots = 0, changes = 0;
    for (int i = 0; i < bs->count; i++) {
        const cm_plan *p = plan_at(bs->n[i].tick);
        int step = (bs->n[i].tick / CM_TICKS) % CM_STEPS;
        if (step == 0 || p->at[step] != p->at[step - 1]) { changes++; roots += (bs->n[i].note - c->key - p->chord[p->at[step]].root + 120) % 12 == 0; }
    }
    int iv = ld->count > 1 ? ld->count - 1 : 1;
    printf("%-15s lead %3d notes, strong-beat chord tones %3d%%, chord+colour %3d%%, intervals rep/step/3rd/4-5th/leap %d/%d/%d/%d/%d%%, "
           "range %d st, max repeat %d, leap reversal %d/%d | bass root on change %d/%d | events arp %d chords %d\n",
           name, ld->count, strong ? 100 * strong_ct / strong : 0, ld->count ? 100 * all_ct / ld->count : 0, 100 * hist[0] / iv,
           100 * hist[1] / iv, 100 * hist[2] / iv, 100 * hist[3] / iv, 100 * hist[4] / iv, hi - lo, maxrun, rev, leaps, roots, changes,
           t[CM_ARP].count, t[CM_CHORDS].count);
}

/* -d BARS: the lead as bar|step:note(length) with the chord, for reading by eye */
static void print_lead(const cm_config *c, const track *t, int bars)
{
    static const char *nm[12] = {"C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"};
    int b = -1;
    for (int i = 0; i < t->count; i++) {
        int step = t->n[i].tick / CM_TICKS, bb = step / 16;
        if (bb >= bars) break;
        const cm_plan *p = plan_at(t->n[i].tick);
        if (bb != b) { b = bb; printf("\n  %c bar %2d [%s q%d] ", 'A' + p->section, b + 1, nm[(c->key + p->chord[p->at[step % CM_STEPS]].root) % 12], p->chord[p->at[step % CM_STEPS]].qual); }
        printf("%d:%s%d(%d) ", step % 16, nm[t->n[i].note % 12], t->n[i].note / 12 - 1, (t->n[i].len + 12) / CM_TICKS);
    }
    printf("\n");
}

static void slug(char *o, const char *s) { for (; *s; s++) *o++ = *s == ' ' ? '-' : *s; *o = 0; }

int main(int argc, char **argv)
{
    const char *out = ".";
    int only = -1, passes = 0, dump = 0, mode = CM_SONG_FORM;
    uint32_t seed = 1;
    for (int i = 1; i + 1 < argc; i += 2) {
        if (!strcmp(argv[i], "-o")) out = argv[i + 1];
        else if (!strcmp(argv[i], "-n")) seed = (uint32_t)strtoul(argv[i + 1], 0, 0);
        else if (!strcmp(argv[i], "-p")) passes = atoi(argv[i + 1]);
        else if (!strcmp(argv[i], "-d")) dump = atoi(argv[i + 1]);
        else if (!strcmp(argv[i], "-m")) mode = atoi(argv[i + 1]);
        else if (!strcmp(argv[i], "-s") && strcmp(argv[i + 1], "all"))
            for (int k = 0; k < cm_nstyles; k++) { char sl[32]; slug(sl, cm_styles[k].name); if (!strcmp(sl, argv[i + 1]) || !strcmp(cm_styles[k].name, argv[i + 1])) only = k; }
    }
    if ((int)(sizeof drums / sizeof drums[0]) != cm_nstyles) { fprintf(stderr, "render: %d drum rows for %d styles\n", (int)(sizeof drums / sizeof drums[0]), cm_nstyles); return 1; }
    for (int k = 0; k < cm_nstyles; k++) {
        const cm_style *st = &cm_styles[k];
        for (int i = 0; i < st->nlead; i++) if (strlen(st->lead[i]) != 32) { fprintf(stderr, "%s lead cell %d: %zu steps\n", st->name, i, strlen(st->lead[i])); return 1; }
        for (int i = 0; i < st->nbass; i++) if (strlen(st->bass[i]) != 16) { fprintf(stderr, "%s bass cell %d\n", st->name, i); return 1; }
        for (int i = 0; i < st->nchords; i++) if (strlen(st->chords[i]) != 16) { fprintf(stderr, "%s chord cell %d\n", st->name, i); return 1; }
        if (strlen(st->arp) != 16) { fprintf(stderr, "%s arp cell\n", st->name); return 1; }
    }
    static track roles[CM_ROLES];
    for (int k = 0; k < cm_nstyles; k++) {
        if (only >= 0 && k != only) continue;
        cm_config c;
        cm_default(&c, k, seed);
        for (int s = 0; s < 3; s++) cm_plan_section(&plans[s], &c, s);
        int np = passes ? passes : (int)strlen(cm_styles[k].song) < 4 ? 4 : (int)strlen(cm_styles[k].song), occ[64];
        if (np > 64) np = 64;
        for (int pass = 0; pass < np; pass++) secs[pass] = (uint8_t)cm_song_at(&c, mode, pass, &occ[pass]);
        for (int r = 0; r < CM_ROLES; r++) {
            roles[r].count = 0;
            for (int pass = 0; pass < np; pass++) {
                cm_event ev[CM_MAX_EVENTS];
                int n = cm_compose(&plans[secs[pass]], &c, r, occ[pass], ev, CM_MAX_EVENTS);
                for (int i = 0; i < n && roles[r].count < MAXN; i++)
                    roles[r].n[roles[r].count++] = (note){ev[i].tick + pass * CM_SECTION_TICKS, ev[i].len, ev[i].note, ev[i].vel};
            }
        }
        char sl[32], path[512];
        slug(sl, cm_styles[k].name);
        stats(cm_styles[k].name, &c, roles);
        if (dump) print_lead(&c, &roles[CM_LEAD], dump);
        snprintf(path, sizeof path, "%s/%s-%u.mid", out, sl, seed);
        FILE *f = fopen(path, "wb");
        if (!f) { perror(path); return 1; }
        static track dr; dr.count = 0;
        for (int b = 0; b < np * CM_BARS; b++)
            for (int s = 0; s < 16; s++)
                for (int lane = 0; lane < 4; lane++)
                    if (drums[k][lane][s] == 'x' && dr.count < MAXN) dr.n[dr.count++] = (note){(b * 16 + s) * CM_TICKS, 12, (int[]){36, 38, 42, 46}[lane], 100};
        fwrite("MThd", 1, 4, f); put32(f, 6); fputc(0, f); fputc(1, f); fputc(0, f); fputc(5, f); fputc(0, f); fputc(96, f);
        midi_track(f, &roles[CM_LEAD], 0, cm_styles[k].bpm);
        midi_track(f, &roles[CM_BASS], 1, 0);
        midi_track(f, &roles[CM_ARP], 2, 0);
        midi_track(f, &roles[CM_CHORDS], 3, 0);
        midi_track(f, &dr, 9, 0);
        fclose(f);
        int full[3] = {CM_LEAD, CM_BASS, CM_CHORDS}, arp[3] = {CM_ARP, CM_BASS, CM_CHORDS};
        snprintf(path, sizeof path, "%s/%s-%u.wav", out, sl, seed);
        render(path, roles, CM_ROLES, full, 3, k, np * CM_BARS);
        snprintf(path, sizeof path, "%s/%s-%u-arp.wav", out, sl, seed);
        render(path, roles, CM_ROLES, arp, 3, k, np * CM_BARS);
    }
    return 0;
}
