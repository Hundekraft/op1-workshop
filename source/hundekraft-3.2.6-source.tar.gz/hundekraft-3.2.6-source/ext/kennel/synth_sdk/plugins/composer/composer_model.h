/* composer: generative sequencer model (docs: OP1-Emulator docs/melody-sequencer-design-2026-10-31.md).
 * A song plan (style, key, progression, form, three seeds) is shared by four roles; each 8-bar section is composed
 * off the tick into an event list, deterministically from the seeds and the pass number. Integers only, no libc,
 * fixed buffers.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef COMPOSER_MODEL_H
#define COMPOSER_MODEL_H
#include <stdint.h>

#define CM_BARS 8
#define CM_STEPS (CM_BARS * 16)               /* 16ths per section */
#define CM_TICKS 24                           /* ticks per 16th at 96 per beat */
#define CM_SECTION_TICKS (CM_STEPS * CM_TICKS)
#define CM_MAX_EVENTS 512                     /* per role and section: four-note chords on every 8th fit */
#define CM_MAX_CHORDS 20                      /* 2026-11-09: 16 + room for two held-key chords (canon, chorale: 16 a section) */

enum { CM_LEAD, CM_BASS, CM_ARP, CM_CHORDS, CM_ROLES };
enum { Q_MAJ, Q_MIN, Q_MAJ7, Q_MIN7, Q_DOM7, Q_MAJ9, Q_MIN9, Q_MIN11, Q_DOM9, Q_SUS2, Q_SUS4, Q_7SUS, Q_ADD9, Q_MMAJ7,
       Q_DIM, Q_M7B5, Q_DIM7, Q_MAJ6, Q_MIN6, Q_DOM13, Q_7S9,      /* 2026-11-03: jazz, blues, gospel, film */
       Q_COUNT };
enum { M_ION, M_DOR, M_PHR, M_LYD, M_MIX, M_AEO, M_HMIN };
/* phrase plans of four 2-bar phrases */
enum { F_SENTENCE, F_PERIOD, F_AAAB, F_AABA, F_LOOP, F_COUNT };
/* song modes: one section looped, the style's song form, or one other section held */
enum { CM_SONG_LOOP, CM_SONG_FORM, CM_SONG_B, CM_SONG_C, CM_SONG_COUNT };
enum { ARP_UP, ARP_UPDOWN, ARP_DOWN, ARP_PUMP, ARP_CONVERGE, ARP_ALBERTI };

typedef struct { uint16_t tick, len; uint8_t note, vel; } cm_event;
typedef struct { uint8_t root, qual, beats; } cm_chord;      /* root: semitones above the key; beats 0 ends a list */

/* Cells are strings: x note, X accent, o ghost, - hold the previous note, . rest. Lead cells are 2 bars (32),
 * the others 1 bar (16). */
typedef struct {
    const char *name;
    uint8_t bpm, key, mode, swing;                       /* swing: 50 straight .. 66 triplet, on the off 16ths */
    const cm_chord *const *prog; uint8_t nprog;
    const uint8_t *form; uint8_t nform;
    const char *const *lead; uint8_t nlead;
    const char *const *bass; uint8_t nbass;
    const char *const *chords; uint8_t nchords;
    const char *arp; uint8_t arp_pat;
    uint8_t lead_mid, bass_low, chord_mid;               /* MIDI register centres (bass: lowest root) */
    uint8_t gate[CM_ROLES];                              /* percent of the written length */
    uint8_t colour;                                      /* 0..4: how much the lead likes 9/11/13 */
    uint8_t free_colour;                                 /* 1: colour tones need no resolution (ambient, neo-soul) */
    uint8_t push;                                        /* percent of chord changes anticipated by an 8th or 16th */
    uint8_t leap;                                        /* 0..4: leap appetite */
    uint8_t b_oct, b_fifth, b_sev, b_appr, b_ghost;      /* bass figure weights, percent */
    uint8_t arp_colour;                                  /* 1: arp adds the colour tone */
    const char *song;                                    /* song form, one letter per 8-bar section: A verse, B chorus /
                                                          * drop, C bridge / breakdown, e.g. "AABBCB" */
    uint8_t names;                                       /* the sections' screen names: A VERSE, B CHORUS (CM_DROP: DROP),
                                                          * C BRIDGE (CM_BREAK: BREAK) */
    uint8_t canon;                                       /* 0, or bars: the lead is played again that much later an
                                                          * octave lower (a two-voice canon; the progression's period) */
} cm_style;
enum { CM_DROP = 1, CM_BREAK = 2 };

extern const cm_style cm_styles[];
extern const int cm_nstyles;
/* section 0 A, 1 B, 2 C of a style by name: VERSE, CHORUS or DROP, BRIDGE or BREAK */
const char *cm_section_name(int style, int section);

typedef struct {
    uint8_t style, key, density, variation, tension, dyn;   /* density/variation/tension/dyn 0..100 (dyn 50 = as written) */
    uint8_t form;                                           /* 0 = the seed picks from the style's forms, else F_* + 1 */
    uint8_t swing, length;                                  /* Shift page: 0 = the style's, else swing 50..75 % on the off
                                                             * 16ths and length 25..200 % of every role's gate */
    uint32_t seed_harm, seed_rhythm, seed_pitch;
} cm_config;

typedef struct {
    cm_chord chord[CM_MAX_CHORDS];
    uint8_t start[CM_MAX_CHORDS];             /* written start step (before the push) */
    uint8_t nchord;
    uint8_t at[CM_STEPS];                     /* chord sounding at each step, pushes applied */
    uint8_t pcs[CM_MAX_CHORDS][7];            /* chord scale per chord: pitch classes above the key */
    uint8_t form, cell_a, cell_b, cell_bass, cell_fill, cell_chords;   /* the style's anchor cells */
    uint8_t section;                          /* 0 A, 1 B, 2 C */
    /* this section's cells (the anchors varied by the rhythm seed and variation; see cm_plan_section) */
    char lead_a[33], lead_b[33], bass_a[17], bass_b[17], comp[17], arp[17];
    uint8_t arp_pat;
} cm_plan;

void cm_default(cm_config *c, int style, uint32_t seed);
void cm_plan_make(cm_plan *p, const cm_config *c);               /* section A */
/* Section B: another of the style's progressions, the motif from the contrast cell, a new pitch / rhythm seed, more
 * density, higher, louder. Section C: a third progression (or A's from its second chord), sparser, lower, softer. */
void cm_plan_section(cm_plan *p, const cm_config *c, int section);
/* The section (0 A, 1 B, 2 C) of song pass `pass` in a CM_SONG_* mode, and how many times that section came before
 * it (the pass number cm_compose wants: its first occurrence is the anchor). */
int cm_song_at(const cm_config *c, int mode, int pass, int *occurrence);
/* One section of one role, its occurrence 0, 1, 2 ... (occurrence % 4 == 0 is the anchor). Events sorted by tick. */
int cm_compose(const cm_plan *p, const cm_config *c, int role, int pass, cm_event *ev, int cap);
/* Dynamics: a velocity's distance from CM_DYN_MID scaled by dyn / 50 (0 all at CM_DYN_MID, 100 twice as far), 1..127 */
#define CM_DYN_MID 90
int cm_dynamics(int vel, int dyn);
/* A held key: from step `from` to the section end the chord is `root` (semitones above the key), its quality built
 * on the mode (a 7th chord when the style's own chords have 7ths). Returns 0 when the chord table is full. */
int cm_plan_override(cm_plan *p, const cm_config *c, int from, int root);
/* key-relative pitch class of a chord's tones, for checks */
uint16_t cm_chord_tones(const cm_plan *p, int ci);
uint16_t cm_chord_colour(const cm_plan *p, int ci);
/* how different two event lists of one section are, 0 (the same) .. 100: rhythm, (16th, note) pairs and, with
 * with_contour, the melodic contour; NEW's minimum-difference check and harness/composer_variety.c */
int cm_distance(const cm_event *a, int na, const cm_event *b, int nb, int with_contour);
/* NEW (synth page): fresh harmony, rhythm and pitch seeds, retried until section A of `role` is at least CM_NEW_MIN
 * away from the one before (at most CM_NEW_TRIES, else the most different). Returns the distance reached. */
#define CM_NEW_MIN 35
#define CM_NEW_TRIES 8
int cm_renew(cm_config *c, int role, uint32_t *nonce, uint32_t salt);
extern cm_event cm_renew_scratch[2][CM_MAX_EVENTS];   /* NEW's scratch (main loop only), shared with cd_renew */
#endif
