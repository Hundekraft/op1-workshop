/* composer drums: the groove model (composer_drums.h). Per bar a hit mask per voice (16 steps), built from the
 * style's groove row, then the section, density (the time voice), ghosts (ghost notes and hat rolls), vary (bar edits between
 * repeats) and fills; then events step by step. Deterministic from the song's rhythm seed and the drum seeds.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "composer_drums.h"
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */

/* kick 1, snare 3, rim 5, clap 6, tambourine 7, closed hat 9, open hat 11, low tom 13, ride 14, high tom 15, crash 16
 * (keys counted from 1) */
const uint8_t cd_pad_stock[CD_VOICES] = {[CD_KICK] = 0, [CD_SNARE] = 2, [CD_CLAP] = 5, [CD_RIM] = 4, [CD_CH] = 8,
                                         [CD_OH] = 10, [CD_LTOM] = 12, [CD_HTOM] = 14, [CD_CRASH] = 15, [CD_TAMB] = 6,
                                         [CD_RIDE] = 13};

static uint32_t hash(uint32_t a, uint32_t b)
{
    uint32_t h = a * 0x9E3779B1u ^ (b + 0x7F4A7C15u + (a << 6) + (a >> 2));
    h ^= h >> 15; h *= 0x2C1B3C6Du; h ^= h >> 12; h *= 0x297A2D39u; h ^= h >> 15;
    return h ? h : 1;
}
static uint32_t rnd(uint32_t *s) { uint32_t x = *s; x ^= x << 13; x ^= x >> 17; x ^= x << 5; return *s = x; }
static int below(uint32_t *s, int n) { return n > 1 ? (int)((rnd(s) >> 8) % (uint32_t)n) : 0; }
static int chance(uint32_t *s, int pct) { return below(s, 100) < pct; }
static int clamp(int x, int lo, int hi) { return x < lo ? lo : x > hi ? hi : x; }

void cd_default(cd_config *d, uint32_t seed)
{
    d->density = 50; d->vary = 30; d->ghosts = 30; d->fills = 50;
    d->seed_groove = hash(seed, 11); d->seed_hats = hash(seed, 12); d->seed_fill = hash(seed, 13);
}

/* ---- the grooves: one row per style, in cm_styles order (append only, as the styles) ----
 * Each pattern is one bar of 16ths written as text ("x" a hit, "X" an accent, "o" a ghost note, "." none) and folded
 * into a mask at compile time. kick2 is the odd bars' kick (blank: the same); ghosts ("o") in the snare or rim row are
 * written ghost notes; toms: "l" low, "h" high; acc: accented steps of the time voices (hats, ride, tambourine).
 * The density shapes the style's main time voice (the one of closed hat, ride, tambourine with the most hits); the
 * family gives the shared section rules (B, C), the ghost voice and the sparse fills. */
#define P1(s, i, c) ((uint16_t)((c) ? (s)[i] == (c) : (s)[i] != '.') << (i))
#define PM(s, c) (uint16_t)(P1(s, 0, c) | P1(s, 1, c) | P1(s, 2, c) | P1(s, 3, c) | P1(s, 4, c) | P1(s, 5, c) | P1(s, 6, c) | \
                            P1(s, 7, c) | P1(s, 8, c) | P1(s, 9, c) | P1(s, 10, c) | P1(s, 11, c) | P1(s, 12, c) |        \
                            P1(s, 13, c) | P1(s, 14, c) | P1(s, 15, c))
#define M(s) PM(s, 0)
#define _ "................"
enum {
    F_TRIP = 1,          /* trap: triplet hat rolls */
    F_FLAT = 2,          /* chiptune: flat velocities */
    F_SOFT = 4,          /* quieter kit (brushes, ballads) */
    F_LIGHT = 8,         /* density never fills the time voice past 8ths */
    F_RIM2SN = 16,       /* B: the rim backbeat (cross stick) becomes the snare */
    F_TOMFILL = 32,      /* fills on the toms */
    F_SNFILL = 64,       /* fills as snare rolls */
    F_BIG = 128,         /* B: another crash half way */
    F_SWELL = 256,       /* the ride swells up through the odd bars */
};
typedef struct {
    uint8_t family, lay;                              /* lay: ticks the backbeat and hats sit behind the grid */
    uint16_t flags;
    uint16_t kick, kick2, snare, clap, rim, ghost, ch, oh, ride, tamb, ltom, htom, acc;
} groove;
#define G(fam, fl, lay, k, k2, sn, cl, rm, ch, oh, rd, tb, tm, ac)                                                     \
    {fam, lay, fl, M(k), M(k2), M(sn), M(cl), M(rm), PM(sn, 'o') | PM(rm, 'o'), M(ch), M(oh), M(rd), M(tb), PM(tm, 'l'),   \
     PM(tm, 'h'), M(ac)}
static const groove grooves[] = {
    /*  family     flags                     lay  kick                kick (odd bars)      snare               clap                rim                 closed hat          open hat            ride                tambourine          toms                accents */
    /* deep house: clap 2 and 4, open hats on the off beats, a shuffled closed hat after each, a syncopated rim */
    G(CD_FOUR,     0,                         0, "X...X...X...X...", "X...X...X...X..x", _,                  "....X.......X...", "......x......x..", "...x...x...x...x", "..x...x...x...x.", _,                  _,                  _,                  _),
    /* melodic techno: off-beat closed hats alone (no open hat rumble), a soft clap, sparse rim ticks */
    G(CD_FOUR,     0,                         0, "X...X...X...X...", _,                  _,                  "....x.......x...", ".......x......x.", "..X...X...X...X.", _,                  _,                  _,                  _,                  _),
    /* trance: rolling 16th hats under off-beat open hats, snare and clap layered, snare-roll fills, crashes */
    G(CD_FOUR,     F_SNFILL | F_BIG,          0, "X...X...X...X...", _,                  "....X.......X...", "....X.......X...", _,                  "xxxxxxxxxxxxxxxx", "..X...X...X...X.", _,                  _,                  _,                  "X...X...X...X..."),
    /* synthwave: kick 1 and 3, a big gated snare + clap backbeat, straight 8th hats, tom fills */
    G(CD_BACKBEAT, F_TOMFILL | F_BIG,         0, "X.......X.......", "X.......X.x.....", "....X.......X...", "....X.......X...", _,                  "x.x.x.x.x.x.x.x.", _,                  _,                  _,                  _,                  "X...X...X...X..."),
    /* pop: kick with a pickup, snare 2 and 4, 8th hats, tambourine on the off beats */
    G(CD_BACKBEAT, 0,                         0, "X.......X.x.....", "X.......X.x....x", "....X.......X...", _,                  _,                  "x.x.x.x.x.x.x.x.", _,                  _,                  "..x...x...x...x.", _,                  _),
    /* lo-fi: lazy kick, the backbeat and hats laid back behind the grid, a soft rim at the end of the bar */
    G(CD_HALF,     F_SOFT,                    3, "X......x..x.....", "X.........x..x..", "....X.......X...", _,                  "..............x.", "x.x.x.x.x.x.x.x.", _,                  _,                  _,                  _,                  _),
    /* city pop: syncopated kick, snare with written ghosts, 16th hats with 8th accents, an open hat on the last 8th */
    G(CD_BACKBEAT, 0,                         0, "X..x......x..x..", "X..x....X.x.....", "....X..o.o..X...", _,                  _,                  "xxxxxxxxxxxxxx.x", "..............x.", _,                  _,                  _,                  "x.x.x.x.x.x.x.x."),
    /* ambient: one kick a bar (beat 1, then beat 3), a rim on 4, a soft shaker */
    G(CD_SPARSE,   F_SOFT | F_LIGHT,          0, "X...............", "........x.......", _,                  _,                  "............x...", _,                  _,                  _,                  "......x.......x.", _,                  _),
    /* idm: broken kick and snare, irregular hats, a rim off the grid */
    G(CD_BROKEN,   0,                         0, "X..x....X.x..x..", "X....x....x.x...", "....X...o..X....", _,                  "..x.........x..x", "x.xx.x..xx.x.x..", "......x.........", _,                  _,                  _,                  _),
    /* drum & bass: two-step kick and snare, 8th hats, a ghost before the bar */
    G(CD_BROKEN,   0,                         0, "X.........X.....", "X.........x..x..", "....X.......X..o", _,                  _,                  "x.x.x.x.x.x.x.x.", "..............x.", _,                  _,                  _,                  _),
    /* garage: 2-step kick (no beat 3), snare 2 and 4, shuffled rims and hats */
    G(CD_BROKEN,   0,                         0, "X......x..x.....", "X.........x..x..", "....X.......X...", _,                  "...x.....x....x.", "..x.x.xx..x.x.xx", _,                  _,                  _,                  _,                  _),
    /* acid: four on the floor, a clap, 909 closed hats with accented off beats, a kick pickup in odd bars */
    G(CD_FOUR,     0,                         0, "X...X...X...X...", "X...X...X...X.x.", _,                  "....X.......X...", _,                  "x.xxx.xxx.xxx.xx", _,                  _,                  _,                  _,                  "..X...X...X...X."),
    /* dub techno: kick, a soft open hat on the off beats, rim echoes, nothing else */
    G(CD_SPARSE,   0,                         0, "X...X...X...X...", _,                  _,                  _,                  "......x.......x.", _,                  "..x...x...x...x.", _,                  _,                  _,                  _),
    /* breakbeat: the amen (kick 1, 1e, 3&, snare 2 and 4 with ghosts) on the ride */
    G(CD_BROKEN,   0,                         0, "X.x.......xx....", "X.x.......x..x..", "....X..o.o..X..o", _,                  _,                  _,                  _,                  "x.x.x.x.x.x.x.x.", _,                  _,                  "X...X...X...X..."),
    /* nu-disco: four on the floor, snare 2 and 4, closed hat on the beat, open hat off it, tambourine 16ths */
    G(CD_FOUR,     0,                         0, "X...X...X...X...", _,                  "....X.......X...", _,                  _,                  "x...x...x...x...", "..x...x...x...x.", _,                  ".x.x.x.x.x.x.x.x", _,                  _),
    /* boom bap: swung kick, snare 2 and 4, 8th hats with a swung 16th before beats 2 and 4, laid back */
    G(CD_HALF,     0,                         2, "X..x......x.....", "X..x....x.x....x", "....X.......X...", _,                  _,                  "x.x.x.xxx.x.x.xx", _,                  _,                  _,                  _,                  _),
    /* trap: half time (snare and clap on 3), sliding kick, 8th hats with triplet rolls, snare-roll fills */
    G(CD_HALF,     F_TRIP | F_SNFILL,         0, "X......x.x......", "X.x.......x..x..", "........X.......", "........X.......", _,                  "x.x.x.x.x.x.x.x.", _,                  _,                  _,                  _,                  _),
    /* neo-soul: behind the beat; cross stick 2 and 4 (snare in B), ghost snares, a soft ride */
    G(CD_HALF,     F_RIM2SN,                  3, "X.....x...x..x..", "X......x..x.....", "..o.....o.....o.", _,                  "....X.......X...", _,                  _,                  "x.x.x.x.x.x.x.x.", _,                  _,                  "X...X...X...X..."),
    /* afrobeats: syncopated kick, clave rim, clap 2 and 4, shaker 16ths, talking-drum toms */
    G(CD_LATIN,    F_TOMFILL,                 0, "X.....x.X.......", "X.....x...x..x..", _,                  "....x.......x...", "...x..x...x..x..", _,                  _,                  _,                  "xxxxxxxxxxxxxxxx", "..........h..l..", "..X...X...X...X."),
    /* amapiano: four on the floor, shaker 16ths accented 3-3-2, syncopated rim, a late clap */
    G(CD_FOUR,     0,                         0, "X...X...X...X...", "X...X...X.....x.", _,                  "....x.......x..x", "...x..x....x....", _,                  _,                  _,                  "xxxxxxxxxxxxxxxx", _,                  "X..X..X.X..X..X."),
    /* reggaeton: the dembow (kick every beat, snare 3a, 4a of each half), 8th hats */
    G(CD_LATIN,    0,                         0, "X...X...X...X...", _,                  "...x..x....x..x.", _,                  _,                  "x.x.x.x.x.x.x.x.", _,                  _,                  _,                  _,                  _),
    /* bossa nova: surdo kick, the bossa rim clave, a soft ride in 8ths */
    G(CD_LATIN,    F_SOFT | F_LIGHT,          0, "X..xX..xX..xX..x", _,                  _,                  _,                  "x..x..x...x..x..", _,                  _,                  "x.x.x.x.x.x.x.x.", _,                  _,                  "X...X...X...X..."),
    /* ballad: kick 1 and 3, cross stick on 2 and 4 (snare in B), soft 8th hats */
    G(CD_BACKBEAT, F_SOFT | F_RIM2SN | F_LIGHT, 0, "X.......x.......", "X.......x.....x.", _,                  _,                  "....x.......x...", "x.x.x.x.x.x.x.x.", _,                  _,                  _,                  _,                  "X...X...X...X..."),
    /* blues: shuffle on the ride, kick 1 and 3, snare 2 and 4, the hat pedal on 2 and 4 */
    G(CD_BACKBEAT, F_LIGHT,                   0, "X.......X.......", "X......xX.......", "....X.......X...", _,                  _,                  "....x.......x...", _,                  "x..xx..xx..xx..x", _,                  _,                  "X...X...X...X..."),
    /* gospel: snare and clap together on 2 and 4, tambourine with them, ride 8ths, a kick before beat 3 */
    G(CD_BACKBEAT, 0,                         0, "X......xX.......", "X......xX.....x.", "....X.......X...", "....X.......X...", _,                  _,                  _,                  "x.x.x.x.x.x.x.x.", "....x.......x...", _,                  "X...X...X...X..."),
    /* funk: busy kick, snare with ghosts, 16th hats, an open hat, tambourine 2 and 4 */
    G(CD_BACKBEAT, 0,                         0, "X..x...x..x.....", "X.x...x..x...x..", "....X.o..o..X.o.", _,                  _,                  "xxxxxxxxxx.xxxxx", "..........x.....", _,                  "....x.......x...", _,                  "X.x.X.x.X.x.X.x."),
    /* folk: kick 1 and 3, cross stick 2 and 4 (snare in B), tambourine 8ths, no hats */
    G(CD_BACKBEAT, F_SOFT | F_RIM2SN,         0, "X.......X.......", "X.....x.X.......", _,                  _,                  "....x.......x...", _,                  _,                  _,                  "x.x.x.x.x.x.x.x.", _,                  "X...X...X...X..."),
    /* cinematic: taiko toms, a kick on 1 and 3, one snare hit on 4, ride swells in the odd bars, crashes */
    G(CD_SPARSE,   F_TOMFILL | F_BIG | F_SWELL, 0, "X.......X.......", "X...............", "............X...", _,                  _,                  _,                  _,                  "....x.x.xxxxxxxx", _,                  "l.....l.l.h.h.h.", _),
    /* chiptune: bouncy kick, snare 2 and 4, noise hats in 16ths, all at one velocity */
    G(CD_BACKBEAT, F_FLAT,                    0, "X..x....X..x....", "X..x....X.xx....", "....X.......X...", _,                  _,                  "xxxxxxxxxxxxxxxx", _,                  _,                  _,                  _,                  _),
    /* darksynth: half time, heavy kick, snare and clap on 3, 8th hats, toms at the end of the bar */
    G(CD_HALF,     F_TOMFILL | F_BIG,         0, "X.x...x...x.x...", "X.x...x...x...x.", "........X.......", "........X.......", _,                  "x.x.x.x.x.x.x.x.", "......x.........", _,                  _,                  "............h.l.", _),
    /* vaporwave: slowed half time, a lazy kick, snare and clap on 3, tambourine on 2 and 4, soft */
    G(CD_HALF,     F_SOFT,                    2, "X.....x.x.......", "X.....x.....x...", "........X.......", "........X.......", _,                  "x.x.x.x.x.x.x.x.", _,                  _,                  "....x.......x...", _,                  _),
    /* film noir: brushes; a feathered kick, the jazz ride, hat pedal 2 and 4, rim on 4, ghost snares */
    G(CD_SPARSE,   F_SOFT | F_LIGHT,          0, "X.......x.......", "X...............", "......o.......o.", _,                  "............x...", "....x.......x...", _,                  "x...x..xx...x..x", _,                  _,                  "X...X...X...X..."),
    /* classical group (2026-11-09): soft orchestral percussion, timpani on the toms */
    /* canon: a soft kick on 1 (3 in odd bars), a rim on 3, timpani rolls into the next ground, a triangle-like ride on 1 */
    G(CD_SPARSE,   F_SOFT | F_LIGHT | F_TOMFILL, 0, "X...............", "X.......x.......", _,                "............x...", "........x.......", _,                  _,                  "x.......x.......", _,                  "........l...l.h.", _),
    /* baroque: a pulse on every beat, rim and tambourine on the 8ths in between, timpani on the cadence */
    G(CD_SPARSE,   F_SOFT | F_TOMFILL,        0, "X...X...X...X...", "X...X...X...x.x.", _,                  _,                  "..x.......x.....", _,                  _,                  _,                  "..x...x...x...x.", "l.......h.......", "X.......X......."),
    /* classical: kick 1 and 3, rim 2 and 4, a ride in quarters, the timpani at the bar end */
    G(CD_SPARSE,   F_SOFT | F_LIGHT,          0, "X.......X.......", "X.......X...x...", _,                  _,                  "....x.......x...", _,                  _,                  "x...x...x...x...", _,                  "..............l.", "X...X...X...X..."),
    /* romantic: timpani swells, a kick on 1, the ride swelling through the odd bars, crashes */
    G(CD_SPARSE,   F_SOFT | F_TOMFILL | F_BIG | F_SWELL, 0, "X...............", "X.....x.........", _,             _,                  "............x...", _,                  _,                  "........xxxxxxxx", _,                  "l...l...l.l.h.h.", _),
    /* chorale: a kick on each half bar, a rim on 4, a tambourine on 2 and 4 in odd bars only by the vary layer */
    G(CD_SPARSE,   F_SOFT | F_LIGHT,          0, "X.......X.......", "X...x...X.......", _,                  _,                  "............x...", _,                  _,                  _,                  "....x.......x...", _,                  "X.......X......."),
};
#undef G
#undef _
_Static_assert(sizeof grooves / sizeof grooves[0] == 37, "a groove row per style");
static const char *const groove_names[] = {"deep house", "melodic techno", "trance", "synthwave", "pop", "lo-fi", "city pop",
    "ambient", "idm", "drum&bass", "garage", "acid", "dub techno", "breakbeat", "nu-disco", "boom bap", "trap", "neo-soul",
    "afrobeats", "amapiano", "reggaeton", "bossa nova", "ballad", "blues", "gospel", "funk", "folk", "cinematic",
    "chiptune", "darksynth", "vaporwave", "film noir", "canon", "baroque", "classical", "romantic", "chorale"};
static int streq(const char *a, const char *b) { while (*a && *a == *b) a++, b++; return *a == *b; }
static int has_row(int style)                         /* the row is the style's (composer_drums_test checks all) */
{
    return style >= 0 && style < cm_nstyles && style < (int)(sizeof grooves / sizeof grooves[0]) && streq(groove_names[style], cm_styles[style].name);
}
static const groove *row_of(int style) { return &grooves[style >= 0 && style < (int)(sizeof grooves / sizeof grooves[0]) ? style : 0]; }
int cd_family(int style) { return has_row(style) ? row_of(style)->family : -1; }
int cd_voices(int style)
{
    if (!has_row(style)) return 0;
    const groove *g = row_of(style);
    int v = 0;
    v |= (g->kick | g->kick2) ? 1 << CD_KICK : 0; v |= g->snare ? 1 << CD_SNARE : 0;
    v |= g->clap ? 1 << CD_CLAP : 0; v |= g->rim ? 1 << CD_RIM : 0; v |= g->ch ? 1 << CD_CH : 0; v |= g->oh ? 1 << CD_OH : 0;
    v |= g->ride ? 1 << CD_RIDE : 0; v |= g->tamb ? 1 << CD_TAMB : 0; v |= g->ltom ? 1 << CD_LTOM : 0; v |= g->htom ? 1 << CD_HTOM : 0;
    return v;
}

/* ---- one bar ---- */
typedef struct { uint16_t hit[CD_VOICES], acc, ghost; uint16_t roll, trip; uint8_t fill_from, fill_vel0; } barmask;

#define ON(b, v, s) ((b)->hit[v] |= (uint16_t)(1u << (s)))
#define OFF(b, v, s) ((b)->hit[v] &= (uint16_t)~(1u << (s)))
#define HAS(b, v, s) (((b)->hit[v] >> (s)) & 1)
static const uint16_t Q4 = 0x1111, E8 = 0x5555;                /* quarters, 8ths */
static int bits(uint16_t m) { int k = 0; for (; m; m &= (uint16_t)(m - 1)) k++; return k; }

/* the style's written groove (section A, density 50) */
static void base(barmask *b, const groove *g, int bar)
{
    for (int v = 0; v < CD_VOICES; v++) b->hit[v] = 0;
    b->roll = b->trip = 0; b->fill_from = 16; b->fill_vel0 = 0;
    b->hit[CD_KICK] = (bar & 1) && g->kick2 ? g->kick2 : g->kick;
    b->hit[CD_SNARE] = g->snare;                          /* (snare and rim rows hold their ghosts too) */
    b->hit[CD_CLAP] = g->clap; b->hit[CD_RIM] = g->rim; b->hit[CD_CH] = g->ch; b->hit[CD_OH] = g->oh;
    b->hit[CD_RIDE] = (g->flags & F_SWELL) && !(bar & 1) ? 0 : g->ride; b->hit[CD_TAMB] = g->tamb;
    b->hit[CD_LTOM] = g->ltom; b->hit[CD_HTOM] = g->htom;
    b->ghost = g->ghost; b->acc = g->acc;
}
/* the main time voice: closed hat, ride or tambourine, whichever the row writes most */
static int time_voice(const groove *g)
{
    int c = bits(g->ch), r = bits(g->ride), t = bits(g->tamb);
    return c >= r && c >= t ? CD_CH : r >= t ? CD_RIDE : CD_TAMB;
}
/* density: below 20 the beats only, below 40 the 8ths, up to 70 as written, then 8ths added, from 85 16ths (light
 * styles stop at 8ths); the other time voices drop out below 25 (the ride keeps its beats) */
static uint16_t shape(uint16_t m, int d, int light)
{
    if (!m) return 0;
    if (d < 20) return m & Q4;
    if (d < 40) return m & E8 ? m & E8 : m;
    if (d < 70) return m;
    return d < 85 || light ? m | E8 : 0xFFFF;
}
static void hats(barmask *b, const groove *g, int d)
{
    int tv = time_voice(g);
    b->hit[tv] = shape(b->hit[tv], d, g->flags & F_LIGHT);
    if (d < 25) {
        if (tv != CD_TAMB) b->hit[CD_TAMB] = 0;
        if (tv != CD_RIDE) b->hit[CD_RIDE] &= Q4;
        if (tv != CD_CH) b->hit[CD_CH] &= Q4;
    }
    b->hit[CD_CH] &= (uint16_t)~b->hit[CD_OH];
}

static int free_step(const barmask *b, int s) { return !HAS(b, CD_SNARE, s) && !HAS(b, CD_CLAP, s) && !HAS(b, CD_KICK, s); }

/* ---- the song's own take on the style (2026-11-09: NEW on the drum page changed only ghosts and fills, so every song of a
 * style had the same beat): from the groove seed, once per song, a few of: extra kicks from the family's pool (odd bars
 * their own), one off-beat kick moved, another figure for the main time voice, open hats placed elsewhere, another
 * pattern for the rim / tambourine the row has, an extra backbeat hit before a beat. The anchors stay: the kick on 1
 * (and every quarter in four-on-the-floor), the backbeat and the row's voices; no voice the row lacks is added (the
 * grid's rows stay). Vary sets how much: 0 is the row as written, 30 (the default) about two changes, 100 about all. */
typedef struct { uint16_t kick[2], kick_off, tv, oh, perc, bb; uint8_t tv_on, oh_on, perc_on, tom_rot, tom_swap; } take;
static const uint16_t kick_pool[CD_FAMILIES] = {
    [CD_FOUR] = 0xC4C8, [CD_BACKBEAT] = 0x4CC8, [CD_HALF] = 0x6CCC, [CD_BROKEN] = 0x6EEC, [CD_LATIN] = 0x4C48, [CD_SPARSE] = 0x4500};
static uint16_t pick_bits(uint16_t pool, int n, uint32_t *r)
{
    uint16_t m = 0;
    for (int k = 0, tries = 0; k < n && tries < 24; tries++) {
        int s = below(r, 16);
        if (pool >> s & 1 && !(m >> s & 1)) { m |= (uint16_t)(1u << s); k++; }
    }
    return m;
}
static void make_take(take *t, const groove *g, const cd_config *d, uint32_t seed)
{
    uint32_t r = hash(seed, 0x7A4Eu);
    int p = d->vary ? 40 + d->vary * 3 / 5 : 0;             /* each change's chance: 58 % at the default 30 */
    t->kick[0] = t->kick[1] = t->kick_off = t->tv = t->oh = t->perc = t->bb = 0; t->tv_on = t->oh_on = t->perc_on = t->tom_rot = t->tom_swap = 0;
    if (!p) return;
    uint16_t pool = (uint16_t)(kick_pool[g->family] & ~g->kick & ~g->snare & ~g->clap);
    int sparse = g->family == CD_SPARSE;
    if (chance(&r, p)) t->kick[0] = pick_bits(pool, 1 + (!sparse && chance(&r, 40)), &r);
    if (chance(&r, p)) t->kick[1] = pick_bits(pool, 1 + (!sparse && chance(&r, 50)), &r);
    else t->kick[1] = t->kick[0];
    if (g->family != CD_FOUR && chance(&r, p / 2)) t->kick_off = 1;
    static const uint16_t figs[] = {0x5555, 0x4444, 0xDDDD, 0x7777, 0x5545, 0x5455, 0xFFFF, 0x5155};   /* 8ths, off, x.xx, xxx., gaps, 16ths */
    int light = g->flags & F_LIGHT;
    int tvv = time_voice(g);
    uint16_t written = tvv == CD_CH ? g->ch : tvv == CD_RIDE ? g->ride : g->tamb;
    if (chance(&r, p))
        for (int k = 0; k < 4 && !t->tv_on; k++) {          /* another figure than the written one */
            uint16_t f = figs[below(&r, light ? 2 : g->family == CD_FOUR ? 8 : 6)];
            if (f != written) { t->tv_on = 1; t->tv = f; }
        }
    if ((g->ch | g->oh) && !sparse && chance(&r, p)) {
        static const uint16_t ohs[] = {0x4000, 0x4040, 0x4444, 0x0400, 0x2000};
        t->oh_on = 1; t->oh = ohs[below(&r, g->family == CD_FOUR ? 5 : 4)];
        if (!g->oh && t->oh == 0x4444) t->oh = 0x4000;   /* a row without open hats gets one at most a bar end */
        if (!g->oh) t->oh &= 0x4000;
    }
    if ((g->rim | g->tamb) && chance(&r, p)) {
        static const uint16_t perc[] = {0x1249, 0x0924, 0x4444, 0x1044, 0x2492, 0x8888, 0x4848};   /* claves, offs, 3-3-2 */
        t->perc_on = 1; t->perc = perc[below(&r, 7)];
    }
    if (!sparse && chance(&r, p / 2)) { static const uint8_t bbs[] = {7, 15, 10, 14}; t->bb = (uint16_t)(1u << bbs[below(&r, 4)]); }
    if ((g->ltom | g->htom) && chance(&r, p)) { t->tom_rot = (uint8_t)(2 * (1 + below(&r, 3))); t->tom_swap = (uint8_t)chance(&r, 50); }
    if (!(t->kick[0] | t->kick[1] | t->kick_off | t->tv_on | t->oh_on | t->perc_on | t->bb | t->tom_rot))
        t->kick[0] = t->kick[1] = pick_bits(pool, 1, &r);   /* at least one change */
}
static void apply_take(barmask *b, const groove *g, const take *t, int bar)
{
    uint16_t backbeat = (uint16_t)((g->snare | g->clap | g->rim) & ~g->ghost);
    uint16_t add = t->kick[bar & 1] & (uint16_t)~backbeat;
    b->hit[CD_KICK] |= add;
    if (t->kick_off) {                                      /* the last off-beat kick one 16th later */
        for (int s = 15; s > 0; s--)
            if ((s & 3) && HAS(b, CD_KICK, s) && !(add >> s & 1)) {
                if (s + 1 < 16 && !(backbeat >> (s + 1) & 1)) { OFF(b, CD_KICK, s); ON(b, CD_KICK, s + 1); }
                break;
            }
    }
    if (t->tv_on) { int tv = time_voice(g); if (b->hit[tv]) b->hit[tv] = t->tv; }
    if (t->oh_on) { b->hit[CD_OH] = t->oh; b->hit[CD_CH] &= (uint16_t)~t->oh; }
    if (t->perc_on) { if (g->rim & ~g->ghost) b->hit[CD_RIM] = (uint16_t)((b->hit[CD_RIM] & g->ghost) | (t->perc & ~backbeat)); else if (g->tamb) b->hit[CD_TAMB] = t->perc; }
    if (t->tom_rot) {                                       /* the written tom figure later in the bar, maybe high for low */
        uint16_t l = b->hit[CD_LTOM], h = b->hit[CD_HTOM];
        l = (uint16_t)((l << t->tom_rot) | (l >> (16 - t->tom_rot))); h = (uint16_t)((h << t->tom_rot) | (h >> (16 - t->tom_rot)));
        b->hit[CD_LTOM] = t->tom_swap ? h : l; b->hit[CD_HTOM] = t->tom_swap ? l : h;
    }
    if (t->bb) {
        int v = g->snare & (uint16_t)~g->ghost ? CD_SNARE : g->clap ? CD_CLAP : CD_RIM;
        if (!HAS(b, CD_KICK, bits(t->bb - 1))) b->hit[v] |= t->bb;
    }
}

/* the section: B fuller (open hats, extra kicks, the cross stick to the snare, crash on bar 1 and with F_BIG on bar 5),
 * C sparse (no kick, or half time; no tambourine; toms only where they are the groove) */
static void section_layer(barmask *b, const groove *g, int section, int bar)
{
    if (section == 1) {
        if (g->family != CD_FOUR && (g->ch | g->oh))
            b->hit[CD_OH] |= g->family == CD_SPARSE ? (uint16_t)(1u << 14) : (uint16_t)((1u << 6) | (1u << 14));
        if (free_step(b, 14) && g->family != CD_SPARSE) ON(b, CD_KICK, 14);
        if (g->family == CD_FOUR && free_step(b, 7) && (bar & 1)) ON(b, CD_KICK, 7);
        if (g->flags & F_RIM2SN) { uint16_t m = b->hit[CD_RIM] & (uint16_t)~b->ghost; b->hit[CD_SNARE] |= m; b->hit[CD_RIM] &= (uint16_t)~m; }
        if ((g->flags & F_BIG) && bar == 4) ON(b, CD_CRASH, 0);
    } else if (section == 2) {
        if (g->family == CD_FOUR || g->family == CD_BROKEN || g->family == CD_SPARSE) b->hit[CD_KICK] = 0;
        else {                                            /* half time */
            b->hit[CD_KICK] &= 1; b->hit[CD_SNARE] &= (uint16_t)(1u << 8); b->hit[CD_CLAP] &= (uint16_t)(1u << 8);
            if (!(b->hit[CD_RIM] | b->hit[CD_SNARE])) ON(b, CD_SNARE, 8);
        }
        b->hit[CD_OH] &= (uint16_t)(1u << 14); b->hit[CD_TAMB] = 0;
        if (g->family != CD_SPARSE) b->hit[CD_LTOM] = b->hit[CD_HTOM] = 0;
    }
}
static const uint8_t ghost_pos[7] = {3, 7, 9, 11, 13, 15, 5};
static void ghost_layer(barmask *b, const groove *g, const cd_config *d, int dens, uint32_t *rng)
{
    int n = d->ghosts * (50 + dens) / 2000;              /* 0..7 a bar */
    int v = g->snare & (uint16_t)~g->ghost ? CD_SNARE : g->rim ? CD_RIM : CD_SNARE;   /* the style's backbeat drum */
    for (int k = 0, tries = 0; k < n && tries < 14; tries++) {
        int s = ghost_pos[below(rng, 7)];
        if (!free_step(b, s) || HAS(b, v, s) || HAS(b, CD_RIM, s)) continue;
        ON(b, v, s); b->ghost |= (uint16_t)(1u << s);
        k++;
    }
    /* hat rolls: trap always rolls with ghosts up, the others from ghosts 60 */
    int trip = g->flags & F_TRIP, rolls = trip ? d->ghosts / 25 : d->ghosts >= 60 ? 1 + (d->ghosts >= 90) : 0;
    for (int k = 0; k < rolls; k++) {
        int s = (k & 1) ? 6 + below(rng, 2) : 12 + below(rng, 4);
        if (!HAS(b, CD_CH, s)) { if (b->hit[CD_CH]) ON(b, CD_CH, s); else continue; }
        if (trip && d->ghosts > 60 && chance(rng, 50)) b->trip |= (uint16_t)(1u << s);
        else b->roll |= (uint16_t)(1u << s);
    }
}
/* vary: edits of this bar on this repeat */
static void vary_layer(barmask *b, const groove *g, int vary, uint32_t *rng)
{
    int ops = vary / 34 + chance(rng, vary % 34 * 3);
    static const uint8_t kick_at[7] = {3, 6, 7, 10, 11, 14, 15};
    for (int e = 0; e < ops; e++) {
        int op = below(rng, 5), s;
        if (op == 0 && g->family != CD_SPARSE) { s = kick_at[below(rng, 7)]; if (free_step(b, s)) ON(b, CD_KICK, s); }
        else if (op == 1) {                               /* a kick off the beat moves one 16th */
            for (s = 1; s < 16; s++) if (HAS(b, CD_KICK, s) && (s & 3)) break;
            int to = s + (chance(rng, 50) ? 1 : -1);
            if (s < 16 && to > 0 && to < 16 && free_step(b, to)) { OFF(b, CD_KICK, s); ON(b, CD_KICK, to); }
        } else if (op == 2) { s = 1 + 2 * below(rng, 8); OFF(b, time_voice(g), s < 16 ? s : 15); }
        else if (op == 3 && g->family != CD_SPARSE && b->hit[CD_CH]) { OFF(b, CD_CH, 14); ON(b, CD_OH, 14); }
        else if (op == 4) {
            int v = g->snare & (uint16_t)~g->ghost ? CD_SNARE : g->rim ? CD_RIM : CD_SNARE;
            s = ghost_pos[below(rng, 7)];
            if (free_step(b, s) && !HAS(b, CD_RIM, s)) { ON(b, v, s); b->ghost |= (uint16_t)(1u << s); }
        }
    }
}
/* a fill from step `from` to the bar end: a snare run, a tom run (high then low) or both with a kick; F_TOMFILL styles
 * pick from the two with toms, F_SNFILL ones roll the snare. Every voice but the crash stops for it. */
static void fill_layer(barmask *b, const groove *g, int from, uint32_t *rng)
{
    uint16_t span = (uint16_t)(0xFFFFu << from);
    for (int v = 0; v < CD_VOICES; v++) if (v != CD_CRASH) b->hit[v] &= (uint16_t)~span;
    b->ghost &= (uint16_t)~span; b->roll &= (uint16_t)~span; b->trip &= (uint16_t)~span;
    int type = g->flags & F_TOMFILL ? 1 + below(rng, 2) : g->flags & F_SNFILL ? 0 : below(rng, 3);
    int sparse = g->family == CD_SPARSE, half = (from + 16) / 2;
    for (int s = from; s < 16; s++) {
        if (sparse && (s & 1)) continue;
        if (type == 0) ON(b, CD_SNARE, s);
        else if (type == 1) { if (s & 1 && from < 12) continue; ON(b, s < half ? CD_HTOM : CD_LTOM, s); }
        else ON(b, (s & 1) ? CD_SNARE : s < half ? CD_HTOM : CD_LTOM, s);
    }
    if (type == 2) ON(b, CD_KICK, from);
    b->fill_from = (uint8_t)from;
}

int cd_fill_bars(const cm_config *c, const cd_config *d, int section, int occurrence, int next_section)
{
    if (!d->fills) return 0;
    uint32_t r = hash(d->seed_fill ^ c->seed_rhythm, 0xF111u + (uint32_t)section * 64 + (uint32_t)occurrence);
    int bars = 0;
    if (next_section >= 0 && next_section != section) bars |= 1 << 7;          /* before a section change: always */
    else if (chance(&r, d->fills / 2 + d->vary / 4)) bars |= 1 << 7;            /* at a repeat's end, now and then */
    if (d->fills > 50 && chance(&r, (d->fills - 50) * 2)) bars |= 1 << 3;       /* half way, a short one */
    return bars;
}
static int fill_len(const cd_config *d, int bar, int change)
{
    if (bar != 7) return 4;
    if (change) return 4 + 4 * (d->fills >= 35) + 4 * (d->fills >= 70);
    return d->fills >= 70 ? 8 : 4;
}

/* ---- events ---- */
static int emit(cm_event *ev, int n, int cap, int t, int len, int voice, int vel)
{
    if (n >= cap || t >= CM_SECTION_TICKS) return n;
    if (t + len > CM_SECTION_TICKS) len = CM_SECTION_TICKS - t;
    ev[n].tick = (uint16_t)t; ev[n].len = (uint16_t)len; ev[n].note = (uint8_t)voice; ev[n].vel = (uint8_t)clamp(vel, 1, 127);
    return n + 1;
}
int cd_compose(const cm_config *c, const cd_config *d, int section, int occurrence, int prev_section, int next_section,
               cm_event *ev, int cap)
{
    if (c->style >= cm_nstyles) return 0;
    const cm_style *st = &cm_styles[c->style];
    const groove *f = row_of(c->style);
    section = clamp(section, 0, 2);
    static const int8_t sec_dd[3] = {0, 15, -30};
    int dens = clamp(d->density + sec_dd[section], 0, 100), swing = c->swing ? c->swing : st->swing;
    int gate = 12 * (c->length ? c->length : 100) / 100, n = 0;
    if (gate < 3) gate = 3;
    int fills = cd_fill_bars(c, d, section, occurrence, next_section), change = next_section >= 0 && next_section != section;
    uint32_t sec_rng = hash(d->seed_hats ^ c->seed_rhythm, 0xD0u + (uint32_t)section);
    take tk;
    make_take(&tk, f, d, d->seed_groove);
    for (int bar = 0; bar < CM_BARS; bar++) {
        barmask b;
        uint32_t ghost_rng = sec_rng;                      /* the same ghosts each bar of a section ... */
        uint32_t bar_rng = hash(d->seed_groove ^ c->seed_rhythm, (uint32_t)(occurrence * 8 + bar) + 0x100u * (uint32_t)section);
        base(&b, f, bar);
        apply_take(&b, f, &tk, bar);
        section_layer(&b, f, section, bar);
        hats(&b, f, dens);
        if (d->vary > 50) ghost_rng = hash(sec_rng, (uint32_t)bar);   /* ... unless vary is above 50 */
        if (d->vary) vary_layer(&b, f, d->vary, &bar_rng);
        if (section != 2 || f->family != CD_SPARSE) ghost_layer(&b, f, d, dens, &ghost_rng);
        if (fills >> bar & 1) { uint32_t fr = hash(d->seed_fill, (uint32_t)(occurrence * 8 + bar)); fill_layer(&b, f, 16 - fill_len(d, bar, change), &fr); }
        if (bar == 0 && (section == 1 || (prev_section >= 0 && prev_section != section && d->fills))) ON(&b, CD_CRASH, 0);
        int soft = f->flags & F_SOFT ? 18 : 0;
        for (int s = 0; s < 16; s++) {
            int t = (bar * 16 + s) * CM_TICKS + ((s & 1) ? (swing - 50) * 2 * CM_TICKS / 100 : 0);
            for (int v = 0; v < CD_VOICES; v++) {
                if (!HAS(&b, v, s)) continue;
                int acc = (b.acc >> s) & 1, beat = !(s & 3), vel;
                if (s >= b.fill_from) vel = 64 + (s - b.fill_from) * 56 / (16 - b.fill_from);     /* the fill builds up */
                else if ((v == CD_SNARE || v == CD_RIM) && (b.ghost >> s & 1)) vel = 40 + d->ghosts / 6;
                else if (f->flags & F_FLAT) vel = 100;
                else if (v == CD_CH) vel = acc ? 90 : (s & 1) ? 66 : 78;
                else if (v == CD_RIDE) vel = f->flags & F_SWELL ? 44 + 4 * s : acc ? 94 : 76;
                else if (v == CD_TAMB) vel = acc ? 86 : (s & 1) ? 58 : 68;
                else if (v == CD_OH) vel = 88;
                else if (v == CD_CRASH) vel = 112;
                else if (v == CD_RIM) vel = 92;
                else if (v == CD_LTOM || v == CD_HTOM) vel = beat ? 104 : 90;
                else vel = beat ? 118 : 100;
                vel -= soft;
                if (c->dyn != 50) vel = cm_dynamics(vel, c->dyn);
                int len = v == CD_OH || v == CD_CRASH || v == CD_RIDE ? gate * 4 : gate;
                int late = v == CD_KICK || v == CD_CRASH || v == CD_LTOM || v == CD_HTOM ? 0 : f->lay;   /* laid back */
                n = emit(ev, n, cap, t + late, len, v, vel);
                t += late;
                if (v == CD_CH && (b.roll >> s & 1)) n = emit(ev, n, cap, t + CM_TICKS / 2, gate / 2 + 1, v, vel - 16);
                if (v == CD_CH && (b.trip >> s & 1)) { n = emit(ev, n, cap, t + 8, gate / 2 + 1, v, vel - 12); n = emit(ev, n, cap, t + 16, gate / 2 + 1, v, vel - 20); }
                t -= late;
            }
        }
    }
    for (int i = 1; i < n; i++)                           /* triplet rolls can pass the next step: sort (stable) */
        for (int j = i; j > 0 && ev[j].tick < ev[j - 1].tick; j--) {
            uint16_t tk = ev[j].tick, ln = ev[j].len; uint8_t no = ev[j].note, ve = ev[j].vel;   /* fields: no memcpy */
            ev[j].tick = ev[j - 1].tick; ev[j].len = ev[j - 1].len; ev[j].note = ev[j - 1].note; ev[j].vel = ev[j - 1].vel;
            ev[j - 1].tick = tk; ev[j - 1].len = ln; ev[j - 1].note = no; ev[j - 1].vel = ve;
        }
    return n;
}

/* ---- NEW (drum page): fresh groove, hat and fill seeds until section A differs enough (as cm_renew) ---- */
static uint32_t remix(uint32_t a) { a ^= a >> 16; a *= 0x7FEB352Du; a ^= a >> 15; a *= 0x846CA68Bu; a ^= a >> 16; return a ? a : 1; }
_Static_assert(CD_MAX_EVENTS <= CM_MAX_EVENTS, "cd_renew uses cm_renew's scratch");
#define new_was cm_renew_scratch[0]
#define new_try cm_renew_scratch[1]
int cd_renew(const cm_config *c, cd_config *d, uint32_t *nonce, uint32_t salt)
{
    cd_config t;
    uint32_t best[3] = {d->seed_groove, d->seed_hats, d->seed_fill};
    int bd = -1, nw = cd_compose(c, d, 0, 0, -1, 0, new_was, CD_MAX_EVENTS);
    for (int k = 0; k < CM_NEW_TRIES && bd < CD_NEW_MIN; k++) {
        for (unsigned i = 0; i < sizeof t; i++) ((uint8_t *)&t)[i] = ((const uint8_t *)d)[i];   /* (no memcpy) */
        uint32_t *sd[3] = {&t.seed_groove, &t.seed_hats, &t.seed_fill};
        for (int i = 0; i < 3; i++) { *nonce = remix(*nonce + 0x9E3779B9u + salt); *sd[i] = remix(*sd[i] ^ *nonce); }
        int dd = cm_distance(new_was, nw, new_try, cd_compose(c, &t, 0, 0, -1, 0, new_try, CD_MAX_EVENTS), 0);
        if (dd > bd) { bd = dd; best[0] = t.seed_groove; best[1] = t.seed_hats; best[2] = t.seed_fill; }
    }
    d->seed_groove = best[0]; d->seed_hats = best[1]; d->seed_fill = best[2];
    return bd;
}
