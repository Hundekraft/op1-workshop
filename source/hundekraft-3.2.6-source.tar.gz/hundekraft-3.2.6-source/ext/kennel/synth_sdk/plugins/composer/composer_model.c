/* composer: the composing model (see composer_model.h). Layers: harmony plan (cm_plan_make), form, motif,
 * pitch scoring and feel (cm_compose). No libc; work per section is bounded by the fixed buffers.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "composer_model.h"
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */

#define B(n) (1u << (n))
typedef struct { uint16_t tones, colour; uint8_t voice[4]; } quality;
/* chord tones, colour tones (9/11/13 the lead may sit on), voicing above the root (ascending) */
static const quality quals[Q_COUNT] = {
    [Q_MAJ]   = {B(0) | B(4) | B(7), B(2) | B(9), {0, 4, 7, 12}},
    [Q_MIN]   = {B(0) | B(3) | B(7), B(2) | B(5) | B(10), {0, 3, 7, 12}},
    [Q_MAJ7]  = {B(0) | B(4) | B(7) | B(11), B(2) | B(9) | B(6), {0, 4, 7, 11}},
    [Q_MIN7]  = {B(0) | B(3) | B(7) | B(10), B(2) | B(5), {0, 3, 7, 10}},
    [Q_DOM7]  = {B(0) | B(4) | B(7) | B(10), B(2) | B(9), {0, 4, 7, 10}},
    [Q_MAJ9]  = {B(0) | B(4) | B(7) | B(11) | B(2), B(9) | B(6), {4, 7, 11, 14}},
    [Q_MIN9]  = {B(0) | B(3) | B(7) | B(10) | B(2), B(5), {3, 7, 10, 14}},
    [Q_MIN11] = {B(0) | B(3) | B(7) | B(10) | B(5), B(2), {3, 10, 14, 17}},
    [Q_DOM9]  = {B(0) | B(4) | B(7) | B(10) | B(2), B(9), {4, 10, 14, 19}},
    [Q_SUS2]  = {B(0) | B(2) | B(7), B(9) | B(5), {0, 2, 7, 12}},
    [Q_SUS4]  = {B(0) | B(5) | B(7), B(2) | B(10), {0, 5, 7, 12}},
    [Q_7SUS]  = {B(0) | B(5) | B(7) | B(10), B(2), {0, 5, 10, 14}},
    [Q_ADD9]  = {B(0) | B(4) | B(7) | B(2), B(9), {0, 4, 7, 14}},
    [Q_MMAJ7] = {B(0) | B(3) | B(7) | B(11), B(2), {3, 7, 11, 14}},
    [Q_DIM]   = {B(0) | B(3) | B(6), B(9), {0, 3, 6, 12}},
    [Q_M7B5]  = {B(0) | B(3) | B(6) | B(10), B(5), {0, 3, 6, 10}},
    [Q_DIM7]  = {B(0) | B(3) | B(6) | B(9), B(2), {0, 3, 6, 9}},
    [Q_MAJ6]  = {B(0) | B(4) | B(7) | B(9), B(2), {0, 4, 7, 9}},
    [Q_MIN6]  = {B(0) | B(3) | B(7) | B(9), B(2) | B(5), {0, 3, 7, 9}},
    [Q_DOM13] = {B(0) | B(4) | B(7) | B(10) | B(9), B(2), {4, 10, 14, 21}},
    [Q_7S9]   = {B(0) | B(4) | B(7) | B(10) | B(3), 0, {4, 10, 15, 19}},
};
static const uint8_t modes[7][7] = {
    {0, 2, 4, 5, 7, 9, 11}, {0, 2, 3, 5, 7, 9, 10}, {0, 1, 3, 5, 7, 8, 10}, {0, 2, 4, 6, 7, 9, 11},
    {0, 2, 4, 5, 7, 9, 10}, {0, 2, 3, 5, 7, 8, 10}, {0, 2, 3, 5, 7, 8, 11}};
static const uint8_t metric[16] = {4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0};

static uint32_t hash(uint32_t a, uint32_t b)
{
    uint32_t h = a * 0x9E3779B1u ^ (b + 0x7F4A7C15u + (a << 6) + (a >> 2));
    h ^= h >> 15; h *= 0x2C1B3C6Du; h ^= h >> 12; h *= 0x297A2D39u; h ^= h >> 15;
    return h ? h : 1;
}
static uint32_t rnd(uint32_t *s) { uint32_t x = *s; x ^= x << 13; x ^= x >> 17; x ^= x << 5; return *s = x; }
static int below(uint32_t *s, int n) { return n > 1 ? (int)((rnd(s) >> 8) % (uint32_t)n) : 0; }
static int chance(uint32_t *s, int pct) { return below(s, 100) < pct; }
static int iabs(int x) { return x < 0 ? -x : x; }
static int mod12(int x) { x %= 12; return x < 0 ? x + 12 : x; }
static int oct7(int s) { return s >= 0 ? s / 7 : -((6 - s) / 7); }
static int deg7(int s) { return s - 7 * oct7(s); }
static uint16_t rot(uint16_t m, int r) { r = mod12(r); return (uint16_t)(((m << r) | (m >> (12 - r))) & 0xfff); }

uint16_t cm_chord_tones(const cm_plan *p, int ci) { return rot(quals[p->chord[ci].qual].tones, p->chord[ci].root); }
uint16_t cm_chord_colour(const cm_plan *p, int ci) { return rot(quals[p->chord[ci].qual].colour, p->chord[ci].root); }

void cm_default(cm_config *c, int style, uint32_t seed)
{
    c->style = (uint8_t)style; c->key = cm_styles[style].key;
    c->density = 50; c->variation = 40; c->tension = 50; c->dyn = 50; c->form = 0; c->swing = 0; c->length = 0;
    c->seed_harm = hash(seed, 1); c->seed_rhythm = hash(seed, 2); c->seed_pitch = hash(seed, 3);
}

/* ---- 1 harmony + form choices ---- */
/* chord scale: the mode, with each chord tone outside it replacing its neighbouring degree */
static void chord_scale(cm_plan *p, const cm_style *st, int i)
{
    uint16_t t = cm_chord_tones(p, i);
    for (int d = 0; d < 7; d++) p->pcs[i][d] = modes[st->mode][d];
    for (int pc = 0; pc < 12; pc++) {
        if (!(t & B(pc))) continue;
        int in = 0, best = -1;
        for (int d = 0; d < 7; d++) in |= p->pcs[i][d] == pc;
        if (in) continue;
        for (int d = 0; d < 7; d++) {
            int dist = mod12(p->pcs[i][d] - pc);
            if (dist != 1 && dist != 11) continue;
            if (best < 0 || (t & B(p->pcs[i][best]))) best = d;
        }
        if (best >= 0) p->pcs[i][best] = (uint8_t)pc;
    }
}
int cm_plan_override(cm_plan *p, const cm_config *c, int from, int root)
{
    const cm_style *st = &cm_styles[c->style];
    if (p->nchord >= CM_MAX_CHORDS || from < 0 || from >= CM_STEPS) return 0;
    const uint8_t *md = modes[st->mode];
    root = mod12(root);
    uint16_t mask = 0;
    for (int d = 0; d < 7; d++) mask |= (uint16_t)B(md[d]);
    int third = (mask & B(mod12(root + 4))) ? 4 : 3, fifth = (mask & B(mod12(root + 7))) || !(mask & B(mod12(root + 6))) ? 7 : 6;
    int sevenths = quals[st->prog[0][0].qual].tones & (B(10) | B(11)), q;
    if (fifth == 6) q = Q_MIN;
    else if (!sevenths) q = third == 4 ? Q_MAJ : Q_MIN;
    else if (third == 3) q = Q_MIN7;
    else q = (mask & B(mod12(root + 11))) ? Q_MAJ7 : Q_DOM7;
    int n = p->nchord;
    p->chord[n].root = (uint8_t)root; p->chord[n].qual = (uint8_t)q; p->chord[n].beats = 4;
    p->start[n] = (uint8_t)from; p->nchord++;
    chord_scale(p, st, n);
    for (int s = from; s < CM_STEPS; s++) p->at[s] = (uint8_t)n;
    return 1;
}

void cm_plan_make(cm_plan *p, const cm_config *c) { cm_plan_section(p, c, 0); }

/* ---- 1b variety: the style's tables are anchors; variation sets how far the seeds take a section from them ----
 * Harmony: a walk over the style's own chords with the anchor's harmonic rhythm (chance variation / 2), then
 * variation / 25 edits (a same-function substitute, a secondary dominant, a borrowed chord, a split, a merge, a sus
 * before its chord). Rhythm: a cell drawn from the onset odds of the style's own cells (chance variation / 2), else
 * the anchor cell, then a few seeded edits (shift, split, tie, rest, pickup, ghost). The bass and the arp only get the
 * edits: their figure is the style's groove. Variation 0 is the anchors. */
#define PROG_MAX 7
typedef struct { cm_chord c[PROG_MAX + 1]; int n, total; } prog;
static int func_of(int pc) { static const uint8_t f[12] = {0, 3, 1, 0, 0, 1, 3, 2, 1, 0, 2, 2}; return f[mod12(pc)]; }
/* the style's chords (every anchor), at most 24 */
static int palette(const cm_style *st, cm_chord *out)
{
    int n = 0;
    for (int i = 0; i < st->nprog; i++)
        for (const cm_chord *c = st->prog[i]; c->beats && n < 24; c++) {
            int dup = 0;
            for (int j = 0; j < n; j++) dup |= out[j].root == c->root && out[j].qual == c->qual;
            if (!dup) out[n++] = *c;
        }
    return n;
}
static int seventh_style(const cm_style *st) { return (quals[st->prog[0][0].qual].tones & (B(10) | B(11))) != 0; }
/* how much a root motion is liked: down a fifth, steps, thirds; staying is out */
static int motion(int from, int to)
{
    static const uint8_t w[12] = {0, 4, 14, 12, 12, 30, 2, 12, 12, 12, 14, 6};
    return w[mod12(to - from)];
}
static void walk(const cm_style *st, prog *g, uint32_t *rng)
{
    cm_chord pal[24];
    int np = palette(st, pal);
    if (np < 3) return;
    for (int i = 1; i < g->n; i++) {
        int sum = 0, wt[24], last = i == g->n - 1, f0 = func_of(g->c[i - 1].root);
        for (int k = 0; k < np; k++) {
            int f = func_of(pal[k].root), w = motion(g->c[i - 1].root, pal[k].root);
            if (f == f0 && f != 3) w /= 2;                                   /* move on: T -> S / D, S -> D, D -> T */
            if (last && f == 2) w *= 2;                                      /* the loop's last chord leans home */
            if (last && pal[k].root == g->c[0].root) w = 0;
            wt[k] = w; sum += w;
        }
        if (!sum) continue;
        int r = below(rng, sum), k = 0;
        while (r >= wt[k]) r -= wt[k++];
        g->c[i].root = pal[k].root; g->c[i].qual = pal[k].qual;
    }
}
static int insert_at(prog *g, int i, cm_chord c)
{
    if (g->n >= PROG_MAX || g->c[i].beats < 4) return 0;
    for (int j = g->n; j > i + 1; j--) g->c[j] = g->c[j - 1];
    int half = g->c[i].beats / 2;
    g->c[i + 1] = c; g->c[i + 1].beats = (uint8_t)half; g->c[i].beats = (uint8_t)(g->c[i].beats - half);
    g->n++;
    return 1;
}
static void edit(const cm_style *st, prog *g, int tension, uint32_t *rng)
{
    cm_chord pal[24];
    int np = palette(st, pal), i = below(rng, g->n), nx = (i + 1) % g->n, op = below(rng, 100);
    int minor = modes[st->mode][2] == 3, sev = seventh_style(st);
    if (op < 30) {                                                       /* a same-function substitute */
        int k = below(rng, np);
        for (int t = 0; t < np; t++, k = (k + 1) % np)
            if (pal[k].root != g->c[i].root && func_of(pal[k].root) == func_of(g->c[i].root)) {
                g->c[i].root = pal[k].root; g->c[i].qual = pal[k].qual; break;
            }
    } else if (op < 30 + tension / 4) {                                  /* V of the next chord in the second half */
        cm_chord d = {(uint8_t)mod12(g->c[nx].root + 7), (uint8_t)(sev ? Q_DOM7 : Q_MAJ), 0};
        if (d.root != g->c[i].root) insert_at(g, i, d);
    } else if (op < 42 + tension / 4) {                                  /* borrowed from the parallel mode */
        static const cm_chord maj_b[3] = {{8, Q_MAJ, 0}, {10, Q_MAJ, 0}, {5, Q_MIN, 0}};
        static const cm_chord min_b[3] = {{5, Q_MAJ, 0}, {7, Q_MAJ, 0}, {2, Q_MIN, 0}};
        cm_chord b = (minor ? min_b : maj_b)[below(rng, 3)];
        if (i && b.root != g->c[i - 1].root && b.root != g->c[nx].root) { g->c[i].root = b.root; g->c[i].qual = b.qual; }
    } else if (op < 70) {                                                /* split: a neighbour in the second half */
        int k = below(rng, np);
        for (int t = 0; t < np; t++, k = (k + 1) % np)
            if (motion(g->c[i].root, pal[k].root) >= 12 && pal[k].root != g->c[nx].root) { insert_at(g, i, pal[k]); break; }
    } else if (op < 85) {                                                /* merge with the next */
        if (g->n > 2 && i + 1 < g->n) {
            g->c[i].beats = (uint8_t)(g->c[i].beats + g->c[i + 1].beats);
            for (int j = i + 1; j + 1 < g->n; j++) g->c[j] = g->c[j + 1];
            g->n--;
        }
    } else if (g->c[i].qual == Q_MAJ || g->c[i].qual == Q_DOM7) {       /* a sus before its chord */
        cm_chord s = g->c[i];
        if (insert_at(g, i, s)) g->c[i].qual = (uint8_t)(s.qual == Q_DOM7 ? Q_7SUS : Q_SUS4);
    }
}
static void vary_prog(const cm_style *st, const cm_chord *anchor, int variation, int tension, uint32_t seed, prog *g)
{
    uint32_t rng = seed;
    g->n = 0; g->total = 0;
    while (g->n < 8 && anchor[g->n].beats) { g->c[g->n] = anchor[g->n]; g->total += anchor[g->n].beats; g->n++; }
    if (g->n > PROG_MAX) return;                                         /* an 8-chord anchor stays as written */
    if (chance(&rng, variation / 2)) walk(st, g, &rng);
    int edits = variation / 25 + chance(&rng, variation % 25 * 4);
    for (int e = 0; e < edits; e++) edit(st, g, tension, &rng);
    while (g->n * 32 / g->total > 14 && g->n > 2) {   /* 14 a section (CM_MAX_CHORDS was 16, room for two held-key chords;
                                                       * kept at 14 so the styles before 2026-11-09 compose as they did) */
        g->c[g->n - 2].beats = (uint8_t)(g->c[g->n - 2].beats + g->c[g->n - 1].beats); g->n--;
    }
    g->c[g->n].beats = 0;
}

/* rhythm cells: x note, X accent, o ghost, - hold, . rest */
static int onset(char ch) { return ch == 'x' || ch == 'X' || ch == 'o'; }
static void ccopy(char *d, const char *s, int len) { int i = 0; for (; i < len && s[i]; i++) d[i] = s[i]; for (; i <= len; i++) d[i] = i < len ? '.' : 0; }
/* a fresh cell from the onset odds per 16th of the style's cells (and their share of held steps) */
static void draw_cell(char *out, const char *const *cells, int ncell, int len, uint32_t *rng)
{
    int odds[16], holds = 0, steps = 0, notes = 0;
    for (int i = 0; i < 16; i++) odds[i] = 0;
    for (int c = 0; c < ncell; c++)
        for (int i = 0; i < len && cells[c][i]; i++) { odds[i & 15] += onset(cells[c][i]); holds += cells[c][i] == '-'; steps++; }
    for (int i = 0; i < 16; i++) odds[i] = odds[i] * 100 / (ncell * (len / 16));
    int hold = steps ? holds * 100 / steps : 0, on = 0;
    for (int i = 0; i < len; i++) {
        int tail = len == 32 && i >= 28;                                    /* a lead phrase breathes at its end */
        if (!tail && chance(rng, odds[i & 15] < 8 ? 8 : odds[i & 15])) { out[i] = 'x'; on = 1; notes++; }
        else out[i] = on && !tail && chance(rng, 30 + hold) ? '-' : (on = 0, '.');
    }
    if (notes < 2) out[0] = 'x';
    out[len] = 0;
}
static void mutate(char *c, int len, int ops, int lead, int ghost, uint32_t *rng)
{
    for (int e = 0; e < ops; e++) {
        int i = 1 + below(rng, len - 1), op = below(rng, lead ? 6 : 5);
        if (op == 0 && onset(c[i]) && (c[i - 1] == '.' || c[i - 1] == '-') && i > 1) { c[i - 1] = c[i]; c[i] = '-'; }   /* earlier */
        else if (op == 1 && onset(c[i]) && i + 1 < len && !onset(c[i + 1])) { c[i + 1] = c[i]; c[i] = c[i - 1] == '.' ? '.' : '-'; }
        else if (op == 2 && c[i] == '-' && metric[i & 15] >= 1) c[i] = 'x';                                          /* split */
        else if (op == 3 && onset(c[i]) && (onset(c[i - 1]) || c[i - 1] == '-')) c[i] = '-';                        /* tie */
        else if (op == 4 && onset(c[i]) && metric[i & 15] == 0) {                                                    /* rest */
            c[i] = ghost ? 'o' : '.';
            for (int j = i + 1; j < len && c[j] == '-'; j++) c[j] = '.';
        } else if (op == 5 && c[len - 2] == '.' && c[len - 1] == '.') c[len - 1] = 'x';                              /* pickup */
    }
}
static void vary_cell(char *out, const char *const *cells, int ncell, int pick, int len, int variation, int lead,
                      int ghost, int draw, uint32_t *rng)
{
    if (draw && chance(rng, variation / 2)) draw_cell(out, cells, ncell, len, rng);
    else ccopy(out, cells[pick], len);
    int ops = variation / (lead ? 20 : 35) + chance(rng, variation % (lead ? 20 : 35) * (lead ? 5 : 3));
    mutate(out, len, ops, lead, ghost, rng);
}

int cm_song_at(const cm_config *c, int mode, int pass, int *occurrence)
{
    const char *f = cm_styles[c->style].song;
    int len = 0;
    while (f && f[len]) len++;
    *occurrence = pass;
    if (mode == CM_SONG_B || mode == CM_SONG_C) return mode == CM_SONG_B ? 1 : 2;
    if (mode != CM_SONG_FORM || !len) return 0;
    int i = pass % len, s = f[i] - 'A', before = 0, per = 0;
    for (int k = 0; k < len; k++) if (f[k] - 'A' == s) { per++; if (k < i) before++; }
    *occurrence = pass / len * per + before;
    return s >= 0 && s <= 2 ? s : 0;
}

void cm_plan_section(cm_plan *p, const cm_config *c, int section)
{
    const cm_style *st = &cm_styles[c->style];
    uint32_t rh = hash(c->seed_harm, 7), rr = hash(c->seed_rhythm, 7), rs = hash(c->seed_harm, 17);
    int ia = below(&rh, st->nprog), pi = ia, rot = 0;
    if (section) {
        int ib = st->nprog > 1 ? (ia + 1 + below(&rs, st->nprog - 1)) % st->nprog : ia;
        pi = ib;
        if (section == 2) {
            pi = ia; rot = 1;
            for (int k = 1; k < st->nprog; k++) { int t = (ib + k) % st->nprog; if (t != ia && t != ib) { pi = t; rot = 0; break; } }
        }
    }
    prog g;
    vary_prog(st, st->prog[pi], c->variation, c->tension, hash(c->seed_harm, 700 + (uint32_t)section), &g);
    const cm_chord *pr = g.c;
    int len = 0, step = 0, n = 0, k;
    uint8_t push[8], idx[CM_MAX_CHORDS];
    for (unsigned i = 0; i < sizeof *p; i++) ((uint8_t *)p)[i] = 0;
    while (len < 8 && pr[len].beats) len++;
    k = rot % len;
    for (int i = 0; i < len; i++) push[i] = (uint8_t)(chance(&rh, st->push) ? (chance(&rh, 60) ? 2 : 1) : 0);
    while (step < CM_STEPS && n < CM_MAX_CHORDS) {
        p->chord[n] = pr[k]; p->start[n] = (uint8_t)step; idx[n] = (uint8_t)k;
        step += pr[k].beats * 4; n++; k = (k + 1) % len;
    }
    p->nchord = (uint8_t)n;
    for (int i = 0; i < n; i++) {
        int s0 = p->start[i] - (i ? push[idx[i]] : 0);
        int e = i + 1 < n ? p->start[i + 1] - push[idx[i + 1]] : CM_STEPS;
        for (int s = s0; s < e && s < CM_STEPS; s++) p->at[s] = (uint8_t)i;
    }
    for (int i = 0; i < n; i++) chord_scale(p, st, i);
    p->form = st->form[below(&rr, st->nform)];
    if (c->form && c->form <= F_COUNT) p->form = (uint8_t)(c->form - 1);
    p->cell_a = (uint8_t)below(&rr, st->nlead);
    p->cell_b = (uint8_t)(st->nlead > 1 ? (p->cell_a + 1 + below(&rr, st->nlead - 1)) % st->nlead : p->cell_a);
    p->cell_bass = (uint8_t)below(&rr, st->nbass);
    p->cell_fill = (uint8_t)(st->nbass > 1 ? (p->cell_bass + 1 + below(&rr, st->nbass - 1)) % st->nbass : p->cell_bass);
    p->cell_chords = (uint8_t)below(&rr, st->nchords);
    p->section = (uint8_t)section;
    if (section == 1) {
        uint8_t t = p->cell_a; p->cell_a = p->cell_b; p->cell_b = t;
        t = p->cell_bass; p->cell_bass = p->cell_fill; p->cell_fill = t;
        p->cell_chords = (uint8_t)((p->cell_chords + 1) % st->nchords);
    }
    uint32_t rv = hash(c->seed_rhythm, 900 + (uint32_t)section);
    int var = c->variation;
    vary_cell(p->lead_a, st->lead, st->nlead, p->cell_a, 32, var, 1, 0, 1, &rv);
    vary_cell(p->lead_b, st->lead, st->nlead, p->cell_b, 32, var, 1, 0, 1, &rv);
    vary_cell(p->bass_a, st->bass, st->nbass, p->cell_bass, 16, var, 0, st->b_ghost > 0, 0, &rv);
    vary_cell(p->bass_b, st->bass, st->nbass, p->cell_fill, 16, var, 0, st->b_ghost > 0, 0, &rv);
    vary_cell(p->comp, st->chords, st->nchords, p->cell_chords, 16, var, 0, 0, 1, &rv);
    const char *arp1[1] = {st->arp};
    vary_cell(p->arp, arp1, 1, 0, 16, var, 0, 0, 0, &rv);
    p->arp_pat = st->arp_pat;
    if (chance(&rv, var / 2)) {                                          /* another arp figure, never Alberti's elsewhere */
        static const uint8_t alt[6][3] = {{ARP_UPDOWN, ARP_PUMP, ARP_CONVERGE}, {ARP_UP, ARP_DOWN, ARP_PUMP},
            {ARP_UP, ARP_UPDOWN, ARP_CONVERGE}, {ARP_UP, ARP_UPDOWN, ARP_CONVERGE}, {ARP_UP, ARP_UPDOWN, ARP_PUMP},
            {ARP_UP, ARP_UPDOWN, ARP_CONVERGE}};
        p->arp_pat = alt[st->arp_pat % 6][below(&rv, 3)];
    }
}
/* per section: density change, lead lift in scale steps, velocity change */
static const int8_t sec_dd[3] = {0, 15, -30}, sec_lift[3] = {0, 1, -1}, sec_dv[3] = {0, 8, -12};
#define DV(p) sec_dv[(p)->section % 3]

/* ---- rhythm cells ---- */
typedef struct { uint8_t n, pos[32], len[32], kind[32]; } rhythm;
static void parse(rhythm *r, const char *cell, int steps)
{
    r->n = 0;
    for (int i = 0; i < steps && cell[i]; i++) {
        char ch = cell[i];
        if (ch == 'x' || ch == 'X' || ch == 'o') {
            r->pos[r->n] = (uint8_t)i; r->len[r->n] = 1; r->kind[r->n] = (uint8_t)(ch == 'X' ? 2 : ch == 'o' ? 3 : 1);
            r->n++;
        } else if (ch == '-' && r->n && r->pos[r->n - 1] + r->len[r->n - 1] == i) r->len[r->n - 1]++;
    }
}
/* Density 50 keeps the cell. Lower merges weak onsets into the note before (or rests); higher splits long notes. */
static void density(rhythm *r, int d, uint32_t *rng)
{
    if (d < 50) {
        int pct = (50 - d) * 2;
        for (int i = 1; i < r->n; i++) {
            int w = metric[r->pos[i] & 15];
            if (!((w == 0 && chance(rng, pct)) || (w == 1 && chance(rng, pct / 2)))) continue;
            if (r->pos[i - 1] + r->len[i - 1] == r->pos[i]) r->len[i - 1] = (uint8_t)(r->len[i - 1] + r->len[i]);
            for (int j = i; j + 1 < r->n; j++) { r->pos[j] = r->pos[j + 1]; r->len[j] = r->len[j + 1]; r->kind[j] = r->kind[j + 1]; }
            r->n--; i--;
        }
    } else if (d > 50) {
        int pct = (d - 50) * 2;
        for (int i = 0; i < r->n && r->n < 32; i++) {
            if (r->len[i] < 4 || !chance(rng, pct)) continue;
            int half = r->len[i] / 2;
            for (int j = r->n; j > i + 1; j--) { r->pos[j] = r->pos[j - 1]; r->len[j] = r->len[j - 1]; r->kind[j] = r->kind[j - 1]; }
            r->pos[i + 1] = (uint8_t)(r->pos[i] + half); r->len[i + 1] = (uint8_t)(r->len[i] - half); r->kind[i + 1] = 1;
            r->len[i] = (uint8_t)half; r->n++; i++;
        }
    }
}

/* ---- 4 pitch ---- */
typedef struct { rhythm r; int8_t s[32]; } phrase;
static void pcopy(phrase *d, const phrase *s)            /* byte copy: struct assignment would call memcpy */
{
    for (unsigned i = 0; i < sizeof *d; i++) ((uint8_t *)d)[i] = ((const uint8_t *)s)[i];
}
typedef struct { const cm_plan *p; const cm_style *st; const cm_config *c; int base, lift; } ctx;
enum { SH_ARCH, SH_RISE, SH_FALL, SH_DIP };
#define C0 2                                  /* lead centre: the 3rd above the tonic, in scale steps */
#define LOW (C0 - 6)
#define NCAND 16

static int weight(const cm_plan *p, int step)
{
    int w = metric[step & 15];
    if (!(step & 31)) w = 5;
    if (step > 0 && p->at[step] != p->at[step - 1] && w < 3) w = 3;
    return w;
}
/* negative = good: chord tones on strong beats, colour tones by style and tension, avoid notes worst (degree dg of
 * chord ci's scale) */
static int harm_deg(const ctx *x, int ci, int dg, int w)
{
    const cm_chord *ch = &x->p->chord[ci];
    const quality *q = &quals[ch->qual];
    int rel = x->p->pcs[ci][dg] - ch->root, t = x->c->tension;
    if (rel < 0) rel += 12;
    if (q->tones & B(rel)) return -3 * w - 1;
    if (q->colour & B(rel)) return -((x->st->colour + t / 34) * w) / 2;
    if (q->tones & B(rel ? rel - 1 : 11)) return 4 * w + 3 - t / 25;
    return 2 * w - (t * w) / 60;
}
static int harm(const ctx *x, int ci, int s, int w) { return harm_deg(x, ci, deg7(s), w); }
static int nct(const ctx *x, int ci, int s)
{
    const cm_chord *ch = &x->p->chord[ci];
    int rel = mod12(x->p->pcs[ci][deg7(s)] - ch->root);
    if (quals[ch->qual].tones & B(rel)) return 0;
    if ((quals[ch->qual].colour & B(rel)) && x->st->free_colour) return 0;
    return 1;
}
static const uint8_t prox[8] = {4, 0, 2, 5, 7, 10, 12, 9};
static const uint8_t cad_closed[7] = {0, 20, 5, 20, 8, 20, 20}, cad_open[7] = {12, 3, 8, 20, 0, 10, 6};

static int centre(int shape, int pos, int amp)
{
    int lo = 4 * C0 - 4, hi = 4 * (C0 + amp);
    switch (shape) {
    case SH_ARCH: return pos <= 20 ? lo + (hi - lo) * pos / 20 : hi - (hi - lo + 4) * (pos - 20) / 12;
    case SH_RISE: return lo + (hi - lo) * pos / 31;
    case SH_FALL: return hi - (hi - lo) * pos / 31;
    default: return pos <= 20 ? hi - (hi - lo) * pos / 20 : lo + (hi - lo) * (pos - 20) / 12;
    }
}
static int shape_cost(const phrase *ph)
{
    int lo = 99, hi = -99, run = 0, cost = 0, leaps = 0;
    for (int i = 0; i < ph->r.n; i++) {
        if (ph->s[i] < lo) lo = ph->s[i];
        if (ph->s[i] > hi) hi = ph->s[i];
        if (i && ph->s[i] == ph->s[i - 1]) { if (++run >= 3) cost += 10; } else run = 0;
        if (i && iabs(ph->s[i] - ph->s[i - 1]) >= 5) leaps++;
    }
    if (ph->r.n >= 4 && hi - lo < 3) cost += 15;
    if (hi - lo > 9) cost += (hi - lo - 9) * 8;
    if (leaps > 1) cost += 10 * (leaps - 1);
    return cost;
}
/* One note at a time: score the NCAND scale steps from LOW (+ the section's lift), pick one at random weighted by
 * 4096 >> ((cost - lowest) * 4 / temp). The per-note parts (metric weight, the chord's and a spanned chord's score per
 * degree, the previous note's facts) are computed once per note, not per candidate: no division in the candidate loop. */
static int gen(const ctx *x, phrase *ph, int from, int shape, int amp, int cad, uint32_t *rng, int prev)
{
    const cm_plan *p = x->p;
    int total = 0, leaps = 0, temp = 4 + x->c->tension / 12, cost[NCAND], s0 = LOW + x->lift, d0 = deg7(s0);
    uint8_t dtab[48];                                 /* (cost - lowest) * 4 / temp below 4 * temp, where it is < 16 */
    for (int v = 0; v < 4 * temp; v++) dtab[v] = (uint8_t)(v * 4 / temp);
    for (int i = 1; i < from; i++) leaps += iabs(ph->s[i] - ph->s[i - 1]) >= 4;
    for (int i = from; i < ph->r.n; i++) {
        int pos = ph->r.pos[i], len = ph->r.len[i], step = x->base + pos, ci = p->at[step], span = -1;
        int w = weight(p, step) + (len >= 4) + (len >= 8), hrow[7], srow[7];
        for (int k = pos + 1; k < pos + len && k < 32; k++)
            if (p->at[x->base + k] != ci) { span = p->at[x->base + k]; break; }
        for (int dg = 0; dg < 7; dg++) { hrow[dg] = harm_deg(x, ci, dg, w); srow[dg] = span >= 0 ? harm_deg(x, span, dg, 2) : 0; }
        const uint8_t *ct = cad && i == ph->r.n - 1 ? (cad == 2 ? cad_closed : cad_open) : 0;
        int pv = 0, pi = 0, pa = 0, res = 0;
        if (i > 0) {
            pv = ph->s[i - 1]; res = nct(x, p->at[x->base + ph->r.pos[i - 1]], pv);
            if (i > 1) { pi = pv - ph->s[i - 2]; pa = iabs(pi); }
        }
        int cq = centre(shape, pos, amp) + 4 * x->lift, lo = 1 << 30, dg = d0;
        for (int k = 0; k < NCAND; k++) {
            int s = s0 + k, dd = 4 * s - cq, c = (dd * dd * 3) / 64 + hrow[dg] + srow[dg];
            if (i == 0 && prev > -100) { int a = iabs(s - prev); c += (a < 7 ? prox[a] : 14) / 2; }
            if (i > 0) {
                int iv = s - pv, a = iabs(iv);
                c += a < 7 ? prox[a] : a == 7 ? prox[7] : 14 + 2 * a;
                if (a >= 3) c -= x->st->leap;
                if (a >= 4 && leaps >= 2) c += 8;
                if (i > 1) {
                    if (pa >= 3 && iv * pi > 0) c += 7;            /* keep going after a leap */
                    if (pa >= 3 && iv * pi < 0 && a <= 2) c -= 2;  /* step back after a leap */
                    if (pa == 1 && iv * pi > 0) c -= 1;            /* a run continues */
                    if (a == 0 && pi == 0) c += 7;                 /* third repeat */
                }
                if (res && a != 1) c += 6;                         /* a non-chord tone resolves by step */
            }
            if (ct) c += ct[dg];
            cost[k] = c;
            if (c < lo) lo = c;
            if (++dg == 7) dg = 0;
        }
        uint32_t wt[NCAND], sum = 0;
        for (int k = 0; k < NCAND; k++) { int v = cost[k] - lo; sum += wt[k] = v < 4 * temp ? 4096u >> dtab[v] : 0; }
        uint32_t r = (rnd(rng) >> 8) % sum;
        int k = 0;
        while (r >= wt[k]) r -= wt[k++];
        ph->s[i] = (int8_t)(s0 + k); total += cost[k];
        if (i && iabs(ph->s[i] - ph->s[i - 1]) >= 4) leaps++;
    }
    return total + shape_cost(ph);
}
/* generate-and-test: six candidates from the same rhythm, keep the cheapest */
static void best(const ctx *x, phrase *ph, int from, int shape, int amp, int cad, uint32_t seed, int prev)
{
    phrase cand, keep;
    pcopy(&keep, ph);
    int lo = 1 << 30;
    for (int k = 0; k < 6; k++) {
        uint32_t r = hash(seed, (uint32_t)k);
        pcopy(&cand, ph);
        int c = gen(x, &cand, from, shape, amp, cad, &r, prev);
        if (c < lo) { lo = c; pcopy(&keep, &cand); }
    }
    pcopy(ph, &keep);
}
/* move notes [from, to) by whole scale steps so strong beats sit on the new chords, then repair what is left */
static void adapt(const ctx *x, phrase *ph, int from, int to, int seq)
{
    static const int8_t ks[5] = {0, -2, 2, -1, 1};
    int bestk = 0, lo = 1 << 30;
    for (int j = 0; j < 5; j++) {
        int k = ks[j], c = 2 * iabs(k) + (seq && !k ? 100 : 0);
        for (int i = from; i < to; i++) {
            int step = x->base + ph->r.pos[i], w = weight(x->p, step);
            if (w >= 2) { int h = harm(x, x->p->at[step], ph->s[i] + k, w); c += h > 0 ? h : h / 2; }
        }
        if (c < lo) { lo = c; bestk = k; }
    }
    for (int i = from; i < to; i++) ph->s[i] = (int8_t)(ph->s[i] + bestk);
    for (int i = from; i < to; i++) {
        int step = x->base + ph->r.pos[i], w = weight(x->p, step), ci = x->p->at[step];
        if (w < 2 || harm(x, ci, ph->s[i], w) <= 0) continue;
        int dn = harm(x, ci, ph->s[i] - 1, w), up = harm(x, ci, ph->s[i] + 1, w);
        ph->s[i] = (int8_t)(ph->s[i] + (dn <= up ? -1 : 1));
    }
}
/* split one long note into the note and a step towards the next one */
static void ornament(phrase *ph, uint32_t *rng)
{
    int cand[32], n = 0;
    for (int i = 0; i < ph->r.n; i++) if (ph->r.len[i] >= 4) cand[n++] = i;
    if (!n || ph->r.n >= 32) return;
    int i = cand[below(rng, n)], half = ph->r.len[i] / 2, dir = i + 1 < ph->r.n && ph->s[i + 1] < ph->s[i] ? -1 : 1;
    for (int j = ph->r.n; j > i + 1; j--) {
        ph->r.pos[j] = ph->r.pos[j - 1]; ph->r.len[j] = ph->r.len[j - 1]; ph->r.kind[j] = ph->r.kind[j - 1]; ph->s[j] = ph->s[j - 1];
    }
    ph->r.pos[i + 1] = (uint8_t)(ph->r.pos[i] + half); ph->r.len[i + 1] = (uint8_t)(ph->r.len[i] - half);
    ph->r.kind[i + 1] = 1; ph->s[i + 1] = (int8_t)(ph->s[i] + dir); ph->r.len[i] = (uint8_t)half; ph->r.n++;
}

/* ---- feel: one event ---- */
/* the Shift page's overrides: 0 keeps the style's swing / gates, else swing 50..75 % and length 25..200 % of each gate */
#define SWING(st, c) ((c)->swing ? (c)->swing : (st)->swing)
#define GATE(st, c, role) ((c)->length ? (st)->gate[role] * (c)->length / 100 : (st)->gate[role])
static int emit(cm_event *ev, int n, int cap, int step, int len, int note, int vel, int gate, int swing)
{
    if (n >= cap || note < 0 || note > 127 || len <= 0) return n;
    int t = step * CM_TICKS, l = len * CM_TICKS * gate / 100;
    if (step & 1) t += (swing - 50) * 2 * CM_TICKS / 100;
    if (l < 6) l = 6;
    if (t + l > CM_SECTION_TICKS) l = CM_SECTION_TICKS - t;
    if (l <= 0) return n;
    ev[n].tick = (uint16_t)t; ev[n].len = (uint16_t)l; ev[n].note = (uint8_t)note; ev[n].vel = (uint8_t)(vel > 127 ? 127 : vel);
    return n + 1;
}

/* ---- 2 form, 3 motif: the lead ---- */
enum { OP_A, OP_EXACT, OP_SEQ, OP_NEWEND, OP_FRAG, OP_B };
static const uint8_t forms[F_COUNT][4][2] = {
    [F_SENTENCE] = {{OP_A, 0}, {OP_SEQ, 0}, {OP_FRAG, 0}, {OP_NEWEND, 2}},
    [F_PERIOD]   = {{OP_A, 0}, {OP_NEWEND, 1}, {OP_EXACT, 0}, {OP_NEWEND, 2}},
    [F_AAAB]     = {{OP_A, 0}, {OP_EXACT, 0}, {OP_EXACT, 0}, {OP_B, 2}},
    [F_AABA]     = {{OP_A, 0}, {OP_EXACT, 0}, {OP_B, 1}, {OP_NEWEND, 2}},
    [F_LOOP]     = {{OP_A, 0}, {OP_EXACT, 0}, {OP_EXACT, 0}, {OP_NEWEND, 0}},
};
static int first_from(const phrase *ph, int pos) { int i = 0; while (i < ph->r.n && ph->r.pos[i] < pos) i++; return i; }

static int compose_lead(const cm_plan *p, const cm_config *c, int pass, cm_event *ev, int cap)
{
    const cm_style *st = &cm_styles[c->style];
    ctx x = {p, st, c, 0, sec_lift[p->section % 3]};
    phrase a, b, ph;
    uint32_t rr = hash(c->seed_rhythm, 101), rp = hash(c->seed_pitch, 101), rv = hash(c->seed_pitch, 977 + (uint32_t)pass);
    int vary = pass % 4 != 0, prev = -100, n = 0;
    parse(&a.r, p->lead_a, 32); density(&a.r, c->density, &rr);
    parse(&b.r, p->lead_b, 32); density(&b.r, c->density, &rr);
    int shape = below(&rp, 3) ? SH_ARCH : SH_RISE, amp = 2 + below(&rp, 3) + (p->section == 1);
    const uint8_t (*plan)[2] = forms[p->form < F_COUNT ? p->form : 0];
    best(&x, &a, 0, shape, amp, plan[0][1], hash(c->seed_pitch, 200), -100);
    for (int j = 0; j < 4; j++) {
        int op = plan[j][0], cad = plan[j][1];
        uint32_t seed = hash(c->seed_pitch, 300 + (uint32_t)j);
        if (vary && chance(&rv, c->variation)) {
            if (op == OP_EXACT) op = OP_SEQ;
            else if (op == OP_SEQ) op = OP_EXACT;
            else seed = hash(seed, (uint32_t)pass);
        }
        x.base = 32 * j;
        switch (op) {
        case OP_A: pcopy(&ph, &a); break;
        case OP_EXACT: case OP_SEQ: pcopy(&ph, &a); adapt(&x, &ph, 0, ph.r.n, op == OP_SEQ); break;
        case OP_NEWEND: {
            pcopy(&ph, &a); int f = first_from(&ph, 16);
            adapt(&x, &ph, 0, f, 0); best(&x, &ph, f, SH_FALL, amp, cad, seed, prev);
            break;
        }
        case OP_FRAG: {
            /* the motif's head twice (the second a step on), then a new continuation on its second-bar rhythm */
            int h = first_from(&a, 8), f = first_from(&a, 16), m = 0;
            if (h < 1) { pcopy(&ph, &a); adapt(&x, &ph, 0, ph.r.n, 1); break; }   /* no head in the first half bar: sequence it */
            for (int rep = 0; rep < 2; rep++)
                for (int i = 0; i < h && m < 32; i++, m++) {
                    ph.r.pos[m] = (uint8_t)(a.r.pos[i] + 8 * rep); ph.r.kind[m] = a.r.kind[i];
                    int l = a.r.len[i]; if (a.r.pos[i] + l > 8) l = 8 - a.r.pos[i];
                    ph.r.len[m] = (uint8_t)(l < 1 ? 1 : l); ph.s[m] = a.s[i];
                }
            int head = m;
            for (int i = f; i < a.r.n && m < 32; i++, m++) { ph.r.pos[m] = a.r.pos[i]; ph.r.len[m] = a.r.len[i]; ph.r.kind[m] = a.r.kind[i]; }
            ph.r.n = (uint8_t)m;
            adapt(&x, &ph, 0, head / 2, 0);
            phrase second; pcopy(&second, &ph); adapt(&x, &second, head / 2, head, 1);
            for (int i = head / 2; i < head; i++) ph.s[i] = second.s[i];
            best(&x, &ph, head, SH_RISE, amp, cad, seed, prev);
            break;
        }
        default: pcopy(&ph, &b); best(&x, &ph, 0, shape == SH_ARCH ? SH_DIP : SH_FALL, amp, cad, seed, prev); break;
        }
        if (vary && j == 0 && chance(&rv, c->variation)) ornament(&ph, &rv);
        prev = ph.r.n ? ph.s[ph.r.n - 1] : prev;
        /* cadence: hold the last note, leave a breath at the phrase end */
        if (cad && ph.r.n) {
            int i = ph.r.n - 1, end = 30 - ph.r.pos[i];
            if (end > ph.r.len[i]) ph.r.len[i] = (uint8_t)end;
        }
        int tonic = st->lead_mid - mod12(st->lead_mid - c->key);
        for (int i = 0; i < ph.r.n; i++) {
            int step = x.base + ph.r.pos[i], ci = p->at[step], s = ph.s[i];
            int note = tonic + 12 * oct7(s) + p->pcs[ci][deg7(s)];
            int vel = 84 + 3 * metric[step & 15] + (ph.r.kind[i] == 2 ? 14 : 0) - (ph.r.kind[i] == 3 ? 34 : 0);
            n = emit(ev, n, cap, step, ph.r.len[i], note, vel + DV(p), GATE(st, c, CM_LEAD), SWING(st, c));
        }
    }
    if (st->canon) {                                      /* the second voice: the lead `canon` bars later, an octave down */
        int lag = st->canon * 16 * CM_TICKS, m = n;
        for (int i = 0; i < m && n < cap; i++) {
            int t = ev[i].tick + lag, l = ev[i].len;
            if (t >= CM_SECTION_TICKS || ev[i].note < 12) continue;
            if (t + l > CM_SECTION_TICKS) l = CM_SECTION_TICKS - t;
            ev[n].tick = (uint16_t)t; ev[n].len = (uint16_t)l; ev[n].note = (uint8_t)(ev[i].note - 12);
            ev[n].vel = (uint8_t)(ev[i].vel > 20 ? ev[i].vel - 10 : ev[i].vel); n++;
        }
        for (int i = 1; i < n; i++)                       /* by tick (stable, fields: no memcpy) */
            for (int j = i; j > 0 && ev[j].tick < ev[j - 1].tick; j--) {
                cm_event e; e.tick = ev[j].tick; e.len = ev[j].len; e.note = ev[j].note; e.vel = ev[j].vel;
                ev[j].tick = ev[j - 1].tick; ev[j].len = ev[j - 1].len; ev[j].note = ev[j - 1].note; ev[j].vel = ev[j - 1].vel;
                ev[j - 1].tick = e.tick; ev[j - 1].len = e.len; ev[j - 1].note = e.note; ev[j - 1].vel = e.vel;
            }
    }
    return n;
}

/* ---- the other roles: 1-bar cells, notes cut and restruck at chord changes ---- */
typedef struct { uint8_t step[48], len[48], kind[48], fresh[48]; int n; } barnotes;
static void bar(const cm_plan *p, const rhythm *r, int b, int restrike, barnotes *o)
{
    o->n = 0;
    for (int i = 0; i < r->n; i++) {
        int s = 16 * b + r->pos[i], e = s + r->len[i], kind = r->kind[i], fresh = 0;
        while (s < e && o->n < 48) {
            int cut = s + 1;
            while (cut < e && p->at[cut] == p->at[s]) cut++;
            o->step[o->n] = (uint8_t)s; o->len[o->n] = (uint8_t)(cut - s); o->kind[o->n] = (uint8_t)kind;
            o->fresh[o->n] = (uint8_t)fresh; o->n++;
            if (!restrike) break;
            s = cut; kind = 1; fresh = 1;
        }
    }
}
static int next_change(const cm_plan *p, int s) { int c = s + 1; while (c < CM_STEPS && p->at[c] == p->at[s]) c++; return c; }
static int root_note(const cm_plan *p, const cm_config *c, int ci, int low)
{
    return low + mod12(c->key + p->chord[ci].root - low);
}

static int compose_bass(const cm_plan *p, const cm_config *c, int pass, cm_event *ev, int cap)
{
    const cm_style *st = &cm_styles[c->style];
    rhythm r, f;
    uint8_t fig[2][32];
    uint32_t rb = hash(c->seed_pitch, 202), rv = hash(c->seed_pitch, 1977 + (uint32_t)pass);
    int n = 0;
    parse(&r, p->bass_a, 16); parse(&f, p->bass_b, 16);
    if (p->section) { uint32_t rd = hash(c->seed_rhythm, 303); density(&r, c->density, &rd); density(&f, c->density, &rd); }
    /* one figure per bar (0 root, 1 octave, 2 fifth, 3 seventh/third, 4 approach, 5 ghost), reused every bar */
    for (int v = 0; v < 2; v++) {
        const rhythm *q = v ? &f : &r;
        for (int i = 0; i < q->n; i++) {
            int sym = 0;
            if (q->kind[i] == 3 || (i && chance(&rb, st->b_ghost))) sym = 5;
            else if (i) {
                int roll = below(&rb, 100), oct = st->b_oct + 10 * v, fif = st->b_fifth, sev = st->b_sev;
                sym = roll < oct ? 1 : roll < oct + fif ? 2 : roll < oct + fif + sev ? 3 : 0;
            }
            if (i == q->n - 1 && chance(&rb, st->b_appr + 25 * v)) sym = 4;
            fig[v][i] = (uint8_t)sym;
        }
    }
    int fill3 = pass % 4 != 0 && chance(&rv, c->variation);
    for (int b = 0; b < CM_BARS; b++) {
        int v = b == 7 || (b == 3 && fill3);
        const rhythm *q = v ? &f : &r;
        barnotes o;
        bar(p, q, b, 1, &o);
        int src = -1;
        for (int i = 0; i < o.n; i++) {
            int s = o.step[i], ci = p->at[s];
            if (!o.fresh[i]) src++;
            int sym = o.fresh[i] ? 0 : fig[v][src < 0 ? 0 : src];
            if (s == 0 || p->at[s] != p->at[s - 1]) sym = 0;
            int nc = next_change(p, s), last = i + 1 >= o.n ? (16 * (b + 1) >= nc) : (o.step[i + 1] >= nc);
            if (sym == 4 && !last) sym = 0;
            int root = root_note(p, c, ci, st->bass_low), note = root, vel = 104 + (o.kind[i] == 2 ? 12 : 0);
            uint16_t t = rot(quals[p->chord[ci].qual].tones, 0);
            switch (sym) {
            case 1: note = root + 12; break;
            case 2: note = root + ((t & B(7)) ? 7 : (t & B(6)) ? 6 : 12); break;
            case 3: note = root + ((t & B(10)) ? 10 : (t & B(11)) ? 11 : (t & B(3)) ? 3 : (t & B(4)) ? 4 : 7); break;
            case 4: {
                int tgt = root_note(p, c, nc < CM_STEPS ? p->at[nc] : 0, st->bass_low);
                int k = (s * 7 + b) % 4;
                note = k < 2 ? tgt - 1 : k == 2 ? tgt + 1 : tgt + 7 - 12;
                if (note < st->bass_low - 2) note += 12;
                break;
            }
            case 5: vel = 52; break;
            }
            n = emit(ev, n, cap, s, o.len[i], note, vel + DV(p), GATE(st, c, CM_BASS), SWING(st, c));
        }
    }
    return n;
}

static void voicing(const cm_plan *p, const cm_config *c, int ci, int mid, const int *prev, int *out)
{
    const quality *q = &quals[p->chord[ci].qual];
    int root = mid - 12 + mod12(c->key + p->chord[ci].root - (mid - 12)), lo = 1 << 30;
    for (int inv = 0; inv < 4; inv++)
        for (int o = -1; o <= 1; o++) {
            int v[4], cost = 0, sum = 0;
            for (int i = 0; i < 4; i++) v[i] = root + q->voice[(i + inv) & 3] + (i + inv >= 4 ? 12 : 0) + 12 * o;
            for (int i = 1; i < 4; i++) for (int j = i; j > 0 && v[j] < v[j - 1]; j--) { int t = v[j]; v[j] = v[j - 1]; v[j - 1] = t; }
            for (int i = 0; i < 4; i++) sum += v[i];
            if (prev) for (int i = 0; i < 4; i++) cost += iabs(v[i] - prev[i]);
            cost += iabs(sum / 4 - mid) * (prev ? 1 : 4);
            if (v[3] > mid + 12) cost += 4 * (v[3] - mid - 12);
            if (v[0] < mid - 12) cost += 4 * (mid - 12 - v[0]);
            if (cost < lo) { lo = cost; for (int i = 0; i < 4; i++) out[i] = v[i]; }
        }
}
static void voicings(const cm_plan *p, const cm_config *c, int mid, int (*v)[4])
{
    for (int i = 0; i < p->nchord; i++) voicing(p, c, i, mid, i ? v[i - 1] : 0, v[i]);
}

static int compose_chords(const cm_plan *p, const cm_config *c, cm_event *ev, int cap)
{
    const cm_style *st = &cm_styles[c->style];
    int v[CM_MAX_CHORDS][4], n = 0;
    rhythm r;
    voicings(p, c, st->chord_mid, v);
    parse(&r, p->comp, 16);
    if (p->section) { uint32_t rd = hash(c->seed_rhythm, 404); density(&r, c->density, &rd); }
    for (int b = 0; b < CM_BARS; b++) {
        barnotes o;
        bar(p, &r, b, 1, &o);
        for (int i = 0; i < o.n; i++) {
            int ci = p->at[o.step[i]], vel = 78 + (o.kind[i] == 2 ? 12 : 0) - (o.kind[i] == 3 ? 24 : 0);
            for (int k = 0; k < 4; k++) n = emit(ev, n, cap, o.step[i], o.len[i], v[ci][k], vel + DV(p), GATE(st, c, CM_CHORDS), SWING(st, c));
        }
    }
    return n;
}

static int compose_arp(const cm_plan *p, const cm_config *c, cm_event *ev, int cap)
{
    static const int8_t pats[6][8] = {
        {0, 1, 2, 3, 4, 5, -1}, {0, 1, 2, 3, 4, 3, 2, 1}, {5, 4, 3, 2, 1, 0, -1}, {0, 4, 1, 4, 2, 4, 3, 4},
        {0, 5, 1, 4, 2, 3, -1}, {0, 2, 1, 2, -1}};
    const cm_style *st = &cm_styles[c->style];
    int v[CM_MAX_CHORDS][4], n = 0, idx = 0, last = -1;
    rhythm r;
    voicings(p, c, st->chord_mid + 7, v);
    parse(&r, p->arp, 16);
    if (p->section) { uint32_t rd = hash(c->seed_rhythm, 505); density(&r, c->density, &rd); }
    const int8_t *pat = pats[p->arp_pat < 6 ? p->arp_pat : 0];
    int plen = 0;
    while (plen < 8 && pat[plen] >= 0) plen++;
    for (int b = 0; b < CM_BARS; b++) {
        barnotes o;
        bar(p, &r, b, 0, &o);
        for (int i = 0; i < o.n; i++) {
            int s = o.step[i], ci = p->at[s];
            if (ci != last || !(s & 15)) idx = 0;
            last = ci;
            int k = pat[idx++ % plen], note = k < 4 ? v[ci][k] : v[ci][k - 4] + 12;
            int vel = 80 + (metric[s & 15] >= 2 ? 14 : 0);
            n = emit(ev, n, cap, s, o.len[i], note, vel + DV(p), GATE(st, c, CM_ARP), SWING(st, c));
        }
    }
    return n;
}

int cm_compose(const cm_plan *p, const cm_config *in, int role, int pass, cm_event *ev, int cap)
{
    if (in->style >= cm_nstyles) return 0;
    /* sections B and C: their own seeds and density; section A is the configuration as it is */
    cm_config cc, *c = &cc;
    for (unsigned i = 0; i < sizeof cc; i++) ((uint8_t *)&cc)[i] = ((const uint8_t *)in)[i];
    if (p->section) {
        int d = in->density + sec_dd[p->section % 3];
        cc.seed_pitch = hash(in->seed_pitch, 0x5EC0u + p->section); cc.seed_rhythm = hash(in->seed_rhythm, 0x5EC0u + p->section);
        cc.density = (uint8_t)(d < 0 ? 0 : d > 100 ? 100 : d);
    }
    int n = 0;
    switch (role) {
    case CM_LEAD: n = compose_lead(p, c, pass, ev, cap); break;
    case CM_BASS: n = compose_bass(p, c, pass, ev, cap); break;
    case CM_ARP: n = compose_arp(p, c, ev, cap); break;
    case CM_CHORDS: n = compose_chords(p, c, ev, cap); break;
    }
    if (in->dyn != 50) for (int i = 0; i < n; i++) ev[i].vel = (uint8_t)cm_dynamics(ev[i].vel, in->dyn);
    return n;
}
int cm_dynamics(int vel, int dyn)
{
    int v = CM_DYN_MID + (vel - CM_DYN_MID) * dyn / 50;          /* per note, off the audio path */
    return v < 1 ? 1 : v > 127 ? 127 : v;
}

/* ---- how different two sections are (NEW's minimum-difference check, harness/composer_variety.c) ----
 * Three parts, each 0..100: rhythm (onset 16ths that only one has, of all onset 16ths), notes ((16th, note) pairs that
 * only one has) and, with `contour`, the melodic contour (direction of successive onsets' first notes that differ, over
 * the shorter list). The mean of the three. Drums (with_contour 0, notes are voices): the mean over the voices of
 * each voice's own pattern distance, weighted 3 : 1 with the rhythm. */
static int jdist(const uint32_t *a, const uint32_t *b, int words)
{
    int both = 0, any = 0;
    for (int i = 0; i < words; i++) {
        uint32_t x = a[i] & b[i], y = a[i] | b[i];
        for (; x; x &= x - 1) both++;
        for (; y; y &= y - 1) any++;
    }
    return any ? 100 - both * 100 / any : 0;
}
static int contour(const cm_event *e, int n, int8_t *dir, int cap)
{
    int k = 0, last = -1, prev = -1;
    for (int i = 0; i < n && k < cap; i++) {
        int s = e[i].tick / CM_TICKS;
        if (s == last) continue;                          /* the first note of each onset 16th */
        last = s;
        if (prev >= 0) dir[k++] = (int8_t)(e[i].note > prev ? 1 : e[i].note < prev ? -1 : 0);
        prev = e[i].note;
    }
    return k;
}
#define CM_DIST_PAIRS 2048                                /* (16th, note % 16) pairs: 128 x 16 bits */
int cm_distance(const cm_event *a, int na, const cm_event *b, int nb, int with_contour)
{
    uint32_t ra[CM_STEPS / 32], rb[CM_STEPS / 32], pa[CM_DIST_PAIRS / 32], pb[CM_DIST_PAIRS / 32];
    for (int i = 0; i < CM_STEPS / 32; i++) ra[i] = rb[i] = 0;
    for (int i = 0; i < CM_DIST_PAIRS / 32; i++) pa[i] = pb[i] = 0;
    for (int i = 0; i < na; i++) { int s = a[i].tick / CM_TICKS % CM_STEPS, q = s * 16 + a[i].note % 16; ra[s >> 5] |= 1u << (s & 31); pa[q >> 5] |= 1u << (q & 31); }
    for (int i = 0; i < nb; i++) { int s = b[i].tick / CM_TICKS % CM_STEPS, q = s * 16 + b[i].note % 16; rb[s >> 5] |= 1u << (s & 31); pb[q >> 5] |= 1u << (q & 31); }
    int r = jdist(ra, rb, CM_STEPS / 32), p = jdist(pa, pb, CM_DIST_PAIRS / 32);
    if (!with_contour) {                                  /* drums: each voice's own pattern counts alike (a moved kick
                                                           * weighs as much as a new hat figure), then the onsets */
        int sum = 0, nv = 0;
        for (int v = 0; v < 16; v++) {
            uint32_t va[CM_STEPS / 32] = {0}, vb[CM_STEPS / 32] = {0}, any = 0;
            for (int w = 0; w < CM_STEPS / 32; w++)
                for (int s = 0; s < 32; s++) {
                    int q = (w * 32 + s) * 16 + v;
                    va[w] |= (pa[q >> 5] >> (q & 31) & 1u) << s; vb[w] |= (pb[q >> 5] >> (q & 31) & 1u) << s;
                }
            for (int w = 0; w < CM_STEPS / 32; w++) any |= va[w] | vb[w];
            if (any) { sum += jdist(va, vb, CM_STEPS / 32); nv++; }
        }
        return nv ? (sum / nv * 3 + r) / 4 : r;
    }
    int8_t da[CM_STEPS], db[CM_STEPS];
    int ka = contour(a, na, da, CM_STEPS), kb = contour(b, nb, db, CM_STEPS), k = ka < kb ? ka : kb, diff = 0;
    for (int i = 0; i < k; i++) diff += da[i] != db[i];
    int c = k ? diff * 100 / k : (ka != kb) * 100;
    return (r + p + c) / 3;
}

/* ---- NEW: fresh seeds until section A of the role differs enough from the one before (at most CM_NEW_TRIES; else
 * the most different try). nonce: the caller's running state, salt: anything that moves it (the playhead). The scratch
 * is static: the main loop only (composer.c calls it from the encoder push and the harness from main). */
static uint32_t remix(uint32_t a) { a ^= a >> 16; a *= 0x7FEB352Du; a ^= a >> 15; a *= 0x846CA68Bu; a ^= a >> 16; return a ? a : 1; }
cm_event cm_renew_scratch[2][CM_MAX_EVENTS];        /* cd_renew borrows them (CD_MAX_EVENTS <= CM_MAX_EVENTS) */
#define new_was cm_renew_scratch[0]
#define new_try cm_renew_scratch[1]
int cm_renew(cm_config *c, int role, uint32_t *nonce, uint32_t salt)
{
    cm_plan p;
    cm_config t;
    uint32_t best[3] = {c->seed_harm, c->seed_rhythm, c->seed_pitch};
    int bd = -1;
    cm_plan_section(&p, c, 0);
    int nw = cm_compose(&p, c, role, 0, new_was, CM_MAX_EVENTS);
    for (int k = 0; k < CM_NEW_TRIES && bd < CM_NEW_MIN; k++) {
        for (unsigned i = 0; i < sizeof t; i++) ((uint8_t *)&t)[i] = ((const uint8_t *)c)[i];
        uint32_t *sd[3] = {&t.seed_harm, &t.seed_rhythm, &t.seed_pitch};
        for (int i = 0; i < 3; i++) { *nonce = remix(*nonce + 0x9E3779B9u + salt); *sd[i] = remix(*sd[i] ^ *nonce); }
        cm_plan_section(&p, &t, 0);
        int d = cm_distance(new_was, nw, new_try, cm_compose(&p, &t, role, 0, new_try, CM_MAX_EVENTS), 1);
        if (d > bd) { bd = d; best[0] = t.seed_harm; best[1] = t.seed_rhythm; best[2] = t.seed_pitch; }
    }
    c->seed_harm = best[0]; c->seed_rhythm = best[1]; c->seed_pitch = best[2];
    return bd;
}
