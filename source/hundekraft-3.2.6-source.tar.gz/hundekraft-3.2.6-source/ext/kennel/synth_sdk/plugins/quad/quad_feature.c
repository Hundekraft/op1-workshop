/* quad and pond LFOs as one feature plugin (kind 3) on the LFO-type hook point (op1_feature_lfo.h): the source lives in
 * lfo/quadlfo.c (the pond rides on quad's apply / trigger / state code, so both types are in this file); this folder
 * makes them a feature. Their lfo_types rows and the SVGs (quadlfo.svg, pondlfo.svg) come with the build either way.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../lfo/quadlfo.c"
#include "../../op1_feature_lfo.h"

#define QL_TYPE_COMMON(m) .stock_class = OP1_LFO_CLASS_MIDI, .match = m, \
    .apply_synth = ql_apply_synth, .apply_drum = ql_apply_drum, .apply_fx = ql_apply_fx, \
    .trig_synth = ql_trig_synth, .trig_drum = ql_trig_drum, .trig_fx = ql_trig_fx, .press = ql_press, .turn = ql_turn

static const op1_lfo_type pond_lfo = {
    .name = "pond", .marker = POND_MARK, QL_TYPE_COMMON(ql_match_pond), .svg = "pondlfo.svg", .screen = &SCREEN_pondlfo,
};
static const op1_lfo_type quad_lfo = {
    .name = "quad", .marker = QL_MARK, QL_TYPE_COMMON(ql_match_quad), .svg = "quadlfo.svg", .screen = &SCREEN_quadlfo,
    .next = &pond_lfo,
};

static const char *const ql_claims[] = { "lfo:quad", "lfo:pond", 0 };
const op1_feature_t FEATURE_quad = { .api = OP1_FEATURE_API, .priority = 500, .name = "quad", .lfo = &quad_lfo, .claims = ql_claims };
