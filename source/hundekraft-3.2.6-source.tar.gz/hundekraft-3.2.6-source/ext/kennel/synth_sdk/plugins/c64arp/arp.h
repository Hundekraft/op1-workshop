/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#ifndef C64ARP_H
#define C64ARP_H
#include <stdint.h>
#define ARP_STEPS 16
typedef struct {
 uint8_t length,rate,octaves,gate,latch,preset,select;
 int8_t offset[ARP_STEPS];uint8_t dwell[ARP_STEPS];
 uint8_t table; /* 0: TABLE OFF (held notes in pitch order), 1: table rows, 2: RANDOM (held notes in random order). */
} arp_config;
typedef struct {
 arp_config cfg;int16_t keys[24],root,sounding,rootkey;
 uint8_t run,step,octave,started;uint16_t elapsed;
 int8_t lastkey; /* RANDOM: key of the previous step, -1 after a restart. */
 uint32_t rng;  /* RANDOM: xorshift32 state, never 0. */
 uint32_t down; /* Physical keys; with hold on, keys[] keeps released notes. */
} arp_state;
void arp_init(arp_state *s);
/* Table presets: 0..7 MAJOR..MINDOWN, ARP_CUSTOM (an edited table), 9..16 OCTAVE..ALBERTI (2026-11-07). Saved by
 * number, so a number never changes meaning; blue steps 0..7 then 9..16. */
#define ARP_CUSTOM 8
#define ARP_PRESETS 17
void arp_preset(arp_state *s,unsigned n);
/* Rate: stored 0..7 = 1/4 .. 1/64 (unchanged), stored 8 = 1/2 (added 2026-11-10). The knob and the screen go in
 * display order 1/2, 1/4, 1/8 .. 1/64, so a stored number never changes meaning. */
#define ARP_RATES 9
unsigned arp_rate_pos(unsigned rate);   /* stored rate -> knob position 0..8 */
unsigned arp_rate_at(unsigned pos);     /* knob position -> stored rate */
void arp_key(arp_state *s,unsigned key,int note,int pressed);
void arp_tick(arp_state *s,int mode);
void arp_stop(arp_state *s);
void arp_bounds_changed(arp_state *s);
void arp_set_latch(arp_state *s,int on);
void arp_set_table(arp_state *s,int mode); /* 0 OFF, 1 table, 2 RANDOM */
void arp_table_turn(arp_state *s,int d);   /* Blue knob on the play page: OFF < table presets < RANDOM. */
unsigned arp_note_count(const arp_state *s);
void arp_output_off(int id);
int arp_output_on(int mode,int note,int key,int velocity);
#endif
