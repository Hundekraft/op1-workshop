/* quad LFO DSP shared by lfo/quadlfo.c (the quad feature) and screens/mlfo.c (the master LFO): the 128-bit word
 * format, rates, tempo divisions, waveforms, smoothing, LFO -> LFO modulation and the state step. Moved here unchanged
 * from quadlfo.c. The includer defines TEMPO_RATE() (and OP1_SINE_TABLE via op1_synth.h) first.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef QL_DSP_H
#define QL_DSP_H
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"
enum { QL_SYNTH = 0, QL_ENV = 1, QL_FX = 2 };

enum { QT_VOICE, QT_FREE, QT_GATE, QT_MONO, QT_1SHT, QT_RAND, QT_N };
#define QL_NTGT 24                                           /* 12 knob / env / fx targets + 4 LFOs x 3 */
#define QL_MARK 0xA5
/* The marker byte (bits 120..127) is also the per-LFO mute (2026-11): the quad family is (b & 0xB2) == 0xA0, i.e. bit 7
 * and 5 set, 6 free, 4 clear, 1 clear (0xA7 = pond has it set), and bits 6, 3, 2, 0 are the mutes of LFO 4, 3, 2, 1:
 * an LFO is muted when its bit differs from QL_MARK's (0xA5 = no LFO muted, so every earlier save reads as before). */
static const uint8_t ql_mute_bit[4] = { 0x01, 0x04, 0x08, 0x40 };
static inline int ql_mark_quad(unsigned hi) { return (hi & 0xB2) == 0xA0; }
#define POND_MARK 0xA7                                       /* pond LFO words (lfo/ql_pond.h, only compiled with QL_POND) */

/* waves 0..5 as ever, 6 / 7 the Lorenz attractor's x / z (ql_lorenz); 8..9 are free, 10..13 are the pond's four species
 * (set by the pond's decode, never stored in quad words, whose wave field is 3 bits) */
typedef struct { uint8_t wave, sync, smooth, off, rate, type, tgt, tl, tk; int8_t amt; int16_t a128; uint32_t inc, phoff; uint8_t chaos, mute; } ql_lfo;
/* lx, ly, lz: the Lorenz state Q16 (lz 0 = start) or, for the pond, three of its four populations (Q20; lz 0 = start);
 * d1: the pond's fourth population */
/* sv: the slewed waveform value; val: what everything reads = sv scaled by the mute gain (1 - mc / 32768; mc 0 = not
 * muted, so val == sv and a state at rest is unmuted); mc moves towards 32768 (muted) or 0 in ql_step */
typedef struct { uint32_t ph, cnt; int16_t val, rnd, sv; uint16_t mc; uint8_t done; int32_t lx, ly, lz, d1; } ql_st;

/* op1r <= 15 quad words: a 0x4000 / 0x6000 marker in each of words 4..7. Not decoded any more, but still a quad LFO
 * (never handed to the MIDI LFO code, whose range asserts would lock the OP-1): they read as defaults (silent) and
 * become the current format, all four LFOs at defaults, on the first edit. */
static inline int ql_old_ctrl(int16_t c) { uint16_t m = (uint16_t)c & 0xE000; return m == 0x4000 || m == 0x6000; }
static int ql_is_old(const int16_t *w)
{
    return !ql_mark_quad((uint16_t)w[7] >> 8) && ((uint16_t)w[7] >> 8) != POND_MARK && ql_old_ctrl(w[4]) && ql_old_ctrl(w[5]) && ql_old_ctrl(w[6]) && ql_old_ctrl(w[7]);
}
/* bit stream over the 8 words */
static uint32_t ql_get(const int16_t *w, int pos, int n)
{
    uint32_t v = 0;
    for (int k = 0; k < n; k++, pos++) v |= (uint32_t)(((uint16_t)w[pos >> 4] >> (pos & 15)) & 1) << k;
    return v;
}
static void ql_put(int16_t *w, int pos, int n, uint32_t v)
{
    for (int k = 0; k < n; k++, pos++) {
        uint16_t m = (uint16_t)(1u << (pos & 15)), x = (uint16_t)w[pos >> 4];
        w[pos >> 4] = (int16_t)((v >> k) & 1 ? x | m : x & ~m);
    }
}
static int clampq(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

/* Time unit: a "block" is 128 output frames (2.9 ms), the unit of every rate, smoothing and the metronome's TEMPO_RATE
 * (verified 207,768,640 at 125 BPM = 8 cycles a beat over 128-frame blocks). R246 calls the LFO once per render call,
 * 64 output frames (1.451 ms, 689 a second; a voice's 128 samples at 88.2 kHz): half a block, QL_CALL_K. Until
 * 2026-11-03 a call stepped a whole block, so every LFO ran 2x fast (free 0.1 .. 40 Hz, a synced 1/4 two cycles a beat). */
#define QL_CALL_K 32768u                                     /* one R246 render call, in blocks (Q16) */

/* tempo divisions (cycle length): shift of the metronome rate (8 cycles per beat), triplet = x 3/2 */
#define QL_DIVS 11
static const char *const ql_div_name[QL_DIVS] = { "4/1", "2/1", "1/1", "1/2", "1/4", "1/4T", "1/8", "1/8T", "1/16", "1/16T", "1/32" };
static const uint8_t ql_div_shift[QL_DIVS] = { 7, 6, 5, 4, 3, 3, 2, 2, 1, 1, 0 };

/* phase increment per block (128 output frames): 0.05 Hz * 400^(x/32768) */
static uint32_t ql_inc(int32_t x)
{
    if (x < 0) x = 0;
    if (x > 32767) x = 32767;
    int32_t oct = (x * 17702) >> 10;                              /* x * log2(400) / 32768, Q16 */
    int32_t f = oct & 0xFFFF;                                     /* 2^f ~ 1 + f (0.6565 + 0.3435 f) */
    uint32_t frac = 65536 + (((uint32_t)f * (uint32_t)(43025 + ((f * 22511) >> 16))) >> 16);   /* < 2^32 */
    uint32_t base = 623203;                                       /* 0.05 Hz * 2^32 * 128 / 44100 (a block) */
    return (uint32_t)(((uint64_t)base * frac) >> 16) << (oct >> 16);
}
static uint32_t ql_div_inc(int r)                                /* tempo division r (cycle length) */
{
    if (r >= QL_DIVS) r = QL_DIVS - 1;
    uint32_t inc = TEMPO_RATE() >> ql_div_shift[r];
    return (r == 5 || r == 7 || r == 9) ? inc + (inc >> 1) : inc;   /* triplets: 3 per 2 */
}
/* waveform value, Q15 */
static int32_t ql_shape(int wave, uint32_t phase, uint32_t cnt, int i)
{
    switch (wave) {
    case 1: { int32_t q = (int32_t)((phase + 0x40000000u) >> 16); return (q < 32768 ? q : 65535 - q) * 2 - 32767; }
    case 2: return (int32_t)phase >> 16;
    case 3: return ~((int32_t)phase >> 16);                       /* -32768 .. 32767 */
    case 4: return phase < 0x80000000u ? 32767 : -32767;
    case 5: { uint32_t x = (cnt + (uint32_t)i * 0x9E37u) * 2654435761u; x ^= x >> 15; return (int16_t)(x >> 16); }
    default: return OP1_SINE_TABLE[phase >> 19];                  /* sin(2 pi phase / 2^32) */
    }
}
/* Lorenz attractor: dx = 10 (y - x), dy = x (rho - z) - y, dz = x y - 8/3 z; state Q16, products from Q8 copies (no
 * 64-bit multiply). adv = phase advance of this step (2^32 = one LFO cycle = one wing loop ~ 0.7 time units); Euler
 * sub-steps of <= 0.01, at most 16 (faster: slowed down). rho_k 0..7 = 28 .. 14 (from 24 down it settles into a wing,
 * faster the lower). Returns Q15. Imported from op1r-src 8c89498 (xoza), see PROVENANCE.md. Bounds: the state is
 * reset (a start point, x offset by the random start) when |x|, |y| > 100, z > 100 or z <= 0; the real attractor stays
 * within |x| < 25, |y| < 30, 0 < z < 55 at every rho 14..28 (harness/quadlfo_test.c runs it long at every setting and
 * counts the resets: none). Every product stays inside 32 bit at the reset limits. The two divisions run once per
 * render call (not per sample). */
#define QL_L1 65536
static int32_t ql_lorenz(ql_st *s, uint32_t adv, int rho_k, int out_z, int rnd_start)
{
    if (!s->lz || s->lx > 100 * QL_L1 || s->lx < -100 * QL_L1 || s->ly > 100 * QL_L1 || s->ly < -100 * QL_L1 ||
        s->lz > 100 * QL_L1 || s->lz < 0) {                          /* start / runaway (products stay in 32 bit) */
        s->lx = QL_L1 + (rnd_start ? (s->rnd & 0x3FFF) * 16 : 0); s->ly = QL_L1; s->lz = 20 * QL_L1;
    }
    uint32_t dt = (uint32_t)(((adv >> 8) * 179u) >> 16);          /* time units Q16: adv / 2^32 * 0.7 * 2^16 */
    int n = (int)((dt + 654) / 655);                                /* sub-steps of <= 0.01 */
    if (n > 16) { n = 16; dt = 16 * 655; }
    int32_t h = n ? (int32_t)(dt / (uint32_t)n) : 0, rho = (28 * 256) - (rho_k & 7) * 512;   /* Q8: 28 .. 14 */
    int32_t x = s->lx, y = s->ly, z = s->lz;
    for (int k = 0; k < n; k++) {
        int32_t xs = x >> 8, ys = y >> 8, zs = z >> 8;
        int32_t dx = 10 * (y - x), dy = xs * (rho - zs) - y, dz = xs * ys - ((z >> 8) * 683);
        x += ((dx >> 8) * h) >> 8; y += ((dy >> 8) * h) >> 8; z += ((dz >> 8) * h) >> 8;   /* (truncating: rounding the tiny slow-rate steps trapped the orbit in one wing in 2 of 88 sweep runs) */
    }
    s->lx = x; s->ly = y; s->lz = z;
    int32_t v = out_z ? (((z - 24 * QL_L1) >> 4) * 1638) >> 12 : ((x >> 4) * 1638) >> 12;   /* x / 20, (z - 24) / 20 */
    return v > 32767 ? 32767 : v < -32767 ? -32767 : v;
}
/* one-pole slew towards x; k = elapsed blocks Q16. Smoothing sm moves 2^-sm of the way per block; per R246 call
 * (half a block) that is 1 - sqrt(1 - 2^-sm) (Q16, ql_slew_c), scaled with k for other elapsed times */
static const uint16_t ql_slew_c[8] = { 0, 19195, 8780, 4233, 2081, 1032, 514, 257 };
static int16_t ql_slew(int16_t y, int32_t x, int sm, uint32_t k)
{
    if (!sm) return (int16_t)x;
    if (k > 64u << 16) k = 64u << 16;                             /* blocks_q16's cap */
    k = k == QL_CALL_K ? ql_slew_c[sm & 7] : (ql_slew_c[sm & 7] * (k >> 6)) >> 9;
    if (k >= 65536) return (int16_t)x;
    int32_t d = x - y;                                            /* |d| < 2^16 */
    if (k <= 32768) return (int16_t)(y + ((d * (int32_t)k + 32768) >> 16));   /* fits 32 bit; rounded, so the per-call
                                                                          * step leaves no wider dead band */
    return (int16_t)(y + (int32_t)(((int64_t)d * (int32_t)k + 32768) >> 16));
}
/* (a * k) >> 16 mod 2^32, exact, without a 64-bit multiply (libgcc on the Blackfin) */
static inline uint32_t ql_mulq16(uint32_t a, uint32_t k)
{
    uint32_t kl = k & 0xFFFF;
    return a * (k >> 16) + (a >> 16) * kl + (((a & 0xFFFF) * kl) >> 16);
}

static inline int16_t ql_out(int16_t val, int a128) { return (int16_t)(((int32_t)val * a128) >> 7); }

/* decode / encode LFO i (bit stream, see top) */
static const uint8_t ql_def_rate[4] = { 19, 31, 42, 54 };       /* ~0.3 / 1 / 3 / 8 Hz (= make_firmware.py defaults) */
#ifdef QL_POND
static int ql_is_pond(const int16_t *w);
static void pond_dec(const int16_t *w, int i, ql_lfo *o);
#endif
static void ql_dec(const int16_t *w, int i, ql_lfo *o)
{
#ifdef QL_POND
    if (ql_is_pond(w)) { pond_dec(w, i, o); return; }
#endif
    if (ql_is_old(w)) {                                           /* old format: defaults, amount 0 */
        o->rate = ql_def_rate[i]; o->sync = 0; o->wave = 0; o->smooth = 0; o->off = 0; o->type = QT_VOICE;
        o->tgt = (uint8_t)i; o->tl = o->tk = 0; o->amt = 0; o->a128 = 0; o->chaos = 0; o->mute = 0; o->inc = ql_inc((o->rate << 9) | 0x100); o->phoff = 0;
        return;
    }
    int b = 30 * i;
    o->chaos = 0;
    { unsigned hi = (uint16_t)w[7] >> 8; o->mute = (uint8_t)(ql_mark_quad(hi) && ((hi ^ QL_MARK) & ql_mute_bit[i & 3]) != 0); }
    o->rate = (uint8_t)ql_get(w, b, 6); o->sync = (uint8_t)ql_get(w, b + 6, 1);
    o->wave = (uint8_t)ql_get(w, b + 7, 3); o->smooth = (uint8_t)ql_get(w, b + 10, 3);
    o->off = (uint8_t)ql_get(w, b + 13, 3); o->type = (uint8_t)clampq((int)ql_get(w, b + 16, 3), 0, QT_N - 1);
    o->tgt = (uint8_t)clampq((int)ql_get(w, b + 19, 5), 0, QL_NTGT - 1);
    o->tl = o->tgt >= 12 ? (uint8_t)((o->tgt - 12) / 3) : 0; o->tk = o->tgt >= 12 ? (uint8_t)((o->tgt - 12) % 3) : 0;
    o->amt = (int8_t)clampq((int)ql_get(w, b + 24, 6) - 32, -31, 31); o->a128 = (int16_t)(o->amt * 127 / 31);
    if (o->sync) o->rate = (uint8_t)clampq(o->rate, 0, QL_DIVS - 1);
    o->inc = o->sync ? ql_div_inc(o->rate) : ql_inc((o->rate << 9) | 0x100);
    o->phoff = (uint32_t)o->off << 29;
}
static void ql_enc(const ql_lfo *o, int16_t *w, int i)
{
    int b = 30 * i;
    ql_put(w, b, 6, o->rate); ql_put(w, b + 6, 1, o->sync); ql_put(w, b + 7, 3, o->wave); ql_put(w, b + 10, 3, o->smooth);
    ql_put(w, b + 13, 3, o->off); ql_put(w, b + 16, 3, o->type); ql_put(w, b + 19, 5, o->tgt);
    ql_put(w, b + 24, 6, (uint32_t)(o->amt + 32));
    unsigned hi = ql_get(w, 120, 8), bit = ql_mute_bit[i & 3];     /* the marker keeps the other LFOs' mutes */
    if (!ql_mark_quad(hi)) hi = QL_MARK;
    hi = (hi & ~bit) | ((QL_MARK & bit) ^ (o->mute ? bit : 0));
    ql_put(w, 120, 8, hi);
}
/* Shift + push: toggle LFO i's mute in the words */
static void ql_toggle_mute(int16_t *w, int i)                 /* only the marker's bit flips: the LFO's own fields stay as stored */
{
    unsigned hi = ql_get(w, 120, 8);
    if (!ql_mark_quad(hi)) hi = QL_MARK;
    ql_put(w, 120, 8, hi ^ ql_mute_bit[i & 3]);
}
/* LFO -> LFO modulation: src[i] = LFO i's value (before amount) in this context, from the previous block */
static void ql_mod(ql_lfo *L, const int16_t *src)
{
    int32_t acc[4][3] = { { 0 } };
    for (int i = 0; i < 4; i++)
        if (L[i].tgt >= 12 && L[i].tl != i) acc[L[i].tl][L[i].tk] += ql_out(src[i], L[i].a128);
    for (int j = 0; j < 4; j++) {
        int32_t f = clampq(acc[j][0], -32767, 32767), a = clampq(acc[j][1], -32767, 32767), o = clampq(acc[j][2], -32767, 32767);
        if (f) {                                                      /* 2^(f * 2 / 32768) octaves */
            int32_t x = f * 4, e = x >> 16, fr = x & 0xFFFF;         /* Q16 octaves: integer + fraction */
            uint32_t m = 65536 + (((uint32_t)fr * (uint32_t)(43025 + ((fr * 22511) >> 16))) >> 16);
            uint64_t inc = ((uint64_t)L[j].inc * m) >> 16;
            inc = e >= 0 ? inc << e : inc >> -e;
            L[j].inc = inc > 0x7FFFFFFFu ? 0x7FFFFFFFu : (uint32_t)inc;
        }
        if (a) L[j].a128 = (int16_t)clampq((L[j].a128 * (32768 + a)) >> 15, -127, 127);
        if (o) L[j].phoff += (uint32_t)o << 16;
    }
}

static inline int ql_group(const ql_lfo *o) { return o->tgt >> 2; }
static inline int ql_dest(const ql_lfo *o)  { return o->tgt & 3; }

#ifdef QL_POND
#include "ql_pond.h"
#endif
/* advance one state by k blocks (Q16) */
static void ql_step(ql_st *s, const ql_lfo *o, uint32_t k, int i)
{
    int32_t x;
    if (o->type == QT_RAND && o->wave < 6) x = s->rnd;               /* RAND: held value; Lorenz: a random start */
    else {
        uint32_t adv = 0;
        if (!(o->type == QT_1SHT && s->done)) {
            adv = k == QL_CALL_K ? o->inc >> 1 : k == 65536 ? o->inc : ql_mulq16(o->inc, k);
            uint32_t n = s->ph + adv;
            if (n < s->ph) { s->cnt++; if (o->type == QT_1SHT) { s->done = 1; n = 0xFFFFFFFFu; } }
            s->ph = n;
        }
#ifdef QL_POND
        if (o->wave >= 10) x = pond_lv(s, o, adv, i); else
#endif
        x = o->wave >= 6 ? ql_lorenz(s, adv, o->off, o->wave == 7, o->type == QT_RAND) : ql_shape(o->wave, s->ph + o->phoff, s->cnt, i);
    }
    s->sv = ql_slew(s->sv, x, o->smooth, k);
    if (o->mute || s->mc) {                                          /* the mute gain: 46 ms (32 calls) from end to end */
        uint32_t d = k >> 5;
        if (d > 32768u) d = 32768u;
        if (!d) d = 1;
        s->mc = (uint16_t)(o->mute ? (s->mc + d > 32768u ? 32768u : s->mc + d) : (s->mc > d ? s->mc - d : 0));
    }
    s->val = s->mc ? (int16_t)(((int32_t)s->sv * (int32_t)(32768 - s->mc)) >> 15) : s->sv;
}
static int wrapq(int v, int n) { return ((v % n) + n) % n; }
#pragma GCC diagnostic pop
#endif
