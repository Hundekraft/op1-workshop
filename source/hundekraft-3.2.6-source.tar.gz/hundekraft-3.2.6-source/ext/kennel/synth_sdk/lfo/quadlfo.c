/* "quad" LFO: four LFOs in one LFO slot (8 waveforms, tempo sync, smoothing, phase offset, 6 types), each routed to a
 * synth / drum engine knob, an envelope stage or an FX knob.
 *
 * Runs in the MIDI LFO class (lfo type 4): the DB row "quad" resolves to it via the lfo_types name compare hook, and
 * the MIDI LFO vtable apply / trigger entries are redirected here (hook.S, make_firmware.py). Anything without the
 * quad marker keeps the original MIDI LFO code.
 *
 * Parameter words (8 x 16 bit, saved with the patch) = one 128-bit little-endian bit stream (bit 0 = w[0] bit 0):
 *   bits 0..119   4 LFOs x 30 bits, LFO i at bit 30 i:  rate 6 | sync 1 | wave 3 | smooth 3 | offset 3 | type 3 |
 *                 target 5 | amount 6 (+32)
 *                 rate 0..63: free 0.05 .. 20 Hz (exponential), sync: tempo division index (QL_DIVS)
 *                 wave 0 sine, 1 triangle, 2 ramp up, 3 ramp down, 4 square, 5 sample & hold, 6 lorenz x, 7 lorenz z
 *                 (Lorenz attractor: one wing loop per cycle, the offset field is the chaos rho 28 .. 14; added 2026-11,
 *                 saved sounds with waves 0..5 read as before)
 *                 smooth 0..7: one-pole slew, 2^smooth blocks; offset 0..7: start phase in 1/8 cycles
 *                 amount -31..31 (full = +-32767); type see QT_*
 *                 target 0..11: synth (drum) knob blue..red, envelope A D S R, FX knob blue..red;
 *                 12..23: LFO j (0..3) x (frequency, amount, phase offset) = 12 + 3 j + k (not its own: skipped
 *                 by the white encoder, ignored if stored - a self target alone would reach no knob)
 *   bits 120..127 marker 0xA5 (w[7] = 0xA5xx, negative: never a stock MIDI LFO word) = no LFO muted. Shift + push mutes one
 *                 LFO: its bit in the marker flips (ql_dsp.h: family (b & 0xB2) == 0xA0, bits 6 / 3 / 2 / 0 = LFO 4 / 3 / 2 / 1)
 * Older quad formats (op1r <= 15, per-word markers) are not read any more.
 * LFO targets (modulation from the modulator's value of the previous block, so order and feedback are harmless):
 *   frequency  x 2^(+-2 octaves) at full amount;  amount  x (0 .. 2);  phase offset  +-1/2 cycle.
 *   Several LFOs on the same target add up. The modulator's own amount scales its effect.
 * Types: VOIC  per-voice phase, runs while the voice plays (never reset)
 *        FREE  one shared free-running phase
 *        GATE  per-voice phase, restarts at the voice's note-on
 *        MONO  shared phase, restarts at every note-on
 *        SHOT  per voice, restarts at note-on, stops after one cycle (holds the end value)
 *        RAND  per voice, a new random value at each note-on, held
 *   FX targets and drums have no per-voice state: there VOIC = FREE, GATE = MONO, 1SHT / RAND are shared.
 * Note-on: VoiceCtl calls the voice LFO object's vt+0x1c trigger(this, words) for every synth (0x019673DC) and
 * drum (0x0196735E) note-on while the LFO is active (lfo_active); for the MIDI LFO class these are bare RTS.
 *
 * Controls on the LFO page (encoder press blue..red selects LFO 1..4; turns edit the selected one):
 *   blue frequency / division, green amount, white target (21: own F / A / O skipped, wraps), red type (6, wraps)
 *   Shift held (table of all four): blue phase offset, green smoothing, white waveform, red sync on / off
 *   Shift + push of an encoder: mute / unmute that LFO (a 46 ms gain fade, the phase keeps running; the row goes grey)
 *
 * Firmware calls (fw 246, docs/10):
 *   synth knobs   Ranges::knob_range_synth(knob, &mod, engine, 0xFF801724)   (apply pass 0)
 *   envelope      0x019F69B0(stage, &mod, 0xFF801724)                         (apply pass 1)
 *   FX knobs      0x01A1DE68(&mod, 0x01DE5C50 + fx_type*0x30 + knob*6, 0xFF801724 + knob*2)
 *                 (FX-object apply, pass 2 = synth FX, 5 = drum FX)
 *   drum knobs    Ranges 0x01A1E57C(knob, &mod, drum engine 0xFF801704[drum slot], 0xFF801724)   (pass 3)
 *   drum env      0x01A1DE68(&mod, 0x01DE56C8 + stage*6, 0xFF801724 + stage*2)                     (pass 4)
 * mod = signed Q15 offset in knob units. The firmware calls apply once per ACTIVE voice and block: per-voice LFOs
 * advance there; shared LFOs advance by elapsed time from the Blackfin CYCLES counter (block length learned from
 * the per-voice calls), so they keep running between notes (screen included). */
#include "../op1_synth.h"

#ifndef OP1_HOST
#define KNOB_RANGE_SYNTH ((void (*)(int, int16_t *, int, void *))0x01A1DFEC)
#define KNOB_RANGE_DRUM  ((void (*)(int, int16_t *, int, void *))0x01A1E57C)
#define DRUM_ENGINE()    (((const int *)0xFF801704)[*(volatile int *)0xFF8016D8 & 7])
#define DRUM_FX_TYPE()   (((const int *)0xFF801754)[*(volatile int *)0xFF8016D8 & 7])
#define DRUM_ENV_RANGE(k) ((const int16_t *)(0x01DE56C8 + (k) * 6))
#define FX_KNOB_MOD      ((void (*)(int16_t *, const int16_t *, int16_t *))0x01A1DE68)   /* (&mod, range, &param) */
#define FX_RANGE(type, k) ((const int16_t *)(0x01DE5C50 + (type) * 0x30 + (k) * 6))
#define FX_PARAM(k)      ((int16_t *)0xFF801724 + (k))
#define ENV_MOD          ((void (*)(int, int16_t *, void *))0x019F69B0)
#define STAGE_PARAMS     ((void *)0xFF801724)
#define SYNTH_LFO_OBJ    ((void *const *)0x01AAAD6C)          /* [6] per-voice LFO objects */
#define SYNTH_ENGINE()   (((const int *)0xFF8016E4)[*(volatile int *)0xFF8016D4 & 7])
#define SYNTH_FX_TYPE()  (((const int *)0xFF801734)[*(volatile int *)0xFF8016D4 & 7])
#define PAGE_POS()       (*(volatile int *)0x01DE4C40 == 1)
#define PAGE_WORDS(pos)  ((const int16_t *)(((pos) ? 0xFF801644 : 0xFF8014C4) + \
                          (*(volatile int *)((pos) ? 0xFF8016D8 : 0xFF8016D4) & 7) * 16))
#define TEMPO_RATE()     (*(volatile uint32_t *)0x01AADAD4)   /* metronome: phase inc per 128-frame block (two calls), 8 cycles per beat */
#define SHIFT_HELD()     (*(volatile uint8_t *)0x01DD7F78)
/* LFO switched on (Shift + T4) in the current slot: synth 0x01AAAC28[synth slot], drum 0x01AAAC38[drum slot 0x01AAAC10]
 * (getters 0x0196726C / 0x0196724C; the stock note-on 0x019673DC / 0x0196735E checks the same bytes) */
#define LFO_ON(pos)      (((volatile uint8_t *)((pos) ? 0x01AAAC38 : 0x01AAAC28))[(pos) ? (*(volatile int *)0x01AAAC10 & 7) \
                                                                                        : (*(volatile int *)0xFF8016D4 & 7)])
#else                                                          /* host test: harness/quadlfo_test.c */
void host_knob_range_synth(int, int16_t *, int, void *);
void host_fx_knob_mod(int16_t *, const int16_t *, int16_t *);
extern int16_t host_fx_range[8][3], host_fx_params[8];
void host_env_mod(int, int16_t *, void *);
extern void *host_lfo_obj[6];
extern int16_t host_lfo_words[8];
#define KNOB_RANGE_SYNTH host_knob_range_synth
void host_knob_range_drum(int, int16_t *, int, void *);
#define KNOB_RANGE_DRUM  host_knob_range_drum
#define DRUM_ENGINE()    3
#define DRUM_FX_TYPE()   5
#define DRUM_ENV_RANGE(k) ((const int16_t *)host_fx_range[k])
#define FX_KNOB_MOD      host_fx_knob_mod
#define FX_RANGE(type, k) ((void)(type), (const int16_t *)host_fx_range[k])
#define FX_PARAM(k)      (&host_fx_params[k])
#define ENV_MOD          host_env_mod
#define STAGE_PARAMS     ((void *)0)
#define SYNTH_LFO_OBJ    ((void *const *)host_lfo_obj)
#define SYNTH_ENGINE()   14
#define SYNTH_FX_TYPE()  5
#define PAGE_POS()       (host_pos)
#define PAGE_WORDS(pos)  ((const int16_t *)host_lfo_words)
extern uint32_t host_cycles, host_tempo_rate; extern uint8_t host_shift; extern int host_pos;
#define TEMPO_RATE()     (host_tempo_rate)
#define SHIFT_HELD()     (host_shift)
extern int host_lfo_on[2];
#define LFO_ON(pos)      (host_lfo_on[pos])
#define READ_CYCLES()    (host_cycles)
#endif
#ifndef READ_CYCLES
static inline uint32_t READ_CYCLES(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
#endif
#define QL_POND                                              /* the pond LFO (ql_pond.h) rides in this file's code */
#include "ql_dsp.h"                                          /* word format and DSP (shared with the master LFO) */

static const char *const ql_type_name[QT_N] = { "VOIC", "FREE", "GATE", "MONO", "SHOT", "RAND" };

static ql_st sh_st[2][4];                                     /* shared state per page (synth, drum) */
static ql_st v_st[6][4];                                      /* per synth voice */
static volatile int16_t disp_all[2][4];                       /* last per-voice output (before amount), screen */
static volatile uint32_t ph_cyc_all[2];                       /* CYCLES at the last shared update per page */
static volatile uint32_t cpb = 1161000;                       /* cycles per block, two render calls (learned; start: 400 MHz) */
static uint32_t voice_cyc[6];
static uint32_t ql_rng = 0x9E3779B9u;
volatile uint8_t ql_sel[2];                                   /* selected LFO per page (synth/drum) */

/* ql_is_quad: words this code runs (quad or pond); ql_match_quad / ql_match_pond: one type's own words (the two
 * op1_lfo_types in plugins/quad/quad_feature.c) */
int ql_match_quad(const int16_t *w) { return ql_mark_quad((uint16_t)w[7] >> 8) || ql_is_old(w); }
int ql_match_pond(const int16_t *w) { return ql_is_pond(w); }
int ql_is_quad(const int16_t *w) { return ql_match_quad(w) || ql_match_pond(w); }

/* shared state (no per-voice phase): drums, FX targets, FREE and MONO */
static inline int ql_shared(int pos, const ql_lfo *o) { return pos || ql_group(o) == QL_FX || o->type == QT_FREE || o->type == QT_MONO; }

static void ql_restart(ql_st *s)
{
    s->ph = 0; s->done = 0; s->cnt++;
    ql_rng = ql_rng * 1664525u + 1013904223u; s->rnd = (int16_t)(ql_rng >> 16);
    s->lz = 0;                                                       /* Lorenz / pond: from the start point again */
}

/* elapsed time since `since` in blocks, Q16 (capped at 64 blocks: no jumps after long pauses) */
static uint32_t blocks_q16(uint32_t now, uint32_t since)
{
    uint32_t d = now - since, c = cpb;
    if (d > 64 * c) d = 64 * c;
    return (uint32_t)(((uint64_t)d << 16) / c);
}
/* advance the shared states of a page to now (audio thread) */
static void ql_advance_pos(int pos, const ql_lfo *L)
{
    uint32_t now = READ_CYCLES();
    if (now - ph_cyc_all[pos] < (cpb >> 2)) return;              /* already advanced this call (other voice / pass) */
    uint32_t b = blocks_q16(now, ph_cyc_all[pos]);
    ph_cyc_all[pos] = now;
    ql_pg = (uint8_t)pos;                                         /* the pond's trail of this page */
    for (int i = 0; i < 4; i++) ql_step(&sh_st[pos][i], &L[i], b, i);
}
static void ql_dec_all(const int16_t *w, ql_lfo *L) { for (int i = 0; i < 4; i++) ql_dec(w, i, &L[i]); }
/* decoded + LFO-modulated parameters for the shared states of a page (src: shared values, per-voice LFOs: last voice) */
static void ql_dec_shared(const int16_t *w, int pos, ql_lfo *L)
{
    int16_t src[4];
    ql_dec_all(w, L);
    for (int i = 0; i < 4; i++) src[i] = ql_shared(pos, &L[i]) ? sh_st[pos][i].val : disp_all[pos][i];
    ql_mod(L, src);
}

/* audio thread: the words decoded once per change (per page), not per voice / pass / block. has_mod: some LFO
 * targets another one (the copies then get ql_mod). Synced rates follow the tempo, so they are refreshed. */
static struct { int16_t w[8]; uint8_t valid, has_mod, any_sync; ql_lfo L[4]; } qc[2];
static const ql_lfo *ql_cached(const int16_t *w, int pos)
{
    int i, same = qc[pos].valid;
    for (i = 0; same && i < 8; i++) same = qc[pos].w[i] == w[i];
    if (!same) {
        for (i = 0; i < 8; i++) qc[pos].w[i] = w[i];
        ql_dec_all(qc[pos].w, qc[pos].L);
        qc[pos].has_mod = qc[pos].any_sync = 0;
        for (i = 0; i < 4; i++) {
            if (qc[pos].L[i].tgt >= 12 && qc[pos].L[i].tl != i && qc[pos].L[i].a128) qc[pos].has_mod = 1;
            if (qc[pos].L[i].sync) qc[pos].any_sync = 1;
        }
        qc[pos].valid = 1;
    } else if (qc[pos].any_sync)
        for (i = 0; i < 4; i++) if (qc[pos].L[i].sync) qc[pos].L[i].inc = ql_div_inc(qc[pos].L[i].rate);
    return qc[pos].L;
}
/* cached parameters, LFO-modulated into buf when needed; src: shared values, per-voice LFOs from v_st[v] (v >= 0) or
 * the last voice (v < 0) */
static const ql_lfo *ql_params(const int16_t *w, int pos, int v, ql_lfo *buf)
{
    const ql_lfo *C = ql_cached(w, pos);
    if (!qc[pos].has_mod) return C;
    int16_t src[4];
    for (int i = 0; i < 4; i++) {
        buf[i] = C[i];
        src[i] = ql_shared(pos, &C[i]) ? sh_st[pos][i].val : (v >= 0 ? v_st[v][i].val : disp_all[pos][i]);
    }
    ql_mod(buf, src);
    return buf;
}

int ql_apply_synth(void *self, const int16_t *w, int pass)
{
    if (pass != 0 && pass != 1) return 0;                         /* synth knobs 0, envelope 1: nothing else here */
    if (!LFO_ON(0)) return 0;
    int engine = SYNTH_ENGINE();
    int applied = 0, v = 0;
    for (int k = 0; k < 6; k++) if (SYNTH_LFO_OBJ[k] == self) { v = k; break; }
    ql_lfo Lb[4], Lvb[4];
    const ql_lfo *L = ql_params(w, 0, -1, Lb);                    /* shared states' parameters */
    const ql_lfo *Lv = ql_params(w, 0, v, Lvb);                   /* this voice's parameters (its own LFO values) */
    if (pass == 0) {
        /* learn the block length: each voice object is called once per render call (half a block) while active */
        uint32_t now = READ_CYCLES(), d = 2 * (now - voice_cyc[v]);
        if (d > cpb / 2 && d < cpb * 2) cpb += ((int32_t)(d - cpb)) / 16;
        voice_cyc[v] = now;
        ql_advance_pos(0, L);
        for (int i = 0; i < 4; i++) if (!ql_shared(0, &Lv[i])) { ql_step(&v_st[v][i], &Lv[i], QL_CALL_K, i); disp_all[0][i] = v_st[v][i].val; }
    }
    for (int i = 0; i < 4; i++) {
        int sh = ql_shared(0, &L[i]), g = ql_group(&L[i]);
        int a128 = sh ? L[i].a128 : Lv[i].a128;
        if (!a128 || g == QL_FX || L[i].tgt >= 12) continue;
        int16_t mod = ql_out(sh ? sh_st[0][i].val : v_st[v][i].val, a128);
        if (g == QL_SYNTH && pass == 0) { KNOB_RANGE_SYNTH(ql_dest(&L[i]), &mod, engine, STAGE_PARAMS); applied = 1; }
        else if (g == QL_ENV && pass == 1) { ENV_MOD(ql_dest(&L[i]), &mod, STAGE_PARAMS); applied = 1; }
    }
    return applied;
}

/* drums: pass 3 = drum engine knobs (per drum voice), pass 4 = drum envelope. Shared states by elapsed time. */
static int ql_drum(const int16_t *w, int pass)
{
    if (pass != 3 && pass != 4) return 0;
    if (!LFO_ON(1)) return 0;
    ql_lfo Lb[4]; const ql_lfo *L = ql_params(w, 1, -1, Lb);
    ql_advance_pos(1, L);
    int engine = DRUM_ENGINE(), applied = 0;
    for (int i = 0; i < 4; i++) {
        int g = ql_group(&L[i]);
        if (!L[i].a128 || g == QL_FX || L[i].tgt >= 12) continue;
        int16_t mod = ql_out(sh_st[1][i].val, L[i].a128);
        int k = ql_dest(&L[i]);
        if (g == QL_SYNTH && pass == 3) { KNOB_RANGE_DRUM(k, &mod, engine, STAGE_PARAMS); applied = 1; }
        else if (g == QL_ENV && pass == 4) { FX_KNOB_MOD(&mod, DRUM_ENV_RANGE(k), FX_PARAM(k)); applied = 1; }
    }
    return applied;
}
int ql_apply_drum(void *self, const int16_t *w, int pass) { (void)self; return ql_drum(w, pass); }

int ql_apply_fx(void *self, const int16_t *w, int pass)
{
    (void)self;
    if (pass == 3 || pass == 4) return ql_drum(w, pass);         /* drum engine / envelope via this object */
    if (pass != 2 && pass != 5) return 0;                         /* 2 = synth FX, 5 = drum FX */
    int pos = pass == 5;
    if (!LFO_ON(pos)) return 0;
    int fxtype = pos ? DRUM_FX_TYPE() : SYNTH_FX_TYPE();
    int applied = 0;
    ql_lfo Lb[4]; const ql_lfo *L = ql_params(w, pos, -1, Lb);
    ql_advance_pos(pos, L);
    for (int i = 0; i < 4; i++) {
        if (ql_group(&L[i]) != QL_FX || L[i].tgt >= 12 || !L[i].a128) continue;
        int16_t mod = ql_out(sh_st[pos][i].val, L[i].a128);
        int k = ql_dest(&L[i]);
        FX_KNOB_MOD(&mod, FX_RANGE(fxtype, k), FX_PARAM(k));
        applied = 1;
    }
    return applied;
}

/* note-on (LFO object vt+0x1c, called by VoiceCtl for each note-on; v = synth voice, -1 = drums) */
static void ql_trigger(int pos, int v, const int16_t *w)
{
    for (int i = 0; i < 4; i++) {
        ql_lfo o; ql_dec(w, i, &o);
        if (v >= 0 && !ql_shared(pos, &o)) v_st[v][i].mc = o.mute ? 32768 : 0;   /* a voice starts at its LFO's mute state */
        if (o.type == QT_VOICE || o.type == QT_FREE) continue;
        if (ql_shared(pos, &o)) ql_restart(&sh_st[pos][i]);
        else if (v >= 0) ql_restart(&v_st[v][i]);
    }
}
void ql_trig_synth(void *self, const int16_t *w)
{
    if (!ql_is_quad(w)) return;                                   /* MIDI LFO: original is a bare RTS */
    int v = -1;
    for (int k = 0; k < 6; k++) if (SYNTH_LFO_OBJ[k] == self) { v = k; break; }
    ql_trigger(0, v, w);
}
void ql_trig_drum(void *self, const int16_t *w) { (void)self; if (ql_is_quad(w)) ql_trigger(1, -1, w); }
void ql_trig_fx(void *self, const int16_t *w) { (void)self; (void)w; }   /* shared restarts happen in the voice trigger */

/* ---- controls (KeyHandler thread, via dispatcher.c key/knob hooks) ---- */
static int32_t step_acc[4];
void ql_press(int pos, int knob) { ql_sel[pos & 1] = (uint8_t)(knob & 3); }
static int ql_steps(int knob, int delta)                          /* one step per detent (1024) */
{
    int32_t *acc = &step_acc[knob & 3];
    if ((*acc > 0 && delta < 0) || (*acc < 0 && delta > 0)) *acc = 0;
    *acc += delta;
    int st = *acc / 1024;
    *acc -= st * 1024;
    return st;
}
static void pond_turn(int16_t *w, int pos, int knob, int st, int shift);
void ql_turn(int16_t *w, int pos, int knob, int delta, int shift)
{
    (void)pos;
    int i = ql_sel[pos & 1] & 3, st = ql_steps(knob, delta);
    if (shift == 2 && !delta) {                                   /* the core's Shift + push of encoder `knob` (dispatcher.c) */
        if (ql_is_pond(w) || knob < 0 || knob > 3) return;        /* pond: no per-species mute */
        if (ql_is_old(w)) {
            ql_lfo d[4];
            for (int k = 0; k < 4; k++) ql_dec(w, k, &d[k]);
            for (int k = 0; k < 8; k++) w[k] = 0;
            for (int k = 0; k < 4; k++) ql_enc(&d[k], w, k);
        }
        ql_toggle_mute(w, knob);
        return;
    }
    if (!st) return;
    if (ql_is_pond(w)) { pond_turn(w, pos, knob, st, shift); return; }
    if (ql_is_old(w)) {                                           /* first edit of an old set: all four to defaults */
        ql_lfo d[4];
        for (int k = 0; k < 4; k++) ql_dec(w, k, &d[k]);
        for (int k = 0; k < 8; k++) w[k] = 0;
        for (int k = 0; k < 4; k++) ql_enc(&d[k], w, k);
    }
    ql_lfo o; ql_dec(w, i, &o);
    if (!shift) switch (knob) {
        case 0: o.rate = (uint8_t)clampq(o.rate + st, 0, o.sync ? QL_DIVS - 1 : 63); break;
        case 1: o.amt = (int8_t)clampq(o.amt + st, -31, 31); break;
        case 2: {                                                 /* 21 targets: its own F / A / O are skipped */
            int t = o.tgt, d = st > 0 ? 1 : -1;
            for (int n = st < 0 ? -st : st; n--; )
                do t = wrapq(t + d, QL_NTGT); while (t >= 12 && (t - 12) / 3 == i);
            o.tgt = (uint8_t)t;
            break;
        }
        default: o.type = (uint8_t)wrapq(o.type + st, QT_N); break;
    } else switch (knob) {
        case 0: o.off = (uint8_t)wrapq(o.off + st, 8); break;
        case 1: o.smooth = (uint8_t)clampq(o.smooth + st, 0, 7); break;
        case 2: o.wave = (uint8_t)clampq(o.wave + st, 0, 7); break;   /* 6 / 7: Lorenz x / z */
        default:
            if (st > 0 && !o.sync) { o.sync = 1; o.rate = 4; }    /* sync on: 1/4 */
            else if (st < 0 && o.sync) { o.sync = 0; o.rate = 31; }   /* free: ~1 Hz */
    }
    ql_enc(&o, w, i);
}

/* pond controls (docs: ARCHITECTURE.md "LFO types"): presses select species 1..4 (ql_sel, as quad); blue speed, green
 * chaos, white amount, red target of the selected species; Shift: blue free / sync, green mode free / retrigger.
 * Targets 0..11 (knob, envelope, FX knob), no LFO or page-2 targets. */
static void pond_turn(int16_t *w, int pos, int knob, int st, int shift)
{
    pond_set f; pond_get(w, &f);
    int k = ql_sel[pos & 1] & 3;
    if (!shift) switch (knob) {
        case 0: f.rate = (uint8_t)clampq(f.rate + st, 0, f.sync ? QL_DIVS - 1 : 63); break;
        case 1: f.chaos = (uint8_t)clampq(f.chaos + st, 0, 31); break;
        case 2: f.amt[k] = (int8_t)clampq(f.amt[k] + st, -31, 31); break;
        default: f.tgt[k] = (uint8_t)wrapq(f.tgt[k] + st, 12); break;
    } else switch (knob) {
        case 0:
            if (st > 0 && !f.sync) { f.sync = 1; f.rate = 4; } else if (st < 0 && f.sync) { f.sync = 0; f.rate = 31; }
            break;
        case 1: f.retrig = (uint8_t)(st > 0); break;
        default: break;
    }
    pond_put(&f, w);
}

/* ======================= screen (GUI thread) =======================
 * display/quadlfo.svg (display/gen_quadlfo_svg.py, geometry in quadlfo_geom.h): per LFO a row with a dot in the
 * encoder colour and a short lane line. Code draws per row: amount span + moving output tick on the lane, then
 * frequency / division (blue), amount in % (green), target glyph (synth: wave, drum page: drum, envelope, fx) with
 * a dot in the target knob / stage colour, and the type (red). The selected row is bright with a bar under its
 * dot, the others lilac. Shift: table of all four (offset, smoothing, waveform, sync). */
#include "quadlfo_geom.h"

#include "ql_draw.h"                                         /* qline, ql_num, ql_hz_text, ql_wave_glyph */

static void ql_screen_init(void *scr) { (void)scr; }            /* no animated SVG nodes */

#include "../screens/stroke_font.h"
#define QT_OFF_X 30                                              /* Shift table columns (text top-left x) */
#define QT_SMOOTH_X 104
#define QT_WAVE_X 128
#define QT_SYNC_X 172
/* Shift held: one row per LFO: phase offset in degrees (blue), smoothing (green), waveform (white), sync (red).
 * The lane lines of the SVG are covered with black. */
static void ql_table(void *r, const int16_t *w, int sel)
{
    static const uint8_t black[4] = { 0, 0, 0, 0xFF };
    for (int i = 0; i < 4; i++) {
        int32_t y = OP1_Q10(ql_lane_y[i]), ty = y - OP1_Q10(6);
        ql_lfo o; ql_dec(w, i, &o);
        char t[8];
        qline(r, OP1_Q10(QL_LANE_X0 - 1), y, OP1_Q10(QL_LANE_X1 + 1), y, 0x600, black);
        qline(r, OP1_Q10(QL_LANE_MID), y - OP1_Q10(5), OP1_Q10(QL_LANE_MID), y + OP1_Q10(5), 0x600, black);
        if (i == sel)
            qline(r, OP1_Q10(QL_DOT_X - 7), y + OP1_Q10(10), OP1_Q10(QL_DOT_X + 7), y + OP1_Q10(10), 0x600, ql_col[i]);
        if (o.wave >= 6) { t[0] = 'R'; ql_num(t + 1, 28 - 2 * o.off); }   /* Lorenz: the offset field is the chaos rho 28 .. 14 */
        else ql_num(t, o.off * 45);
        const uint8_t *c0 = o.mute ? ql_dim : ql_col[0], *c1 = o.mute ? ql_dim : ql_col[1], *c2 = o.mute ? ql_dim : ql_col[2];
        sf_text(r, OP1_Q10(QT_OFF_X), ty, OP1_Q10(2), t, 0x400, c0);
        ql_num(t, o.smooth);
        sf_text(r, OP1_Q10(QT_SMOOTH_X), ty, OP1_Q10(2), t, 0x400, c1);
        ql_wave_glyph(r, o.wave, OP1_Q10(QT_WAVE_X), y, c2);
        sf_text(r, OP1_Q10(QT_SYNC_X), ty, OP1_Q10(2), o.mute ? "MUTE" : o.sync ? "SYNC" : "FREE", 0x400,
                o.mute ? ql_dim : o.sync ? ql_col[3] : ql_dim);
    }
}

/* target glyph, 12 x 10 px, (x, y) = left end at the row centre: synth wave, drum (circle, centre dot, stick),
 * envelope (ADSR), fx */
static void ql_glyph(void *r, int pos, int g, int32_t gx, int32_t y, const uint8_t *c)
{
    if (g == QL_SYNTH && pos) {                                   /* drum: green circle, dot, line down from it */
        int32_t cx = gx + OP1_Q10(6), rr = OP1_Q10(5);
        for (int k = 0; k < 12; k++) {
            int32_t a0 = k * 8192 / 12, a1 = (k + 1) * 8192 / 12;
            qline(r, cx + (OP1_SINE_TABLE[a0] * rr >> 15), y - (OP1_SINE_TABLE[(a0 + 2048) & 8191] * rr >> 15),
                     cx + (OP1_SINE_TABLE[a1 & 8191] * rr >> 15), y - (OP1_SINE_TABLE[(a1 + 2048) & 8191] * rr >> 15), 0x300, ql_col[1]);
        }
        qline(r, cx - 0x180, y, cx + 0x180, y, 0x500, ql_col[1]);
        qline(r, cx, y, cx, y + OP1_Q10(9), 0x300, ql_col[1]);
        return;
    }
    switch (g) {
    case QL_SYNTH:                                                   /* wave */
        qline(r, gx, y, gx + OP1_Q10(3), y - OP1_Q10(4), 0x400, c);
        qline(r, gx + OP1_Q10(3), y - OP1_Q10(4), gx + OP1_Q10(9), y + OP1_Q10(4), 0x400, c);
        qline(r, gx + OP1_Q10(9), y + OP1_Q10(4), gx + OP1_Q10(12), y, 0x400, c);
        break;
    case QL_ENV:                                                     /* ADSR */
        qline(r, gx, y + OP1_Q10(4), gx + OP1_Q10(3), y - OP1_Q10(4), 0x400, c);
        qline(r, gx + OP1_Q10(3), y - OP1_Q10(4), gx + OP1_Q10(6), y, 0x400, c);
        qline(r, gx + OP1_Q10(6), y, gx + OP1_Q10(9), y, 0x400, c);
        qline(r, gx + OP1_Q10(9), y, gx + OP1_Q10(12), y + OP1_Q10(4), 0x400, c);
        break;
    default:                                                         /* fx: the text "fx" from lines */
        qline(r, gx + OP1_Q10(2), y + OP1_Q10(5), gx + OP1_Q10(2), y - OP1_Q10(3), 0x480, c);
        qline(r, gx + OP1_Q10(2), y - OP1_Q10(3), gx + OP1_Q10(4), y - OP1_Q10(5), 0x480, c);
        qline(r, gx + OP1_Q10(4), y - OP1_Q10(5), gx + OP1_Q10(6), y - OP1_Q10(5), 0x480, c);
        qline(r, gx, y - OP1_Q10(1), gx + OP1_Q10(5), y - OP1_Q10(1), 0x480, c);
        qline(r, gx + OP1_Q10(8), y - OP1_Q10(1), gx + OP1_Q10(14), y + OP1_Q10(5), 0x480, c);
        qline(r, gx + OP1_Q10(14), y - OP1_Q10(1), gx + OP1_Q10(8), y + OP1_Q10(5), 0x480, c);
    }
}

static void ql_screen_update(void *scr, int dt)
{
    int pos = PAGE_POS();
    const int16_t *w = PAGE_WORDS(pos);
    int sel = ql_sel[pos] & 3;
    op1_screen_draw(scr, dt);
    void *r = op1_raster();
    ql_lfo L[4], Lm[4]; ql_dec_all(w, L); ql_dec_shared(w, pos, Lm);   /* text: set values, lane: modulated */
    int lfo_on = LFO_ON(pos);
    uint32_t b = blocks_q16(READ_CYCLES(), ph_cyc_all[pos]);
    if (lfo_on && b > (4u << 16)) ql_advance_pos(pos, Lm);                       /* audio idle (no voice / FX calls): advance here */
    if (SHIFT_HELD()) { ql_table(r, w, sel); return; }
    for (int i = 0; i < 4; i++) {
        const ql_lfo *o = &L[i];
        int32_t y = OP1_Q10(ql_lane_y[i]), ty = y - OP1_Q10(6);
        int on = i == sel, muted = o->mute;                              /* muted: grey text, no span, tick at the centre, MUTE for the amount */
        const uint8_t *tc = muted ? ql_dim : on ? 0 : ql_lilac;
        /* amount span: centre +- |amount| (dim lane colour), output tick */
        int a = muted ? 0 : Lm[i].a128 < 0 ? -Lm[i].a128 : Lm[i].a128;
        int32_t span = (int32_t)(((int64_t)a * OP1_Q10(QL_LANE_HALF)) >> 7);
        if (span) {
            uint8_t dc[4];
            for (int k = 0; k < 3; k++) dc[k] = (uint8_t)(ql_col[i][k] * 3 / 8);
            dc[3] = 0xFF;
            qline(r, OP1_Q10(QL_LANE_MID) - span, y, OP1_Q10(QL_LANE_MID) + span, y, QL_SPAN_W, dc);
        }
        int16_t out = lfo_on && !muted ? ql_out(ql_shared(pos, o) ? sh_st[pos][i].val : disp_all[pos][i], Lm[i].a128) : 0;
        int32_t x = OP1_Q10(QL_LANE_MID) + (int32_t)(((int64_t)out * OP1_Q10(QL_LANE_HALF)) >> 15);
        qline(r, x, y - OP1_Q10(QL_TICK_H), x, y + OP1_Q10(QL_TICK_H), 0x800, ql_col[i]);
        if (on) qline(r, OP1_Q10(QL_DOT_X - 7), y + OP1_Q10(10), OP1_Q10(QL_DOT_X + 7), y + OP1_Q10(10), 0x600, ql_col[i]);
        /* frequency / division, amount % */
        char t[8];
        if (o->sync) { const char *n = ql_div_name[o->rate]; int k = 0; while ((t[k] = n[k])) k++; }
        else ql_hz_text(t, o->inc);
        sf_text(r, OP1_Q10(QL_FREQ_X), ty, OP1_Q10(2), t, 0x400, tc ? tc : ql_col[0]);
        int pc = o->amt * 100 / 31; char *p = t;
        if (pc < 0) { *p++ = '-'; pc = -pc; }
        ql_num(p, pc);
        if (muted) { t[0] = 'M'; t[1] = 'U'; t[2] = 'T'; t[3] = 'E'; t[4] = 0; }
        sf_text(r, OP1_Q10(QL_AMT_X), ty, OP1_Q10(2), t, 0x400, tc ? tc : ql_col[1]);
        /* target: glyph + dot in the knob / stage colour; LFO targets: F / A / O + dot in the target LFO's colour */
        int dcol = ql_dest(o);
        if (o->tgt >= 12) {
            static const char *const kp[3] = { "F", "A", "O" };
            dcol = (o->tgt - 12) / 3;
            sf_text(r, OP1_Q10(QL_GLYPH_X + 2), ty, OP1_Q10(2), kp[(o->tgt - 12) % 3], 0x400, tc ? tc : ql_white);
        } else ql_glyph(r, pos, ql_group(o), OP1_Q10(QL_GLYPH_X), y, tc ? tc : ql_white);
        int32_t dx = OP1_Q10(QL_TDOT_X);                                 /* dot: two crossing bars (no zero-length lines) */
        qline(r, dx - OP1_Q10(3), y, dx + OP1_Q10(3), y, OP1_Q10(4), ql_col[dcol]);
        qline(r, dx, y - OP1_Q10(3), dx, y + OP1_Q10(3), OP1_Q10(4), ql_col[dcol]);
        sf_text(r, OP1_Q10(QL_TYPE_X), ty, OP1_Q10(2), ql_type_name[o->type], 0x400, tc ? tc : ql_col[3]);
    }
}

const op1_screen_t SCREEN_quadlfo = { ql_screen_init, ql_screen_update };

/* ---- pond LFO screen (display/pondlfo.svg: the axes, species 1 - 3 across, 2 - 4 up): the last 48 points (1/48 cycle
 * apart) as dots in the colour of the species that led then, fading with age; the current point larger; top left the
 * four populations as bars (the selected species marked); bottom row (stroke font): speed, chaos, amount and target
 * of the selected species; Shift: clock and mode. Plot design: op1r-src f2aed5d (xoza); text in kennel's stroke font. */
#define PD_CX 165
#define PD_CY 52
#define PD_COL_W 78                                              /* bottom row: four columns of 78 px from x 8 */
#define PD_LAB_Y 112                                             /* label top (9 px high at scale 1.5) */
#define PD_VAL_Y 124                                             /* value top; ink ends at y 133 */
#define PD_S 1536                                                /* stroke font scale 1.5 (Q10) */
static void pd_dot(void *r, int32_t x, int32_t y, int32_t sz, const uint8_t *c)   /* two crossing bars */
{
    qline(r, x - sz / 2, y, x + sz / 2, y, sz * 7 / 10, c);
    qline(r, x, y - sz / 2, x, y + sz / 2, sz * 7 / 10, c);
}
static char *pd_cat(char *p, const char *s) { while (*s) *p++ = *s++; *p = 0; return p; }
static void pd_pct(char *p, int v31, int sign)                   /* -31..31 -> "+80" / "80%" */
{
    int v = (v31 * 100 + (v31 < 0 ? -15 : 15)) / 31;
    if (sign) *p++ = v < 0 ? '-' : '+';
    p = ql_num(p, v < 0 ? -v : v);
    if (!sign) pd_cat(p, "%");
}
static void pd_text(void *r, int col, int y, const char *t, const uint8_t *c)
{
    sf_text(r, OP1_Q10(8 + PD_COL_W * col), OP1_Q10(y), PD_S, t, 0x400, c);
}
/* a target as the value of a column: "INST" / "DRUM" / "FX" + a dot in the knob's colour, envelope stages as "ENV A" */
static void pd_target(void *r, int col, int t, int pos)
{
    static const char ec[4] = { 'A', 'D', 'S', 'R' };
    char b[8];
    const char *wd;
    int k = -1;
    if (t < 4) { wd = pos ? "DRUM" : "INST"; k = t; }
    else if (t < 8) { pd_cat(pd_cat(b, "ENV "), "A"); b[4] = ec[t - 4]; wd = b; }
    else { wd = "FX"; k = (t - 8) & 3; }
    pd_text(r, col, PD_VAL_Y, wd, ql_white);
    if (k < 0) return;
    int n = 0; while (wd[n]) n++;
    pd_dot(r, OP1_Q10(8 + PD_COL_W * col) + n * 6 * PD_S + OP1_Q10(5), OP1_Q10(PD_VAL_Y + 4), OP1_Q10(6), ql_col[k]);
}
static void pd_screen_update(void *scr, int dt)
{
    int pos = PAGE_POS(), pg = pos & 1, sel = ql_sel[pg] & 3;
    const int16_t *w = PAGE_WORDS(pos);
    pond_set f; pond_get(w, &f);
    op1_screen_draw(scr, dt);
    void *r = op1_raster();
    {                                                            /* idle audio: advance the shared state here, as quad's lanes */
        ql_lfo Lm[4]; ql_dec_shared(w, pos, Lm);
        uint32_t b = blocks_q16(READ_CYCLES(), ph_cyc_all[pos]);
        if (LFO_ON(pos) && b > (4u << 16)) ql_advance_pos(pos, Lm);
    }
    int hd = pond_head[pg];
    for (int k = 47; k >= 0; k--) {                              /* the trail, newest last (k = 0) */
        int j = (hd - k + 48) % 48;
        int32_t a = pond_trail[pg][j][0], b = pond_trail[pg][j][1];
        a = a > 11800 ? 11800 : a < -11800 ? -11800 : a; b = b > 11800 ? 11800 : b < -11800 ? -11800 : b;   /* 32-bit products */
        if (!a && !b) continue;                                  /* not filled yet */
        const uint8_t *cc = ql_col[pond_dom[pg][j] & 3];
        int lv = 256 - k * 5;
        uint8_t c[4] = { (uint8_t)(cc[0] * lv >> 8), (uint8_t)(cc[1] * lv >> 8), (uint8_t)(cc[2] * lv >> 8), 0xFF };
        int32_t x = OP1_Q10(PD_CX) + (int32_t)((a * OP1_Q10(128)) / 9830);    /* +-0.6 -> +-128 px (|a| < 2^15: 32 bit) */
        int32_t y = OP1_Q10(PD_CY) - (int32_t)((b * OP1_Q10(44)) / 11469);    /* +-0.7 -> +-44 px */
        pd_dot(r, x, y, OP1_Q10(k ? 3 : 6), k ? c : cc);
    }
    {                                                            /* the four populations (Q14: 0.5 -> 24 px) */
        const ql_st *st = &sh_st[pg][0];
        int32_t xs[4] = { st->lx, st->ly, st->lz, st->d1 };
        for (int k = 0; k < 4; k++) {
            int32_t hgt = st->lz ? (xs[k] >> 6) * 48 / 16384 : 0; if (hgt > 40) hgt = 40;
            int32_t bx = OP1_Q10(8 + 7 * k);
            if (hgt > 0) qline(r, bx, OP1_Q10(46), bx, OP1_Q10(46 - hgt), OP1_Q10(4), ql_col[k]);
            if (k == sel) qline(r, bx - OP1_Q10(3), OP1_Q10(50), bx + OP1_Q10(3), OP1_Q10(50), OP1_Q10(2), ql_col[k]);
        }
    }
    for (int i = 0; i < 4; i++)
        qline(r, OP1_Q10(8 + PD_COL_W * i), OP1_Q10(108), OP1_Q10(PD_COL_W - 2 + PD_COL_W * i), OP1_Q10(108), 0x800, ql_col[i]);
    char t[16], *p;
    if (!SHIFT_HELD()) {
        pd_text(r, 0, PD_LAB_Y, "SPEED", ql_col[0]);
        if (f.sync) pd_cat(t, ql_div_name[f.rate]);
        else { ql_hz_text(t, ql_inc((f.rate << 9) | 0x100)); char *e = t; while (*e) e++; pd_cat(e, " HZ"); }
        pd_text(r, 0, PD_VAL_Y, t, ql_white);
        pd_text(r, 1, PD_LAB_Y, "CHAOS", ql_col[1]);
        pd_pct(t, f.chaos, 0); pd_text(r, 1, PD_VAL_Y, t, ql_white);
        p = pd_cat(t, "AMOUNT "); *p++ = (char)('1' + sel); *p = 0; pd_text(r, 2, PD_LAB_Y, t, ql_col[2]);
        pd_pct(t, f.amt[sel], 1); pd_text(r, 2, PD_VAL_Y, t, ql_white);
        p = pd_cat(t, "TARGET "); *p++ = (char)('1' + sel); *p = 0; pd_text(r, 3, PD_LAB_Y, t, ql_col[3]);
        pd_target(r, 3, f.tgt[sel], pos);
    } else {
        pd_text(r, 0, PD_LAB_Y, "CLOCK", ql_col[0]); pd_text(r, 0, PD_VAL_Y, f.sync ? "SYNC" : "FREE", ql_white);
        pd_text(r, 1, PD_LAB_Y, "MODE", ql_col[1]); pd_text(r, 1, PD_VAL_Y, f.retrig ? "RETRIG" : "FREE", ql_white);
    }
}
const op1_screen_t SCREEN_pondlfo = { ql_screen_init, pd_screen_update };
