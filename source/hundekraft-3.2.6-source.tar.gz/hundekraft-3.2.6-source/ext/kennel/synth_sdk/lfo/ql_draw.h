/* quad LFO drawing helpers shared by lfo/quadlfo.c and screens/mlfo.c (moved unchanged from quadlfo.c).
 * Needs ql_dsp.h (ql_shape) first.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef QL_DRAW_H
#define QL_DRAW_H
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
static void qline(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, const uint8_t *c)
{
    op1_pt a = { x0, y0 }, b = { x1, y1 };
    op1_raster_line(r, &a, &b, w, c);
}

static char *ql_num(char *p, int v) { if (v >= 10) p = ql_num(p, v / 10); *p++ = (char)('0' + v % 10); *p = 0; return p; }
/* Hz of a free frequency word as text: "0.05" .. "9.99", "10.0" .. "20.0" */
static void ql_hz_text(char *t, uint32_t inc)
{
    uint32_t c = (uint32_t)(((uint64_t)inc * 4410000u) >> 39);   /* Hz * 100 = inc * 44100 * 100 / (128 * 2^32) */
    if (c >= 1000) { c /= 10; t = ql_num(t, c / 10); *t++ = '.'; ql_num(t, c % 10); }
    else { t = ql_num(t, c / 100); *t++ = '.'; *t++ = (char)('0' + c / 10 % 10); *t++ = (char)('0' + c % 10); *t = 0; }
}
/* waveform glyph: 24 x 12 px, (x, y) = left end of the centre line, Q10 */
static void ql_wave_glyph(void *r, int wave, int32_t x, int32_t y, const uint8_t *c)
{
    static const int8_t sh[4] = { 4, -3, 6, -5 };                  /* sample & hold: fixed steps */
    static const int8_t lor[2][25] = {                               /* a real Lorenz x / z stretch, px (op1r-src 8c89498) */
        { 4, 4, 2, 1, 0, 0, 0, 0, -1, -1, -2, -4, -5, -4, -2, 0, 1, 1, 2, 2, 3, 4, 4, 3, 2 },
        { 3, 4, 3, 1, 0, -1, -2, -3, -4, -4, -3, -1, 4, 5, 3, 1, 0, -1, -2, -1, 0, 2, 3, 3, 1 } };
    int32_t px = 0, py = 0;
    for (int k = 0; k <= 24; k++) {
        uint32_t a = (uint32_t)k * (0xFFFFFFFFu / 24);
        int32_t v = wave >= 6 ? lor[(wave - 6) & 1][k] * 5461 : wave == 5 ? sh[k < 24 ? k / 6 : 3] * 5000 : ql_shape(wave, a, 0, 0);
        if (wave == 2 || wave == 3) v = (wave == 2 ? 2 : -2) * ((int32_t)(a >> 17) - 16384);   /* ramps without the wrap */
        int32_t nx = x + OP1_Q10(k), ny = y - (v * OP1_Q10(6) >> 15);
        if (k) {
            int step = wave == 4 || wave == 5;
            if (step && ny != py) qline(r, px, py, px, ny, 0x400, c);                   /* vertical edges */
            qline(r, px, step ? ny : py, nx, ny, 0x400, c);
        }
        px = nx; py = ny;
    }
}
#pragma GCC diagnostic pop
#endif
