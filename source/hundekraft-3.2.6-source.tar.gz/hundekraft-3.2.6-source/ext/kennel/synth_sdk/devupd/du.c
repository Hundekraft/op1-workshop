/* Development update over SysEx: see du.h and docs/35. */
#include "du.h"
#include "../kn_mem.h"

static const uint8_t du_hdr[DU_SYSEX_HDR] = { 0xF0, 0x00, 0x20, 0x76, 0x7D };
static int same_path(const char *a, const char *b);

uint32_t du_crc32(uint32_t crc, const uint8_t *p, uint32_t n)
{
    crc = ~crc;
    while (n--) {
        crc ^= *p++;
        for (int k = 0; k < 8; k++) crc = crc >> 1 ^ (0xEDB88320u & (0u - (crc & 1)));
    }
    return ~crc;
}

int du_pack7(const uint8_t *in, int n, uint8_t *out)
{
    int o = 0;
    for (int i = 0; i < n; i += 7) {
        int m = n - i < 7 ? n - i : 7;
        uint8_t hi = 0;
        for (int k = 0; k < m; k++) hi |= (uint8_t)((in[i + k] >> 7) << k);
        out[o++] = hi;
        for (int k = 0; k < m; k++) out[o++] = in[i + k] & 0x7F;
    }
    return o;
}

int du_unpack7(const uint8_t *in, int n, uint8_t *out)
{
    int o = 0;
    for (int i = 0; i < n;) {
        uint8_t hi = in[i++];
        if (hi & 0x80) return -1;
        for (int k = 0; k < 7 && i < n; k++, i++) {
            if (in[i] & 0x80) return -1;
            out[o++] = (uint8_t)(in[i] | ((hi >> k & 1) << 7));
        }
    }
    return o;
}

int du_build(uint8_t *msg, int cmd, int seq, const uint8_t *payload, int n)
{
    if (DU_SYSEX_HDR + 3 + (n + 6) / 7 * 8 + 1 > DU_MAX_MSG) return -1;
    int o = 0;
    for (int i = 0; i < DU_SYSEX_HDR; i++) msg[o++] = du_hdr[i];
    msg[o++] = (uint8_t)(cmd & 0x7F);
    msg[o++] = (uint8_t)(seq & 0x7F);
    msg[o++] = (uint8_t)(seq >> 7 & 0x7F);
    o += du_pack7(payload, n, msg + o);
    msg[o++] = 0xF7;
    return o;
}

static int lower(int c) { return c >= 'A' && c <= 'Z' ? c + 32 : c; }
static int contains_ci(const char *s, const char *w)
{
    for (; *s; s++) {
        int i = 0;
        while (w[i] && lower((unsigned char)s[i]) == w[i]) i++;
        if (!w[i]) return 1;
    }
    return 0;
}

static int ends(const char *p, const char *e)
{
    int a = 0, b = 0;
    while (p[a]) a++;
    while (e[b]) b++;
    if (a < b) return 0;
    for (int i = 0; i < b; i++) if (p[a - b + i] != e[i]) return 0;
    return 1;
}

static int starts(const char *p, const char *w) { while (*w) if (*p++ != *w++) return 0; return 1; }

int du_plugin_path(const char *p)
{
    const char *f = starts(p, "plugins/") ? p + 8 : starts(p, "content/") ? p + 8 : 0;
    if (!f || !*f || *f == '.' || !du_path_ok(p)) return 0;      /* (never plugins/.boot, the crash marker) */
    for (const char *q = f; *q; q++) if (*q == '/') return 0;
    return (ends(f, ".knl") && f[4]) || (ends(f, ".op1p") && f[5]);
}

int du_path_ok(const char *p)
{
    int n = 0;
    for (const char *q = p; *q; q++, n++) {
        char c = *q;
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '.' ||
              c == '-' || c == '/')) return 0;
    }
    if (n == 0 || n >= DU_MAX_PATH || p[0] == '/' || p[n - 1] == '/') return 0;
    if (contains_ci(p, "te-boot") || contains_ci(p, "te_boot") || contains_ci(p, "teboot")) return 0;   /* never */
    if (contains_ci(p, "..") || contains_ci(p, "//")) return 0;
    if (!(p[0] == 'O' && p[1] == 'P' && p[2] == '1' && p[3] == '_' && p[4] == 'v' && p[5] == 'd' && p[6] == 'k' &&
          p[7] == '.' && p[8] == 'l' && p[9] == 'd' && p[10] == 'r' && (p[11] == 0 || same_path(p + 11, ".knp"))) &&
        !(p[0] == 'c' && p[1] == 'o' && p[2] == 'n' && p[3] == 't' && p[4] == 'e' && p[5] == 'n' && p[6] == 't' &&
          p[7] == '/') &&
        !(starts(p, "plugins/") && (ends(p, ".knl") || ends(p, ".op1p"))))
        return 0;
    if (starts(p, "plugins/"))                                    /* plugins/<file>: one level, not hidden */
        for (const char *q = p + 8; *q; q++) if (*q == '/' || (q == p + 8 && *q == '.')) return 0;
    if (starts(p, "content/") && ends(p, DU_PATCH_EXT) && !du_content_patch(p, 0)) return 0;   /* .knp.knp, .knp */
    return 1;
}

int du_content_patch(const char *p, char *target)
{
    if (!starts(p, "content/") || !ends(p, DU_PATCH_EXT)) return 0;
    char t[DU_MAX_PATH];
    int n = 0;
    while (p[n] && n < DU_MAX_PATH - 1) { t[n] = p[n]; n++; }
    if (p[n] || n < 4) return 0;
    t[n - 4] = 0;                                                 /* strip ".knp" */
    if (ends(t, DU_PATCH_EXT) || !du_path_ok(t) || !starts(t, "content/") || !t[8]) return 0;
    if (target) for (int i = 0; i <= n - 4; i++) target[i] = t[i];
    return 1;
}

/* the file a staged path ends up as: a content patch's target, else the path itself */
static void target_of(const char *p, char *out)
{
    if (du_content_patch(p, out)) return;
    int i = 0; while (p[i] && i < DU_MAX_PATH - 1) { out[i] = p[i]; i++; } out[i] = 0;
}
static int same_target(const char *a, const char *b)
{
    char x[DU_MAX_PATH], y[DU_MAX_PATH];
    target_of(a, x); target_of(b, y);
    return same_path(x, y);
}

void du_stage_name(int i, char *out)
{
    const char *d = DU_STAGE_DIR "/f";
    int o = 0;
    while (*d) out[o++] = *d++;
    out[o++] = (char)('0' + i / 100 % 10); out[o++] = (char)('0' + i / 10 % 10); out[o++] = (char)('0' + i % 10);
    out[o] = 0;                                                   /* f000..f128 (a stage is applied by the core that wrote it) */
}

void du_result_name(int i, char *out)
{
    du_stage_name(i, out);
    int o = 0; while (out[o]) o++;
    out[o - 4] = 'r';                                             /* r000..r127 */
}

void du_init(du_session *s, const du_fs *fs)
{
    s->fs = fs; s->open = 0; s->written = s->crc = 0; s->n = 0; s->off_have = 0; s->asking = s->restart_cancel = 0;
}

static uint32_t rd32(const uint8_t *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
static void wr32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }

static int reply(uint8_t *rep, int cmd, int seq, int status, const uint8_t *pl, int n)
{
    uint8_t b[16];
    b[0] = (uint8_t)status;
    for (int i = 0; i < n && i < 15; i++) b[1 + i] = pl[i];
    return du_build(rep, cmd | DU_REPLY, seq, b, 1 + (n < 15 ? n : 15));
}

static int reply_wide(uint8_t *rep, int cmd, int seq, int status, uint32_t total, const uint8_t *pl, int n)
{
    uint8_t b[5 + DU_INV_CHUNK];                                  /* status, u32 total, up to DU_INV_CHUNK bytes */
    b[0] = (uint8_t)status; wr32(b + 1, total);
    for (int i = 0; i < n && i < DU_INV_CHUNK; i++) b[5 + i] = pl[i];
    return du_build(rep, cmd | DU_REPLY, seq, b, 5 + (n < DU_INV_CHUNK ? n : DU_INV_CHUNK));
}

static int off_char(char c)                                       /* as the settings service's ok_char */
{
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == ' ' || c == '.' ||
           c == '_' || c == ',' || c == ':' || c == '-';
}

static void abort_session(du_session *s)
{
    if (s->open) s->fs->close(s->fs->ctx);
    char name[40];
    for (int i = 0; i <= DU_MAX_FILES; i++) { du_stage_name(i, name); s->fs->remove(s->fs->ctx, name); }   /* whole staging dir */
    if (s->fs->content_patch)
        for (int i = 0; i < DU_MAX_FILES; i++) { du_result_name(i, name); s->fs->remove(s->fs->ctx, name); }   /* results */
    s->fs->remove(s->fs->ctx, DU_MANIFEST);
    s->open = 0; s->n = 0;
}

void du_abort(du_session *s) { s->restart_cancel = s->asking; s->asking = 0; abort_session(s); }   /* T2 */

static int same_path(const char *a, const char *b) { while (*a && *a == *b) a++, b++; return *a == *b; }

int du_patch_header(const uint8_t *s, uint32_t n, du_patch_hdr *h)
{
    if (n < 24 || s[0] != 'K' || s[1] != 'N' || s[2] != 'P' || s[3] != '1') return -1;
    h->base_size = rd32(s + 4); h->base_crc = rd32(s + 8); h->size = rd32(s + 12); h->crc = rd32(s + 16);
    h->n = rd32(s + 20);
    return h->size && h->size <= 127u * DU_BLOCK && h->base_size <= 127u * DU_BLOCK ? 0 : -1;
}

int du_patch_apply(const uint8_t *s, uint32_t n, int (*read)(void *ctx, uint32_t off, uint8_t *dst, uint32_t len),
                   void *ctx, uint8_t *out)
{
    du_patch_hdr h;
    if (du_patch_header(s, n, &h)) return 1;
    uint32_t at = 24, o = 0;
    for (uint32_t r = 0; r < h.n; r++) {
        if (at >= n) return 2;
        if (s[at] == 'C') {
            if (n - at < 9) return 2;
            uint32_t src = rd32(s + at + 1), len = rd32(s + at + 5);
            at += 9;
            if (src > h.base_size || len > h.base_size - src || len > h.size - o) return 3;
            if (len && read(ctx, src, out + o, len)) return 4;
            o += len;
        } else if (s[at] == 'L') {
            if (n - at < 5) return 2;
            uint32_t len = rd32(s + at + 1);
            at += 5;
            if (len > n - at || len > h.size - o) return 3;
            for (uint32_t i = 0; i < len; i++) out[o + i] = s[at + i];
            at += len; o += len;
        } else return 2;
    }
    if (at != n || o != h.size) return 5;
    return du_crc32(0, out, o) == h.crc ? 0 : 6;
}

static int commit_now(du_session *s, uint8_t *rep, int cmd, int seq)     /* T1 pressed: manifest, reply, restart */
{
    if (s->n) {
        static char text[DU_MAX_FILES * (DU_MAX_PATH + 32) + 64] kn_farbss;
        int len = du_manifest_write(s, text, (int)sizeof text);
        if (len < 0 || s->fs->open_w(s->fs->ctx, DU_MANIFEST)) {
            abort_session(s); return reply(rep, cmd, seq, DU_E_IO, 0, 0);
        }
        int io_error = s->fs->write(s->fs->ctx, (const uint8_t *)text, (uint32_t)len);
        if (s->fs->close(s->fs->ctx)) io_error = 1;
        if (io_error) { abort_session(s); return reply(rep, cmd, seq, DU_E_IO, 0, 0); }
    }
    int r = reply(rep, cmd, seq, DU_OK, 0, 0);
    s->n = 0; s->asking = 0;
    s->fs->reboot(s->fs->ctx);                                    /* (firmware: after the reply went out) */
    return r;
}

int du_handle(du_session *s, const uint8_t *msg, int n, uint8_t *rep)
{
    if (n < DU_SYSEX_HDR + 4 || n > DU_MAX_MSG || msg[n - 1] != 0xF7) return 0;
    for (int i = 0; i < DU_SYSEX_HDR; i++) if (msg[i] != du_hdr[i]) return 0;
    int cmd = msg[5], seq = msg[6] | msg[7] << 7;
    uint8_t pl[DU_MAX_MSG];
    int pn = du_unpack7(msg + 8, n - 9, pl);
    if (pn < 0) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
    uint8_t out[8];
    switch (cmd) {
    case DU_HELLO:
        wr32(out, 1);                                             /* protocol version */
        out[4] = (s->fs->inv_read ? DU_CAP_INVENTORY | DU_CAP_PLUGINS : 0) | (s->fs->stat_crc ? DU_CAP_PATCH : 0) |
                 (s->fs->stat_crc && s->fs->content_patch ? DU_CAP_FILE_PATCH : 0);   /* (stock 2.x: no byte 4) */
        return reply(rep, cmd, seq, DU_OK, out, 5);
    case DU_LIST: {                                               /* u32 offset -> u32 total, text bytes from there */
        if (!s->fs->inv_read) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        if (pn != 4) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        uint8_t chunk[DU_INV_CHUNK];
        uint32_t total = 0;
        int k = s->fs->inv_read(s->fs->ctx, rd32(pl), chunk, DU_INV_CHUNK, &total);
        if (k < 0) return reply_wide(rep, cmd, seq, rd32(pl) > total ? DU_E_OFFSET : DU_E_IO, total, 0, 0);
        return reply_wide(rep, cmd, seq, DU_OK, total, chunk, k);
    }
    case DU_OFF_GET: {                                            /* u8 at_boot, u16 offset -> u32 total, bytes */
        if (!s->fs->off_get) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        if (pn != 3) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        static char t[DU_OFF_MAX + 96];                           /* (main loop only; 1 KB off the stack) */
        int len = s->fs->off_get(s->fs->ctx, pl[0] != 0, t, (int)sizeof t);
        if (len < 0) return reply(rep, cmd, seq, DU_E_IO, 0, 0);
        if (len > (int)sizeof t - 1) len = (int)sizeof t - 1;
        uint32_t off = (uint32_t)(pl[1] | pl[2] << 8);
        if (off > (uint32_t)len) return reply_wide(rep, cmd, seq, DU_E_OFFSET, (uint32_t)len, 0, 0);
        return reply_wide(rep, cmd, seq, DU_OK, (uint32_t)len, (const uint8_t *)t + off, len - (int)off);
    }
    case DU_OFF_SET: {                                            /* u16 offset, u16 total, bytes; stored when complete */
        if (!s->fs->off_set) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        if (pn < 4) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        int off = pl[0] | pl[1] << 8, total = pl[2] | pl[3] << 8, len = pn - 4;
        if (total > DU_OFF_MAX || off + len > total) return reply(rep, cmd, seq, DU_E_SIZE, 0, 0);
        for (int i = 0; i < len; i++) if (!off_char((char)pl[4 + i])) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        if (off == 0) s->off_have = 0;                            /* a new value starts */
        out[0] = (uint8_t)s->off_have; out[1] = (uint8_t)(s->off_have >> 8);
        if (off != s->off_have) return reply(rep, cmd, seq, DU_E_OFFSET, out, 2);   /* host resends from there */
        for (int i = 0; i < len; i++) s->off_buf[off + i] = (char)pl[4 + i];
        s->off_have = off + len;
        out[0] = (uint8_t)s->off_have; out[1] = (uint8_t)(s->off_have >> 8);
        if (s->off_have < total) return reply(rep, cmd, seq, DU_OK, out, 2);
        s->off_buf[total] = 0;                                    /* (off_have stays: a resent last chunk -> offset = total) */
        if (s->fs->off_set(s->fs->ctx, s->off_buf)) return reply(rep, cmd, seq, DU_E_IO, 0, 0);
        return reply(rep, cmd, seq, DU_OK, out, 2);               /* (out = total) */
    }
    case DU_STAT: {                                               /* u32 off, u32 len, u32 crc in, path -> size, crc, n */
        if (!s->fs->stat_crc) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        if (pn < 14 || pl[pn - 1] != 0) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        const char *path = (const char *)pl + 12;
        if (!same_path(path, "OP1_vdk.ldr") &&                    /* the core file, and content/ files with bit 8 */
            !(s->fs->content_patch && starts(path, "content/") && du_path_ok(path)))
            return reply(rep, cmd, seq, DU_E_PATH, 0, 0);
        uint32_t len = rd32(pl + 4), size = 0, crc = 0;
        if (len > DU_STAT_MAX) return reply(rep, cmd, seq, DU_E_SIZE, 0, 0);
        int k = s->fs->stat_crc(s->fs->ctx, path, rd32(pl), len, rd32(pl + 8), &size, &crc);
        if (k < 0) return reply(rep, cmd, seq, DU_E_IO, 0, 0);
        uint8_t st[12]; wr32(st, size); wr32(st + 4, crc); wr32(st + 8, (uint32_t)k);
        return reply(rep, cmd, seq, DU_OK, st, 12);
    }
    case DU_BEGIN: {                                              /* u32 size, u32 crc, path (0-terminated) */
        if (s->open) return reply(rep, cmd, seq, DU_E_STATE, 0, 0);
        if (pn < 10 || pl[pn - 1] != 0) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        const char *path = (const char *)pl + 8;
        if (!du_path_ok(path)) return reply(rep, cmd, seq, DU_E_PATH, 0, 0);
        uint32_t size = rd32(pl);
        if (size > 127u * DU_BLOCK) return reply(rep, cmd, seq, DU_E_SIZE, 0, 0);
        if (s->n >= DU_MAX_FILES) return reply(rep, cmd, seq, DU_E_FULL, 0, 0);
        for (int i = 0; i < s->n; i++)                            /* same file twice (or sent and deleted, or a file */
            if (same_target(s->f[i].path, path) || (path[0] == 'O' && s->f[i].path[0] == 'O'))   /* and a patch of it) */
                return reply(rep, cmd, seq, DU_E_STATE, 0, 0);
        du_file *f = &s->f[s->n];
        int k = 0; while (path[k]) { f->path[k] = path[k]; k++; } f->path[k] = 0;
        f->size = size; f->crc = rd32(pl + 4);
        char name[40]; du_stage_name(s->n, name);
        if (s->fs->open_w(s->fs->ctx, name)) return reply(rep, cmd, seq, DU_E_IO, 0, 0);
        s->open = 1; s->written = 0; s->crc = 0;
        return reply(rep, cmd, seq, DU_OK, 0, 0);
    }
    case DU_DATA: {                                               /* u32 offset, data */
        if (!s->open) return reply(rep, cmd, seq, DU_E_STATE, 0, 0);
        if (pn < 4 || pn > 4 + DU_MAX_DATA) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        uint32_t off = rd32(pl), len = (uint32_t)pn - 4;
        wr32(out, s->written);
        if (off != s->written) return reply(rep, cmd, seq, DU_E_OFFSET, out, 4);   /* host resends from there */
        if (s->written + len > s->f[s->n].size) return reply(rep, cmd, seq, DU_E_SIZE, out, 4);
        if (s->fs->write(s->fs->ctx, pl + 4, len)) { abort_session(s); return reply(rep, cmd, seq, DU_E_IO, 0, 0); }
        s->written += len; s->crc = du_crc32(s->crc, pl + 4, len);
        wr32(out, s->written);
        return reply(rep, cmd, seq, DU_OK, out, 4);
    }
    case DU_END: {
        if (!s->open) return reply(rep, cmd, seq, DU_E_STATE, 0, 0);
        int close_error = s->fs->close(s->fs->ctx); s->open = 0;
        if (close_error) { abort_session(s); return reply(rep, cmd, seq, DU_E_IO, 0, 0); }
        du_file *f = &s->f[s->n];
        if (s->written != f->size) { char name[40]; du_stage_name(s->n, name); s->fs->remove(s->fs->ctx, name); return reply(rep, cmd, seq, DU_E_SIZE, 0, 0); }
        if (s->crc != f->crc) { char name[40]; du_stage_name(s->n, name); s->fs->remove(s->fs->ctx, name); return reply(rep, cmd, seq, DU_E_CRC, 0, 0); }
        s->n++;
        return reply(rep, cmd, seq, DU_OK, 0, 0);
    }
    case DU_COMMIT: {
        if (s->open || s->n == 0) return reply(rep, cmd, seq, DU_E_STATE, 0, 0);
        if (!s->fs->key_pressed(s->fs->ctx)) return reply(rep, cmd, seq, DU_WAIT_KEY, 0, 0);   /* host asks again */
        return commit_now(s, rep, cmd, seq);
    }
    case DU_DELETE: {                                             /* path (0-terminated): removed at the restart */
        if (!s->fs->inv_read) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        if (s->open) return reply(rep, cmd, seq, DU_E_STATE, 0, 0);
        if (pn < 2 || pl[pn - 1] != 0) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        const char *path = (const char *)pl;
        if (!du_plugin_path(path)) return reply(rep, cmd, seq, DU_E_PATH, 0, 0);
        for (int i = 0; i < s->n; i++)
            if (same_target(s->f[i].path, path))                  /* a resent DELETE: fine; sent (or patched): no */
                return reply(rep, cmd, seq, s->f[i].size == DU_DELETED ? DU_OK : DU_E_STATE, 0, 0);
        if (s->n >= DU_MAX_FILES) return reply(rep, cmd, seq, DU_E_FULL, 0, 0);
        du_file *f = &s->f[s->n];
        int k = 0; while (path[k]) { f->path[k] = path[k]; k++; } f->path[k] = 0;
        f->size = DU_DELETED; f->crc = 0; s->n++;
        return reply(rep, cmd, seq, DU_OK, 0, 0);
    }
    case DU_RESTART: {                                            /* T1 restarts (staged files / deletes applied first) */
        if (!s->fs->inv_read) return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
        if (s->open) return reply(rep, cmd, seq, DU_E_STATE, 0, 0);
        if (s->restart_cancel) { s->restart_cancel = 0; return reply(rep, cmd, seq, DU_E_STATE, 0, 0); }   /* T2 */
        if (!s->fs->key_pressed(s->fs->ctx)) { s->asking = 1; return reply(rep, cmd, seq, DU_WAIT_KEY, 0, 0); }
        return commit_now(s, rep, cmd, seq);
    }
    case DU_ABORT:
        abort_session(s);
        return reply(rep, cmd, seq, DU_OK, 0, 0);
    default:
        return reply(rep, cmd, seq, DU_E_FORMAT, 0, 0);
    }
}

/* manifest: "op1r-stage 1\n", per file "F <size> <crc hex8> <path>\n", "N <count> <crc hex8 of the lines above>\n" */
static int put_s(char *o, int at, int cap, const char *s) { while (*s) { if (at >= cap - 1) return -1; o[at++] = *s++; } return at; }
static int put_u(char *o, int at, int cap, uint32_t v)
{
    char t[12]; int n = 0;
    do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n) { if (at >= cap - 1) return -1; o[at++] = t[--n]; }
    return at;
}
static int put_x(char *o, int at, int cap, uint32_t v)
{
    for (int i = 7; i >= 0; i--) { if (at >= cap - 1) return -1; o[at++] = "0123456789abcdef"[v >> (i * 4) & 15]; }
    return at;
}

int du_manifest_write(const du_session *s, char *o, int cap)
{
    int at = put_s(o, 0, cap, "op1r-stage 1\n");
    for (int i = 0; i < s->n && at >= 0; i++) {
        if (s->f[i].size == DU_DELETED) {                         /* "D <path>": remove at the restart */
            at = put_s(o, at, cap, "D "); if (at < 0) break;
            at = put_s(o, at, cap, s->f[i].path); if (at < 0) break;
            at = put_s(o, at, cap, "\n");
            continue;
        }
        at = put_s(o, at, cap, "F "); if (at < 0) break;
        at = put_u(o, at, cap, s->f[i].size); if (at < 0) break;
        at = put_s(o, at, cap, " "); if (at < 0) break;
        at = put_x(o, at, cap, s->f[i].crc); if (at < 0) break;
        at = put_s(o, at, cap, " "); if (at < 0) break;
        at = put_s(o, at, cap, s->f[i].path); if (at < 0) break;
        at = put_s(o, at, cap, "\n");
    }
    if (at < 0) return -1;
    uint32_t c = du_crc32(0, (const uint8_t *)o, (uint32_t)at);
    at = put_s(o, at, cap, "N "); if (at < 0) return -1;
    at = put_u(o, at, cap, (uint32_t)s->n); if (at < 0) return -1;
    at = put_s(o, at, cap, " "); if (at < 0) return -1;
    at = put_x(o, at, cap, c); if (at < 0) return -1;
    at = put_s(o, at, cap, "\n"); if (at < 0) return -1;
    o[at] = 0;
    return at;
}

static const char *get_u(const char *p, uint32_t *v)
{
    if (*p < '0' || *p > '9') return 0;
    uint32_t x = 0;
    while (*p >= '0' && *p <= '9') { if (x > 429496729u) return 0; x = x * 10 + (uint32_t)(*p++ - '0'); }
    *v = x; return p;
}
static const char *get_x(const char *p, uint32_t *v)
{
    uint32_t x = 0;
    for (int i = 0; i < 8; i++, p++) {
        int d = *p >= '0' && *p <= '9' ? *p - '0' : *p >= 'a' && *p <= 'f' ? *p - 'a' + 10 : -1;
        if (d < 0) return 0;
        x = x << 4 | (uint32_t)d;
    }
    *v = x; return p;
}

int du_manifest_parse(const char *t, du_file *f, int *n)
{
    const char *p = t, *h = "op1r-stage 1\n";
    while (*h) if (*p++ != *h++) return -1;
    int k = 0;
    while (*p == 'F' || *p == 'D') {
        if (k >= DU_MAX_FILES || p[1] != ' ') return -1;
        if (*p == 'D') {
            p += 2;
            int i = 0;
            while (*p && *p != '\n') { if (i >= DU_MAX_PATH - 1) return -1; f[k].path[i++] = *p++; }
            f[k].path[i] = 0;
            if (*p++ != '\n' || !du_plugin_path(f[k].path)) return -1;
            f[k].size = DU_DELETED; f[k].crc = 0;
            k++;
            continue;
        }
        p += 2;
        if (!(p = get_u(p, &f[k].size)) || *p++ != ' ' || !(p = get_x(p, &f[k].crc)) || *p++ != ' ') return -1;
        int i = 0;
        while (*p && *p != '\n') { if (i >= DU_MAX_PATH - 1) return -1; f[k].path[i++] = *p++; }
        f[k].path[i] = 0;
        if (*p++ != '\n' || !du_path_ok(f[k].path) || f[k].size > 127u * DU_BLOCK) return -1;
        k++;
    }
    uint32_t c = du_crc32(0, (const uint8_t *)t, (uint32_t)(p - t)), cnt, cc;
    if (*p++ != 'N' || *p++ != ' ' || !(p = get_u(p, &cnt)) || *p++ != ' ' || !(p = get_x(p, &cc)) || *p++ != '\n' || *p)
        return -1;
    if (cnt != (uint32_t)k || cc != c || k == 0) return -1;
    *n = k;
    return 0;
}

/* ---- guarded flasher ---- */
int du_guard(int block) { return block >= DU_FIRST_BLOCK && block <= DU_LAST_BLOCK; }

static int hdr_ok(const uint8_t *h)
{
    uint8_t x = 0;
    for (int i = 0; i < 16; i++) x ^= h[i];
    return h[3] == 0xAD && x == 0;                                          /* block code signature, header XOR */
}

int du_ldr_ok(const uint8_t *l, uint32_t size)
{
    if (size < 16 || size > 127u * DU_BLOCK) return 0;
    for (uint32_t o = 0; o < size;) {                                       /* walk the whole block chain */
        if (size - o < 16 || !hdr_ok(l + o)) return 0;
        uint32_t flags = (uint32_t)l[o] | (uint32_t)l[o + 1] << 8, count = rd32(l + o + 8);
        o += 16;
        if (!(flags & 0x100)) {                                             /* FILL blocks carry no payload */
            if (count > size - o) return 0;
            o += count;
        }
    }
    return 1;
}

/* Encrypted (CALLBACK | INDIRECT) blocks of R246's OP1_vdk.ldr: patchers can't change them, and they are identical
 * in stock R246, op1r 31 and hundekraft 2.7.1. CRC-32 of the block payload. */
const du_fp du_r246_fp[] = {
    { 0xFF900698u, 0xAC8, 0xDE6B1CCFu }, { 0xFF901284u, 0x1094, 0x3820AC29u },
    { 0xFF904610u, 0x1994, 0xBA6C122Cu }, { 0xFF906320u, 0xBDC, 0x41E523C7u },
};
const int du_r246_fp_n = (int)(sizeof du_r246_fp / sizeof *du_r246_fp);

int du_ldr_has(const uint8_t *l, uint32_t size, const du_fp *fp, int n)    /* (l passed du_ldr_ok) */
{
    for (int i = 0; i < n; i++) {
        int found = 0;
        for (uint32_t o = 0; o + 16 <= size && !found;) {
            uint32_t flags = (uint32_t)l[o] | (uint32_t)l[o + 1] << 8, addr = rd32(l + o + 4), count = rd32(l + o + 8);
            o += 16;
            if (flags & 0x100) continue;
            if (addr == fp[i].addr && count == fp[i].count && du_crc32(0, l + o, count) == fp[i].crc) found = 1;
            o += count;
        }
        if (!found) return 0;
    }
    return 1;
}

int du_ldr_check(const uint8_t *l, uint32_t size, const du_fp *fp, int n)
{
    if (!du_ldr_ok(l, size)) return DU_F_BADLDR;
    if (!du_ldr_has(l, size, fp, n)) return DU_F_NOTOP1;
    return DU_F_OK;
}

int du_blocks_needed(uint32_t size)
{
    int nb = (int)((size + DU_BLOCK - 1) / DU_BLOCK);
    uint32_t tail = size - (uint32_t)(nb - 1) * DU_BLOCK;
    return nb + (DU_BLOCK - tail < 0x100 ? 1 : 0);
}

static int g_erase(const du_nand *d, int b) { return du_guard(b) ? d->erase(d->ctx, b) : -1; }
static int g_write(const du_nand *d, int b, const uint8_t *p) { return du_guard(b) ? d->write(d->ctx, b, p) : -1; }
static int g_read(const du_nand *d, int b, uint8_t *p) { return du_guard(b) ? d->read(d->ctx, b, p) : -1; }

int du_flash_ldr(const du_nand *d, const uint8_t *ldr, uint32_t size, uint8_t *buf, const du_fp *fp, int n)
{
    int c = du_ldr_check(ldr, size, fp, n);
    if (c) return c;
    /* blocks needed: the data, plus one 0xFF block if the last one is (almost) full (as te-boot's flasher) */
    int nb = (int)((size + DU_BLOCK - 1) / DU_BLOCK);
    uint32_t tail = size - (uint32_t)(nb - 1) * DU_BLOCK;
    int need = du_blocks_needed(size);
    /* plan: the good blocks from DU_FIRST_BLOCK, before touching anything */
    int plan[DU_LAST_BLOCK + 1], np = 0;
    for (int b = DU_FIRST_BLOCK; b <= DU_LAST_BLOCK && np < need; b++)
        if (!d->is_bad(d->ctx, b)) plan[np++] = b;
    if (np < need) return DU_F_NOSPACE;
    for (int i = 0; i < np; i++) if (!du_guard(plan[i])) return DU_F_GUARD;
    /* erase every good block of the boot area from 4 (as te-boot), then write and verify the planned ones */
    for (int b = DU_FIRST_BLOCK; b <= DU_LAST_BLOCK; b++)
        if (!d->is_bad(d->ctx, b) && g_erase(d, b)) return DU_F_ERASE;
    for (int i = 0; i < need; i++) {
        const uint8_t *src = i < nb ? ldr + (uint32_t)i * DU_BLOCK : 0;
        uint32_t len = i < nb - 1 ? DU_BLOCK : i == nb - 1 ? tail : 0;
        for (uint32_t k = 0; k < DU_BLOCK; k++) buf[k] = k < len ? src[k] : 0xFF;
        if (g_write(d, plan[i], buf)) return DU_F_WRITE;
    }
    for (int i = 0; i < need; i++) {                                         /* read back everything */
        uint32_t len = i < nb - 1 ? DU_BLOCK : i == nb - 1 ? tail : 0;
        if (g_read(d, plan[i], buf)) return DU_F_VERIFY;
        for (uint32_t k = 0; k < DU_BLOCK; k++)
            if (buf[k] != (k < len ? ldr[(uint32_t)i * DU_BLOCK + k] : 0xFF)) return DU_F_VERIFY;
    }
    return DU_F_OK;
}
