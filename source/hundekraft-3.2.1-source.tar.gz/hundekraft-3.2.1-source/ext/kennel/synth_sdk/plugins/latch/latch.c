/* latch: keep synth keyboard notes sounding after the keys come up, for drones. A feature plugin (docs/feature-hooks.md
 * "latch"): the red encoder push on the synth envelope page (T2, screen 0x16, no Shift) toggles it.
 *
 * While latch is on, the input filter takes the key-up of a keyboard key that played a synth note, so VoiceCtl never
 * gets the note off; the note input observer remembers the op1_note the key-down produced. Turning latch off, a new
 * chord, STOP, a sound key, the DRUM key, a slot or mode change release them with op1_key_up (the observers, the note
 * pipeline and the MIDI note-off, as the stock key-up would have).
 *
 * R246 details (Ghidra on R246, docs/feature-hooks.md "latch"):
 *   - a keyboard press goes to FUN_019ac0b0: if no sequencer player takes the key, it panics when the key's
 *     "sounding" byte 0x01AAD488[index] is already set (global_controller.cpp:240), sets it and plays the note
 *     (index + 0x35 + 12 * synth octave, velocity 0x7F, send_midi 1) through VoiceCtl key_down. The key-up
 *     (FUN_019ac2f8) clears that byte and plays the note off. A swallowed key-up must clear the byte here, or the
 *     next press of that key halts the OP-1.
 *   - a key a sequencer player took is not in that byte (it is in the player's key list): its key-up always goes on
 *     to the stock code, so a running sequencer gets its own key-ups and nothing is latched.
 * Keyboard notes only: MIDI in and sequencer notes never pass the input filter.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../../op1_feature.h"
#include "../../screens/stroke_font.h"

#ifdef OP1_HOST /* harness/latch_fc_test.c: R246's bytes as host data */
extern uint8_t host_key_sounding[24];
extern int32_t host_drum_bank, host_synth_oct, host_mode;
extern int host_t2_stock;
#define KEY_SOUNDING(i) (host_key_sounding[i])
#define DRUM_BANK()     (host_drum_bank)
#define SYNTH_OCTAVE()  (host_synth_oct)
#define CUR_MODE()      (host_mode)
#define T2_STOCK()      (host_t2_stock)
#else
#define KEY_SOUNDING(i) (((volatile uint8_t *)0x01AAD488)[i])                  /* global controller, per key index */
#define DRUM_BANK()     (*(volatile int *)0x01DE4C40 == 1)                      /* page_pos_is_drum */
#define SYNTH_OCTAVE()  (((const volatile int *)0x01DFE4E0)[*(volatile int *)0xFF8016D4 & 7])
#define CUR_MODE()      (*(volatile int *)0xFF907D58)                           /* ModeSwitcher: synth 0 */
/* the synth T2 page shows the stock ADSR screen object (vtable at +0xC), not sampler+'s own T2 page */
#define ADSR_VT 0x0190EA14u                                     /* measured natively, 3.1.4 rc2 */
#define T2_STOCK()      ({ const uint32_t *o = ((const uint32_t *const *)0x01DF4E54)[0x16]; o && o[3] == ADSR_VT; })
#endif

#define SCREEN_T2  0x16
#define KEY_RED    0x3E
#define KEY_STOP   0x23
#define KEY_DRUM   0x03

enum { NONE, DOWN, LATCHED };
static uint8_t on, state[24];
static op1_note note[24];
static uint32_t down;                    /* keyboard keys physically down (any mode) */
static int pending = -1, expected;       /* the key whose note the next note_in down should be */
static uint8_t red_taken;

/* KeyHandler key code -> keyboard index 0..23 (note_key_index 0x019C3322), -1 for other keys */
static int key_index(int code)
{
    static const int8_t idx[0x36] = {
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  1,  3,  5,      /* 0x00..0x0F: f3# g3# a3# */
        -1, -1, -1, -1, -1, -1, 10, 13, 15, 17, 20, 22,  7,  9, 11, 12,      /* 0x10..0x1F */
         8, -1, -1, -1, -1, -1, -1,  0,  2,  4,  6, -1, -1, -1, -1, -1,      /* 0x20..0x2F */
        14, 16, 18, 19, 21, 23 };                                            /* 0x30..0x35 */
    return code >= 0 && code < 0x36 ? idx[code] : -1;
}
static int sound_key(int code) { return (code >= 0x2D && code <= 0x2F) || (code >= 0x10 && code <= 0x14); }

static void release(int i)
{
    if (state[i] == LATCHED) {
        state[i] = NONE;
        if (!DRUM_BANK()) { op1_note n = note[i]; n.velocity = 0x40; op1_key_up(&n); }  /* as the stock key-up */
    }
}
static int any_latched(void) { for (int i = 0; i < 24; i++) if (state[i] == LATCHED) return 1; return 0; }
static void release_all(void) { for (int i = 0; i < 24; i++) release(i); }
static void forget(void) { for (int i = 0; i < 24; i++) if (state[i] == LATCHED) state[i] = NONE; }

static void set_on(int v)
{
    on = (uint8_t)v;
    if (!on) {
        release_all();
        for (int i = 0; i < 24; i++) state[i] = NONE;     /* keys still down go up the stock way */
    }
    op1_toast(on ? "latch on" : "latch off");
}

static int input(const op1_input *in)
{
    if (in->type != OP1_IN_KEY) return 0;
    int code = in->code, i = key_index(code);
    pending = -1;
    if (i >= 0) {
        uint32_t bit = 1u << i;
        if (in->pressed) {
            uint32_t was = down;
            down |= bit;
            if (!on || DRUM_BANK()) return 0;
            if (!was && any_latched()) release_all();      /* first key after all were up: a new chord */
            release(i);                                    /* a latched key again: R246 ignores a held note */
            state[i] = NONE;
            pending = i; expected = i + 0x35 + 12 * SYNTH_OCTAVE();
            return 0;
        }
        down &= ~bit;
        if (state[i] != DOWN) return 0;
        state[i] = NONE;
        if (!on || DRUM_BANK() || !KEY_SOUNDING(i)) return 0;   /* a player's key, or the stock code's to release */
        KEY_SOUNDING(i) = 0;                               /* what the stock key-up would clear: the next press is safe */
        state[i] = LATCHED;
        return 1;
    }
    if (code == KEY_RED && in->mode == 0 && in->screen == SCREEN_T2 && !in->shift && T2_STOCK()) {
        if (in->pressed) { red_taken = 1; set_on(!on); return 1; }
    }
    if (code == KEY_RED && !in->pressed && red_taken) { red_taken = 0; return 1; }
    if (in->pressed && (code == KEY_STOP || code == KEY_DRUM || sound_key(code))) release_all();   /* before the bank
                                                                     * or slot changes: the note offs go to this synth */
    return 0;
}

static void note_down(const op1_note *n, int param)
{
    (void)param;
    if (pending < 0) return;
    if (n->note == expected) { note[pending] = *n; state[pending] = DOWN; }
    pending = -1;
}
static const op1_note_input observe = { .down = note_down };

static void event(int id, int32_t arg)
{
    (void)arg;
    if (id == OP1_EV_NOTES_RESET) forget();               /* the stock voice reset has silenced them */
    if (id == OP1_EV_SLOT || (id == OP1_EV_MODE && DRUM_BANK())) { if (DRUM_BANK()) forget(); else release_all(); }
}

/* Keyboard strip in the top margin (owner-approved art run/screens-2026-11-03/latch.svg): 24 thin lines, one per
 * keyboard key, black keys shorter; navy when free, pink when latched; then "LATCH n". Every line is at most 9 px
 * (R246's rasterizer keeps a buffer the size of the longest line ever drawn). Integers only. */
#define STRIP_X 64    /* strip x 64..133, text to x 182: the left half of the top margin. Right of it the stock FX name box (T3, x 257..312)
                        * and REACTOR's vessel (x 187..261, from y 2) are in the way; FREQ on T3 ends at x 44 */
#define STRIP_DX 3
static void overlay(void *r, int32_t screen)
{
    static const uint8_t navy[4] = { 0x38, 0x35, 0x72, 255 }, pink[4] = { 0xff, 0x90, 0xa7, 255 };
    (void)screen;
    if (!on || CUR_MODE() != 0) return;                    /* synth mode only */
    int n = 0;
    for (int i = 0; i < 24; i++) n += state[i] == LATCHED;
    for (int pass = 0; pass < 2; pass++)                   /* free keys first, so a latched line is never hidden */
        for (int i = 0; i < 24; i++) {
            int lit = state[i] == LATCHED, k = i % 12, black = k == 1 || k == 3 || k == 5 || k == 8 || k == 10;
            if (lit != pass) continue;
            int32_t x = OP1_Q10(STRIP_X + STRIP_DX * i);
            sf_line(r, x, OP1_Q10(4), x, OP1_Q10(black ? 9 : 13), 1536, lit ? pink : navy);
        }
    int32_t x = sf_text(r, OP1_Q10(STRIP_X + STRIP_DX * 23 + 6), OP1_Q10(5), OP1_Q10(1), "LATCH", OP1_Q10(1), pink);
    if (n > 0) {
        char d[3] = { 0, 0, 0 };
        if (n >= 10) { d[0] = (char)('0' + n / 10); d[1] = (char)('0' + n % 10); } else d[0] = (char)('0' + n);
        sf_text(r, x + OP1_Q10(3), OP1_Q10(5), OP1_Q10(1), d, OP1_Q10(1), pink);
    }
}

static const char *const claims[] = { "key:synth:t2+orange", 0 };
const op1_feature_t FEATURE_latch = { .api = OP1_FEATURE_API, .priority = 950, .name = "latch", .input = input,
    .note_in = &observe, .event = event, .overlay = overlay, .claims = claims };
