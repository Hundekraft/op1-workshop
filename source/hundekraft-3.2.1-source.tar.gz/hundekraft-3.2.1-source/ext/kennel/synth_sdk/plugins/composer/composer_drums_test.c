/* composer drums model checks; build: cc -std=c11 -Wall -Wextra -fsanitize=address,undefined composer_drums_test.c composer_drums.c composer_model.c composer_styles.c -o composer_drums_test
 * Every style has a groove row (and a family); at the defaults every style's groove differs from every other's (kick,
 * backbeat and time voices, at least 8 hits in two bars), uses the voices its row lists, a kick and a snare, clap or
 * rim; every style x 40 seeds x sections x passes x settings (0 / 50 / 100): events bounded,
 * sorted, inside the section, valid voices and velocities, deterministic. Per family the written groove (kick, snare /
 * clap, hats where they belong); section B fuller with a crash on bar 1, C sparse / half time; a fill before a section
 * change (bigger with Fills up), none at Fills 0; Density more hats, Ghosts more ghost notes, Vary 0 the same bars and
 * repeats; swing moves the odd 16ths; Dynamics 0 flattens. An event hash pins the output.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "composer_drums.h"

static cm_event ev[CD_MAX_EVENTS], ev2[CD_MAX_EVENTS];
static int style_named(const char *name)
{
    for (int i = 0; i < cm_nstyles; i++) if (!strcmp(cm_styles[i].name, name)) return i;
    assert(!"style");
    return 0;
}
static void setup(cm_config *c, cd_config *d, int style)
{
    cm_default(c, style, 7); cd_default(d, 7);
    c->swing = 50;                                    /* straight: steps are tick / 24 */
    d->vary = 0; d->ghosts = 0; d->fills = 0; d->density = 50;
}
/* a hit of voice v at step s (0..15) of bar b (up to 4 ticks late: a laid-back style) */
static int at(int n, int v, int b, int s)
{
    for (int i = 0; i < n; i++) if (ev[i].note == v && ev[i].tick >= (b * 16 + s) * CM_TICKS && ev[i].tick <= (b * 16 + s) * CM_TICKS + 4) return 1;
    return 0;
}
static int count(int n, int v, int lo, int hi)        /* voice v (or -1 any) with lo <= vel < hi */
{
    int k = 0;
    for (int i = 0; i < n; i++) if ((v < 0 || ev[i].note == v) && ev[i].vel >= lo && ev[i].vel < hi) k++;
    return k;
}
static int bar_sig(int n, int b, uint32_t *h)         /* the bar's events relative to its start */
{
    uint32_t x = 2166136261u; int k = 0;
    for (int i = 0; i < n; i++) if (ev[i].tick / (16 * CM_TICKS) == b) {
        x = (x ^ (uint32_t)(ev[i].tick % (16 * CM_TICKS))) * 16777619u; x = (x ^ ev[i].note) * 16777619u; x = (x ^ ev[i].vel) * 16777619u; k++;
    }
    *h = x; return k;
}

int main(void)
{
    /* every style has its row (and a family); the design's examples are where it puts them */
    for (int st = 0; st < cm_nstyles; st++) assert(cd_family(st) >= 0 && cd_family(st) < CD_FAMILIES);
    static const struct { const char *s; int f; } fam[] = {
        {"deep house", CD_FOUR}, {"melodic techno", CD_FOUR}, {"trance", CD_FOUR}, {"acid", CD_FOUR}, {"nu-disco", CD_FOUR},
        {"amapiano", CD_FOUR}, {"pop", CD_BACKBEAT}, {"synthwave", CD_BACKBEAT}, {"city pop", CD_BACKBEAT}, {"funk", CD_BACKBEAT},
        {"gospel", CD_BACKBEAT}, {"ballad", CD_BACKBEAT}, {"folk", CD_BACKBEAT}, {"boom bap", CD_HALF}, {"lo-fi", CD_HALF},
        {"trap", CD_HALF}, {"neo-soul", CD_HALF}, {"darksynth", CD_HALF}, {"drum&bass", CD_BROKEN}, {"breakbeat", CD_BROKEN},
        {"garage", CD_BROKEN}, {"idm", CD_BROKEN}, {"reggaeton", CD_LATIN}, {"afrobeats", CD_LATIN}, {"bossa nova", CD_LATIN},
        {"ambient", CD_SPARSE}, {"cinematic", CD_SPARSE}, {"film noir", CD_SPARSE}, {"dub techno", CD_SPARSE}};
    for (unsigned i = 0; i < sizeof fam / sizeof fam[0]; i++) assert(cd_family(style_named(fam[i].s)) == fam[i].f);
    assert(cd_family(-1) < 0 && cd_family(cm_nstyles) < 0 && !cd_voices(cm_nstyles));
    /* the stock pads: TE's standard layout (docs/composer-drums-design-2026-11-05.md, Pads) */
    static const uint8_t want_pad[CD_VOICES] = {0, 2, 5, 4, 8, 10, 12, 14, 15, 6, 13};
    assert(!memcmp(cd_pad_stock, want_pad, sizeof want_pad));

    /* every style its own groove: section A at the defaults (density 50; vary, ghosts and fills 0; straight), bars 1
     * and 2 as a mask per voice. Each style plays its row's voices (no crash in A), a kick and a backbeat drum; every
     * pair differs in the kick, the backbeat (snare, clap, rim) or the time voices (hats, ride, tambourine), by at
     * least 8 hits. */
    static uint32_t gm[64][CD_VOICES];
    assert(cm_nstyles <= 64);
    for (int st = 0; st < cm_nstyles; st++) {
        cm_config c; cd_config d;
        setup(&c, &d, st);
        int n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS), used = 0;
        for (int v = 0; v < CD_VOICES; v++) gm[st][v] = 0;
        for (int i = 0; i < n; i++) {
            used |= 1 << ev[i].note;
            if (ev[i].tick < 32 * CM_TICKS) gm[st][ev[i].note] |= 1u << (ev[i].tick / CM_TICKS);
        }
        int want = cd_voices(st);
        if (used != want) { fprintf(stderr, "%s: voices %03x, its row %03x\n", cm_styles[st].name, (unsigned)used, (unsigned)want); assert(0); }
        assert(want >> CD_KICK & 1 && (want & (1 << CD_SNARE | 1 << CD_CLAP | 1 << CD_RIM)) && !(want >> CD_CRASH & 1));
    }
    int closest = 1000, ca = 0, cb = 0;
    static const uint8_t groups[3][4] = {{CD_KICK, CD_KICK, CD_KICK, CD_KICK}, {CD_SNARE, CD_CLAP, CD_RIM, CD_RIM}, {CD_CH, CD_OH, CD_RIDE, CD_TAMB}};
    for (int a = 0; a < cm_nstyles; a++)
        for (int b = a + 1; b < cm_nstyles; b++) {
            int dist = 0;
            for (int g = 0; g < 3; g++) for (int k = 0; k < 4; k++) if (!k || groups[g][k] != groups[g][k - 1]) {
                uint32_t x = gm[a][groups[g][k]] ^ gm[b][groups[g][k]];
                for (; x; x &= x - 1) dist++;
            }
            if (dist < closest) closest = dist, ca = a, cb = b;
            if (dist < 8) { fprintf(stderr, "%s and %s: %d hits apart\n", cm_styles[a].name, cm_styles[b].name, dist); assert(0); }
        }

    /* bounds and determinism */
    uint32_t fnv = 2166136261u; long events = 0;
    static const uint8_t lv[3] = {0, 50, 100};
    for (int st = 0; st < cm_nstyles; st++)
        for (uint32_t seed = 1; seed <= 40; seed++) {
            cm_config c; cd_config d;
            cm_default(&c, st, seed); cd_default(&d, seed);
            d.density = lv[seed % 3]; d.vary = lv[seed / 3 % 3]; d.ghosts = lv[seed / 9 % 3]; d.fills = lv[(seed + 1) % 3];
            c.dyn = (uint8_t)(seed * 37 % 101); c.swing = (uint8_t)(seed % 2 ? 0 : 50 + seed % 26); c.length = (uint8_t)(seed % 4 ? 0 : 25 + 5 * (seed % 36));
            for (int sec = 0; sec < 3; sec++)
                for (int occ = 0; occ < 3; occ++) {
                    int next = (int)(seed + occ) % 4 - 1, prev = (int)(seed * 3 + occ) % 4 - 1;
                    int n = cd_compose(&c, &d, sec, occ, prev, next, ev, CD_MAX_EVENTS);
                    int m = cd_compose(&c, &d, sec, occ, prev, next, ev2, CD_MAX_EVENTS);
                    assert(n == m && !memcmp(ev, ev2, sizeof ev[0] * (size_t)n));
                    assert(n < CD_MAX_EVENTS && (n > 0 || cd_family(st) == CD_SPARSE));
                    for (int i = 0; i < n; i++) {
                        assert(ev[i].note < CD_VOICES && ev[i].vel >= 1 && ev[i].vel <= 127 && ev[i].len > 0);
                        assert(ev[i].tick + ev[i].len <= CM_SECTION_TICKS && (!i || ev[i].tick >= ev[i - 1].tick));
                        const uint8_t *e = (const uint8_t *)&ev[i];
                        for (unsigned k = 0; k < sizeof ev[i]; k++) fnv = (fnv ^ e[k]) * 16777619u;
                    }
                    events += n;
                }
        }

    /* the written grooves, section A at the defaults (vary, ghosts and fills 0) */
    cm_config c; cd_config d; int n;
    setup(&c, &d, style_named("deep house"));
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int b = 0; b < 8; b++) for (int s = 0; s < 16; s += 4) assert(at(n, CD_KICK, b, s));    /* four on the floor */
    for (int b = 0; b < 8; b++) assert(at(n, CD_CLAP, b, 4) && at(n, CD_CLAP, b, 12) && at(n, CD_OH, b, 2) && at(n, CD_OH, b, 14));
    setup(&c, &d, style_named("pop"));
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int b = 0; b < 8; b++) {
        assert(at(n, CD_KICK, b, 0) && at(n, CD_KICK, b, 8) && at(n, CD_SNARE, b, 4) && at(n, CD_SNARE, b, 12));
        for (int s = 0; s < 16; s++) assert(at(n, CD_CH, b, s) == !(s & 1));                      /* 8th hats */
    }
    int pop_ch = count(n, CD_CH, 0, 128);
    setup(&c, &d, style_named("boom bap"));
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int b = 0; b < 8; b++) assert(at(n, CD_KICK, b, 0) && at(n, CD_SNARE, b, 4) && at(n, CD_SNARE, b, 12) && !at(n, CD_SNARE, b, 8));
    setup(&c, &d, style_named("trap"));                                                           /* half time */
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int b = 0; b < 8; b++) assert(at(n, CD_SNARE, b, 8) && at(n, CD_CLAP, b, 8) && !at(n, CD_SNARE, b, 4) && !at(n, CD_SNARE, b, 12));
    setup(&c, &d, style_named("drum&bass"));
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int b = 0; b < 8; b++) assert(at(n, CD_KICK, b, 0) && at(n, CD_KICK, b, 10) && at(n, CD_SNARE, b, 4) && at(n, CD_SNARE, b, 12));
    setup(&c, &d, style_named("breakbeat"));
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    assert(count(n, CD_SNARE, 0, CD_GHOST_VEL) >= 8 * 3);                                        /* amen ghosts */
    setup(&c, &d, style_named("reggaeton"));
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int b = 0; b < 8; b++) assert(at(n, CD_SNARE, b, 3) && at(n, CD_SNARE, b, 6) && at(n, CD_SNARE, b, 11) && at(n, CD_SNARE, b, 14));
    setup(&c, &d, style_named("bossa nova"));
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int b = 0; b < 8; b++) assert(at(n, CD_RIM, b, 0) && at(n, CD_RIM, b, 3) && at(n, CD_RIM, b, 6) && at(n, CD_RIM, b, 10));
    setup(&c, &d, style_named("afrobeats"));
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    assert(count(n, CD_TAMB, 0, 128) == 8 * 16 && !count(n, CD_CH, 0, 128) && count(n, CD_LTOM, 0, 128) == 8);   /* shaker, toms */
    setup(&c, &d, style_named("breakbeat"));                                                     /* the amen on the ride */
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    assert(count(n, CD_RIDE, 0, 128) == 8 * 8 && !count(n, CD_CH, 0, 128));
    setup(&c, &d, style_named("film noir"));                                                     /* the jazz ride */
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int b = 0; b < 8; b++) assert(at(n, CD_RIDE, b, 0) && at(n, CD_RIDE, b, 4) && at(n, CD_RIDE, b, 7) && at(n, CD_RIDE, b, 15) && at(n, CD_CH, b, 4));
    setup(&c, &d, style_named("lo-fi"));                                                         /* laid back */
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int i = 0; i < n; i++) assert(ev[i].tick % CM_TICKS == (ev[i].note == CD_KICK ? 0 : 3));
    setup(&c, &d, style_named("chiptune"));                                                      /* one velocity */
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    assert(count(n, -1, 100, 101) == n);
    setup(&c, &d, style_named("cinematic"));                                                     /* ride swells, odd bars */
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int i = 0, last = 0; i < n; i++) if (ev[i].note == CD_RIDE) {
        int b = ev[i].tick / (16 * CM_TICKS);
        assert(b & 1);
        if (ev[i].tick % (16 * CM_TICKS) > 4 * CM_TICKS) assert(ev[i].vel > last);
        last = ev[i].vel;
    }
    setup(&c, &d, style_named("ballad"));                                                        /* cross stick, snare in B */
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    assert(count(n, CD_RIM, 0, 128) == 16 && !count(n, CD_SNARE, 0, 128));
    n = cd_compose(&c, &d, 1, 0, 0, 1, ev, CD_MAX_EVENTS);
    assert(!count(n, CD_RIM, 0, 128) && at(n, CD_SNARE, 1, 4) && at(n, CD_SNARE, 1, 12));
    setup(&c, &d, style_named("trance"));                                                        /* crashes in B */
    n = cd_compose(&c, &d, 1, 0, 0, 1, ev, CD_MAX_EVENTS);
    assert(count(n, CD_CRASH, 0, 128) == 2 && at(n, CD_CRASH, 0, 0) && at(n, CD_CRASH, 4, 0));
    setup(&c, &d, style_named("ambient"));
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    assert(count(n, CD_KICK, 0, 128) == 8 && !count(n, CD_SNARE, 0, 128) && count(n, CD_RIM, 0, 128) >= 8);

    /* sections: B fuller with a crash on bar 1, C sparse (no kick) or half time */
    setup(&c, &d, style_named("pop"));
    int na = cd_compose(&c, &d, 0, 0, -1, 0, ev2, CD_MAX_EVENTS);
    n = cd_compose(&c, &d, 1, 0, 0, 1, ev, CD_MAX_EVENTS);
    assert(n > na && at(n, CD_CRASH, 0, 0) && count(n, CD_OH, 0, 128) >= 8 && count(n, CD_KICK, 0, 128) > 16);
    n = cd_compose(&c, &d, 2, 0, 1, 2, ev, CD_MAX_EVENTS);
    assert(n < na && count(n, CD_KICK, 0, 128) == 8 && count(n, CD_SNARE, 0, 128) == 8);
    for (int b = 0; b < 8; b++) assert(at(n, CD_KICK, b, 0) && at(n, CD_SNARE, b, 8));
    setup(&c, &d, style_named("melodic techno"));
    n = cd_compose(&c, &d, 2, 0, 1, 2, ev, CD_MAX_EVENTS);
    assert(!count(n, CD_KICK, 0, 128) && count(n, CD_CLAP, 0, 128) == 16);                       /* the breakdown */

    /* fills: before a section change at once, at Fills 0 never; bigger with Fills up */
    setup(&c, &d, style_named("pop"));
    assert(cd_fill_bars(&c, &d, 0, 0, 1) == 0);
    n = cd_compose(&c, &d, 0, 0, -1, 1, ev, CD_MAX_EVENTS);
    assert(!count(n, CD_LTOM, 0, 128) && !count(n, CD_HTOM, 0, 128));
    int sizes[3] = {0, 0, 0};
    for (int k = 0; k < 3; k++) {
        d.fills = (uint8_t)(k == 0 ? 10 : k == 1 ? 50 : 100);
        long span = 0;
        for (uint32_t seed = 1; seed <= 30; seed++) {
            d.seed_fill = seed * 2654435761u;
            assert(cd_fill_bars(&c, &d, 0, 0, 1) & 0x80);
            n = cd_compose(&c, &d, 0, 0, -1, 1, ev, CD_MAX_EVENTS);
            int first = 16;                           /* the fill's first step: the bar's toms or snare run */
            for (int i = 0; i < n; i++) {
                int b = ev[i].tick / (16 * CM_TICKS), s = ev[i].tick / CM_TICKS % 16;
                if (b == 7 && (ev[i].note == CD_LTOM || ev[i].note == CD_HTOM || (ev[i].note == CD_SNARE && s != 4 && s != 12)) && s < first) first = s;
            }
            assert(first < 16);
            span += 16 - first;
        }
        sizes[k] = (int)span;
    }
    assert(sizes[0] < sizes[1] && sizes[1] < sizes[2]);
    d.fills = 50;
    /* a crash on bar 1 after a section change (B has one anyway) */
    n = cd_compose(&c, &d, 0, 1, 1, 0, ev, CD_MAX_EVENTS);
    assert(at(n, CD_CRASH, 0, 0));
    d.fills = 0;
    n = cd_compose(&c, &d, 0, 1, 1, 0, ev, CD_MAX_EVENTS);
    assert(!at(n, CD_CRASH, 0, 0));

    /* density: more hats; ghosts: more ghost notes and rolls; ranges stay bounded at 0 and 100 */
    setup(&c, &d, style_named("pop"));
    d.density = 0; n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS); int ch0 = count(n, CD_CH, 0, 128);
    d.density = 100; n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS); int ch100 = count(n, CD_CH, 0, 128);
    assert(ch0 < pop_ch && pop_ch < ch100 && ch0 == 32 && ch100 == 128);
    d.density = 50;
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS); assert(!count(n, CD_SNARE, 0, CD_GHOST_VEL));
    d.ghosts = 50; n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS); int g50 = count(n, CD_SNARE, 0, CD_GHOST_VEL);
    d.ghosts = 100; n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS); int g100 = count(n, CD_SNARE, 0, CD_GHOST_VEL);
    assert(0 < g50 && g50 < g100 && count(n, CD_CH, 0, 128) > 8 * 8);                            /* rolls add hats */
    setup(&c, &d, style_named("trap")); d.ghosts = 100;
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    int offgrid = 0;
    for (int i = 0; i < n; i++) offgrid += ev[i].note == CD_CH && ev[i].tick % CM_TICKS;
    assert(offgrid >= 8);                                                                          /* trap hat rolls */

    /* vary 0: every bar of one parity the same and every repeat the same; vary 100 moves bars and repeats */
    setup(&c, &d, style_named("funk"));
    uint32_t h0, h1; n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int b = 2; b < 8; b++) { bar_sig(n, b, &h1); bar_sig(n, b & 1, &h0); assert(h0 == h1); }
    n = cd_compose(&c, &d, 0, 3, -1, 0, ev2, CD_MAX_EVENTS);
    assert(n == cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS) && !memcmp(ev, ev2, sizeof ev[0] * (size_t)n));
    int differ = 0;
    d.vary = 100;
    for (uint32_t seed = 1; seed <= 10; seed++) {
        d.seed_groove = seed;
        int a = cd_compose(&c, &d, 0, 0, -1, 0, ev2, CD_MAX_EVENTS), b = cd_compose(&c, &d, 0, 1, -1, 0, ev, CD_MAX_EVENTS);
        differ += a != b || memcmp(ev, ev2, sizeof ev[0] * (size_t)a);
    }
    assert(differ >= 8);

    /* swing: odd 16ths late by (swing - 50) * 48 / 100 ticks; dynamics 0: every velocity 90 */
    setup(&c, &d, style_named("pop")); d.density = 100; c.swing = 66;
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    for (int i = 0; i < n; i++) assert(ev[i].tick % (2 * CM_TICKS) == 0 || ev[i].tick % (2 * CM_TICKS) == CM_TICKS + 7);
    c.swing = 50; c.dyn = 0;
    n = cd_compose(&c, &d, 0, 0, -1, 0, ev, CD_MAX_EVENTS);
    assert(count(n, -1, CM_DYN_MID, CM_DYN_MID + 1) == n);

    /* the densest settings fit the buffer */
    int most = 0;
    for (int st = 0; st < cm_nstyles; st++) for (int sec = 0; sec < 3; sec++) {
        setup(&c, &d, st); d.density = d.vary = d.ghosts = d.fills = 100;
        n = cd_compose(&c, &d, sec, 1, (sec + 2) % 3, (sec + 1) % 3, ev, CD_MAX_EVENTS);
        if (n > most) most = n;
    }
    assert(most < CD_MAX_EVENTS);
    printf("composer_drums_test: closest styles %s and %s (%d hits in two bars); most events %d of %d\n", cm_styles[ca].name,
           cm_styles[cb].name, closest, most, CD_MAX_EVENTS);
    assert(fnv == 0x97e19ebdu);                       /* a change to the grooves must be deliberate */
    printf("composer_drums_test: ok (%ld events, hash %08x)\n", events, (unsigned)fnv);
    return 0;
}
