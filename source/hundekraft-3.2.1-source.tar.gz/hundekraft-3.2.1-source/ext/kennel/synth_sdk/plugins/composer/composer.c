/* composer: generative sequencer (synth mode) on the model in composer_model.c.
 * Threads: the main-loop service (OP1_EV_SERVICE) owns the plan and composes; the tick only plays a ready event
 * buffer. While a section plays, the service composes the next one into the other buffer (busy guards the swap). A
 * setting change or a held chord key recomposes the playing pass, swapped in at the next bar. Stopped, buffer cur
 * always holds pass 0, so a key starts at once.
 * Keys: a key starts it (held), Shift on release latches. While it runs, another key sets the chord (its pitch class
 * above the song key) from the next bar for as long as it is held. STOP, a synth slot change and disk mode stop it.
 * Drum page (composer picked as the drum sequencer): its own player plays the song's DRUMS part (composer_drums.c) on
 * the kit's pads; see "drums" below.
 * Song: each 8-bar pass is a section of the style's song form (A verse, B chorus / drop, C bridge / breakdown), or
 * one section looped (LOOP = A, B ONLY, C ONLY).
 * Shift page (shown while Shift is held): KEY FROM (turn FOLLOW / MANUAL, push LOCK: the playing pass repeats exactly
 * until pushed again), SWING and LENGTH (STYLE or a percentage, saved), NEXT (turn a section of the song form, push
 * JUMP: from the next bar that section plays from its start; in SONG the form goes on after it, in LOOP / B ONLY /
 * C ONLY the mode's own section comes back after one pass).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../op1_feature_seq.h"
#include "../../op1_synth.h"
#include "../../seq/seq_text.h"
#include "composer_model.h"
#include "composer_drums.h"
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */

#ifdef OP1_HOST /* harness/composer_fc_test.c: R246's bank, Shift and keyboard octaves as host data */
extern int32_t host_bank, host_drum_oct, host_synth_oct; extern uint8_t host_shift;
#define MODE() (host_bank == 1)
#define SHIFT() (host_shift)
#define OCTAVE() (host_synth_oct)
#define DRUM_OCT() (host_drum_oct)
extern int fc_screen;
#define SHOWN() (fc_screen == 0x2D)
#else
#define MODE() (*(volatile int *)0x01DE4C40 == 1)
#define SHIFT() (*(volatile uint8_t *)0x01DD7F78)
/* keyboard octave of the current synth slot */
#define OCTAVE() (((const int *)0x01DFE4E0)[*(volatile int *)0xFF8016D4 & 7])
/* keyboard octave of the current drum slot (as kn_seq.c), and composer's page (slot 0x2D) on screen */
#define DRUM_OCT() (((const int *)0x01DFE500)[*(volatile int *)0xFF8016D8 & 7])
#define SHOWN() (*(volatile int *)0x018B65C8 == 0x2D)
#endif

#define VOICES 12
#define BAR_TICKS (16 * CM_TICKS)
typedef struct {
    cm_config cfg, undo;
    uint8_t undo_valid, role, follow, page, changed, plan_key, song;
    cm_plan plan;                                     /* the service's */
    cm_event ev[2][CM_MAX_EVENTS];
    int16_t n[2];
    volatile uint8_t cur, spare_ready, spare_bar, busy, edit, armed, running, latched;
    volatile int8_t over;                             /* held chord: semitones above the key, -1 none */
    volatile uint8_t lock, spare_jump;                /* lock: the playing pass repeats; spare_jump: the spare is a jump */
    uint8_t next, jump, jump_sec;                     /* NEXT pick (section + 1, 0 none), a queued jump to jump_sec */
    int8_t forced_sec;                                /* LOOP / B ONLY / C ONLY: pass forced_pass plays this section */
    uint16_t playing_pass, spare_pass, armed_pass, forced_pass;
    uint16_t t, idx;                                  /* tick in the section, next event */
    uint8_t start_key, over_key;
    uint32_t held, nonce;
    int16_t id[VOICES];
    uint16_t off[VOICES];
    int8_t sec[2];                                    /* the section each buffer was composed for (the header's) */
} composer;
static composer cs;
static uint8_t loaded;
static volatile uint32_t composer_ticks[2];                  /* player ticks seen, synth / drum (read from RAM in the emulator) */
static int accum[4];

static int clamp(int x, int lo, int hi) { return x < lo ? lo : x > hi ? hi : x; }
static void copy(void *d, const void *s, unsigned n) { for (unsigned i = 0; i < n; i++) ((uint8_t *)d)[i] = ((const uint8_t *)s)[i]; }
static int same(const void *a, const void *b, unsigned n) { for (unsigned i = 0; i < n; i++) if (((const uint8_t *)a)[i] != ((const uint8_t *)b)[i]) return 0; return 1; }
static uint32_t mix(uint32_t a)
{
    a ^= a >> 16; a *= 0x7FEB352Du; a ^= a >> 15; a *= 0x846CA68Bu; a ^= a >> 16;
    return a ? a : 1;
}
static int song_key(void)
{
    int32_t h[4];
    if (cs.follow && op1_harmony_context(h)) return h[0];
    return cs.cfg.key;
}

/* ---- notes ---- */
static void release_all(void)
{
    for (int v = 0; v < VOICES; v++) if (cs.id[v] >= 0) { op1_seq_note_off(cs.id[v]); cs.id[v] = -1; }
}
static void note_start(const cm_event *e)
{
    int note = e->note + 12 * OCTAVE(), v, free = -1, soon = 0;
    if (note < 0 || note > 127) return;
    for (v = 0; v < VOICES; v++) {
        if (cs.id[v] < 0) { if (free < 0) free = v; continue; }
        if ((cs.id[v] & 255) == note) { op1_seq_note_off(cs.id[v]); cs.id[v] = -1; if (free < 0) free = v; }
        else if (cs.off[v] < cs.off[soon] || cs.id[soon] < 0) soon = v;
    }
    if (free < 0) { op1_seq_note_off(cs.id[soon]); cs.id[soon] = -1; free = soon; }
    cs.id[free] = (int16_t)op1_seq_note_on_quantized(0, note, cs.start_key, e->vel);
    cs.off[free] = (uint16_t)(cs.t + e->len);
}

/* ---- the service: plan and composing ---- */
/* the section of song pass `pass` and its occurrence: the song mode's, or a jump's forced section (its anchor) */
static int section_of(int pass, int *occurrence)
{
    if (cs.forced_sec >= 0 && pass == cs.forced_pass) { *occurrence = 0; return cs.forced_sec; }
    return cm_song_at(&cs.cfg, cs.song, pass, occurrence);
}
/* the style's song form has section s */
static int in_form(int s)
{
    for (const char *f = cm_styles[cs.cfg.style].song; f && *f; f++) if (*f - 'A' == s) return 1;
    return 0;
}
/* the pass a jump to section `sec` plays, from pass `from` on: in SONG the form's next pass with that section (the form
 * goes on from there), else pass `from` forced to that section, after which the mode's own section comes back */
static int jump_pass(int from, int sec)
{
    int len = 0, occurrence;
    while (cm_styles[cs.cfg.style].song[len]) len++;
    cs.forced_sec = -1;
    if (cs.song == CM_SONG_FORM)
        for (int p = from; p < from + len; p++) if (cm_song_at(&cs.cfg, cs.song, p, &occurrence) == sec) return p;
    cs.forced_sec = (int8_t)sec; cs.forced_pass = (uint16_t)from;
    return from;
}
/* the plan for song pass `pass` (its section), with the held chord from step over_from */
static void build(int over_from, int pass)
{
    cm_config c;
    int occurrence;
    copy(&c, &cs.cfg, sizeof c);
    c.key = (uint8_t)song_key();
    cs.plan_key = c.key;
    cm_plan_section(&cs.plan, &c, section_of(pass, &occurrence));
    if (cs.over >= 0 && over_from < CM_STEPS) cm_plan_override(&cs.plan, &c, over_from, cs.over);
}
static int compose(int buf, int pass)
{
    cm_config c;
    int occurrence;
    copy(&c, &cs.cfg, sizeof c);
    c.key = cs.plan_key;
    cs.sec[buf] = (int8_t)section_of(pass, &occurrence);
    return cs.n[buf] = (int16_t)cm_compose(&cs.plan, &c, cs.role, occurrence, cs.ev[buf], CM_MAX_EVENTS);
}
/* the spare from step 0: pass `pass` for the section end (bar 0) or a jump at the next bar (jump 1) */
static void spare(int pass, int jump)
{
    build(0, pass); compose(!cs.cur, pass);
    cs.spare_pass = (uint16_t)pass; cs.spare_bar = 0; cs.spare_jump = (uint8_t)jump; cs.spare_ready = 1;
}
static void service(void)
{
    if (song_key() != cs.plan_key) cs.edit = 1;
    if (!cs.running || !cs.armed) {
        if (cs.edit || !cs.armed || cs.jump) {
            int pass = 0;                              /* stopped, a queued jump makes the next start begin there */
            if (cs.jump) { cs.jump = 0; pass = jump_pass(0, cs.jump_sec); cs.spare_jump = 1; }
            else if (cs.spare_jump) pass = cs.armed_pass;
            else cs.forced_sec = -1;
            cs.armed = 0; cs.edit = 0;
            build(CM_STEPS, pass); compose(cs.cur, pass);
            cs.armed_pass = (uint16_t)pass;
            if (cs.running) cs.playing_pass = (uint16_t)pass, cs.spare_jump = 0;
            cs.spare_ready = 0; cs.armed = 1;
        }
        return;
    }
    cs.busy = 1;
    int next = cs.lock ? cs.playing_pass : cs.playing_pass + 1;   /* locked, the playing pass comes again */
    if (cs.jump) { cs.jump = 0; cs.edit = 0; spare(jump_pass(cs.playing_pass + 1, cs.jump_sec), 1); }
    else if (cs.edit && cs.spare_ready && cs.spare_jump) { cs.edit = 0; spare(cs.spare_pass, 1); }   /* the jump, as edited */
    else if (cs.edit) {
        cs.edit = 0;
        int from = (cs.t / BAR_TICKS + 1) * 16;
        if (from < CM_STEPS) { build(from, cs.playing_pass); compose(!cs.cur, cs.playing_pass); cs.spare_pass = cs.playing_pass; cs.spare_bar = 1; cs.spare_jump = 0; cs.spare_ready = 1; }
        else spare(next, 0);
    } else if (!cs.spare_ready) spare(next, 0);
    cs.busy = 0;
}

/* ---- the player ---- */
static void start(int key, int latch)
{
    release_all();
    cs.start_key = (uint8_t)key; cs.held = 1u << key; cs.latched = (uint8_t)latch; cs.over = -1;
    cs.t = 0; cs.idx = 0; cs.playing_pass = cs.armed_pass; cs.spare_ready = 0; cs.spare_jump = 0;
    cs.running = 1;
}
static void halt(void)
{
    if (!cs.running && cs.over < 0) return;
    cs.running = 0; cs.latched = 0; cs.held = 0; cs.over = -1; cs.spare_jump = 0;
    release_all();
    cs.armed = 0;                                     /* the service puts pass 0 back in cur */
}
static void tick(void *self, int counter)
{
    (void)self; (void)counter;
    composer_ticks[0]++;
    if (MODE() || !cs.running || !cs.armed) return;
    const cm_event *e = cs.ev[cs.cur];
    for (int v = 0; v < VOICES; v++) if (cs.id[v] >= 0 && cs.off[v] <= cs.t) { op1_seq_note_off(cs.id[v]); cs.id[v] = -1; }
    while (cs.idx < cs.n[cs.cur] && e[cs.idx].tick <= cs.t) note_start(&e[cs.idx++]);
    if (++cs.t % BAR_TICKS) return;
    if (cs.t >= CM_SECTION_TICKS) {
        for (int v = 0; v < VOICES; v++) if (cs.id[v] >= 0) { op1_seq_note_off(cs.id[v]); cs.id[v] = -1; }
        cs.t = 0; cs.idx = 0;
        if (cs.spare_ready && !cs.busy) { cs.cur ^= 1; cs.playing_pass = cs.spare_pass; cs.spare_ready = 0; cs.spare_jump = 0; }
    } else if (cs.spare_ready && cs.spare_jump && !cs.busy) {   /* a jump: the new section from its start */
        for (int v = 0; v < VOICES; v++) if (cs.id[v] >= 0) { op1_seq_note_off(cs.id[v]); cs.id[v] = -1; }
        cs.cur ^= 1; cs.playing_pass = cs.spare_pass; cs.t = 0; cs.idx = 0; cs.spare_ready = 0; cs.spare_jump = 0;
    } else if (cs.spare_ready && cs.spare_bar && !cs.busy) {
        cs.cur ^= 1; cs.spare_ready = 0; cs.idx = 0;
        while (cs.idx < cs.n[cs.cur] && cs.ev[cs.cur][cs.idx].tick < cs.t) cs.idx++;
    }
}
static int down(void *self, int key)
{
    (void)self;
    if ((unsigned)key >= 24 || MODE()) return 0;
    if (!cs.running) { start(key, SHIFT()); return 1; }
    cs.held |= 1u << key;
    cs.over_key = (uint8_t)key;
    cs.over = (int8_t)(((key + 53 + 12 * OCTAVE() - song_key()) % 12 + 12) % 12);
    cs.edit = 1;
    return 1;
}
static int up(void *self, int key)
{
    (void)self;
    if ((unsigned)key >= 24 || !(cs.held & (1u << key))) return 1;
    cs.held &= ~(1u << key);
    if (key == cs.over_key && cs.over >= 0) { cs.over = -1; cs.edit = 1; }
    if (key == cs.start_key && !cs.latched) { if (SHIFT()) cs.latched = 1; else halt(); }
    return 1;
}
static int nop(void *self) { (void)self; return 0; }
/* R246's stop / reset (mode switch, SEQ off): a latched part only goes silent, a held one stops */
static void quiet(void) { if (cs.latched) release_all(); else halt(); }
static void p_stop(void *self) { (void)self; quiet(); }
static void p_reset(void *self) { (void)self; if (!MODE()) quiet(); }
/* uintptr_t: 32-bit words on the OP-1, host-sized in the harness */
static const uintptr_t vt[16] = {0, 0, 0, (uintptr_t)nop, 0, (uintptr_t)down, 0, (uintptr_t)up, 0, (uintptr_t)p_reset, 0,
                                 (uintptr_t)tick, 0, (uintptr_t)nop, 0, (uintptr_t)p_stop};
static struct { const uintptr_t *vt; uint32_t pad[7]; } player = {vt, {0}};

/* ---- drums: the song's DRUMS part, played by the drum page's own player ----
 * Its own transport (buffers, tick, section, lock / jump) beside the synth part's, the song (style, seeds, form,
 * swing, length, dynamics, song mode) shared from cs.cfg. Events hold voices (CD_KICK ..); a voice's pad is looked up
 * when it plays (the stock map or the PADS page's). A key starts the part (held, Shift on release latches); while it
 * runs, holding another key mutes that pad until released (the start key never mutes). On the PADS page with
 * composer's screen shown a key sets the selected voice's pad instead and sounds as usual. */
typedef struct {
    cd_config cfg, undo;
    uint8_t undo_valid, page, sel, kit, changed, on;  /* page 0 PLAY, 1 SONG, 2 PADS; kit 0 stock, 1 the own map */
    uint8_t pad[CD_VOICES];
    cm_event ev[2][CD_MAX_EVENTS];
    int16_t n[2];
    volatile uint8_t cur, spare_ready, spare_bar, busy, edit, armed, running, latched, lock, spare_jump;
    uint8_t next, jump, jump_sec, start_key;
    int8_t forced_sec, sec[2];
    uint8_t fill[2];                                  /* fill bars of each buffer (bit per bar) */
    uint16_t playing_pass, spare_pass, armed_pass, forced_pass, t, idx;
    uint32_t held;
    int16_t id[CD_VOICES];
    uint16_t off[CD_VOICES];
} drums;
static drums ds;
static int daccum[4];
static void initialize(void);

static int pad_of(int v) { return ds.kit ? ds.pad[v] : cd_pad_stock[v]; }
static void d_release(int v) { if (ds.id[v] >= 0) { op1_seq_note_off(ds.id[v]); ds.id[v] = -1; } }
static void d_release_all(void) { for (int v = 0; v < CD_VOICES; v++) d_release(v); }
static uint32_t d_muted(void) { return ds.running ? ds.held & ~(1u << ds.start_key) : 0; }
static void d_note_start(const cm_event *e)
{
    int v = e->note;
    if (v >= CD_VOICES) return;
    int pad = pad_of(v);
    if (d_muted() >> pad & 1) return;                 /* a held key mutes its pad */
    for (int w = 0; w < CD_VOICES; w++) if (ds.id[w] >= 0 && (w == v || pad_of(w) == pad)) d_release(w);
    ds.id[v] = (int16_t)op1_seq_note_on(1, pad + 0x35 + 12 * DRUM_OCT(), pad, e->vel);   /* as Grids' drum notes */
    ds.off[v] = (uint16_t)(ds.t + e->len);
}
static int d_section_of(int pass, int *occurrence)
{
    if (ds.forced_sec >= 0 && pass == ds.forced_pass) { *occurrence = 0; return ds.forced_sec; }
    return cm_song_at(&cs.cfg, cs.song, pass, occurrence);
}
static int d_jump_pass(int from, int sec)             /* as jump_pass, on the drum part's forced slot */
{
    int len = 0, occurrence;
    while (cm_styles[cs.cfg.style].song[len]) len++;
    ds.forced_sec = -1;
    if (cs.song == CM_SONG_FORM)
        for (int p = from; p < from + len; p++) if (cm_song_at(&cs.cfg, cs.song, p, &occurrence) == sec) return p;
    ds.forced_sec = (int8_t)sec; ds.forced_pass = (uint16_t)from;
    return from;
}
/* pass `pass` into buffer buf: its section, the sections around it (a fill before a change, a crash after one) */
static int d_compose(int buf, int pass)
{
    int occurrence, o2, sec = d_section_of(pass, &occurrence);
    int prev = ds.lock ? sec : pass ? d_section_of(pass - 1, &o2) : -1, next = ds.lock ? sec : d_section_of(pass + 1, &o2);
    ds.sec[buf] = (int8_t)sec;
    ds.fill[buf] = (uint8_t)cd_fill_bars(&cs.cfg, &ds.cfg, sec, occurrence, next);
    return ds.n[buf] = (int16_t)cd_compose(&cs.cfg, &ds.cfg, sec, occurrence, prev, next, ds.ev[buf], CD_MAX_EVENTS);
}
static void d_spare(int pass, int jump)
{
    d_compose(!ds.cur, pass);
    ds.spare_pass = (uint16_t)pass; ds.spare_bar = 0; ds.spare_jump = (uint8_t)jump; ds.spare_ready = 1;
}
static void dservice(void)                            /* as service(), for the drum part (once the drum page used it) */
{
    if (!ds.on) return;
    if (!ds.running || !ds.armed) {
        if (ds.edit || !ds.armed || ds.jump) {
            int pass = 0;
            if (ds.jump) { ds.jump = 0; pass = d_jump_pass(0, ds.jump_sec); ds.spare_jump = 1; }
            else if (ds.spare_jump) pass = ds.armed_pass;
            else ds.forced_sec = -1;
            ds.armed = 0; ds.edit = 0;
            d_compose(ds.cur, pass);
            ds.armed_pass = (uint16_t)pass;
            if (ds.running) ds.playing_pass = (uint16_t)pass, ds.spare_jump = 0;
            ds.spare_ready = 0; ds.armed = 1;
        }
        return;
    }
    ds.busy = 1;
    int next = ds.lock ? ds.playing_pass : ds.playing_pass + 1;
    if (ds.jump) { ds.jump = 0; ds.edit = 0; d_spare(d_jump_pass(ds.playing_pass + 1, ds.jump_sec), 1); }
    else if (ds.edit && ds.spare_ready && ds.spare_jump) { ds.edit = 0; d_spare(ds.spare_pass, 1); }
    else if (ds.edit) {
        ds.edit = 0;
        if ((ds.t / BAR_TICKS + 1) * 16 < CM_STEPS) {      /* the playing pass again, swapped in at the next bar */
            d_compose(!ds.cur, ds.playing_pass);
            ds.spare_pass = ds.playing_pass; ds.spare_bar = 1; ds.spare_jump = 0; ds.spare_ready = 1;
        } else d_spare(next, 0);
    } else if (!ds.spare_ready) d_spare(next, 0);
    ds.busy = 0;
}
static void d_start(int key, int latch)
{
    d_release_all();
    ds.start_key = (uint8_t)key; ds.held = 1u << key; ds.latched = (uint8_t)latch;
    ds.t = 0; ds.idx = 0; ds.playing_pass = ds.armed_pass; ds.spare_ready = 0; ds.spare_jump = 0;
    ds.running = 1;
}
static void d_halt(void)
{
    if (!ds.running) return;
    ds.running = 0; ds.latched = 0; ds.held = 0; ds.spare_jump = 0;
    d_release_all();
    ds.armed = 0;                                     /* the service puts pass 0 back in cur */
}
static void dtick(void *self, int counter)
{
    (void)self; (void)counter;
    composer_ticks[1]++;
    if (!ds.running || !ds.armed) return;
    const cm_event *e = ds.ev[ds.cur];
    for (int v = 0; v < CD_VOICES; v++) if (ds.id[v] >= 0 && ds.off[v] <= ds.t) d_release(v);
    while (ds.idx < ds.n[ds.cur] && e[ds.idx].tick <= ds.t) d_note_start(&e[ds.idx++]);
    if (++ds.t % BAR_TICKS) return;
    if (ds.t >= CM_SECTION_TICKS) {
        d_release_all();
        ds.t = 0; ds.idx = 0;
        if (ds.spare_ready && !ds.busy) { ds.cur ^= 1; ds.playing_pass = ds.spare_pass; ds.spare_ready = 0; ds.spare_jump = 0; }
    } else if (ds.spare_ready && ds.spare_jump && !ds.busy) {
        d_release_all();
        ds.cur ^= 1; ds.playing_pass = ds.spare_pass; ds.t = 0; ds.idx = 0; ds.spare_ready = 0; ds.spare_jump = 0;
    } else if (ds.spare_ready && ds.spare_bar && !ds.busy) {
        ds.cur ^= 1; ds.spare_ready = 0; ds.idx = 0;
        while (ds.idx < ds.n[ds.cur] && ds.ev[ds.cur][ds.idx].tick < ds.t) ds.idx++;
    }
}
static int ddown(void *self, int key)
{
    (void)self;
    if ((unsigned)key >= 24) return 0;
    initialize(); ds.on = 1;
    if (ds.page == 2 && SHOWN()) {                    /* PADS: the key is the selected voice's pad, and sounds */
        if (!ds.kit) for (int v = 0; v < CD_VOICES; v++) ds.pad[v] = cd_pad_stock[v];
        ds.pad[ds.sel] = (uint8_t)key; ds.kit = 1; ds.changed = 1;
        return 0;
    }
    if (!ds.running) { d_start(key, SHIFT()); return 1; }
    ds.held |= 1u << key;
    if (key != ds.start_key) for (int v = 0; v < CD_VOICES; v++) if (pad_of(v) == key) d_release(v);   /* mute now */
    return 1;
}
static int dup(void *self, int key)
{
    (void)self;
    if ((unsigned)key >= 24 || !(ds.held & (1u << key))) return 1;
    ds.held &= ~(1u << key);
    if (key == ds.start_key && !ds.latched) { if (SHIFT()) ds.latched = 1; else d_halt(); }
    return 1;
}
static void dquiet(void) { if (ds.latched) d_release_all(); else d_halt(); }
static void dp_stop(void *self) { (void)self; dquiet(); }
static void dp_reset(void *self) { (void)self; if (MODE()) dquiet(); }
static const uintptr_t dvt[16] = {0, 0, 0, (uintptr_t)nop, 0, (uintptr_t)ddown, 0, (uintptr_t)dup, 0, (uintptr_t)dp_reset, 0,
                                  (uintptr_t)dtick, 0, (uintptr_t)nop, 0, (uintptr_t)dp_stop};
static struct { const uintptr_t *vt; uint32_t pad[7]; } dplayer = {dvt, {0}};

/* ---- settings: the synth row (the song and the synth part) and the drum row (the drum part's own settings) ----
 * Drum row: 102, density, vary, ghosts, fills, kit, the eleven pads (CD_VOICES), the three drum seeds as 4 bytes each
 * (29 words). Version 101 (3.2) has nine pads (no tambourine or ride: those get the stock pads). Before 2026-11-05 the
 * drum row held a copy of the synth row (first word 2..4): it loads as the drum defaults. */
#define WORDS 25                                      /* version 4; versions 2 and 3 have 23 (no swing, length) */
#define DWORDS (6 + CD_VOICES + 12)
#define DROW 102
#define DROW_NINE 101                                 /* nine pads */
static int d_serialize(char *out, int n)
{
    int v[DWORDS], k = 0;
    const cd_config *d = &ds.cfg;
    v[k++] = DROW; v[k++] = d->density; v[k++] = d->vary; v[k++] = d->ghosts; v[k++] = d->fills; v[k++] = ds.kit;
    for (int i = 0; i < CD_VOICES; i++) v[k++] = ds.pad[i];
    uint32_t seeds[3] = {d->seed_groove, d->seed_hats, d->seed_fill};
    for (int i = 0; i < 3; i++) for (int b = 0; b < 4; b++) v[k++] = (int)(seeds[i] >> (8 * b) & 255);
    return sq_join(out, n, v, k);
}
static int d_parse(const char *text, int len)
{
    int v[DWORDS + 1], k = sq_split(text, len, v, DWORDS + 1);
    int pads = k == DWORDS && v[0] == DROW ? CD_VOICES : k == DWORDS - 2 && v[0] == DROW_NINE ? 9 : 0;
    if (!pads) return 0;
    for (int i = 1; i < k; i++) if (v[i] < 0 || v[i] > (i < 5 ? 100 : i == 5 ? 1 : i < 6 + pads ? 23 : 255)) return 0;
    cd_config *d = &ds.cfg;
    d->density = (uint8_t)v[1]; d->vary = (uint8_t)v[2]; d->ghosts = (uint8_t)v[3]; d->fills = (uint8_t)v[4]; ds.kit = (uint8_t)v[5];
    for (int i = 0; i < CD_VOICES; i++) ds.pad[i] = i < pads ? (uint8_t)v[6 + i] : cd_pad_stock[i];
    uint32_t seeds[3] = {0, 0, 0};
    for (int i = 0; i < 3; i++) for (int b = 0; b < 4; b++) seeds[i] |= (uint32_t)v[6 + pads + 4 * i + b] << (8 * b);
    d->seed_groove = seeds[0] ? seeds[0] : 1; d->seed_hats = seeds[1] ? seeds[1] : 1; d->seed_fill = seeds[2] ? seeds[2] : 1;
    ds.edit = 1;
    return 1;
}
static int serialize(int m, char *out, int n)
{
    if (m) return d_serialize(out, n);
    int v[WORDS], k = 0;
    const cm_config *c = &cs.cfg;
    v[k++] = 4; v[k++] = c->style; v[k++] = c->key; v[k++] = c->density; v[k++] = c->variation; v[k++] = c->tension;
    v[k++] = c->dyn; v[k++] = c->form; v[k++] = cs.role; v[k++] = cs.follow; v[k++] = cs.song;
    uint32_t seeds[3] = {c->seed_harm, c->seed_rhythm, c->seed_pitch};
    for (int i = 0; i < 3; i++) for (int b = 0; b < 4; b++) v[k++] = (int)(seeds[i] >> (8 * b) & 255);
    v[k++] = c->swing; v[k++] = c->length;
    return sq_join(out, n, v, k);
}
static int parse(int m, const char *text, int len)
{
    if (m) return d_parse(text, len);
    int v[WORDS], k = sq_split(text, len, v, WORDS);
    if (k < 1 || v[0] < 2 || v[0] > 4 || k != (v[0] == 4 ? 25 : 23)) return 0;
    if (v[0] < 4) v[23] = v[24] = 0;                  /* older rows: the style's swing and length */
    if ((v[23] && (v[23] < 50 || v[23] > 75)) || (v[24] && (v[24] < 25 || v[24] > 200 || v[24] % 5))) return 0;
    if (v[1] >= cm_nstyles || v[2] > 11 || v[3] > 100 || v[4] > 100 || v[5] > 100 || v[6] > (v[0] == 2 ? 4 : 100) || v[7] > F_COUNT || v[8] >= CM_ROLES || v[9] > 1 ||
        v[10] >= CM_SONG_COUNT) return 0;
    for (int i = 0; i < WORDS; i++) if (v[i] < 0 || (i >= 11 && v[i] > 255)) return 0;
    cm_config *c = &cs.cfg;
    c->style = (uint8_t)v[1]; c->key = (uint8_t)v[2]; c->density = (uint8_t)v[3]; c->variation = (uint8_t)v[4];
    c->tension = (uint8_t)v[5]; c->dyn = (uint8_t)(v[0] == 2 ? 50 : v[6]);   /* version 2 kept the octave there */ c->form = (uint8_t)v[7]; cs.role = (uint8_t)v[8]; cs.follow = (uint8_t)v[9];
    cs.song = (uint8_t)v[10];
    uint32_t seeds[3] = {0, 0, 0};
    for (int i = 0; i < 3; i++) for (int b = 0; b < 4; b++) seeds[i] |= (uint32_t)v[11 + 4 * i + b] << (8 * b);
    c->swing = (uint8_t)v[23]; c->length = (uint8_t)v[24];
    c->seed_harm = seeds[0] ? seeds[0] : 1; c->seed_rhythm = seeds[1] ? seeds[1] : 1; c->seed_pitch = seeds[2] ? seeds[2] : 1;
    cs.edit = 1; ds.edit = 1;
    return 1;
}
static char sql[400];
static sq_store_t store = {.name = "composerseq", .ser = serialize, .parse = parse, .sql = sql, .cap = sizeof sql, .maxlen = 200};
static void initialize(void)
{
    if (loaded) return;
    for (int v = 0; v < VOICES; v++) cs.id[v] = -1;
    cm_default(&cs.cfg, 0, 0x2026u);
    cs.song = CM_SONG_FORM; cs.over = -1; cs.forced_sec = -1; cs.nonce = 0x31u;
    cd_default(&ds.cfg, 0x2026u);
    for (int v = 0; v < CD_VOICES; v++) { ds.id[v] = -1; ds.pad[v] = cd_pad_stock[v]; }
    ds.forced_sec = -1;
    loaded = 1;
    sq_store_load(&store);
}

/* ---- controls ---- */
static void reseed(uint32_t *s) { cs.nonce = mix(cs.nonce + 0x9E3779B9u + cs.t); *s = mix(*s ^ cs.nonce); }
static void changed(const cm_config *before, uint8_t role_before, uint8_t song_before)
{
    if (same(before, &cs.cfg, sizeof *before) && role_before == cs.role && song_before == cs.song) return;
    copy(&cs.undo, before, sizeof *before); cs.undo_valid = 1; cs.changed = 1; cs.edit = 1; ds.edit = 1;
}
/* ---- drum page controls ----
 * PLAY: STYLE (shared), DENSITY, VARY, FILLS; SONG: KIT (STOCK / CUSTOM; push: PADS), GHOSTS, DYNAMICS (shared),
 * SONG (shared); PADS: VOICE, its PAD, KIT, push orange: the stock map. Pushes: blue the next page (PLAY, SONG, PADS),
 * green NEW (all drum seeds), white FILLS (new fills), orange UNDO (the drum settings). Shift: KEY FROM / LOCK,
 * SWING (shared) / RHYTHM (new kick and snare), LENGTH (shared) / GROOVE (new hats and ghosts), NEXT / JUMP. */
static void d_changed(const cd_config *before)
{
    if (same(before, &ds.cfg, sizeof *before)) return;
    copy(&ds.undo, before, sizeof *before); ds.undo_valid = 1; ds.changed = 1; ds.edit = 1;
}
static void d_kit(int d)
{
    int k = clamp(ds.kit + d, 0, 1);
    if (k == ds.kit) return;
    ds.kit = (uint8_t)k; ds.changed = 1;              /* the own map is kept while STOCK is picked */
}
static void dturn(int knob, int delta, int shift)
{
    initialize();
    int *a = &daccum[knob], d;
    *a += delta; d = *a / 1024; *a -= d * 1024;
    if (!d) return;
    cm_config before, *c = &cs.cfg;
    cd_config dbefore, *dc = &ds.cfg;
    uint8_t role = cs.role, song = cs.song;
    copy(&before, c, sizeof before); copy(&dbefore, dc, sizeof dbefore);
    if (shift) {                                      /* as the synth page's Shift page; NEXT is the drum part's */
        if (knob == 0) { cs.follow = d > 0; cs.changed = 1; cs.edit = 1; return; }
        if (knob == 1) { int i = clamp((c->swing ? c->swing - 49 : 0) + d, 0, 26); c->swing = (uint8_t)(i ? i + 49 : 0); }
        if (knob == 2) { int i = clamp((c->length ? (c->length - 25) / 5 + 1 : 0) + d, 0, 36); c->length = (uint8_t)(i ? 25 + 5 * (i - 1) : 0); }
        if (knob == 3) {
            uint8_t opt[4] = {0}; int n = 1, at = 0;
            for (int sct = 0; sct < 3; sct++) if (in_form(sct)) { if (ds.next == sct + 1) at = n; opt[n++] = (uint8_t)(sct + 1); }
            ds.next = opt[clamp(at + d, 0, n - 1)];
            return;
        }
        changed(&before, role, song);
        return;
    }
    if (ds.page == 0) {
        if (knob == 0) {
            int v = clamp(c->style + d, 0, cm_nstyles - 1);
            if (v != c->style) { c->style = (uint8_t)v; c->key = cm_styles[v].key; c->form = 0; }
        }
        if (knob == 1) dc->density = (uint8_t)clamp(dc->density + 5 * d, 0, 100);
        if (knob == 2) dc->vary = (uint8_t)clamp(dc->vary + 5 * d, 0, 100);
        if (knob == 3) dc->fills = (uint8_t)clamp(dc->fills + 5 * d, 0, 100);
    } else if (ds.page == 1) {
        if (knob == 0) d_kit(d);
        if (knob == 1) dc->ghosts = (uint8_t)clamp(dc->ghosts + 5 * d, 0, 100);
        if (knob == 2) c->dyn = (uint8_t)clamp(c->dyn + 5 * d, 0, 100);
        if (knob == 3) cs.song = (uint8_t)clamp(cs.song + d, 0, CM_SONG_COUNT - 1);
    } else {
        if (knob == 0) ds.sel = (uint8_t)clamp(ds.sel + d, 0, CD_VOICES - 1);
        if (knob == 1) {
            if (!ds.kit) for (int v = 0; v < CD_VOICES; v++) ds.pad[v] = cd_pad_stock[v];
            ds.pad[ds.sel] = (uint8_t)clamp(ds.pad[ds.sel] + d, 0, 23); ds.kit = 1; ds.changed = 1;
        }
        if (knob == 2) d_kit(d);
    }
    changed(&before, role, song);
    d_changed(&dbefore);
}
static void dpress(int knob, int shift)
{
    initialize();
    cd_config before;
    copy(&before, &ds.cfg, sizeof before);
    if (shift) {
        if (knob == 0) { ds.lock ^= 1; ds.edit = 1; return; }
        if (knob == 3) { if (ds.next && in_form(ds.next - 1)) { ds.jump_sec = (uint8_t)(ds.next - 1); ds.jump = 1; } return; }
        reseed(knob == 1 ? &ds.cfg.seed_groove : &ds.cfg.seed_hats);
        d_changed(&before);
        return;
    }
    if (knob == 0) { ds.page = (uint8_t)((ds.page + 1) % 3); return; }
    if (knob == 3 && ds.page == 2) {                  /* the stock map */
        for (int v = 0; v < CD_VOICES; v++) ds.pad[v] = cd_pad_stock[v];
        ds.kit = 0; ds.changed = 1;
        return;
    }
    if (knob == 3) {
        if (!ds.undo_valid) return;
        cd_config t;
        copy(&t, &ds.cfg, sizeof t); copy(&ds.cfg, &ds.undo, sizeof t); copy(&ds.undo, &t, sizeof t);
        ds.changed = 1; ds.edit = 1;
        return;
    }
    if (ds.page == 2) return;
    if (knob == 1) { reseed(&ds.cfg.seed_groove); reseed(&ds.cfg.seed_hats); reseed(&ds.cfg.seed_fill); }
    if (knob == 2) reseed(&ds.cfg.seed_fill);
    d_changed(&before);
}
static void turn(int m, int knob, int delta, int shift)
{
    if ((unsigned)knob > 3) return;
    if (m) { dturn(knob, delta, shift); return; }
    initialize();
    int *a = &accum[knob], d;
    *a += delta; d = *a / 1024; *a -= d * 1024;
    if (!d) return;
    cm_config before, *c = &cs.cfg;
    uint8_t role = cs.role, song = cs.song;
    copy(&before, c, sizeof before);
    if (shift) {                                      /* the Shift page */
        if (knob == 0) { cs.follow = d > 0; cs.changed = 1; cs.edit = 1; return; }
        if (knob == 1) {                              /* STYLE, then 50..75 % */
            int i = clamp((c->swing ? c->swing - 49 : 0) + d, 0, 26);
            c->swing = (uint8_t)(i ? i + 49 : 0);
        }
        if (knob == 2) {                              /* STYLE, then 25..200 % in 5s */
            int i = clamp((c->length ? (c->length - 25) / 5 + 1 : 0) + d, 0, 36);
            c->length = (uint8_t)(i ? 25 + 5 * (i - 1) : 0);
        }
        if (knob == 3) {                              /* -, then the form's sections in order */
            uint8_t opt[4] = {0}; int n = 1, at = 0;
            for (int sct = 0; sct < 3; sct++) if (in_form(sct)) { if (cs.next == sct + 1) at = n; opt[n++] = (uint8_t)(sct + 1); }
            cs.next = opt[clamp(at + d, 0, n - 1)];
            return;
        }
        changed(&before, role, song);
        return;
    }
    if (!cs.page) {
        if (knob == 0) {
            int v = clamp(c->style + d, 0, cm_nstyles - 1);
            if (v != c->style) { c->style = (uint8_t)v; c->key = cm_styles[v].key; c->form = 0; }
        }
        if (knob == 1) c->density = (uint8_t)clamp(c->density + 5 * d, 0, 100);
        if (knob == 2) c->variation = (uint8_t)clamp(c->variation + 5 * d, 0, 100);
        if (knob == 3) c->tension = (uint8_t)clamp(c->tension + 5 * d, 0, 100);
    } else {
        int32_t h[4];
        if (knob == 0) cs.role = (uint8_t)clamp(cs.role + d, 0, CM_ROLES - 1);
        if (knob == 1) { if (cs.follow && op1_harmony_context(h)) { op1_toast("key follows scale"); return; } c->key = (uint8_t)((c->key + d % 12 + 12) % 12); }
        if (knob == 2) c->dyn = (uint8_t)clamp(c->dyn + 5 * d, 0, 100);
        if (knob == 3) cs.song = (uint8_t)clamp(cs.song + d, 0, CM_SONG_COUNT - 1);
    }
    changed(&before, role, song);
}
static void press(int m, int knob, int shift)
{
    if ((unsigned)knob > 3) return;
    if (m) { dpress(knob, shift); return; }
    initialize();
    cm_config before;
    copy(&before, &cs.cfg, sizeof before);
    if (shift && knob == 0) { cs.lock ^= 1; cs.edit = 1; return; }
    if (shift && knob == 3) { if (cs.next && in_form(cs.next - 1)) { cs.jump_sec = (uint8_t)(cs.next - 1); cs.jump = 1; } return; }
    if (knob == 0) { cs.page ^= 1; return; }
    if (knob == 3) {
        if (!cs.undo_valid) return;
        cm_config t;
        copy(&t, &cs.cfg, sizeof t); copy(&cs.cfg, &cs.undo, sizeof t); copy(&cs.undo, &t, sizeof t);
        cs.changed = 1; cs.edit = 1;
        return;
    }
    if (knob == 1) { if (shift) reseed(&cs.cfg.seed_rhythm); else { reseed(&cs.cfg.seed_harm); reseed(&cs.cfg.seed_rhythm); reseed(&cs.cfg.seed_pitch); } }
    if (knob == 2) { if (shift) reseed(&cs.cfg.seed_harm); else reseed(&cs.cfg.seed_pitch); }
    changed(&before, cs.role, cs.song);
}
/* the drum page gets the drum part's player (create_player runs in the page's mode, as kn_seq.c picks the type) */
static void *get_player(void) { initialize(); if (MODE()) { ds.on = 1; return &dplayer; } return &player; }
static void midi_start(void)
{
    if (cs.running) { release_all(); cs.t = 0; cs.idx = 0; }
    if (ds.running) { d_release_all(); ds.t = 0; ds.idx = 0; }
}
static int input(const op1_input *in) { if (loaded && in->type == OP1_IN_KEY && in->pressed && in->code == 0x23) { halt(); d_halt(); } return 0; }
static void event(int id, int32_t arg)
{
    (void)arg;
    if (!loaded) return;
    if (id == OP1_EV_NOTES_RESET) { release_all(); d_release_all(); }
    if (id == OP1_EV_SLOT || id == OP1_EV_DISK) halt();
    if (id == OP1_EV_DISK) d_halt();                  /* (OP1_EV_SLOT is the synth slot; a kit change keeps the drums) */
    if (id == OP1_EV_SERVICE) {
        service();
        dservice();
        if (cs.changed || ds.changed) { cs.changed = 0; ds.changed = 0; sq_store_dirty(&store); }
    }
}

/* ---- screen: header, the playing section as a note roll with the playhead, four controls ---- */
static const uint8_t white[4] = {232, 232, 232, 255}, blue[4] = {105, 142, 255, 255}, green[4] = {0, 223, 160, 255},
                     orange[4] = {255, 91, 55, 255}, dim[4] = {88, 100, 94, 255};
#define T_TITLE 1536
#define T_HEAD 1126
#define T_LABEL 1331
#define T_VALUE 1434
#define T_PUSH 1024
static void text(void *r, int x, int y, int scale, const char *s, const uint8_t *c) { sq_text(r, OP1_Q10(x), OP1_Q10(y), scale, s, scale * 3 / 4, c); }
static int width(const char *s, int scale) { int u = 0; for (; *s; s++) u += *s == '1' || *s == '.' ? 4 : 6; return u ? (u - 2) * scale / 1024 : 0; }
static void upper(char *o, const char *s) { for (; *s; s++) *o++ = *s >= 'a' && *s <= 'z' ? (char)(*s - 32) : *s; *o = 0; }
static void screen_init(void *scr) { (void)scr; }
/* the header's section slot: the section and bar ("A 3"); a queued jump "NEXT B", a held chord "CHORD", locked
 * "A LOCK" ("LOCK" stopped). The section is the playing buffer's, not section_of(playing_pass): a second jump moves
 * the forced slot to the next pass while the service composes it, before spare_jump says NEXT */
static const char *header(char *sec)
{
    if (cs.jump || cs.spare_jump) { char *q = sq_cat(sec, "NEXT "); q[0] = (char)('A' + cs.jump_sec); q[1] = 0; return sec; }
    if (cs.over >= 0) return "CHORD";
    if (!cs.running) return cs.lock ? "LOCK" : "";
    sec[0] = (char)('A' + cs.sec[cs.cur]); sec[1] = ' ';
    if (cs.lock) sq_cat(sec + 2, "LOCK"); else sq_num(sec + 2, (uint32_t)(cs.t / BAR_TICKS + 1), 1);
    return sec;
}
/* ---- the drum page: header, the playing bar as a voice grid (PLAY, SONG) or the pad map (PADS), four controls ---- */
static const char *const dvoice[CD_VOICES] = {"KICK", "SNARE", "CLAP", "RIM", "CL HAT", "OP HAT", "LOW TOM", "HI TOM", "CRASH",
                                             "TAMB", "RIDE"};
static const char *const dshort[CD_VOICES] = {"K", "S", "CP", "R", "CH", "OH", "LT", "HT", "CR", "TB", "RD"};
static const char *const dshortname[9] = {"deep house", "techno", "trance", "synthwave", "pop", "lo-fi", "city pop", "ambient", "idm"};
/* the grid's rows: one per voice the style's groove row writes, in this order, plus a voice the playing section uses
 * outside its fill bars (B's open hat, a cross stick turned snare, ghost snares); at most D_ROWS (the least important
 * share their fallback's row, as do voices heard only in a fill and the crash) */
#define D_ROWS 7
static const uint8_t d_order[CD_VOICES] = {CD_KICK, CD_SNARE, CD_CLAP, CD_RIM, CD_CH, CD_OH, CD_RIDE, CD_TAMB, CD_LTOM, CD_HTOM, CD_CRASH};
/* a voice without a row draws on the first of these that has one (else the top row) */
static const uint8_t d_near[CD_VOICES][4] = {
    [CD_KICK] = {CD_KICK, CD_KICK, CD_KICK, CD_KICK}, [CD_SNARE] = {CD_CLAP, CD_RIM, CD_LTOM, CD_KICK},
    [CD_CLAP] = {CD_SNARE, CD_RIM, CD_TAMB, CD_KICK}, [CD_RIM] = {CD_SNARE, CD_CLAP, CD_TAMB, CD_KICK},
    [CD_CH] = {CD_TAMB, CD_RIDE, CD_OH, CD_KICK}, [CD_OH] = {CD_CH, CD_RIDE, CD_TAMB, CD_KICK},
    [CD_LTOM] = {CD_HTOM, CD_SNARE, CD_CLAP, CD_RIM}, [CD_HTOM] = {CD_LTOM, CD_SNARE, CD_CLAP, CD_RIM},
    [CD_CRASH] = {CD_OH, CD_RIDE, CD_CH, CD_TAMB}, [CD_TAMB] = {CD_CH, CD_RIDE, CD_OH, CD_KICK},
    [CD_RIDE] = {CD_OH, CD_CH, CD_TAMB, CD_KICK}};
static const uint8_t d_spare_first[9] = {CD_HTOM, CD_TAMB, CD_RIM, CD_OH, CD_RIDE, CD_CLAP, CD_LTOM, CD_CH, CD_SNARE};
/* rows: the row of each voice (row_of[v]) and each row's first voice; returns the row count */
static int d_rows(int8_t *row_of, uint8_t *row_voice)
{
    int has = cd_voices(cs.cfg.style), n = ds.armed ? ds.n[ds.cur] : 0;
    const cm_event *e = ds.ev[ds.cur];
    for (int i = 0; i < n; i++) if (e[i].note < CD_VOICES && !(ds.fill[ds.cur] >> (e[i].tick / BAR_TICKS) & 1)) has |= 1 << e[i].note;
    has &= ~(1 << CD_CRASH);
    has |= 1 << CD_KICK;
    for (int k = 0, rows = 99; rows > D_ROWS && k < 9; k++) {
        rows = 0;
        for (int v = 0; v < CD_VOICES; v++) rows += has >> v & 1;
        if (rows > D_ROWS) has &= ~(1 << d_spare_first[k]);
    }
    int rows = 0;
    for (int i = 0; i < CD_VOICES; i++) { int v = d_order[i]; row_of[v] = -1; if (has >> v & 1) { row_of[v] = (int8_t)rows; row_voice[rows++] = (uint8_t)v; } }
    for (int v = 0; v < CD_VOICES; v++)
        if (row_of[v] < 0) { row_of[v] = 0; for (int k = 3; k >= 0; k--) if (has >> d_near[v][k] & 1) row_of[v] = row_of[d_near[v][k]]; }
    return rows;
}
static const char *d_header(char *sec)
{
    if (ds.jump || ds.spare_jump) { char *q = sq_cat(sec, "NEXT "); q[0] = (char)('A' + ds.jump_sec); q[1] = 0; return sec; }
    if (!ds.running) return ds.lock ? "LOCK" : "";
    int bar = ds.t / BAR_TICKS;
    sec[0] = (char)('A' + ds.sec[ds.cur]); sec[1] = ' ';
    if (ds.lock) sq_cat(sec + 2, "LOCK");
    else { char *q = sq_num(sec + 2, (uint32_t)(bar + 1), 1); if (ds.fill[ds.cur] >> bar & 1) sq_cat(q, " FILL"); }
    return sec;
}
static void d_grid(void *r)
{
    int bar = ds.running ? ds.t / BAR_TICKS : 0, step = ds.running ? ds.t % BAR_TICKS / CM_TICKS : -1;
    int8_t row_of[CD_VOICES]; uint8_t row_voice[CD_VOICES];
    int rows = d_rows(row_of, row_voice);
    uint8_t mark[D_ROWS][16];                         /* 0 none, 1 ghost, 2 hit, 3 accent; muted pads: + 4 */
    for (int q = 0; q < D_ROWS; q++) for (int s = 0; s < 16; s++) mark[q][s] = 0;   /* (no memset in the firmware) */
    uint32_t muted = d_muted();
    const cm_event *e = ds.ev[ds.cur];
    int n = ds.armed ? ds.n[ds.cur] : 0;
    for (int i = 0; i < n; i++) {
        int b = e[i].tick / BAR_TICKS, v = e[i].note;
        if (b < bar) continue;
        if (b > bar) break;
        if (v >= CD_VOICES) continue;
        int s = e[i].tick % BAR_TICKS / CM_TICKS, row = row_of[v];
        int m = (v == CD_SNARE || v == CD_RIM || v == CD_KICK) && e[i].vel < CD_GHOST_VEL ? 1 : e[i].vel >= 100 ? 3 : 2;
        if (muted >> pad_of(v) & 1) m = 4 + m;
        if ((mark[row][s] & 3) < (m & 3) || (m & 4)) mark[row][s] = (uint8_t)m;
    }
    /* rows fill y 31..67: 9 px apart up to 5 rows, then 7 and 6 */
    int sp = rows <= 5 ? 9 : rows == 6 ? 7 : 6, scale = sp >= 9 ? 820 : sp == 7 ? 700 : 620;
    for (int q = 1; q < 4; q++) { int x = 48 + q * 64; sq_line(r, OP1_Q10(x), OP1_Q10(29), OP1_Q10(x), OP1_Q10(69), 650, dim); }
    for (int row = 0; row < rows; row++) {
        int y = 31 + sp * row, any_muted = 0;
        for (int v = 0; v < CD_VOICES; v++) any_muted |= row_of[v] == row && (muted >> pad_of(v) & 1);
        for (int s = 0; s < 16; s++) {
            int x = 50 + s * 16, m = mark[row][s];
            if (!m) { sq_line(r, OP1_Q10(x + 6), OP1_Q10(y), OP1_Q10(x + 8), OP1_Q10(y), 900, dim); continue; }
            const uint8_t *col = m >= 4 || (m & 3) == 1 ? dim : s == step ? orange : green;
            int w = ((m & 3) == 3 ? 5000 : (m & 3) == 2 ? 3300 : 2000) * sp / 9;
            sq_line(r, OP1_Q10(x + 2), OP1_Q10(y), OP1_Q10(x + 12), OP1_Q10(y), w, col);
        }
        text(r, 12, y - 3 * scale / 820, scale, dvoice[row_voice[row]], any_muted ? orange : white);
    }
    if (step >= 0) { int x = 50 + step * 16 + 7; sq_line(r, OP1_Q10(x), OP1_Q10(28), OP1_Q10(x), OP1_Q10(70), 650, white); }
}
static void d_pads(void *r)                           /* the 24 keys from the lowest F, each voice over its key */
{
    static const uint8_t black[12] = {0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0};
    static const uint8_t keycol[4] = {48, 56, 54, 255};
    for (int k = 0; k < 24; k++) {
        int x = 18 + k * 12, who = -1;
        for (int v = CD_VOICES - 1; v >= 0; v--) if (pad_of(v) == k) who = v;
        if (pad_of(ds.sel) == k) who = ds.sel;
        const uint8_t *c = who == ds.sel ? orange : who >= 0 ? green : black[k % 12] ? keycol : dim;
        sq_line(r, OP1_Q10(x), OP1_Q10(black[k % 12] ? 46 : 50), OP1_Q10(x), OP1_Q10(66), 8000, c);
        if (who >= 0) {
            const char *s = dshort[who];
            text(r, x + 1 - width(s, 700) / 2, black[k % 12] ? 31 : 38, 700, s, who == ds.sel ? orange : green);
        }
    }
}
static void d_screen(void *r, int sh)
{
    const cm_config *c = &cs.cfg;
    const cd_config *d = &ds.cfg;
    const uint8_t *colors[4] = {blue, green, white, orange};
    static const char *pagen[3] = {"PLAY", "SONG", "PADS"};
    static const char *songn[CM_SONG_COUNT] = {"LOOP", "SONG", "B ONLY", "C ONLY"};
    char val[24], sec[12];
    text(r, 12, 14, T_TITLE, "COMPOSER", white);
    text(r, 112, 16, T_HEAD, sh ? "SHIFT" : pagen[ds.page], green);
    text(r, 158, 16, T_HEAD, ds.latched ? "LATCH" : ds.running ? "HOLD" : "STOP", orange);
    text(r, 210, 16, T_HEAD, d_header(sec), white);
    text(r, 308 - width("DRUMS", T_HEAD), 16, T_HEAD, "DRUMS", dim);
    if (ds.page == 2 && !sh) d_pads(r); else d_grid(r);
    static const char *play[4] = {"STYLE", "DENSITY", "VARY", "FILLS"}, *song[4] = {"KIT", "GHOSTS", "DYNAMICS", "SONG"};
    static const char *pads[4] = {"VOICE", "PAD", "KIT", "MAP"};
    static const char *pp[4] = {"PUSH PAGE", "PUSH NEW", "PUSH FILLS", "PUSH UNDO"};
    static const char *shl[4] = {"KEY FROM", "SWING", "LENGTH", "NEXT"}, *shp[4] = {"PUSH LOCK", "PUSH RHYTHM", "PUSH GROOVE", "PUSH JUMP"};
    for (int i = 0; i < 4; i++) {
        int x = 12 + i * 79;
        const char *label = sh ? shl[i] : ds.page == 0 ? play[i] : ds.page == 1 ? song[i] : pads[i];
        const char *push = sh ? shp[i] : pp[i];
        if (!sh && ds.page == 1 && i == 0) push = "PUSH PADS";
        if (!sh && ds.page == 2) push = i == 0 ? "PUSH PAGE" : i == 3 ? "PUSH STOCK" : "";
        text(r, x, 76, T_LABEL, label, colors[i]);
        char *p = val;
        val[0] = 0;
        if (sh) {
            int pct = i == 1 ? c->swing : i == 2 ? c->length : 0;
            if (i == 0) sq_cat(val, cs.follow ? "FOLLOW" : "MANUAL");
            else if (i == 3) { val[0] = ds.next && in_form(ds.next - 1) ? (char)('A' + ds.next - 1) : '-'; val[1] = 0; }
            else if (!pct) sq_cat(val, "STYLE");
            else p = sq_num(val, (uint32_t)pct, 1), sq_cat(p, "%");
        } else if (ds.page == 0) {
            if (i == 0) upper(val, c->style < 9 ? dshortname[c->style] : cm_styles[c->style].name);
            else p = sq_num(val, (uint32_t)(i == 1 ? d->density : i == 2 ? d->vary : d->fills), 1), sq_cat(p, "%");
        } else if (ds.page == 1) {
            if (i == 0) sq_cat(val, ds.kit ? "CUSTOM" : "STOCK");
            else if (i == 1) p = sq_num(val, d->ghosts, 1), sq_cat(p, "%");
            else if (i == 2) p = sq_num(val, c->dyn, 1), sq_cat(p, "%");
            else sq_cat(val, songn[cs.song]);
        } else {
            if (i == 0) sq_cat(val, dvoice[ds.sel]);
            else if (i == 1) p = sq_cat(val, "KEY "), sq_num(p, (uint32_t)(pad_of(ds.sel) + 1), 1);
            else if (i == 2) sq_cat(val, ds.kit ? "CUSTOM" : "STOCK");
            else {
                int moved = 0;
                for (int v = 0; v < CD_VOICES; v++) moved += pad_of(v) != cd_pad_stock[v];
                if (moved) p = sq_num(val, (uint32_t)moved, 1), sq_cat(p, " MOVED"); else sq_cat(val, "AS STOCK");
            }
        }
        int vs = T_VALUE, w = width(val, vs);
        if (w > 66) vs = vs * 66 / w;
        text(r, x, 89, vs, val, white);
        text(r, x, 106, T_PUSH, push, colors[i]);
    }
}
static void screen_update(void *scr, int dt)
{
    op1_screen_draw_cached(scr, dt, 0);
    void *r = op1_raster();
    if (MODE()) { d_screen(r, SHIFT() != 0); return; }
    const cm_config *c = &cs.cfg;
    const uint8_t *colors[4] = {blue, green, white, orange};
    static const char *keys[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    static const char *roles[CM_ROLES] = {"LEAD", "BASS", "ARP", "CHORDS"};
    static const char *shortname[9] = {"deep house", "techno", "trance", "synthwave", "pop", "lo-fi", "city pop", "ambient", "idm"};
    static const char *songn[CM_SONG_COUNT] = {"LOOP", "SONG", "B ONLY", "C ONLY"};
    char val[24];
    int sh = SHIFT() != 0;                            /* Shift held: the Shift page */
    text(r, 12, 14, T_TITLE, "COMPOSER", white);
    text(r, 112, 16, T_HEAD, sh ? "SHIFT" : cs.page ? "SONG" : "PLAY", green);
    text(r, 158, 16, T_HEAD, cs.latched ? "LATCH" : cs.running ? "HOLD" : "STOP", orange);
    char sec[8];
    text(r, 210, 16, T_HEAD, header(sec), white);
    sq_cat(sq_cat(val, keys[song_key() % 12]), cs.follow ? " FOLLOW" : "");
    text(r, 308 - width(val, T_HEAD), 16, T_HEAD, val, dim);
    /* the section: 8 bars over x 14..306, notes over y 30..68 */
    const cm_event *e = cs.ev[cs.cur];
    int n = cs.armed ? cs.n[cs.cur] : 0, lo = 127, hi = 0;
    for (int i = 0; i < n; i++) { if (e[i].note < lo) lo = e[i].note; if (e[i].note > hi) hi = e[i].note; }
    if (hi - lo < 12) hi = lo + 12;
    for (int b = 1; b < CM_BARS; b++) { int x = 14 + b * 292 / CM_BARS; sq_line(r, OP1_Q10(x), OP1_Q10(66), OP1_Q10(x), OP1_Q10(68), 650, dim); }
    for (int i = 0; i < n && i < 192; i++) {
        int x0 = 14 + e[i].tick * 292 / CM_SECTION_TICKS, x1 = 14 + (e[i].tick + e[i].len) * 292 / CM_SECTION_TICKS;
        int y = 66 - (e[i].note - lo) * 34 / (hi - lo);
        int now = cs.running && e[i].tick <= cs.t && cs.t < e[i].tick + e[i].len;
        sq_line(r, OP1_Q10(x0), OP1_Q10(y), OP1_Q10(x1 > x0 + 1 ? x1 : x0 + 1), OP1_Q10(y), now ? 1500 : 900, now ? orange : green);
    }
    if (cs.running) { int x = 14 + cs.t * 292 / CM_SECTION_TICKS; sq_line(r, OP1_Q10(x), OP1_Q10(28), OP1_Q10(x), OP1_Q10(70), 650, white); }
    static const char *play[4] = {"STYLE", "DENSITY", "VARY", "TENSION"}, *song[4] = {"ROLE", "KEY", "DYNAMICS", "SONG"};
    static const char *pp[4] = {"PUSH PAGE", "PUSH NEW", "PUSH NOTES", "PUSH UNDO"};
    static const char *shl[4] = {"KEY FROM", "SWING", "LENGTH", "NEXT"}, *shp[4] = {"PUSH LOCK", "PUSH RHYTHM", "PUSH CHORDS", "PUSH JUMP"};
    for (int i = 0; i < 4; i++) {
        int x = 12 + i * 79;
        text(r, x, 76, T_LABEL, sh ? shl[i] : cs.page ? song[i] : play[i], colors[i]);
        char *p = val;
        if (sh) {
            int pct = i == 1 ? c->swing : i == 2 ? c->length : 0;
            if (i == 0) sq_cat(val, cs.follow ? "FOLLOW" : "MANUAL");
            else if (i == 3) { val[0] = cs.next && in_form(cs.next - 1) ? (char)('A' + cs.next - 1) : '-'; val[1] = 0; }
            else if (!pct) sq_cat(val, "STYLE");
            else p = sq_num(val, (uint32_t)pct, 1), sq_cat(p, "%");
        } else if (!cs.page) {
            if (i == 0) upper(val, c->style < 9 ? shortname[c->style] : cm_styles[c->style].name);
            else p = sq_num(val, (uint32_t)(i == 1 ? c->density : i == 2 ? c->variation : c->tension), 1), sq_cat(p, "%");
        } else {
            if (i == 0) sq_cat(val, roles[cs.role]);
            else if (i == 1) sq_cat(val, keys[song_key() % 12]);
            else if (i == 2) p = sq_num(val, c->dyn, 1), sq_cat(p, "%");
            else sq_cat(val, songn[cs.song]);
        }
        int vs = T_VALUE, w = width(val, vs);
        if (w > 66) vs = vs * 66 / w;
        text(r, x, 89, vs, val, white);
        text(r, x, 106, T_PUSH, sh ? shp[i] : pp[i], colors[i]);
    }
}
const op1_screen_t SCREEN_composer = {screen_init, screen_update};
static const op1_seq_type_t type = {.name = "composer", .player = get_player, .svg = "composer.svg", .screen = &SCREEN_composer,
                                    .press = press, .turn = turn, .midi_start = midi_start};
const op1_feature_t FEATURE_composer = {.api = OP1_FEATURE_API, .priority = 1000, .name = "composer", .seq = &type, .input = input, .event = event};
