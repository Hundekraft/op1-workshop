/* composer model checks; build: cc -std=c11 -Wall -Wextra -fsanitize=address,undefined composer_test.c composer_model.c composer_styles.c -o composer_test
 * Every style x 300 seeds x sections A, B, C x passes x 4 roles: events bounded, sorted, inside the section, valid notes, deterministic;
 * the lead puts most strong-beat notes on chord tones and the bass roots each chord it lands on.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "composer_model.h"

int main(void)
{
    static cm_event a[CM_MAX_EVENTS], b[CM_MAX_EVENTS];
    long events = 0;
    uint32_t fnv = 2166136261u;                         /* every event of every case: a change must be deliberate */
    for (int st = 0; st < cm_nstyles; st++) {               /* the PLAY page shows the name in one 79 px column (the first 9 have short names in composer.c) */
        const cm_style *s = &cm_styles[st];
        assert((st < 9 || strlen(s->name) <= 10) && s->nprog >= 2 && s->nlead >= 2 && s->nbass >= 1 && s->nchords >= 1 && strlen(s->arp) == 16);
        for (int i = 0; i < s->nlead; i++) assert(strlen(s->lead[i]) == 32);
        for (int i = 0; i < s->nbass; i++) assert(strlen(s->bass[i]) == 16);
        for (int i = 0; i < s->nchords; i++) assert(strlen(s->chords[i]) == 16);
        for (int i = 0; i < s->nprog; i++) {
            int beats = 0, n = 0;
            for (const cm_chord *c = s->prog[i]; c->beats; c++) { beats += c->beats; n++; assert(c->root < 12 && c->qual < Q_COUNT); }
            assert(n >= 1 && n <= 8 && (n * 32 + beats - 1) / beats <= CM_MAX_CHORDS - 2);   /* room for two held-key chords */
        }
        for (const char *f = s->song; *f; f++) assert(*f >= 'A' && *f <= 'C');
    }
    for (int st = 0; st < cm_nstyles; st++) {
        long strong = 0, strong_ct = 0, b_differs = 0, plans = 0;
        for (uint32_t seed = 1; seed <= 300; seed++) {
            cm_config c; cm_plan p, q;
            cm_default(&c, st, seed);
            c.density = (uint8_t)(seed * 37 % 101); c.variation = (uint8_t)(seed * 53 % 101); c.tension = (uint8_t)(seed * 71 % 101);
            for (int section = 0; section < 3; section++) {
            cm_plan_section(&p, &c, section); cm_plan_section(&q, &c, section);
            assert(!memcmp(&p, &q, sizeof p) && p.section == section);
            for (int s = 0; s < CM_STEPS; s++) assert(p.at[s] < p.nchord);
            if (section == 1 && cm_styles[st].nprog > 1) {
                cm_plan a; cm_plan_make(&a, &c);
                b_differs += memcmp(a.chord, p.chord, sizeof a.chord) != 0; plans++;
            }
            for (int pass = 0; pass < (section ? 4 : 8); pass++)
                for (int role = 0; role < CM_ROLES; role++) {
                    int n = cm_compose(&p, &c, role, pass, a, CM_MAX_EVENTS), m = cm_compose(&p, &c, role, pass, b, CM_MAX_EVENTS);
                    assert(n == m && !memcmp(a, b, sizeof a[0] * (size_t)n));
                    assert(n > 0 && n < CM_MAX_EVENTS);
                    for (int i = 0; i < n; i++) {
                        assert(a[i].note < 128 && a[i].vel > 0 && a[i].len > 0);
                        assert(a[i].tick + a[i].len <= CM_SECTION_TICKS);
                        assert(!i || a[i].tick >= a[i - 1].tick);
                        int step = a[i].tick / CM_TICKS, ci = p.at[step], pc = (a[i].note - c.key + 120) % 12;
                        if (role == CM_LEAD && !(step & 3)) { strong++; strong_ct += (cm_chord_tones(&p, ci) >> pc) & 1; }
                        if (role == CM_BASS && a[i].vel > 60 && (step == 0 || p.at[step] != p.at[step - 1]))
                            assert((a[i].note - c.key - p.chord[ci].root + 120) % 12 == 0);
                    }
                    events += n;
                    for (int i = 0; i < n; i++) {
                        const uint8_t *e = (const uint8_t *)&a[i];
                        for (unsigned k = 0; k < sizeof a[i]; k++) fnv = (fnv ^ e[k]) * 16777619u;
                    }
                }
            }
        }
        assert(b_differs * 10 >= plans * 9);           /* B has its own progression (A's and B's may share a chord list) */
        int share = (int)(100 * strong_ct / strong);
        printf("%-15s strong-beat lead chord tones %d%%\n", cm_styles[st].name, share);
        assert(share >= 60);
    }
    /* variety at the default settings: over 300 seeds, how many distinct progressions and rhythms each style gives
     * (host/variety.c prints the full table). Floors well under the 2026-11-03 numbers, so a regression shows. */
    for (int st = 0; st < cm_nstyles; st++) {
        static uint32_t h[5][300];
        static cm_event e[CM_MAX_EVENTS];
        int k[5] = {0};
        for (uint32_t seed = 1; seed <= 300; seed++) {
            cm_config c; cm_plan p;
            cm_default(&c, st, seed); cm_plan_section(&p, &c, 0);
            uint32_t v[5] = {2166136261u, 2166136261u, 2166136261u, 2166136261u, 2166136261u};
            for (int i = 0; i < p.nchord; i++) { v[0] = (v[0] ^ p.chord[i].root) * 16777619u; v[0] = (v[0] ^ p.chord[i].qual) * 16777619u; v[0] = (v[0] ^ p.start[i]) * 16777619u; }
            for (int role = 0; role < CM_ROLES; role++) {
                int n = cm_compose(&p, &c, role, 0, e, CM_MAX_EVENTS);
                for (int i = 0; i < n; i++) v[1 + role] = (v[1 + role] ^ e[i].tick ^ (role == CM_ARP ? (uint32_t)e[i].note << 16 : 0)) * 16777619u;
            }
            for (int d = 0; d < 5; d++) {
                int seen = 0;
                for (uint32_t j = 0; j + 1 < seed && !seen; j++) seen = h[d][j] == v[d];
                h[d][seed - 1] = v[d]; k[d] += !seen;
            }
        }
        /* chords, lead rhythm, bass rhythm, arp notes and rhythm, chord rhythm */
        static const int floor_[5] = {100, 100, 20, 100, 30};
        for (int d = 0; d < 5; d++) {
            if (k[d] < floor_[d]) printf("%s: variety %d is %d, floor %d\n", cm_styles[st].name, d, k[d], floor_[d]);
            assert(k[d] >= floor_[d]);
        }
    }
    /* the song form: sections in order, occurrences counted per section */
    cm_config c; cm_default(&c, 0, 1);
    const char *f = cm_styles[0].song; int len = (int)strlen(f), seen[3] = {0, 0, 0};
    for (int pass = 0; pass < 3 * len; pass++) {
        int occ, s = cm_song_at(&c, CM_SONG_FORM, pass, &occ);
        assert(s == f[pass % len] - 'A' && occ == seen[s]++);
    }
    for (int pass = 0; pass < 9; pass++) {
        int occ;
        assert(cm_song_at(&c, CM_SONG_LOOP, pass, &occ) == 0 && occ == pass);
        assert(cm_song_at(&c, CM_SONG_B, pass, &occ) == 1 && cm_song_at(&c, CM_SONG_C, pass, &occ) == 2);
    }
    /* SONG page Dynamics: 50 leaves every velocity as written, 0 flattens them to CM_DYN_MID, 100 doubles the spread */
    {
        cm_config d; cm_plan p; cm_default(&d, 0, 7); cm_plan_section(&p, &d, 0);
        static cm_event e50[CM_MAX_EVENTS], e0[CM_MAX_EVENTS], e100[CM_MAX_EVENTS];
        for (int role = 0; role < CM_ROLES; role++) {
            d.dyn = 50; int n = cm_compose(&p, &d, role, 0, e50, CM_MAX_EVENTS);
            d.dyn = 0; assert(cm_compose(&p, &d, role, 0, e0, CM_MAX_EVENTS) == n);
            d.dyn = 100; assert(cm_compose(&p, &d, role, 0, e100, CM_MAX_EVENTS) == n);
            for (int i = 0; i < n; i++) {
                assert(e0[i].tick == e50[i].tick && e0[i].note == e50[i].note && e0[i].vel == CM_DYN_MID);
                int far = CM_DYN_MID + 2 * (e50[i].vel - CM_DYN_MID);
                assert(e100[i].vel == (far < 1 ? 1 : far > 127 ? 127 : far));
            }
        }
        assert(cm_dynamics(127, 100) == 127 && cm_dynamics(1, 100) == 1 && cm_dynamics(60, 50) == 60);
    }
    /* Shift page SWING and LENGTH: 0 is the style's (the event hash above runs there); the style's own value given as an
     * override is the same events; swing moves only the odd 16ths, by (swing - 50) * 48 / 100 ticks; length scales each
     * role's gate (the written length in ticks times gate * length / 100, at least 6, cut at the section end) */
    {
        static cm_event e0[CM_MAX_EVENTS], e1[CM_MAX_EVENTS], e2[CM_MAX_EVENTS];
        long checked = 0;
        for (int st = 0; st < cm_nstyles; st++)
            for (uint32_t seed = 1; seed <= 6; seed++) {
                cm_config d; cm_plan p; cm_default(&d, st, seed);
                d.density = (uint8_t)(seed * 37 % 101);
                for (int section = 0; section < 3; section++) {
                    cm_plan_section(&p, &d, section);
                    for (int role = 0; role < CM_ROLES; role++) {
                        d.swing = 0; d.length = 0;
                        int n = cm_compose(&p, &d, role, 1, e0, CM_MAX_EVENTS);
                        d.swing = cm_styles[st].swing; d.length = 100;
                        assert(cm_compose(&p, &d, role, 1, e1, CM_MAX_EVENTS) == n && !memcmp(e0, e1, sizeof e0[0] * (size_t)n));
                        d.swing = 50; d.length = 0;
                        assert(cm_compose(&p, &d, role, 1, e1, CM_MAX_EVENTS) == n);
                        d.swing = 66;
                        assert(cm_compose(&p, &d, role, 1, e2, CM_MAX_EVENTS) == n);
                        for (int i = 0; i < n; i++) {
                            int step = e1[i].tick / CM_TICKS;
                            assert(e1[i].tick % CM_TICKS == 0 && e1[i].note == e2[i].note && e1[i].vel == e2[i].vel);
                            assert(e2[i].tick == e1[i].tick + (step & 1 ? 16 * 48 / 100 : 0));
                            assert(e2[i].len == e1[i].len || e2[i].tick + e2[i].len == CM_SECTION_TICKS);
                            assert(!i || e2[i].tick >= e2[i - 1].tick);
                        }
                        d.swing = 75; d.length = 200;             /* the extremes stay inside the section, sorted */
                        int m = cm_compose(&p, &d, role, 1, e2, CM_MAX_EVENTS);
                        assert(m == n);
                        for (int i = 0; i < m; i++) {
                            assert(e2[i].len > 0 && e2[i].tick + e2[i].len <= CM_SECTION_TICKS && (!i || e2[i].tick >= e2[i - 1].tick));
                            assert(e2[i].tick == e1[i].tick + (e1[i].tick / CM_TICKS & 1 ? 12 : 0));
                        }
                        for (int len = 25; len <= 200; len += 175) {
                            d.swing = 50; d.length = (uint8_t)len;
                            assert(cm_compose(&p, &d, role, 1, e2, CM_MAX_EVENTS) == n);
                            int g = cm_styles[st].gate[role], g2 = g * len / 100;
                            for (int i = 0; i < n; i++) {
                                assert(e2[i].tick == e1[i].tick && e2[i].note == e1[i].note);
                                if (e1[i].tick + e1[i].len == CM_SECTION_TICKS || e2[i].tick + e2[i].len == CM_SECTION_TICKS || e1[i].len == 6) continue;
                                /* the written length in 16ths w gives e1 = w * 24 * g / 100: find w, then expect e2 */
                                int w = 1;
                                while (w < CM_STEPS && w * CM_TICKS * g / 100 != e1[i].len) w++;
                                assert(w < CM_STEPS);
                                int want = w * CM_TICKS * g2 / 100;
                                assert(e2[i].len == (want < 6 ? 6 : want));
                                checked++;
                            }
                        }
                    }
                }
            }
        printf("swing / length overrides: %ld event lengths checked\n", checked);
    }
    printf("composer model passed: %ld events (hash %08x), %d styles x 300 seeds x (A 8, B 4, C 4 passes) x %d roles; song forms\n", events, fnv, cm_nstyles, CM_ROLES);
    return 0;
}
