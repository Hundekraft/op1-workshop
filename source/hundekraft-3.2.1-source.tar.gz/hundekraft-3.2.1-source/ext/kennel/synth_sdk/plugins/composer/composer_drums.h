/* composer drums: the DRUMS part of a composer song (OP1-Emulator docs/composer-drums-design-2026-11-05.md).
 * One 8-bar section of the style's own groove (a row per style: kick, snare, clap, rim, hats, ride, tambourine and
 * toms as 16-step masks, plus feel flags), the section (A as written, B fuller, C sparse or half time by the style's
 * family), fills before a section change, and the drum page's own Density, Vary, Ghosts and Fills. Events are cm_events whose note is a voice (CD_KICK ..); the player
 * maps a voice to its pad when it plays it, so a pad map change needs no recompose. Integers only, no libc.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef COMPOSER_DRUMS_H
#define COMPOSER_DRUMS_H
#include "composer_model.h"

/* voices; append only (the drum row saves a pad per voice in this order) */
enum { CD_KICK, CD_SNARE, CD_CLAP, CD_RIM, CD_CH, CD_OH, CD_LTOM, CD_HTOM, CD_CRASH, CD_TAMB, CD_RIDE, CD_VOICES };
enum { CD_FOUR, CD_BACKBEAT, CD_HALF, CD_BROKEN, CD_LATIN, CD_SPARSE, CD_FAMILIES };
#define CD_MAX_EVENTS 448                     /* per section; composer_drums_test checks the densest settings fit */
#define CD_GHOST_VEL 64                       /* below this a snare / rim / kick hit is a ghost note */

typedef struct {
    uint8_t density, vary, ghosts, fills;      /* 0..100 */
    uint32_t seed_groove, seed_hats, seed_fill; /* kick / snare placement, hats and ghosts, fills */
} cd_config;

/* stock kits' pads (0-based keys from the lowest F), TE's standard layout checked against the 14 factory kits */
extern const uint8_t cd_pad_stock[CD_VOICES];
void cd_default(cd_config *d, uint32_t seed);
int cd_family(int style);                     /* CD_* family of a cm_styles index (-1: none) */
int cd_voices(int style);                     /* the voices the style's groove row writes (bit v = voice v) */
/* bars of a section that end in a fill (bit b = bar b), from the section and the next pass's section (-1: unknown) */
int cd_fill_bars(const cm_config *c, const cd_config *d, int section, int occurrence, int next_section);
/* one section: section 0 A, 1 B, 2 C; occurrence as cm_compose; prev / next section: the passes around it (-1 none).
 * Sorted by tick, at most cap events. */
int cd_compose(const cm_config *c, const cd_config *d, int section, int occurrence, int prev_section, int next_section,
               cm_event *ev, int cap);
#endif
