/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "arp.h"
static const int8_t presets[ARP_PRESETS][8]={
 {0,4,7},{0,3,7},{0,4,7,11},{0,3,7,10},{0,7,12},{0,5,7},{0,4,7,12,7,4},{0,3,7,12,7,3},
 {0},                                                     /* ARP_CUSTOM: no preset of its own */
 {0,12},{0,2,7},{0,4,7,10},{0,3,6,9},{0,4,8},{0,4,7,14},{0,3,7,10,14},{0,7,4,7}};   /* OCTAVE SUS2 DOM7 DIM7 AUG ADD9 MIN9 ALBERTI */
static const uint8_t lengths[ARP_PRESETS]={3,3,4,4,3,3,6,6,1,2,3,4,4,3,4,5,4};
static const uint8_t ticks[8]={96,48,32,24,16,12,8,6};
static void silence(arp_state *s){if(s->sounding>=0){arp_output_off(s->sounding);s->sounding=-1;}}
static void restart(arp_state *s){silence(s);s->started=0;s->step=s->octave=0;s->elapsed=0;s->lastkey=-1;}
static void pick_root(arp_state *s){
 s->root=-1;for(unsigned i=0;i<24;i++)if(s->keys[i]>=0){s->root=s->keys[i];s->rootkey=(int16_t)i;}
 if(s->root<0)restart(s);
}
void arp_stop(arp_state *s){silence(s);s->run=s->started=0;s->step=s->octave=0;s->elapsed=0;s->lastkey=-1;s->root=-1;s->rootkey=0;s->down=0;for(unsigned i=0;i<24;i++)s->keys[i]=-1;}
unsigned arp_note_count(const arp_state *s){unsigned n=0;for(unsigned i=0;i<24;i++)n+=s->keys[i]>=0;return n;}
static unsigned length(const arp_state *s){return s->cfg.table==1?s->cfg.length:arp_note_count(s);}
void arp_bounds_changed(arp_state *s){
 if((s->cfg.table==1&&s->step>=s->cfg.length)||s->octave>=s->cfg.octaves)restart(s);
}
void arp_preset(arp_state *s,unsigned n){
 if(n>=ARP_PRESETS||n==ARP_CUSTOM)n=0;s->cfg.preset=(uint8_t)n;s->cfg.length=lengths[n];s->cfg.select=0;s->cfg.table=1;
 for(unsigned i=0;i<ARP_STEPS;i++){s->cfg.offset[i]=i<lengths[n]?presets[n][i]:0;s->cfg.dwell[i]=1;}
 restart(s);
}
void arp_set_table(arp_state *s,int mode){mode=mode<0?0:mode>2?2:mode;if(s->cfg.table!=mode){s->cfg.table=(uint8_t)mode;restart(s);}}
/* Blue knob: OFF < MAJOR .. MINDOWN < OCTAVE .. ALBERTI < RANDOM; leaving OFF or RANDOM restores the previous table. */
void arp_table_turn(arp_state *s,int d){
 arp_config *c=&s->cfg;
 /* Blue, left to right: OFF < MAJOR .. MINDOWN < RANDOM; CUSTOM (an edited table) sits between OFF and RANDOM. */
 if(c->table==2){if(d<0)arp_set_table(s,1);}                 /* back to the table it had */
 else if(!c->table){if(d>0)arp_set_table(s,1);}
 else if(c->preset==ARP_CUSTOM)arp_set_table(s,d<0?0:2);
 else{
  int pos=(c->preset<ARP_CUSTOM?c->preset:c->preset-1)+d;     /* knob position 0..15 (CUSTOM is not on the knob) */
  if(pos<0)arp_set_table(s,0);else if(pos>ARP_PRESETS-2)arp_set_table(s,2);
  else arp_preset(s,(unsigned)(pos<ARP_CUSTOM?pos:pos+1));
 }
}
/* Hold off forgets the released notes; physically held keys keep playing. */
void arp_set_latch(arp_state *s,int on){
 s->cfg.latch=!!on;if(on)return;
 for(unsigned i=0;i<24;i++)if(!(s->down>>i&1))s->keys[i]=-1;
 pick_root(s);
}
void arp_init(arp_state *s){
 s->sounding=-1;s->root=-1;s->rootkey=0;s->lastkey=-1;s->rng=2463534242u;s->run=s->started=s->step=s->octave=0;s->elapsed=0;s->down=0;
 for(unsigned i=0;i<24;i++)s->keys[i]=-1;
 s->cfg.rate=3;s->cfg.octaves=1;s->cfg.gate=75;s->cfg.latch=0;arp_preset(s,0);
}
void arp_key(arp_state *s,unsigned key,int note,int pressed){
 if(key>=24)return;
 if(pressed){
  /* Like the stock arpeggio hold: the first key after a full release starts a new set. */
  if(s->cfg.latch&&!s->down)for(unsigned i=0;i<24;i++)s->keys[i]=-1;
  s->down|=1u<<key;s->keys[key]=(int16_t)note;s->root=(int16_t)note;s->rootkey=(int16_t)key;
 }else{
  s->down&=~(1u<<key);
  if(s->cfg.latch)return;
  s->keys[key]=-1;pick_root(s);
 }
}
/* TABLE OFF: the n-th held note in pitch order (ties by key). */
static int held(const arp_state *s,unsigned n,int *key){
 int last=-1,lastkey=-1;
 for(unsigned k=0;k<=n;k++){
  int best=-1,bestkey=-1;
  for(int i=0;i<24;i++){int v=s->keys[i];
   if(v<0||v<last||(v==last&&i<=lastkey))continue;
   if(best<0||v<best){best=v;bestkey=i;}}
  if(best<0)return -1;last=best;lastkey=bestkey;
 }
 *key=lastkey;return last;
}
/* RANDOM: any held note but the previous one (when two or more are held). Multiply-shift, no division. */
static int pick_random(arp_state *s,int *key){
 int ks[24],n=0,p=-1;
 for(int i=0;i<24;i++)if(s->keys[i]>=0){if(i==s->lastkey)p=n;ks[n++]=i;}
 if(!n)return -1;
 uint32_t x=s->rng;x^=x<<13;x^=x>>17;x^=x<<5;s->rng=x;
 unsigned r=x>>16;int j;
 if(n>=2&&p>=0){j=(int)((r*(unsigned)(n-1))>>16);if(j>=p)j++;}
 else j=(int)((r*(unsigned)n)>>16);
 *key=ks[j];s->lastkey=(int8_t)ks[j];return s->keys[ks[j]];
}
void arp_tick(arp_state *s,int mode){
 if(!s->run||s->root<0)return;
 unsigned duration=ticks[s->cfg.rate]*(s->cfg.table==1?s->cfg.dwell[s->step]:1);
 if(s->started){
  s->elapsed++;
  if(s->elapsed>=duration){s->elapsed=0;s->step++;
   if(s->step>=length(s)){s->step=0;if(++s->octave>=s->cfg.octaves)s->octave=0;}
   s->started=0;
  }else if(s->elapsed*100+99>=duration*s->cfg.gate)silence(s);
  /* Preserve the floor gate threshold without a software divide on every tick. */
 }
 if(!s->started){
  silence(s);int note,key=s->rootkey;
  if(s->cfg.table==1)note=s->root+s->cfg.offset[s->step];
  else if(s->cfg.table==2){if(s->step>=arp_note_count(s))s->step=0;note=pick_random(s,&key);if(note<0)note=-1000;}
  else{if(s->step>=arp_note_count(s))s->step=0;note=held(s,s->step,&key);}
  note+=s->octave*12;
  if(note>=0&&note<=127)s->sounding=(int16_t)arp_output_on(mode,note,key,100);
  s->started=1;
 }
}
