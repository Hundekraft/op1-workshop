/* Selected-input producer at R246's post-decimator high-pass entry. No encrypted patch.
 * The assembly entry passes the caller's local has-input flag; only the verified
 * PmSynth call site runs input engines; the input observer (line clock) may clear the flag at all three verified
 * core_block_process call sites. Input source/mode and sampler taps stay intact.
 * GPL-3.0-or-later with OP-1 firmware permission. */
#include "kn_input.h"
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "../op1_feature_sound.h"
#include "kn_input_gain.h"
const op1_input_engine_t *op1_input_engines[OP1_SLOTS];
static const op1_input_engine_t *active;
static int active_slot=-1;
static uint32_t active_rate,active_source,active_mode;
static uint32_t rate=22050, previous_clock, clock_sum, clock_count;
static int block_touched;
/* INPUT GAIN per source (0 mic .. 3 USB), dB; see kn_input_service */
static volatile int8_t gain_db[4];
static volatile uint8_t gain_dirty;
static uint8_t gain_loaded;
static int gain_acc;
#define PLAY_MODE (*(volatile uint32_t *)0xFF801038)
#define SLOT (*(volatile uint32_t *)0xFF8016D4&7)
#define TYPE (*(volatile uint32_t *)(0xFF8016E4+4*SLOT))
#define INPUT_MODE (*(volatile uint32_t *)0xFF8010B0)
#define INPUT_SOURCE (*(volatile uint32_t *)0xFF8010B4)
#define SCREEN (*(volatile int *)0x018B65C8)
#define TABLE ((void **)0x01DF4E54)
static int current(void){
 if(PLAY_MODE!=0||TYPE!=14)return 0;
 int n=op1_synth_knobs(SLOT)[4]-OP1_ENGINE_MAGIC;
 return n>0&&n<OP1_SLOTS&&op1_input_engines[n]&&op1_sound_engine(n)?n:0;
}
void kn_input_clock(uint32_t now){
 uint32_t d=now-previous_clock;previous_clock=now;block_touched=0;
 /* Derive the two supported rates from the actual 400MHz callback cadence,
  * ignoring startup pauses. Change only after 16 consistent valid periods. */
 if(d<400000u||d>1600000u){clock_sum=clock_count=0;return;}
 clock_sum+=d;
 if(++clock_count==16){rate=clock_sum>13931968u?22050:44100;clock_sum=clock_count=0;}
}
/* CPU cycles in one audio block at the measured cadence: 64 frames at 44.1 kHz on the unit (1.451 ms), twice that
 * at the emulator's old 22.05 kHz link (OP1EMU_SPORT_HZ=22050) (docs: OP1-Emulator docs/emu-audio-clock-2026-10-21.md). kennel/kn_shed.c */
uint32_t kn_audio_block_cycles(void){return rate==44100?580499u:1160997u;}
extern void kn_input_highpass_stock(void);
/* Input observer (op1_input.h op1_input_observe, line clock). core_bus_highpass has three callers, all inside
 * core_block_process (0xFFA017EC), which moves SP only in its prologue and epilogue: synth (return 0xFFA02896), drum
 * (0xFFA02464) and game (0xFFA01EC2) pass the same has-input local at SP+0x34 (read at 0xFFA020C2 and 0xFFA0211A
 * for the dry monitor and the input added after the output stage). Any other caller is not observed. */
static volatile op1_input_observer_fn observer;
int op1_input_observe(op1_input_observer_fn fn){
 if(fn&&observer&&observer!=fn)return -1;
 observer=fn;return 0;
}
#define LINE_JACK (*(volatile uint8_t *)0x018B621C)
static int observe(uint32_t *monitor,uint32_t caller){
 op1_input_observer_fn fn=observer;
 if(!fn||(caller!=0xFFA02896u&&caller!=0xFFA02464u&&caller!=0xFFA01EC2u))return 0;
 const int16_t *in=*monitor?(const int16_t *)0xFF800CB4:0;
 return fn(in,(int)INPUT_SOURCE,LINE_JACK!=0,rate);
}
void kn_input_bus(uint32_t *monitor,uint32_t caller){
 int mute=observe(monitor,caller);
 if(caller!=0xFFA02896u){kn_input_highpass_stock();if(mute)*monitor=0;return;}
 int n=current();
 if(!n){kn_input_highpass_stock();if(mute)*monitor=0;return;}
 const op1_input_engine_t *d=op1_input_engines[n];int slot=(int)SLOT;
 if(d!=active||slot!=active_slot||active_rate!=rate||active_source!=INPUT_SOURCE||active_mode!=INPUT_MODE){if(active)active->reset(-1,rate);active=d;active_slot=slot;active_rate=rate;active_source=INPUT_SOURCE;active_mode=INPUT_MODE;d->reset(slot,rate);}
 block_touched=1;
 int16_t words[8];for(int k=0;k<8;k++)words[k]=op1_synth_knobs(slot)[k];
 /* Resampling the master would feed this producer back into itself. Silence
  * explicitly while that source is selected; do not rewrite stock source flags. */
 static const int16_t silence[64];
 const int16_t *input=(*monitor&&INPUT_MODE==0&&!mute)?(const int16_t *)0xFF800CB4:silence;
 /* INPUT GAIN (T2, per source): 0 dB passes the input buffer itself, so the engine sees the same bytes */
 static int16_t gained[64];
 const int db=gain_db[INPUT_SOURCE&3];
 if(db&&input!=silence){kn_gain_apply(input,gained,64,db);input=gained;}
 uint32_t t=op1_cycles();
 d->process(input,(int16_t *)0xFF800BB4,words,rate);
 uint32_t elapsed=op1_cycles()-t;sm_cy[SMC_SYNTH]+=elapsed;kn_input_budget(n,elapsed);
 *monitor=0; /* only the caller's two dry-monitor additions; input buffer unchanged */
}
void kn_input_end(void){if(!block_touched&&active){active->reset(-1,rate);active=0;active_slot=-1;active_rate=0;}}
/* INPUT GAIN: one trim per input source (mic, line, radio, USB), -12..+24 dB, settings "input.gain.mic" etc. (kennel
 * settings, not the sound: the gain matches the source). Read on the first main-loop pass, written there after a turn
 * (the KeyHandler thread only changes gain_db and marks it). The audio thread reads gain_db once a block. */
static const char *const gain_key[4]={"gain.mic","gain.line","gain.radio","gain.usb"};
int op1_input_gain_db(void){return gain_db[INPUT_SOURCE&3];}
void kn_input_service(void){
 if(!gain_loaded){gain_loaded=1;for(int i=0;i<4;i++)gain_db[i]=(int8_t)kn_gain_clamp((int)op1_setting_get("input",gain_key[i],0));}
 if(gain_dirty){uint8_t d=gain_dirty;gain_dirty&=(uint8_t)~d;for(int i=0;i<4;i++)if(d>>i&1)op1_setting_set("input",gain_key[i],gain_db[i]);}
 int n=current();if(n&&op1_input_engines[n]->service)op1_input_engines[n]->service();
}
/* T2 objects are ordinary table entries, so the shared-screen lifetime fix covers
 * their drawing caches. Allocate only for installed providers, once at boot. */
static uint32_t *objects[OP1_SLOTS];
static void *prior,*shown;
void *kn_alloc(uint32_t);
void kn_input_ctor(void){
 for(int n=1;n<OP1_SLOTS;n++)if(op1_input_engines[n]&&op1_input_engines[n]->tuner){
  uint32_t *s=kn_alloc(128),*v=kn_alloc(40);if(!s||!v)continue;
  void *save=TABLE[22];((void *(*)(void *,int,const char *))0x01A3BAB0)(s,22,"usbout.svg");TABLE[22]=save;
  for(int i=0;i<10;i++)v[i]=((const uint32_t *)0x019103FC)[i];
  v[7]=(uint32_t)op1_input_engines[n]->tuner->update;v[9]=(uint32_t)op1_input_engines[n]->tuner->init;s[3]=(uint32_t)v;
  objects[n]=s;
 }
}
void kn_input_load(void){for(int n=1;n<OP1_SLOTS;n++)if(objects[n]){
 uint32_t *s=objects[n];s[0]=(uint32_t)((void *(*)(void *))0x01A503D8)((void *)s[2]);
 if(s[0])op1_input_engines[n]->tuner->init(s);else objects[n]=0;
}}
void kn_input_screen_sync(void){
 int n=current();void *target=n?objects[n]:0;
 if(shown&&TABLE[22]!=shown){shown=0;prior=0;} /* another scoped host restored stock */
 if(!target){if(shown&&TABLE[22]==shown)TABLE[22]=prior;shown=prior=0;return;}
 if(TABLE[22]!=target){if(!shown)prior=TABLE[22];TABLE[22]=target;shown=target;}
}
int kn_input_tuner_visible(void){int n=current();return SCREEN==22&&n&&objects[n]&&TABLE[22]==objects[n];}
int kn_input_control(int type,int code,int down,int delta){
 (void)down;
 if(!kn_input_tuner_visible())return 0;
 if(type==OP1_IN_KNOB&&code==KN_GAIN_KNOB&&gain_loaded){       /* blue turn: INPUT GAIN, 1 dB a detent (1024) */
  gain_acc+=delta;
  int steps=gain_acc/1024;                                       /* KeyHandler thread, not audio */
  if(steps){gain_acc-=steps*1024;const uint32_t so=INPUT_SOURCE&3;
   int g=kn_gain_clamp(gain_db[so]+steps);if(g!=gain_db[so]){gain_db[so]=(int8_t)g;gain_dirty|=(uint8_t)(1u<<so);}}
 }
 return type==OP1_IN_KNOB||(type==OP1_IN_KEY&&code>=0x3B&&code<=0x3E);
}

int op1_input_tuner_active(void){return kn_input_tuner_visible();}
