/*
 * R246 resets only documents reachable in the table passed to screens_update. Kennel shares slots between
 * engines, effects and feature pages, so a displaced document's drawing buffers otherwise escape that reset.
 *
 * Keep the exact table drawn by the Gfx thread stable for the whole frame. At the next frame boundary, reset
 * documents removed from that table, before allocating the next screen's drawing buffers. Merely comparing
 * live table pointers once per frame is insufficient: KeyHandler can replace them again during drawing.
 * A fixed frame snapshot means intermediate requests never draw, so no retirement queue/registry can overflow.
 * Reset frees drawing caches, not the SVG tree. Screen objects live until reboot, and so do their documents,
 * except the lazy ones (engine and FX pages, docs/svg-lazy.md): parsed here when a frame first shows them and
 * freed here, after a frame, least recently drawn first, while the resident ones pass KN_SVG_CAP.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (LICENSE, NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")
#include <stdint.h>
#include "kn_screens.h"

static void *frame[KN_SCREEN_SLOTS];
static void *previous_docs[KN_SCREEN_SLOTS];

#ifdef OP1_HOST
void host_screens_update(void *table);
void host_screen_document_reset(void *doc);
void *host_svg_load(void *loader);
void host_document_delete(void *doc);
uint32_t host_te_used(void);
void host_artcache_forget(void *doc);
#define SCREENS_UPDATE host_screens_update
#define reset_document host_screen_document_reset
#define SVG_LOAD host_svg_load
#define delete_document host_document_delete
#define te_used host_te_used
#define kn_artcache_forget host_artcache_forget
static uint32_t cycles(void) { return 0; }
#else
#define SCREENS_UPDATE ((void (*)(void *))0x01A3BB20)
static void reset_document(void *doc)
{
    uint8_t *vt = *(uint8_t **)((uint8_t *)doc + 0x54);
    void (*reset)(void *) = *(void (**)(void *))(vt + 0x7C);
    reset((uint8_t *)doc + *(int16_t *)(vt + 0x78));
}
#define SVG_LOAD ((void *(*)(void *))0x01A503D8)     /* svg_load(loader): parses loader[1] from YAFFS into loader[0] */
/* The document's deleting destructor, as R246's loader teardown 0x01A50394 calls it: vt+0x8 this-adjust, vt+0xC
 * function, R1 = 3 (delete). It returns the parsed tree to the TE heap. */
static void delete_document(void *doc)
{
    uint8_t *vt = *(uint8_t **)((uint8_t *)doc + 0x54);
    void (*del)(void *, int) = *(void (**)(void *, int))(vt + 0x0C);
    del((uint8_t *)doc + *(int16_t *)(vt + 0x08), 3);
}
static uint32_t te_used(void) { return *(volatile uint32_t *)0x0106B7D0; }   /* TE heap TLSF statistics: used */
void kn_artcache_forget(void *doc);
static uint32_t cycles(void) { uint32_t c; __asm__ volatile("%0 = CYCLES;" : "=d"(c)); return c; }
#endif

static void *document(void *screen) { return screen ? *(void **)screen : 0; }

typedef struct { uintptr_t *screen; void (*init)(void *); void *fallback; uint32_t cost, drawn; uint8_t failed; } lazy_t;
static lazy_t lazy[KN_LAZY_MAX];
static uint32_t lazy_count, frame_no;
volatile uint32_t kn_svg_eager;
volatile uint32_t kn_lazy_stats[6];

int kn_lazy_add(void *screen, void (*init)(void *), void *fallback)
{
    if (!screen || !init || lazy_count >= KN_LAZY_MAX) return 0;
    lazy[lazy_count++] = (lazy_t){ screen, init, fallback, 0, 0, 0 };
    return 1;
}
static lazy_t *lazy_of(void *screen)
{
    for (uint32_t i = 0; i < lazy_count; i++) if (lazy[i].screen == screen) return &lazy[i];
    return 0;
}
static int parse(lazy_t *l)                            /* 1: the document is there and init has run */
{
    if (l->screen[0]) return 1;
    if (l->failed || !l->screen[2]) return 0;
    uint32_t before = te_used(), c0 = cycles();
    void *doc = SVG_LOAD((void *)l->screen[2]);
    if (!doc) { l->failed = 1; kn_lazy_stats[3]++; return 0; }   /* the stock page instead, until reboot */
    l->screen[0] = (uintptr_t)doc;
    l->init(l->screen);                                  /* node lookups again: the old ones went with the old tree */
    uint32_t c = cycles() - c0, after = te_used();
    l->cost = after > before ? after - before : 0;
    kn_lazy_stats[0] += l->cost; kn_lazy_stats[1]++; kn_lazy_stats[4] = c;
    if (c > kn_lazy_stats[5]) kn_lazy_stats[5] = c;
    return 1;
}
static void release(lazy_t *l)
{
    void *doc = (void *)l->screen[0];
    kn_artcache_forget(doc);                             /* a new document at this address must not replay its pixels */
    for (int i = 0; i < KN_SCREEN_SLOTS; i++) if (previous_docs[i] == doc) previous_docs[i] = 0;
    l->screen[0] = 0;
    *(uintptr_t *)l->screen[2] = 0;                       /* the loader's own copy: svg_load parses again */
    delete_document(doc);
    kn_lazy_stats[0] -= l->cost < kn_lazy_stats[0] ? l->cost : kn_lazy_stats[0];
    kn_lazy_stats[2]++;
    l->cost = 0;
}
static void lazy_load(void)                            /* before the frame's resets: show what can be shown */
{
    if (kn_svg_eager) for (uint32_t i = 0; i < lazy_count; i++) parse(&lazy[i]);
    for (int i = 0; i < KN_SCREEN_SLOTS; i++) {
        lazy_t *l = frame[i] ? lazy_of(frame[i]) : 0;
        if (!l) continue;
        if (parse(l)) l->drawn = frame_no;
        else frame[i] = l->fallback;
    }
}
static void lazy_evict(void)                           /* after the frame: least recently drawn first, over the cap */
{
    while (!kn_svg_eager && kn_lazy_stats[0] > KN_SVG_CAP) {
        lazy_t *old = 0;
        for (uint32_t i = 0; i < lazy_count; i++) {
            lazy_t *l = &lazy[i];
            if (!l->screen[0] || frame_no - l->drawn < 2) continue;   /* this frame's or the previous one's */
            if (!old || frame_no - l->drawn > frame_no - old->drawn) old = l;
        }
        if (!old) break;
        release(old);
    }
}

void kn_screens_frame(void *requested)
{
    void *volatile *live = requested;
    /* Only Gfx draws. Each aligned pointer load is atomic; requests may change during this copy, but every
     * captured object is fully constructed and remains alive. No IRQ masking across copies or SVG resets. */
    for (int i = 0; i < KN_SCREEN_SLOTS; i++) frame[i] = live[i];
    frame_no++;
    if (lazy_count) lazy_load();
    for (int i = 0; i < KN_SCREEN_SLOTS; i++) {
        void *old = previous_docs[i];
        if (!old || old == document(frame[i])) continue;
        int present = 0;
        for (int j = 0; j < KN_SCREEN_SLOTS; j++)
            if (document(frame[j]) == old) { present = 1; break; }
        if (present) continue;                                 /* aliases/moves retain their cache */
        int duplicate = 0;
        for (int j = 0; j < i; j++)
            if (previous_docs[j] == old) { duplicate = 1; break; }
        if (!duplicate) reset_document(old);                   /* Gfx boundary, never in an input/audio handler */
    }
    for (int i = 0; i < KN_SCREEN_SLOTS; i++) previous_docs[i] = document(frame[i]);
#ifndef OP1_HOST
    extern volatile uint32_t kn_te_ext;
    extern void kn_te_heap_extend(void);
    if (!kn_te_ext) kn_te_heap_extend();                       /* the fixed range as TE heap, once (kn_boot.c) */
#endif
    SCREENS_UPDATE(frame);                                     /* stock ID/heap-pressure resets and overlays intact */
    if (lazy_count) lazy_evict();
}
