/*
 * Hook point "LFO types" (op1_feature_lfo.h, docs/feature-hooks.md): the core side. R246's sites stay patched by the
 * core (hook.S, make_firmware.py, dispatcher.c); they ask here whether a word set belongs to a feature LFO and call
 * the registered types (up to KN_LFO_MAX, from one feature or several: op1_lfo_type.next), running in the MIDI LFO class.
 * Reserved: quad's and pond's names and word encodings are known here even when no feature registers them (the file
 * missing or broken), so a sound saved with quad or pond still loads (no range assert at boot) and its LFO then does
 * nothing.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_feature_lfo.h"

const op1_lfo_type *kn_lfo_owner(const int16_t *w);
int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);

const op1_lfo_type *kn_lfo_types[KN_LFO_MAX];    /* the registered LFO types, in registration order */
int kn_lfo_n;                                    /* how many; 0 = none (all sites stock) */
const op1_lfo_type *kn_lfo_type;                 /* the first one (the page / press / turn sites ask kn_lfo_owner) */

#define QUAD_MARK 0xA5                           /* quad (lfo/quadlfo.c): word 7 = 0xA5xx */
#define POND_MARK 0xA7                           /* pond (lfo/quadlfo.c, same file): word 7 = 0xA7xx */
static inline int quad_old_ctrl(int16_t c) { uint16_t m = (uint16_t)c & 0xE000; return m == 0x4000 || m == 0x6000; }

/* words of a released feature LFO, registered or not: quad's current format, and op1r <= 15 quad
 * (0x4000 / 0x6000 control words in 4..7) */
static int kn_lfo_reserved(const int16_t *w)
{
    if (((uint16_t)w[7] >> 8) == QUAD_MARK || ((uint16_t)w[7] >> 8) == POND_MARK) return 1;
    return quad_old_ctrl(w[4]) && quad_old_ctrl(w[5]) && quad_old_ctrl(w[6]) && quad_old_ctrl(w[7]);
}

static int same(const char *a, const char *b)
{
    if (!a || !b) return 0;
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}

/* kn_features_finish: every usable LFO type of every feature (and its `next` chain), a name and a marker once */
void kn_lfo_finish(void)
{
    kn_lfo_n = 0; kn_lfo_type = 0;
    for (int i = 0; i < kn_feature_count(); i++) {
        int guard = 0;                           /* a cyclic `next` ends here */
        for (const op1_lfo_type *t = kn_feature_at(i)->lfo; t && guard < KN_LFO_MAX; t = t->next, guard++) {
            if (!t->name || !t->match || t->stock_class != OP1_LFO_CLASS_MIDI || t->marker < 0x80) continue;
            int dup = 0;
            for (int k = 0; k < kn_lfo_n; k++) if (same(kn_lfo_types[k]->name, t->name) || kn_lfo_types[k]->marker == t->marker) dup = 1;
            if (!dup && kn_lfo_n < KN_LFO_MAX) kn_lfo_types[kn_lfo_n++] = t;
        }
    }
    kn_lfo_type = kn_lfo_n ? kn_lfo_types[0] : 0;
}

const char *kn_lfo_name(void) { return kn_lfo_type ? kn_lfo_type->name : 0; }
const char *kn_lfo_name_at(int i) { return i >= 0 && i < kn_lfo_n ? kn_lfo_types[i]->name : 0; }
/* 1: `name` is a registered type's */
int kn_lfo_is_name(const char *name)
{
    for (int i = 0; i < kn_lfo_n; i++) if (same(kn_lfo_types[i]->name, name)) return 1;
    return 0;
}

/* patch range check (dispatcher.c lfo_range_ok): word 7's high byte marks a feature LFO's words */
int kn_lfo_marker(int hi)
{
    if (hi == QUAD_MARK || hi == POND_MARK) return 1;
    for (int i = 0; i < kn_lfo_n; i++) if (hi == kn_lfo_types[i]->marker) return 1;
    return 0;
}

/* not stock MIDI LFO words: read_lfo_param must not range-check them, LfoMidi must not run them */
int kn_lfo_claims(const int16_t *w)
{
    return kn_lfo_reserved(w) || kn_lfo_owner(w);
}

/* the registered type whose words these are, or 0 */
const op1_lfo_type *kn_lfo_owner(const int16_t *w)
{
    for (int i = 0; i < kn_lfo_n; i++) if (kn_lfo_types[i]->match(w)) return kn_lfo_types[i];
    return 0;
}
static inline const op1_lfo_type *owner(const int16_t *w) { return kn_lfo_owner(w); }

/* LfoMidi vtable apply entries for claimed words (hook.S QL_STUB); unowned (reserved) words: no modulation */
int kn_lfo_apply_synth(void *self, const int16_t *w, int pass)
{
    const op1_lfo_type *t = owner(w);
    return t && t->apply_synth ? t->apply_synth(self, w, pass) : 0;
}
int kn_lfo_apply_drum(void *self, const int16_t *w, int pass)
{
    const op1_lfo_type *t = owner(w);
    return t && t->apply_drum ? t->apply_drum(self, w, pass) : 0;
}
int kn_lfo_apply_fx(void *self, const int16_t *w, int pass)
{
    const op1_lfo_type *t = owner(w);
    return t && t->apply_fx ? t->apply_fx(self, w, pass) : 0;
}

/* LfoMidi vtable +0x1c note-on triggers (make_firmware DATA_PATCHES); the stock ones are bare RTS */
void kn_lfo_trig_synth(void *self, const int16_t *w)
{
    const op1_lfo_type *t = owner(w);
    if (t && t->trig_synth) t->trig_synth(self, w);
}
void kn_lfo_trig_drum(void *self, const int16_t *w)
{
    const op1_lfo_type *t = owner(w);
    if (t && t->trig_drum) t->trig_drum(self, w);
}
void kn_lfo_trig_fx(void *self, const int16_t *w)
{
    const op1_lfo_type *t = owner(w);
    if (t && t->trig_fx) t->trig_fx(self, w);
}

/* dispatcher.c midi_cc_hook / midi_start_hook */
void kn_lfo_midi_cc(int cc, int value)
{
    for (int i = 0; i < kn_lfo_n; i++) if (kn_lfo_types[i]->midi_cc) kn_lfo_types[i]->midi_cc(cc, value);
}
void kn_lfo_midi_start(void)
{
    for (int i = 0; i < kn_lfo_n; i++) if (kn_lfo_types[i]->midi_start) kn_lfo_types[i]->midi_start();
}
