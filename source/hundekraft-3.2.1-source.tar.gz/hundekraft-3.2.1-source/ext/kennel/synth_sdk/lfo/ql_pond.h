/* "pond" LFO: four competing species (competitive Lotka-Volterra). DSP and word format, included by ql_dsp.h when the
 * includer defines QL_POND (lfo/quadlfo.c): the pond decodes into four quad LFOs (waves 10..13) that run through quad's
 * apply / trigger / state code, so the type shares quadlfo.c with quad.
 * Imported from op1r-src f2aed5d (xoza, pcppcp/op1r-src, GPL-3.0-or-later with the OP-1 firmware permission);
 * see PROVENANCE.md. Adapted: no page-2 / LFO targets (0..11 only), the 64-bit multiplies replaced by 32-bit ones,
 * population start flag in lz (no d2), tables unchanged.
 * Copyright (C) 2026 pcppcp and contributors (op1r-src), Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE). */
#ifndef QL_POND_H
#define QL_POND_H
/* Competitive Lotka-Volterra after Vano et al. 2006: dx_i/dt = r_i x_i (1 - sum_j a_ij x_j), off-diagonal a_ij scaled by
 * s = 0.85 .. 1.05 (chaos 0..31: from a gentle regular oscillation to chaos). Populations Q20 in LFO 0's state (lx, ly,
 * lz, d1; lz = 0 means not started; Q14 lost small species: their growth rounded to 0, the system froze), Euler
 * sub-steps <= 0.02 time units (max 32: a call at more than ~11 Hz is slowed down), floor 0.001 (no extinction).
 * One LFO cycle = the mean oscillation period at that chaos (pond_T), output k = (x_k - mean_k) / max swing_k (pond_mean,
 * pond_ext): calm = small swings, full chaos ~ +-1. Words: rate 6 | sync 1 | retrig 1 | chaos 5 | 4 x (target 5 |
 * amount 6 +32), marker 0xA7 in bits 120..127. Decoded as four quad LFOs, waves 10..13 (10 integrates, 11..13 read),
 * FREE / MONO. Targets 0..11 (knobs, envelope, FX knobs); a stored LFO target (12+) reads as blue. */
static int ql_is_pond(const int16_t *w) { return ((uint16_t)w[7] >> 8) == POND_MARK; }
typedef struct { uint8_t rate, sync, retrig, chaos, tgt[4]; int8_t amt[4]; } pond_set;
static void pond_get(const int16_t *w, pond_set *f)
{
    f->rate = (uint8_t)ql_get(w, 0, 6); f->sync = (uint8_t)ql_get(w, 6, 1); f->retrig = (uint8_t)ql_get(w, 7, 1);
    f->chaos = (uint8_t)ql_get(w, 8, 5);
    for (int k = 0; k < 4; k++) {
        int t = (int)ql_get(w, 13 + 11 * k, 5);
        f->tgt[k] = (uint8_t)(t >= 12 ? 0 : t);
        f->amt[k] = (int8_t)clampq((int)ql_get(w, 18 + 11 * k, 6) - 32, -31, 31);
    }
    if (f->sync) f->rate = (uint8_t)clampq(f->rate, 0, QL_DIVS - 1);
}
static void pond_put(const pond_set *f, int16_t *w)
{
    ql_put(w, 0, 6, f->rate); ql_put(w, 6, 1, f->sync); ql_put(w, 7, 1, f->retrig); ql_put(w, 8, 5, f->chaos);
    for (int k = 0; k < 4; k++) { ql_put(w, 13 + 11 * k, 5, f->tgt[k]); ql_put(w, 18 + 11 * k, 6, (uint32_t)(f->amt[k] + 32)); }
    ql_put(w, 120, 8, POND_MARK);
}
static void pond_dec(const int16_t *w, int i, ql_lfo *o)
{
    pond_set f; pond_get(w, &f);
    o->rate = f.rate; o->sync = f.sync; o->smooth = 0; o->off = 0; o->tl = o->tk = 0; o->phoff = 0;
    o->type = f.retrig ? QT_MONO : QT_FREE; o->chaos = f.chaos;
    o->inc = o->sync ? ql_div_inc(o->rate) : ql_inc((o->rate << 9) | 0x100);
    o->wave = (uint8_t)(10 + i); o->tgt = f.tgt[i]; o->amt = f.amt[i];
    o->a128 = (int16_t)(o->amt * 127 / 31);
}

static const int16_t pond_r[4] = { 4096, 2949, 6267, 5202 };          /* r_i Q12 */
static const int16_t pond_a[4][4] = { { 4096, 4465, 6226, 0 }, { 0, 4096, 1802, 5571 }, { 9544, 0, 4096, 1925 },
                                      { 4956, 2089, 1434, 4096 } };    /* a_ij Q12 */
static const uint16_t pond_T[33] = { 2578, 2572, 2564, 2556, 2547, 2537, 2526, 2514, 2502, 2489, 2475, 2460, 2444, 2428,
    2415, 2402, 2388, 2371, 2352, 2333, 2311, 2312, 2282, 2154, 2030, 1924, 1956, 1968, 1992, 1930, 1937, 1929, 1939 };   /* Q6 */
static const int16_t pond_mean[33][4] = { {5437,7655,2984,6586},{5419,7658,2934,6545},{5397,7655,2893,6509},{5375,7645,2856,6477},
    {5361,7639,2809,6440},{5343,7644,2761,6399},{5317,7636,2728,6369},{5302,7625,2687,6335},{5284,7632,2641,6295},{5258,7618,2612,6269},
    {5247,7622,2562,6227},{5220,7616,2532,6198},{5207,7616,2487,6160},{5179,7611,2460,6131},{5163,7608,2421,6096},{5134,7607,2390,6067},
    {5113,7592,2361,6042},{5085,7584,2337,6016},{5070,7571,2304,5987},{5046,7557,2279,5963},{5022,7548,2253,5937},{5003,7545,2220,5905},
    {4975,7527,2203,5887},{4955,7537,2161,5851},{4934,7520,2140,5828},{4914,7508,2114,5803},{4895,7497,2089,5777},{4873,7494,2061,5749},
    {4851,7476,2043,5726},{4829,7470,2014,5703},{4805,7465,1990,5678},{4786,7440,1974,5660},{4762,7420,1956,5644} };   /* Q14 */
static const int16_t pond_ext[4] = { 6972, 5838, 4794, 4219 };       /* max swing at full chaos, Q14 */
static volatile int16_t pond_trail[2][48][2];                         /* (x1 - x3, x2 - x4) Q14 per 1/48 cycle, per page */
static volatile uint8_t pond_dom[2][48], pond_head[2];
static uint8_t ql_pg;                                                  /* the page whose shared states are stepped (ql_advance_pos) */
static int32_t *pond_x(ql_st *s, int k) { return k == 0 ? &s->lx : k == 1 ? &s->ly : k == 2 ? &s->lz : &s->d1; }
static int32_t pond_lv(ql_st *s, const ql_lfo *o, uint32_t adv, int i)
{
    ql_st *s0 = s - i;                                         /* species k: LFO k reads LFO 0's state (sh_st[pos][0]) */
    int q = o->chaos > 31 ? 31 : o->chaos;
    if (i == 0) {
        if (!s->lz) { s->lx = 314573; s->ly = 419430; s->lz = 314573; s->d1 = 524288; }   /* (0.3, 0.4, 0.3, 0.5) Q20 */
        /* time units Q12 this step = adv * T / 2^26 (T Q6), in 32 bit: (adv * T) >> 16 without a 64-bit multiply */
        uint32_t dt = (((adv >> 16) * pond_T[q]) + (((adv & 0xFFFF) * pond_T[q]) >> 16)) >> 10;
        int n = (int)((dt + 81) / 82);                                   /* sub-steps <= 0.02 */
        if (n > 32) { n = 32; dt = 32 * 82; }
        int32_t h = n ? (int32_t)(dt / (uint32_t)n) : 0, sc = 3482 + q * 26;   /* s Q12: 0.85 .. 1.05 */
        int32_t x[4] = { s->lx, s->ly, s->lz, s->d1 };
        for (int st = 0; st < n; st++) {
            int32_t d[4];
            for (int a = 0; a < 4; a++) {
                int32_t sum = 0;
                for (int b = 0; b < 4; b++) {
                    int32_t c = a == b ? pond_a[a][b] : (pond_a[a][b] * sc) >> 12;
                    sum += (c * (x[b] >> 8)) >> 12;              /* Q12 */
                }
                if (sum > 16384) sum = 16384;                    /* (never reached by the dynamics; keeps the products in 32 bit) */
                int32_t rx = ((x[a] >> 4) * pond_r[a]) >> 8;     /* r x, Q20 */
                d[a] = ((rx >> 6) * (4096 - sum)) >> 6;          /* Q20 per time unit */
            }
            for (int a = 0; a < 4; a++) { x[a] += (d[a] * h) >> 12; if (x[a] < 1049) x[a] = 1049; if (x[a] > 2097152) x[a] = 2097152; }
        }
        s->lx = x[0]; s->ly = x[1]; s->lz = x[2]; s->d1 = x[3];
        uint32_t nph = s->ph, oph = nph - adv;
        if (adv && (((oph >> 16) * 48) >> 16) != (((nph >> 16) * 48) >> 16)) {   /* every 1/48 cycle */
            int pg = ql_pg & 1, hd = (pond_head[pg] + 1) % 48, dm = 0;
            for (int a = 1; a < 4; a++) if (x[a] > x[dm]) dm = a;
            pond_trail[pg][hd][0] = (int16_t)((x[0] - x[2]) >> 6); pond_trail[pg][hd][1] = (int16_t)((x[1] - x[3]) >> 6);
            pond_dom[pg][hd] = (uint8_t)dm; pond_head[pg] = (uint8_t)hd;
        }
    }
    int32_t out = ((*pond_x(s0, i) >> 6) - pond_mean[q][i]) * 32767 / pond_ext[i];   /* |difference| < 2^15: fits 32 bit */
    return out > 32767 ? 32767 : out < -32767 ? -32767 : out;
}
#endif
