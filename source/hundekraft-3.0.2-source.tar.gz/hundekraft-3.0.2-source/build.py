#!/usr/bin/env python3
"""Build from the source snapshot; Git and prebuilt patch data are not required."""
import argparse,copy,hashlib,json,os,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--firmware',type=Path);p.add_argument('--toolchain',type=Path);p.add_argument('--binutils',type=Path);p.add_argument('--lander',action='store_true');p.add_argument('--output',type=Path);p.add_argument('--verify',action='store_true');a=p.parse_args()
manifest=json.loads((ROOT/'PROVENANCE.json').read_text())
changed=[n for n,v in manifest['files'].items() if not(ROOT/n).is_file() or hashlib.sha256((ROOT/n).read_bytes()).hexdigest()!=v]
if a.verify:
 print(json.dumps({'source_files':len(manifest['files']),'changed':changed}));sys.exit(bool(changed))
if not a.firmware or not a.toolchain:p.error('--firmware and --toolchain BIN_DIRECTORY required')
f=a.firmware.resolve();compiler=a.toolchain.resolve()/'bfin-elf-gcc';binutils=(a.binutils or a.toolchain).resolve()
if not compiler.is_file():p.error('bfin-elf-gcc not found')
# Preserve the source builders; supply their conventional input and toolchain paths.
for target,actual in [(ROOT/'firmware/op1_246.op1',f),(ROOT/'toolchain/bfin-gcc',compiler.parent.parent),(ROOT/'toolchain/bfin',binutils.parent)]:
 target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists() or target.is_symlink():
  if target.resolve()!=actual:p.error(str(target)+' already points elsewhere')
 else:target.symlink_to(actual)
sys.path[:0]=[str(ROOT/'tools/firmware'),str(ROOT/'tools/engines')]
import builder as B,op1r_plugins as P,runtime as R
original=f.read_bytes();R.checked(original,'c5315218f825f143b415ca554516541898abee843d3a236df0b54c04e1fb13a9','Original R246')
B.GCC=P.GCC=compiler;P.BINUTILS=binutils;B.SQLC.GCC=compiler;B.M.BINUTILS=str(binutils)
profile=copy.deepcopy(B.BASES['kennel30-plugins']);profile['source_commit']=manifest['kennel_commit']
B.R.PRODUCT.update(name='hundekraft',version='3.0.2',label='hundekraft 3.0.2',slug='hundekraft-3.0.2')
P.git_head=lambda path:profile['source_commit'] if 'kennel' in str(path) else profile['commit']
P.select(profile)
# fxgeneric.svg is the unmodified stock Iter screen: obtain it only from the user's verified input.
stock=dict((m.name,d)for m,d in R.unpack(original));screen=ROOT/'ext/kennel/synth_sdk/display/fxgeneric.svg';screen.write_bytes(stock['content/display/iter.svg'])
generated=ROOT/'build/generated'
if generated.exists():p.error('build/generated exists; move it aside before a fresh rebuild')
P.make_base(generated,f)
class SnapshotBuilder(B.Builder):
 def __init__(self):
  self.profile=profile;self.catalog=copy.deepcopy(B.CATALOG);self.catalog['base']='kennel30-plugins'
  listed={'kennel30-plugins',profile['catalog_base']};self.catalog['op1r_plugins']=[v for v in self.catalog['op1r_plugins'] if listed & set(v.get('bases',listed))]
  for v in self.catalog['utilities']:
   text=v.pop('kennel_description',None)
   if text:v['description']=text
  self.upstream=ROOT/profile['directory'];self.generated=generated;self.base_dir=generated/'patcher/data'
  meta=json.loads((generated/'base.json').read_text());self.utility_chains=tuple(tuple(int(x,16)for x in c)for c in meta['utility_chains']);self.shift_wants=int(meta['seq_shift_wants'],16)if meta.get('seq_shift_wants')else None
  self.kennel_choices();self.base=json.loads((self.base_dir/'manifest.json').read_text());self.op1=original;self.original=R.unpack(original);self.members=R.apply_manifest(self.original,self.base,lambda n:(self.base_dir/n).read_bytes())
  self.release=json.loads((ROOT/'expected.json').read_text())['release'];self.cache=ROOT/'build/cache';self.cache.mkdir(parents=True,exist_ok=True)
  self.cf=['-mcpu=bf524','-O2','-ffreestanding','-fno-builtin','-Wall','-Wextra','-I',str(ROOT/'tools/engines'),'-I',str(ROOT/'tools/fx')];self.diff=B.module('op1r_diff',self.upstream/'build_patch.py')
b=SnapshotBuilder();expected=json.loads((ROOT/'expected.json').read_text());key='100000000000007ff'if a.lander else '7ff';config=expected['variants'][key]['config']
members,_=b.configured_members(config);b.validate(members,config);out=R.pack_op1(R.pack_tar(members));dst=(a.output or ROOT/'build'/('hundekraft-3.0.2'+('-lander'if a.lander else '')+'.op1')).resolve()
if dst==f:p.error('output cannot overwrite original input')
dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(out);digest=hashlib.sha256(out).hexdigest();report={'config':config,'config_id':key,'filename':dst.name,'output_sha256':digest,'expected_sha256':expected['variants'][key]['sha256'],'matches_published_firmware':digest==expected['variants'][key]['sha256'],'modified_source':changed};dst.with_suffix('.build.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if not changed and not report['matches_published_firmware']:sys.exit('Rebuild differs: check compiler and host dependencies')
