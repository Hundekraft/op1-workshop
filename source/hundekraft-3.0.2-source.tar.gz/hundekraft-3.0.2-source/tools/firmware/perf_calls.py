#!/usr/bin/env python3
"""Guest cycles per audio call from an emulator run, for op1r's code image with our plugins (relative numbers only).

    python3 tools/firmware/perf_calls.py breaks [ELF]        -> the OP1EMU_BREAK value to run with
    python3 tools/firmware/perf_calls.py report LOG [ELF]    -> cycles per call, per function

Run the emulator with --deterministic (guest time = executed packets, one CCLK each, so guest_ns / 2.5 = packets)
and OP1EMU_BREAK set to the `breaks` output. The breaks are op1r's sysmon audio wrapper (whole callback per block),
each plugin's render entry and the return sites of the dispatcher's indirect calls (synth_render, fx_render,
fx_render_stereo) and of R246's mono FX call. A call's cost is the guest time from its entry break to the next return-site break, so it
includes anything that interrupts it; the report gives the median and the maximum.

The emulator counts packets, not Blackfin cycles: no stalls, no SDRAM or cache latency, and the audio link runs at
22.05k frames/s. Use the numbers to rank functions and to check that a change lowers the count, not as % of budget."""
import re, statistics, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import perf_scan

CCLK_NS = 2.5                     # 400 MHz
CALLERS = ['_synth_render', '_fx_render', '_fx_render_stereo']
AUDIO_CB = '_sm_audio_cb'
# R246 calls the mono filter FX's process straight from L1 (vtable +0x14 at 0xFFA02B34, docs/firmware/synth.md), so a
# mono FX render returns there, not to the dispatcher
R246_RETURNS = [0xFFA02B36]
TAGS = ['_ql_apply_synth']        # Quad LFO on a synth


def points(elf):
    """{pc: label}: entry breaks ('enter NAME'), return sites ('return'), audio callback start/end"""
    funcs, by_addr = perf_scan.parse(perf_scan.tool('bfin-elf-objdump', '-d', elf))
    roots = perf_scan.table_roots(elf, by_addr)
    pts = {}
    for label, fn in roots.items():
        if label.endswith('.render'):
            pts.setdefault(funcs[fn]['start'], f'enter {label}')
    for c in CALLERS:
        for a in funcs[c]['icalls']:
            pts[a + 2] = 'return'                       # CALL (Pn) is 16 bits
    for t in TAGS:                                      # only marks the block it runs in
        pts.setdefault(funcs[t]['start'], f'tag {t[1:]}')
    for a in R246_RETURNS:
        pts[a] = 'return'
    cb = funcs[AUDIO_CB]
    pts[cb['start']] = 'cb start'
    pts[cb['icalls'][0] + 2] = 'cb end'
    return pts


def report(log, elf):
    pts = points(elf)
    hit = re.compile(r'break (0x[0-9a-f]+) hit')
    ns = re.compile(r'guest_ns=(\d+)')
    events, pc = [], None
    for line in open(log, errors='replace'):
        m = hit.search(line)
        if m:
            pc = int(m.group(1), 16)
            continue
        m = ns.search(line)
        if m and pc is not None:
            events.append((pc, int(m.group(1))))
            pc = None
    # cb: per audio block, the callback's cost grouped by the plugin calls made in it (e.g. 6 x fmbell + clouds)
    calls, cb, open_call, cb_t0, inside = {}, {}, None, None, []
    for pc, t in events:
        what = pts.get(pc, '?')
        if what.startswith('enter '):
            open_call = (what[6:], t)
            inside.append(what[6:])
        elif what.startswith('tag '):
            inside.append(what[4:])
        elif what == 'return' and open_call:
            calls.setdefault(open_call[0], []).append((t - open_call[1]) / CCLK_NS)
            open_call = None
        elif what == 'cb start':
            cb_t0, inside = t, []
        elif what == 'cb end' and cb_t0 is not None:
            key = ' + '.join(f'{inside.count(x)} x {x}' for x in sorted(set(inside))) or 'no plugin'
            cb.setdefault(key, []).append((t - cb_t0) / CCLK_NS)
            cb_t0 = None
    print(f'{len(events)} break hits')
    print(f"{'call':28} {'n':>7} {'median':>9} {'max':>9}  (packets)")
    for name, v in sorted(calls.items()):
        print(f'{name:28} {len(v):7} {statistics.median(v):9.0f} {max(v):9.0f}')
    print(f"\n{'audio callback per block, by plugin calls in it':60} {'n':>7} {'median':>9} {'max':>9}")
    for key, v in sorted(cb.items(), key=lambda kv: -len(kv[1])):
        if len(v) >= 20:
            print(f'{key[:60]:60} {len(v):7} {statistics.median(v):9.0f} {max(v):9.0f}')
    return calls, cb


def main(argv):
    if not argv or argv[0] not in ('breaks', 'report'):
        sys.exit(__doc__)
    if argv[0] == 'breaks':
        elf = Path(argv[1]) if len(argv) > 1 else perf_scan.default_elf()
        print('+'.join(f'{a:x}' for a in sorted(points(elf))) + ',5000000')
    else:
        elf = Path(argv[2]) if len(argv) > 2 else perf_scan.default_elf()
        report(argv[1], elf)


if __name__ == '__main__':
    main(sys.argv[1:])
