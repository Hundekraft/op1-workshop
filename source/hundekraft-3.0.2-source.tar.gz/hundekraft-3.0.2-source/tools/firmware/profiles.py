"""Pinned firmware base adapters."""
RELEASED_BASE = 'op1r18'
BASES = {
    'op1r18': {
        'version': '18', 'commit': 'fb06689142726d48d7307c4c9eeb687e943ef92d',
        'directory': 'ext/op1r', 'experimental': False,
        'utility_chains': ((0x019c2d3e, 0x01e4064a, 0x01e01598),
                           (0x019c2e94, 0x01e406ae, 0x01e01d98)),
    },
    'op1r20': {
        'version': '20', 'commit': '0ed5f5c52579f47790d852d09fd4936d24f139e7',
        'directory': 'ext/op1r20', 'experimental': True,
        'utility_chains': ((0x019c2d3e, 0x01e4064a, 0x01e01640),
                           (0x019c2e94, 0x01e406ae, 0x01e01f4c)),
    },
    'op1r22': {
        'version': '22', 'commit': '3a3e9d78dcd388e8fa493c9cfedfd96ebfc705c6',
        'directory': 'ext/op1r22', 'experimental': True,
        'utility_chains': ((0x019c2d3e, 0x01e4064a, 0x01e0178c),
                           (0x019c2e94, 0x01e406ae, 0x01e02304)),
    },
    # op1r 27 carries the SQLite page-cache cap itself (same call site and limits as ours), so the builder skips its own.
    'op1r27': {
        'version': '27', 'commit': 'd02d60c6a76fa62ba40d75269124d650f5233be0',
        'directory': 'ext/op1r27', 'experimental': True, 'sqlite_cache_cap': True,
        'utility_chains': ((0x019c2d3e, 0x01e4064a, 0x01e01998),
                           (0x019c2e94, 0x01e406ae, 0x01e0275c)),
    },
    # op1r 27 built from op1r-src with our synths/FX as its plugins (op1r_plugins.py). The base is generated and
    # cached by content; 'directory'/'commit' pin op1r's patcher and docs, 'source_commit' the pinned op1r-src.
    # Maiko's input chain targets are read from the generated image (base.json), not pinned here.
    'op1r27-plugins': {
        'version': '27', 'commit': 'd02d60c6a76fa62ba40d75269124d650f5233be0',
        'directory': 'ext/op1r27', 'experimental': True, 'sqlite_cache_cap': True,
        'plugins': True, 'source': 'ext/op1r-src', 'source_commit': '5db2464284cb1d8604f4d3e0719fca4436f45833',
        'utility_chains': None,
    },
    # op1r 30 (drum+, sample editor and tape erase work; the Quad LFO fix is upstream): the same plugin build from
    # op1r-src 99665a3 (ext/op1r-src30) with op1r's patcher at 6b77bf3 (ext/op1r30).
    'op1r30-plugins': {
        'version': '30', 'commit': '6b77bf3fe2a0a006dc79750b34c03c9ba8d8fe01',
        'directory': 'ext/op1r30', 'experimental': True, 'sqlite_cache_cap': True,
        'plugins': True, 'source': 'ext/op1r-src30', 'source_commit': '99665a3115ad2c9ac4bde5838cf71bf0fb8eebc6',
        'utility_chains': None,
    },
    # hundekraft 2.7: op1r-src df30df0 (main with Musica Obscura #1 merged, synths 8/9, FX 6/7; devupd hooks only in
    # --dev builds) merged with chord-hk edb5af3 (2.7.1 = abae9b0), plus 78c536b seq_shift_wants for the Scale-mode
    # Shift shortcuts (maiko249.SHIFT_STUB): branch hk27-base in ext/op1r-src30mochord (fork Hundekraft/op1r-src).
    # 2.8: fork branch hk28-base 175ca8c = 78c536b + the safer SysEx update (devupd-safe), checkout ext/op1r-src-devupd;
    # 'devupd' pokes its two hooks into the base (op1r_plugins.add_devupd_hooks) and sets "devupd" in release.json.
    # All plugin code is linked to 'plugin_region' (its own LDR block): with every plugin in op1r's core image it
    # would run past Maiko's 0x01E40000.
    'op1r30mo-chord-plugins': {
        'version': '30', 'commit': '6b77bf3fe2a0a006dc79750b34c03c9ba8d8fe01',
        'directory': 'ext/op1r30', 'experimental': True, 'sqlite_cache_cap': True,
        'plugins': True, 'source': 'ext/op1r-src-devupd', 'source_commit': '175ca8c60ccb9de3daa40a1e7fd2042b25af95fd',
        'plugin_region': 0x01F08000, 'utility_chains': None, 'devupd': True,
    },
    # Hundekraft 3.0: the kennel core (ext/kennel, its own repo) with op1r's patcher at 6b77bf3. Compiled-in
    # plugins link to 'plugin_region'; "loadable" ones ship as content/<name>.knl. Maiko #249 is never patched in
    # (its hooks collide with kennel's, e.g. 0x019B2690): the utilities bundle ships kennel's rebuild instead, the
    # scale / naming / file / undo plugin files. Every plugin file is a choice per build (runtime.file_choices).
    'kennel30-plugins': {
        'version': '30', 'commit': '6b77bf3fe2a0a006dc79750b34c03c9ba8d8fe01',
        'directory': 'ext/op1r30', 'experimental': True, 'sqlite_cache_cap': True,
        'plugins': True, 'source': 'ext/kennel', 'source_commit': 'fe0883ad6d2205ad6fe762ceeba2fb9ea784b804',
        'plugin_region': 0x01F08000, 'utility_chains': None, 'devupd': True, 'kennel': True,
        'catalog_base': 'op1r30mo-chord-plugins',   # op1r plugins as listed for 2.x (catalog 'bases')
    },
    # Alternative base: op1r30-plugins plus chord mode (docs/chord-mod.md), chord integration in
    # ext/op1r-src30chord (from 99665a3; tracked copy in patches/op1r-src30chord/). Not for release.
    'op1r30chord-plugins': {
        'version': '30', 'commit': '6b77bf3fe2a0a006dc79750b34c03c9ba8d8fe01',
        'directory': 'ext/op1r30', 'experimental': True, 'sqlite_cache_cap': True,
        'plugins': True, 'source': 'ext/op1r-src30chord', 'source_commit': 'f1305eab92e3c6d70c018405b0c81b2b2c8ac727',
        'utility_chains': None,
    },
}
