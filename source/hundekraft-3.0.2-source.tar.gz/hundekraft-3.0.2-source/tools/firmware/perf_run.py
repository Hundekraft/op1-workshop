#!/usr/bin/env python3
"""Emulator profile of op1r's plugins: one preset per engine (dry) and per effect / Quad LFO (on fmbell), each played
as a held 6-note chord, with perf_calls.py's breaks. Relative numbers only (see perf_calls.py).

    python3 tools/firmware/perf_run.py presets OUT_DIR
        -> OUT_DIR/perf/*.aif, 12 presets "a1 supersaw" .. "c1 quad" (defaults from the 2.5 DB rows)
    python3 tools/firmware/perf_run.py run NAND OUT_DIR [--row N] [--nav] [--emu OP1EMU]
        -> OUT_DIR/emu.log (break hits), OUT_DIR/pNN.ppm (browser before each chord), OUT_DIR/report.txt,
           OUT_DIR/elf.txt (the op1r-plugins ELF the breaks came from: the newest under build/configurator, so
           build the firmware under test last)

NAND: a 2.5 firmware (builder.py --base op1r27-plugins) installed with tools/mknand.sh, plus the presets folder
installed with tools/install_presets.sh (absolute folder path). --row is the PERF folder's row in the synth preset
browser (0 = CLUSTER; 6 on a NAND with only factory folders and PERF); --nav takes a screenshot per row instead of
playing, to find it. --emu runs another op1emu build (default ext/op1emu/build/op1emu); OP1EMU_* variables in the
environment are passed on (perf_mem.py sets the memory model's). The run is --deterministic and --nand-snapshot
(about 2.5 min). One emulator at a time."""
import os, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

ENGINES = {'supersaw': [8000, 0, 12000, 6000, 21249], 'fmbell': [8192, 16000, 8000, 0, 21250],
           'wavetable': [16384, 8192, 0, 8192, 21252], 'taffy': [16384, 8192, 0, 8192, 21253],
           'pew': [16384, 8192, 0, 8192, 21254], 'elg': [16384, 8192, 0, 8192, 21255]}
FX = {'tape': [5361, 10500, 8250, 12691, 21249, 0, 0, 0], 'clouds': [7296, 12288, 16896, 20479, 21250, 16384, 22938, 0],
      'reverb': [7126, 15000, 11264, 17191, 21251, 0, 0, 0], 'washer': [7296, 12288, 11264, 20480, 21252, 0, 0, 0],
      'snowglobe': [7296, 12288, 11264, 20480, 21253, 0, 0, 0]}
QUAD = [19, -8192, 7, -22526, 2, -9727, 24576, -23168]
CHORD = ['c4', 'e4', 'g4', 'a4', 'c5', 'd5']
COUNT = len(ENGINES) + len(FX) + 1


def preset(name, engine, fx=None, quad=False):
    return {"adsr": [200, 8000, 32767, 4000, 2048, 5568, 4000, 4000], "fx_active": fx is not None,
            "fx_params": FX[fx] if fx else [8000, 8000, 8000, 8000, 0, 0, 0, 0], "fx_type": fx or "delay",
            "knobs": ENGINES[engine] + [0, 0, 0], "lfo_active": quad,
            "lfo_params": QUAD if quad else [16000, 0, 0, 16000, 0, 0, 0, 0], "lfo_type": "quad" if quad else "tremolo",
            "name": name, "octave": 0, "synth_version": 2, "type": engine}


def presets(out):
    sys.path.insert(0, str(ROOT / 'tools'))
    import op1r_presets
    folder = Path(out) / 'perf'
    folder.mkdir(parents=True, exist_ok=True)
    metas = [preset(f'a{i} {e}', e) for i, e in enumerate(ENGINES, 1)]
    metas += [preset(f'b{i} {f}', 'fmbell', fx=f) for i, f in enumerate(FX, 1)]
    metas += [preset('c1 quad', 'fmbell', quad=True)]
    for m in metas:
        (folder / f"{m['name']}.aif").write_bytes(op1r_presets.aifc(m, []))
    print(f'{len(metas)} presets in {folder}')


def script(row, nav):
    L = ['accel 64 -64 512', 'volume 255', 'wait-frames 1 600000', 'wait-frames 20 600000', 'wait-frames 300',
         'tap synth 150', 'wait-frames 120', 'press shift', 'wait-frames 6', 'tap s1 150', 'wait-frames 6',
         'release shift', 'wait-frames 90', 'turn enc1 ccw 300', 'wait-frames 30']
    if nav:
        for r in range(1, 25):
            L += ['turn enc1 cw 8', 'wait-frames 20', f'screenshot row{r:02d}.ppm']
        return '\n'.join(L + ['quit']) + '\n'
    # one row at a time: a single long turn accelerates and overshoots
    L += ['turn enc1 cw 8', 'wait-frames 20'] * row + ['wait-frames 20', 'turn enc2 ccw 300', 'wait-frames 40']
    for i in range(COUNT):
        if i:
            L.append('turn enc2 cw 8')
        L += ['wait-frames 60', f'screenshot p{i:02d}.ppm'] + [f'press {k}' for k in CHORD] + ['wait-frames 120'] + \
             [f'release {k}' for k in CHORD] + ['wait-frames 90']
    return '\n'.join(L + ['wait-frames 30', 'quit']) + '\n'


def run(nand, out, row, nav, emu=None):
    out = Path(out).resolve()
    (out / 'gui').mkdir(parents=True, exist_ok=True)
    subprocess.run(['cp', str(ROOT / 'otp/otp.bin'), str(out)], check=True)
    for f in ('ui.json', 'ui.png'):
        if not (out / 'gui' / f).exists():
            (out / 'gui' / f).symlink_to(ROOT / 'ext/op1emu/gui' / f)
    (out / 'in.txt').write_text(script(row, nav))
    env = dict(os.environ)
    if not nav:
        sys.path.insert(0, str(HERE))
        import perf_scan
        elf = perf_scan.default_elf()          # recorded: the reports map pcs with the same ELF
        (out / 'elf.txt').write_text(str(elf) + '\n')
        env['OP1EMU_BREAK'] = subprocess.run([sys.executable, str(HERE / 'perf_calls.py'), 'breaks', str(elf)],
                                             capture_output=True, text=True, check=True).stdout.strip()
    with open(out / 'emu.log', 'w') as log:
        subprocess.run([str(Path(emu).resolve() if emu else ROOT / 'ext/op1emu/build/op1emu'), str(Path(nand).resolve()), '--nand-snapshot', '--headless',
                        '--deterministic', '--input-script', 'in.txt'], cwd=out, env=env, stdout=log,
                       stderr=subprocess.STDOUT, check=True)
    if not nav:
        rep = subprocess.run([sys.executable, str(HERE / 'perf_calls.py'), 'report', str(out / 'emu.log'), str(elf)],
                             capture_output=True, text=True, check=True).stdout
        (out / 'report.txt').write_text(rep)
        print(rep)


def main(argv):
    if len(argv) >= 2 and argv[0] == 'presets':
        presets(argv[1])
    elif len(argv) >= 3 and argv[0] == 'run':
        row = int(argv[argv.index('--row') + 1]) if '--row' in argv else 6
        emu = argv[argv.index('--emu') + 1] if '--emu' in argv else None
        run(argv[1], argv[2], row, '--nav' in argv, emu)
    else:
        sys.exit(__doc__)


if __name__ == '__main__':
    main(sys.argv[1:])
