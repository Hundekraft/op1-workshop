#!/usr/bin/env python3
"""Add the SQLite page-cache cap (sqlite_cache_hook.c) to an existing R246-based .op1.

Appends one plain LDR block with the hook at HOOK_ADDR (free SDRAM after the boot banner) and redirects the
CALL to the stock "open all databases" routine inside SQLite init. Nothing else changes; encrypted blocks and
te-boot stay byte-identical. Not part of builder.py or any release.

usage: sqlite_cache_patch.py IN.op1 OUT.op1 [--overlay FILE]   (--overlay also writes an OP1EMU_OVERLAY file)
"""
import argparse
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'tools/engines'))
import mkfw as M  # noqa: E402
import runtime as R  # noqa: E402

GCC = ROOT / 'toolchain/bfin-gcc/bin/bfin-elf-gcc'
HOOK_ADDR = 0x01EF0100                 # free SDRAM (mkfw FREE_LO..FREE_HI); banner block ends at 0x01EF0040
HOOK_END = 0x01EF1000
CALL_SITE = 0x0196F942                 # CALL 0x0196f6b4 inside the SQLite init routine 0x0196f912
STOCK_CALL = bytes.fromhex('ffe3b9fe')
STOCK = {'stock_db_open_all': 0x0196F6B4, 'stock_db_exec': 0x0196F950}


def call(pc, target):
    """CALL target at pc: 0xE3 | imm24[23:16], imm24[15:0]; imm24 = (target - pc) / 2"""
    off = (target - pc) >> 1
    if not -(1 << 23) <= off < (1 << 23):
        raise SystemExit(f'CALL from {pc:#x} to {target:#x} is out of range')
    off &= 0xFFFFFF
    return struct.pack('<HH', 0xE300 | (off >> 16), off & 0xFFFF)


def build_hook(work):
    script = work / 'hook.ld'
    script.write_text(f'ENTRY(_sqlite_cache_hook)\nSECTIONS {{\n . = {HOOK_ADDR:#x};\n'
                      ' .text : { *(.text.hooks) *(.text*) }\n .rodata : { *(.rodata*) }\n'
                      ' .data : { *(.data*) *(.sdata*) *(.bss*) *(.sbss*) *(COMMON) }\n __hook_end = .;\n'
                      ' /DISCARD/ : { *(.comment) *(.eh_frame*) *(.note*) }\n}\n')
    elf = work / 'hook.elf'
    syms = [f'-Wl,--defsym,_{k}={v:#x}' for k, v in STOCK.items()]
    subprocess.run([GCC, '-mcpu=bf524', '-O2', '-ffreestanding', '-fno-builtin', '-Wall', '-Wextra', '-Werror',
                    '-nostdlib', '-T', script, *syms, HERE / 'sqlite_cache_hook.c', '-lgcc', '-o', elf], check=True)
    load, image, table = elf_image(elf)
    if load != HOOK_ADDR or table['sqlite_cache_hook'] != HOOK_ADDR or HOOK_ADDR + len(image) > HOOK_END:
        raise SystemExit('hook layout unexpected')
    return image


def elf_image(elf):
    nm = subprocess.run([str(Path(M.BINUTILS) / 'bfin-elf-nm'), elf], capture_output=True, text=True, check=True)
    syms = {p[2].lstrip('_'): int(p[0], 16) for p in (line.split() for line in nm.stdout.splitlines()) if len(p) == 3}
    out = elf.with_suffix('.bin')
    subprocess.run([str(Path(M.BINUTILS) / 'bfin-elf-objcopy'), '-O', 'binary', elf, out], check=True)
    image = out.read_bytes()
    image += bytes((-len(image)) % 4)
    return HOOK_ADDR, image, syms


def patch_ldr(ldr, image):
    blocks = M.ldr_blocks(ldr)
    for _, flags, start, count, _ in blocks:
        if count and not flags & 0x1000 and start < HOOK_END and start + count > HOOK_ADDR:
            raise SystemExit(f'hook range overlaps LDR block at {start:#x}')
    at = M.ldr_word(ldr, blocks, CALL_SITE)
    if ldr[at:at + 4] != STOCK_CALL:
        raise SystemExit('unexpected instruction at the SQLite init call site (already patched or not R246?)')
    ldr = ldr[:at] + call(CALL_SITE, HOOK_ADDR) + ldr[at + 4:]
    final = next(o for o, flags, _, _, _ in blocks if flags & 0x8000)
    return M.fix_first_header(ldr[:final] + M.header(6, HOOK_ADDR, len(image), 0) + image + ldr[final:])


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument('input', type=Path)
    ap.add_argument('output', type=Path)
    ap.add_argument('--overlay', type=Path, help='also write an OP1EMU_OVERLAY file for an unpatched NAND')
    a = ap.parse_args()
    with tempfile.TemporaryDirectory() as td:
        image = build_hook(Path(td))
    members = R.unpack(a.input.read_bytes())
    out = []
    for info, data in members:
        if info.name == 'OP1_vdk.ldr':
            data = patch_ldr(data, image)
            R.validate_ldr(data)
        out.append((info, data))
    raw = R.pack_tar(out)
    a.output.write_bytes(R.pack_op1(raw))
    check = dict((m.name, d) for m, d in R.unpack(a.output.read_bytes()))
    if check['te-boot.ldr'] != dict((m.name, d) for m, d in members)['te-boot.ldr']:
        raise SystemExit('te-boot changed')
    print(f'{a.output}: hook {len(image)} bytes at {HOOK_ADDR:#x}, sha256 {R.sha256(a.output.read_bytes())}')
    if a.overlay:
        blob = a.overlay.with_suffix('.bin')
        blob.write_bytes(image)
        word = int.from_bytes(call(CALL_SITE, HOOK_ADDR), 'little')
        a.overlay.write_text(f'# sqlite_cache_patch.py hook (same bytes as the candidate firmware)\n'
                             f'load {HOOK_ADDR:08x} {blob.resolve()}\nword {CALL_SITE:08x} {word:08x}\n')


if __name__ == '__main__':
    main()
