#!/usr/bin/env python3
"""Estimated memory stalls per plugin call on the real BF524, from op1emu's memory model (fork branch memmodel,
OP1EMU_MEMMODEL; model and assumptions in its src/cpu/memmodel.h).

    python3 tools/firmware/perf_mem.py run NAND OUT_DIR --emu OP1EMU [--l1 LO-HI[+...]] [--remap LO-HI:TO[+...]]
        perf_run.py's profiled run with the plugin code (0x01E00000..0x01F00000) interpreted and modelled.
        What-if layouts: --l1 counts address ranges as L1; --remap models [LO, HI) as if placed at TO (another
        SDRAM bank, a write-through page). About 3.5 min.
    python3 tools/firmware/perf_mem.py report OUT_DIR [ELF]
        per plugin render: instructions and estimated stall cycles per call, for the four model variants

Variants: warm = caches kept between calls (only plugin code is traced, so R246's own evictions are missing:
optimistic); cold = caches flushed at the start of every audio block (pessimistic). noalloc / walloc = a data
write miss does or does not allocate a line (not documented in what we have). The truth is between warm and
cold; the cost model is an estimate until it is checked against sysmon on the unit."""
import os, re, statistics, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import perf_calls, perf_scan

VARIANTS = ['warm-noalloc', 'warm-walloc', 'cold-noalloc', 'cold-walloc']
CODE = '1e00000-1f00000'


def run(argv):
    nand, out = argv[1], Path(argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, OP1EMU_MEMMODEL=str(out / 'memmodel.txt'), OP1EMU_INTERP_FIRST=f'4000000000,{CODE}',
               OP1EMU_MEMMODEL_FLUSH=f"{perf_calls_flush_pc(perf_scan.default_elf()):x}")
    if '--l1' in argv:
        env['OP1EMU_MEMMODEL_L1'] = argv[argv.index('--l1') + 1]
    if '--remap' in argv:
        env['OP1EMU_MEMMODEL_REMAP'] = argv[argv.index('--remap') + 1]
    args = [sys.executable, str(HERE / 'perf_run.py'), 'run', nand, str(out), '--emu', argv[argv.index('--emu') + 1]]
    if '--row' in argv:
        args += ['--row', argv[argv.index('--row') + 1]]
    subprocess.run(args, env=env, check=True)
    report(out)


def perf_calls_flush_pc(elf):
    """the sysmon audio wrapper's entry: the start of every audio block"""
    pts = perf_calls.points(elf)
    return next(pc for pc, what in pts.items() if what == 'cb start')


def report(out, elf=None):
    out = Path(out)
    if not elf and (out / 'elf.txt').exists():
        elf = Path((out / 'elf.txt').read_text().strip())
    elf = elf or perf_scan.default_elf()
    funcs, by_addr = perf_scan.parse(perf_scan.tool('bfin-elf-objdump', '-d', elf))
    starts = sorted((f['start'], f['end'], n) for n, f in funcs.items())

    def owner(pc):
        lo, hi = 0, len(starts)
        while lo < hi:
            mid = (lo + hi) // 2
            if starts[mid][0] <= pc:
                lo = mid + 1
            else:
                hi = mid
        if lo and starts[lo - 1][0] <= pc <= starts[lo - 1][1]:
            return starts[lo - 1][2]
        return None

    per = {}        # function -> variant -> [insns, imiss, rmiss, wmiss, victims, stall]
    l1 = remap = ''
    for line in open(out / 'memmodel.txt'):
        if line.startswith('#'):
            if 'L1 what-if ranges:' in line:
                l1 = line.split('ranges:', 1)[1].strip()
            if line.startswith('# remap:'):
                remap = line.split(':', 1)[1].strip()
            continue
        p = line.split()
        fn = owner(int(p[0], 16)) or 'other'
        acc = per.setdefault(fn, {}).setdefault(p[1], [0] * 6)
        for i, v in enumerate(p[2:8]):
            acc[i] += int(v)

    # calls per render entry, from the same run's breaks
    pts = perf_calls.points(elf)
    calls = {}
    hit = re.compile(r'break (0x[0-9a-f]+) hit')
    for line in open(out / 'emu.log', errors='replace'):
        m = hit.search(line)
        if m:
            what = pts.get(int(m.group(1), 16), '')
            if what.startswith('enter '):
                calls[what[6:]] = calls.get(what[6:], 0) + 1

    roots = {k: v for k, v in perf_scan.table_roots(elf, by_addr).items() if k.endswith('.render')}
    reach = {k: perf_scan.reach(funcs, fn)[1] for k, fn in roots.items()}
    shared = {f for k, s in reach.items() for f in s if sum(f in t for t in reach.values()) > 1}
    lines = [f"memory model: {out / 'memmodel.txt'}" + (f'; L1 what-if: {l1}' if l1 else '') +
             (f'; remap: {remap}' if remap else ''),
             'per call: instructions, then estimated stall cycles (and stall as % of the instructions) per variant',
             f"{'render':22} {'calls':>6} {'insns':>8} " + ' '.join(f'{v:>18}' for v in VARIANTS)]
    for label in sorted(roots):
        n = calls.get(label, 0)
        if not n:
            continue
        own = [f for f in reach[label] if f not in shared]
        tot = {v: [sum(per.get(f, {}).get(v, [0] * 6)[i] for f in own) for i in range(6)] for v in VARIANTS}
        insns = tot[VARIANTS[0]][0] / n
        cells = []
        for v in VARIANTS:
            st = tot[v][5] / n
            cells.append(f'{st:9.0f} ({100 * st / insns if insns else 0:4.0f} %)')
        lines.append(f'{label:22} {n:6} {insns:8.0f} ' + ' '.join(f'{c:>18}' for c in cells))
    lines.append('')
    lines.append('misses per call (warm-noalloc / cold-noalloc): instruction, data read, data write; victims')
    for label in sorted(roots):
        n = calls.get(label, 0)
        if not n:
            continue
        own = [f for f in reach[label] if f not in shared]
        row = []
        for v in ('warm-noalloc', 'cold-noalloc'):
            t = [sum(per.get(f, {}).get(v, [0] * 6)[i] for f in own) / n for i in range(6)]
            row.append(f'{t[1]:6.1f} {t[2]:7.1f} {t[3]:7.1f} {t[4]:6.1f}')
        lines.append(f'{label:22} ' + '   |   '.join(row))
    text = '\n'.join(lines) + '\n'
    (out / 'memreport.txt').write_text(text)
    print(text)


def main(argv):
    if len(argv) >= 4 and argv[0] == 'run' and '--emu' in argv:
        run(argv)
    elif len(argv) >= 2 and argv[0] == 'report':
        report(argv[1], Path(argv[2]) if len(argv) > 2 else None)
    else:
        sys.exit(__doc__)


if __name__ == '__main__':
    main(sys.argv[1:])
