/* Cap SQLite's page cache per connection.
 *
 * Stock R246 gives SQLite 3.6.20 a fixed 1.06 MB memsys5 pool, and the page cache (default 2000 pages per
 * connection) keeps every page it has read until the pool is full; then statements fail with SQLITE_NOMEM
 * and the firmware panics in db2.cpp. This hook replaces the CALL to the stock "open all databases" routine
 * inside SQLite init, then sets PRAGMA cache_size on each connection so the cache recycles pages instead.
 * cache_size is per connection and not stored in the database file.
 *
 * Built and placed by sqlite_cache_patch.py; the stock addresses come from its --defsym list. */

void stock_db_open_all(void);                          /* 0x0196f6b4 */
void stock_db_exec(void *conn, const char *sql);       /* 0x0196f950: mutex, prepare, step, finalize; panics on error */

/* Connection objects stored by stock_db_open_all at 0x01bab720 + 4 * slot. */
#define SLOT(i) (((void *const *)0x01bab720)[i])

static const char *const pragma[4] = {
    "PRAGMA cache_size=110",                           /* user/op1.db: settings, presets, sequencer rows */
    "PRAGMA cache_size=60",                            /* content/op1_factory.db: factory presets */
    "PRAGMA cache_size=8",                             /* content/kerntable.db */
    "PRAGMA cache_size=24",                            /* user/tape.db */
};

__attribute__((section(".text.hooks"))) void sqlite_cache_hook(void)
{
    stock_db_open_all();
    for (int i = 0; i < 4; i++)
        if (SLOT(i))
            stock_db_exec(SLOT(i), pragma[i]);
}
