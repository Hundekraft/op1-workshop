"""Isolate optional modules from the pinned #249 archive for pinned op1r builder adapters.

Maiko Pruett's compiled modules are read from a local, hash-checked firmware input.
No complete firmware or device key is distributed. See docs/maiko249-audit.md for
provenance, reverse-engineered boundaries and the validation limits.
"""
SOURCE_SHA256 = 'b7adf5c0fdd523a726e81880e683eda48061a261944dfa1a7a52c57ebfc41066'
IMAGE_ADDRESS = 0x01E40000
IMAGE_SIZE = 222552
BSS_ADDRESS = 0x01E76558
BSS_SIZE = 265996
TABLE = 0x8AF4
MODULE_INDEX = {'undo': 0, 'naming': 1, 'scale': 2, 'files': 3}
UNDO_ADDRESS = 0x02800000
UNDO_SIZE = 0x180000
NAMING_HOOKS = (0x019F0A3C, 0x019AD220, 0x019AD5A6)
# Width includes both pointer words and the queue hook's following instruction.
UNDO_HOOKS = {0x018FC0B0: 8, 0x0191B67E: 4, 0x0191B89C: 4, 0x0191B9F0: 4,
              0x0191C750: 4, 0x01A53EC8: 4, 0x01A54808: 8, 0x01A54842: 4,
              0x01A549A0: 4, 0x01A54AEE: 4}
SHARED_HOOKS = (0x019975F0, 0x019B2690, 0x019C2D3E, 0x019C2E94, 0x019F0A2A)
SCALE_HOOKS = (0x019AC548, 0x019ACA10, 0x019ACDB6)
# Shift shortcuts with Scale mode (workshop issue #1): op1r's Shift+key sequencer shortcuts (C# run/stop, D# mute all,
# mutes, patterns) read the key index that the stock key-down (0x019AC0B0) hands its player, and #249's scale
# wrapper (0x01E450AC) snaps or drops that index first. On bases that export seq_shift_wants(key) (op1r-src
# hk27-base, dispatcher.c), the two key-down sites call this stub instead: with Shift held (0x01DD7F78) it asks
# seq_shift_wants; for a shortcut key it records the raw key in #249's key-up table (0x01E7653C, so #249's key-up
# wrapper releases the same key) and goes straight to the stock key-down. Every other key goes to #249's wrapper,
# so all notes that sound stay in the scale. The key-up site (0x019ACDB6) keeps #249's wrapper.
SCALE_DOWN_HOOKS = SCALE_HOOKS[:2]
# The stub sits in the free tail of op1r's code window, below #249's image (builder checks that op1r's image ends
# before it). At 0x01EB7464, right above #249's state, it worked in the emulator but on the OP-1 it killed all USB
# MIDI input (notes and SysEx) while the unit's own keys still played; the cause there is unknown.
SHIFT_STUB = 0x01E3FF00
SHIFT_STUB_CODE = bytes.fromhex(
    '0832'          # P1 = R0;                      key index
    'ba68'          # P2 = 23 (X);
    '510a'          # CC = P1 <= P2 (IU);
    '1e10'          # IF !CC JUMP maiko;            not a keyboard key
    '4ae1dd01'      # P2.H = 0x01DD;
    '0ae1787f'      # P2.L = 0x7F78;                Shift flag
    '1299'          # R2 = B[P2] (Z);
    '020c'          # CC = R2 == 0;
    '1718'          # IF CC JUMP maiko;
    '00e80500'      # LINK 20;                      RETS, key, flag, 12-byte argument area
    'f0bb'          # [FP - 4] = R0;
    'e1bb'          # [FP - 8] = R1;
    '00e30000'      # CALL seq_shift_wants          (SHIFT_STUB + 0x1E)
    '1030'          # R2 = R0;
    'f0b9'          # R0 = [FP - 4];
    'e1b9'          # R1 = [FP - 8];
    '01e80000'      # UNLINK;
    '020c'          # CC = R2 == 0;
    '0a18'          # IF CC JUMP maiko;             Shift + key is no shortcut: snap as usual
    '0832'          # P1 = R0;
    '4ae1e701'      # P2.H = 0x01E7;
    '0ae13c65'      # P2.L = 0x653C;                #249 key-up table
    '8a5a'          # P2 = P2 + P1;
    '109b'          # B[P2] = R0;
    '00e20000'      # JUMP.L stock key-down         (SHIFT_STUB + 0x3E)
    '00e20000'      # maiko: JUMP.L #249 wrapper    (SHIFT_STUB + 0x42)
    '0000')         # pad to 4
SHIFT_STUB_WANTS = 0x1E
SHIFT_STUB_STOCK = 0x3E
SHIFT_STUB_MAIKO = 0x42
SCALE_DOWN = (0x019AC0B0, 0x01E450AC)                    # stock key-down, #249 snapping wrapper
CHAINS = ((0x019C2D3E, 0x01E4064A, 0x01E01598),
          (0x019C2E94, 0x01E406AE, 0x01E01D98))
# Tape erase (audio_clipboard::service case 4, CALL 0x01A54B08 at 0x0191B9F0): #249's undo wrapper (0x01E44134)
# marks the erase for its history and ends with JUMP.L 0x01A54B08 at 0x01E44172. op1r 28+ calls its fast erase
# (fast_tape_erase, void) from the same site; with undo the wrapper keeps the site and jumps to op1r's function.
ERASE_CHAIN = (0x0191B9F0, 0x01E44172, 0x01A54B08)
OP1R_CODE = (0x01E00000, 0x01E40000)


def apply(ldr, source_ldr, original_ldr, features, M, R, chains=None, shift_wants=None):
    """shift_wants: address of the base's seq_shift_wants (op1r code), or None: Scale mode without the Shift stub."""
    if not features:
        return ldr
    if len(set(features)) != len(features) or set(features) - set(MODULE_INDEX):
        raise ValueError('Unknown or duplicate #249 utility')
    blocks = M.ldr_blocks(ldr)
    source_blocks = M.ldr_blocks(source_ldr)
    original_blocks = M.ldr_blocks(original_ldr)
    candidates = [(o, n) for o, flags, a, n, arg in source_blocks
                  if a == IMAGE_ADDRESS and flags & 0xffff == 6]
    if len(candidates) != 1 or candidates[0][1] != IMAGE_SIZE:
        raise ValueError('Unexpected #249 module image')
    off, size = candidates[0]
    image = bytearray(source_ldr[off + 16:off + 16 + size])
    regions = [(IMAGE_ADDRESS, BSS_ADDRESS + BSS_SIZE)]
    stub = 'scale' in features and shift_wants is not None
    if stub:
        if not OP1R_CODE[0] <= shift_wants < OP1R_CODE[1]:
            raise ValueError('seq_shift_wants is outside op1r code: ' + hex(shift_wants))
        regions.append((SHIFT_STUB, SHIFT_STUB + len(SHIFT_STUB_CODE)))
    if 'undo' in features:
        regions.append((UNDO_ADDRESS, UNDO_ADDRESS + UNDO_SIZE))
    for o, flags, address, count, arg in blocks:
        if count and not flags & 0x1000 and any(address < end and address + count > start for start, end in regions):
            raise ValueError('#249 module memory overlaps an existing LDR region')
    records = b''.join(image[TABLE + MODULE_INDEX[f] * 32:TABLE + (MODULE_INDEX[f] + 1) * 32]
                       for f in MODULE_INDEX if f in features)
    image[TABLE:TABLE + 160] = records + bytes(160 - len(records))
    # #249's two shared input dispatchers originally tail-called op1r 12.
    # Require the selected adapter targets, then preserve that input chain.
    for hook, chain, expected in (CHAINS if chains is None else chains):
        at = M.ldr_word(ldr, blocks, hook)
        target = M.jump_l_target(hook, ldr[at:at + 4], 0xE300)
        if target != expected:
            raise ValueError('Unexpected op1r input target at ' + hex(hook))
        image[chain - IMAGE_ADDRESS:chain - IMAGE_ADDRESS + 4] = M.jump_l(chain, target)
    chained = {c[0] for c in (CHAINS if chains is None else chains)}
    if 'undo' in features:
        hook, chain, stock = ERASE_CHAIN
        at = M.ldr_word(ldr, blocks, hook)
        old = M.ldr_word(original_ldr, original_blocks, hook)
        if ldr[at:at + 4] != original_ldr[old:old + 4]:
            target = M.jump_l_target(hook, ldr[at:at + 4], 0xE300)
            if not OP1R_CODE[0] <= target < OP1R_CODE[1]:
                raise ValueError('Unexpected tape erase hook at ' + hex(hook))
            if M.jump_l_target(chain, bytes(image[chain - IMAGE_ADDRESS:chain - IMAGE_ADDRESS + 4]), 0xE200) != stock:
                raise ValueError('Unexpected #249 erase wrapper')
            image[chain - IMAGE_ADDRESS:chain - IMAGE_ADDRESS + 4] = M.jump_l(chain, target)
            chained.add(hook)
    hooks = dict.fromkeys(SHARED_HOOKS, 4)
    if 'scale' in features:
        hooks.update(dict.fromkeys(SCALE_HOOKS, 4))
    if 'naming' in features:
        hooks.update(dict.fromkeys(NAMING_HOOKS, 4))
    if 'undo' in features:
        hooks.update(UNDO_HOOKS)
    for hook, width in hooks.items():
        at = M.ldr_word(ldr, blocks, hook)
        src = M.ldr_word(source_ldr, source_blocks, hook)
        if hook not in chained:
            old = M.ldr_word(original_ldr, original_blocks, hook)
            if ldr[at:at + width] != original_ldr[old:old + width]:
                raise ValueError('Unexpected utility hook bytes at ' + hex(hook))
        ldr = ldr[:at] + source_ldr[src:src + width] + ldr[at + width:]
    added = (M.header(6, IMAGE_ADDRESS, len(image), 0) + image
             + M.header(0x106, BSS_ADDRESS, BSS_SIZE, 0))
    if stub:
        code = bytearray(SHIFT_STUB_CODE)
        for hook in SCALE_DOWN_HOOKS:
            old = M.ldr_word(original_ldr, original_blocks, hook)
            src = M.ldr_word(source_ldr, source_blocks, hook)
            if (M.jump_l_target(hook, original_ldr[old:old + 4], 0xE300),
                    M.jump_l_target(hook, source_ldr[src:src + 4], 0xE300)) != SCALE_DOWN:
                raise ValueError('Unexpected #249 scale key-down hook at ' + hex(hook))
            at = M.ldr_word(ldr, blocks, hook)
            ldr = ldr[:at] + M.call_l(hook, SHIFT_STUB) + ldr[at + 4:]
        code[SHIFT_STUB_WANTS:SHIFT_STUB_WANTS + 4] = M.call_l(SHIFT_STUB + SHIFT_STUB_WANTS, shift_wants)
        for offset, target in ((SHIFT_STUB_STOCK, SCALE_DOWN[0]), (SHIFT_STUB_MAIKO, SCALE_DOWN[1])):
            code[offset:offset + 4] = M.jump_l(SHIFT_STUB + offset, target)
        added += M.header(6, SHIFT_STUB, len(code), 0) + code
    if 'undo' in features:
        added += M.header(0x106, UNDO_ADDRESS, UNDO_SIZE, 0)
    final = next(o for o, flags, a, n, arg in blocks if flags & 0x8000)
    result = M.fix_first_header(ldr[:final] + added + ldr[final:])
    R.validate_ldr(result)
    return result
