#!/usr/bin/env python3
"""Static audio-path scan of op1r's code image (synth.elf with our plugins): which libgcc helpers each audio entry
point can reach, how often they are called, and whether a call sits inside a loop.

    python3 tools/firmware/perf_scan.py [ELF] [--json OUT]

ELF defaults to the most recently built op1r-plugins base under build/configurator (builder.py makes it).
Roots are every plugin's note_on/render/note_off (ENGINE_*), every FX's init/render (FX_*) and the dispatcher's own
audio-time functions (AUDIO_ROOTS). Calls are followed through direct CALL/JUMP.L/JUMP.S targets only; indirect calls
(CALL (Pn)) are counted, not followed. A call is "in a loop" when it lies inside an LSETUP range or under a
backward branch of the same function. This is a static map, not a cost measurement."""
import json, re, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BINUTILS = ROOT / 'toolchain/bfin/bin'

# libgcc software helpers: 32-bit divide/modulo, 64-bit arithmetic, float/double emulation
HELPER = re.compile(r'^___(?:u?(?:div|mod)[sd]i3|u?muldi3|[a-z]+[sd]f[0-9]|float\w*|fix\w*|(?:un)?pack_[df]|'
                    r'clz[sd]i2|ashl|ashr|lshr|cmp[sd]f2)')
# op1r dispatcher functions that run in the audio callback (besides the plugin tables); see synth_sdk/dispatcher.c
AUDIO_ROOTS = ['_synth_render', '_fx_render', '_fx_render_stereo', '_ql_apply_synth', '_ql_apply_fx',
               '_ql_apply_drum', '_sm_audio_cb', '_ci_metro_render', '_pu_block', '_se_ac_apply', '_se_fade_apply']

LINE = re.compile(r'^\s*([0-9a-f]+):\s+(?:[0-9a-f]{2} )+\s*(.*)$')
FUNC = re.compile(r'^([0-9a-f]+) <([^>]+)>:$')
BR = re.compile(r'(CALL|JUMP\.[LS]|JUMP|IF !?CC JUMP) 0x([0-9a-f]+)')
LSETUP = re.compile(r'LSETUP\(0x([0-9a-f]+)[^,]*, 0x([0-9a-f]+)')


def default_elf():
    """the most recently built op1r-plugins base (base_key depends on how the firmware path is spelled, so it is
    not recomputed here); printed to stderr"""
    elfs = sorted((ROOT / 'build/configurator').glob('op1r-plugins-*/synth_sdk/build/synth.elf'),
                  key=lambda p: p.stat().st_mtime)
    if not elfs:
        sys.exit('no op1r-plugins base under build/configurator: run builder.py build --base op1r27-plugins first')
    print(f'ELF {elfs[-1].relative_to(ROOT)}', file=sys.stderr)
    return elfs[-1]


def tool(name, *args):
    return subprocess.run([str(BINUTILS / name), *map(str, args)], capture_output=True, text=True, check=True).stdout


def parse(dis):
    """{name: {'start', 'end', 'calls': [(addr, kind, target)], 'icalls': [addr], 'loops': [(lo, hi)]}}, {start: name}.
    Static functions of different plugins share names (_render, _init): later ones are named NAME@ADDR."""
    funcs, cur, by_addr = {}, None, {}
    for line in dis.splitlines():
        m = FUNC.match(line)
        if m:
            start, name = int(m.group(1), 16), m.group(2)
            if name in funcs:
                name = f'{name}@{start:x}'
            cur = funcs[name] = {'start': start, 'end': start, 'calls': [], 'icalls': [], 'loops': []}
            by_addr[start] = name
            continue
        m = LINE.match(line)
        if not m or cur is None:
            continue
        addr, text = int(m.group(1), 16), m.group(2)
        cur['end'] = max(cur['end'], addr)
        for kind, tgt in BR.findall(text):
            tgt = int(tgt, 16)
            cur['calls'].append((addr, kind, tgt))
            if kind != 'CALL' and cur['start'] <= tgt < addr:
                cur['loops'].append((tgt, addr))
        if re.search(r'CALL \(P\d\)', text):
            cur['icalls'].append(addr)
        m = LSETUP.search(text)
        if m:
            cur['loops'].append((int(m.group(1), 16), int(m.group(2), 16)))
    # resolve targets to names; branches that stay inside the function are local, not calls
    for name, f in funcs.items():
        out = []
        for addr, kind, tgt in f['calls']:
            t = by_addr.get(tgt)
            if t and t != name:
                out.append((addr, kind, t))
        f['calls'] = out
    return funcs, by_addr


def table_roots(elf, by_addr):
    """note_on/render/note_off of ENGINE_* and init/render of FX_*, read from the ELF's data words"""
    syms = {}
    for line in tool('bfin-elf-nm', elf).splitlines():
        p = line.split()
        if len(p) == 3:
            syms[p[2]] = int(p[0], 16)
    roots = {}
    for sym, fields in [(s, ('note_on', 'render', 'note_off')) for s in syms if s.startswith('_ENGINE_')] + \
                       [(s, ('init', 'render')) for s in syms if s.startswith('_FX_')]:
        a = syms[sym]
        dump = tool('bfin-elf-objdump', '-s', f'--start-address={a}', f'--stop-address={a + 4 * len(fields)}', elf)
        data = b''.join(bytes.fromhex(''.join(l.strip().split('  ')[0].split()[1:])) for l in dump.splitlines()
                        if re.match(r'^\s+[0-9a-f]+ [0-9a-f]', l))
        for i, field in enumerate(fields):
            ptr = int.from_bytes(data[4 * i:4 * i + 4], 'little')
            if ptr and ptr in by_addr:
                roots[f'{sym[1:]}.{field}'] = by_addr[ptr]
    return roots


def in_loop(f, addr):
    return any(lo <= addr <= hi for lo, hi in f['loops'])


def reach(funcs, root):
    """helpers reachable from root: {helper: [(caller, addr, in_loop)]}, plus visited functions and indirect calls"""
    seen, stack, hits, icalls = set(), [root], {}, []
    while stack:
        n = stack.pop()
        if n in seen or n not in funcs:
            continue
        seen.add(n)
        f = funcs[n]
        icalls += [(n, a) for a in f['icalls']]
        for addr, _, t in f['calls']:
            if HELPER.match(t):
                hits.setdefault(t, []).append((n, addr, in_loop(f, addr)))
            else:
                stack.append(t)
    return hits, seen, icalls


def scan(elf):
    funcs, by_addr = parse(tool('bfin-elf-objdump', '-d', elf))
    roots = table_roots(elf, by_addr)
    roots.update({n[1:]: n for n in AUDIO_ROOTS if n in funcs})
    report = {}
    for label, fn in sorted(roots.items()):
        hits, seen, icalls = reach(funcs, fn)
        report[label] = {
            'function': fn,
            'reached': len(seen),
            'code_bytes': sum(funcs[n]['end'] - funcs[n]['start'] for n in seen),
            'indirect_calls': [f'{n}+{a - funcs[n]["start"]:#x}' for n, a in icalls],
            'helpers': {h: [{'caller': c, 'offset': a - funcs[c]['start'], 'in_loop': l} for c, a, l in sites]
                        for h, sites in sorted(hits.items())},
        }
    return report


def main(argv):
    args = [a for a in argv if not a.startswith('--')]
    out = argv[argv.index('--json') + 1] if '--json' in argv else None
    if out:
        args.remove(out)
    elf = Path(args[0]) if args else default_elf()
    report = scan(elf)
    if out:
        Path(out).write_text(json.dumps({'elf': str(elf), 'roots': report}, indent=1) + '\n')
    for label, r in report.items():
        loops = sum(s['in_loop'] for v in r['helpers'].values() for s in v)
        print(f"{label:28} {r['function']:26} funcs {r['reached']:3}  bytes {r['code_bytes']:6}  "
              f"icalls {len(r['indirect_calls']):2}  helper sites {sum(map(len, r['helpers'].values())):3} "
              f"(in loop {loops})")
        for h, sites in r['helpers'].items():
            where = ', '.join(sorted({f"{s['caller']}+{s['offset']:#x}{'*' if s['in_loop'] else ''}" for s in sites}))
            print(f"    {h:14} {where}")


if __name__ == '__main__':
    main(sys.argv[1:])
