#!/usr/bin/env python3
"""Compile selected additions, build R246 firmware, or prepare a static web release."""
import argparse
import copy
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sqlite3
import struct
import subprocess
import sys
import tempfile
import zipfile

import runtime as R
import maiko249 as U
import op1r_plugins as PLUG
import sqlite_cache_patch as SQLC
from profiles import BASES, RELEASED_BASE

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CATALOG = json.loads((HERE / 'catalog.json').read_text())
# These utilities are available to native builds only.
PRIVATE_UTILITIES = {'naming', 'undo'}
OP1R_COMMIT = BASES[RELEASED_BASE]['commit']
WORK = ROOT / 'build/configurator'
GCC = ROOT / 'toolchain/bfin-gcc/bin/bfin-elf-gcc'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


M = module('mkfw', ROOT / 'tools/engines/mkfw.py')
PRESETS = module('op1r_presets', ROOT / 'tools/op1r_presets.py')
PRESET_POLISH = module('kennel_preset_polish', ROOT / 'tools/presets/polish.py')
PRESET_VARIATION = module('kennel_preset_variation', ROOT / 'tools/presets/variation.py')


def json_write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def run(args):
    subprocess.run([str(x) for x in args], check=True, capture_output=True)


def all_configs(catalog=CATALOG):
    for mask in range(1 << (7 + len(catalog['utilities']))):
        if (300 if mask & 64 else 100) not in catalog['preset_caps']:
            continue                           # kennel bases: 300 presets only
        yield {'schema': 1, 'base': catalog['base'],
               'synths': [f['id'] for i, f in enumerate(catalog['synths']) if mask & (1 << i)],
               'effects': [f['id'] for i, f in enumerate(catalog['effects']) if mask & (1 << (i + 4))],
               'preset_cap': 300 if mask & 64 else 100,
               **({'utilities': [f['id'] for i, f in enumerate(catalog['utilities']) if mask & (128 << i)]}
                  if mask >> 7 else {})}


def public_catalog(catalog=CATALOG):
    catalog = copy.deepcopy(catalog)
    catalog['utilities'] = [f for f in catalog['utilities'] if f['id'] not in PRIVATE_UTILITIES]
    return catalog


def public_configs(catalog=CATALOG):
    for config in all_configs(catalog):
        if not PRIVATE_UTILITIES.intersection(config.get('utilities', [])):
            # Removing pending trailing bits must never renumber released variants.
            require(R.config_id(config, catalog) == R.config_id(config, public_catalog(catalog)),
                    'Release catalog would renumber existing configurations')
            yield config


def release_identity(base, profile=None):
    profile = BASES[RELEASED_BASE] if profile is None else profile
    paths = sorted([HERE / 'builder.py', HERE / 'runtime.py', HERE / 'catalog.json', HERE / 'maiko249.py', HERE / 'profiles.py',
                    HERE / 'sqlite_cache_patch.py', HERE / 'sqlite_cache_hook.c', HERE / 'op1r_plugins.py',
                    * (ROOT / 'tools/engines').rglob('*.c'),
                    * (ROOT / 'tools/engines').rglob('*.h'),
                    ROOT / 'tools/engines/engine.ld', ROOT / 'tools/engines/mkfw.py', ROOT / 'tools/op1r_presets.py',
                    * (ROOT / 'tools/fx').rglob('*.c'), * (ROOT / 'tools/fx').rglob('*.h'),
                    * (ROOT / 'tools/engines').rglob('*.svg'), * (ROOT / 'tools/fx').rglob('*.svg')])
    # A release can change without DSP edits: web assets, product version and preset authorship matter too.
    paths += [HERE / 'release.py', ROOT / 'tools/presets/polish.py', ROOT / 'tools/presets/variation.py']
    paths += [p for p in (ROOT / 'web/firmware').iterdir() if p.is_file()]
    if profile.get('kennel'):
        paths += list((ROOT / profile['source'] / 'synth_sdk/plugins').glob('*/presets/*.aif'))
        # Core/plugin changes must change release identity too, including fresh local
        # candidates. Do not hash generated output, harnesses or source archives.
        for subtree in ('synth_sdk', 'tools/kennel'):
            root = ROOT / profile['source'] / subtree
            paths += [p for p in root.rglob('*') if p.is_file()
                      and not {'build', 'out', '__pycache__', 'harness', '.git'}.intersection(p.relative_to(root).parts)
                      and not p.name.startswith('test_')
                      and p.suffix in ('.c', '.h', '.S', '.ld', '.json', '.svg', '.aif', '.py', '.inc')]

    paths = sorted(set(paths))
    content = b''.join(str(p.relative_to(ROOT)).encode() + b'\0' + p.read_bytes() for p in paths)
    version = subprocess.check_output([str(GCC), '--version'])
    return {'id': R.sha256(content + version + json.dumps({'base': base, 'product': R.PRODUCT}, sort_keys=True).encode())[:16],
            'product': dict(R.PRODUCT), 'op1r_commit': profile['commit'], 'experimental': profile['experimental'], 'compiler': version.decode().splitlines()[0]}


def boot_text(config, version, kennel=False):
    """Boot screen text under the TE logo: the product, then what it is built on. Each line starts at the left edge
    and is centred with spaces (30 spaces centre the 14-character label; the font is about one space per character).
    The boot font has no '&' (it draws another glyph), so '+' joins the names."""
    feat = 'feat. op1r ' + version + (' + maiko #249' if config.get('utilities') else '')
    lines = [R.PRODUCT['label']] if kennel else [R.PRODUCT['label'], feat]   # kennel: the product alone
    return '\n' * 17 + '\n'.join(' ' * max(0, round(37 - len(line) / 2)) + line for line in lines)


class Builder:
    def __init__(self, firmware, base=RELEASED_BASE):
        if base not in BASES:
            raise ValueError('Unsupported base bundle: ' + base)
        self.profile = BASES[base]
        self.catalog = copy.deepcopy(CATALOG)
        self.catalog['base'] = base
        # op1r plugins only some bases have (catalog 'bases'); they sit at the end, so the others keep their bits
        listed = {base, self.profile.get('catalog_base', base)}
        self.catalog['op1r_plugins'] = [f for f in self.catalog.get('op1r_plugins', [])
                                        if listed & set(f.get('bases', listed))]
        for f in self.catalog['utilities']:        # kennel bases rebuild Maiko's tools; some work differently there
            text = f.pop('kennel_description', None)
            if text and self.profile.get('kennel'):
                f['description'] = text
        self.upstream = ROOT / self.profile['directory']
        upstream = self.upstream
        expected_commit = self.profile['commit']
        if not (upstream / 'data/manifest.json').is_file():
            raise ValueError('Clone op1r into ' + str(upstream) + ' at ' + expected_commit)
        commit = subprocess.check_output(['git', '-C', str(upstream), 'rev-parse', 'HEAD'], text=True).strip()
        if commit != expected_commit:
            raise ValueError('Expected pinned op1r commit ' + expected_commit)
        if subprocess.check_output(['git', '-C', str(upstream), 'status', '--porcelain', '--', 'data']):
            raise ValueError('op1r patch data has local changes; use the pinned release')
        self.base_dir = upstream / 'data'
        self.utility_chains = self.profile['utility_chains']
        self.shift_wants = None                    # seq_shift_wants in the base (Scale-mode Shift shortcuts)
        self.generated = None                      # the generated plugin base (op1r_plugins.cached_base)
        if self.profile.get('plugins'):
            # op1r-src with our engines compiled in: generated (and cached) from the pinned source.
            source = ROOT / self.profile['source']
            if subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() != \
                    self.profile['source_commit']:
                raise ValueError('Expected pinned op1r-src commit ' + self.profile['source_commit'])
            PLUG.select(self.profile)
            generated = self.generated = PLUG.cached_base(firmware, WORK)
            self.base_dir = generated / 'patcher/data'
            meta = json.loads((generated / 'base.json').read_text())
            require(not meta['ours_in_db'], 'Generated base must not list our engines')
            self.utility_chains = tuple(tuple(int(x, 16) for x in c) for c in meta['utility_chains'])
            self.shift_wants = int(meta['seq_shift_wants'], 16) if meta.get('seq_shift_wants') else None
            # the Scale-mode Shift stub lives in the free tail of op1r's code window
            require(not self.shift_wants or int(meta['image_end'], 16) <= U.SHIFT_STUB, 'op1r image runs into the Shift stub')
            if self.profile.get('kennel'):
                self.kennel_choices()
        self.base = json.loads((self.base_dir / 'manifest.json').read_text())
        self.op1 = Path(firmware).read_bytes()
        R.checked(self.op1, self.base['original']['sha256'], 'Original R246')
        self.original = R.unpack(self.op1)
        self.members = R.apply_manifest(self.original, self.base, lambda name: (self.base_dir / name).read_bytes())
        self.release = release_identity(self.base, self.profile)
        self.cache = WORK / self.release['id']
        self.cache.mkdir(parents=True, exist_ok=True)
        self.cf = ['-mcpu=bf524', '-O2', '-ffreestanding', '-fno-builtin', '-Wall', '-Wextra',
                   '-I', str(ROOT / 'tools/engines'), '-I', str(ROOT / 'tools/fx')]
        sys.path.insert(0, str(upstream))
        self.diff = module('op1r_diff', upstream / 'build_patch.py')

    def kennel_choices(self):
        """Kennel bases: every catalog choice is a kennel plugin file, content/<id>.knl (kennel's naming rule), chosen
        per build (runtime.file_choices); only settings is compiled into the core and it isn't a choice. 'needs' lists
        other choices it can't work without (none today: a plugin imports core exports only).
        On kennel bases op1r_plugins holds every file choice beyond synths / effects / utilities. Entries the catalog
        marks 'always' (the standard set: tape tools, sequencers, drum+, MIDI, pages) ship their file in every
        build and have no box; a configuration that hides one is refused (runtime.normalize)."""
        plugins = ROOT / self.profile['source'] / 'synth_sdk/plugins'
        meta = json.loads((self.generated / 'base.json').read_text())
        if meta.get('lander_flag'):
            self.catalog['core_options'] = [{'id': 'lander', 'bit': 64, 'default': False}]
            self.lander_flag = int(meta['lander_flag'], 16)
        self.catalog['preset_caps'] = [300]        # 300 presets is the baseline on kennel bases (no 100 option)
        for group in ('synths', 'effects', 'utilities', 'op1r_plugins'):
            for f in self.catalog[group]:          # groups: one choice shipping several files ('files', runtime.entry_files)
                for name in f.get('files', []):
                    require((self.generated / 'files' / name).is_file() and R.path_ok('content/' + name),
                            f'{f["id"]}: no plugin file {name} that the SysEx update can send')
        for group in ('synths', 'effects', 'utilities', 'op1r_plugins'):
            for f in self.catalog[group]:
                if f.get('reserved'):
                    continue                       # a removed plugin's bit, kept so the later bits stay put
                kid = PLUG.KENNEL_UTILITY.get(f['id'], f['id']) if group == 'utilities' else f['id'].replace(' ', '_')
                path = plugins / kid / 'plugin.json'
                require(path.is_file(), f'{f["id"]}: kennel has no plugin {kid}')
                meta = json.loads(path.read_text())
                require(meta['name'] == kid, f'kennel plugin {kid}: plugin.json name {meta["name"]} is not its id')
                saved = meta.get('saved_name', kid.replace('_', ' '))
                if group != 'utilities':           # a catalog id is either the kennel id or its saved name
                    require(f['id'] in (kid, saved), f'{f["id"]}: kennel names it {kid} / {saved!r}')
                require(meta.get('loadable'), f'kennel plugin {kid} is compiled into the core, not a file')
                f['file'] = kid + '.knl'           # the naming rule: <id>.knl, nothing else
                require((self.generated / 'files' / f['file']).is_file(), 'Kennel base lacks ' + f['file'])
                require(R.path_ok('content/' + f['file']), 'Plugin file name the SysEx update cannot send: ' + f['file'])
                f['needs'] = []
                if kid != f['id'] or saved != kid:
                    f['saved'] = saved             # saved sounds and the DB name it so (runtime.saved_name)
                f['id'] = kid

    def compile(self, config):
        # Variants share module/host objects as well as the final ELF. Lock the
        # whole release cache, not just a config, and publish only complete files.
        with (self.cache / '.compile.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            return self._compile_locked(config)

    def _compile_object(self, args, destination):
        temporary = destination.with_suffix('.tmp.o')
        run([*args, '-o', temporary])
        temporary.replace(destination)

    def _compile_locked(self, config):
        ident = R.config_id({k: v for k, v in config.items() if k not in ('utilities', 'hidden')}, self.catalog)
        elf = self.cache / (ident + '.elf')
        if elf.exists():
            return M.elf_image(str(elf))
        objects, rows, declarations = [], {'synths': [], 'effects': []}, []
        for group in rows:
            for feature in self.catalog[group]:
                name, marker = feature['id'], feature['marker']
                if name not in config[group]:
                    continue
                fx = group == 'effects'
                prefix = name + ('_fx' if fx else '')
                renames = ({'fx_reset': prefix + '_reset', 'fx_process': prefix + '_process'} if fx else
                           {'engine_' + f: prefix + '_' + f for f in ('note_on', 'render', 'note_off')})
                renames.update({'engine_screen_' + f: prefix + '_screen_' + f for f in ('load', 'animate', 'draw')})
                directory = ROOT / 'tools' / ('fx' if fx else 'engines') / name
                for source in sorted(directory.glob('*.c')):
                    obj = self.cache / (prefix + '_' + source.stem + '.o')
                    if not obj.exists():
                        self._compile_object([GCC, *self.cf, *['-D' + k + '=' + v for k, v in renames.items()],
                                              '-c', source], obj)
                    objects.append(obj)
                if fx:
                    declarations.extend([f'void {prefix}_reset(int);',
                                         f'void {prefix}_process(int,int16_t*,int,const int16_t*);'])
                    callbacks = f'{prefix}_reset,{prefix}_process'
                else:
                    declarations.extend([f'void {prefix}_note_on(void*,const int16_t*);',
                                         f'void {prefix}_render(void*,int16_t*,const int16_t*);',
                                         f'void {prefix}_note_off(void*,const int16_t*);'])
                    callbacks = f'{prefix}_note_on,{prefix}_render,{prefix}_note_off'
                for method in ('load', 'animate', 'draw'):
                    params = 'void*s,void*c' if method == 'draw' else 'void*s'
                    body = '(void)s;(void)c;' if method == 'draw' else '(void)s;'
                    declarations.append(f'__attribute__((weak)) void {prefix}_screen_{method}({params}){{{body}}}')
                rows[group].append(f'{{{marker},"{name}","{name}.svg",{callbacks},'
                                   f'{prefix}_screen_load,{prefix}_screen_animate,{prefix}_screen_draw}}')
        table = self.cache / (ident + '.c')
        text = '#include "op1r_engines.h"\n' + '\n'.join(declarations) + '\n'
        for group, typ, sym in [('synths', 'op1r_engine', 'op1r_engines'), ('effects', 'op1r_fx', 'op1r_fxs')]:
            count = 'op1r_engine_count' if group == 'synths' else 'op1r_fx_count'
            text += f'const {typ} {sym}[]={{' + ','.join(rows[group] + ['{0}']) + '};\n'
            text += f'const int {count}={len(rows[group])};\n'
        table.write_text(text)
        host = self.cache / f'host-{config["preset_cap"]}.o'
        if not host.exists():
            self._compile_object([GCC, *self.cf, f'-DOP1R_USER_SYNTH_PRESETS={config["preset_cap"]}',
                                  f'-DOP1R_VERSION="{self.profile["version"]}"', '-c',
                                  ROOT / 'tools/engines/op1r_host.c'], host)
        temp_elf = elf.with_suffix('.tmp.elf')
        run([GCC, *self.cf, '-nostdlib', '-T', ROOT / 'tools/engines/engine.ld',
             host, table, *objects, '-lgcc', '-o', temp_elf])
        temp_elf.replace(elf)
        return M.elf_image(str(elf))

    def configured_members(self, config):
        config = R.normalize(config, self.catalog)
        members, sizes = self._configured_members(R.variant_config(config, self.catalog))
        # as runtime.patch in the browser: plugin files not chosen are left out, hidden op1r plugins without a
        # file lose their picker rows
        choices = R.file_choices(self.catalog)
        drop = {'content/' + n for n in R.files(R.variant_config(config, self.catalog), self.catalog) - R.files(config, self.catalog)}
        members = [(m, d) for m, d in members if m.name not in drop]
        members = R.apply_hidden(members, self.catalog, [h for h in config.get('hidden', []) if h not in choices],
                                 R.left_out_rows(config, self.catalog) if choices else [])
        idx = next(i for i, (m, _) in enumerate(members) if m.name == 'OP1_vdk.ldr')
        ldr = members[idx][1]
        blocks = M.ldr_blocks(ldr)
        if hasattr(self, 'lander_flag'):
            at = M.ldr_word(ldr, blocks, self.lander_flag)
            require(ldr[at:at + 4] == bytes(4), 'Unexpected Lander build-option word')
            ldr = ldr[:at] + struct.pack('<I', int(config.get('lander', False))) + ldr[at + 4:]
        # Dedicated read-only banner range, outside upstream, Maiko and Workshop images.
        address = 0x01EF0000
        banner = boot_text(config, self.profile['version'], self.profile.get('kennel')).encode('ascii') + b'\0'
        banner += bytes((-len(banner)) % 4)
        for _, flags, start, count, _ in blocks:
            require(not count or flags & 0x1000 or start + count <= address or start >= address + len(banner),
                    'Boot branding overlaps an existing load region')
        for offset, opcode, word in ((0, b'\x00\xe1', address & 65535), (4, b'\x40\xe1', address >> 16)):
            at = M.ldr_word(ldr, blocks, M.BOOT_TEXT + offset)
            require(ldr[at:at + 2] == opcode, 'Unexpected boot text instruction')
            ldr = ldr[:at + 2] + struct.pack('<H', word) + ldr[at + 4:]
        final = next(o for o, flags, _, _, _ in blocks if flags & 0x8000)
        ldr = M.fix_first_header(ldr[:final] + M.header(6, address, len(banner), 0) + banner + ldr[final:])
        # SQLite page-cache cap (2.1): stops the fixed SQLite pool from filling (Dots/Euclid db2.cpp panics).
        # op1r 27 and later patch the same call site with the same cap; keep theirs.
        if self.profile.get('sqlite_cache_cap'):
            at = M.ldr_word(ldr, M.ldr_blocks(ldr), SQLC.CALL_SITE)
            require(ldr[at:at + 4] != SQLC.STOCK_CALL, 'Base is expected to cap the SQLite page cache')
        else:
            if not hasattr(self, 'sqlite_cache_hook'):
                with tempfile.TemporaryDirectory() as td:
                    self.sqlite_cache_hook = SQLC.build_hook(Path(td))
            ldr = SQLC.patch_ldr(ldr, self.sqlite_cache_hook)
        members[idx] = (members[idx][0], ldr)
        return members, {**sizes, 'branding_bytes': len(banner), 'branding_address': hex(address)}

    def _configured_members(self, config):
        config = R.normalize(config, self.catalog)
        if (not config['synths'] and not config['effects'] and config['preset_cap'] == 100
                and not self.profile.get('plugins')):
            return self.utilities(list(self.members), config, {'image_bytes': 0, 'memory_bytes': 0})
        members = list(self.members)
        idx = {m.name: i for i, (m, _) in enumerate(members)}
        i = idx['OP1_vdk.ldr']
        if self.profile.get('plugins'):
            # Every engine's code is in the base; a choice is its DB row and screen. 300 presets: one fill block.
            ldr = members[i][1]
            if config['preset_cap'] == 300:
                ldr = PLUG.preset_cap(ldr, 300)
            members[i] = (members[i][0], ldr)
            sizes = {'image_bytes': 0, 'memory_bytes': (169 + 33 + 300 + 16) * 56 if config['preset_cap'] == 300 else 0}
        else:
            load, image, syms = self.compile(config)
            ldr, image = M.patch_ldr_op1r(members[i][1], image, load, syms)
            members[i] = (members[i][0], ldr)
            sizes = {'image_bytes': len(image), 'memory_bytes': syms['_memory_end'] - load}
        i = idx['content/op1_factory.db']
        db = members[i][1]
        for feature in self.catalog['synths']:
            if feature['id'] in config['synths'] and not feature.get('file'):
                db = M.patch_db_op1r(db, feature['id'], [16384, 8192, 0, 8192, feature['marker'], 0, 0, 0])
        for feature in self.catalog['effects']:
            if feature['id'] in config['effects'] and not feature.get('file'):
                db = M.patch_db_fx(db, feature['id'], feature['marker'])
        members[i] = (members[i][0], db)
        for group, directory in [('synths', 'engines'), ('effects', 'fx')]:
            # Plugin bases load every compiled-in plugin's screen at boot and halt on a missing SVG
            # (Parser.cpp:162), so all of them ship; the DB row alone decides what is listed.
            names = [f['id'] for f in self.catalog[group]] if self.profile.get('plugins') else config[group]
            for name in [n for n in names if not any(f['id'] == n and f.get('file') for f in self.catalog[group])]:
                info = copy.copy(members[idx['content/display/iter.svg']][0])
                info.name = f'content/display/{name}.svg'
                path = ROOT / 'tools' / directory / name / (name + '.svg')
                data = M.svg_with_bases(path.read_bytes(), path.relative_to(ROOT))
                members.append((info, data))
        return self.utilities(members, config, sizes)

    def plugin_files(self, members, config, sizes):
        """Kennel bases: the plugin files this (variant) configuration ships, from the generated base's files/."""
        template = next(m for m, _ in members if m.name == 'content/display/iter.svg')
        total = 0
        for name in sorted(R.files(config, self.catalog)):
            info = copy.copy(template)
            info.name = 'content/' + name
            data = (self.generated / 'files' / name).read_bytes()
            members.append((info, data))
            total += len(data)
        # A complete boot-menu install supersedes interrupted SysEx work,
        # including same-core reinstalls. te-boot clears only these empty dirs.
        directory = next(m for m, _ in members if m.name == 'content')
        for name in ('op1r_stage', 'kennel_recovery'):
            info = copy.copy(directory); info.name = name
            members.append((info, None))
        return members, {**sizes, 'plugin_file_bytes': total}

    def utilities(self, members, config, sizes):
        if self.profile.get('kennel'):
            members, sizes = self.plugin_files(members, config, sizes)
        features = config.get('utilities', [])
        if not features:
            return members, sizes
        if self.profile.get('kennel'):
            return members, sizes                  # kennel's tools are plugin files (plugin_files); never #249 here
        if not hasattr(self, 'utility_ldr'):
            path = ROOT / 'firmware/op1_249.op1'
            if not path.exists():
                raise ValueError('Utility builds require the pinned #249 archive at ' + str(path))
            data = path.read_bytes()
            R.checked(data, U.SOURCE_SHA256, 'Maiko #249 source')
            self.utility_ldr = dict((m.name, d) for m, d in R.unpack(data))['OP1_vdk.ldr']
        idx = next(i for i, (m, _) in enumerate(members) if m.name == 'OP1_vdk.ldr')
        original = dict((m.name, d) for m, d in self.original)['OP1_vdk.ldr']
        members[idx] = (members[idx][0], U.apply(members[idx][1], self.utility_ldr, original, features, M, R, chains=self.utility_chains,
                                                               shift_wants=self.shift_wants))
        return members, {**sizes, 'utility_image_bytes': U.IMAGE_SIZE,
                         'utility_memory_bytes': U.IMAGE_SIZE + U.BSS_SIZE + (U.UNDO_SIZE if 'undo' in features else 0),
                         'utility_source_sha256': U.SOURCE_SHA256}

    def validate(self, members, config):
        files = {m.name: d for m, d in members}
        if self.profile.get('kennel'):
            require(all(any(m.name == name and m.isdir() and d is None for m, d in members) for name in ('op1r_stage', 'kennel_recovery')), 'Full install must clear transient updater state')
        base = {m.name: d for m, d in self.members}
        for name, data in files.items():   # every screen the OP-1 will parse at boot, base and ours
            if name.startswith('content/display/') and name.endswith('.svg') and data is not None:
                M.svg_check_decimals(data, name)
        R.validate_ldr(files['OP1_vdk.ldr'])
        require(files['te-boot.ldr'] == base['te-boot.ldr'], 'Bootloader changed')
        if self.profile.get('devupd'):             # every file the build changes is one a SysEx update must send
            stock = {m.name: d for m, d in self.original}
            for name, data in files.items():
                if data is not None and stock.get(name) != data:
                    require(R.path_ok(name), 'Path the SysEx update cannot send: ' + name)
        # Encrypted blocks are carried unchanged, so no OTP is needed for patching.
        encrypted = lambda data: [data[o:o + 16 + n] for o, f, a, n, arg in M.ldr_blocks(data)
                                  if f & 0x2400 == 0x2400]
        require(encrypted(files['OP1_vdk.ldr']) == encrypted(base['OP1_vdk.ldr']), 'Encrypted blocks changed')
        blocks = M.ldr_blocks(files['OP1_vdk.ldr'])
        if hasattr(self, 'lander_flag'):
            at = M.ldr_word(files['OP1_vdk.ldr'], blocks, self.lander_flag)
            require(struct.unpack_from('<I', files['OP1_vdk.ldr'], at)[0] == int(config.get('lander', False)), 'Wrong Lander option')
        capoff = M.ldr_word(files['OP1_vdk.ldr'], blocks, M.SYNTH_CAP_GATE) + 2
        require(int.from_bytes(files['OP1_vdk.ldr'][capoff:capoff + 2], 'little') == config['preset_cap'], 'Wrong preset capacity')
        with tempfile.TemporaryDirectory() as td:
            for label, data in [('new', files['content/op1_factory.db']), ('base', base['content/op1_factory.db'])]:
                Path(td, label).write_bytes(data)
            with sqlite3.connect(Path(td, 'new')) as db, sqlite3.connect(Path(td, 'base')) as old:
                require(db.execute('PRAGMA integrity_check').fetchone() == ('ok',), 'Database integrity check failed')
                config = R.normalize(config, self.catalog)
                hidden = config.get('hidden', []) + (R.left_out_rows(config, self.catalog) if self.profile.get('kennel') else [])
                saved = {f['id']: R.saved_name(f) for g in ('synths', 'effects', 'op1r_plugins') for f in self.catalog[g]}
                hidden = [saved.get(h, h) for h in hidden]   # DB rows carry saved names
                for group, table in [('synths', 'synth_types'), ('effects', 'fx_types')]:
                    old_rows = [r for r in old.execute(f'SELECT * FROM {table} ORDER BY id').fetchall()
                                if r[1] not in hidden]
                    new_rows = db.execute(f'SELECT * FROM {table} ORDER BY id').fetchall()
                    require(new_rows[:len(old_rows)] == old_rows, 'Base rows changed')
                    require(not {r[1] for r in new_rows} & set(hidden), 'Hidden plugin still listed')
                    rows = [i for i in config[group] if not any(f['id'] == i and f.get('file') for f in self.catalog[group])]
                    require(len(new_rows) == len(old_rows) + len(rows), 'Wrong selected row count')
                    for f in self.catalog[group]:
                        if f.get('file'):
                            continue               # registered by kennel's loader at boot, not a DB row
                        row = db.execute(f'SELECT default_params FROM {table} WHERE type=?', (f['id'],)).fetchone()
                        require(bool(row) == (f['id'] in config[group]), 'Wrong membership: ' + f['id'])
                        if row:
                            require(json.loads(row[0])[4] == f['marker'], 'Wrong marker: ' + f['id'])
                        screen = bool(self.profile.get('plugins')) or bool(row)
                        require((f'content/display/{f["id"]}.svg' in files) == screen, 'Wrong screen membership: ' + f['id'])
        if self.profile.get('kennel'):
            # A valid file can still import a missing service (GCC can introduce
            # memcpy for struct copies). Check the actual linked core's export
            # strings, not every ELF symbol, before offering a release.
            sym = {parts[2]: int(parts[0], 16) for line in
                   (self.generated / 'synth_sdk/build/synth.sym').read_text().splitlines()
                   if len(parts := line.split()) == 3}
            ldr = files['OP1_vdk.ldr']
            ro = next(ldr[o+16:o+16+n] for o, f, a, n, _ in M.ldr_blocks(ldr)
                      if a == 0x01E00000 and not f & 0x100)
            def word(addr):
                at = addr - 0x01E00000
                require(0 <= at <= len(ro)-4, 'Core export pointer outside image')
                return struct.unpack_from('<I', ro, at)[0]
            count = word(sym['_kn_export_count'])
            require(count <= 1024, 'Invalid core export count')
            exports = set()
            for i in range(count):
                at = word(sym['_kn_exports'] + i*8) - 0x01E00000
                require(0 <= at < len(ro), 'Core export name outside image')
                end = ro.find(b'\0', at, min(at+128, len(ro)))
                require(end >= at, 'Invalid core export name')
                exports.add(ro[at:end].decode('ascii'))
            kn = module('kennel_release_format', ROOT / self.profile['source'] / 'tools/kennel/reloc.py')
            for name, data in files.items():
                if name.startswith('content/') and name.endswith('.knl') and data is not None:
                    missing = set(kn.parse(data)['imports']) - exports
                    require(not missing, f'{name}: imports not exported by this core: {sorted(missing)}')
            chosen = R.files(config, self.catalog)
            for _, name in R.file_choices(self.catalog).values():
                require(('content/' + name in files) == (name in chosen), 'Wrong plugin file membership: ' + name)

    def preset_pack(self, config, directory):
        profile = getattr(self, 'profile', {})
        if profile.get('kennel'):
            return self.kennel_preset_pack(config, directory)
        engines = {'supersaw', 'fmbell', 'granular', 'iter', *config['synths']}
        patches = [(meta, pcm) for meta, pcm in PRESETS.presets()
                   if meta['type'] in engines and
                   (meta['fx_type'] not in ('washer', 'snowglobe') or meta['fx_type'] in config['effects'])]
        patches = [(meta['type'], meta['name'], PRESETS.aifc(meta, pcm)) for meta, pcm in patches]
        counts = {}
        path = directory / 'presets.zip'
        def write(archive, name, data):
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, data)
        with zipfile.ZipFile(path, 'w') as archive:
            for kind, name, data in patches:
                counts[kind] = counts.get(kind, 0) + 1
                write(archive, f'synth/{kind}/{name}.aif', data)
            instructions = (f'Hundekraft preset collection — {len(patches)} patches for this configuration.\n\n'
                'Install the matching firmware first. Enter disk mode (Shift + COM, then T3).\n'
                'Copy the folders inside synth/ into the OP-1 disk’s synth/ directory, then eject.\n'
                'The OP-1 restarts by itself, syncs the new files and waits for a key press. Presets are separate from firmware.\n'
                f'Your firmware supports {config["preset_cap"]} user synth presets TOTAL, including existing ones.\n'
                + ('This pack exceeds that limit: enable 300 presets or install only a subset.\n' if len(patches) > config['preset_cap'] else '')
                + 'Granular presets are settings: load or record a sample into the slot first.\n'
                'Washer/Snowglobe sounds are synth patches using those effects; they are not standalone FX presets.\n'
                'An existing patch with the same filename may keep its old sound after sync; use a fresh name to replace it.\n')
            write(archive, 'INSTALL.txt', instructions.encode())
            write(archive, 'config.json', (json.dumps(config, indent=2) + '\n').encode())
        return {'count': len(patches), 'by_engine': counts, 'sha256': R.sha256(path.read_bytes()),
                'exceeds_cap': len(patches) > config['preset_cap']}

    def kennel_preset_pack(self, config, directory):
        """Kennel bases: our presets plus the ones kennel plugins carry (eva, mbira: knobs[4] = 0x5300), kept by
        runtime.preset_keep, written by runtime.preset_zip: the browser filters the variant's pack with the same
        rule and writer (runtime.filter_preset_zip), so both give the same bytes for a configuration."""
        config = R.normalize(config, self.catalog)
        patches = []
        for meta, pcm in PRESETS.presets():
            # Author kennel's factory patches for its compact selector bands.
            # The historical 2.x generator/firmware retain their original controls.
            if meta['type'] in ('fmbell', 'elg'):
                meta = dict(meta, knobs=list(meta['knobs']))
                q = meta['knobs'][0]
                choice = q >> 11 if meta['type'] == 'fmbell' else (q * 5) >> 15
                meta['knobs'][0] = choice * 512 + 256
            patches.append((meta['type'], meta['name'], PRESETS.aifc(meta, pcm)))
        for folder in sorted((ROOT / self.profile['source'] / 'synth_sdk/plugins').glob('*/presets')):
            patches += [(folder.parent.name, f.stem, f.read_bytes()) for f in sorted(folder.glob('*.aif'))]
        # Fill missing processing, then apply the 38 accepted native-reviewed retunes.
        patches = [(kind, name, PRESET_VARIATION.apply(PRESET_POLISH.apply(data)))
                   for kind, name, data in patches]
        patches = [p for p in patches if R.preset_keep(p[0], R.preset_effect(R.preset_meta(p[2])), config, self.catalog)]
        path = directory / 'presets.zip'
        path.write_bytes(R.preset_zip(patches, config))
        # with items: [engine, fx_type or ''] per preset in pack order, what preset_keep reads (the page counts from it)
        return R.preset_info(path.read_bytes(), config['preset_cap'])

    def variant(self, config, target):
        config = R.normalize(config, self.catalog)
        require('hidden' not in config, 'Hidden op1r plugins are applied at patch time, not prebuilt')
        ident = R.config_id(config, self.catalog)
        directory = target / 'variants' / ident
        directory.mkdir(parents=True, exist_ok=True)
        members, sizes = self.configured_members(config)
        self.validate(members, config)
        original = {m.name: d for m, d in self.members}
        patched, added, directories = [], [], []
        for info, data in members:
            if data is None:
                if info.name not in original:
                    require(info.isdir() and info.name in ('op1r_stage', 'kennel_recovery'), 'Unexpected new directory')
                    directories.append({'path': info.name, 'template': 'content'})
                continue
            name = info.name
            if name in original:
                if data != original[name]:
                    ops = self.diff.file_ops(name, original[name], data, str(directory))
                    patched.append({'path': name, 'orig_sha256': R.sha256(original[name]),
                                    'result_sha256': R.sha256(data), 'ops': ops})
            else:
                blob = name.replace('/', '_')
                (directory / blob).write_bytes(data)
                added.append({'path': name, 'blob': blob, 'sha256': R.sha256(data),
                              'template': 'content/display/iter.svg'})
        manifest = {'config': config, 'release': self.release, 'sizes': sizes,
                    'filename': R.PRODUCT['slug'] + '-' + ident + '.op1',
                    'presets': self.preset_pack(config, directory),
                    'patched_files': patched, 'added_files': added,
                    **({'added_directories': directories} if directories else {}),
                    'result': {'tar_sha256': R.sha256(R.pack_tar(members))}}
        json_write(directory / 'manifest.json', manifest)
        # Apply the distributed delta independently and compare the complete archive.
        actual = R.apply_manifest(self.members, manifest, lambda n: (directory / n).read_bytes())
        require(R.pack_tar(actual) == R.pack_tar(members), 'Generated delta differs from reference')
        return manifest

    def prepare(self, target, configs, catalog=None):
        target.mkdir(parents=True, exist_ok=True)
        shutil.copytree(self.base_dir, target / 'base', dirs_exist_ok=True)
        shutil.copy2(self.upstream / 'README.md', target / 'OP1R-README.md')
        shutil.copytree(self.upstream / 'docs/images', target / 'op1r-images', dirs_exist_ok=True)
        shutil.copy2(HERE / 'runtime.py', target / 'runtime.py')
        catalog = self.catalog if catalog is None else catalog
        require(catalog['base'] == self.catalog['base'], 'Release catalog has a different base')
        json_write(target / 'catalog.json', catalog)
        (target / 'screens').mkdir(exist_ok=True)
        for group, folder in [('synths', 'engines'), ('effects', 'fx')]:
            for feature in self.catalog[group]:
                name = feature['id']
                shutil.copy2(ROOT / 'tools' / folder / name / (name + '.svg'), target / 'screens' / (name + '.svg'))
        index = {'schema': 1, 'release': self.release, 'catalog': catalog, 'devupd': bool(self.profile.get('devupd')),
                 'runtime_sha256': R.sha256((target / 'runtime.py').read_bytes()),
                 'base_sha256': R.sha256((target / 'base/manifest.json').read_bytes()), 'variants': {}}
        for config in configs:
            ident = R.config_id(config, self.catalog)
            manifest = self.variant(config, target)
            index['variants'][ident] = {'sha256': R.sha256((target / 'variants' / ident / 'manifest.json').read_bytes()),
                                        'sizes': manifest['sizes'], 'presets': manifest['presets']}
            print(f'Validated {ident}: {config["synths"]} / {config["effects"]} / {config["preset_cap"]}', flush=True)
        json_write(target / 'release.json', index)
        return index


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    build = sub.add_parser('build', help='Build one configuration from original R246')
    build.add_argument('firmware', type=Path)
    build.add_argument('--config', type=Path, required=True)
    build.add_argument('--output', type=Path, help='Defaults to build/<release>-<selection>.op1')
    release = sub.add_parser('release', help='Prepare accepted feature combinations and the static web app')
    release.add_argument('firmware', type=Path)
    release.add_argument('--output', type=Path, default=ROOT / 'build/firmware-web')
    candidate = sub.add_parser('validate-candidate', help='Validate all 2048 private variants without a web app')
    candidate.add_argument('firmware', type=Path)
    candidate.add_argument('--output', type=Path, required=True)
    for command in (build, candidate):
        command.add_argument('--base', choices=BASES, default=RELEASED_BASE,
                             help='Native candidate base; public release remains pinned')
    args = parser.parse_args()
    try:
        builder = Builder(args.firmware, getattr(args, 'base', RELEASED_BASE))
        if args.command == 'validate-candidate':
            builder.prepare(args.output, all_configs(builder.catalog))
        elif args.command == 'release':
            builder.prepare(args.output, public_configs(), public_catalog())
            for path in (ROOT / 'web/firmware').iterdir():
                if path.is_file():
                    shutil.copy2(path, args.output / path.name)
                elif path.is_dir():
                    shutil.copytree(path, args.output / path.name, dirs_exist_ok=True)
            print('Static app:', args.output.resolve())
        else:
            config = R.normalize(json.loads(args.config.read_text()), builder.catalog)
            prebuilt = R.variant_config(config, builder.catalog)
            with tempfile.TemporaryDirectory() as td:
                directory = Path(td)
                builder.prepare(directory, [prebuilt])
                variant_dir = directory / 'variants' / R.config_id(prebuilt, builder.catalog)
                manifest = json.loads((variant_dir / 'manifest.json').read_text())
                out, report = R.patch(builder.op1, builder.base, manifest,
                                      lambda n: (builder.base_dir / n).read_bytes(),
                                      lambda n: (variant_dir / n).read_bytes(), print,
                                      catalog=builder.catalog, config=config)
                builder.validate(R.unpack(out), config)
                presets = (variant_dir / 'presets.zip').read_bytes()
            if args.output is None:
                args.output = ROOT / 'build' / (R.PRODUCT['slug'] + '-' + R.config_id(config, builder.catalog) + '.op1')
            if args.output.resolve() == args.firmware.resolve():
                raise ValueError('Output must not overwrite the original firmware')
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_bytes(out)
            args.output.with_suffix('.presets.zip').write_bytes(presets)
            json_write(args.output.with_suffix('.build.json'), report)
            print(f'Built {args.output}: {report["output_sha256"]}')
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        if isinstance(exc, subprocess.CalledProcessError):
            print((exc.stderr or b'').decode() if isinstance(exc.stderr, bytes) else exc.stderr, file=sys.stderr)
        parser.exit(1, str(exc) + '\n')


if __name__ == '__main__':
    main()
