/* Native test harness for an effect: plays a test signal through it and writes a 16-bit WAV.
 * cc -O2 -DFX_HOST_TEST -I tools/fx -o build/fx/NAME-host tools/fx/fxtest.c tools/fx/NAME/NAME.c
 * build/fx/NAME-host OUT.wav [SECONDS [K0 K1 K2 K3 [SIGNAL]]]
 * SIGNAL: pluck (default; a saw chord, plucked every second, silent for the last third) or saw (held). */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fx.h"

static void put32(FILE *f, uint32_t v) { fwrite(&v, 4, 1, f); }
static void put16(FILE *f, uint16_t v) { fwrite(&v, 2, 1, f); }

int main(int argc, char **argv)
{
    if (argc < 2) { fprintf(stderr, "usage: %s OUT.wav [SECONDS [K0 K1 K2 K3 [pluck|saw]]]\n", argv[0]); return 1; }
    const double seconds = argc > 2 ? atof(argv[2]) : 4.0;
    int16_t knobs[8] = {16384, 16384, 0, 16384, 0, 0, 0, 0};
    for (int k = 0; k < 4 && argc > 3 + k; k++) knobs[k] = (int16_t)atoi(argv[3 + k]);
    const int held = argc > 7 && !strcmp(argv[7], "saw");
    const int blocks = (int)(seconds * 44100 / FX_BLOCK);
    FILE *f = fopen(argv[1], "wb");
    if (!f) { perror(argv[1]); return 1; }
    const uint32_t bytes = (uint32_t)blocks * FX_BLOCK * 2;
    fwrite("RIFF", 1, 4, f); put32(f, 36 + bytes); fwrite("WAVEfmt ", 1, 8, f);
    put32(f, 16); put16(f, 1); put16(f, 1); put32(f, 44100); put32(f, 88200); put16(f, 2); put16(f, 16);
    fwrite("data", 1, 4, f); put32(f, bytes);
    fx_reset(FX_SYNTH);
    const double hz[3] = {130.81, 164.81, 196.0};
    double ph[3] = {0, 0, 0};
    int16_t io[FX_BLOCK];
    for (int b = 0; b < blocks; b++) {
        for (int i = 0; i < FX_BLOCK; i++) {
            const double t = (double)(b * FX_BLOCK + i) / 44100;
            double env = held ? 1.0 : exp(-3.0 * fmod(t, 1.0));
            if (!held && t > seconds * 2 / 3) env = 0;
            double x = 0;
            for (int v = 0; v < 3; v++) {
                ph[v] += hz[v] / 44100;
                ph[v] -= floor(ph[v]);
                x += 2 * ph[v] - 1;
            }
            io[i] = (int16_t)(x / 3 * env * 20000);
        }
        fx_process(FX_SYNTH, io, FX_BLOCK, knobs);
        fwrite(io, 2, FX_BLOCK, f);
    }
    fclose(f);
    printf("%s: %d blocks, knobs %d %d %d %d\n", argv[1], blocks, knobs[0], knobs[1], knobs[2], knobs[3]);
    return 0;
}
