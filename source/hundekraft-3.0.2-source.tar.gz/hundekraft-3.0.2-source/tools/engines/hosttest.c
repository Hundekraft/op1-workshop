/* Native test harness for an engine: renders one voice at a fixed note and writes a 16-bit WAV.
 * cc -O2 -DENGINE_HOST_TEST -o build/engines/NAME-host tools/engines/hosttest.c tools/engines/NAME/[sources]
 * build/engines/NAME-host OUT.wav [MIDI_NOTE [SECONDS [K0 K1 K2 K3]]]
 * Pitch matches the firmware: increment = 2^32 * f / 44100, constant within a block. */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "engine.h"

uint32_t engine_host_pitch[128];

static void put32(FILE *f, uint32_t v) { fwrite(&v, 4, 1, f); }
static void put16(FILE *f, uint16_t v) { fwrite(&v, 2, 1, f); }

int main(int argc, char **argv)
{
    if (argc < 2) { fprintf(stderr, "usage: %s OUT.wav [NOTE [SECONDS [K0 K1 K2 K3]]]\n", argv[0]); return 1; }
    const int note = argc > 2 ? atoi(argv[2]) : 60;
    const double seconds = argc > 3 ? atof(argv[3]) : 2.0;
    int16_t knobs[8] = {16384, 8192, 0, 8192, 0, 0, 0, 0};
    for (int k = 0; k < 4 && argc > 4 + k; k++) knobs[k] = (int16_t)atoi(argv[4 + k]);
    const double hz = 440.0 * pow(2.0, (note - 69) / 12.0);
    const uint32_t inc = (uint32_t)(hz * 4294967296.0 / 44100.0 + 0.5);
    for (int i = 0; i < 128; i++) engine_host_pitch[i] = inc;
    void *self = (void *)(uintptr_t)0xFFB00000u;   /* voice 0 */
    const int blocks = (int)(seconds * 44100 / 128);
    FILE *f = fopen(argv[1], "wb");
    if (!f) { perror(argv[1]); return 1; }
    const uint32_t bytes = (uint32_t)blocks * 128 * 2;
    fwrite("RIFF", 1, 4, f); put32(f, 36 + bytes); fwrite("WAVEfmt ", 1, 8, f);
    put32(f, 16); put16(f, 1); put16(f, 1); put32(f, 44100); put32(f, 88200); put16(f, 2); put16(f, 16);
    fwrite("data", 1, 4, f); put32(f, bytes);
    engine_note_on(self, knobs);
    int16_t out[128];
    for (int b = 0; b < blocks; b++) {
        engine_render(self, out, knobs);
        fwrite(out, 2, 128, f);
    }
    engine_note_off(self, knobs);
    fclose(f);
    printf("%s: note %d (%.2f Hz), %d blocks, knobs %d %d %d %d\n", argv[1], note, hz, blocks, knobs[0], knobs[1], knobs[2], knobs[3]);
    return 0;
}
