/* The organ screen (pew.svg, docs/design/engine-screens/round5/build_round5.py) in motion. iter's draw turns the
 * hidden bar0..bar3; on top:
 *   pipes0..2  the blue, green and white pipe groups stand 45 .. 100 % tall with their drawbar knob, about the
 *              pipe feet (y 82.9)
 *   horn       the Leslie's treble horn spins with the audio's rotor (squashed by the cosine of its angle about
 *              x 280.75, so the bells swap sides as it turns)
 *   drum       the bass drum's slats slide a quarter of the box (7.8 px) per quarter turn of the drum rotor
 *   arrows     two red arcs round the horn (280.75, 74.6), drawn live: 30..140 degrees long with the rotor speed
 *              (red knob), turning with the horn
 *   organist   rocks to the music about the hip (137.85, 114)
 * Coordinates are screen px (the SVG is drawn at 1:1).
 */
#ifndef ENGINE_HOST_TEST
#include "../engine.h"

extern volatile uint32_t pew_blocks, pew_horn, pew_drum;
extern volatile int16_t pew_knobs[4];

#define ONE 1024
#define Q(v) ((int32_t)((v) * 1024))   /* screen px -> Q10 */

static void *e_pipes[3], *e_horn, *e_drum, *e_organist;
static uint32_t last_blocks, t;
static int32_t act;
/* a knob as the voices hear it (after the slot LFO) while notes play, else as set */
#define K(i) screen_knob_live(pew_knobs, (i), act > 64)

static const uint8_t red[4] = {0xFF, 0x3A, 0x5D, 0xFF};

void engine_screen_load(void *screen)
{
    static const char *const pipes[3] = {"pipes0", "pipes1", "pipes2"};
    for (int i = 0; i < 3; i++) e_pipes[i] = SVG_FIND(screen, pipes[i]);
    e_horn = SVG_FIND(screen, "horn");
    e_drum = SVG_FIND(screen, "drum");
    e_organist = SVG_FIND(screen, "organist");
}

void engine_screen_animate(void *screen)
{
    (void)screen;
    const uint32_t blocks = pew_blocks;
    const int on = blocks != last_blocks;
    last_blocks = blocks;
    act += ((on ? ONE : 0) - act) >> 3;
    t++;

    /* pipes: 45 .. 100 % of their height with the drawbar knob, about the feet */
    for (int i = 0; i < 3; i++) {
        const int32_t k = K(i);
        svg_scale(e_pipes[i], ONE, 461 + ((k * 563) >> 15), 0, Q(82.87));
    }

    /* horn: the audio's rotor angle (2^32 per turn), seen from the front */
    svg_scale(e_horn, SVG_SIN((pew_horn >> 19) + 2048) >> 5, ONE, Q(280.75), 0);
    /* drum: the slats slide 0 .. 7.8 px over each quarter turn, then start again */
    svg_move(e_drum, (int32_t)(((pew_drum >> 16) & 16383) * Q(7.78) >> 14), 0);

    /* organist: rocks +-3 degrees about the hip while notes play */
    svg_turn(e_organist, (uint32_t)((SVG_SIN(t * 96) * 68 >> 15) * act >> 10), Q(137.85), Q(113.98));
}

static void line(void *canvas, int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    const svg_pt a = {x0, y0}, b = {x1, y1};
    SVG_LINE(canvas, &a, &b, 0x666, red);                  /* 1.6 px */
}

/* point on a circle about the horn (280.75, 74.63), radius r px, angle a (8192 per turn) */
static void at(uint32_t a, int32_t r, int32_t *x, int32_t *y)
{
    *x = Q(280.75) + ((SVG_SIN(a + 2048) * r) >> 5);
    *y = Q(74.63) + ((SVG_SIN(a) * r) >> 5);
}

void engine_screen_draw(void *screen, void *canvas)
{
    (void)screen;
    if (!canvas) return;
    /* two arcs on radius 17, each 30..140 degrees with the red knob, centred below and above the horn and turning
       with it; an arrowhead (radius 14..20, 16 degrees back) at the leading end */
    const int32_t k3 = K(3);
    const uint32_t sweep = 683 + (uint32_t)((k3 * 2503) >> 15);
    enum { N = 10 };
    for (int e = 0; e < 2; e++) {
        const uint32_t mid = (pew_horn >> 19) + 2048 + (uint32_t)e * 4096, a0 = mid - sweep / 2;
        int32_t px, py, x, y;
        at(a0, 17, &px, &py);
        for (int i = 1; i <= N; i++) {
            at(a0 + sweep * (uint32_t)i / N, 17, &x, &y);
            line(canvas, px, py, x, y);
            px = x;
            py = y;
        }
        int32_t hx, hy;
        at(a0 + sweep - 364, 14, &hx, &hy);
        line(canvas, hx, hy, px, py);
        at(a0 + sweep - 364, 20, &hx, &hy);
        line(canvas, hx, hy, px, py);
    }
}
#endif
