/* Run engines next to op1r's custom engines (op1r's own architecture: iter hosts them, knobs[4] holds a
 * marker 0x53nn, the patch type name aliases to "iter"). The engines come from the op1r_engines table
 * (op1r_engines.h), which tools/engines/build.sh generates from OP1R="name:marker ...".
 *
 * tools/engines/mkfw.py --op1r points four words of R246 at the hooks below and stores op1r's previous targets
 * in the op1r_chain_* words, so everything that is not one of these engines goes to op1r unchanged:
 *   iter vtable 0x019103CC +0x14 render, +0x1C note_on, +0x2C note_off  -> op1r_hook_*
 *   JUMP.L at 0x019B975C (string equals(cstr, std::string), op1r's alias check) -> op1r_hook_name_eq
 * An engine is selected when knobs[4] is its marker (the default params of its synth_types row) and its patch
 * type name is accepted wherever the firmware looks for "iter". op1r's own dispatch only knows markers below
 * its engine count, so these markers never reach it.
 */
#include "engine.h"
#include "op1r_engines.h"

/* Fixed entry points at the start of the image (engine.ld puts .text.hooks first): R246's patched words point here,
 * so a rebuilt engine can be tried with OP1EMU_OVERLAY without reinstalling the firmware. */
__asm__(".section .text.hooks,\"ax\",@progbits\n"
        "    .global _op1r_entry_render\n_op1r_entry_render:   jump.l _op1r_hook_render;\n"
        "    .global _op1r_entry_note_on\n_op1r_entry_note_on:  jump.l _op1r_hook_note_on;\n"
        "    .global _op1r_entry_note_off\n_op1r_entry_note_off: jump.l _op1r_hook_note_off;\n"
        "    .global _op1r_entry_name_eq\n_op1r_entry_name_eq:  jump.l _op1r_hook_name_eq;\n"
        "    .global _op1r_entry_screens_init\n_op1r_entry_screens_init: jump.l _op1r_hook_screens_init;\n"
        "    .global _op1r_entry_screens_load\n_op1r_entry_screens_load: jump.l _op1r_hook_screens_load;\n"
        /* ScreenId::synth case 14 (iter): reached through the switch's jump table, inside the stock function's
           frame; return its result like op1r's own case code does */
        "    .global _op1r_entry_pick\n_op1r_entry_pick: call _op1r_hook_pick; p0 = [fp + 4]; unlink; jump (p0);\n"
        /* effects: the filter FX's vtable (mono +0x14 process, +0x1C init; stereo +0x14 process, +0x1C reset),
           the FX name compare at 0x019AAD8E and ScreenId::fx case 5 (same stub shape as the synth case) */
        "    .global _op1r_entry_fx_process\n_op1r_entry_fx_process: jump.l _op1r_hook_fx_process;\n"
        "    .global _op1r_entry_fx_init\n_op1r_entry_fx_init: jump.l _op1r_hook_fx_init;\n"
        "    .global _op1r_entry_fx_st_process\n_op1r_entry_fx_st_process: jump.l _op1r_hook_fx_st_process;\n"
        "    .global _op1r_entry_fx_st_reset\n_op1r_entry_fx_st_reset: jump.l _op1r_hook_fx_st_reset;\n"
        "    .global _op1r_entry_fx_name_eq\n_op1r_entry_fx_name_eq: jump.l _op1r_hook_fx_name_eq;\n"
        "    .global _op1r_entry_fx_pick\n_op1r_entry_fx_pick: call _op1r_hook_fx_pick; p0 = [fp + 4]; unlink; jump (p0);\n"
        "    .text\n");

typedef int (*render_fn)(void *, int16_t *, const int16_t *);
typedef int (*note_fn)(void *, const int16_t *);
typedef int (*eq_fn)(const char *, const void *);
typedef int (*void3_fn)(int, int, int);
typedef int (*pick_fn)(void);

/* Filled in by mkfw.py (op1r's targets); in .data so they sit at fixed offsets in the image. */
__attribute__((used, section(".data"))) render_fn op1r_chain_render = 0;
__attribute__((used, section(".data"))) note_fn op1r_chain_note_on = 0;
__attribute__((used, section(".data"))) note_fn op1r_chain_note_off = 0;
__attribute__((used, section(".data"))) eq_fn op1r_chain_name_eq = 0;
__attribute__((used, section(".data"))) void3_fn op1r_chain_screens_init = 0;
__attribute__((used, section(".data"))) void3_fn op1r_chain_screens_load = 0;
__attribute__((used, section(".data"))) pick_fn op1r_chain_pick = 0;
typedef int (*fx_process_fn)(void *, int16_t *, const int16_t *);
typedef int (*fx_init_fn)(void *, int);
typedef int (*fx_st_process_fn)(void *, int16_t *, int16_t *, const int16_t *);
typedef int (*fx_st_reset_fn)(void *);
__attribute__((used, section(".data"))) fx_process_fn op1r_chain_fx_process = 0;
__attribute__((used, section(".data"))) fx_init_fn op1r_chain_fx_init = 0;
__attribute__((used, section(".data"))) fx_st_process_fn op1r_chain_fx_st_process = 0;
__attribute__((used, section(".data"))) fx_st_reset_fn op1r_chain_fx_st_reset = 0;
__attribute__((used, section(".data"))) eq_fn op1r_chain_fx_name_eq = 0;
__attribute__((used, section(".data"))) pick_fn op1r_chain_fx_pick = 0;

/* Boot screen text under the TE logo (R246: "R. 00246", op1r: "op1r 18"); mkfw.py points the load at
 * 0x01A2FCB8 here. 17 lines down, centred near column 37 like the stock text. The first number is op1r's
 * release (upstream), the second ours: 1 wavetable, 2 its screen, 3 animated + presets, 4 taffy, pew and elg,
 * 5 on op1r 14 with iter presets, the preset fixes and the ELG LFO fix. */
#ifndef OP1R_VERSION
#define OP1R_VERSION "14" /* Legacy build.sh default; the configurator supplies its pinned base. */
#endif
#define FEAT_VERSION "5"
__attribute__((used)) const char op1r_boot_text[] =
    "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" "                        "
    "op1r " OP1R_VERSION " feat. hundekraft " FEAT_VERSION;

/* More user synth presets: R246 keeps at most 100 (gate 0x019FEEF8) and holds every synth patch (factory, sampler
 * and user) in a table of 318 entries of 56 bytes at 0x01DDDB68, which the loader fills without a bound. mkfw.py
 * moves that table here (zeros in the image; the firmware's constructor runs on it at start-up) and raises the
 * gate to OP1R_USER_SYNTH_PRESETS. Room: 169 factory, 33 more sampler, the user presets and a margin. The real
 * limit is the preset database's heap: 432 user presets boot and browse, 500 stop the boot with "db2.cpp:129 out
 * of memory"; 300 leaves room for the rest of the database (drum presets, the user's own patches). */
#ifndef OP1R_USER_SYNTH_PRESETS
#define OP1R_USER_SYNTH_PRESETS 300
#endif
#if OP1R_USER_SYNTH_PRESETS != 100 && OP1R_USER_SYNTH_PRESETS != 300
#error "Supported user preset capacities are 100 and 300"
#endif
#if OP1R_USER_SYNTH_PRESETS > 100
#define OP1R_SYNTH_PATCHES (169 + 33 + OP1R_USER_SYNTH_PRESETS + 16)
__attribute__((used, aligned(4))) uint8_t op1r_synth_patches[OP1R_SYNTH_PATCHES * 56];
__attribute__((used)) const int32_t op1r_synth_patch_count = OP1R_SYNTH_PATCHES;
__attribute__((used)) const int32_t op1r_user_synth_cap = OP1R_USER_SYNTH_PRESETS;
#endif

static uint8_t owned[ENGINE_VOICES];   /* 1 + index of the engine the voice is playing, 0 = op1r's */

static int find_engine(int16_t marker)
{
    for (int i = 0; i < op1r_engine_count; i++)
        if (op1r_engines[i].marker == (uint16_t)marker) return i;
    return -1;
}

int op1r_hook_note_on(void *self, const int16_t *knobs)
{
    const int v = ENGINE_VOICE(self), e = find_engine(knobs[4]);
    owned[v] = (uint8_t)(e + 1);
    if (e >= 0) {
        op1r_engines[e].note_on(self, knobs);
        return 0;
    }
    return op1r_chain_note_on(self, knobs);
}

int op1r_hook_render(void *self, int16_t *out, const int16_t *knobs)
{
    const int v = ENGINE_VOICE(self), e = find_engine(knobs[4]);
    if (e >= 0) {
        if (owned[v] != e + 1) {   /* engine picked while the voice was sounding */
            owned[v] = (uint8_t)(e + 1);
            op1r_engines[e].note_on(self, knobs);
        }
        op1r_engines[e].render(self, out, knobs);
        return 0;
    }
    owned[v] = 0;
    return op1r_chain_render(self, out, knobs);
}

int op1r_hook_note_off(void *self, const int16_t *knobs)
{
    const int o = owned[ENGINE_VOICE(self)];
    if (o) {
        op1r_engines[o - 1].note_off(self, knobs);
        return 0;
    }
    return op1r_chain_note_off(self, knobs);
}

/* std::string on this firmware: length at +0x14, capacity at +0x18, characters inline at +4 while the
 * capacity is at most 15, else a pointer at +4. */
static const char *str_data(const void *s)
{
    const uint8_t *p = (const uint8_t *)s;
    return *(const uint32_t *)(p + 0x18) <= 15 ? (const char *)(p + 4) : *(const char *const *)(p + 4);
}

static int cstr_eq(const char *a, const char *b)
{
    while (*a && *a == *b) a++, b++;
    return *a == *b;
}

int op1r_hook_name_eq(const char *cstr, const void *str)
{
    if (cstr_eq(cstr, "iter")) {
        const uint32_t len = *(const uint32_t *)((const uint8_t *)str + 0x14);
        const char *d = str_data(str);
        for (int e = 0; e < op1r_engine_count; e++) {
            const char *n = op1r_engines[e].name;
            uint32_t i = 0;
            while (i < len && n[i] && d[i] == n[i]) i++;
            if (i == len && !n[i]) return 1;
        }
    }
    return op1r_chain_name_eq(cstr, str);
}

/* ---- effects (op1r hosts its tape/clouds/reverb in the filter FX the same way; docs/synth-engines.md) ----
 * The firmware calls the filter FX per 64-sample block: mono process(this, buf, params) for the synth and the
 * drum instrument (one shared object; init(this, which) says which), stereo process(this, L, R, params) for the
 * master. params[4] = our marker selects our FX; params 0..3 stay inside the filter's ranges, which we stretch
 * to 0..32767 for the effect. op1r runs the master FX on the mono sum and adds the change to both channels;
 * we do the same. */
#define FX_BLOCK_N 64
static const int16_t fx_lo[4] = {64, 0, 0, 8192}, fx_hi[4] = {14528, 24576, 22528, 32767};   /* filter, R246 */
static int fx_mono_chan;
static int8_t fx_cur[3] = {-1, -1, -1};

static int find_fx(int16_t marker)
{
    for (int i = 0; i < op1r_fx_count; i++)
        if (op1r_fxs[i].marker == (uint16_t)marker) return i;
    return -1;
}

static void fx_knobs(const int16_t *params, int16_t *k)
{
    for (int i = 0; i < 4; i++) {
        int32_t v = params[i];
        if (v < fx_lo[i]) v = fx_lo[i];
        if (v > fx_hi[i]) v = fx_hi[i];
        k[i] = (int16_t)(((v - fx_lo[i]) * 32767) / (fx_hi[i] - fx_lo[i]));
    }
    for (int i = 4; i < 8; i++) k[i] = params[i];
}

static void fx_run(int e, int chan, int16_t *buf, const int16_t *params)
{
    int16_t k[8];
    if (fx_cur[chan] != e) {
        fx_cur[chan] = (int8_t)e;
        op1r_fxs[e].reset(chan);
    }
    fx_knobs(params, k);
    op1r_fxs[e].process(chan, buf, FX_BLOCK_N, k);
}

int op1r_hook_fx_init(void *self, int which)
{
    fx_mono_chan = which & 1;
    fx_cur[fx_mono_chan] = -1;
    return op1r_chain_fx_init(self, which);
}

int op1r_hook_fx_process(void *self, int16_t *buf, const int16_t *params)
{
    const int e = find_fx(params[4]);
    if (e < 0) {
        fx_cur[fx_mono_chan] = -1;
        return op1r_chain_fx_process(self, buf, params);
    }
    fx_run(e, fx_mono_chan, buf, params);
    return 0;
}

int op1r_hook_fx_st_reset(void *self)
{
    fx_cur[2] = -1;
    return op1r_chain_fx_st_reset(self);
}

int op1r_hook_fx_st_process(void *self, int16_t *l, int16_t *r, const int16_t *params)
{
    const int e = find_fx(params[4]);
    if (e < 0) {
        fx_cur[2] = -1;
        return op1r_chain_fx_st_process(self, l, r, params);
    }
    int16_t dry[FX_BLOCK_N], wet[FX_BLOCK_N];
    for (int i = 0; i < FX_BLOCK_N; i++) dry[i] = wet[i] = (int16_t)((l[i] + r[i]) >> 1);
    fx_run(e, 2, wet, params);
    for (int i = 0; i < FX_BLOCK_N; i++) {
        const int32_t d = wet[i] - dry[i];
        l[i] = engine_sat16(l[i] + d);
        r[i] = engine_sat16(r[i] + d);
    }
    return 0;
}

int op1r_hook_fx_name_eq(const char *cstr, const void *str)
{
    if (cstr_eq(cstr, "filter")) {
        const uint32_t len = *(const uint32_t *)((const uint8_t *)str + 0x14);
        const char *d = str_data(str);
        for (int e = 0; e < op1r_fx_count; e++) {
            const char *n = op1r_fxs[e].name;
            uint32_t i = 0;
            while (i < len && n[i] && d[i] == n[i]) i++;
            if (i == len && !n[i]) return 1;
        }
    }
    return op1r_chain_fx_name_eq(cstr, str);
}

/* ---- the engine's own screen (as op1r builds its engines' screens) ----
 * R246: Screen::Screen(obj, id, "file.svg") at 0x01A3BAB0 registers obj in the screen table, so the iter entry
 * (0x01DF4EA4) is saved and restored around it; the document loader 0x01A503D8 loads obj+8's name into obj+0.
 * Like op1r, the object gets a copy of iter's screen class (vtable 0x019103FC: draw at +0x1C rotates the SVG's
 * bar0..bar3 by knobs 0..3 and renders the document, on_load at +0x24 finds the bars) with draw and on_load
 * wrapped, so the engine can move more elements and draw over the result (engine_screen_* in engine.h).
 * The case-14 picker points the iter entry at this object while the slot plays this engine. */
#define SCREEN_CTOR ((void (*)(void *, int, const char *))0x01A3BAB0)
#define DOC_LOAD ((void *(*)(void *))0x01A503D8)
#define ITER_SCREEN_VTABLE ((const uint32_t *)0x019103FCu)
#define SCREEN_ENTRY (*(void *volatile *)0x01DF4EA4)
#define CANVAS ((void *(*)(void))0x01A3B490)
#define CUR_SLOT (*(const volatile uint32_t *)0xFF8016D4 & 7)
#define SLOT_KNOB4(s) (((const volatile int16_t *)(0xFF8013C4u + (s) * 16))[4])

typedef int (*draw_fn)(void *, int);
typedef void (*load_fn)(void *);

static uint32_t screen_obj[OP1R_MAX_ENGINES][0x80 / 4];
static uint32_t screen_vtable[OP1R_MAX_ENGINES][10];
static uint8_t screen_ok[OP1R_MAX_ENGINES];

static int screen_engine(const void *obj)
{
    return (int)(((const uint32_t *)obj - screen_obj[0]) / (0x80 / 4));
}

static int screen_draw(void *obj, int arg)
{
    const op1r_engine *e = &op1r_engines[screen_engine(obj)];
    e->screen_animate(obj);
    const int r = ((draw_fn)ITER_SCREEN_VTABLE[0x1C / 4])(obj, arg);
    e->screen_draw(obj, CANVAS());
    return r;
}

static void screen_on_load(void *obj)
{
    ((load_fn)ITER_SCREEN_VTABLE[0x24 / 4])(obj);
    op1r_engines[screen_engine(obj)].screen_load(obj);
}

/* effect screens: id 0xB, table entry 0x01DF4E80 */
#define FX_SCREEN_ENTRY (*(void *volatile *)0x01DF4E80)
static uint32_t fx_screen_obj[OP1R_MAX_FX][0x80 / 4];
static uint32_t fx_screen_vtable[OP1R_MAX_FX][10];
static uint8_t fx_screen_ok[OP1R_MAX_FX];

static int fx_screen_index(const void *obj)
{
    return (int)(((const uint32_t *)obj - fx_screen_obj[0]) / (0x80 / 4));
}

static int fx_screen_draw(void *obj, int arg)
{
    const op1r_fx *e = &op1r_fxs[fx_screen_index(obj)];
    e->screen_animate(obj);
    const int r = ((draw_fn)ITER_SCREEN_VTABLE[0x1C / 4])(obj, arg);
    e->screen_draw(obj, CANVAS());
    return r;
}

static void fx_screen_on_load(void *obj)
{
    ((load_fn)ITER_SCREEN_VTABLE[0x24 / 4])(obj);
    op1r_fxs[fx_screen_index(obj)].screen_load(obj);
}

/* the FX params block of the screen being edited: master, drum or synth slot (as op1r's 0x01E0023C) */
static const int16_t *fx_edit_params(void)
{
    const uint32_t mode = *(const volatile uint32_t *)0x01DF4E3C;
    if (mode == 3) return (const int16_t *)0xFF8016C4u;
    if (mode == 1) return (const int16_t *)(0xFF8015C4u + (*(const volatile uint32_t *)0xFF8016D8 & 7) * 16);
    return (const int16_t *)(0xFF801444u + (*(const volatile uint32_t *)0xFF8016D4 & 7) * 16);
}

int op1r_hook_fx_pick(void)
{
    const int e = find_fx(fx_edit_params()[4]);
    if (e >= 0 && e < OP1R_MAX_FX && fx_screen_ok[e]) {
        FX_SCREEN_ENTRY = fx_screen_obj[e];
        return 0xB;
    }
    return op1r_chain_fx_pick();   /* op1r puts the stock or its own screen back */
}

int op1r_hook_screens_init(int a, int b, int c)
{
    const int r = op1r_chain_screens_init(a, b, c);
    for (int e = 0; e < op1r_engine_count && e < OP1R_MAX_ENGINES; e++) {
        void *const saved = SCREEN_ENTRY;
        SCREEN_CTOR(screen_obj[e], 0x14, op1r_engines[e].svg);
        SCREEN_ENTRY = saved;
        for (int i = 0; i < 10; i++) screen_vtable[e][i] = ITER_SCREEN_VTABLE[i];
        screen_vtable[e][0x1C / 4] = (uint32_t)(uintptr_t)screen_draw;
        screen_vtable[e][0x24 / 4] = (uint32_t)(uintptr_t)screen_on_load;
        screen_obj[e][0xC / 4] = (uint32_t)(uintptr_t)screen_vtable[e];
    }
    for (int e = 0; e < op1r_fx_count && e < OP1R_MAX_FX; e++) {
        void *const saved = FX_SCREEN_ENTRY;
        SCREEN_CTOR(fx_screen_obj[e], 0xB, op1r_fxs[e].svg);
        FX_SCREEN_ENTRY = saved;
        for (int i = 0; i < 10; i++) fx_screen_vtable[e][i] = ITER_SCREEN_VTABLE[i];
        fx_screen_vtable[e][0x1C / 4] = (uint32_t)(uintptr_t)fx_screen_draw;
        fx_screen_vtable[e][0x24 / 4] = (uint32_t)(uintptr_t)fx_screen_on_load;
        fx_screen_obj[e][0xC / 4] = (uint32_t)(uintptr_t)fx_screen_vtable[e];
    }
    return r;
}

int op1r_hook_screens_load(int a, int b, int c)
{
    const int r = op1r_chain_screens_load(a, b, c);
    for (int e = 0; e < op1r_engine_count && e < OP1R_MAX_ENGINES; e++) {
        void *doc = screen_obj[e][2] ? DOC_LOAD((void *)screen_obj[e][2]) : 0;
        screen_obj[e][0] = (uint32_t)(uintptr_t)doc;
        if (doc) {
            screen_on_load(screen_obj[e]);
            screen_ok[e] = 1;
        }
    }
    for (int e = 0; e < op1r_fx_count && e < OP1R_MAX_FX; e++) {
        void *doc = fx_screen_obj[e][2] ? DOC_LOAD((void *)fx_screen_obj[e][2]) : 0;
        fx_screen_obj[e][0] = (uint32_t)(uintptr_t)doc;
        if (doc) {
            fx_screen_on_load(fx_screen_obj[e]);
            fx_screen_ok[e] = 1;
        }
    }
    return r;
}

int op1r_hook_pick(void)
{
    const int e = find_engine(SLOT_KNOB4(CUR_SLOT));
    if (e >= 0 && e < OP1R_MAX_ENGINES && screen_ok[e]) {
        SCREEN_ENTRY = screen_obj[e];
        return 0x14;
    }
    return op1r_chain_pick();   /* op1r restores iter's screen for ids it does not know */
}
