/* "hello": two saw/square oscillators, a sub-octave square and a one-pole low-pass.
 * blue   (knob 0): shape, saw -> square
 * green  (knob 1): detune of the second oscillator, up to about half a semitone
 * white  (knob 2): sub-octave level
 * orange (knob 3): brightness (low-pass cutoff)
 */
#include "../engine.h"

typedef struct {
    uint32_t ph1, ph2, sub;
    int32_t lp;
} voice_t;

static voice_t voices[ENGINE_VOICES];

static inline int32_t morph(uint32_t ph, int32_t shape)
{
    const int32_t saw = (int32_t)ph >> 16;
    const int32_t sq = (int32_t)ph < 0 ? -32767 : 32767;
    return saw + (((sq - saw) * (shape >> 1)) >> 14);
}

void engine_note_on(void *self, const int16_t *knobs)
{
    voice_t *v = &voices[ENGINE_VOICE(self)];
    (void)knobs;
    v->ph1 = 0;
    v->ph2 = 0x40000000u;
    v->sub = 0;
    v->lp = 0;
}

void engine_note_off(void *self, const int16_t *knobs)
{
    (void)self;
    (void)knobs;
}

void engine_render(void *self, int16_t *out, const int16_t *knobs)
{
    voice_t *v = &voices[ENGINE_VOICE(self)];
    const int32_t shape = knobs[0], detune = knobs[1], sub = knobs[2];
    const int32_t a = 512 + (knobs[3] >> 1);             /* low-pass coefficient, Q15 */
    uint32_t ph1 = v->ph1, ph2 = v->ph2, ph3 = v->sub;
    int32_t lp = v->lp;
    for (int i = 0; i < ENGINE_BLOCK; i++) {
        const uint32_t inc = ENGINE_PITCH[i];
        ph1 += inc;
        ph2 += inc + (((inc >> 12) * (uint32_t)(detune >> 4)) >> 4);   /* inc * detune / 2^20 */
        ph3 += inc >> 1;
        int32_t mix = (morph(ph1, shape) + morph(ph2, shape)) >> 1;
        const int32_t subsq = (int32_t)ph3 < 0 ? -32767 : 32767;
        mix = (mix * 3 + ((subsq * (sub >> 1)) >> 14)) >> 2;
        lp += ((mix - lp) * a) >> 15;
        out[i] = engine_sat16(lp);
    }
    v->ph1 = ph1;
    v->ph2 = ph2;
    v->sub = ph3;
    v->lp = lp;
}
