#!/usr/bin/env python3
"""Native sustained-note knob audit; writes audio and counterfactual step metrics.

Each rendering runs in a fresh process so random/rotor state is reproducible.
The hold/jump pair is identical until sample 44032. Their first-sample difference
isolates a control discontinuity from the waveform's normal adjacent-sample slope.
These metrics flag review candidates, not universal sound-quality pass thresholds.
No firmware, envelope, CPU cycle budget or hardware stability is tested here.
"""
import argparse
import array
import json
import math
from pathlib import Path
import subprocess
import wave

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--engines", nargs="+", default=["pew", "wavetable", "taffy", "elg"])
    parser.add_argument("--source-root", type=Path, default=ROOT, help="Engine source snapshot to compare")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    report = {"scope": __doc__, "cases": []}
    for engine in args.engines:
        binary = args.output.resolve() / (engine + "-knobtest")
        subprocess.run(["cc", "-O2", "-fwrapv", "-DENGINE_HOST_TEST", "-o", str(binary),
                        str(ROOT / "knobtest.c"), str(args.source_root / engine / (engine + ".c")), "-lm"], check=True)
        for voices, note in [(1, 48), (1, 72), (6, 48)]:
            for knob in range(4):
                renders = []
                for mode, label in enumerate(["hold", "jump", "sweep", "encoder-step"]):
                    stem = f"{engine}-v{voices}-n{note}-k{knob}-{label}"
                    raw = args.output / (stem + ".raw")
                    subprocess.run([str(binary), str(raw), str(mode), str(knob), str(note), str(voices)], check=True)
                    data = raw.read_bytes()
                    with wave.open(str(args.output / (stem + ".wav")), "wb") as wav:
                        wav.setparams((1, 2, 44100, 0, "NONE", "not compressed"))
                        wav.writeframes(data)
                    samples = array.array("h", data)
                    renders.append(samples)
                    raw.unlink()
                hold, jump, sweep, small = renders
                start = 344 * 128
                assert hold[:start] == small[:start]
                assert hold[:start] == jump[:start], "A/B state mismatch before event"
                assert len(sweep) == 1032 * 128
                rms = math.sqrt(sum(x*x for x in sweep[start:]) / len(sweep[start:]))
                # Silent controls are allowed (e.g. a spent attack envelope); a whole
                # engine silence is not judged by this per-control metric.
                report["cases"].append({
                    "engine": engine, "voices": voices, "note": note, "knob": knob,
                    "encoder_step_first_sample_delta": abs(small[start] - hold[start]),
                    "first_sample_control_delta": abs(jump[start] - hold[start]),
                    "first_block_control_peak": max(abs(a-b) for a, b in zip(jump[start:start+128], hold[start:start+128])),
                    "sweep_rms": rms, "sweep_peak": max(abs(x) for x in sweep),
                    "clipped_samples": sum(abs(x) >= 32767 for x in sweep),
                })
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(args.output / "report.json")


if __name__ == "__main__":
    main()
