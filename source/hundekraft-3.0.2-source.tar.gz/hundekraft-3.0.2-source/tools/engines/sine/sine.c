/* "sine": test engine for the emulator's audio path. A 1000 Hz sine, independent of the key played, so
 * discontinuities (repeated, dropped or torn buffers) show up as phase jumps in a recording. */
#include "../engine.h"

static uint32_t phase[ENGINE_VOICES];

void engine_note_on(void *self, const int16_t *knobs)
{
    (void)knobs;
    phase[ENGINE_VOICE(self)] = 0;
}

void engine_note_off(void *self, const int16_t *knobs)
{
    (void)self;
    (void)knobs;
}

void engine_render(void *self, int16_t *out, const int16_t *knobs)
{
    uint32_t ph = phase[ENGINE_VOICE(self)];
    (void)knobs;
    for (int i = 0; i < ENGINE_BLOCK; i++) {
        ph += 97391548u;                                   /* 2^32 * 1000 / 44100 */
        const int32_t x = (int32_t)ph >> 16;               /* -32768..32767 = -pi..pi */
        const int32_t ax = x < 0 ? -x : x;
        out[i] = (int16_t)((x * (32768 - ax)) >> 14 >> 1); /* parabola: 4x(1-|x|), peak ~16384 */
    }
    phase[ENGINE_VOICE(self)] = ph;
}
