/* "probe": test engine for the emulator's audio path. Outputs a xorshift32 noise sequence that restarts at
 * note_on (seed 1). A recording can be matched against the same sequence on the host to show exactly which
 * engine samples were played, repeated or lost (a slow ramp would not survive the output high-pass). */
#include "../engine.h"

static uint32_t state[ENGINE_VOICES];

void engine_note_on(void *self, const int16_t *knobs)
{
    (void)knobs;
    state[ENGINE_VOICE(self)] = 1;
}

void engine_note_off(void *self, const int16_t *knobs)
{
    (void)self;
    (void)knobs;
}

void engine_render(void *self, int16_t *out, const int16_t *knobs)
{
    uint32_t x = state[ENGINE_VOICE(self)];
    (void)knobs;
    for (int i = 0; i < ENGINE_BLOCK; i++) {
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        out[i] = (int16_t)((int32_t)x >> 17);
    }
    state[ENGINE_VOICE(self)] = x;
}
