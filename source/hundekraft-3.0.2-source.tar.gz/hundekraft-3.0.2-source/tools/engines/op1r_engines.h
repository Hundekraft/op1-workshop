/* The engines one op1r_host.c image runs (tools/engines/build.sh generates the table from OP1R="name:marker ..."). */
#ifndef OP1R_ENGINES_H
#define OP1R_ENGINES_H

#include <stdint.h>

#define OP1R_MAX_ENGINES 8

typedef struct {
    uint16_t marker;                 /* knobs[4] of its synth_types row, 0x53nn */
    const char *name;                /* patch type; its screen is content/display/NAME.svg */
    const char *svg;
    void (*note_on)(void *, const int16_t *);
    void (*render)(void *, int16_t *, const int16_t *);
    void (*note_off)(void *, const int16_t *);
    void (*screen_load)(void *);
    void (*screen_animate)(void *);
    void (*screen_draw)(void *, void *);
} op1r_engine;

extern const op1r_engine op1r_engines[];
extern const int op1r_engine_count;



/* Our effects (tools/fx/NAME), run next to op1r's tape/clouds/reverb inside the stock filter FX ("Mmmf", fx enum
 * 5): params[4] holds the marker, as op1r does it. chan 0 = synth instrument, 1 = drum instrument, 2 = master. */
#define OP1R_MAX_FX 8

typedef struct {
    uint16_t marker;
    const char *name;
    const char *svg;
    void (*reset)(int chan);
    void (*process)(int chan, int16_t *io, int n, const int16_t *knobs);   /* knobs 0..3 scaled to 0..32767 */
    void (*screen_load)(void *);
    void (*screen_animate)(void *);
    void (*screen_draw)(void *, void *);
} op1r_fx;

extern const op1r_fx op1r_fxs[];
extern const int op1r_fx_count;
#endif
