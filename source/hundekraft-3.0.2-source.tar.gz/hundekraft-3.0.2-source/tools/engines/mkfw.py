#!/usr/bin/env python3
"""Build an OP-1 R246 firmware package with a custom synth engine in place of the hidden "iter" engine.

    tools/engines/mkfw.py firmware/op1_246.op1 build/engines/hello.elf -o firmware/op1_246-hello.op1

What it changes (see docs/synth-engines.md):
  OP1_vdk.ldr   iter's producer vtable (0x019103CC): render (+0x14), note_on (+0x1C), note_off (+0x2C) point at the
                engine's `engine_render`, `engine_note_on`, `engine_note_off`; the engine's code and data go in one
                new plain LDR block (load address from the ELF, 0x01F00000 by default) right before the FINAL
                block; the first header's length argument and checksum are fixed up.
  content/op1_factory.db   a synth_types row for "iter" so the engine browser lists it (default knobs from
                `--knobs`, 8 values).
Everything else is copied unchanged. Nothing here is encrypted: iter's vtable sits in a plain LDR block.

--op1r NAME:MARKER (once per engine): the input is an op1r firmware (patch_op1.py output). The engines run next
to op1r's engines the way op1r runs its own (tools/engines/op1r_host.c): the three vtable words and the JUMP.L at
0x019B975C (op1r's name alias check) point at op1r_hook_*, op1r's previous targets go into op1r_chain_*, and each
engine gets a synth_types row NAME with knobs[4] = MARKER and, with --svg NAME=FILE, content/display/NAME.svg.

.op1 = CRC32 (LE) + LZMA "alone" stream of a tar archive. Python standard library + bfin-elf binutils only.
"""
import argparse, binascii, copy, io, json, lzma, os, sqlite3, struct, subprocess, sys, tarfile, tempfile

R = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BINUTILS = os.path.join(R, 'toolchain', 'bfin', 'bin')
# op1repacker's settings: the OP-1's updater has limited RAM for the LZMA dictionary
LZMA_FILTERS = [{'id': lzma.FILTER_LZMA1, 'preset': 9, 'lc': 3, 'lp': 1, 'pb': 2, 'dict_size': 2 ** 23}]

ITER_VTABLE = 0x019103CC
VT_SLOTS = {'engine_render': (0x14, 0x019B99D4), 'engine_note_on': (0x1C, 0x019B9B8A),
            'engine_note_off': (0x2C, 0x019B996C)}   # fn word offset, stock value
FREE_LO, FREE_HI = 0x01E00000, 0x02000000          # unused SDRAM in R246 (op1r uses 0x01E00000-0x01E20000)
OP1R_HOOKS = {'op1r_entry_render': 0x14, 'op1r_entry_note_on': 0x1C, 'op1r_entry_note_off': 0x2C}
NAME_EQ = 0x019B975C                               # string equals(); op1r jumps from here to its alias check
SCREENS_INIT = 0x01A3BD58                          # CALL in the screen setup; op1r: builds its engines' screens
SCREENS_LOAD = 0x019F07D2                          # CALL in the document loader; op1r: loads their SVGs
BOOT_TEXT = 0x01A2FCB8                             # R0.L = text, R0.H = text: the version line on the boot screen
PICK_CASE14 = 0x018F8074                           # ScreenId::synth jump table, case 14 (iter); op1r: its picker
OP1R_LO, OP1R_HI = 0x01E00000, 0x01F00000
# effects (op1r hosts its FX in the stock filter FX "Mmmf"): vtable words of its mono and stereo classes
FX_HOOKS = {'op1r_entry_fx_process': 0x01910CA8, 'op1r_entry_fx_init': 0x01910CB0,
            'op1r_entry_fx_st_process': 0x01910CC8, 'op1r_entry_fx_st_reset': 0x01910CD0}
FX_NAME_EQ = 0x019AAD8E                            # FX copy of string equals(); op1r: its "filter" alias
FX_PICK = 0x018F7FF8                               # ScreenId::fx jump table, case 5 (filter); op1r: its picker
# More user synth presets (R246, docs/synth-engines.md 7.2): the user-preset gate "count < 100", the table of all
# synth patches (318 x 56 bytes at 0x01DDDB68: its constructor/destructor counts, the asserts, the ten loads of its
# address) -> the image's op1r_synth_patches with op1r_synth_patch_count entries and op1r_user_synth_cap
SYNTH_CAP_GATE = 0x019FEF02                        # R1 = 0x64 (X): [0x018B610C] (user synthesis presets) < 100
SYNTH_TABLE = 0x01DDDB68
SYNTH_TABLE_COUNT = (0x01A05FFA, 0x01A060A6)       # R1 = 0x13e (X) for the vector constructor / destructor
SYNTH_TABLE_ASSERTS = ((0x01A05996, 100), (0x01A057F8, 318), (0x01A05960, 318))   # log-only checks
SYNTH_TABLE_LOADS = {0: (0x01940030, 0x019407E8, 0x01A05684, 0x01A05FFE, 0x01A060AA),   # Rx.L at pc, Rx.H at pc + 4
                     4: (0x01A020BA, 0x01A021F8, 0x01A024B2, 0x01A027DE, 0x01A054E8)}
FX_DEFAULTS = [7296, 12288, 11264, 20480]          # inside the filter's p0..p3 ranges (checked on patch load)


def ldr_word(d, blocks, a):
    """file offset of guest address a in a plain LDR block"""
    for off, bc, addr, cnt, _ in blocks:
        if not bc & 0x100 and addr <= a < addr + cnt:
            if (bc & 0x2400) == 0x2400:
                fail(f'{a:#x} is in an encrypted block')
            return off + 16 + a - addr
    fail(f'no LDR block holds {a:#x}')


def jump_l(pc, target):
    """JUMP.L target at pc: 0xE2 | imm24[23:16], imm24[15:0]; imm24 = (target - pc) / 2"""
    off = (target - pc) >> 1
    if not -(1 << 23) <= off < (1 << 23):
        fail(f'JUMP.L from {pc:#x} to {target:#x} is out of range')
    off &= 0xFFFFFF
    return struct.pack('<HH', 0xE200 | (off >> 16), off & 0xFFFF)


def call_l(pc, target):
    w = jump_l(pc, target)
    return struct.pack('<H', struct.unpack('<H', w[:2])[0] | 0x0100) + w[2:]   # 0xE3xx: CALL


def jump_l_target(pc, word, op=0xE200):
    hi, lo = struct.unpack('<HH', word)
    if hi & 0xFF00 != op:
        fail(f'{pc:#x} is not a {"CALL" if op == 0xE300 else "JUMP.L"} ({word.hex()})')
    off = ((hi & 0xFF) << 16) | lo
    if off & 0x800000:
        off -= 1 << 24
    return pc + 2 * off


def patch_synth_cap(d, blocks, image, load, syms):
    """Raise the user synth preset cap and move the synth patch table into the image (constants checked first)."""
    count = struct.unpack_from('<i', image, syms['op1r_synth_patch_count'] - load)[0]
    cap = struct.unpack_from('<i', image, syms['op1r_user_synth_cap'] - load)[0]
    return patch_synth_table(d, blocks, syms['op1r_synth_patches'], count, cap)


def patch_synth_table(d, blocks, table, count, cap):
    """patch_synth_cap with the table address, entry count and user preset cap given directly"""
    def imm(d, pc, old, new):   # 32-bit instruction with a 16-bit immediate in its second half
        p = ldr_word(d, blocks, pc)
        if struct.unpack_from('<H', d, p + 2)[0] != old & 0xFFFF:
            fail(f'{pc:#x}: expected immediate {old & 0xFFFF:#x}, found {d[p:p + 4].hex()}')
        return d[:p + 2] + struct.pack('<H', new & 0xFFFF) + d[p + 4:]

    if not 318 <= count < 0x8000 or not 100 <= cap < 0x8000 or table % 4:
        fail(f'synth table: count {count}, cap {cap}, address {table:#x}')
    d = imm(d, SYNTH_CAP_GATE, 100, cap)
    for pc in SYNTH_TABLE_COUNT:
        d = imm(d, pc, 318, count)
    for pc, old in SYNTH_TABLE_ASSERTS:
        d = imm(d, pc, old, cap if old == 100 else count)
    for delta, pcs in SYNTH_TABLE_LOADS.items():
        for pc in pcs:
            d = imm(d, pc, SYNTH_TABLE + delta, table + delta)
            d = imm(d, pc + 4, (SYNTH_TABLE + delta) >> 16, (table + delta) >> 16)
    print(f'user synth presets: up to {cap} (table of {count} entries at {table:#x})')
    return d


def patch_ldr_op1r(d, image, load, syms):
    """Point R246's hook words at op1r_hook_* and store op1r's targets in the image's op1r_chain_* words."""
    blocks = ldr_blocks(d)
    image = bytearray(image)

    def chain(sym, value):
        if not OP1R_LO <= value < OP1R_HI:
            fail(f'{sym}: op1r target {value:#x} is outside op1r\'s code; is the input an op1r firmware?')
        struct.pack_into('<I', image, syms[sym] - load, value)

    for hook, slot in OP1R_HOOKS.items():
        p = ldr_word(d, blocks, ITER_VTABLE + slot)
        chain(hook.replace('entry', 'chain'), struct.unpack_from('<I', d, p)[0])
        d = d[:p] + struct.pack('<I', syms[hook]) + d[p + 4:]
    p = ldr_word(d, blocks, NAME_EQ)
    chain('op1r_chain_name_eq', jump_l_target(NAME_EQ, d[p:p + 4]))
    d = d[:p] + jump_l(NAME_EQ, syms['op1r_entry_name_eq']) + d[p + 4:]
    if 'op1r_entry_pick' in syms:   # the engine's own screen
        for pc, ent, ch in ((SCREENS_INIT, 'op1r_entry_screens_init', 'op1r_chain_screens_init'),
                            (SCREENS_LOAD, 'op1r_entry_screens_load', 'op1r_chain_screens_load')):
            p = ldr_word(d, blocks, pc)
            chain(ch, jump_l_target(pc, d[p:p + 4], 0xE300))
            d = d[:p] + call_l(pc, syms[ent]) + d[p + 4:]
        p = ldr_word(d, blocks, PICK_CASE14)
        tramp = struct.unpack_from('<I', d, p)[0]          # op1r's case code: CALL picker; return its result
        q = ldr_word(d, blocks, tramp)
        chain('op1r_chain_pick', jump_l_target(tramp, d[q:q + 4], 0xE300))
        d = d[:p] + struct.pack('<I', syms['op1r_entry_pick']) + d[p + 4:]
    if 'op1r_entry_fx_process' in syms:   # effects
        for hook, word in FX_HOOKS.items():
            p = ldr_word(d, blocks, word)
            chain(hook.replace('entry', 'chain'), struct.unpack_from('<I', d, p)[0])
            d = d[:p] + struct.pack('<I', syms[hook]) + d[p + 4:]
        p = ldr_word(d, blocks, FX_NAME_EQ)
        chain('op1r_chain_fx_name_eq', jump_l_target(FX_NAME_EQ, d[p:p + 4]))
        d = d[:p] + jump_l(FX_NAME_EQ, syms['op1r_entry_fx_name_eq']) + d[p + 4:]
        p = ldr_word(d, blocks, FX_PICK)
        tramp = struct.unpack_from('<I', d, p)[0]          # op1r's case code: CALL picker; return its result
        q = ldr_word(d, blocks, tramp)
        chain('op1r_chain_fx_pick', jump_l_target(tramp, d[q:q + 4], 0xE300))
        d = d[:p] + struct.pack('<I', syms['op1r_entry_fx_pick']) + d[p + 4:]
    if 'op1r_synth_patches' in syms:
        d = patch_synth_cap(d, blocks, image, load, syms)
    if 'op1r_boot_text' in syms:   # R0.L = lo; R0.H = hi (two 32-bit loads) -> the image's text
        p = ldr_word(d, blocks, BOOT_TEXT)
        q = ldr_word(d, blocks, BOOT_TEXT + 4)
        if d[p:p + 2] != b'\x00\xe1' or d[q:q + 2] != b'\x40\xe1':
            fail(f'{BOOT_TEXT:#x}: not the boot text load ({d[p:p + 4].hex()} {d[q:q + 4].hex()})')
        t = syms['op1r_boot_text']
        d = d[:p + 2] + struct.pack('<H', t & 0xFFFF) + d[p + 4:]
        d = d[:q + 2] + struct.pack('<H', t >> 16) + d[q + 4:]
    final = [b for b in blocks if b[1] & 0x8000]
    if len(final) != 1:
        fail('OP1_vdk.ldr: expected exactly one FINAL block')
    image = bytes(image)
    pad = (-len(image)) % 4
    blob = header(0x0006, load, len(image) + pad, 0) + image + b'\0' * pad
    at = final[0][0]
    d = d[:at] + blob + d[at:]
    return fix_first_header(d), image


def fail(msg):
    sys.exit('mkfw: ' + msg)


def ldr_blocks(d):
    off, out = 0, []
    while off + 16 <= len(d):
        bc, addr, cnt, arg = struct.unpack_from('<IIII', d, off)
        out.append((off, bc, addr, cnt, arg))
        off += 16 + (0 if bc & 0x100 else cnt)
    if off != len(d):
        fail('OP1_vdk.ldr: block chain does not end at the end of the file')
    return out


def header(bc_flags, addr, cnt, arg):
    """16-byte BF52x block header; HDRCHK (bits 23:16) makes the XOR of all header bytes zero."""
    h = bytearray(struct.pack('<IIII', 0xAD000000 | bc_flags, addr, cnt, arg))
    x = 0
    for b in h:
        x ^= b
    h[2] = x
    return bytes(h)


def fix_first_header(d):
    bc, addr, cnt, _ = struct.unpack_from('<IIII', d, 0)
    if not bc & 0x4000:
        fail('OP1_vdk.ldr: first block is not a FIRST block')
    return header(bc & 0xFFFF, addr, cnt, len(d) - 16) + d[16:]


def patch_ldr(d, image, load, syms):
    blocks = ldr_blocks(d)
    # vtable words live in a plain block's payload
    for name, (slot, stock) in VT_SLOTS.items():
        a = ITER_VTABLE + slot
        for off, bc, addr, cnt, _ in blocks:
            if not bc & 0x100 and addr <= a < addr + cnt:
                if (bc & 0x2400) == 0x2400:
                    fail(f'{a:#x} is in an encrypted block')
                p = off + 16 + a - addr
                old = struct.unpack_from('<I', d, p)[0]
                if old != stock:
                    fail(f'iter vtable +{slot:#x} is {old:#x}, expected stock {stock:#x} (already patched?)')
                d = d[:p] + struct.pack('<I', syms[name]) + d[p + 4:]
                break
        else:
            fail(f'no LDR block holds {a:#x}')
    final = [b for b in blocks if b[1] & 0x8000]
    if len(final) != 1:
        fail('OP1_vdk.ldr: expected exactly one FINAL block')
    pad = (-len(image)) % 4
    blob = header(0x0006, load, len(image) + pad, 0) + image + b'\0' * pad
    at = final[0][0]
    d = d[:at] + blob + d[at:]
    return fix_first_header(d)


def elf_image(elf):
    """(load address, flat bytes of all allocated sections, {symbol: address}) via bfin-elf binutils"""
    nm = subprocess.run([os.path.join(BINUTILS, 'bfin-elf-nm'), elf], capture_output=True, text=True, check=True)
    syms = {}
    for line in nm.stdout.splitlines():
        parts = line.split()
        if len(parts) == 3:
            name = parts[2][1:] if parts[2].startswith('_') else parts[2]   # C symbols carry one '_' on bfin
            syms[name] = int(parts[0], 16)
    with tempfile.TemporaryDirectory() as td:
        out = os.path.join(td, 'img.bin')
        subprocess.run([os.path.join(BINUTILS, 'bfin-elf-objcopy'), '-O', 'binary', elf, out], check=True)
        image = open(out, 'rb').read()
    load = syms.get('_engine_start')
    if load is None:
        fail('ELF has no __engine_start symbol (use tools/engines/engine.ld)')
    need = list(OP1R_HOOKS) + ['op1r_entry_name_eq'] if 'op1r_entry_render' in syms else list(VT_SLOTS)
    for name in need:
        if name not in syms:
            fail(f'ELF has no {name}')
    if syms.get('_memory_end', load) > FREE_HI:
        fail(f'engine memory ends at {syms["_memory_end"]:#x}, past free SDRAM {FREE_HI:#x}')
    if not (FREE_LO <= load and load + len(image) <= FREE_HI):
        fail(f'engine image {load:#x}+{len(image):#x} is outside free SDRAM {FREE_LO:#x}-{FREE_HI:#x}')
    return load, image, syms


def patch_db(data, knobs):
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, 'f.db')
        open(p, 'wb').write(data)
        c = sqlite3.connect(p)
        if c.execute("SELECT COUNT(*) FROM synth_types WHERE type='iter'").fetchone()[0]:
            fail('op1_factory.db already lists iter')
        nid = c.execute('SELECT MAX(id) FROM synth_types').fetchone()[0] + 1
        c.execute('INSERT INTO synth_types (id, type, default_params) VALUES (?, ?, ?)',
                  (nid, 'iter', json.dumps(knobs)))
        c.commit()
        c.close()
        return open(p, 'rb').read()


def patch_db_fx(data, name, marker):
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, 'f.db')
        open(p, 'wb').write(data)
        c = sqlite3.connect(p)
        if c.execute('SELECT COUNT(*) FROM fx_types WHERE type=?', (name,)).fetchone()[0]:
            fail(f'op1_factory.db already lists the FX {name}')
        nid = c.execute('SELECT MAX(id) FROM fx_types').fetchone()[0] + 1
        c.execute('INSERT INTO fx_types (id, type, default_params) VALUES (?, ?, ?)',
                  (nid, name, json.dumps(FX_DEFAULTS + [marker, 0, 0, 0])))
        c.commit()
        c.close()
        return open(p, 'rb').read()


def patch_db_op1r(data, name, knobs):
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, 'f.db')
        open(p, 'wb').write(data)
        c = sqlite3.connect(p)
        if not c.execute("SELECT COUNT(*) FROM synth_types WHERE type='iter'").fetchone()[0]:
            fail('op1_factory.db has no iter row: not an op1r firmware?')
        if c.execute('SELECT COUNT(*) FROM synth_types WHERE type=?', (name,)).fetchone()[0]:
            fail(f'op1_factory.db already lists {name}')
        nid = c.execute('SELECT MAX(id) FROM synth_types').fetchone()[0] + 1
        c.execute('INSERT INTO synth_types (id, type, default_params) VALUES (?, ?, ?)', (nid, name, json.dumps(knobs)))
        c.commit()
        c.close()
        return open(p, 'rb').read()


def svg_split_paths(text):
    """The firmware's path parser joins a path's subpaths into one line (a stray stroke from the end of one to the
    next M). Each <path> with several M becomes one <path> per subpath, in a <g> that keeps the id if it had one."""
    import re

    def split(m):
        tag = m.group(0)
        d = re.search(r'\bd="([^"]*)"', tag).group(1)
        subs = [x.strip() for x in re.split(r'(?=[Mm])', d) if x.strip()]
        if len(subs) < 2:
            return tag
        idm = re.search(r'\sid="([^"]*)"', tag)
        rest = re.sub(r'\sid="[^"]*"', '', tag)
        paths = ''.join(re.sub(r'\bd="[^"]*"', f'd="{sp}"', rest) for sp in subs)
        return f'<g id="{idm.group(1)}">{paths}</g>' if idm else paths
    return re.sub(r'<path\b[^>]*/>', split, text)


def svg_check_decimals(data, name):
    """R246's SVG parser panics at boot on a number with more than 4 decimals ("Parser.cpp:116 unsupported decimal
    count") and the OP-1 hangs before its first frame. Stock screens use at most 4; Python float noise such as
    1.6500000000000001 has more. Raises ValueError naming the file and the number; returns data unchanged."""
    import re
    m = re.search(rb'\d*\.\d{5,}', data)
    if m:
        raise ValueError(f'{name}: SVG number {m.group().decode()} has more than 4 decimals (R246 halts at boot); round it')
    return data


def svg_with_bases(data, name='screen SVG'):
    """iter's screen class looks up base0..base3 with the firmware's strict lookup (0x01A3B580), which stops the
    OP-1 with an error when an id is missing. Screens without dial hubs get a tiny dot in the bar's colour at
    each bar's pivot, hidden under the bar's end. Where a knob is a moving scene part, its bar goes off-screen."""
    import re
    text = svg_split_paths(data.decode())
    for i in range(4):   # a screen with knob parts (<g id="knobN">) moves them; its hidden barN would stay behind
        if re.search(rf'id="knob{i}"', text):
            text = re.sub(rf'(<line[^>]*id="bar{i}"[^>]*>)', lambda m: re.sub(
                r'\b(x1|y1|x2|y2)="[^"]*"', lambda a: f'{a.group(1)}="{-20 if a.group(1) != "y2" else -21}"',
                m.group(1)), text)
    for i in range(4):
        if re.search(rf'id="base{i}"', text):
            continue
        m = re.search(rf'<line[^>]*id="bar{i}"[^>]*>', text)
        if not m:
            fail(f'screen has no bar{i}')
        tag = m.group(0)
        get = lambda a: re.search(rf'\b{a}="([^"]*)"', tag).group(1)
        dot = (f'<circle id="base{i}" cx="{get("x1")}" cy="{get("y1")}" r="0.5" fill="{get("stroke")}" '
               f'stroke="{get("stroke")}" stroke-width="0.5"/>')
        text = text[:m.start()] + dot + '\n' + text[m.start():]
    return svg_check_decimals(text.encode(), name)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('firmware')
    ap.add_argument('engine_elf')
    ap.add_argument('-o', '--output', help='patched .op1 to write')
    ap.add_argument('--overlay', help='also write an OP1EMU_OVERLAY file (PATH) plus PATH.bin with the engine '
                    'image, to try the engine in op1emu without reinstalling')
    ap.add_argument('--knobs', default='[16384, 8192, 0, 8192, 0, 0, 0, 0]', help='default knobs (JSON, 8 values)')
    ap.add_argument('--op1r', metavar='NAME:MARKER', action='append',
                    help='input is op1r; add the engine NAME next to op1r\'s (repeat for more engines)')
    ap.add_argument('--op1r-fx', metavar='NAME:MARKER', action='append', default=[],
                    help='input is op1r; add the effect NAME next to op1r\'s (repeat for more)')
    ap.add_argument('--svg', metavar='NAME=FILE', action='append', default=[],
                    help='--op1r: the screen of engine NAME (content/display/NAME.svg)')
    a = ap.parse_args()
    knobs = json.loads(a.knobs)
    if len(knobs) != 8:
        fail('--knobs needs 8 values')

    load, image, syms = elf_image(a.engine_elf)
    engines = [(n, int(m, 0)) for n, m in (e.split(':') for e in a.op1r or [])]
    effects = [(n, int(m, 0)) for n, m in (e.split(':') for e in a.op1r_fx)]
    svgs = dict(x.split('=', 1) for x in a.svg)
    if a.overlay and not a.op1r:
        open(a.overlay + '.bin', 'wb').write(image)
        with open(a.overlay, 'w') as f:
            f.write(f'# {a.engine_elf}\nload {load:x} {os.path.abspath(a.overlay)}.bin\n')
            for name, (slot, _) in VT_SLOTS.items():
                f.write(f'word {ITER_VTABLE + slot:x} {syms[name]:x}\n')
        print(f'{a.overlay}: overlay for OP1EMU_OVERLAY')
    if not a.output:
        return

    op1 = open(a.firmware, 'rb').read()
    if struct.unpack('<L', op1[:4])[0] != binascii.crc32(op1[4:]):
        fail('input CRC mismatch')
    raw = lzma.decompress(op1[4:], format=lzma.FORMAT_ALONE)
    members = []
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        for m in t.getmembers():
            members.append((m, t.extractfile(m).read() if m.isfile() else None))
    idx = {m.name: i for i, (m, _) in enumerate(members)}

    i = idx['OP1_vdk.ldr']
    if a.op1r:
        ldr, image = patch_ldr_op1r(members[i][1], image, load, syms)
        members[i] = (members[i][0], ldr)
        if a.overlay:   # the engine image with op1r's chain targets filled in; the hook words are in the NAND
            open(a.overlay + '.bin', 'wb').write(image)
            with open(a.overlay, 'w') as f:
                f.write(f'# {a.engine_elf} (op1r)\nload {load:x} {os.path.abspath(a.overlay)}.bin\n')
            print(f'{a.overlay}: overlay for OP1EMU_OVERLAY (engine image only)')
        i = idx['content/op1_factory.db']
        for name, marker in engines:
            knobs[4] = marker
            members[i] = (members[i][0], patch_db_op1r(members[i][1], name, knobs))
        for name, marker in effects:
            members[i] = (members[i][0], patch_db_fx(members[i][1], name, marker))
        if 'op1r_entry_pick' in syms:
            ref = members[idx['content/display/iter.svg']][0]
            for name, _ in engines + effects:
                if name not in svgs:
                    fail(f'the engines have their own screens: pass --svg {name}=FILE')
                info = copy.copy(ref)
                info.name = f'content/display/{name}.svg'
                members.insert(idx['content/display/iter.svg'] + 1, (info, svg_with_bases(open(svgs[name], 'rb').read(), svgs[name])))
    else:
        members[i] = (members[i][0], patch_ldr(members[i][1], image, load, syms))
        i = idx['content/op1_factory.db']
        members[i] = (members[i][0], patch_db(members[i][1], knobs))

    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w', format=tarfile.GNU_FORMAT) as t:
        for info, data in members:
            info = copy.copy(info)
            if data is not None:
                info.size = len(data)
                t.addfile(info, io.BytesIO(data))
            else:
                t.addfile(info)
    comp = lzma.compress(buf.getvalue(), format=lzma.FORMAT_ALONE, filters=LZMA_FILTERS)
    open(a.output, 'wb').write(struct.pack('<L', binascii.crc32(comp)) + comp)
    if engines:
        print(f'{a.output}: engines {len(image)} bytes at {load:#x}; next to op1r: '
              + ', '.join(f'{n} ({m:#x})' for n, m in engines)
              + (', effects ' + ', '.join(f'{n} ({m:#x})' for n, m in effects) if effects else ''))
    else:
        print(f'{a.output}: engine {len(image)} bytes at {load:#x}; render {syms["engine_render"]:#x}, '
              f'note_on {syms["engine_note_on"]:#x}, note_off {syms["engine_note_off"]:#x}')


if __name__ == '__main__':
    main()
