/* Sustained notes with encoder-sized steps. No envelope, FX or host audio device:
 * captures the engine itself, including the exact sample where a control changes.
 * Called by knob_audit.py; mode: hold, jump, sweep or encoder step. */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "engine.h"

uint32_t engine_host_pitch[128];

int main(int argc, char **argv)
{
    if (argc != 6) return 2;
    FILE *out = fopen(argv[1], "wb");
    if (!out) return 2;
    const int mode = atoi(argv[2]), knob = atoi(argv[3]);
    const int note = atoi(argv[4]), count = atoi(argv[5]);
    if (knob < 0 || knob > 3 || count < 1 || count > 6) return 2;
    const int intervals[6] = {0, 4, 7, 12, 16, 19};
    int16_t knobs[8] = {8192, 8192, 16384, 8192};
    knobs[knob] = 8192;
    for (int v = 0; v < count; v++)
        engine_note_on((void *)(uintptr_t)(0xFFB00000u + v * 36), knobs);
    for (int b = 0; b < 1032; b++) {
        if (mode == 1 && b == 344) knobs[knob] = 24576;
        if (mode == 3 && b == 344) knobs[knob] += 1057;
        if (mode == 2 && b >= 344 && b < 856) {
            int step = (b - 344) / 8;
            knobs[knob] = (int16_t)((step < 32 ? step : 63 - step) * 1057);
        }
        int32_t mix[128] = {0};
        for (int v = 0; v < count; v++) {
            double hz = 440.0 * pow(2.0, (note + intervals[v] - 69) / 12.0);
            uint32_t inc = (uint32_t)(hz * 4294967296.0 / 44100.0 + 0.5);
            for (int i = 0; i < 128; i++) engine_host_pitch[i] = inc;
            int16_t samples[128];
            engine_render((void *)(uintptr_t)(0xFFB00000u + v * 36), samples, knobs);
            for (int i = 0; i < 128; i++) mix[i] += samples[i];
        }
        for (int i = 0; i < 128; i++) {
            int16_t sample = (int16_t)(mix[i] / count);
            fwrite(&sample, 2, 1, out);
        }
    }
    fclose(out);
    return 0;
}
