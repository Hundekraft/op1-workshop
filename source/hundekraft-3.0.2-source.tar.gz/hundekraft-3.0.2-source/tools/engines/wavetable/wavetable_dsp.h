/* Shared wavetable DSP. State and audio inputs belong to the caller; no firmware addresses. */
#ifndef WORKSHOP_WAVETABLE_DSP_H
#define WORKSHOP_WAVETABLE_DSP_H
#include <stdint.h>
#include "wavetables.h"
#define WAVETABLE_BLOCK 128
typedef struct {
    uint32_t ph1, ph2;
    int32_t y1, y2, y3, y4;
    int32_t control[6]; /* previous block: wave position, detune, filter/gain coefficients */
    int control_ready;
} WavetableState;

/* soft clip: 1.5x - 0.5x^3 over +-32767, flat beyond */
static inline int32_t wavetable_soft(int32_t x)
{
    if (x > 32767) x = 32767;
    if (x < -32767) x = -32767;
    return (x * (98304 - ((x * x) >> 15))) >> 16;
}

/* one table at phase ph, linear interpolation between the 256 points */
static inline int32_t wavetable_read(const int16_t *w, uint32_t ph)
{
    const uint32_t i = ph >> 24;
    const int32_t f = (int32_t)((ph >> 9) & 0x7FFF);
    const int32_t a = w[i];
    return a + (((w[i + 1] - a) * f) >> 15);
}

static inline int32_t wavetable_osc(const int16_t *wa, const int16_t *wb, int32_t frac, uint32_t ph)
{
    const int32_t a = wavetable_read(wa, ph);
    return a + (((wavetable_read(wb, ph) - a) * frac) >> 15);
}

static inline void wavetable_dsp_on(WavetableState *v)
{
    v->control_ready = 0;
    v->ph1 = 0;
    v->ph2 = 0x55555555u;
    v->y1 = v->y2 = v->y3 = v->y4 = 0;
}

/* one output sample: oscillators, drive, ladder filter; the caller's ramped or constant controls. Always inlined:
   as a call (gcc's choice with two call sites) its ten arguments cost more than the fast path saves. */
static inline __attribute__((always_inline)) int16_t wavetable_sample(uint32_t *ph1, uint32_t *ph2, int32_t *y, uint32_t inc, int32_t position,
                                       int32_t k1, int32_t g, int32_t k, int32_t drive, int32_t makeup)
{
    const int16_t *wa = wt_waves[position >> 15];
    const int16_t *wb = wt_waves[(position >> 15) + ((position >> 15) < WT_WAVES - 1)];
    const int32_t frac = position & 0x7FFF;
    const uint32_t dd = ((inc >> 7) * (uint32_t)(k1 >> 3)) >> 12;   /* up to inc/128 each way */
    *ph1 += inc - dd;
    *ph2 += inc + dd;
    int32_t x = (wavetable_osc(wa, wb, frac, *ph1) + wavetable_osc(wa, wb, frac, *ph2)) >> 2;   /* +-15000: headroom for drive */
    x = wavetable_soft((x * drive) >> 12);
    const int32_t u = wavetable_soft(x - ((k * y[3]) >> 12));
    y[0] += (g * (u - y[0])) >> 15;
    y[1] += (g * (y[0] - y[1])) >> 15;
    y[2] += (g * (y[1] - y[2])) >> 15;
    y[3] += (g * (y[2] - y[3])) >> 15;
    return (int16_t)wavetable_soft((y[3] * makeup) >> 12);
}

static inline void wavetable_dsp_render(WavetableState *v, int16_t *out,
                                       const int16_t *knobs,
                                       const volatile uint32_t *pitch, int vel)
{
    if (vel < 1 || vel > 127) vel = 100;
    const int32_t k0 = knobs[0] < 0 ? 0 : knobs[0];
    const int32_t k1 = knobs[1] < 0 ? 0 : knobs[1];
    const int32_t k2 = knobs[2] < 0 ? 0 : knobs[2];
    const int32_t k3 = knobs[3] < 0 ? 0 : knobs[3];

    const int32_t pos = k0 * (WT_WAVES - 1);              /* wave index in the high bits, Q15 fraction */

    const int32_t ci = k2 * WT_CUTOFFS;                   /* cutoff table index, Q15 fraction */
    const int32_t g0 = wt_cutoff[ci >> 15];
    const int32_t g = g0 + (((wt_cutoff[(ci >> 15) + 1] - g0) * (ci & 0x7FFF)) >> 15);
    const int32_t k = (k3 * 15974) >> 15;                 /* resonance, Q12, up to ~3.9 */
    const int32_t drive = 4096 + (k3 * 3 >> 3);           /* Q12, 1x to ~4x */
    /* output gain, Q12: 0.75x (resonance thins the passband, so up to ~1x) times velocity / 127; TE's voice level,
       so chords stay under the voice-sum bus's rail */
    const int32_t makeup = (((3072 + (k >> 2)) * vel) >> 7);

    /* Ramp derived coefficients, not filter state. No exp/table setup in the sample loop. */
    const int32_t target[6] = {pos, k1, g, k, drive, makeup};
    int32_t control[6], delta[6];
    for (int j = 0; j < 6; j++) {
        const int32_t previous = v->control_ready ? v->control[j] : target[j];
        control[j] = previous * WAVETABLE_BLOCK;
        delta[j] = target[j] - previous;
        v->control[j] = target[j];
    }
    v->control_ready = 1;
    uint32_t ph1 = v->ph1, ph2 = v->ph2;
    int32_t y[4] = {v->y1, v->y2, v->y3, v->y4};
    if (!(delta[0] | delta[1] | delta[2] | delta[3] | delta[4] | delta[5])) {
        /* knobs unchanged (the usual case): the controls are constant over the block; same samples as the ramp */
        const int32_t position = control[0] >> 7, k1 = control[1] >> 7, g = control[2] >> 7;
        const int32_t k = control[3] >> 7, drive = control[4] >> 7, makeup = control[5] >> 7;
        for (int i = 0; i < WAVETABLE_BLOCK; i++)
            out[i] = wavetable_sample(&ph1, &ph2, y, pitch[i], position, k1, g, k, drive, makeup);
    } else {
        for (int i = 0; i < WAVETABLE_BLOCK; i++) {
            out[i] = wavetable_sample(&ph1, &ph2, y, pitch[i], control[0] >> 7, control[1] >> 7, control[2] >> 7,
                                      control[3] >> 7, control[4] >> 7, control[5] >> 7);
            for (int j = 0; j < 6; j++) control[j] += delta[j];
        }
    }
    v->ph1 = ph1;
    v->ph2 = ph2;
    v->y1 = y[0];
    v->y2 = y[1];
    v->y3 = y[2];
    v->y4 = y[3];
}

/* the morphed wave at knob position k0 (0..32767) and phase ph, for the screen's conveyor belt */
static inline int32_t wavetable_dsp_shape(int32_t k0, uint32_t ph)
{
    const int32_t pos = (k0 < 0 ? 0 : k0) * (WT_WAVES - 1);
    const int16_t *wa = wt_waves[pos >> 15];
    const int16_t *wb = wt_waves[(pos >> 15) + ((pos >> 15) < WT_WAVES - 1)];
    return wavetable_osc(wa, wb, pos & 0x7FFF, ph);
}

#endif
