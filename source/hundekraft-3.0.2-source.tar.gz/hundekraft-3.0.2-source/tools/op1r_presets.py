#!/usr/bin/env python3
"""Synth presets for op1r's custom engines (supersaw, fmbell, granular) and our wavetable engine as OP-1 patch files.

An OP-1 synth patch is an AIFC file (16-bit mono, 44.1 kHz, 'sowt') with an APPL chunk holding "op-1" + JSON
and an SSND chunk. op1r stores its engines as their own type name with a marker in knobs[4]
(0x5301 supersaw, 0x5302 fmbell, 0x5303 granular; our engines from tools/engines, 0x5304 wavetable, 0x5305 taffy,
0x5306 pew, 0x5307 elg, which only a firmware built with them in OP1R knows), the same as the firmware writes when it saves a slot.
Ordinary patches carry a 1 s preview; these carry none (the firmware renders one when it syncs).
Values outside what the firmware accepts make it import the file as a plain sampler sample when it syncs
after disk mode, so every value is checked against the range the 169 factory presets use (RANGE_*).
op1r's granular engine granulates the sample already in the slot (the sampler's buffer, or a recording made
with the input key on a granular slot); a patch cannot bring its own, since the firmware keeps only the
preview when it syncs. So the granular presets are settings: load a sample first, then the preset.

Usage: tools/op1r_presets.py [--no-granular] OUT_DIR   -> OUT_DIR/{supersaw,fmbell,granular,wavetable,taffy,pew,elg,iter}/*.aif
(112 presets: needs our firmware, which keeps up to 300; stock R246 and plain op1r keep 100, so leave out granular there)
Install: tools/install_presets.sh NAND OUT_DIR/supersaw OUT_DIR/fmbell OUT_DIR/granular [OUT_DIR/wavetable ...]
(our engines' folders only on an image with those engines), or by hand: tools/usbip_msc.py put FOLDER... --dir synth --eject
(with the emulator in disk mode: Shift + COM, T3).
"""
import json
import math
import os
import struct
import sys

RATE = 44100
MARKER = {"supersaw": 0x5301, "fmbell": 0x5302, "granular": 0x5303, "wavetable": 0x5304, "taffy": 0x5305,
          "pew": 0x5306, "elg": 0x5307, "iter": 0}   # iter: TE's hidden engine itself (no marker), op1r's lab screen


def ieee_extended(x):
    """80-bit IEEE 754 extended float, as AIFF's COMM sample rate."""
    if x == 0:
        return b"\0" * 10
    exp = int(math.floor(math.log2(x)))
    mant = int(x / 2 ** exp * 2 ** 63)
    return struct.pack(">HQ", exp + 16383, mant)


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def aifc(meta, samples):
    frames = len(samples)
    comm = struct.pack(">hIh", 1, frames, 16) + ieee_extended(RATE) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    js = json.dumps(meta, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    appl = chunk(b"APPL", b"op-1" + js)
    pcm = struct.pack("<%dh" % frames, *samples)
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + appl
            + chunk(b"SSND", struct.pack(">II", 0, 0) + pcm))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


# Ranges the factory presets use (content/op1_factory.db). Out-of-range values (e.g. ADSR release 20000,
# delay time 14000) made the firmware treat the patch as a raw sample.
RANGE_ADSR = [(64, 16320), (64, 16320), (0, 32767), (64, 16320)]
RANGE_FX = {
    "delay": [(3392, 11200), (4969, 32767), (0, 16384), (1332, 32767)],
    "spring": [(1344, 16448), (9920, 16448), (0, 16384), (2047, 26120)],
    "phone": [(8286, 20480), (3072, 3968), (1536, 7776), (7168, 17408)],
    "nitro": [(64, 5952), (-31744, 23552), (0, 20643), (6976, 16448)],
    "cwo": [(0, 22527), (0, 29055), (0, 32767), (0, 32767)],
    "grid": [(1344, 12824), (1344, 13752), (13392, 28165), (6854, 32767)],
    "punch": [(5672, 11538), (0, 28315), (5952, 25088), (13569, 32767)],
    # our effects live in the stock filter FX (fx enum 5); its ranges, dumped from the running firmware
    "washer": [(64, 14528), (0, 24576), (0, 22528), (8192, 32767)],
    "snowglobe": [(64, 14528), (0, 24576), (0, 22528), (8192, 32767)],
}
# Measured in the emulator (docs/synth-engines.md section 7.1): the C4 key plays C3 at octave 0, so octave -1 puts
# the fundamental at C2 (65 Hz) and -2 at C1 (33 Hz), too low to carry a sound; pew's lowest drawbar is 16' (an
# octave under the key), so pew stays at octave 0 or above. (Attack is free: above ~10000 it gets very slow, which
# suits a pad that should swell in, see the doc.)
MIN_OCTAVE = {"pew": 0}
FX_MARKER = {"washer": 0x5304, "snowglobe": 0x5305}   # fx_params[4], as op1r marks its FX


def fxk(name, b, g, w, r):
    """our effect's knobs as fractions 0..1 (blue, green, white, red) -> the filter's raw ranges"""
    return [round(lo + f * (hi - lo)) for f, (lo, hi) in zip((b, g, w, r), RANGE_FX[name])]
RANGE_LFO = {
    "tremolo": [(2289, 29816), (-32767, 32767), (-18663, 32767), (0, 32767)],
    "value": [(0, 12776), (-32767, 32767), (1024, 11264), (1024, 15360)],
    "element": [(1024, 5824), (-19975, 32767), (1024, 7168), (1024, 15360)],
    "random": [(1023, 32767), (7057, 31743), (2000, 5120), (5248, 30129)],
}


def check(name, what, values, ranges):
    for i, (v, (lo, hi)) in enumerate(zip(values, ranges)):
        if not lo <= v <= hi:
            raise ValueError(f"{name}: {what}[{i}] = {v} is outside {lo}..{hi}")


def patch(engine, name, knobs, adsr, fx=None, lfo=None, octave=0):
    """knobs: the engine's four encoder values (0..32767). adsr: attack, decay, sustain, release."""
    check(name, "adsr", adsr, RANGE_ADSR)
    if octave < MIN_OCTAVE.get(engine, -1):
        raise ValueError(f"{name}: octave {octave} < {MIN_OCTAVE.get(engine, -1)} (fundamental below ~65 Hz)")
    if fx:
        check(name, "fx " + fx[0], fx[1], RANGE_FX[fx[0]])
    if lfo:
        check(name, "lfo " + lfo[0], lfo[1], RANGE_LFO[lfo[0]])
    meta = {
        "adsr": list(adsr) + [2048, 5568, 4000, 4000],
        "fx_active": fx is not None,
        "fx_params": (fx or ("delay", [8000] * 4))[1] + [FX_MARKER.get((fx or ("",))[0], 0), 0, 0, 0],
        "fx_type": (fx or ("delay", None))[0],
        "knobs": list(knobs) + [MARKER[engine], 0, 0, 0],
        "lfo_active": lfo is not None,
        "lfo_params": (lfo or ("tremolo", [16000, 0, 0, 16000]))[1] + [0, 0, 0, 0],
        "lfo_type": (lfo or ("tremolo", None))[0],
        "name": name,
        "octave": octave,
        "synth_version": 2,
        "type": engine,
    }
    return meta


def silence():
    """No preview: the firmware renders its own (~58 KB file) when it syncs the patch; 0 frames is accepted."""
    return []


# ---- the presets ----

def presets():
    out = []
    S, F, G = "supersaw", "fmbell", "granular"
    out.append((patch(S, "saw lead", [20000, 9000, 14000, 6000], [64, 9000, 26000, 6000],
                      fx=("delay", [9000, 14000, 8000, 12000]), lfo=("value", [3000, 4000, 2000, 2000])), silence()))
    out.append((patch(S, "trance pad", [26000, 22000, 9000, 12000], [9000, 12000, 28000, 14000],
                      fx=("spring", [16448, 15000, 2000, 10239]), lfo=("tremolo", [6000, 3000, 2000, 2000])), silence()))
    out.append((patch(S, "saw pluck", [14000, 4000, 20000, 3000], [64, 5200, 0, 4200],
                      fx=("delay", [6000, 18000, 9000, 9000])), silence()))
    out.append((patch(S, "big bass", [8000, 2000, 6000, 1500], [64, 7000, 20000, 2500],
                      fx=("nitro", [64, 5120, 20643, 8320]), octave=-1), silence()))
    out.append((patch(F, "glass bell", [9000, 14000, 6000, 10000], [64, 14000, 0, 12000],
                      fx=("spring", [16448, 15000, 2000, 10239])), silence()))
    out.append((patch(F, "church", [4000, 22000, 12000, 18000], [64, 16000, 4000, 16000],
                      fx=("delay", [10000, 22000, 8000, 14000])), silence()))
    out.append((patch(F, "toy box", [16000, 8000, 22000, 6000], [64, 6000, 0, 5000],
                      fx=("phone", [10536, 3968, 7776, 17408]), octave=1), silence()))
    out.append((patch(F, "fm keys", [12000, 6000, 9000, 4000], [64, 9000, 12000, 6000],
                      lfo=("tremolo", [4000, 6000, 2000, 2000])), silence()))
    for name, knobs, adsr, fx, lfo in (
        ("choir cloud", [12000, 20000, 16384, 18000], [6000, 12000, 28000, 16000],
         ("spring", [16448, 15000, 2000, 10239]), None),
        ("glass dust", [6000, 6000, 16384, 26000], [2000, 12000, 22000, 16000],
         ("delay", [10000, 20000, 9000, 14000]), ("value", [2000, 6000, 2000, 2000])),
        ("wind", [20000, 28000, 12000, 10000], [9000, 16000, 30000, 16000], None,
         ("tremolo", [2500, 5000, 2000, 2000])),
        ("pluck smear", [3000, 9000, 16384, 22000], [64, 10000, 18000, 9000],
         ("delay", [9000, 16000, 8000, 12000]), None),
    ):
        out.append((patch(G, name, knobs, adsr, fx=fx, lfo=lfo), silence()))
    # second set (8 per engine): name, knobs, adsr, fx, lfo, octave
    more = {
        S: [
            ("hoover", [26000, 30000, 20000, 9000], [400, 9000, 24000, 7000], ("nitro", [2000, 9000, 14000, 12000]),
             ("value", [6000, 9000, 4000, 6000]), 0),
            ("dark saws", [12000, 18000, 6000, 14000], [3000, 12000, 26000, 12000], ("cwo", [6000, 12000, 18000, 20000]),
             ("tremolo", [3000, 4000, 2000, 2000]), 0),
            ("stab", [18000, 6000, 26000, 2000], [64, 3800, 0, 2600], ("punch", [8000, 12000, 15000, 20000]), None, 0),
            ("sub drone", [4000, 26000, 3000, 20000], [8000, 14000, 32767, 16000], ("spring", [8000, 12000, 8000, 12000]),
             ("element", [2000, 9000, 2000, 6000]), -1),
            ("anthem", [22000, 24000, 16000, 10000], [1200, 10000, 28000, 11000], ("delay", [7000, 20000, 9000, 16000]),
             None, 0),
            ("grit lead", [30000, 12000, 28000, 4000], [64, 7000, 20000, 5000], ("grid", [6000, 8000, 20000, 18000]),
             ("value", [4000, -12000, 3000, 5000]), 1),
            ("swell", [16000, 20000, 12000, 16000], [10000, 14000, 30000, 15000], ("delay", [10000, 26000, 6000, 20000]),
             ("tremolo", [12000, 6000, 2000, 2000]), 0),
            ("bit bass", [9000, 4000, 30000, 1000], [64, 6000, 14000, 3000], ("nitro", [500, 2000, 16000, 9000]),
             None, -1),
        ],
        F: [
            ("music box", [20000, 6000, 26000, 3000], [64, 9000, 0, 9000], ("spring", [4000, 14000, 4000, 8000]),
             None, 1),
            ("gong", [2000, 28000, 8000, 26000], [64, 16000, 2000, 16000], ("delay", [11000, 24000, 6000, 18000]),
             None, -1),
            ("e piano", [10000, 4000, 12000, 6000], [64, 11000, 9000, 7000], ("cwo", [3000, 8000, 12000, 16000]),
             ("tremolo", [5000, 9000, 2000, 2000]), 0),
            ("marimba", [14000, 2000, 16000, 1500], [64, 5000, 0, 4000], ("punch", [6000, 8000, 12000, 18000]), None, 0),
            ("temple", [6000, 18000, 20000, 12000], [64, 14000, 3000, 14000], ("spring", [16000, 16000, 12000, 20000]),
             ("value", [1500, 5000, 2000, 2000]), 0),
            ("metal pad", [8000, 24000, 30000, 20000], [10000, 12000, 26000, 15000], ("delay", [9000, 22000, 12000, 20000]),
             ("element", [3000, 12000, 3000, 9000]), 0),
            ("chimes", [24000, 12000, 6000, 18000], [64, 15000, 0, 15000], ("grid", [4000, 6000, 18000, 16000]),
             ("random", [6000, 12000, 3000, 9000]), 1),
            ("fm bass", [16000, 8000, 4000, 2000], [64, 7000, 12000, 3000], ("nitro", [1500, 4000, 12000, 10000]),
             None, -1),
        ],
        G: [
            ("shimmer", [9000, 22000, 24000, 20000], [8000, 12000, 30000, 16000], ("spring", [16448, 16448, 14000, 24000]),
             None),
            ("stutter", [4000, 2000, 16384, 30000], [64, 6000, 26000, 4000], ("delay", [5000, 18000, 4000, 12000]),
             ("tremolo", [20000, 12000, 2000, 2000])),
            ("frozen", [16384, 30000, 16384, 6000], [9000, 16000, 32767, 16000], None, None),
            ("octave up", [12000, 12000, 26000, 16000], [2000, 12000, 24000, 12000], ("delay", [8000, 16000, 8000, 14000]),
             None),
            ("drift", [20000, 16000, 14000, 12000], [10000, 14000, 28000, 15000], None,
             ("element", [1500, 9000, 2000, 6000])),
            ("dust", [26000, 4000, 16384, 32767], [64, 9000, 20000, 9000], ("phone", [12000, 3500, 4000, 12000]),
             ("random", [9000, 9000, 2500, 8000])),
            ("dark cloud", [8000, 26000, 6000, 14000], [9000, 14000, 30000, 16000], ("cwo", [5000, 10000, 20000, 24000]),
             None),
            ("scrub", [16384, 6000, 16384, 20000], [64, 8000, 22000, 7000], None, ("value", [8000, 20000, 3000, 6000])),
        ],
    }
    # wavetable knobs: blue wave position (0 sine, 4681 warm, 9362 triangle, 14043 saw, 18724 square, 23405 pulse,
    # 28086 vocal, 32767 digital, morphing in between), green detune (0..~14 cents), white cutoff (30 Hz..16 kHz,
    # exponential), red resonance with drive (self-oscillates near the top)
    more["wavetable"] = [
        ("warm pad", [6000, 14000, 15000, 6000], [9000, 12000, 28000, 14000], ("spring", [16448, 15000, 2000, 10239]),
         ("tremolo", [5000, 3000, 2000, 2000]), 0),
        ("acid", [14043, 1500, 9000, 26000], [64, 5000, 8000, 2500], ("delay", [6000, 16000, 9000, 10000]),
         ("value", [6000, 8000, 3000, 3000]), -1),
        ("square lead", [18724, 6000, 24000, 9000], [64, 8000, 24000, 6000], ("delay", [9000, 14000, 8000, 12000]),
         None, 0),
        ("vox", [28086, 9000, 20000, 12000], [3000, 10000, 26000, 10000], ("spring", [12000, 14000, 6000, 12000]),
         ("element", [2000, 9000, 2000, 6000]), 0),
        ("sub bass", [2000, 2000, 7000, 4000], [64, 6000, 26000, 2500], ("nitro", [1000, 3000, 14000, 9000]), None, -1),
        ("digital bell", [32767, 3000, 28000, 8000], [64, 12000, 0, 11000], ("delay", [10000, 20000, 8000, 14000]),
         None, 1),
        ("pwm strings", [21000, 20000, 18000, 4000], [7000, 12000, 28000, 13000], ("spring", [16448, 16000, 10000, 20000]),
         ("tremolo", [3000, 5000, 2000, 2000]), 0),
        ("reso sweep", [11000, 10000, 6000, 28000], [6000, 14000, 30000, 14000], ("delay", [11000, 22000, 6000, 16000]),
         ("value", [1500, 20000, 3000, 6000]), 0),
        ("pluck", [9362, 5000, 16000, 14000], [64, 4200, 0, 3500], ("delay", [6000, 18000, 9000, 9000]), None, 0),
        ("morph pad", [16000, 16000, 14000, 10000], [10000, 14000, 30000, 16000], ("cwo", [6000, 12000, 18000, 20000]),
         ("element", [1500, 14000, 1024, 15360]), 0),
        ("fat brass", [13000, 22000, 13000, 7000], [1500, 9000, 22000, 6000], ("punch", [7000, 10000, 14000, 20000]),
         None, 0),
        ("whistle", [0, 1000, 30000, 31000], [2000, 9000, 24000, 8000], ("delay", [9000, 16000, 8000, 12000]),
         ("tremolo", [9000, 4000, 2000, 2000]), 1),
    ]
    # taffy knobs: blue wave (0 saw, 10923 square, 21845 pulse, 32767 saw-pulse, morphing between), green
    # distortion, white envelope depth (extra distortion at each note's start), red resonance (CZ resonant wave)
    more["taffy"] = [
        ("cz brass", [0, 9000, 22000, 0], [1500, 9000, 24000, 6000], ("delay", [8000, 14000, 8000, 12000]), None, 0),
        ("cz bass", [0, 14000, 26000, 4000], [64, 6000, 14000, 2500], ("nitro", [1000, 3000, 14000, 9000]), None, -1),
        ("reso sweep", [0, 6000, 30000, 30000], [64, 9000, 20000, 6000], ("delay", [10000, 20000, 8000, 14000]),
         None, -1),
        ("hollow pad", [10923, 8000, 6000, 0], [9000, 12000, 28000, 14000], ("spring", [16448, 15000, 2000, 10239]),
         ("tremolo", [5000, 3000, 2000, 2000]), 0),
        ("pulse lead", [21845, 18000, 10000, 0], [64, 8000, 26000, 6000], ("delay", [9000, 16000, 8000, 12000]),
         ("value", [3000, 4000, 2000, 2000]), 0),
        ("clav", [27000, 22000, 24000, 6000], [64, 7000, 0, 4000], ("punch", [6000, 8000, 12000, 18000]), None, 0),
        ("taffy pluck", [5000, 4000, 32767, 12000], [64, 6000, 0, 4500], ("delay", [6000, 18000, 9000, 9000]), None, 1),
        ("vox reso", [16000, 10000, 8000, 20000], [6000, 12000, 26000, 12000], ("spring", [12000, 14000, 6000, 12000]),
         ("element", [2000, 9000, 2000, 6000]), 0),
        ("chewy bass", [32767, 12000, 20000, 8000], [64, 7000, 16000, 3000], ("cwo", [3000, 8000, 12000, 16000]),
         None, -1),
        ("glass keys", [0, 3000, 16000, 26000], [64, 11000, 6000, 9000], ("spring", [8000, 12000, 8000, 12000]),
         None, 1),
        ("square org", [10923, 3000, 0, 0], [400, 9000, 30000, 4000], ("spring", [16448, 16448, 14000, 24000]),
         None, 0),
        ("sugar rush", [24000, 26000, 30000, 16000], [64, 6000, 18000, 5000], ("grid", [6000, 8000, 20000, 18000]),
         ("random", [9000, 9000, 2500, 8000]), 0),
    ]
    # pew knobs: blue low drawbars (16', 8', 5 1/3'), green middle (4', 2 2/3', 2'), white high (1 3/5', 1 1/3',
    # 1', plus key click), red rotor speed (slow ~0.7 Hz .. fast ~6.7 Hz)
    more["pew"] = [
        ("sunday", [32767, 20000, 4000, 4000], [64, 9000, 32767, 4000], ("spring", [16448, 15000, 2000, 10239]),
         None, 0),
        ("gospel", [32767, 32767, 12000, 30000], [64, 9000, 32767, 3000], None, None, 0),
        ("jazz", [26000, 8000, 0, 12000], [64, 9000, 32767, 2500], None, None, 0),
        ("full stop", [32767, 32767, 32767, 32767], [64, 9000, 32767, 3000], ("nitro", [500, 2000, 16000, 9000]),
         None, 0),
        ("flute", [0, 26000, 0, 6000], [800, 9000, 30000, 5000], ("spring", [12000, 14000, 6000, 12000]), None, 1),
        ("bass pedal", [32767, 0, 0, 2000], [64, 9000, 30000, 2500], None, None, 0),
        ("whistle stop", [0, 0, 32767, 20000], [64, 9000, 30000, 4000], ("delay", [9000, 16000, 8000, 12000]),
         None, 1),
        ("funeral", [32767, 12000, 0, 0], [3000, 12000, 30000, 14000], ("spring", [16448, 16448, 14000, 24000]),
         None, 0),
        ("rock organ", [32767, 24000, 20000, 32767], [64, 9000, 32767, 2500], ("nitro", [1500, 4000, 12000, 10000]),
         None, 0),
        ("church mouse", [6000, 20000, 26000, 8000], [64, 6000, 12000, 4000], ("phone", [10536, 3968, 7776, 17408]),
         None, 1),
        ("drawbar pad", [20000, 20000, 8000, 16000], [9000, 12000, 30000, 14000], ("delay", [11000, 22000, 6000, 16000]),
         ("tremolo", [3000, 5000, 2000, 2000]), 0),
        ("theatre", [28000, 16000, 24000, 22000], [64, 9000, 32767, 5000], ("spring", [16448, 15000, 2000, 10239]),
         ("value", [1500, 5000, 2000, 2000]), 0),
    ]
    # elg knobs: blue the third voice's interval (0 unison, 6554 fifth, 13107 octave, 19661 octave + fifth,
    # 26214 two octaves), green detune (beating), white timbre (cutoff and growl), red movement (LFO, drift)
    more["elg"] = [
        ("moose call", [6554, 9000, 14000, 12000], [9000, 12000, 30000, 16000], ("spring", [16448, 15000, 2000, 10239]),
         None, -1),
        ("tundra", [13107, 6000, 6000, 20000], [9000, 14000, 32767, 16000], ("delay", [11000, 22000, 6000, 16000]),
         None, -1),
        ("rumen", [0, 14000, 20000, 6000], [6000, 12000, 30000, 14000], ("nitro", [1000, 3000, 14000, 9000]), None, -1),
        ("northern light", [19661, 12000, 12000, 30000], [9000, 14000, 32767, 16000],
         ("spring", [16448, 16448, 14000, 24000]), ("tremolo", [2500, 5000, 2000, 2000]), 0),
        ("bog", [6554, 20000, 4000, 16000], [9000, 14000, 30000, 16000], ("cwo", [5000, 10000, 20000, 24000]), None, -1),
        ("antler", [26214, 4000, 18000, 8000], [8000, 12000, 30000, 14000], ("delay", [9000, 22000, 12000, 20000]),
         None, -1),
        ("roar", [6554, 16000, 30000, 14000], [3000, 10000, 28000, 12000], ("punch", [8000, 12000, 15000, 20000]),
         None, -1),
        ("mist", [13107, 8000, 9000, 24000], [9000, 16000, 32767, 16000], ("delay", [10000, 26000, 6000, 20000]),
         ("element", [1500, 9000, 2000, 6000]), 0),
        ("hum", [0, 3000, 10000, 4000], [10000, 12000, 32767, 14000], None, None, -1),
        ("forest floor", [19661, 18000, 7000, 12000], [9000, 14000, 30000, 16000], ("spring", [8000, 12000, 8000, 12000]),
         ("value", [1500, 5000, 2000, 2000]), -1),
        ("glacier", [26214, 2000, 4000, 28000], [9000, 16000, 32767, 16000], ("delay", [11200, 26000, 4000, 22000]),
         None, -1),
        ("rut", [6554, 24000, 24000, 18000], [4000, 12000, 28000, 12000], ("grid", [6000, 8000, 20000, 18000]),
         None, -1),
    ]
    # iter knobs (measured, docs/synth-engines.md section 7.1): a near-sine voice; blue no audible change on a held
    # note, green odd harmonics (sine at 0 .. brighter), white a plucked burst of harmonics at note-on (and a lower
    # sustain), red how long the bright partials last at note-on (long at 0 .. short at the top)
    more["iter"] = [
        ("lab flute", [1516, 16704, 0, 15168], [800, 9000, 28000, 6000], ("spring", [12000, 14000, 6000, 12000]),
         ("tremolo", [5000, 3000, 2000, 2000]), 1),
        ("pure sine", [0, 0, 0, 32767], [64, 9000, 32767, 4000], None, None, 0),
        ("beaker pluck", [8000, 20000, 32767, 4000], [64, 6000, 0, 5000], ("delay", [6000, 18000, 9000, 9000]),
         None, 0),
        ("bunsen bass", [4000, 12000, 16000, 20000], [64, 7000, 26000, 3000], ("nitro", [1000, 3000, 14000, 9000]),
         None, -1),
        ("test tube", [16000, 26000, 20000, 0], [64, 9000, 6000, 8000], ("spring", [8000, 12000, 8000, 12000]),
         None, 1),
        ("titration pad", [12000, 20000, 0, 16000], [9000, 12000, 30000, 14000], ("spring", [16448, 15000, 2000, 10239]),
         ("tremolo", [3000, 5000, 2000, 2000]), 0),
        ("centrifuge", [20000, 32767, 8000, 8000], [64, 9000, 28000, 6000], ("cwo", [6000, 12000, 18000, 20000]),
         ("value", [6000, 8000, 3000, 3000]), 0),
        ("distill", [2000, 6000, 0, 24000], [8000, 14000, 32767, 16000], ("delay", [10000, 26000, 6000, 20000]),
         ("element", [1500, 9000, 2000, 6000]), 0),
        ("spark gap", [24000, 32767, 32767, 0], [64, 7000, 0, 4000], ("punch", [6000, 8000, 12000, 18000]), None, 0),
        ("litmus keys", [10000, 18000, 24000, 12000], [64, 10000, 12000, 7000], ("cwo", [3000, 8000, 12000, 16000]),
         None, 0),
        ("glass organ", [6000, 30000, 0, 20000], [400, 9000, 30000, 4000], ("spring", [16448, 16448, 14000, 24000]),
         ("tremolo", [4000, 6000, 2000, 2000]), 0),
        ("fume hood", [14000, 24000, 12000, 30000], [6000, 12000, 28000, 12000], ("grid", [6000, 8000, 20000, 18000]),
         ("random", [9000, 9000, 2500, 8000]), 0),
    ]
    for engine, rows in more.items():
        for row in rows:
            name, knobs, adsr, fx, lfo = row[:5]
            octave = row[5] if len(row) > 5 else 0
            out.append((patch(engine, name, knobs, adsr, fx=fx, lfo=lfo, octave=octave), silence()))
    # patches built around our effects, on our own engines (they sit in the engine's folder; an OP-1 effect has no
    # presets of its own): (engine, name, knobs, adsr, effect, effect knobs 0..1 blue/green/white/red, octave)
    W, SG = "washer", "snowglobe"
    for engine, name, knobs, adsr, fx, fk, octave in (
        ("wavetable", "jet wash", [14043, 4000, 22000, 8000], [64, 9000, 26000, 6000], W, (0.15, 0.8, 0.9, 0.7), 0),
        ("wavetable", "warm ensemble", [6000, 14000, 15000, 6000], [9000, 12000, 28000, 14000], W,
         (0.2, 0.9, 0.0, 0.8), 0),
        ("wavetable", "ice pad", [9362, 12000, 18000, 4000], [8000, 12000, 30000, 14000], SG, (0.9, 0.7, 0.8, 0.7), 0),
        ("wavetable", "snowfield", [2000, 6000, 12000, 6000], [9000, 14000, 32767, 16000], SG,
         (1.0, 0.3, 1.0, 0.65), 0),
        ("taffy", "tumble dry", [10923, 9000, 16000, 0], [64, 6000, 18000, 5000], W, (0.55, 0.4, 0.5, 0.5), 0),
        ("taffy", "spin cycle", [0, 9000, 22000, 0], [1500, 9000, 24000, 6000], W, (0.35, 0.6, 0.0, 0.5), 0),
        ("taffy", "candy snow", [21845, 6000, 12000, 8000], [64, 9000, 6000, 9000], SG, (0.7, 0.8, 0.6, 0.5), 1),
        ("taffy", "frozen toffee", [5000, 4000, 32767, 12000], [64, 6000, 0, 4500], SG, (0.8, 0.5, 0.9, 0.6), 0),
        ("pew", "rinse organ", [32767, 20000, 6000, 0], [64, 9000, 32767, 3000], W, (0.25, 0.5, 0.0, 0.6), 0),
        ("pew", "wobble chapel", [26000, 16000, 12000, 2000], [64, 9000, 32767, 3000], W, (0.6, 0.6, 0.6, 0.6), 0),
        ("pew", "midnight mass", [32767, 20000, 4000, 4000], [64, 9000, 32767, 4000], SG, (0.85, 0.3, 1.0, 0.5), 0),
        ("pew", "frozen hymn", [26000, 8000, 0, 2000], [4000, 12000, 32767, 14000], SG, (1.0, 0.0, 1.0, 0.7), 0),
        ("elg", "drone flange", [6554, 9000, 14000, 12000], [9000, 12000, 30000, 16000], W, (0.05, 1.0, 1.0, 0.6), -1),
        ("elg", "swamp chorus", [0, 14000, 10000, 8000], [8000, 12000, 30000, 14000], W, (0.3, 0.9, 0.2, 0.8), -1),
        ("elg", "aurora", [19661, 12000, 12000, 30000], [9000, 14000, 32767, 16000], SG, (0.95, 0.9, 1.0, 0.8), 0),
        ("elg", "blizzard", [13107, 20000, 22000, 24000], [9000, 14000, 32767, 16000], SG, (0.9, 0.6, 0.9, 0.75),
         -1),
    ):
        out.append((patch(engine, name, knobs, adsr, fx=(fx, fxk(fx, *fk)), octave=octave), silence()))
    return out


# Stock R246 keeps at most 100 user synth presets: past that the sync after disk mode drops the new ones (measured
# 2026-10-12). Our firmware raises that to 300 (op1r_host.c, docs/synth-engines.md 7.2); a stock or plain op1r
# OP-1 still drops everything past 100.
MAX_PRESETS = 300


def main():
    args = sys.argv[1:]
    granular = "--no-granular" not in args   # granular presets are silent until a sample is loaded
    args = [a for a in args if a != "--no-granular"]
    if len(args) != 1:
        sys.exit(__doc__)
    out = [(meta, pcm) for meta, pcm in presets() if granular or meta["type"] != "granular"]
    if len(out) > MAX_PRESETS:
        sys.exit(f"{len(out)} presets: our firmware keeps at most {MAX_PRESETS} user synth presets")
    os.makedirs(args[0], exist_ok=True)
    for meta, pcm in out:
        folder = os.path.join(args[0], meta["type"])   # one folder per engine, like the factory list
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, meta["name"] + ".aif")
        open(path, "wb").write(aifc(meta, pcm))
        print(f"{path}: {meta['type']}")


if __name__ == "__main__":
    main()
