/* Production mono FX probe: stdin/output float32, 64-sample blocks, normalized Q15 args.
 * The caller supplies declared common gain/envelope; this is not the native mixer.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#if defined(FX_FATHER)
#include "father_dsp.h"
static mw_state state;
#define INIT mw_init
#define PROCESS mw_process
#elif defined(FX_PLATE)
#include "plate_dsp.h"
static plate_state state;
#define INIT plate_init
#define PROCESS plate_process
#elif defined(FX_WARBLE)
#include "warble_dsp.h"
static wb_state state;
#define INIT wb_init
#define PROCESS wb_process
#else
#include "crush_dsp.h"
static crush_state state;
#define INIT crush_reset
#define PROCESS crush_process
#endif
int main(int argc,char **argv){
 if(argc!=5)return 2;
#ifdef FX_CRUSH
 int16_t q[4];
#else
 int32_t q[4];
#endif
 for(int i=0;i<4;i++)q[i]=atoi(argv[i+1]);
 INIT(&state);float in[64];int16_t b[64];
 while(fread(in,sizeof(float),64,stdin)==64){
  for(int i=0;i<64;i++){float x=in[i]*32768;b[i]=x>32767?32767:x< -32768?-32768:(int16_t)x;}
  PROCESS(&state,b,0,q);
  for(int i=0;i<64;i++)in[i]=b[i]/32768.f;
  if(fwrite(in,sizeof(float),64,stdout)!=64)return 3;
 }
 return ferror(stdin)||ferror(stdout)?3:0;
}
