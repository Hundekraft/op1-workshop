#!/usr/bin/env python3
"""Calibrate bounded static Wavetable/Elg trims from original production host binaries.
Usage: python3 tools/presets/calibrate_levels.py REVIEW_DIR
Uses REVIEW_DIR/before/bin/{wavetable,elg}, or builds original-gain source with --compile; writes current kennel headers and evidence.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""
from pathlib import Path
import subprocess,json,math
import numpy as np
import sys,argparse
R=Path(__file__).resolve().parents[2];D=None
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('directory',type=Path);ap.add_argument('--compile',action='store_true',help='compile original-gain production host sources using KENNEL_LEVEL_CALIBRATION');args=ap.parse_args();D=args.directory.resolve()
if args.compile:
 sdk=R/'ext/kennel/synth_sdk';(D/'before/bin').mkdir(parents=True,exist_ok=True)
 for engine in ['wavetable','elg']:
  folder=sdk/'plugins'/engine;j=json.loads((folder/'plugin.json').read_text())
  subprocess.run(['cc','-O2','-DOP1_HOST','-DKENNEL_LEVEL_CALIBRATION','-DENGINE='+j['symbol'],'-I'+str(sdk),str(R/'tools/presets/review_host.c'),*[str(folder/f)for f in j['sources']],'-Wl,-dead_strip','-lm','-o',str(D/'before/bin'/engine)],check=True)
rows={}
for e in ['wavetable','elg']:
 waves=8 if e=='wavetable' else 5;cuts=9 if e=='wavetable' else 17;resos=5 if e=='wavetable' else 1
 table=[];evidence=[]
 for w in range(waves):
  for c in range(cuts):
   for r in range(resos):
    q=[round(w*32767/7) if e=='wavetable' else w*512+256,8192,round(c*32767/(cuts-1)),round(r*32767/4)if e=='wavetable'else 0,21248,0,0,0]
    levels=[]
    for note in (48,60,72):
     x=np.frombuffer(subprocess.check_output([str(D/'before/bin'/e),*map(str,q),str(note),'100','1']),dtype='<f4')[4410:35280].astype(float);x-=x.mean();levels.append(float(np.sqrt(np.mean(x*x))))
    rms=max(levels)  # conservative loudest register, never average away a hot low note
    target=10**((-14 if e=='wavetable' else -18)/20)
    lo=.5;hi=10**((2 if e=='wavetable'else 3)/20)
    gain=max(lo,min(hi,target/max(rms,1e-8)));table.append(round(gain*4096));evidence.append(dict(q=q,rms=levels,gain_q12=table[-1]))
  print(e,'wave',w,flush=True)
 rows[e]=evidence
 filename=e+'_level.h';name='wt_level'if e=='wavetable'else 'elg_level_trim'
 out='/* Bounded static output trims, Q12. Generated from production AC RMS at MIDI48/60/72, velocity100.\n * '+('8 waves x9 cutoffs x5 resonances; -6.02..+2dB, nominal -14dBFS.'if e=='wavetable'else '5 intervals x17 timbres, movement off; -6.02..+3dB, nominal -18dBFS.')+'\n * No signal detector/AGC: velocity, envelopes, detune and movement remain expressive.\n * Calibration/method: OP1-Emulator tools/presets/calibrate_levels.py.\n * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */\n'
 out+='static const int16_t '+name+'['+str(len(table))+'] = {\n'+'\n'.join(' '+','.join(map(str,table[i:i+15]))+',' for i in range(0,len(table),15))+'\n};\n'
 (R/'ext/kennel/synth_sdk/plugins'/e/filename).write_text(out)
(D/'calibration.json').write_text(json.dumps(rows,indent=2)+'\n')
