"""Current kennel bundle's deliberate FX/LFO additions; historical 2.x packs are unchanged.
Only absent FX/LFO are filled. Synth knobs, octave, envelope and sample bytes are preserved.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""
import copy
import json
import struct

FILTER_RANGES = ((64, 14528), (0, 24576), (0, 22528), (8192, 32767))
# Normalized controls, 0..1. Small mixes retain attack definition and chord clarity.
FX = {
 ('elg','hum'): ('warble', (.20,.12,.72,.18)),
 ('fmbell','fm keys'): ('plate', (.28,.52,.06,.14)),
 ('granular','frozen'): ('father', (.35,0,.52,.14)),
 ('pew','jazz'): ('warble', (.16,.10,.70,.14)),
 ('oxbow','bp quack'): ('crush', (.80,.88,.04,.14)),
 ('oxbow','brass stab'): ('plate', (.22,.48,.04,.12)),
 ('oxbow','soft keys'): ('warble', (.18,.12,.68,.16)),
 ('sid','saw lead'): ('plate', (.22,.55,.04,.12)),
 ('sid','pulse keys'): ('warble', (.22,.12,.72,.16)),
 ('sid','sync bite'): ('crush', (.82,.92,.02,.12)),
 ('mbira','steel duet'): ('plate', (.25,.55,.03,.14)),
 ('mbira','bottle caps'): ('crush', (.78,.90,.02,.12)),
}
# Native Value LFO: slow, shallow motion, synth destination, green or white target.
# Never modulate blue selectors/programs. Native rate/depth needs OP-1 audition;
# host evidence measures the dry sources and production custom FX, not native LFO.
LFO = {
 ('eva','ee halo'): [1200,700,2000,10000],
 ('eva','ensemble ah'): [1400,600,2000,6000],
 ('mbira','glass rain'): [1100,500,2000,10000],
 ('mbira','glass dusk'): [1000,500,2000,10000],
 ('oxbow','pwm string'): [1200,700,2000,2000],  # blue is continuous cutoff, not page-2 PROGRAM
 ('oxbow','sweep pad'): [1000,700,2000,2000],
 ('oxbow','hollow pad'): [1300,500,2000,2000],
 ('oxbow','square ld'): [1700,600,2000,2000],
 ('oxbow','vintage pd'): [1100,500,2000,2000],
 ('sid','pulse keys'): [1400,500,2000,6000],
 ('sid','soft triangle'): [1000,600,2000,10000],
 ('elg','glacier'): [1100,500,2000,10000],
 ('pew','gospel'): [1200,600,2000,10000],
}

def enrich(meta):
    key=(meta['type'],meta['name']);m=copy.deepcopy(meta)
    if key in FX and not m.get('fx_active'):
        name,q=FX[key]
        m.update(fx_active=True,fx_type=name,fx_params=[round(lo+v*(hi-lo)) for v,(lo,hi) in zip(q,FILTER_RANGES)]+[0x5300,0,0,0])
    if key in LFO and not m.get('lfo_active'):
        m.update(lfo_active=True,lfo_type='value',lfo_params=LFO[key]+[0,0,0,0])
    return m

def apply(data):
    """Replace only APPL when needed; keep preview PCM and all other chunks exact."""
    pos=12;chunks=[];changed=False
    while pos<len(data):
        size=int.from_bytes(data[pos+4:pos+8],'big');end=pos+8+size+(size&1)
        raw=data[pos:end]
        if data[pos:pos+4]==b'APPL' and data[pos+8:pos+12]==b'op-1':
            old=json.loads(data[pos+12:pos+8+size]);new=enrich(old)
            if new!=old:
                body=b'op-1'+json.dumps(new,sort_keys=True,separators=(',',':')).encode()+b'\n'
                raw=b'APPL'+struct.pack('>I',len(body))+body+(b'\0' if len(body)&1 else b'');changed=True
        chunks.append(raw);pos=end
    if not changed:return data
    body=b'AIFC'+b''.join(chunks)
    return b'FORM'+struct.pack('>I',len(body))+body
