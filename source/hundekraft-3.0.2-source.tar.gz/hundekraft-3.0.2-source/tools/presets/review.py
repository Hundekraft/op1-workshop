#!/usr/bin/env python3
"""Render the current preset pack with production host engines and write spectral evidence.
Dry engine review only: native OP-1 ADSR, LFO routing, effects, mixing and CPU are excluded.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""
from pathlib import Path
import argparse,hashlib,json,math,subprocess,sys,wave,zipfile
import numpy as np
from scipy import signal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools/firmware'))
import runtime
RATE=44100

def db(v):return round(20*math.log10(max(float(v),1e-10)),2)
def features(x):
    a=x[:44100].astype(float);steady=a[4410:35280];p=np.abs(a)
    f,ps=signal.welch(steady,RATE,nperseg=4096)
    total=ps.sum()+1e-30
    bands=np.geomspace(30,20000,49)
    fingerprint=[float(ps[(f>=lo)&(f<hi)].sum()/total) for lo,hi in zip(bands,bands[1:])]
    return dict(peak_dbfs=db(p.max()),rms_dbfs=db(np.sqrt(np.mean(steady**2))),
        ac_rms_dbfs=db(np.sqrt(np.mean((steady-np.mean(steady))**2))),
        first50ms_rms_dbfs=db(np.sqrt(np.mean(a[:2205]**2))),
        dc=float(np.mean(steady)),rail_percent=round(float(np.mean(p>=32766/32768))*100,5),
        centroid_hz=round(float(np.sum(f*ps)/total),1),above8k_percent=round(float(ps[f>=8000].sum()/total)*100,3),
        dominant_hz=round(float(f[np.argmax(ps)]),1),fingerprint=fingerprint,
        source_release_ratio_db=db(np.sqrt(np.mean(x[66150:88200].astype(float)**2)))-db(np.sqrt(np.mean(steady**2))))

def wav(path,x):
    # Every audition file has the SAME -12.04dB gain; no per-preset normalization.
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(RATE)
        w.writeframes(np.clip(x*8192,-32768,32767).astype('<i2').tobytes())

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('directory',type=Path);ap.add_argument('--pack',type=Path,help='explicit pack; disables automatic SID/MBIRA additions');ap.add_argument('--compile',action='store_true',help='compile production host engines first with cc');args=ap.parse_args();d=args.directory.resolve()
    (d/'bin').mkdir(parents=True,exist_ok=True)
    if args.compile:
        sdk=ROOT/'ext/kennel/synth_sdk'
        for engine in ['sid','mbira','oxbow','supersaw','fmbell','granular','wavetable','taffy','pew','elg','eva']:
            folder=sdk/'plugins'/engine;definition=json.loads((folder/'plugin.json').read_text())
            command=['cc','-O2','-DOP1_HOST','-DENGINE='+definition['symbol'],'-I'+str(sdk),str(ROOT/'tools/presets/review_host.c'),*[str(folder/f) for f in definition['sources']],'-Wl,-dead_strip','-lm','-o',str(d/'bin'/engine)]
            result=subprocess.run(command,capture_output=True,text=True);(d/(engine+'-compile.log')).write_text(result.stdout+result.stderr)
            if result.returncode:raise RuntimeError(engine+' host compile failed')
    for sub in ['audio','spectrograms']: (d/sub).mkdir(exist_ok=True)
    patches=[]
    with zipfile.ZipFile(args.pack or d/'baseline/presets.zip') as z:
        for name in z.namelist():
            if name.endswith('.aif'):
                raw=z.read(name);patches.append(dict(path=name,meta=runtime.preset_meta(raw),sha256=hashlib.sha256(raw).hexdigest(),new=False))
    names={x['path'] for x in patches}
    for engine in ([]if args.pack else ['sid','mbira']):
        for p in sorted((ROOT/f'ext/kennel/synth_sdk/plugins/{engine}/presets').glob('*.aif')):
            path=f'synth/{engine}/{p.name}'
            if path not in names:
                raw=p.read_bytes();patches.append(dict(path=path,meta=runtime.preset_meta(raw),sha256=hashlib.sha256(raw).hexdigest(),new=True))
    failures=[]
    for row in patches:
        m=row['meta'];engine=m['type'];exe=d/'bin'/engine
        row['native_adsr_fx_lfo_applied']=False
        if not exe.exists():row['render_status']='not rendered: stock engine has no host renderer';continue
        octave=m.get('octave',0);clips={};base=list(m['knobs'])[:8];base += [0]*(8-len(base))
        try:
            for label,note,vel,nv in [('low',48,100,1),('middle',60,100,1),('high',72,100,1),('soft',60,64,1),('triad',60,100,3)]:
                r=subprocess.run([str(exe),*map(str,base),str(note+12*octave),str(vel),str(nv)],capture_output=True,timeout=30)
                if r.returncode:raise RuntimeError(f'{label} returned {r.returncode}: {r.stderr[-200:]!r}')
                x=np.frombuffer(r.stdout,dtype='<f4').copy()
                if len(x)!=690*128 or not np.isfinite(x).all():raise RuntimeError('invalid rendered data')
                clips[label]=x
            row['render_status']='dry production engine'
            row['notes_midi']=[48+12*octave,60+12*octave,72+12*octave]
            row['measurements']={k:features(x) for k,x in clips.items()}
            row['velocity_rms_difference_db']=round(row['measurements']['middle']['rms_dbfs']-row['measurements']['soft']['rms_dbfs'],2)
            stem=engine+'__'+m['name'].replace(' ','_')
            np.save(d/'audio'/(stem+'.npy'),clips['middle'])
            wav(d/'audio'/(stem+'.wav'),clips['middle']);wav(d/'audio'/(stem+'__triad.wav'),clips['triad'])
            row['audio']=str((d/'audio'/(stem+'.wav')).relative_to(ROOT));row['audio_npy']=str(d/'audio'/(stem+'.npy'))
            if engine=='granular':row['sample_dependency']='fixed declared host reference sample; actual source sample is user-supplied'
        except Exception as e:
            row['render_status']='failed';row['render_error']=str(e);failures.append(row['path']);print('FAILED',row['path'],e,flush=True)
        print(row['path'],row['render_status'],flush=True)
    # Equal axes and absolute scales are deliberate: no hidden per-patch boosting.
    for engine in sorted({x['meta']['type'] for x in patches}):
        rows=[x for x in patches if x['meta']['type']==engine and x.get('audio_npy')]
        if not rows:continue
        nc=4;nr=math.ceil(len(rows)/nc);fig,axes=plt.subplots(nr,nc,figsize=(16,2.75*nr),squeeze=False,constrained_layout=True)
        for ax,row in zip(axes.flat,rows):
            x=np.load(row['audio_npy']);f,t,z=signal.stft(x,RATE,nperseg=4096,noverlap=3584,boundary=None)
            zdb=20*np.log10(np.maximum(2*np.abs(z),1e-5))
            mesh=ax.pcolormesh(t,f,zdb,vmin=-90,vmax=0,cmap='magma',shading='auto',rasterized=True)
            ax.axvline(1,color='cyan',lw=.6,ls='--');ax.set_yscale('log');ax.set_ylim(40,16000);ax.set_xlim(0,2)
            q=row['measurements']['middle'];ax.set_title(f"{row['meta']['name']}{' [NEW]' if row['new'] else ''}\npeak {q['peak_dbfs']} / RMS {q['rms_dbfs']} dBFS",fontsize=9)
            ax.set_xlabel('seconds');ax.set_ylabel('Hz')
        for ax in list(axes.flat)[len(rows):]:ax.set_visible(False)
        fig.suptitle(f'{engine.upper()} — dry engine; native ADSR/LFO/FX excluded; note-off at 1s\nShared -90..0dBFS scale; MIDI C4 at each preset octave',fontsize=12)
        fig.colorbar(mesh,ax=list(axes.flat),label='dBFS amplitude');fig.savefig(d/'spectrograms'/(engine+'.png'),dpi=130);plt.close(fig)
    # A smaller FFT makes brief engine attacks visible; do not mistake the late RMS
    # window for silence when the instrument intentionally decays before 100ms.
    short=[x for x in patches if x.get('audio_npy') and (x['meta']['type']=='mbira' or (x['meta']['type']=='oxbow' and x['meta']['name'] in ['clav pluck','arp pluck','arp seq','random arp','reso zap','perc hit']))]
    nr=math.ceil(len(short)/4);fig,axes=plt.subplots(nr,4,figsize=(16,2.7*nr),squeeze=False,constrained_layout=True)
    for ax,row in zip(axes.flat,short):
        x=np.load(row['audio_npy'])[:13230];f,t,z=signal.stft(x,RATE,nperseg=1024,noverlap=896,boundary=None)
        mesh=ax.pcolormesh(t,f,20*np.log10(np.maximum(2*np.abs(z),1e-5)),vmin=-90,vmax=0,cmap='magma',shading='auto',rasterized=True)
        ax.set_yscale('log');ax.set_ylim(80,16000);ax.set_xlim(0,.3);ax.set_title(row['meta']['type']+' / '+row['meta']['name'],fontsize=9);ax.set_xlabel('seconds');ax.set_ylabel('Hz')
    for ax in list(axes.flat)[len(short):]:ax.set_visible(False)
    fig.suptitle('Attack detail — production dry source, 1024-point FFT, first 300ms; native ADSR/LFO/FX excluded')
    fig.colorbar(mesh,ax=list(axes.flat),label='dBFS amplitude');fig.savefig(d/'spectrograms/attacks.png',dpi=120);plt.close(fig)
    output=dict(method='Production host-engine code, no native ADSR, native LFO routing, effects, post-engine mixer or hardware CPU. 1s held, 1s released. WAVs all use common -12.04dB gain; metrics use raw source units.',sample_rate=RATE,baseline_presets=sum(not p['new']for p in patches),new_presets=sum(p['new']for p in patches),failures=failures,presets=patches)
    (d/'review.json').write_text(json.dumps(output,indent=2)+'\n')
    print('DONE',len(patches),'presets, failures',failures,flush=True)

if __name__=='__main__':main()
