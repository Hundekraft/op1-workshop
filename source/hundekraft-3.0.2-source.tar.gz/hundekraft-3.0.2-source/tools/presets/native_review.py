#!/usr/bin/env python3
"""Compare native dry/full preset captures and export a safe audition directory.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""
from pathlib import Path
import argparse,json,sys,math,wave,shutil,html,collections
import numpy as np
from scipy import signal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('directory',type=Path);ap.add_argument('captures',nargs='+',help='capture folder names relative to directory');ap.add_argument('--sheets',help='only regenerate these comma-separated sheets; preserve other existing sheets');args=ap.parse_args();D=args.directory.resolve();A=D/'audition';A.mkdir(exist_ok=True)
def db(x):return round(float(20*np.log10(max(float(x),1e-10))),2)
def feature(x,held):
 n=min(round(held*22050),len(x));h=x[:n];f,p=signal.welch(h,22050,nperseg=2048)
 p=p/(p.sum()+1e-30);edges=np.geomspace(35,10000,49);bands=np.array([p[(f>=a)&(f<b)].sum()for a,b in zip(edges,edges[1:])]);finger=np.sqrt(bands/(bands.sum()+1e-30))
 windows=np.array_split(h,12);env=np.array([np.sqrt(np.mean(w*w))for w in windows]);env=env/(env.max()+1e-30)
 onset=x[:min(len(x),33075)];win=2205;onset_rms=max(np.sqrt(np.mean(onset[i:i+win]**2))for i in range(0,max(1,len(onset)-win+1),551))
 return {'peak_100ms_rms_first_1_5s_dbfs':db(onset_rms),'peak_dbfs':db(abs(x).max()),'held_rms_dbfs':db(np.sqrt(np.mean(h*h))),'tail_rms_dbfs':db(np.sqrt(np.mean(x[n:]**2)))if len(x)>n else -200,'dc':float(h.mean()),'rail_samples':int((abs(x)>=.9999).sum()),'centroid_hz':round(float((f*p).sum()),1),'fingerprint':finger.tolist(),'envelope':env.tolist(),'first100ms_rms_dbfs':db(np.sqrt(np.mean(h[:2205]**2)))}
rows=[];capture_checks=[]
for folder in args.captures:
 folder=D/folder
 if not(folder/'result.json').exists():raise RuntimeError('unfinished '+str(folder))
 r=json.loads((folder/'result.json').read_text());assert r['complete']and r['source_nand_unchanged']
 capture_checks.append({'capture':str(folder.relative_to(D)),'checks':len(r['checks']),'all_passed':all(c['pass']for c in r['checks'].values()),'source_nand_unchanged':r['source_nand_unchanged'],'native_new_captures':r.get('native_new_captures',len(r['presets'])),'reused_dry_references':r.get('reused_dry_references',0)})
 if not capture_checks[-1]['all_passed']:raise RuntimeError('failed native checks')
 for p in r['presets']:
  x=np.load(folder/(p['file'][:-4]+'.npy'));q=dict(p,metrics=feature(x,p['held_seconds']),capture=str(folder.relative_to(D)));rows.append(q);shutil.copyfile(folder/p['file'],A/p['file'])
 if(folder/'granular-reference.wav').exists():shutil.copyfile(folder/'granular-reference.wav',A/'granular-reference.wav')
by=collections.defaultdict(dict)
for p in rows:by[(p['meta']['type'],p['meta']['name'])][p['mode']]=p
pairs=[];families={}
for e in sorted({k[0]for k in by}):
 patches=[(k,v)for k,v in by.items()if k[0]==e];close=[]
 for i,(k,v)in enumerate(patches):
  if 'dry'not in v:continue
  for k2,v2 in patches[i+1:]:
   if 'dry'not in v2:continue
   a=v['dry']['metrics'];b=v2['dry']['metrics'];sim=float(np.dot(a['fingerprint'],b['fingerprint']));env=float(np.sqrt(np.mean((np.array(a['envelope'])-b['envelope'])**2)))
   close.append({'a':k[1],'b':k2[1],'dry_spectral_similarity':round(sim,4),'normalized_envelope_distance':round(env,4),'same_octave':v['dry']['meta']['octave']==v2['dry']['meta']['octave']})
 families[e]=sorted(close,key=lambda q:q['dry_spectral_similarity'],reverse=True)[:8]
 if args.sheets and e not in args.sheets.split(','):continue
 # Matched axes, including saved native ADSR in both modes; no per-patch audio normalization.
 nr=len(patches);mesh=None;fig,axes=plt.subplots(nr,2,figsize=(12,max(3,nr*1.7)),squeeze=False,constrained_layout=True)
 for i,(key,modes)in enumerate(patches):
  for j,mode in enumerate(['dry','full']):
   ax=axes[i,j]
   if mode not in modes:ax.set_visible(False);continue
   p=modes[mode];folder=D/p['capture'];x=np.load(folder/(p['file'][:-4]+'.npy'));f,t,z=signal.stft(x,22050,nperseg=2048,noverlap=1792,boundary=None);mesh=ax.pcolormesh(t,f,20*np.log10(np.maximum(2*abs(z),1e-6)),vmin=-90,vmax=-6,cmap='magma',shading='auto',rasterized=True);ax.set_yscale('log');ax.set_ylim(40,10000);ax.set_xlim(0,len(x)/22050);ax.axvline(p['held_seconds'],color='cyan',lw=.5);ax.set_title(key[1]+' — '+mode+' / peak '+str(p['metrics']['peak_dbfs'])+'dBFS',fontsize=8)
 fig.suptitle(e.upper()+' | Native envelope dry vs full native LFO+FX | common absolute scales');fig.colorbar(mesh,ax=list(axes.flat),label='Recorded dBFS amplitude')if mesh is not None else None;fig.savefig(A/(e+'.png'),dpi=105);plt.close(fig)
for key,modes in by.items():
 if not set(['dry','full'])<=set(modes):continue
 d=modes['dry'];f=modes['full'];dm=d['metrics'];fm=f['metrics'];pairs.append({'engine':key[0],'name':key[1],'fx':f['meta']['fx_type']if f['meta']['fx_active']else None,'lfo':f['meta']['lfo_type']if f['meta']['lfo_active']else None,'dry_full_spectral_similarity':round(float(np.dot(dm['fingerprint'],fm['fingerprint'])),4),'held_change_db':round(fm['held_rms_dbfs']-dm['held_rms_dbfs'],2),'tail_change_db':round(fm['tail_rms_dbfs']-dm['tail_rms_dbfs'],2),'dry':dm,'full':fm,'files':{m:p['file']for m,p in modes.items()},'reason':f.get('proposal_reason'),'settings':{k:f['meta'][k]for k in ['knobs','adsr','octave','fx_type','fx_active','fx_params','lfo_type','lfo_active','lfo_params']}})
for pair in pairs:
 modes=by[(pair['engine'],pair['name'])]
 if 'fx'in modes:
  q=modes['fx']['metrics'];f=modes['full']['metrics'];pair['fx_only']=q;pair['lfo_held_change_db']=round(f['held_rms_dbfs']-q['held_rms_dbfs'],2);pair['lfo_spectral_similarity']=round(float(np.dot(q['fingerprint'],f['fingerprint'])),4)
report={'method':'Native R246 envelope in both modes; full enables saved LFO+FX; fx enables saved FX with LFO off. Independent silent fork per capture; real key note. Spectral similarity flags overlap, not musical quality. Held RMS under-rates short percussion; use peak/maximum 100ms RMS and attack spectra for those voices. Element LFO has fixed accel and silent input in this fixture. No per-preset audio normalization.','captures':len(rows),'presets':len(by),'pairs':pairs,'nearest_within_engine':families,'capture_checks':capture_checks};(D/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');(A/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
options=''.join('<option>'+html.escape(e)+'</option>'for e in families)
page='''<!doctype html><meta charset="utf-8"><title>Preset review — native full chain</title><style>body{background:#141619;color:#e9e5d9;font:16px system-ui;max-width:1100px;margin:35px auto;padding:15px}select,button{padding:9px;background:#303940;color:inherit;border:1px solid #75888a}audio{width:100%}img{width:100%}pre{white-space:pre-wrap;font-size:13px}.row{display:grid;grid-template-columns:1fr 1fr;gap:24px}a{color:#67d6b6}</style><h1>Preset review: native full chain</h1><p><strong>COUNTS</strong></p><p>The original dry source review omitted the OP-1 envelope, LFO and effects. These captures use the actual firmware. Both modes include the saved envelope; Full also includes saved LFO + FX. Each capture starts from the same silent machine. Audio uses the actual native output gain.</p><p>Choose Full first. Dry reveals whether the underlying voices are different. Spectral similarity is a comparison aid, not a musical-quality score. Granular uses the declared <a href="granular-reference.wav">own reference recording</a>, not an embedded preset sample.</p><select id="engine">OPTIONS</select> <select id="patch"></select><div class="row"><section><h2>Full: envelope + LFO + FX</h2><audio id="full"controls></audio></section><section><h2>Dry: envelope, FX/LFO off</h2><audio id="dry"controls></audio></section></div><details id="fxControl" hidden><summary>Isolate LFO: native envelope + FX, LFO off</summary><audio id="fxOnly" controls></audio></details><pre id="details"></pre><section id="proposal" hidden><h2>Separate retuning proposal — not installed</h2><div class="row"><section><h3>Proposed full chain</h3><audio id="proposalFull" controls></audio></section><section><h3>Proposed dry voice</h3><audio id="proposalDry" controls></audio></section></div><p id="proposalReason"></p></section><details><summary>Equal-scale native spectrogram sheet</summary><img id="sheet"></details><p><a href="analysis.json">Full measured report</a></p><script>let data,proposal;const initial=new URLSearchParams(location.search);const E=document.querySelector('#engine'),P=document.querySelector('#patch');function update(){let r=data.pairs.find(x=>x.engine===E.value&&x.name===P.value);if(!r)return;for(let m of ['full','dry']){let a=document.getElementById(m);a.pause();a.src=r.files[m]}document.querySelector('#details').textContent=JSON.stringify({engine:r.engine,preset:r.name,fx:r.fx,lfo:r.lfo,dry:r.dry.held_rms_dbfs+' dBFS held RMS',full:r.full.held_rms_dbfs+' dBFS held RMS',tail_change_db:r.tail_change_db,dry_full_spectral_similarity:r.dry_full_spectral_similarity},null,2);document.querySelector('#sheet').src=E.value+'.png';document.querySelector('#fxControl').hidden=!r.files.fx;const fx=document.querySelector('#fxOnly');fx.pause();if(r.files.fx)fx.src=r.files.fx;const pr=proposal?.pairs.find(x=>x.engine===E.value&&x.name===P.value);document.querySelector('#proposal').hidden=!pr;for(let m of ['Full','Dry'])document.querySelector('#proposal'+m).pause();if(pr){for(let m of ['Full','Dry']){let a=document.querySelector('#proposal'+m);a.pause();a.src='proposal/'+pr.files[m.toLowerCase()]}document.querySelector('#proposalReason').textContent=pr.reason||'Candidate for comparison; production preset unchanged.'}}function group(){P.innerHTML='';for(let r of data.pairs.filter(x=>x.engine===E.value)){let o=document.createElement('option');o.textContent=r.name;P.appendChild(o)}update()}E.onchange=group;P.onchange=update;fetch('analysis.json').then(r=>r.json()).then(r=>{data=r;const engines=Array.from(E.options).map(x=>x.value);if(engines.includes(initial.get('engine')))E.value=initial.get('engine');else if(engines.includes('wavetable'))E.value='wavetable';group();const desired=initial.get('preset')||(E.value==='wavetable'?'warm ensemble':null);if(desired&&Array.from(P.options).some(x=>x.value===desired)){P.value=desired;update()}fetch('proposal/analysis.json').then(r=>r.ok?r.json():null).then(r=>{proposal=r;update()}).catch(()=>{})})</script>'''.replace('OPTIONS',options).replace('COUNTS',str(len(by))+' presets · '+str(len(rows))+' recordings/references')
(A/'index.html').write_text(page);print(json.dumps({'captures':len(rows),'presets':len(by),'rails':sum(p['metrics']['rail_samples']for p in rows),'near_pairs':families},indent=2))
