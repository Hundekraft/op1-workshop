#!/usr/bin/env python3
"""Review custom FX at native22.05kHz with controlled resampled source bursts. Native LFO/ADSR excluded.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""
from pathlib import Path
import sys,json,subprocess,zipfile,math,html
import numpy as np
from scipy import signal
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[2];D=Path(sys.argv[1]).resolve();sys.path[:0]=[str(R/'tools/firmware'),str(R/'tools/presets')];import runtime,polish
RATE=22050

def controlled(row):
 x=signal.resample_poly(np.load(row['audio_npy']),1,2)
 src=np.zeros(RATE*5//64*64,dtype='<f4');src[:RATE]=x[:RATE]*.25
 fade=round(RATE*.024);src[RATE-fade:RATE]*=np.cos(np.linspace(0,np.pi/2,fade))**2
 return src

for fx in ['father','plate','warble','crush']:
 p=R/'ext/kennel/synth_sdk/plugins'/fx
 subprocess.run(['cc','-O2','-DFX_'+fx.upper(),'-I'+str(p),str(R/'tools/presets/review_fx_host.c'),str(p/(fx+'_dsp.c')),'-o',str(D/'bin'/('fx_'+fx))],check=True)
rows=json.load(open(D/'review.json'))['presets'];by={(r['meta']['type'],r['meta']['name']):r for r in rows}
measure=[]
# Controlled one-second burst and 24ms cosine release; fixed -12.04dB probe gain.
# This lets us compare effects on identical input, without inventing native ADSR timing.
for key,(fx,q) in polish.FX.items():
 row=by[key];src=controlled(row)
 # Quantize the exact saved raw params through the same documented filter range law.
 m=polish.enrich(row['meta']);raw=m['fx_params'];q15=[(raw[i]-lo)*32767//(hi-lo) for i,(lo,hi) in enumerate(polish.FILTER_RANGES)]
 y=np.frombuffer(subprocess.check_output([str(D/'bin'/('fx_'+fx)),*map(str,q15)],input=src.tobytes()),dtype='<f4').copy()
 stem=key[0]+'__'+key[1].replace(' ','_');np.save(D/'audio'/(stem+'__fx.npy'),y)
 import wave
 with wave.open(str(D/'audio'/(stem+'__fx.wav')),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(RATE);w.writeframes(np.clip(y*32768,-32768,32767).astype('<i2').tobytes())
 db=lambda a:float(20*np.log10(max(float(a),1e-10)))
 measure.append(dict(engine=key[0],name=key[1],effect=fx,normalized=q,raw=raw,peak_dbfs=round(db(abs(y).max()),2),rms_change_db=round(db(np.sqrt(np.mean(y[:RATE]**2)))-db(np.sqrt(np.mean(src[:RATE]**2))),2),rail_samples=int((abs(y)>=32766/32768).sum()),late_rms_dbfs=round(db(np.sqrt(np.mean(y[2*RATE:3*RATE]**2))),2),file=stem+'__fx.wav'))
 print(key,measure[-1],flush=True)
# Side-by-side identical scales expose extra high-frequency bands, smearing and tails.
fig,axs=plt.subplots(len(measure),2,figsize=(12,2.05*len(measure)),constrained_layout=True)
for axrow,m in zip(axs,measure):
 row=by[(m['engine'],m['name'])];dry=controlled(row)
 for ax,x,label in zip(axrow,[dry,np.load(D/'audio'/(m['file'].replace('.wav','.npy')))],['controlled dry',m['effect']]):
  f,t,z=signal.stft(x,RATE,nperseg=2048,noverlap=1792,boundary=None);mesh=ax.pcolormesh(t,f,20*np.log10(np.maximum(2*abs(z),1e-6)),vmin=-90,vmax=0,cmap='magma',shading='auto',rasterized=True)
  ax.set_yscale('log');ax.set_ylim(40,10000);ax.set_xlim(0,5);ax.set_title(m['engine']+' / '+m['name']+' — '+label,fontsize=10);ax.set_xlabel('seconds');ax.set_ylabel('Hz')
fig.suptitle('Production mono FX at22.05kHz: same -12.04dB input gain; controlled 1s burst / 24ms release\nNative ADSR, native LFO, native mixer and hardware CPU excluded')
fig.colorbar(mesh,ax=list(axs.flat),label='dBFS amplitude');fig.savefig(D/'spectrograms/fx-comparisons.png',dpi=110);plt.close(fig)
(D/'fx-review.json').write_text(json.dumps({'method':'Production mono FX, 22.05kHz; own 44.1kHz host source resampled with scipy.resample_poly (not R246 decimator), fixed .25 source gain, controlled 1s burst with 24ms cosine release, 4s tail; native ADSR/LFO/mixer excluded. Zero rails in this probe is not hardware clipping or CPU proof.','presets':measure},indent=2)+'\n')
