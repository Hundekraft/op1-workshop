#!/usr/bin/env python3
"""Accepted current-kennel preset retunes, also usable for separate audition packs.
Input: the current kennel preset ZIP. Output: candidate ZIP and explicit field diff.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""
from pathlib import Path
import argparse,copy,json,sys,zipfile
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'));sys.path.insert(0,str(ROOT/'tools/firmware'))
import op1r_presets as writer
import runtime
FILTER=((64,14528),(0,24576),(0,22528),(8192,32767))
# Full raw controls are explicit: no random broadening and no selector modulation.
# Accepted after native comparison; historical 2.x presets remain unchanged.
DRY={
 ('fmbell','metal pad'):([1792,22000,1500,14000],[7000,12000,24000,13000],0,'Slow index decay preserves FM sidebands through the pad attack; the old fast decay left a mostly sine body.'),
 ('wavetable','warm ensemble'):([18724,26000,23500,2500],[4800,10000,29000,11000],0,'Open square ensemble instead of the identical filtered Warm Pad source.'),
 ('wavetable','ice pad'):([30200,4000,26200,3500],[6400,11500,24000,12000],0,'Bright digital/vocal ice texture, distinct from the warm fundamentals.'),
 ('wavetable','snowfield'):([800,1200,23000,1500],[3200,10000,27000,15000],1,'Sparse upper-register sine bed rather than another low warm pad.'),
 ('wavetable','fat brass'):([14043,17000,22000,6000],[900,6500,21000,4500],0,'Expose saw harmonics with a shorter brass envelope.'),
 ('taffy','spin cycle'):([32767,20000,1000,1600],[64,4200,12000,3200],0,'Bright saw-pulse keys instead of the CZ Brass source/envelope.'),
 ('taffy','hollow pad'):([10923,27000,1200,11000],[6000,11500,26000,12000],0,'Keep a clearly hollow square spectrum after the transient.'),
 ('taffy','square org'):([10923,26000,0,0],[64,6000,30000,1500],0,'Sustained bright square organ, with minimal release and no distortion envelope.'),
 ('pew','jazz'):([0,30000,5000,12000],[64,9000,32767,2500],0,'Light upper registration without the shared low drawbar.'),
 ('pew','rinse organ'):([16000,0,28000,0],[64,9000,32767,3000],0,'Low/high gap registration before Washer, instead of another full low organ.'),
 ('pew','midnight mass'):([27000,1500,24000,800],[1200,12000,28000,14000],0,'Low-plus-high registration with a missing middle, unlike Sunday.'),
 ('elg','drone flange'):([1280,700,23500,3000],[4200,10500,29000,11000],0,'Open, tightly tuned octave drone instead of Moose Call.'),
 ('elg','aurora'):([2304,7000,22500,16000],[5500,13000,30000,15000],0,'Open two-octave stack with moderate movement instead of Northern Light.'),
 ('supersaw','saw lead'):([2200,0,1500,1500],[64,6000,25000,2200],0,'Narrow unison saw lead; retain broad detuned voices elsewhere.'),
 ('supersaw','dark saws'):([400,32767,26000,0],[2300,11000,22000,10000],0,'Nearly locked hollow pulse plus strong sub, rather than another driven saw.'),
 ('supersaw','bit bass'):([0,32767,0,10000],[64,3500,9000,1800],-1,'Short locked pulse bass without the dominant sub, before deliberate digital processing.'),
}
# Normalized current-plugin controls. FX are chosen to create different gestures,
# rather than spreading one subtle chorus/reverb across every voice.
FX={
 ('wavetable','warm pad'):('father',(.28,0,.58,.34)),
 ('wavetable','ice pad'):('snowglobe',(.82,.52,.76,.47)),
 ('wavetable','snowfield'):('plate',(.72,.66,.16,.48)),
 ('wavetable','fat brass'):('plate',(.19,.42,.06,.24)),
 ('taffy','hollow pad'):('warble',(.24,.38,.68,.42)),
 ('taffy','square org'):None,
 ('taffy','sugar rush'):('crush',(.42,.56,.14,.38)),
 ('pew','midnight mass'):('father',(.62,0,.40,.42)),
 ('elg','aurora'):('snowglobe',(.85,.70,.68,.46)),
 ('elg','hum'):('warble',(.16,.40,.52,.46)),
 ('supersaw','saw pluck'):('plate',(.20,.50,.06,.24)),
 ('supersaw','trance pad'):('warble',(.30,.32,.74,.34)),
 ('supersaw','dark saws'):('father',(.34,0,.30,.36)),
 ('supersaw','bit bass'):('crush',(.36,.52,.09,.42)),
 ('fmbell','glass bell'):('plate',(.56,.65,.16,.40)),
 ('fmbell','music box'):('warble',(.22,.44,.60,.52)),
 ('fmbell','marimba'):None,
 ('fmbell','metal pad'):('snowglobe',(.78,.50,.66,.44)),
 ('sid','saw lead'):('plate',(.26,.50,.05,.28)),
 ('sid','pulse keys'):('warble',(.28,.42,.70,.42)),
 ('sid','sync bite'):('crush',(.42,.54,.10,.38)),
 ('mbira','steel duet'):('plate',(.36,.56,.07,.30)),
 ('mbira','bottle caps'):('crush',(.48,.62,.10,.34)),
 ('mbira','glass dusk'):('warble',(.15,.42,.42,.44)),
 ('oxbow','soft keys'):('warble',(.22,.36,.60,.38)),
 ('oxbow','bp quack'):('crush',(.56,.68,.08,.30)),
}
LFO={
 ('wavetable','warm ensemble'):('value',[1600,3200,2000,6000]),
 ('wavetable','ice pad'):('value',[1200,2200,2000,10000]),
 ('wavetable','snowfield'):None,
 ('taffy','hollow pad'):('value',[1300,2600,2000,6000]),
 ('taffy','spin cycle'):None,
 ('taffy','square org'):None,
 ('elg','drone flange'):None,
 ('elg','aurora'):('value',[1600,2400,2000,10000]),
 ('elg','forest floor'):('value',[1500,2800,2000,10000]),
 ('fmbell','temple'):('value',[1500,2400,2000,6000]),
 ('sid','pulse keys'):('value',[2400,3000,2000,6000]),
 ('sid','soft triangle'):('value',[1300,2600,2000,10000]),
 ('mbira','glass dusk'):('value',[1300,1800,2000,10000]),
 ('oxbow','pwm string'):('value',[1800,2400,2000,2000]),
 ('oxbow','sweep pad'):('value',[1200,4000,2000,2000]),
 ('oxbow','hollow pad'):('value',[1600,2300,2000,2000]),
}

def propose(old):
 m=copy.deepcopy(old);key=(m['type'],m['name'])
 if key in DRY:
  k,a,o,_=DRY[key];m['knobs'][:4]=k;m['adsr'][:4]=a;m['octave']=o
 if key in FX:
  fx=FX[key];m['fx_active']=fx is not None
  if fx:
   name,q=fx;m['fx_type']=name;m['fx_params']=[round(lo+v*(hi-lo))for v,(lo,hi)in zip(q,FILTER)]+[0x5300,0,0,0]
 if key in LFO:
  lfo=LFO[key];m['lfo_active']=lfo is not None
  if lfo:m['lfo_type']=lfo[0];m['lfo_params']=lfo[1]+[0,0,0,0]
 for what,values,ranges in [('adsr',m['adsr'][:4],writer.RANGE_ADSR),('lfo',m['lfo_params'][:4],writer.RANGE_LFO[m['lfo_type']])]:
  writer.check(m['name'],what,values,ranges)
 if m['fx_active']:
  writer.check(m['name'],'fx',m['fx_params'][:4],writer.RANGE_FX.get(m['fx_type'],FILTER))
 return m

def apply(data):
 """Apply accepted settings; preserve untouched files and reject nonempty audio."""
 old=runtime.preset_meta(data);new=propose(old)
 if new==old:return data
 if b'SSND\x00\x00\x00\x08' not in data:
  raise RuntimeError('Refusing to discard preset audio: '+old['name'])
 return writer.aifc(new,[])


def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('source',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args();patches=[];changes=[]
 with zipfile.ZipFile(a.source)as z:
  for n in z.namelist():
   if not n.endswith('.aif'):continue
   data=z.read(n);old=runtime.preset_meta(data);m=propose(old)
   if m!=old:
    # Current settings-only pack has no preview/sample data. Refuse to drop audio.
    if b'SSND\x00\x00\x00\x08'not in data:raise RuntimeError('nonempty source audio: '+n)
    data=writer.aifc(m,[]);changes.append({'engine':m['type'],'name':m['name'],'reason':DRY.get((m['type'],m['name']),(None,None,None,'Make processing a distinct, audible role; retain dry references.'))[3],'fields':{k:{'before':old[k],'after':m[k]}for k in old if old[k]!=m[k]}})
   patches.append((m['type'],m['name'],data))
 # Reuse the production deterministic ZIP writer without changing bundle filtering.
 a.output.write_bytes(runtime.preset_zip(patches,{'preset_cap':300}));a.output.with_suffix('.changes.json').write_text(json.dumps(changes,indent=2)+'\n');print(len(patches),'presets,',len(changes),'retunes written to',a.output)
if __name__=='__main__':main()
