/* Dry production-engine renderer for preset review. No native OP-1 ADSR/LFO/FX.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "op1_plugin.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
int16_t host_sine[8192];int32_t host_pitch_inc[128];uint8_t host_voice_mem[6*0x24];int16_t host_voice_vel[6];
int16_t host_knobs[8][8];int host_slot;const uint8_t *host_sample_buffer[8];
int16_t host_fx_knobs[3][8],host_fx_meter[3];void *host_fx_scratch[3];
volatile uint8_t op1_fx_page[3][4],op1_eng_page[4];uint8_t host_shift;
void *host_find_node(void *s,const char *id){return 0;}
void host_node_set_transform(void *n,const int32_t *m){}
void host_node_set_visible(void *n,int on){}
void host_screen_draw(void *s,int dt){}
void *host_raster(void){return 0;}
void host_raster_line(void *r,const void *a,const void *b,int32_t w,const uint8_t *c){}
void *read_fx_param_safe(int slot,int pos){return 0;}
void *host_text_ctor(void *o,int32_t x,int32_t y,int32_t z,const uint8_t *c){return o;}
void host_text_set(void *o,const char *s){}
void host_text_draw(void *o,void *r,const int32_t *m){}
extern const op1_engine_t ENGINE;
static int32_t inc(int n){return (int32_t)llround(4294967296.0*440.0*pow(2.0,(n-69)/12.0)/44100.0);}
int main(int argc,char **argv){
 if(argc!=12)return 2;
 int16_t k[8];for(int i=0;i<8;i++)k[i]=(int16_t)atoi(argv[1+i]);
 int note=atoi(argv[9]),vel=atoi(argv[10]),nv=atoi(argv[11]);if(nv<1||nv>3)return 2;
 for(int i=0;i<8192;i++)host_sine[i]=(int16_t)lrint(32767*sin(2*M_PI*i/8192));
 /* Granular comparisons use this declared common sample, never a pretend preset sample. */
 static int16_t smp[OP1_SAMPLE_GUARD+88200];static struct{int16_t *d;int16_t p[OP1_PEAK_BUCKETS];} sb;
 for(int i=0;i<88200;i++)smp[OP1_SAMPLE_GUARD+i]=(int16_t)(9000*sin(i*.0373)*(.5+.5*sin(i*.00007))+3000*sin(i*.0559));
 sb.d=smp;for(int i=0;i<OP1_PEAK_BUCKETS;i++)sb.p[i]=i<345?12000:0;host_sample_buffer[0]=(const uint8_t *)&sb;
 static const int offsets[3]={0,4,7};int16_t out[128];float sum[128];
 for(int v=0;v<nv;v++){
  host_voice_vel[v]=(int16_t)(vel<<8);for(int i=0;i<128;i++)host_pitch_inc[i]=inc(note+offsets[v]);
  ENGINE.note_on(host_voice_mem+v*0x24,k);
 }
 for(int b=0;b<690;b++){
  for(int i=0;i<128;i++)sum[i]=0;
  for(int v=0;v<nv;v++){
   void *self=host_voice_mem+v*0x24;
   if(b==345 && ENGINE.note_off)ENGINE.note_off(self);
   for(int i=0;i<128;i++)host_pitch_inc[i]=inc(note+offsets[v]);
   ENGINE.render(self,out,k);
   for(int i=0;i<128;i++)sum[i]+=(float)out[i]/32768.0f;
  }
  if(fwrite(sum,sizeof(float),128,stdout)!=128)return 3;
 }
 return ferror(stdout)?3:0;
}
