/* drum+ in the firmware (docs/31), a kennel drum type (op1_feature_drum.h): the core's DrumSampler vtable slots
 * render / note_on / note_off (kennel/kn_drum.c) call dpf_render / dpf_note_on / dpf_note_off. Pads without drum+
 * extras (and every pad of a stock kit) call the original functions, unchanged; drum+ pads run dp_plus_* with
 * per-voice state indexed like the 12 stock voices. The pages are dp_ui.c; FEATURE_drumplus is at the end. */
#include "dp_plus.h"
#include "../op1_feature_drum.h"

#define DP_SLOTS   8                                          /* drum_slots rows */
#define DP_PADS    24
#define DP_VOICES  12
#define VOICE_OBJ  ((void *const *)0x01AAAD30)                /* voice objects [12] (0xFFB00000 + v * 0x14) */
#define VOICE_PAD  ((const int32_t *)0xFF801334)              /* pad of voice v (note_on_drum) */
#define VOICE_VEL  ((const int16_t *)0xFF8012EC)              /* velocity << 8 of voice v (int16) */
#define DRUM_SLOT  (*(const volatile int32_t *)0x01AAAC10)    /* current drum slot */
#define BUF_INC    ((int32_t *)0xFF801950)                    /* synth_phase_inc_bus [128] (refilled per voice) */
#define BUF_VEL    ((int16_t *)0xFF801D50)                    /* synth_env_buf [128] (velocity << 8, per voice) */
#define FIR        ((const int16_t *)0xFF8021D2)              /* interpolation table centre */
#define BEAT_LEN   (*(const volatile int32_t *)0x01AADAD8)    /* metronome beat length, 0x4000 per sample */

typedef void (*render_fn)(void *, int16_t *, const dp_pad *);
typedef void (*pad_fn)(void *, const dp_pad *);
#define STOCK_RENDER   ((render_fn)0x019789EC)
#define STOCK_NOTE_ON  ((pad_fn)0x01978926)
#define STOCK_NOTE_OFF ((pad_fn)0x01978898)

dp_extra dp_x[DP_SLOTS][DP_PADS];                             /* filled by dpf_load (op1r key) */
dp_pre   dp_c[DP_SLOTS][DP_PADS];
static dp_xvoice dp_xs[DP_VOICES];

static int voice_index(void *self)
{
    for (int i = 0; i < DP_VOICES; i++) if (VOICE_OBJ[i] == self) return i;
    return -1;
}
static dp_voice *model(void *self) { return (dp_voice *)((uint8_t *)self + 8); }   /* pos, state, blocks */
static int slot_ok(void) { return (uint32_t)DRUM_SLOT < DP_SLOTS; }
static int pad_of(int v) { int p = VOICE_PAD[v]; return (uint32_t)p < DP_PADS ? p : 0; }
static uint32_t samples_per_beat(void) { int32_t l = BEAT_LEN >> 14; return l > 0 ? (uint32_t)l : 22050; }

static void dpf_note_on(void *self, const dp_pad *pad)
{
    int v = voice_index(self);
    if (v < 0 || !slot_ok()) { STOCK_NOTE_ON(self, pad); return; }
    int slot = DRUM_SLOT, p = pad_of(v);
    dp_voice *vp[DP_VOICES]; uint8_t vpad[DP_VOICES];
    for (int i = 0; i < DP_VOICES; i++) { vp[i] = model(VOICE_OBJ[i]); vpad[i] = (uint8_t)pad_of(i); }
    /* (voice v itself may be stolen and get marked: its note-on below clears the fade) */
    dp_plus_choke(vp, dp_xs, vpad, DP_VOICES, p, dp_x[slot]);
    if (!dp_c[slot][p].active) {
        STOCK_NOTE_ON(self, pad);
        dp_xs[v].fading = 0; dp_xs[v].hits_left = 0;
        return;
    }
    dp_plus_note_on(model(self), &dp_xs[v], pad, &dp_x[slot][p], &dp_c[slot][p], VOICE_VEL[v] >> 8,
                    samples_per_beat());
}

static void dpf_note_off(void *self, const dp_pad *pad)
{
    int v = voice_index(self);
    if (v < 0 || !slot_ok() || !dp_c[DRUM_SLOT][pad_of(v)].active) { STOCK_NOTE_OFF(self, pad); return; }
    int slot = DRUM_SLOT, p = pad_of(v);
    dp_plus_note_off(model(self), &dp_xs[v], pad, &dp_x[slot][p], &dp_c[slot][p]);
}

/* render cycles, drum+ / stock path (resource monitor line "drum+ x stock y", % of the audio time) */
volatile uint32_t dp_prof[2];
static inline uint32_t cycles(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }

static void dp_fw_render_(void *self, int16_t *out, const dp_pad *pad);
static void dpf_render(void *self, int16_t *out, const dp_pad *pad)
{
    uint32_t t0 = cycles();
    dp_fw_render_(self, out, pad);
    int v = voice_index(self);
    dp_prof[v >= 0 && slot_ok() && (dp_c[DRUM_SLOT][pad_of(v)].active || dp_xs[v].fading) ? 0 : 1] += cycles() - t0;
}
static void dp_fw_render_(void *self, int16_t *out, const dp_pad *pad)
{
    int v = voice_index(self);
    if (v < 0 || !slot_ok()) { STOCK_RENDER(self, out, pad); return; }
    int slot = DRUM_SLOT, p = pad_of(v);
    if (!dp_c[slot][p].active && !dp_xs[v].fading) { STOCK_RENDER(self, out, pad); return; }
    dp_extra *x = &dp_x[slot][p]; const dp_pre *c = &dp_c[slot][p];
    if (dp_plus_fast_pre(model(self), &dp_xs[v], x, c, BUF_INC, BUF_VEL)) {    /* stock render on our buffers */
        STOCK_RENDER(self, out, pad);
        dp_plus_fast_post(model(self), &dp_xs[v], x, c, out);
        return;
    }
    const int16_t *data = **(const int16_t *const *const *)((uint8_t *)self + 4);
    dp_plus_render(model(self), &dp_xs[v], out, pad, &dp_x[slot][p], &dp_c[slot][p], BUF_INC, BUF_VEL, data, FIR,
                   samples_per_beat());
}

/* ---- persistence: "op1r": {"engine": "drum+", "pads": [[f0, f1, ...], ... 24]} in the drum patch JSON ----
 * The core keeps "op1r" across load (so the stock writer saves it again) and calls dpf_load with the slot that
 * loaded (kennel/kn_drum.c): the pads are read into dp_x / dp_c (values clamped; missing key or pad = all off). */
#define JV_KEY    ((void *(*)(void *, const char *))0x019BFEB4)       /* Value::operator[](const char *) */
#define JV_IDX    ((void *(*)(void *, unsigned))0x019BFAF8)           /* Value::operator[](ArrayIndex) */
#define JV_ASSIGN ((void *(*)(void *, const void *))0x019BDDC0)       /* Value::operator= */
#define JV_SIZE   ((unsigned (*)(const void *))0x019BE8D8)            /* Value::size */
#define JV_DTOR   ((void (*)(void *, int))0x019BDD18)
#define JV_FROM_INT ((void *(*)(void *, int))0x019BD890)               /* Value(int) */
enum { JV_NULL = 0, JV_INT = 1, JV_UINT = 2, JV_ARRAY = 6, JV_OBJECT = 7 };
static uint8_t jv_type(const void *v) { return ((const uint8_t *)v)[8]; }
static int32_t jv_int(const void *v)                   /* ints only, never asserts (as asInt, 0x019BE0C0) */
{
    int32_t w = *(const int32_t *)v;                   /* 32-bit Int / UInt in the 8-byte union (high word: junk) */
    return jv_type(v) == JV_INT || (jv_type(v) == JV_UINT && w >= 0) ? w : 0;
}

static void dpf_load(int slot, void *op1r)
{
    if ((unsigned)slot >= DP_SLOTS) return;
    for (int p = 0; p < DP_PADS; p++)
        for (int i = 0; i < DP_NFIELDS; i++) dp_extra_set(&dp_x[slot][p], i, 0);
    if (op1r && jv_type(op1r) == JV_OBJECT) {
        void *pads = JV_KEY(op1r, "pads");
        if (jv_type(pads) == JV_ARRAY) {
            unsigned n = JV_SIZE(pads);
            for (unsigned p = 0; p < n && p < DP_PADS; p++) {
                void *a = JV_IDX(pads, p);
                if (jv_type(a) != JV_ARRAY) continue;
                unsigned m = JV_SIZE(a);
                for (unsigned i = 0; i < m && i < DP_NFIELDS; i++) dp_extra_set(&dp_x[slot][p], (int)i, jv_int(JV_IDX(a, i)));
            }
        }
    }
    for (int p = 0; p < DP_PADS; p++) dp_plus_prepare(&dp_x[slot][p], &dp_c[slot][p]);
}

/* op1r.pads[pad] = the pad's fields (UI edits); the caller marks the patch changed (stock saver writes it) */
void dp_fw_store_pad(int slot, int pad)
{
    if ((unsigned)slot >= DP_SLOTS || (unsigned)pad >= DP_PADS) return;
    void *op = JV_KEY(OP1_DRUM_PATCH_JSON(slot), OP1_DRUM_KEY);
    if (jv_type(op) != JV_OBJECT) return;                         /* not a drum+ slot */
    void *pads = JV_KEY(op, "pads");
    if (jv_type(pads) != JV_ARRAY && jv_type(pads) != JV_NULL) return;
    void *a = JV_IDX(pads, (unsigned)pad);                        /* (null -> array; grows with null entries) */
    if (jv_type(a) != JV_ARRAY && jv_type(a) != JV_NULL) return;
    uint32_t tmp[4];
    for (int i = 0; i < DP_NFIELDS; i++) {
        JV_FROM_INT(tmp, dp_extra_get(&dp_x[slot][pad], i));
        JV_ASSIGN(JV_IDX(a, (unsigned)i), tmp);
        JV_DTOR(tmp, 2);
    }
}

/* ---- the drum type (kennel feature API): picked as the "drum+" row (id 2) of the drum type browser ---- */
void dpu_fw_init(void);                                          /* pages: dp_ui.c */
void dpu_fw_draw(int page, int slot, void *raster);
int  dpu_fw_turn(int page, int slot, int knob, int delta);
void dpu_fw_press(int page, int slot, int knob);

static const struct op1_drum_type dp_type = {
    .api = OP1_DRUM_API, .id = OP1_DRUM_TYPE_ID, .name = "drum+",
    .load = dpf_load,
    .render = (void (*)(void *, int16_t *, const op1_drum_pad *))dpf_render,
    .note_on = (void (*)(void *, const op1_drum_pad *))dpf_note_on,
    .note_off = (void (*)(void *, const op1_drum_pad *))dpf_note_off,
    .page_init = dpu_fw_init, .page_draw = dpu_fw_draw, .page_turn = dpu_fw_turn, .page_press = dpu_fw_press,
};
const op1_feature_t FEATURE_drumplus = { .api = OP1_FEATURE_API, .priority = 500, .name = "drumplus", .drum = &dp_type };   /* id; the kit's "drum+" is dp_type.name */
