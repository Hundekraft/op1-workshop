/*
 * Snapshot save hook (op1_feature.h OP1_EV_SAVE_HOLD, op1_snapshot_defer / _save / _name_exists): lets a feature
 * hold back the stock hold-to-save of a sound and finish it later under its own name (sound naming).
 *
 * R246 (global controller, FUN_019AD090, called from the main loop at 0x019F0A3C): while exactly one sound key is
 * held (bytes 0x01AACDBC..C3, the slot), help and Shift are up and the core is not stopped (0xFF801040 != 1), a
 * countdown 0x01AACDC8 runs from 400 per main loop pass (0x01AACDC4 = running); at 320 it checks free space
 * (16 MB) and the bank's save gate, below that it draws the progress; when it goes below 0 it saves a snapshot of
 * the slot in the bank 0x01DE4C40 (0 synth, 1 drum) under the date stamp "%i%02i%02i_%02i%02i" (snprintf at
 * 0x019AD220 synth, 16-byte buffer / 0x019AD5A6 drum), "_N" added while the file exists, then clears the held
 * bytes and the running flag. Releasing the key early clears the running flag and hides the progress.
 *
 * Core sites (hook.S, make_firmware.py): CALL FUN_019AD090 at 0x019F0A3C -> kn_save_service; the two stamp
 * snprintf CALLs -> _kn_stamp_stub (stock snprintf unless a feature's name is armed, then kn_snap_name).
 *   - the pass in which stock would save: OP1_EV_SAVE_HOLD (kind << 8 | slot); a feature that calls
 *     op1_snapshot_defer() in it gets the save held back: the held bytes are cleared, so stock takes its
 *     "released" branch (progress hidden), as after its own save.
 *   - op1_snapshot_save(kind, slot, name) (any thread) is performed on a later main loop pass with help and Shift
 *     up: the bank is set to `kind` for that one call, the slot's held byte set, the countdown at its last step and
 *     the name armed; stock saves (its own "_N", its own file and JSON writes) and the bank is put back.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_feature.h"

#ifdef OP1_HOST                                                 /* harness/save_test.c */
extern uint8_t host_held[8], host_running, host_help, host_shift_held;
extern int32_t host_count, host_run_state, host_bank;
int host_stock_save_pass(void);
int host_access(const char *path);
#define HELD          host_held
#define RUNNING       host_running
#define COUNT         host_count
#define RUN_STATE     host_run_state
#define HELP_HELD     host_help
#define SHIFT         host_shift_held
#define BANK          host_bank
#define STOCK_PASS    host_stock_save_pass
#define ACCESS(p)     host_access(p)
#else
#define HELD          ((volatile uint8_t *)0x01AACDBC)        /* one byte per sound key 1..8 */
#define RUNNING       (*(volatile uint8_t *)0x01AACDC4)
#define COUNT         (*(volatile int32_t *)0x01AACDC8)
#define RUN_STATE     (*(volatile int32_t *)0xFF801040)        /* core_run_state */
#define HELP_HELD     (*(volatile uint8_t *)0xFF9077F4)
#define SHIFT         (*(volatile uint8_t *)0x01DD7F78)        /* shift_held (shift_is_held 0x019D7C6C) */
#define BANK          (*(volatile int32_t *)0x01DE4C40)        /* page_pos_is_drum */
#define STOCK_PASS    ((int (*)(void))0x019AD090)
#define ACCESS(p)     (((int (*)(const char *, int))0x01A9A6B0)((p), 0))   /* yaffs_access: 0 = exists */
#endif

void kn_event(int id, int32_t arg);

static volatile int defer_asked;                               /* set by op1_snapshot_defer during SAVE_HOLD */
static volatile int in_save_hold;
static volatile int deferred = -1;                              /* kind << 8 | slot held back, -1 none */
static volatile int pending = -1;                               /* kind << 8 | slot to save, -1 none */
static char pending_name[OP1_SNAPSHOT_NAME_MAX + 1];
volatile int kn_snap_armed;                                     /* hook.S _kn_stamp_stub reads it */

static int name_ok(char c)
{
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-' ||
           c == '.' || c == ' ' || c == ',';
}

void op1_snapshot_defer(void) { if (in_save_hold) defer_asked = 1; }

int op1_snapshot_save(int kind, int slot, const char *name)
{
    int id = (kind & 1) << 8 | (slot & 7);
    if (kind < 0 || kind > 1 || slot < 0 || slot > 7 || pending >= 0 || deferred != id) return -1;
    int n = 0;
    for (const char *s = name; s && *s; s++) {
        if (n >= OP1_SNAPSHOT_NAME_MAX || !name_ok(*s)) return -1;   /* too long or not a file name character */
        pending_name[n++] = *s;
    }
    pending_name[n] = 0;
    deferred = -1;
    pending = id;                                               /* last: the main loop starts here */
    return 0;
}

int op1_snapshot_name_exists(int kind, const char *name)
{
    char path[96], *o = path;
    const char *pre = kind ? "/yaffs2/user/audio/preset_drum/snapshot/" : "/yaffs2/user/audio/preset_synth/snapshot/";
    while (*pre) *o++ = *pre++;
    int n = 0;
    for (; name && name[n]; n++) {
        if (n >= OP1_SNAPSHOT_NAME_MAX || !name_ok(name[n])) return 0;
        *o++ = name[n];
    }
    if (!n) return 0;
    for (const char *s = ".raw"; *s; s++) *o++ = *s;
    *o = 0;
    return ACCESS(path) == 0;
}

/* _kn_stamp_stub (hook.S), armed: the feature's name instead of the date stamp; n = the buffer (16 synth, 256 drum) */
int kn_snap_name(char *dst, int n)
{
    int i = 0;
    for (; pending_name[i] && i < n - 1; i++) dst[i] = pending_name[i];
    dst[i] = 0;
    return i;
}

static int one_held(void)                                       /* the slot of the only held sound key, or -1 */
{
    int slot = -1;
    for (int i = 0; i < 8; i++)
        if (HELD[i]) { if (slot >= 0) return -1; slot = i; }
    return slot;
}

/* main loop: CALL FUN_019AD090 at 0x019F0A3C */
int kn_save_service(void)
{
    int quiet = RUN_STATE != 1 && !HELP_HELD && !SHIFT;
    if (pending >= 0 && quiet) {                                /* a feature's save: one forged stock pass */
        int bank = BANK, kind = pending >> 8, slot = pending & 7;
        uint8_t held[8];
        for (int i = 0; i < 8; i++) { held[i] = HELD[i]; HELD[i] = (uint8_t)(i == slot); }
        BANK = kind;
        RUNNING = 1;
        COUNT = 0;                                              /* the last step: this pass saves */
        kn_snap_armed = pending_name[0] != 0;                   /* "" = the stock stamp */
        int r = STOCK_PASS();
        kn_snap_armed = 0;
        BANK = bank;
        for (int i = 0; i < 8; i++) HELD[i] = held[i] && i != slot;   /* keys still down stay flagged */
        pending = -1;
        return r;
    }
    int slot = one_held();
    if (quiet && slot >= 0 && RUNNING && COUNT == 0) {           /* stock saves in this pass */
        int id = (BANK & 1) << 8 | slot;
        defer_asked = 0; in_save_hold = 1;
        kn_event(OP1_EV_SAVE_HOLD, id);
        in_save_hold = 0;
        if (defer_asked && pending < 0) {                       /* a newer deferral replaces an unfinished one */
            deferred = id;
            for (int i = 0; i < 8; i++) HELD[i] = 0;            /* stock: "released", progress hidden */
        }
    }
    return STOCK_PASS();
}
