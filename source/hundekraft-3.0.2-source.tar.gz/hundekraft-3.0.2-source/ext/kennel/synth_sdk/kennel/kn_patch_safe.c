/*
 * Sound loading safety net (ported from hundekraft 2.7.2, op1r-src hk272-base 8f0374d / 50e1811). A sound that fails
 * parse_patch_json (0x01A037A8) ends in an assert: patch.cpp:390 "Invalid synth patch <type>:<name> - error N"
 * (synth slot loader 0x01A051E8, parser call 0x01A051F8) or patch.cpp:221 "Invalid drum patch ... error N"
 * (load_drum_patch, parser call 0x01A04BC0), and the OP-1 locks at every boot while the sound is stored.
 * Seen in the field: drum+ up to 2.7.1 stored gate as playmode 0, below the stock range (error 12), and an FX type
 * the parser does not know (error 22).
 * Selective repair follows op1r-src7cf11af (patch_repair.c, GPL-3.0-or-later + OP-1 permission).
 * Invalid drum pad words are clamped; invalid FX or LFO blocks are individually replaced
 * with stock filter/tremolo defaults and switched off. Bounded retries cover slot loads and
 * preset imports. Other errors remain errors. Repairs produce a log entry and toast.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>

#ifndef PARSE_PATCH
#define PARSE_PATCH  ((int (*)(void *, int))0x01A037A8)
#define JV_KEY       ((void *(*)(void *, const char *))0x019BFEB4)        /* Value::operator[](const char *) */
#define JV_IDX       ((void *(*)(void *, unsigned))0x019BFAF8)            /* Value::operator[](ArrayIndex) */
#define JV_SIZE      ((unsigned (*)(const void *))0x019BE8D8)             /* Value::size */
#define JV_ASSIGN    ((void *(*)(void *, const void *))0x019BDDC0)        /* Value::operator= */
#define JV_FROM_INT  ((void *(*)(void *, int))0x019BD890)                 /* Value(int) */
#define JV_FROM_BOOL ((void *(*)(void *, int))0x019BD832)                 /* Value(bool) (parser: fx_active) */
#define JV_FROM_STR  ((void *(*)(void *, const char *))0x019BDC4C)        /* Value(const char *) */
#define JV_DTOR      ((void (*)(void *, int))0x019BDD18)
#define JV_REMOVE    ((void (*)(void *, void *, const char *))0x019BEE88) /* removeMember(key) -> out */
#endif
enum { JV_INT = 1, JV_UINT = 2, JV_ARRAY = 6, JV_OBJECT = 7 };
static uint8_t jv_type(const void *v) { return ((const uint8_t *)v)[8]; }

void kn_log_line(const char *what, const char *msg);              /* kn_boot.c */
void op1_toast(const char *text);                                 /* kn_core.c */
static void report(const char *log, const char *toast, int r)
{
    kn_log_line("sound", r ? "repair failed" : log);
    op1_toast(toast);
}

/* ---- drum pads: clamp into the stock range ----
 * Range table 0x01DE5890 (filled at boot by 0x01A1E914), 64-byte rows of 8 x {min, max, 2 unused}; row 8 holds the
 * drum pad words, columns as the parser checks them. Clamping keeps a mode: playmode 0 -> 4096 is still gate
 * (value >> 13). */
#ifndef PAD_RANGES
#define PAD_RANGES ((const int16_t *)0x01DE5890 + 8 * 32)
#endif
static int clamp_pads(void *json)
{
    static const struct { const char *key; uint8_t col; } keys[] = { { "pitch", 0 }, { "playmode", 3 },
                                                                      { "reverse", 4 }, { "volume", 7 } };
    int changed = 0;
    if (jv_type(json) != JV_OBJECT) return 0;
    for (unsigned k = 0; k < sizeof keys / sizeof keys[0]; k++) {
        void *a = JV_KEY(json, keys[k].key);
        if (jv_type(a) != JV_ARRAY) continue;
        int lo = PAD_RANGES[keys[k].col * 4], hi = PAD_RANGES[keys[k].col * 4 + 1];
        for (unsigned i = 0, n = JV_SIZE(a); i < n && i < 24; i++) {
            void *v = JV_IDX(a, i);
            if (jv_type(v) != JV_INT && jv_type(v) != JV_UINT) continue;
            int w = *(const int32_t *)v;               /* 32-bit Int / UInt in the 8-byte union */
            int c = jv_type(v) == JV_UINT && w < 0 ? hi : w < lo ? lo : w > hi ? hi : w;
            if (c == w) continue;
            uint32_t tmp[4];                           /* an int Value owns no heap memory: no destructor needed */
            JV_FROM_INT(tmp, c);
            JV_ASSIGN(v, tmp);
            changed = 1;
        }
    }
    return changed;
}

/* ---- FX / LFO: stock defaults, switched off ---- */
static void set_ints(void *obj, const char *key, const int16_t *v)
{
    uint32_t t[4];                                     /* a Json::Value (16 bytes) */
    JV_REMOVE(obj, t, key); JV_DTOR(t, 2);             /* whatever it was: the null member below becomes an array */
    void *a = JV_KEY(obj, key);
    for (unsigned i = 0; i < 8; i++) {
        JV_FROM_INT(t, v[i]);                          /* an int Value owns no heap memory */
        JV_ASSIGN(JV_IDX(a, i), t);
    }
}

static void set_block(void *obj, const char *type, const char *name, const char *active, const char *params,
                      const int16_t *v)
{
    uint32_t t[4];
    JV_FROM_STR(t, name); JV_ASSIGN(JV_KEY(obj, type), t); JV_DTOR(t, 2);
    JV_FROM_BOOL(t, 0); JV_ASSIGN(JV_KEY(obj, active), t);
    set_ints(obj, params, v);
}

/* Stock parser errors22..24 concern FX only;25..27 concern LFO only.
 * Bounded retries preserve the other valid block and the synth/sample/ADSR data.
 * Shared by slot loading and all three preset insertion/import paths. */
const char *kn_lfo_name(void);
static int same(const char *a, const char *b)
{
    if (!a || !b) return 0;
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}
static int known_lfo(const char *name)
{
    static const char *const stock[] = { "tremolo", "value", "random", "element", "midi", "bend", "crank", "quad", 0 };
    for (const char *const *n = stock; *n; n++) if (same(name, *n)) return 1;
    return same(name, kn_lfo_name());
}
static const char *string_value(const void *v)
{
    return jv_type(v) == 4 ? *(const char *const *)v : 0;
}
/* Stock asInt/asBool can assert on containers or strings. Validate before calling
 * the parser, including object-with-eight-members (size() alone is insufficient).
 * Real words are permitted when representable without a narrowing wrap. */
static int word_value(const void *v)
{
    unsigned type = jv_type(v);
    if (type == 0 || type == 5) return 1;
    if (type == JV_INT) { int32_t n = *(const int32_t *)v; return n >= -32768 && n <= 32767; }
    if (type == JV_UINT) return *(const uint32_t *)v <= 32767;
    if (type == 3) {
        const uint32_t *w = v; /* little-endian IEEE double, no floating-point work */
        unsigned hi = w[1], exp = (hi >> 20) & 2047;
        return exp < 1038 || (hi == 0xc0e00000u && w[0] == 0); /* abs <32768, or -32768 */
    }
    return 0;
}
static int block_values(void *json, const char *params, const char *active)
{
    void *a = JV_KEY(json, params);
    if (jv_type(a) != JV_ARRAY || JV_SIZE(a) != 8) return 0;
    for (unsigned i = 0; i < 8; i++) if (!word_value(JV_IDX(a, i))) return 0;
    unsigned type = jv_type(JV_KEY(json, active));
    return type <= 3 || type == 5;
}
static int parse_safe(void *json, int mode, int drum)
{
    static const int16_t fx_filter[8] = { 7548, 0, 8272, 19572, 8000, 8000, 8000, 8000 };
    static const int16_t lfo_tremolo[8] = { 16000, 0, 0, 16000, 0, 0, 0, 0 };
    if (!json || jv_type(json) != JV_OBJECT) return PARSE_PATCH(json, mode);
    int pads = 0, fx = 0, lfo = 0;
    /* Repair metadata before stock asString/conversion calls, as upstream does. */
    const char *name = string_value(JV_KEY(json, "fx_type"));
    if (!name || !*name || !block_values(json, "fx_params", "fx_active")) {
        set_block(json, "fx_type", "filter", "fx_active", "fx_params", fx_filter); fx = 1;
    }
    if (!known_lfo(string_value(JV_KEY(json, "lfo_type"))) || !block_values(json, "lfo_params", "lfo_active")) {
        set_block(json, "lfo_type", "tremolo", "lfo_active", "lfo_params", lfo_tremolo); lfo = 1;
    }
    int r = PARSE_PATCH(json, mode);
    if (r && drum && (pads = clamp_pads(json))) r = PARSE_PATCH(json, mode);
    if (!fx && r >= 22 && r <= 24) {
        set_block(json, "fx_type", "filter", "fx_active", "fx_params", fx_filter);
        fx = 1; r = PARSE_PATCH(json, mode);
    }
    if (!lfo && r >= 25 && r <= 27) {
        set_block(json, "lfo_type", "tremolo", "lfo_active", "lfo_params", lfo_tremolo);
        lfo = 1; r = PARSE_PATCH(json, mode);
    }
    if (pads) report("drum pads clamped into range", "drum pads put back in range", r);
    if (fx) report("invalid fx reset", "fx reset on a sound", r);
    if (lfo) report("invalid lfo reset", "lfo reset on a sound", r);
    return r;
}
int kn_drum_parse_safe(void *json, int mode) { return parse_safe(json, mode, 1); }
int synth_load_parse(void *json, int mode) { return parse_safe(json, mode, 0); }
int patch_parse_safe(void *json, int mode) { return parse_safe(json, mode, 1); }
