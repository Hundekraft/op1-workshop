/*
 * Hook point "LFO types" (op1_feature_lfo.h, docs/feature-hooks.md): the core side. R246's sites stay patched by the
 * core (hook.S, make_firmware.py, dispatcher.c); they ask here whether a word set belongs to a feature LFO and call
 * the registered type. v1: one type, running in the MIDI LFO class.
 * Reserved: quad's name and word encoding are known here even when no quad feature is registered (its file missing
 * or broken), so a sound saved with quad still loads (no range assert at boot) and its LFO then does nothing.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_feature_lfo.h"

int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);

const op1_lfo_type *kn_lfo_type;                 /* the registered LFO type, 0 = none (all sites stock) */

#define QUAD_MARK 0xA5                           /* quad (lfo/quadlfo.c): word 7 = 0xA5xx */
static inline int quad_old_ctrl(int16_t c) { uint16_t m = (uint16_t)c & 0xE000; return m == 0x4000 || m == 0x6000; }

/* words of a released feature LFO, registered or not: quad's current format, and op1r <= 15 quad
 * (0x4000 / 0x6000 control words in 4..7) */
static int kn_lfo_reserved(const int16_t *w)
{
    if (((uint16_t)w[7] >> 8) == QUAD_MARK) return 1;
    return quad_old_ctrl(w[4]) && quad_old_ctrl(w[5]) && quad_old_ctrl(w[6]) && quad_old_ctrl(w[7]);
}

void kn_lfo_finish(void)                         /* kn_features_finish: first feature with a usable LFO type */
{
    for (int i = 0; i < kn_feature_count() && !kn_lfo_type; i++) {
        const op1_lfo_type *t = kn_feature_at(i)->lfo;
        if (t && t->name && t->match && t->stock_class == OP1_LFO_CLASS_MIDI && t->marker >= 0x80)
            kn_lfo_type = t;
    }
}

const char *kn_lfo_name(void) { return kn_lfo_type ? kn_lfo_type->name : 0; }

/* patch range check (dispatcher.c lfo_range_ok): word 7's high byte marks a feature LFO's words */
int kn_lfo_marker(int hi)
{
    return hi == QUAD_MARK || (kn_lfo_type && hi == kn_lfo_type->marker);
}

/* not stock MIDI LFO words: read_lfo_param must not range-check them, LfoMidi must not run them */
int kn_lfo_claims(const int16_t *w)
{
    return kn_lfo_reserved(w) || (kn_lfo_type && kn_lfo_type->match(w));
}

static inline const op1_lfo_type *owner(const int16_t *w)
{
    const op1_lfo_type *t = kn_lfo_type;
    return t && t->match(w) ? t : 0;
}

/* LfoMidi vtable apply entries for claimed words (hook.S QL_STUB); unowned (reserved) words: no modulation */
int kn_lfo_apply_synth(void *self, const int16_t *w, int pass)
{
    const op1_lfo_type *t = owner(w);
    return t && t->apply_synth ? t->apply_synth(self, w, pass) : 0;
}
int kn_lfo_apply_drum(void *self, const int16_t *w, int pass)
{
    const op1_lfo_type *t = owner(w);
    return t && t->apply_drum ? t->apply_drum(self, w, pass) : 0;
}
int kn_lfo_apply_fx(void *self, const int16_t *w, int pass)
{
    const op1_lfo_type *t = owner(w);
    return t && t->apply_fx ? t->apply_fx(self, w, pass) : 0;
}

/* LfoMidi vtable +0x1c note-on triggers (make_firmware DATA_PATCHES); the stock ones are bare RTS */
void kn_lfo_trig_synth(void *self, const int16_t *w)
{
    const op1_lfo_type *t = owner(w);
    if (t && t->trig_synth) t->trig_synth(self, w);
}
void kn_lfo_trig_drum(void *self, const int16_t *w)
{
    const op1_lfo_type *t = owner(w);
    if (t && t->trig_drum) t->trig_drum(self, w);
}
void kn_lfo_trig_fx(void *self, const int16_t *w)
{
    const op1_lfo_type *t = owner(w);
    if (t && t->trig_fx) t->trig_fx(self, w);
}

/* dispatcher.c midi_cc_hook / midi_start_hook */
void kn_lfo_midi_cc(int cc, int value)
{
    if (kn_lfo_type && kn_lfo_type->midi_cc) kn_lfo_type->midi_cc(cc, value);
}
void kn_lfo_midi_start(void)
{
    if (kn_lfo_type && kn_lfo_type->midi_start) kn_lfo_type->midi_start();
}
