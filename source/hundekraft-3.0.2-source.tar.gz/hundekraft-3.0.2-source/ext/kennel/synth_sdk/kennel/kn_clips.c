/*
 * Clip rows per track, for tape undo (op1_feature_tape.h op1_tape_clips_get / op1_tape_clips_set): a snapshot of a
 * track's clips and a replace-all, through R246's own clip pool calls so the pool and tape.db stay in step.
 *
 * R246 (docs/firmware/tape.md "Clip pool", Clips.cpp): the pool (tape_clips_instance 0x0195BBB4, 0x01AA8D70) holds 512
 * records of {channel, start, stop} (12 bytes), then has_clip u8[512] at +0x1800 and the free count at +0x1A00.
 * tape_clips_remove_channel 0x0195D688 (pool, channel) deletes a track's rows (pool flags, DELETE FROM clips queued
 * for the background file job); tape_clips_add 0x0195CCEC (pool, &{channel, start, stop}) takes the lowest free id and
 * queues INSERT INTO clips. tape_clips_add panics on a range it does not accept (start < 0, stop <= start, shorter
 * than the minimum clip length at 0x01AA7360, start > 0xF23F9F, stop > 0xF23FA0), so every range is checked here first.
 * Main loop only; refused while recording or while R246's clipboard queue has commands.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_feature_tape.h"

#define POOL_MAX 512
#ifdef OP1_HOST                                         /* harness/clips_test.c */
void *host_clips_instance(void);
void host_clips_remove_channel(void *pool, int ch);
int host_clips_add2(void *pool, const int32_t *clip);
extern int32_t host_min_clip, host_run, host_clip_cons2, host_clip_prod2;
#define CLIPS_INSTANCE   host_clips_instance
#define CLIPS_REMOVE_CH  host_clips_remove_channel
#define CLIPS_ADD        host_clips_add2
#define MIN_CLIP         host_min_clip
#define TAPE_RUN         host_run
#define CLIP_CONS        host_clip_cons2
#define CLIP_PROD        host_clip_prod2
#else
#define CLIPS_INSTANCE   ((void *(*)(void))0x0195BBB4)
#define CLIPS_REMOVE_CH  ((void (*)(void *, int))0x0195D688)
#define CLIPS_ADD        ((int (*)(void *, const int32_t *))0x0195CCEC)
#define MIN_CLIP         (*(volatile int32_t *)0x01AA7360)
#define TAPE_RUN         (*(volatile int32_t *)0xFF802960)
#define CLIP_CONS        (*(volatile int32_t *)0x01AA7330)
#define CLIP_PROD        (*(volatile int32_t *)0x01AA7334)
#endif
#define REC(pool, id)    ((const int32_t *)((const uint8_t *)(pool) + (id) * 12))
#define HAS(pool, id)    (((const uint8_t *)(pool))[0x1800 + (id)])
#define FREE_N(pool)     (*(const int32_t *)((const uint8_t *)(pool) + 0x1A00))

int op1_tape_clips_get(int track, op1_tape_clip *out, int max)
{
    if (track < 0 || track > 3) return -1;
    const void *pool = CLIPS_INSTANCE();
    int n = 0;
    for (int id = 0; id < POOL_MAX; id++) {
        if (!HAS(pool, id) || REC(pool, id)[0] != track) continue;
        op1_tape_clip c = { REC(pool, id)[1], REC(pool, id)[2] };
        if (n < max && out) {                           /* insertion by start */
            int k = n;
            while (k > 0 && out[k - 1].start > c.start) { out[k] = out[k - 1]; k--; }
            out[k] = c;
        } else if (out && max > 0 && c.start < out[max - 1].start) {
            int k = max - 1;                            /* full: keep the first `max` by start */
            while (k > 0 && out[k - 1].start > c.start) { out[k] = out[k - 1]; k--; }
            out[k] = c;
        }
        n++;
    }
    return n;
}

int op1_tape_clips_set(int track, const op1_tape_clip *clips, int n)
{
    if (track < 0 || track > 3 || n < 0 || (n && !clips) || TAPE_RUN == 1 || CLIP_CONS != CLIP_PROD) return -1;
    int32_t min = MIN_CLIP;
    for (int i = 0; i < n; i++) {                       /* what tape_clips_add accepts without a panic */
        int32_t a = clips[i].start, b = clips[i].stop;
        if (a < 0 || b <= a || b - a < min || a > 0xF23F9F || b > 0xF23FA0) return -1;
    }
    void *pool = CLIPS_INSTANCE();
    int mine = op1_tape_clips_get(track, 0, 0);
    if (FREE_N(pool) + mine < n) return -1;             /* not enough rows once the track's own are gone */
    CLIPS_REMOVE_CH(pool, track);
    for (int i = 0; i < n; i++) {
        int32_t c[3] = { track, clips[i].start, clips[i].stop };
        if (CLIPS_ADD(pool, c) < 0) return -1;
    }
    return 0;
}
