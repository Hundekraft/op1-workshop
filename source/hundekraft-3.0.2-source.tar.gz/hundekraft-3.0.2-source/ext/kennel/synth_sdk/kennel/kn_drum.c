/*
 * Drum type hook point (op1_feature_drum.h, docs/feature-hooks.md "Drum types"): the core side of every R246 site a
 * drum type needs. The functions keep the names hook.S, make_firmware.py (SLOTS) and dispatcher.c call them by
 * (they were drum+'s own, drumplus/ before the move); each one dispatches to the registered type or does the stock
 * thing.
 *
 * Kits: a drum patch with an OP1_DRUM_KEY ("op1r") object belongs to the drum type. The key is always kept across
 * load, so it is saved again even when no type is registered (the feature file missing or broken): such a kit loads
 * as the stock sampled kit it also is (same samples, regions and pad words; the type's extras are not played), its
 * browser row is the stock one, and it is the type's kit again once the type is back. Picking the type's row with
 * no type registered does nothing (the stock job would strip the kit's regions).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_synth.h"
#include "../op1_feature_drum.h"
#include "kn_drum_scope.h"

int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);

static const struct op1_drum_type *dtype;       /* the registered drum type, 0 = none */
static uint8_t has_key[OP1_DRUM_SLOTS];         /* slot's patch has an OP1_DRUM_KEY object (set on load / pick) */

void kn_drum_finish(void)
{
    for (int i = 0; i < kn_feature_count() && !dtype; i++) {
        const struct op1_drum_type *t = kn_feature_at(i)->drum;
        if (t && t->api == OP1_DRUM_API && t->id == OP1_DRUM_TYPE_ID) dtype = t;
    }
    if (!dtype || !dtype->load) return;
    for (int s = 0; s < OP1_DRUM_SLOTS; s++)    /* kits loaded before the type registered (boot order) */
        if (has_key[s]) dtype->load(s, ((void *(*)(void *, const char *))0x019BFEB4)(OP1_DRUM_PATCH_JSON(s), OP1_DRUM_KEY));
}
static int slot_of_type(int slot) { return dtype && has_key[slot & 7]; }

/* ---- DrumSampler vtable render / note_on / note_off (make_firmware.py SLOTS) ---- */
void dp_fw_render(void *self, int16_t *out, const op1_drum_pad *pad)
{
    uint32_t t0=op1_cycles();
    if (dtype && dtype->render) dtype->render(self, out, pad); else OP1_DRUM_STOCK_RENDER(self, out, pad);
    sm_cy[SMC_DRUM]+=op1_cycles()-t0;
}
void dp_fw_note_on(void *self, const op1_drum_pad *pad)
{
    if (dtype && dtype->note_on) dtype->note_on(self, pad); else OP1_DRUM_STOCK_NOTE_ON(self, pad);
}
void dp_fw_note_off(void *self, const op1_drum_pad *pad)
{
    if (dtype && dtype->note_off) dtype->note_off(self, pad); else OP1_DRUM_STOCK_NOTE_OFF(self, pad);
}

/* ---- persistence ----
 * parse_patch_json (0x01A037A8) rebuilds the patch from its known keys and assigns the result over the patch
 * (0x01A044A8: operator=(patch, fresh)): dp_keep_op1r copies the key across first, so it survives load and is saved
 * again by the stock writer. load_drum_patch's call of the parser (0x01A04BC0) sets the drum load scope (kn_drum_scope.h): every parse
 * through it is a drum patch (8 slots and the kit table), and a slot object's keep step goes to the drum type. */
#define JV_KEY    ((void *(*)(void *, const char *))0x019BFEB4)       /* Value::operator[](const char *) */
#define JV_ASSIGN ((void *(*)(void *, const void *))0x019BDDC0)       /* Value::operator= */
#define PARSE_PATCH ((int (*)(void *, int))0x01A037A8)
#define DRUM_PATCHES 0x01DDD9A8                                       /* 8 drum patch objects x 0x38 (JSON at +4) */
enum { JV_NULL = 0, JV_STRING = 4, JV_ARRAY = 6, JV_OBJECT = 7 };
static uint8_t jv_type(const void *v) { return ((const uint8_t *)v)[8]; }

static kn_drum_scope scope = { 0, -1, 0 };

/* Inside a parse through the drum load site (slots and kit table). For the instrument name compare (dispatcher.c
 * instr_name_eq): op1r-src PR #5 resolves unknown non-empty type names to dbox instead of iter while this is set. */
int dp_is_loading_patch(void) { return scope.depth > 0; }

void *dp_keep_op1r(void *patch, void *fresh)
{
    void *old = JV_KEY(patch, OP1_DRUM_KEY);          /* (adds a null member if absent: patch is overwritten next) */
    int keep = jv_type(old) == JV_OBJECT;
    if (keep) JV_ASSIGN(JV_KEY(fresh, OP1_DRUM_KEY), old);
    int slot = kn_drum_keep_slot(&scope, patch);
    if (slot >= 0) {
        has_key[slot] = (uint8_t)keep;
        if (dtype && dtype->load) dtype->load(slot, keep ? JV_KEY(fresh, OP1_DRUM_KEY) : 0);
    }
    uint32_t off=(uint32_t)patch-(0x01DDD7E8+4);
    if(off<8*0x38 && off%0x38==0){extern void sp_slot_loaded(int,void *);sp_slot_loaded((int)(off/0x38),keep?JV_KEY(fresh,OP1_DRUM_KEY):0);}
    return JV_ASSIGN(patch, fresh);
}

int kn_drum_parse_safe(void *json, int mode);        /* kn_patch_safe.c: parse, on a failure clamp pads / reset FX */
int dp_load_parse(void *json, int mode)
{
    return kn_drum_parse_scoped(&scope, json, kn_drum_slot_of((uint32_t)json, DRUM_PATCHES + 4, 0x38, OP1_DRUM_SLOTS),
                                mode, kn_drum_parse_safe);
}

/* ---- drum type browser (Shift + T1): the type's drum_types row (id OP1_DRUM_TYPE_ID, make_firmware.py) ----
 * Start row (CALL patch_01a01ffe at 0x01977900 in DrumController). The stock id comes from drum_type_id_by_name
 * 0x01A01EF4: drum_types row id, or for "type": "drum" minus the index of the kit with the same name in the kit
 * table 0x01DE20FC, which holds factory AND user kits (drum_presets + drum_user). The browser list (patch_01A025E8)
 * has only factory kits: a user kit's id is not found and the browser starts on row 0 (DBOX), and turning from
 * there loads a factory kit. So: a slot of the type -> its row; an id the list does not have -> 0 (DRUM, nothing
 * loaded until a turn; one step down = the type's row, which keeps the live kit). */
#define DP_DRUM_ID   ((int (*)(int, uint8_t *))0x01A01FFE)
#define DP_TYPE_LIST ((uint8_t *(*)(void))0x01A025E8)
static int dp_list_has(int id)
{
    uint8_t *l = DP_TYPE_LIST();                              /* rows 0x30 (+0x1c id, +0x24/+0x28 items 0x20, +0x1c id) */
    for (uint8_t *r = *(uint8_t **)(l + 4); r < *(uint8_t **)(l + 8); r += 0x30) {
        if (*(int *)(r + 0x1c) == id) return 1;
        for (uint8_t *it = *(uint8_t **)(r + 0x24); it < *(uint8_t **)(r + 0x28); it += 0x20)
            if (*(int *)(it + 0x1c) == id) return 1;
    }
    return 0;
}
int dp_browser_id(int slot, uint8_t *found)
{
    int id = DP_DRUM_ID(slot, found);
    if (slot_of_type(slot)) return OP1_DRUM_TYPE_ID;              /* (slot word 0xFF8016D8 & 7, as elsewhere) */
    if (!dp_list_has(id)) { id = 0; *found = 0; }
    return id;
}

/* The stock type job 0x0193F86C (job +4 slot, +8 selection: <= 0 kit -n, > 0 drum_types id) would strip the kit's
 * regions for a type row. dp_type_job (job vtable slot) handles the type's row itself: a sampled kit ("type":
 * "drum") keeps everything and gets OP1_DRUM_KEY: {"engine": name}, then UI refresh and slot save as the stock job.
 * Any other selection first drops the key (a new kit / dbox is a stock drum again; the job's reload clears the
 * type's slot through load(slot, 0)). */
#define TYPE_JOB     ((void (*)(void *))0x0193F86C)
#define SAVE_SLOT    ((void (*)(void *))0x01940574)              /* job: +4 byte drum, +8 slot: UPDATE ..._slots */
#define UI_SLOT      ((void (*)(int))0x019C2BA0)
#define UI_SIGNAL    ((void (*)(void))0x019C2F04)                /* KeyHandler::signal */
#define JV_FROM_STR  ((void *(*)(void *, const char *))0x019BDC4C) /* Value(const char *) */
#define JV_DTOR      ((void (*)(void *, int))0x019BDD18)
#define JV_REMOVE    ((void (*)(void *, void *, const char *))0x019BEE88)   /* removeMember(key) -> out */

static int jv_is_str(void *v, const char *s)
{
    if (jv_type(v) != JV_STRING) return 0;
    const char *p = *(const char *const *)v;
    if (!p) return 0;
    while (*s && *p == *s) p++, s++;
    return *p == *s;
}

void dpu_sync_auto(void);                                        /* dispatcher.c: screens for 0x10 / 0x17 */

void dp_type_job(void *job)
{
    int slot = *(int32_t *)((uint8_t *)job + 4), sel = *(int32_t *)((uint8_t *)job + 8);
    if ((uint32_t)slot >= OP1_DRUM_SLOTS) { TYPE_JOB(job); return; }
    void *json = OP1_DRUM_PATCH_JSON(slot);
    uint32_t tmp[4];                                             /* a Json::Value (16 bytes) */
    if (sel != OP1_DRUM_TYPE_ID) {
        extern void kn_ds_type_changing(void *) __attribute__((weak));
        extern void kn_ds_type_changed(void) __attribute__((weak));
        if (kn_ds_type_changing) kn_ds_type_changing(json);
        JV_REMOVE(json, tmp, OP1_DRUM_KEY); JV_DTOR(tmp, 2);
        has_key[slot] = 0;
        dpu_sync_auto();
        TYPE_JOB(job);
        if (kn_ds_type_changed) kn_ds_type_changed();
        return;
    }
    if (!dtype) return;                                          /* the row without its type: keep the kit as it is */
    if (!jv_is_str(JV_KEY(json, "type"), "drum")) return;     /* dbox: no sample regions to keep */
    void *op = JV_KEY(json, OP1_DRUM_KEY);
    if (jv_type(op) != JV_OBJECT) {                              /* null -> object on the first key */
        JV_FROM_STR(tmp, dtype->name);
        JV_ASSIGN(JV_KEY(op, "engine"), tmp);
        JV_DTOR(tmp, 2);
    }
    has_key[slot] = 1;
    dpu_sync_auto();
    UI_SLOT(slot);
    UI_SIGNAL();
    struct { uint32_t vt; uint8_t drum, pad[3]; int32_t slot; } save = { 0, 1, { 0, 0, 0 }, slot };
    SAVE_SLOT(&save);
}

/* ---- pages: screen objects for slots 0x10 (T1) / 0x17 (T2), swapped in while the drum slot is of the type ----
 * dispatcher.c builds the objects at screen construction (dpu_objects / dpu_vtable / SCREEN_drumplus), loads them
 * (dpu_set_stock) and swaps them on every key event (se_swap -> dpu_screen_for / dpu_sync). */
#define SCREEN_TABLE    ((void **)0x01DF4E54)
#define CURRENT_SCREEN  (*(volatile int *)0x018B65C8)
#define DRUM_MODE       (*(volatile int *)0x01DE4C40 == 1)

static uint32_t dpu_scr[2][32], dpu_vt[10];
static void *dpu_stock[2];
static uint8_t dpu_ready;

static int dpu_slot_type(void) { return DRUM_MODE && dtype && dtype->page_draw && has_key[OP1_DRUM_SLOT_CUR]; }

/* the object for slot 0x10 / 0x17 when no editor is open; stock = the boot-time objects */
void *dpu_screen_for(int id)
{
    int i = id == 0x17;
    if (!dpu_ready || (id != 0x10 && id != 0x17)) return 0;
    return dpu_slot_type() ? (void *)dpu_scr[i] : dpu_stock[i];
}
void dpu_sync(int editor_open_on_10)
{
    if (!dpu_ready) return;
    if (!editor_open_on_10) SCREEN_TABLE[0x10] = dpu_screen_for(0x10);
    SCREEN_TABLE[0x17] = dpu_screen_for(0x17);
}
static int dpu_page(void)                                        /* 0 / 1 if a type page is shown, else -1 */
{
    if (!dpu_ready || !dpu_slot_type()) return -1;
    int id = CURRENT_SCREEN;
    if (id == 0x10 && SCREEN_TABLE[0x10] == (void *)dpu_scr[0]) return 0;
    if (id == 0x17 && SCREEN_TABLE[0x17] == (void *)dpu_scr[1]) return 1;
    return -1;
}

/* returns 1 if consumed (else the stock controller gets the turn) */
int dpu_knob(int knob, int delta)
{
    int page = dpu_page();
    if (page < 0 || knob < 0 || knob > 3 || !dtype->page_turn) return 0;
    return dtype->page_turn(page, OP1_DRUM_SLOT_CUR, knob, delta);
}
int dpu_key(int code, int pressed)                               /* encoder presses 0x3B..0x3E */
{
    int page = dpu_page();
    if (page < 0 || code < 0x3B || code > 0x3E) return 0;
    if (pressed && dtype->page_press) dtype->page_press(page, OP1_DRUM_SLOT_CUR, code - 0x3B);
    return 1;
}

static void dpu_init(void *scr) { (void)scr; if (dtype && dtype->page_init) dtype->page_init(); }
static void dpu_update(void *scr, int dt)
{
    op1_screen_draw(scr, dt);
    if (dtype && dtype->page_draw)
        dtype->page_draw(scr == (void *)dpu_scr[1], OP1_DRUM_SLOT_CUR, op1_raster());
}
const op1_screen_t SCREEN_drumplus = { dpu_init, dpu_update };

uint32_t *dpu_objects(int i) { return dpu_scr[i]; }
uint32_t *dpu_vtable(void) { return dpu_vt; }
void dpu_set_stock(void *t1, void *t2) { dpu_stock[0] = t1; dpu_stock[1] = t2; dpu_ready = t1 && t2; }
