/*
 * Settings service for features (op1_feature.h): small values saved in op1.db, table op1rsettings (key TEXT PRIMARY
 * KEY, val), the table chord and the settings page already use. Keys are "<feature>.<key>". Integers are stored as
 * numbers, strings as text; both through R246's db2 helpers (read: db2_get, write: op1_db_write, which reports errors
 * instead of asserting). Not from the audio thread. Also the list of switched-off plugins (kn_plugin_off).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")
#include "../op1_synth.h"
#include "../op1_feature.h"

#define DB_HANDLE ((void *(*)(void))0x0196DD44)
#define DB_EXEC   ((void (*)(void *, const char *))0x0196F950)
#define DB_GET    ((void (*)(void *, void *, const char *))0x0196FBD0)
#define OP_DELETE ((void (*)(void *))0x01A5E310)
typedef struct { uint32_t alloc; union { char buf[16]; char *ptr; } u; uint32_t size, cap; uint32_t pad; } st_dstr;
static const char CREATE[] = "CREATE TABLE IF NOT EXISTS op1rsettings (key TEXT PRIMARY KEY, val INTEGER NOT NULL)";

static char *cat(char *d, const char *s) { while (*s) *d++ = *s++; *d = 0; return d; }
static int ok_char(char c)
{
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == ' ' || c == '.' ||
           c == '_' || c == ',' || c == ':' || c == '-';
}
static int ok_str(const char *s, int max) { int i = 0; for (; s[i]; i++) if (i >= max || !ok_char(s[i])) return 0; return 1; }
static char *key_of(char *o, const char *feature, const char *key) { return cat(cat(cat(o, feature), "."), key); }

/* the row's value as text into out (size bytes); its length, 0 if there is none */
static int get_text(const char *feature, const char *key, char *out, int size)
{
    if (!ok_str(feature, 15) || !ok_str(key, 31) || size < 1) return 0;
    char sql[128];
    cat(key_of(cat(sql, "SELECT val FROM op1rsettings WHERE key='"), feature, key), "'");
    void *db = DB_HANDLE();
    DB_EXEC(db, CREATE);
    st_dstr s = { 0 };
    DB_GET(&s, db, sql);
    const char *p = s.cap > 15 ? s.u.ptr : s.u.buf;
    int n = 0;
    for (; (uint32_t)n < s.size && n < size - 1; n++) out[n] = p[n];
    out[n] = 0;
    if (s.cap > 15 && s.u.ptr) OP_DELETE(s.u.ptr);
    return (int)s.size;
}

static void put(const char *feature, const char *key, const char *val, int quoted)
{
    if (!ok_str(feature, 15) || !ok_str(key, 31)) return;
    char sql[256], *o = key_of(cat(sql, "INSERT OR REPLACE INTO op1rsettings VALUES ('"), feature, key);
    o = cat(cat(cat(cat(o, "',"), quoted ? "'" : ""), val), quoted ? "')" : ")");
    void *db = DB_HANDLE();
    DB_EXEC(db, CREATE);
    op1_db_write(db, sql);
}

int32_t op1_setting_get(const char *feature, const char *key, int32_t def)
{
    char t[16];
    if (!get_text(feature, key, t, sizeof t)) return def;
    int neg = t[0] == '-', i = neg;
    int32_t v = 0;
    if (t[i] < '0' || t[i] > '9') return def;
    for (; t[i] >= '0' && t[i] <= '9'; i++) v = v * 10 + (t[i] - '0');
    return neg ? -v : v;
}

void op1_setting_set(const char *feature, const char *key, int32_t value)
{
    char d[12], t[12];
    int n = 0, neg = value < 0;
    uint32_t u = neg ? (uint32_t)-value : (uint32_t)value;
    do d[n++] = (char)('0' + u % 10); while (u /= 10);
    int k = 0;
    if (neg) t[k++] = '-';
    while (n) t[k++] = d[--n];
    t[k] = 0;
    put(feature, key, t, 0);
}

int op1_setting_get_str(const char *feature, const char *key, char *out, int size)
{
    return get_text(feature, key, out, size);
}

void op1_setting_set_str(const char *feature, const char *key, const char *value)
{
    if (ok_str(value, 160)) put(feature, key, value, 1);         /* letters only: no quoting to escape */
}

/* switched-off plugins and features: "kennel.off" = "name,name,..." (the plugins page writes it). With every plugin a
 * file it can name all of them: up to 64 type names, longer than op1_setting_set_str's 160 (devupd DU_OFF_MAX). */
#define KN_OFF_MAX 1023
void kn_off_store(const char *names)                             /* OFF_SET (du_fw.c, main loop) */
{
    static char sql[KN_OFF_MAX + 80];
    if (!ok_str(names, KN_OFF_MAX)) return;                       /* letters only: no quoting to escape */
    cat(cat(cat(sql, "INSERT OR REPLACE INTO op1rsettings VALUES ('kennel.off','"), names), "')");
    void *db = DB_HANDLE();
    DB_EXEC(db, CREATE);
    op1_db_write(db, sql);
}
static char off_list[KN_OFF_MAX + 1];                                       /* as read at boot: changes apply at the next boot */
const char *kn_off_boot(void)
{
    static int loaded;
    if (!loaded) { loaded = 1; get_text("kennel", "off", off_list, sizeof off_list); }
    return off_list;
}

int kn_plugin_off(const char *name)
{
    for (const char *p = kn_off_boot(); *p; ) {
        const char *a = name;
        while (*a && *a == *p) { a++; p++; }
        if (!*a && (!*p || *p == ',')) return 1;
        while (*p && *p != ',') p++;
        if (*p == ',') p++;
    }
    return 0;
}
