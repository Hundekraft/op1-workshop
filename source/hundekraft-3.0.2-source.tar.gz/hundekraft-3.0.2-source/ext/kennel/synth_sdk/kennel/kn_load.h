/*
 * kennel plugin loader: checks and relocation of one plugin file (docs/plugin-format.md), the same steps and order
 * as the reference loader tools/kennel/reloc.py. No firmware calls here: kn_boot.c reads the files and registers
 * the result; the host test (harness/kennel_load_host.c) runs this file on the PC against reloc.py.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_LOAD_H
#define KN_LOAD_H
#include <stdint.h>

#define KN_FORMAT_VERSION 1
#define KN_HEADER_SIZE    144
#define KN_NONE           0xFFFFFFFFu
#define KN_KIND_SYNTH     1
#define KN_KIND_FX        2
#define KN_KIND_FEATURE   3
#define KN_FLAG_USES_SAMPLE 1u
#define KN_FLAG_PAGE2       2u
#define KN_FLAG_STEREO      4u
#define KN_FLAG_INPUT       8u

typedef struct { const char *name; uint32_t addr; } kn_export;

/* What a checked file says (pointers point into the file buffer). */
typedef struct {
    uint8_t  kind, legacy_order;
    char     type_name[16];          /* NUL-terminated copy */
    uint32_t flags;
    int16_t  defaults[4], page2[4];
    uint32_t image_size, load_size, image_align, text_size;
    uint32_t entry_offset, screen_offset;
    uint32_t hdr_off;                /* 0, or where the header starts after the SVG prefix */
    const uint8_t *svg;              /* 0 if none; else the file itself starts with the screen SVG */
    uint32_t svg_size;
    uint32_t crc;                    /* the header's crc32 */
    const char *claims, *author, *version;   /* extension table entries (NUL-terminated; claims: a NUL-separated
                                                list ending in an empty string), 0 if absent */
} kn_info;

/* Check `file` (size bytes) and fill `info`. 0 = ok, else *err says why (a static string). */
int kn_parse(const uint8_t *file, uint32_t size, uint16_t api_version, kn_info *info, const char **err);

/* Copy the image to `dst` (which will run at address `base`, `cap` bytes available), zero .bss and apply the
 * relocations; imports are looked up in `exports` (n entries). 0 = ok, else *err. Call kn_parse first. */
int kn_relocate(const uint8_t *file, const kn_info *info, uint8_t *dst, uint32_t base, uint32_t cap,
                const kn_export *exports, int n, const char **err);

#endif
