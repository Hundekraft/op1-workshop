/* Keep physical-key identity across octave changes through the note pipeline.
 * R246 transposes its final held voices in place; scale/chord remember earlier
 * input notes, so a later key-up can miss their records. Release/replay physical
 * keys through the same pipeline around the stock octave change instead.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later + OP-1 firmware permission. */
#include "../op1_synth.h"
#include "../op1_feature_midi.h"
#include "../op1_feature_tape.h"
#ifdef OP1_HOST
extern int host_keys_mode,host_keys_slot,host_keys_oct[8];
extern uint8_t host_keys_held[24];
void host_keys_ctor(op1_note *,int,int);
int host_keys_octave(int);
void host_keys_reset_stock(void);
void host_keys_slot_stock(int);
#define MODE host_keys_mode
#define SLOT host_keys_slot
#define OCT host_keys_oct[host_keys_slot]
#define KEY_HELD host_keys_held
#define CTOR host_keys_ctor
#define STOCK_OCT host_keys_octave
#define RESET_STOCK host_keys_reset_stock
#define SLOT_STOCK host_keys_slot_stock
#else
#define MODE (*(volatile int *)0x01DE4C40)
#define SLOT (*(volatile int *)0xFF8016D4 & 7)
#define OCT (((const volatile int *)0x01DFE4E0)[SLOT])
#define KEY_HELD ((const volatile uint8_t *)0x01AAD488)
#define CTOR ((void (*)(op1_note *,int,int))0x01A85014)
#define STOCK_OCT ((int (*)(int))0x01A86158)
void kn_notes_reset_stock(void);
void kn_keys_slot_stock(int);
#define RESET_STOCK kn_notes_reset_stock
#define SLOT_STOCK kn_keys_slot_stock
#endif
static op1_note keys[24];
static uint32_t held;
static int slot=-1;
void kn_keys_reset(void){held=0;}
void kn_keys_sync(void) { if(MODE!=0 || slot!=SLOT){held=0;slot=SLOT;} }
void kn_keys_down(op1_note *n,int key,int velocity)
{
    CTOR(n,key,velocity); kn_keys_sync();
    if(MODE==0 && (unsigned)key<24){keys[key]=*n;held|=1u<<key;}
}
void kn_keys_up(op1_note *n,int key,int velocity)
{
    CTOR(n,key,velocity); kn_keys_sync();
    if(MODE==0 && (unsigned)key<24 && (held&(1u<<key))){n->note=keys[key].note;held&=~(1u<<key);}
}
/* Both stock octave and slot changes transpose final held voices in place.
 * Remove physical inputs through Scale/Chord first, then rebuild them at the new
 * slot/octave, rather than moving only their already-generated output notes. */
extern volatile int kn_src_force;
static uint32_t release_keys(void)
{
    int source=kn_src_force;kn_src_force=OP1_SRC_KEYS;
    uint32_t replay=0;
    for(int k=0;k<24;k++)if(held&(1u<<k)){
        if(!KEY_HELD[k]){held&=~(1u<<k);continue;}
        op1_key_up(&keys[k]);replay|=1u<<k;
    }
    kn_src_force=source;return replay;
}
static void replay_keys(uint32_t replay)
{
    int source=kn_src_force;kn_src_force=OP1_SRC_KEYS;
    slot=SLOT;
    for(int k=0;k<24;k++)if(replay&(1u<<k)){
        CTOR(&keys[k],k,keys[k].velocity);
        if((unsigned)keys[k].note<128){held|=1u<<k;op1_key_down(&keys[k],0);}
        else held&=~(1u<<k);
    }
    kn_src_force=source;
}
int kn_keys_octave(int dir)
{
    kn_keys_sync();
    if(MODE!=0 || (dir!=-1 && dir!=1) || OCT+dir < -4 || OCT+dir > 4)return STOCK_OCT(dir);
    uint32_t replay=release_keys();int oct=STOCK_OCT(dir);replay_keys(replay);
    return oct;
}
void kn_keys_slot(int next)
{
    kn_keys_sync();
    if(MODE!=0 || (unsigned)next>=8 || next==SLOT){SLOT_STOCK(next);return;}
    uint32_t replay=release_keys();SLOT_STOCK(next);replay_keys(replay);
}

/* Every stock voice reset also invalidates note-pipeline/physical-key histories.
 * Clearing only for Randomiser left stale Scale/Chord records after mode/slot
 * changes and other stock reset paths. Delivered on the reset caller's thread. */
void kn_event(int,int32_t);
void kn_notes_reset(void)
{
    RESET_STOCK();
    kn_keys_reset();
    kn_event(OP1_EV_NOTES_RESET,0);
}
