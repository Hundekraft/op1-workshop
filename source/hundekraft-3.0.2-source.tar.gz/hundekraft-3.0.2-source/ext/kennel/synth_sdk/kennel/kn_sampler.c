/*
 * Sampler hook point (op1_feature_sampler.h, docs/feature-hooks.md "Sampler"): TE's sampler screens, the slot's sample
 * buffer and markers, base_freq and a main-loop job runner, as core services. No patch site of its own: it reads R246
 * state (screens, slots, buffers, the drum pad table) and calls R246's own setters; kn_core.c's main loop pass calls
 * kn_sampler_service.
 *   synth sampler  screen 6 (stock object vtable 0x01911424), engine 6 (0xFF8016E4[slot]), markers = knob words
 *                  0..3 (fractions of the 6 s buffer, 32768 = 1.0), base_freq in the patch JSON root
 *   drum sampler   screen 0x10 (stock vtable 0x0190FAF4), engine 8 (0xFF801704[slot]), markers = the live pad table
 *                  (0x01AAADB4 + slot * 0x180, 24 keys x 8 int16: +1 / +2 start / end >> 16, +5 / +6 low bits >> 1,
 *                  fractions x 2^31 of 12 s, as screens/sampedit.c)
 * With OP1_HOST the R246 state is the struct kn_sampler_host (fake-core tests).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_synth.h"
#include "../op1_feature_sampler.h"

#define CAP_SYNTH   (264600 - 8)                /* audio after the 8 guard samples */
#define CAP_DRUM    (529200 - 8)
#define FULL_DRUM   529200                      /* the pad table's fractions are of the whole buffer */
#define FULL_SYNTH  CAP_SYNTH                   /* knob words: fractions of the audio (as sampedit.c) */

void kn_log_line(const char *what, const char *msg);

#ifdef OP1_HOST
#include "kn_sampler_host.h"
kn_sampler_host_t kn_sampler_host;
#define H kn_sampler_host
static int cur_screen(void) { return H.screen; }
static int stock_screen(int id) { (void)id; return H.stock; }
static int synth_slot(void) { return H.synth_slot & 7; }
static int drum_slot(void) { return H.drum_slot & 7; }
static int synth_type(int s) { (void)s; return H.synth_type; }
static int drum_type(int s) { (void)s; return H.drum_type; }
static int drum_key(void) { return H.key; }
static int is_busy(void) { return H.busy; }
static int16_t *synth_data(int s) { (void)s; return H.data; }
static int16_t *drum_data(int s) { (void)s; return H.data; }
static int16_t *synth_words(int s) { (void)s; return H.words; }
static int16_t *pad_table(int s) { (void)s; return H.pads; }
static uint32_t peaks_hash(int kind, int s) { (void)kind; (void)s; return H.sound; }
static void persist(int kind, int s, int audio) { (void)kind; (void)s; H.commits++; if (audio) H.audio_commits++; }
static int bf_get(int s, uint32_t b[2]) { (void)s; if (!H.has_bf) return 0; b[0] = H.bf[0]; b[1] = H.bf[1]; return 1; }
static void bf_set(int s, const uint32_t b[2], uint32_t f32) { (void)s; H.has_bf = 1; H.bf[0] = b[0]; H.bf[1] = b[1]; H.bf32 = f32; H.commits++; }
static uint32_t cycles(void) { return H.cycles += 1000; }
static void overview_service(void) {}
#else
#define SCREEN_TABLE  ((void *volatile *)0x01DF4E54)
#define CUR_SCREEN_ID (*(volatile int *)0x018B65C8)
static int cur_screen(void) { return CUR_SCREEN_ID; }
static int stock_screen(int id)                 /* the stock object (vtable at +0xC) is the one in the table */
{
    const uint32_t *o = (const uint32_t *)SCREEN_TABLE[id];
    return o && o[3] == (id == 6 ? 0x01911424u : 0x0190FAF4u);
}
static int synth_slot(void) { return *(volatile int *)0xFF8016D4 & 7; }
static int drum_slot(void) { return *(volatile int *)0xFF8016D8 & 7; }
static int synth_type(int s) { return *(volatile int *)(0xFF8016E4 + s * 4); }
static int drum_type(int s) { return *(volatile int *)(0xFF801704 + s * 4); }
static int drum_key(void) { int k = *(volatile int *)0xFF801044; return k >= 0 && k < 24 ? k : 0; }
static int is_busy(void)                        /* tape run 1 = recording; keyboard-to-sample flags (0x019DEE1C clears them) */
{
    return *(volatile int32_t *)0xFF802960 == 1 || *(volatile uint8_t *)0x01DD84F5 || *(volatile uint8_t *)0x01DD84F6;
}
static uint8_t *synth_sb(int s) { return (uint8_t *)op1_sample_buffer(s); }
static uint8_t *drum_sb(int s) { uint32_t *o = ((uint32_t **)0x01CC10CC)[s]; return o ? (uint8_t *)o[0] : 0; }
static int16_t *sb_data(uint8_t *sb) { return sb && *(int16_t **)sb ? *(int16_t **)sb + OP1_SAMPLE_GUARD : 0; }
static int16_t *synth_data(int s) { return sb_data(synth_sb(s)); }
static int16_t *drum_data(int s) { return sb_data(drum_sb(s)); }
static int16_t *synth_words(int s) { return (int16_t *)op1_synth_knobs(s); }
static int16_t *pad_table(int s) { return (int16_t *)(0x01AAADB4 + s * 0x180); }
static uint32_t peaks_hash(int kind, int s)     /* the overview (one peak per 256 samples) identifies the sound */
{
    uint8_t *sb = kind ? drum_sb(s) : synth_sb(s);
    if (!sb) return 0;
    const int16_t *pk = (const int16_t *)(sb + 4);
    uint32_t h = 2166136261u;
    for (int i = 0; i < OP1_PEAK_BUCKETS; i += 3) h = (h ^ (uint16_t)pk[i]) * 16777619u;
    return h;
}
#define PATCH_S(s)     ((void *)(0x01DDD7E8 + ((s) & 7) * 0x38))
#define PATCH_D(s)     ((void *)(0x01DDD9A8 + ((s) & 7) * 0x38))
#define SET_KNOBS      ((void (*)(void *, const int16_t *))0x01A00D14)   /* knob words -> patch JSON (+ changed) */
#define DRUM_TO_PATCH  ((void (*)(void *))0x019FFC50)                   /* live pad table -> patch JSON (+ changed) */
#define DIRTY_S        ((void (*)(int))0x019412AC)                     /* bg saver: synth_<slot>.raw */
#define DIRTY_D        ((void (*)(int))0x01941286)                     /* bg saver: drum_<slot>.raw */
/* the overview (one peak per 256 samples, as SampleBuffer::load_file) is rebuilt on the main loop, OV_CHUNK samples
 * a pass (the whole 12 s took ~2.5M cycles in one go); then the background saver writes the sample file */
#define OV_CHUNK 32768
static uint8_t *volatile ov_sb;
static int32_t ov_pos, ov_cap;
static int ov_kind, ov_slot;
static void persist(int kind, int s, int audio)
{
    if (kind) DRUM_TO_PATCH(PATCH_D(s)); else SET_KNOBS(PATCH_S(s), synth_words(s));
    if (!audio) return;
    uint8_t *sb = kind ? drum_sb(s) : synth_sb(s);
    if (!sb) { if (kind) DIRTY_D(s); else DIRTY_S(s); return; }
    int16_t *pk = (int16_t *)(sb + 4);
    for (int i = 0; i < OP1_PEAK_BUCKETS; i++) pk[i] = 0;
    ov_kind = kind; ov_slot = s; ov_pos = 0; ov_cap = *(int32_t *)(sb + 0x1038);
    ov_sb = sb;                                                 /* last: the main loop starts here */
}
static void overview_service(void)
{
    uint8_t *sb = ov_sb;
    if (!sb) return;
    int16_t *all = *(int16_t **)sb, *pk = (int16_t *)(sb + 4);
    int32_t e = ov_pos + OV_CHUNK < ov_cap ? ov_pos + OV_CHUNK : ov_cap;
    for (int32_t i = ov_pos; i < e; i++) if (all[i] > pk[i >> 8]) pk[i >> 8] = all[i];
    ov_pos = e;
    if (e < ov_cap) return;
    ov_sb = 0;
    if (ov_kind) DIRTY_D(ov_slot); else DIRTY_S(ov_slot);
}
/* base_freq: patch_load (0x01A010F8) reads the JSON root "base_freq" as a double and calls sampler_set_base_freq
 * (0x01A51A08: read step = 88200 / (freq * 16384), assert freq > 0) on the slot's entry in table 0x01DF6F78 */
#define JV_KEY      ((void *(*)(void *, const char *))0x019BFEB4)      /* Value::operator[](const char *) */
#define JV_ASSIGN   ((void *(*)(void *, const void *))0x019BDDC0)      /* Value::operator= */
#define JV_DOUBLE   ((void (*)(void *, uint32_t, uint32_t))0x019BD854) /* Value(double): low word, high word */
#define JV_DTOR     ((void (*)(void *, int))0x019BDD18)
#define SET_BASE    ((void (*)(void *, uint32_t))0x01A51A08)
static int bf_get(int s, uint32_t b[2])
{
    const uint32_t *v = (const uint32_t *)JV_KEY((uint8_t *)PATCH_S(s) + 4, "base_freq");
    if (((const uint8_t *)v)[8] != 3) return 0;                        /* realValue */
    b[0] = v[0]; b[1] = v[1];
    return 1;
}
static void bf_set(int s, const uint32_t b[2], uint32_t f32)
{
    uint32_t tmp[4];
    JV_DOUBLE(tmp, b[0], b[1]);
    JV_ASSIGN(JV_KEY((uint8_t *)PATCH_S(s) + 4, "base_freq"), tmp);
    JV_DTOR(tmp, 2);
    SET_BASE(((void **)0x01DF6F78)[s], f32);
    SET_KNOBS(PATCH_S(s), synth_words(s));                             /* marks the patch changed */
}
static uint32_t cycles(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
#endif

static volatile uint32_t commit_gen;

int op1_sampler_now(op1_sampler_t *s)
{
    int id = cur_screen(), kind;
    if (id == 6) kind = OP1_SAMPLER_SYNTH; else if (id == 0x10) kind = OP1_SAMPLER_DRUM; else return 0;
    int slot = kind ? drum_slot() : synth_slot();
    if ((kind ? drum_type(slot) : synth_type(slot)) != (kind ? 8 : 6) || !stock_screen(id)) return 0;
    int16_t *d = kind ? drum_data(slot) : synth_data(slot);
    if (!d) return 0;
    s->kind = (uint8_t)kind; s->slot = (uint8_t)slot;
    s->key = (int8_t)(kind ? drum_key() : -1);
    s->busy = (uint8_t)(is_busy() != 0);
    s->data = d;
    s->cap = kind ? CAP_DRUM : CAP_SYNTH;
    s->gen = ((uint32_t)kind << 30 | (uint32_t)slot << 27 | (uint32_t)(s->key & 31) << 22)
             ^ peaks_hash(kind, slot) ^ commit_gen * 2654435761u;
    return 1;
}

/* drum pad entry: value = fraction x 2^31 of the whole buffer */
static int32_t pad_get(const int16_t *p, int end)
{
    int32_t v = ((int32_t)p[end ? 2 : 1] << 16) + ((uint16_t)p[end ? 6 : 5] << 1);
    int32_t s = (int32_t)(((int64_t)v * FULL_DRUM + (1LL << 30)) >> 31);
    return s > CAP_DRUM ? CAP_DRUM : s < 0 ? 0 : s;
}
static void pad_set(int16_t *p, int end, int32_t s)
{
    int64_t v = (((int64_t)s << 31) + FULL_DRUM / 2) / FULL_DRUM;
    if (v > 0x7FFFFFFF) v = 0x7FFFFFFF;
    p[end ? 2 : 1] = (int16_t)(v >> 16); p[end ? 6 : 5] = (int16_t)((v & 0xFFFF) >> 1);
}

int32_t op1_sampler_marker(int marker, int key)
{
    op1_sampler_t s;
    if (!op1_sampler_now(&s) || marker < 0 || marker > 3) return 0;
    if (s.kind == OP1_SAMPLER_DRUM) {
        if (key < 0 || key > 23) key = s.key;
        return pad_get(pad_table(s.slot) + key * 8, marker >= OP1_SM_LOOP_B);
    }
    int32_t w = synth_words(s.slot)[marker];
    return (int32_t)(((int64_t)(w < 0 ? 0 : w) * FULL_SYNTH) >> 15);
}

void op1_sampler_set_marker(int marker, int key, int32_t pos)
{
    op1_sampler_t s;
    if (!op1_sampler_now(&s) || marker < 0 || marker > 3) return;
    if (pos < 0) pos = 0;
    if (pos > s.cap) pos = s.cap;
    if (s.kind == OP1_SAMPLER_DRUM) {
        if (key < 0 || key > 23) key = s.key;
        pad_set(pad_table(s.slot) + key * 8, marker >= OP1_SM_LOOP_B, pos);
        return;
    }
    int32_t w = (int32_t)((((int64_t)pos << 15) + FULL_SYNTH / 2) / FULL_SYNTH);
    synth_words(s.slot)[marker] = (int16_t)(w > 32767 ? 32767 : w);
}

void op1_sampler_commit(int audio)
{
    op1_sampler_t s;
    if (!op1_sampler_now(&s)) return;
    persist(s.kind, s.slot, audio);
    if (audio) commit_gen++;
}

int op1_sampler_base_freq(uint32_t bits[2])
{
    op1_sampler_t s;
    if (!op1_sampler_now(&s) || s.kind != OP1_SAMPLER_SYNTH) return 0;
    return bf_get(s.slot, bits);
}

int op1_sampler_set_base_freq(const uint32_t bits[2], uint32_t f32)
{
    op1_sampler_t s;
    if (!op1_sampler_now(&s) || s.kind != OP1_SAMPLER_SYNTH || !(f32 & 0x7FFFFFFF) || f32 >= 0x7F800000) return -1;
    bf_set(s.slot, bits, f32);
    return 0;
}

/* ---- main loop job ---- */
static int (*volatile job_step)(void *);
static void *volatile job_ctx;
static uint32_t job_total, job_max, job_steps, job_max_at;

int op1_sampler_job(int (*step)(void *ctx), void *ctx)
{
    if (job_step || !step) return -1;
    job_ctx = ctx; job_total = job_max = job_steps = job_max_at = 0;
    job_step = step;                                            /* last: the main loop starts here */
    return 0;
}
int op1_sampler_job_running(void) { return job_step != 0; }

static char *put_u(char *o, uint32_t n)
{
    char d[12]; int k = 0;
    do d[k++] = (char)('0' + n % 10); while (n /= 10);
    while (k) *o++ = d[--k];
    return o;
}
void kn_sampler_service(void)                                   /* main loop (kn_core.c) */
{
    overview_service();
    int (*step)(void *) = job_step;
    if (!step) return;
    uint32_t t0 = cycles();
    int more = step(job_ctx);
    uint32_t dt = cycles() - t0;
    job_total += dt;
    if (dt > job_max) { job_max = dt; job_max_at = job_steps; }
    job_steps++;
    if (more) return;
    char m[64], *o = m;
    const char *a = "job ", *b = " cycles, max ", *c = " at ", *d = "/";
    while (*a) *o++ = *a++;
    o = put_u(o, job_total);
    while (*b) *o++ = *b++;
    o = put_u(o, job_max);
    while (*c) *o++ = *c++;
    o = put_u(o, job_max_at);
    while (*d) *o++ = *d++;
    o = put_u(o, job_steps);
    *o = 0;
    kn_log_line("sampler", m);
    job_step = 0;
}
