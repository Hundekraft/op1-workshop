/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#ifndef KN_SEQ_ROWS_H
#define KN_SEQ_ROWS_H
/* Only explicitly owned loadable rows are removable; foreign rows stay untouched.
 * Keep SQL callback helpers out of the large loader translation-unit body: the
 * Observed Blackfin GCC 13.3 inlined output dropped this cleanup tail as
 * unreachable. This boundary avoids that optimizer anomaly; its cause is open. */
static char *kn_sr_cat(char *d,const char *s){while(*s)*d++=*s++;*d=0;return d;}
static int kn_sr_name(const char *s){unsigned n=0;if(!s)return 0;for(;s[n];n++)if(n>=15||!((s[n]>='a'&&s[n]<='z')||(s[n]>='0'&&s[n]<='9')||s[n]=='_'||s[n]=='-'))return 0;return n>0;}
static __attribute__((noinline)) void kn_seq_row_ensure(void *db,const char *name,void (*exec)(void *,const char *)){
 if(!kn_sr_name(name))return;
 char sql[256],*o;
 exec(db,"CREATE TABLE IF NOT EXISTS kennel_seq_owned (type TEXT PRIMARY KEY)");
 o=kn_sr_cat(sql,"INSERT OR IGNORE INTO kennel_seq_owned SELECT '");o=kn_sr_cat(kn_sr_cat(o,name),"' WHERE NOT EXISTS (SELECT 1 FROM seq_types WHERE type='");kn_sr_cat(kn_sr_cat(o,name),"')");exec(db,sql);
 o=kn_sr_cat(sql,"INSERT INTO seq_types SELECT (SELECT COALESCE(MAX(id),0)+1 FROM seq_types),'");o=kn_sr_cat(kn_sr_cat(o,name),"' WHERE NOT EXISTS (SELECT 1 FROM seq_types WHERE type='");kn_sr_cat(kn_sr_cat(o,name),"')");exec(db,sql);
}
static __attribute__((noinline)) void kn_seq_rows_cleanup(void *db,const char *const *names,unsigned count,void (*exec)(void *,const char *)){
 char sql[1100],*o;exec(db,"CREATE TABLE IF NOT EXISTS kennel_seq_owned (type TEXT PRIMARY KEY)");
 o=kn_sr_cat(sql,"DELETE FROM seq_types WHERE type IN (SELECT type FROM kennel_seq_owned) AND type NOT IN ('");
 for(unsigned i=0;i<count&&i<48;i++)if(kn_sr_name(names[i]))o=kn_sr_cat(kn_sr_cat(o,names[i]),"','");
 kn_sr_cat(o,"')");exec(db,sql);
 /* Remove ownership only after its corresponding row is gone. */
 exec(db,"DELETE FROM kennel_seq_owned WHERE type NOT IN (SELECT type FROM seq_types)");
}
#endif
