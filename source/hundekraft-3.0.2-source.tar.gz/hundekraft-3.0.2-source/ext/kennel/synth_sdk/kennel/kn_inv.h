/*
 * Inventory: what this boot found and decided, for the workshop over SysEx (devupd LIST, docs/inventory.md).
 * One record per plugin file, built-in engine / effect and built-in feature, recorded by the loader (kn_boot.c) and
 * the feature registry (kn_features.c) at boot and never changed afterwards. LIST reads it as text.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_INV_H
#define KN_INV_H
#include <stdint.h>
#include "../op1_feature.h"

enum { KN_INV_LOADED = 0, KN_INV_FAILED = 1, KN_INV_SKIPPED = 2, KN_INV_OFF = 3 };
enum { KN_INV_BUILTIN = 0, KN_INV_KNL = 1, KN_INV_OP1P = 2 };
#define KN_INV_REPLACES 1u                 /* a file that took a built-in's place (same name) */

typedef struct kn_inv_rec {
    struct kn_inv_rec *next;
    uint8_t kind, source, state, flags;    /* kind: KN_KIND_* (kn_load.h), 0 unknown (the file did not parse) */
    uint32_t size, crc;                    /* file size; the CRC the file carries (.knl header, .op1p trailer) */
    char name[16];                         /* type / feature name ("" if the file did not parse) */
    const char *path;                      /* "plugins/x.knl", "content/x.knl"; 0 for built-ins */
    const char *author, *version;          /* .knl extension table, or 0 */
    const char *claims;                    /* .knl extension table: NUL-separated, empty string ends it; or 0 */
    const char *reason;                    /* why failed / off (static text), or 0 */
    const op1_feature_t *f;                /* features: the registered object (its claims), or 0 */
    const char *lost_claim, *lost_to;      /* the claims resolver switched it off: which claim, who has it */
} kn_inv_rec;

extern kn_inv_rec *kn_inv_cur;             /* the file record being loaded (kn_boot.c), 0 between files */

kn_inv_rec *kn_inv_add(int source, const char *path);      /* new record (arena), appended; 0 if the arena is full */
const char *kn_inv_str(const char *s, int max);            /* copy into the arena (max bytes with the NUL), or 0 */
const char *kn_inv_list(const char *list, int max);        /* copy a NUL-separated list ending in an empty string */
/* the feature registry's decision (kn_feature_register): r 0 registered, -1 refused, -2 switched off, -3 a file
 * replaces this built-in, -4 shadowed by an earlier file provider */
void kn_inv_feature_result(const op1_feature_t *f, int r, int builtin);
void kn_inv_lost(const op1_feature_t *loser, const char *claim, const char *winner);   /* resolve_claims */
/* inventory text from byte off: up to cap bytes into out, *total = text length; bytes copied, -1 off past the end */
int kn_inv_read(uint32_t off, uint8_t *out, int cap, uint32_t *total);

#endif
