/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#ifndef KN_SEQ_ASSET_H
#define KN_SEQ_ASSET_H
#include "../op1_feature_seq.h"
/* File arena owns the descriptors and path; never write through const relocated
 * plugin structures. Caller rolls the arena back if allocation/register fails. */
static const op1_feature_t *kn_seq_asset(const op1_feature_t *feature,const char *path,void *(*allocate)(uint32_t)){
 if(!feature->seq||!path)return feature;
 unsigned n=0;while(path[n]&&n<48)n++;if(n>=48)return 0;
 op1_feature_t *f=allocate(sizeof *f);op1_seq_type_t *s=allocate(sizeof *s);char *p=allocate(n+1);
 if(!f||!s||!p)return 0;
 const uint8_t *src=(const uint8_t *)feature;uint8_t *dst=(uint8_t *)f;
 for(unsigned i=0;i<sizeof *f;i++)dst[i]=src[i];
 src=(const uint8_t *)feature->seq;dst=(uint8_t *)s;
 for(unsigned i=0;i<sizeof *s;i++)dst[i]=src[i];
 for(unsigned i=0;i<=n;i++)p[i]=path[i];
 s->svg=p;f->seq=s;return f;
}
#endif
