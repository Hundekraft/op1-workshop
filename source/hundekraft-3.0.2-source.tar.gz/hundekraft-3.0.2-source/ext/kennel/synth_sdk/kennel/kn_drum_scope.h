/*
 * Drum load scope (kennel/kn_drum.c): which drum patch R246's load_drum_patch is parsing. Pure functions, no firmware
 * calls, so the host test (harness/kn_drum_test.c) runs the same code.
 * load_drum_patch's parser call (0x01A04BC0) parses the 8 slot patches (0x01DDD9A8 + slot * 0x38, JSON at +4) and
 * the kit table (0x01DE20FC, factory and user kits, same stride): every parse through it is a drum patch (`depth`);
 * only the slot objects have a slot (`slot`, for the drum type's load). Nested calls restore the outer scope, also
 * after an error return (the parser's result is passed on unchanged).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_DRUM_SCOPE_H
#define KN_DRUM_SCOPE_H
#include <stdint.h>

typedef struct {
    int depth;                  /* > 0: inside a parse through the drum load site */
    int slot;                   /* drum slot of the patch being parsed, -1 = not a slot object (kit table) */
    const void *json;           /* the patch JSON being parsed */
} kn_drum_scope;

/* slot of a patch JSON address: slots of `stride` bytes from `first` (the first slot's JSON), else -1 */
static inline int kn_drum_slot_of(uint32_t json, uint32_t first, uint32_t stride, unsigned slots)
{
    if (!stride || json < first) return -1;
    uint32_t off = json - first;
    return off % stride == 0 && off / stride < slots ? (int)(off / stride) : -1;
}

static inline int kn_drum_parse_scoped(kn_drum_scope *sc, void *json, int slot, int mode, int (*parse)(void *, int))
{
    kn_drum_scope outer = *sc;
    sc->depth = outer.depth + 1; sc->slot = slot; sc->json = json;
    int r = parse(json, mode);
    *sc = outer;
    return r;
}

/* the slot whose patch is assigned now (the parser's keep step), or -1: only the patch this scope is parsing, so a
 * nested parse of some other patch never reaches the drum type */
static inline int kn_drum_keep_slot(const kn_drum_scope *sc, const void *patch)
{
    return sc->depth > 0 && patch == sc->json ? sc->slot : -1;
}
#endif
