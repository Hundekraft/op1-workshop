/*
 * Flash check (op1_feature.h op1_flash_*): a read-only scan of every block of the YAFFS partition, opened from FILE
 * (blue push), drawn as Maiko Pruett's #250 shows its check (behaviour from its guide page; our own code and drawing):
 * four counts over a map with one dot per block, healthy blue, fixed white, errors red, dead pink, not read yet navy.
 *
 * R246 / YAFFS2 Direct: the device as kn_storage.c finds it (0x01A98E52("/yaffs2"), mounted at +0xC0,
 * [[+0xD7C] + 8]); chunks per block +0x0C, blocks +0xCC..+0xD0 (132..4095: 3964), block info +0x114 (8 bytes per
 * block, state = bits 20..23 of word 0, 9 = dead). Pages are read through the driver's read hook (device +0x5C,
 * yaffs_nand_read_chunk_tags; args device, chunk, data, tags), not yaffs_rd_chunk_tags_nand (0x01A95A14), which flags
 * a block on an ECC event (FUN_01A8FC28) and so could retire it: the check marks nothing. ECC result: tags +0x10
 * (1 clean, 2 corrected, 3 uncorrectable). Reads hold yaffs_lock (0x01A98B3C / 0x01A98B78).
 * A block: dead if YAFFS retired it (not read); errors if a page could not be corrected; fixed if one was corrected;
 * else healthy. The scan runs on the main loop (kn_core_service), 16 pages a pass, while the check is shown, the tape
 * is stopped and disk mode is off; otherwise it waits (PAUSED).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "../screens/stroke_font.h"

#define PER_PASS   16                                   /* pages read per main loop pass */
#define MAP_COLS   124
#define MAP_X      36
#define MAP_Y      46
enum { B_UNREAD, B_HEALTHY, B_FIXED, B_ERRORS, B_DEAD };

#ifdef OP1_HOST                                         /* harness/flash_test.c, golden_frames.c */
extern uint8_t *host_flash_dev;
extern volatile int32_t host_flash_tape_run;
extern volatile uint8_t host_flash_disk, host_flash_com;
void host_yaffs_lock(void), host_yaffs_unlock(void);
#define DEV()        host_flash_dev
#define TAPE_RUN     host_flash_tape_run
#define DISK_ACTIVE  host_flash_disk
#define COM_UP       host_flash_com
#define Y_LOCK       host_yaffs_lock
#define Y_UNLOCK     host_yaffs_unlock
#else
static uint8_t *dev_find(void)
{
    uint8_t rest[8];
    uint8_t *m = ((uint8_t *(*)(const char *, void *))0x01A98E52)("/yaffs2", rest);
    if (!m || !*(uint32_t *)(m + 0xC0)) return 0;
    uint8_t *ctx = *(uint8_t **)(m + 0xD7C);
    return ctx ? *(uint8_t **)(ctx + 8) : 0;
}
#define DEV()        dev_find()
#define TAPE_RUN     (*(volatile int32_t *)0xFF802960)  /* 0 stopped, 1 recording, 2 playing, 3 shuttle */
#define DISK_ACTIVE  (*(volatile uint8_t *)0xFF906EF9)  /* disk_mode_active */
int kn_pages_com_up(void);
#define COM_UP       kn_pages_com_up()                  /* the COM view on screen (left COM: not shown) */
#define Y_LOCK       ((void (*)(void))0x01A98B3C)
#define Y_UNLOCK     ((void (*)(void))0x01A98B78)
#endif
typedef int (*read_hook)(void *dev, int chunk, uint8_t *data, uint8_t *tags);

static struct {
    uint8_t *state;                                     /* per block B_*, from the arena */
    uint8_t *page;                                      /* 2 KiB + 64 tag bytes, from the arena */
    int32_t first, n, per;                              /* first block, blocks, pages per block */
    int32_t block, pg, worst;                           /* the scan: block, page in it, its worst ECC result */
    int32_t count[5];
    uint8_t running, done, shown;
} fl;

int op1_flash_shown(void) { return fl.shown; }
int op1_flash_counts(int32_t out[4])                    /* healthy, fixed, errors, dead; 0 idle, 1 scanning, 2 done */
{
    for (int i = 0; i < 4; i++) out[i] = fl.count[i + 1];
    return fl.done ? 2 : fl.running ? 1 : 0;
}
void op1_flash_close(void) { fl.shown = 0; }

static int setup(void)
{
    uint8_t *dev = DEV();
    if (!dev) return 0;
    int32_t first = *(int32_t *)(dev + 0xCC), last = *(int32_t *)(dev + 0xD0), per = *(int32_t *)(dev + 0x0C);
    if (last < first || last - first >= 4096 || per <= 0 || per > 256) return 0;
    if (!fl.state && !(fl.state = op1_alloc(4096))) return 0;
    if (!fl.page && !(fl.page = op1_alloc(2048 + 64))) return 0;
    fl.first = first; fl.n = last - first + 1; fl.per = per;
    return 1;
}

void op1_flash_open(void)                               /* show it; start a scan unless one is running */
{
    fl.shown = 1;
    if (fl.running || !setup()) return;
    for (int i = 0; i < fl.n; i++) fl.state[i] = B_UNREAD;
    for (int i = 0; i < 5; i++) fl.count[i] = 0;
    fl.block = 0; fl.pg = 0; fl.worst = 0; fl.done = 0; fl.running = 1;
}

int op1_flash_push(int knob)                            /* while shown: blue checks (again), others leave */
{
    if (!fl.shown) return 0;
    if (knob == 0) { if (!fl.running) op1_flash_open(); return 0; }
    if (knob > 0) { fl.shown = 0; return 1; }
    return 0;
}

static int paused(void) { return !fl.shown || !COM_UP || TAPE_RUN != 0 || DISK_ACTIVE; }

static void finish_block(int st)
{
    fl.state[fl.block] = (uint8_t)st;
    fl.count[st]++;
    fl.block++; fl.pg = 0; fl.worst = 0;
    if (fl.block >= fl.n) { fl.running = 0; fl.done = 1; }
}

/* main loop (kn_core_service) */
void kn_flash_service(void)
{
    if (!fl.running || paused()) return;
    uint8_t *dev = DEV();
    if (!dev) return;
    const uint32_t *bi = *(const uint32_t **)(dev + 0x114);
    read_hook rd = *(read_hook *)(dev + 0x5C);
    if (!bi || !rd) { fl.running = 0; return; }
    Y_LOCK();
    for (int k = 0; k < PER_PASS && fl.running; k++) {
        if (fl.pg == 0 && ((bi[2 * fl.block] >> 20) & 0xF) == 9) { finish_block(B_DEAD); continue; }   /* retired */
        uint8_t *tags = fl.page + 2048;
        for (int i = 0; i < 64; i++) tags[i] = 0;
        rd(dev, (fl.first + fl.block) * fl.per + fl.pg, fl.page, tags);
        uint32_t ecc = *(uint32_t *)(tags + 0x10);
        if ((int32_t)ecc > fl.worst) fl.worst = (int32_t)ecc;
        if (++fl.pg >= fl.per) finish_block(fl.worst >= 3 ? B_ERRORS : fl.worst == 2 ? B_FIXED : B_HEALTHY);
    }
    Y_UNLOCK();
}

/* ---- the screen (Gfx thread) ---- */
#define STROKE 0x600
static const uint8_t c_text[4] = { 0xdf, 0xd9, 0xff, 255 },
    c_state[5][4] = { { 0x1b, 0x21, 0x40, 255 }, { 0x69, 0x8e, 0xff, 255 }, { 0xff, 0xff, 0xff, 255 },
                      { 0xff, 0x3a, 0x5d, 255 }, { 0xff, 0x90, 0xa7, 255 } };
static char *num(char *o, int32_t v) { char d[10]; int k = 0; do d[k++] = (char)('0' + v % 10); while (v /= 10); while (k) *o++ = d[--k]; return o; }
static void line(void *r, int x0, int y0, int x1, int y1, int32_t w, const uint8_t *c) { sf_line(r, x0 << 10, y0 << 10, x1 << 10, y1 << 10, w, c); }

void op1_flash_draw(void *r)
{
    static const char *const label[4] = { "HEALTHY", "FIXED", "ERRORS", "DEAD" };
    static const int col_x[5] = { 6, 80, 130, 190, 247 };
    for (int i = 0; i < 4; i++) {                       /* a dot in the state's colour, the label, the count */
        line(r, col_x[i], 15, col_x[i] + 1, 15, 3 << 10, c_state[i + 1]);
        sf_text(r, (col_x[i] + 7) << 10, 11 << 10, 1331, label[i], STROKE, c_text);
        char v[12]; *num(v, fl.count[i + 1]) = 0;
        sf_text(r, (col_x[i] + 7) << 10, 26 << 10, 1331, v, STROKE, c_state[i + 1]);
    }
    sf_text(r, col_x[4] << 10, 11 << 10, 1331, "SCAN", STROKE, c_text);
    char s[12], *o = s;
    if (fl.done) { const char *t = "DONE"; while (*t) *o++ = *t++; }
    else if (fl.running && paused() == 0) { o = num(o, fl.n ? fl.block * 100 / fl.n : 0); *o++ = '%'; }
    else if (fl.running) { const char *t = "PAUSED"; while (*t) *o++ = *t++; }
    else { *o++ = '0'; *o++ = '%'; }
    *o = 0;
    sf_text(r, col_x[4] << 10, 26 << 10, 1331, s, STROKE, c_text);
    /* the map: 2 x 2 px per block, rows of MAP_COLS; runs of one state drawn as one line */
    int n = fl.state ? fl.n : 3964;
    for (int row = 0; row * MAP_COLS < n; row++) {
        int y = MAP_Y + row * 2 + 1, c = 0;
        while (c < MAP_COLS && row * MAP_COLS + c < n) {
            int i = row * MAP_COLS + c, st = fl.state ? fl.state[i] : B_UNREAD, e = c;
            while (e + 1 < MAP_COLS && row * MAP_COLS + e + 1 < n && (fl.state ? fl.state[i + e + 1 - c] : B_UNREAD) == st) e++;
            line(r, MAP_X + c * 2, y, MAP_X + e * 2 + 2, y, 3 << 10, c_state[st]);   /* 3 px: rows overlap, no gaps */
            c = e + 1;
        }
    }
}
