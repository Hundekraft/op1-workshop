/*
 * MIDI and synth services for features (op1_feature_midi.h, docs/feature-hooks.md "MIDI and synth services"):
 *   CCs taken        dispatcher.c midi_cc_hook skips its CC -> key / encoder mapping for them
 *   raw MIDI in      devupd/du_fw.c du_rx_poll hands every USB-MIDI packet of the RX ring to kn_midi_raw_packet
 *                    (before the stock parser; the RX hook at 0x019E3CC8 is the dev-update hook, which OP1-Emulator's
 *                    builder always installs, make_firmware only with --dev)
 *   note source      VoiceCtl key_down / key_up entry stubs (hook.S) pass their caller to kn_note_source_set
 *   parameters       op1_param_set queues; private key code KN_PARAM_KEY in the KeyHandler queue applies them
 *                    (dispatcher.c key_event_hook -> kn_param_apply), as the synth controller's on_knob does
 *   stock seq keys   op1_stock_seq_key pushes key events into the KeyHandler queue
 *   SEQ + TAPE view  kn_tapeview_key / _push / _knob (dispatcher.c), screen object in the tape screen's slot
 *   switches         op1_switch rows, drawn and turned by the settings page (screens/settings.c)
 * The parameter, key-queue and view parts follow op1r-src 5c90efb (op1r 35, midi/mx.c and seqdev/ms_fw.c, GPL,
 * pcppcp), PROVENANCE.md.
 * Copyright (C) 2026 Hundekraft, pcppcp. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_synth.h"
#include "../op1_feature_midi.h"

int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);

#ifdef OP1_HOST
/* host: R246 state and calls as plain data (kennel harness/midi_core_test.c) */
extern int host_kq[256], host_kq_n;                     /* KeyHandler queue: code | down << 8 */
extern int host_mode, host_screen, host_synth_slot, host_midi_ch;
extern uint8_t host_shift;
extern int16_t host_eng_word[8][4], host_env_word[8][4], host_fx_word[8][4], host_lfo_word[8][4];
extern int16_t host_eng_range[32][4][4], host_env_range[4][3], host_fx_range[16][4][3], host_lfo_range[16][4][3];
extern int host_engine[8], host_fx_type[8], host_lfo_type[8], host_fx_on[8], host_lfo_on[8], host_patch_set[4];
extern void *host_screen_table[0x44];
extern void host_key_dispatch(int code, int pressed);
static uint32_t irq_off(void) { return 0; }
static void irq_on(uint32_t m) { (void)m; }
static int kq_push(int code, int down) { host_kq[host_kq_n++ & 255] = code | down << 8; return 1; }
#define CUR_MODE        host_mode
#define CUR_SCREEN      host_screen
#define SHIFT_HELD      host_shift
#define MIDI_CH         host_midi_ch
#define SLOT            (host_synth_slot & 7)
#define ENG_WORDS(s)    host_eng_word[s]
#define ENV_WORDS(s)    host_env_word[s]
#define FX_WORDS(s)     host_fx_word[s]
#define LFO_WORDS(s)    host_lfo_word[s]
#define ENG_RANGE(e, k) host_eng_range[e][k]
#define ENV_RANGE(k)    host_env_range[k]
#define FX_RANGE(t, k)  host_fx_range[t][k]
#define LFO_RANGE(t, k) host_lfo_range[t][k]
#define ENGINE(s)       host_engine[s]
#define FX_TYPE(s)      host_fx_type[s]
#define LFO_TYPE(s)     host_lfo_type[s]
#define FX_ON(s)        host_fx_on[s]
#define LFO_ON(s)       host_lfo_on[s]
#define SET(g, s, w)    (host_patch_set[g]++)
#define SCREEN_TABLE    host_screen_table
#define KEY_DISPATCH    host_key_dispatch
#else
static uint32_t irq_off(void) { uint32_t m; __asm__ volatile ("cli %0;" : "=d"(m)); return m; }
static void irq_on(uint32_t m) { __asm__ volatile ("sti %0;" : : "d"(m)); }
/* KeyHandler queue (s_key_queue, 256 x u16 code | pressed << 8; read 0x01DD5244, write 0x01DD5248, 0x01DD524D set
 * while it is being reset); 0x019C2F04 posts the KeyHandler semaphore, as the key-scan ISR does */
static int kq_push(int code, int down)
{
    volatile uint32_t *rd = (volatile uint32_t *)0x01DD5244, *wr = (volatile uint32_t *)0x01DD5248;
    uint32_t m = irq_off(), w = *wr, n = (w + 1) & 0xFF;
    int ok = n != *rd && !*(volatile uint8_t *)0x01DD524D;
    if (ok) { ((volatile uint16_t *)0x01DD5044)[w] = (uint16_t)(code | down << 8); *wr = n; }
    irq_on(m);
    if (ok) ((void (*)(void))0x019C2F04)();
    return ok;
}
#define CUR_MODE        (*(volatile int *)0xFF907D58)
#define CUR_SCREEN      (*(volatile int *)0x018B65C8)
#define SHIFT_HELD      (*(volatile uint8_t *)0x01DD7F78)
#define MIDI_CH         (*(volatile int *)0x01AADB20 & 15)      /* the OP-1's MIDI channel */
#define SLOT            (*(volatile int *)0xFF8016D4 & 7)
#define ENG_WORDS(s)    ((int16_t *)(0xFF8013C4 + (s) * 16))
#define ENV_WORDS(s)    ((int16_t *)(0x01B60EF0 + (s) * 16))
#define FX_WORDS(s)     ((int16_t *)(0xFF801444 + (s) * 16))
#define LFO_WORDS(s)    ((int16_t *)(0xFF8014C4 + (s) * 16))
#define ENG_RANGE(e, k) ((const int16_t *)(0x01DE5890 + (e) * 0x40 + (k) * 8))   /* {min, max, scale, mode} */
#define ENV_RANGE(k)    ((const int16_t *)(0x01DE5710 + (k) * 6))                /* {min, max, scale} */
#define FX_RANGE(t, k)  ((const int16_t *)(0x01DE5C50 + (t) * 0x30 + (k) * 6))
#define LFO_RANGE(t, k) ((const int16_t *)(0x01DE5740 + (t) * 0x30 + (k) * 6))
#define ENGINE(s)       (((volatile int *)0xFF8016E4)[s])
#define FX_TYPE(s)      (((volatile int *)0xFF801734)[s])
#define LFO_TYPE(s)     (((volatile int *)0xFF801384)[s])
#define FX_ON(s)        (((int (*)(int))0x0196727C)(s))
#define LFO_ON(s)       (((int (*)(int))0x0196726C)(s))
#define PATCH(s)        ((void *)(0x01DDD7E8 + (s) * 0x38))
static void (*const setters[4])(void *, int16_t *) = {
    (void (*)(void *, int16_t *))0x01A00D14,               /* patch::set_knobs */
    (void (*)(void *, int16_t *))0x01A00C98,               /* envelope */
    (void (*)(void *, int16_t *))0x019FF664,               /* set_fx */
    (void (*)(void *, int16_t *))0x019FF734 };             /* set_lfo_params */
#define SET(g, s, w)    setters[g](PATCH(s), (w))
#define SCREEN_TABLE    ((void **)0x01DF4E54)
#define KEY_DISPATCH    ((void (*)(int, int))0x019B6C74)
#define SCREEN_CTOR     ((void *(*)(void *, int, const char *))0x01A3BAB0)
#define ITER_SCREEN_VT  ((const uint32_t *)0x019103FC)
#define SVG_LOAD        ((void *(*)(void *))0x01A503D8)
#endif

/* ---- raw MIDI in ---- */
static const op1_feature_t *raw_features(int i) { return i < kn_feature_count() ? kn_feature_at(i) : 0; }
void kn_midi_raw(const uint8_t *msg, int len)
{
    const op1_feature_t *f;
    for (int i = 0; (f = raw_features(i)); i++) if (f->midi_raw) f->midi_raw(msg, len);
}
/* one USB-MIDI packet (cable / CIN, then 3 bytes): channel messages and real time, not SysEx */
void kn_midi_raw_packet(const volatile uint8_t *pk)
{
    int cin = pk[0] & 15, len;
    switch (cin) {
    case 0x8: case 0x9: case 0xA: case 0xB: case 0xE: len = 3; break;
    case 0xC: case 0xD: len = 2; break;
    case 0xF: len = pk[1] >= 0xF8 ? 1 : 0; break;             /* single byte: real time only */
    default: len = 0;
    }
    if (!len || !(pk[1] & 0x80)) return;
    uint8_t m[3] = { pk[1], (uint8_t)(pk[2] & 127), (uint8_t)(pk[3] & 127) };
    kn_midi_raw(m, len);
}

static volatile uint32_t cc_taken[4];
void op1_midi_take_cc(int cc, int take)
{
    if (cc < 0 || cc > 127) return;
    uint32_t m = irq_off();
    if (take) cc_taken[cc >> 5] |= 1u << (cc & 31); else cc_taken[cc >> 5] &= ~(1u << (cc & 31));
    irq_on(m);
}
int kn_cc_taken(int cc) { return cc >= 0 && cc < 128 && (cc_taken[cc >> 5] >> (cc & 31) & 1); }

/* ---- note source ---- */
static volatile int note_src;
volatile int kn_src_force;                                 /* op1_seq_note_on: the next note is a player's */
int kn_note_source_of(uint32_t ret)                        /* VoiceCtl key_down / key_up's caller -> OP1_SRC_* */
{
    if ((ret >= 0x019AC0B0 && ret < 0x019AC2F2) || (ret >= 0x019AC2F8 && ret < 0x019AC3C6)) return OP1_SRC_KEYS;
    if (ret >= 0x01A858D8 && ret < 0x01A85C16) return OP1_SRC_MIDI | MIDI_CH << 8;   /* VoiceCtl note on / off (MIDI) */
    if (ret >= 0x01E00000 && ret < 0xFF000000) return OP1_SRC_FEATURE;               /* kennel code and plugin files */
    return OP1_SRC_PLAYER;
}
void kn_note_source_set(uint32_t ret)
{
    int f = kn_src_force;
    int source=kn_note_source_of(ret);
    /* An interrupted native replay must not relabel stock USB MIDI/keyboard
     * or stock-player input. Only native callers request an explicit source. */
    note_src = f && source==OP1_SRC_FEATURE ? f : source;
}
int op1_note_source(void) { return note_src; }

/* ---- synth parameters (op1r 35 midi/mx.c) ---- */
#define KN_PARAM_KEY 0x3F                                  /* private key code: apply pending parameters */
static volatile uint8_t pval[16];
static volatile uint16_t pend;
static volatile uint8_t queued;
static int scale(const int16_t *rg, int v)                 /* 0..127 over [min, max] */
{
    int lo = rg[0], hi = rg[1];
    return hi <= lo ? lo : lo + (hi - lo) * (v & 127) / 127;
}
int op1_param_set(int group, int knob, int value)
{
    if (group < 0 || group > 3 || knob < 0 || knob > 3) return -1;
    int i = group * 4 + knob;
    uint32_t m = irq_off();
    pval[i] = (uint8_t)(value < 0 ? 0 : value > 127 ? 127 : value);
    pend |= (uint16_t)(1u << i);
    int push = !queued;
    if (push) queued = 1;                                  /* one pending KN_PARAM_KEY at a time */
    irq_on(m);
    if (push && !kq_push(KN_PARAM_KEY, 1)) queued = 0;      /* queue full: the next call tries again */
    return 0;
}
static int apply(int i, int v)                             /* KeyHandler thread; -1 = skipped */
{
    int s = SLOT, k = i & 3, g = i >> 2;
    int16_t *w; const int16_t *rg;
    switch (g) {
    case OP1_PARAM_ENGINE: {
        int e = ENGINE(s);
        if (e < 0 || e > 31) return -1;
        rg = ENG_RANGE(e, k);
        if (rg[3] != 0 && rg[3] != 1) return -1;           /* linked sample ranges: stock-only */
        w = ENG_WORDS(s);
        break;
    }
    case OP1_PARAM_ENV: rg = ENV_RANGE(k); w = ENV_WORDS(s); break;
    case OP1_PARAM_FX: {
        int t = FX_TYPE(s);
        if (!FX_ON(s) || t < 0 || t > 15) return -1;
        rg = FX_RANGE(t, k); w = FX_WORDS(s);
        break;
    }
    default: {
        int t = LFO_TYPE(s);
        if (!LFO_ON(s) || t < 0 || t > 15 || t == 4 || (t == 5 && k == 3) || (t == 6 && k == 0)) return -1;
        rg = LFO_RANGE(t, k); w = LFO_WORDS(s);
    }
    }
    if (rg[1] <= rg[0]) return -1;                         /* range table not filled */
    w[k] = (int16_t)scale(rg, v);
    SET(g, s, w);
    return 0;
}
void kn_param_apply(void)                                  /* key_event_hook: KN_PARAM_KEY */
{
    uint32_t m = irq_off();
    uint16_t p = pend; pend = 0; queued = 0;
    uint8_t v[16];
    for (int i = 0; i < 16; i++) v[i] = pval[i];
    irq_on(m);
    for (int i = 0; i < 16; i++) if (p >> i & 1) apply(i, v[i]);
}

/* ---- notes into the stock sequencer: key i of the keyboard plays 53 + i at octave 0 (op1r 35 ms_fw.c) ---- */
static const uint8_t kb_keys[24] = { 39, 13, 40, 14, 41, 15, 42, 28, 32, 29, 22, 30, 31, 23, 48, 24, 49, 25, 50, 51, 26, 52, 27, 53 };
static volatile uint8_t kb_down[24];
void op1_stock_seq_key(int note, int down)
{
    int i = note - 53;
    while (i < 0) i += 12;
    while (i > 23) i -= 12;
    down = down != 0;
    uint32_t m = irq_off();
    int change = !down != !kb_down[i];                     /* never a second down of a held key (stock asserts) */
    if (change) kb_down[i] = (uint8_t)down;
    irq_on(m);
    if (change && !kq_push(kb_keys[i], down)) kb_down[i] = (uint8_t)!down;
}

/* ---- SEQ + TAPE view ---- */
static const op1_page_t *tv_page;                          /* the first feature with a tape_view (after boot) */
static volatile uint8_t tv_open, tv_req, seq_down, seq_chord, tv_swallow[0x40], tv_off;
static int tv_id = -1;
static void *tv_tape_obj;
static uint32_t *tv_scr, *tv_vt;                           /* screen object and vtable, in the arena on first use */
void *kn_alloc(uint32_t size);
static const op1_page_t *view_page(void)
{
    if (!tv_page)
        for (int i = 0; i < kn_feature_count(); i++)
            if (kn_feature_at(i)->tape_view && kn_feature_at(i)->tape_view->screen) { tv_page = kn_feature_at(i)->tape_view; break; }
    return tv_page;
}
/* Construct with the other screens at boot, before Gfx starts. Lazy construction
 * on first SEQ+TAPE also exposed a partially constructed screen-table entry. */
void kn_tapeview_ctor(void)
{
#ifndef OP1_HOST
    if(!view_page())return;
    const int id=21; /* R246 tape screen; current Gfx id can still be settings. */
    tv_scr=kn_alloc(32*4);tv_vt=kn_alloc(10*4);
    if(!tv_scr || !tv_vt)return;
    void *saved=SCREEN_TABLE[id];
    SCREEN_CTOR(tv_scr,id,tv_page->svg);SCREEN_TABLE[id]=saved;
    for(int i=0;i<10;i++)tv_vt[i]=ITER_SCREEN_VT[i];
    tv_vt[7]=(uint32_t)tv_page->screen->update;
    tv_vt[9]=(uint32_t)tv_page->screen->init;
    tv_scr[3]=(uint32_t)tv_vt;
#endif
}
void kn_tapeview_load(void)
{
#ifndef OP1_HOST
    if(!tv_scr || !tv_scr[2] || !SCREEN_TABLE[21])return;
    tv_scr[0]=(uint32_t)SVG_LOAD((void*)tv_scr[2]);
    if(!tv_scr[0])return;
    tv_page->screen->init(tv_scr);tv_tape_obj=SCREEN_TABLE[21];tv_id=21;
#endif
}
static void view_set(int on)
{
#ifndef OP1_HOST
    if(tv_id<0)return;
    SCREEN_TABLE[tv_id]=on?(void*)tv_scr:tv_tape_obj;
#endif
    tv_open=(uint8_t)on;
}
int op1_tape_view_open(void) { return tv_open; }
void op1_tape_view_close(void) { if (tv_open) view_set(0); }
void op1_tape_view_enable(int on) { tv_off = !on; if (!on) { tv_req = 0; op1_tape_view_close(); } }
/* key_event_hook, before the features' input filter: 1 = consumed. Only with a tape_view feature registered. */
int kn_tapeview_key(int code, int pressed)
{
    if (code < 0 || code >= 0x40 || !view_page()) return 0;
    if (!pressed && tv_swallow[code]) { tv_swallow[code] = 0; return 1; }
    if (tv_off) {                                          /* switched off: stock, but a held SEQ still comes out */
        if (code == 0x15 && !pressed && seq_down) { seq_down = 0; if (!seq_chord) { KEY_DISPATCH(0x15, 1); KEY_DISPATCH(0x15, 0); } return 1; }
        return 0;
    }
    if (code == 0x15) {                                    /* SEQ: held for the SEQ + TAPE chord */
        if (pressed) { seq_down = 1; seq_chord = 0; return 1; }
        seq_down = 0;
        if (!seq_chord) { KEY_DISPATCH(0x15, 1); KEY_DISPATCH(0x15, 0); }   /* plain SEQ: stock, late */
        return 1;
    }
    if (code == 0x04 && pressed) {                         /* TAPE: with SEQ held opens the view, alone closes it */
        if (seq_down && CUR_MODE == 2) { seq_chord = 1; if (!tv_open) view_set(1); tv_swallow[code] = 1; return 1; }
        if (seq_down) { seq_chord = 1; tv_req = 1; return 0; }   /* not in tape mode yet: stock switches, then open */
        tv_req=0;
        if (tv_open) view_set(0);
        return 0;
    }
    return 0;
}
/* After feature input: let REC+metronome be consumed while the view is still open. Only an unconsumed mode
 * key closes it; SEQ/TAPE chord handling above remains reserved ahead of feature input. */
void kn_tapeview_after_input(int code, int pressed)
{
    if (pressed && (code==0x02 || code==0x03 || code==0x05 || code==0x00 || code==0x01 || code==0x2C)) {
        tv_req=0;
        if(tv_open)view_set(0);
    }
}
/* key_event_hook, after the tape features (red press = tape marker in the view too): encoder pushes to the view */
int kn_tapeview_push(int code, int pressed)
{
    if (!tv_open || !tv_page || !tv_page->push || code < 0x3B || code > 0x3E) return 0;
    if (pressed) tv_page->push(code - 0x3B);
    return 1;
}
int kn_tapeview_knob(int knob, int delta)                  /* knob_event_hook, after the input filter and tape */
{
    if (!tv_open || !tv_page || !tv_page->turn || knob < 0 || knob > 3) return 0;
    tv_page->turn(knob, delta);
    return 1;
}
void kn_tapeview_service(void)                             /* main loop: SEQ + TAPE pressed outside tape mode */
{
    if (tv_req && CUR_MODE == 2) { tv_req = 0; if (!tv_off) view_set(1); }
}

/* ---- settings page switches ---- */
#define KN_SWITCHES 3
static struct { const char *feature, *label; volatile uint8_t on; } sw[KN_SWITCHES];
static int n_sw;
static int same(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
int op1_switch(const char *feature, const char *label)
{
    if (!feature || !label) return -1;
    for (int i = 0; i < n_sw; i++) if (same(sw[i].feature, feature)) return 0;
    if (n_sw >= KN_SWITCHES) return -1;
    sw[n_sw].feature = feature; sw[n_sw].label = label;
    sw[n_sw].on = (uint8_t)(op1_setting_get(feature, "on", 0) != 0);
    n_sw++;
    return 0;
}
int op1_switch_on(const char *feature)
{
    for (int i = 0; i < n_sw; i++) if (same(sw[i].feature, feature)) return sw[i].on;
    return 0;
}
int kn_switch_count(void) { return n_sw; }
const char *kn_switch_label(int i) { return i >= 0 && i < n_sw ? sw[i].label : 0; }
int kn_switch_get(int i) { return i >= 0 && i < n_sw ? sw[i].on : 0; }
void kn_switch_set(int i, int on)                          /* settings page (KeyHandler thread): saved at once */
{
    if (i < 0 || i >= n_sw || !sw[i].on == !on) return;
    sw[i].on = (uint8_t)(on != 0);
    op1_setting_set(sw[i].feature, "on", sw[i].on);
}
