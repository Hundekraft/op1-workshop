/*
 * Which saved FX names load as the "filter" FX slot (type 5): every non-empty name that is not a stock FX. Pure, so
 * the host test (harness/fx_name_test.c) runs the same code as dispatcher.c fx_name_eq.
 * Stock names: R246's own fx_types name table (8 entries next to the "unknown fx mode" asserts of fx_bypass.cpp,
 * order = type id 0..7). A custom FX, a renamed one ("sitting") or one whose plugin file is missing loads as filter;
 * fx_patch_type_hook then picks the plugin by name, or the stock filter when none is loaded. An empty name is not
 * matched (kn_patch_safe.c resets the FX).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_FX_NAMES_H
#define KN_FX_NAMES_H
#include <stdint.h>

static const char *const kn_stock_fx_names[] = { "delay", "grid", "punch", "phone", "spring", "filter", "nitro", "cwo",
                                                 0 };

/* p[0..n) (not 0-terminated) equals the C string s */
static inline int kn_fx_name_is(const char *p, uint32_t n, const char *s)
{
    uint32_t i = 0;
    for (; i < n; i++) if (p[i] != s[i] || !s[i]) return 0;
    return s[n] == 0;
}

static inline int kn_fx_name_to_filter(const char *p, uint32_t n)
{
    if (!n) return 0;
    for (const char *const *s = kn_stock_fx_names; *s; s++)
        if (kn_fx_name_is(p, n, *s)) return 0;          /* a stock FX: its own entry matches */
    return 1;
}
#endif
