/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (LICENSE, NOTICE). */
#ifndef KN_SCREENS_H
#define KN_SCREENS_H

#define KN_SCREEN_SLOTS 0x44

/* Gfx thread only. Draw a stable frame table and retire displaced documents' drawing caches.
 * The requested table and parsed documents retain their existing ownership/lifetime. */
void kn_screens_frame(void *requested);

#endif
