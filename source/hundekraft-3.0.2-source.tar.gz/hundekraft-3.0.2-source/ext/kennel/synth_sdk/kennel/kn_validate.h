/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#ifndef KN_VALIDATE_H
#define KN_VALIDATE_H
#include <stdint.h>
/* Validate relocated 32-bit ABI descriptors without executing plugin code.
 * OP1P has no text boundary; its executable range is its initialized image. */
int kn_validate(const uint8_t *image, uint32_t base, uint32_t image_size, uint32_t text_size,
                int kind, int extensions, uint32_t entry, uint32_t screen, const char **err);
#endif
