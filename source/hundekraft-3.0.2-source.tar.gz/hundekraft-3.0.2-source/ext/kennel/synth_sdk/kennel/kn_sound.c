/* Native sound-change services. Fade derived from pcppcp/op1r-src screens/overlay.c,
 * 7cf11afc2bade31f0fb08d3af877b9bb04f970bd (GPL-3.0-or-later + OP-1 firmware permission).
 * Kennel integration Copyright (C) 2026 Hundekraft, same terms. */
#include "../op1_feature_sound.h"
#include "../op1_synth.h"
#define GAIN (*(volatile int16_t *)0xFF80107C)
#define STEP (*(volatile int16_t *)0xFF80107E)
#define AUDIO_MODE (*(volatile int *)0xFF801038)
#define REQUEST_MODE (*(volatile int *)0x01DE4C40)
volatile uint8_t kn_fade_live, kn_sampler_adsr_live;
static volatile uint8_t fade_pre;
static uint32_t irq_off(void) { uint32_t m; __asm__ volatile("cli %0;" : "=d"(m)); return m; }
static void irq_on(uint32_t m) { __asm__ volatile("sti %0;" : : "d"(m) : "memory"); }
int op1_sound_fade(int out)
{
    uint32_t m = irq_off();
    if (!out || AUDIO_MODE != REQUEST_MODE) { kn_fade_live = 0; irq_on(m); return out ? 1 : 0; }
    if (!kn_fade_live) { fade_pre = 0; kn_fade_live = 1; }
    int pending = kn_fade_live != 2; irq_on(m); return pending;
}
/* Audio, envelope entry: stock resets the step before the voices, so override it here.
 * Bound the negative step so gain never crosses zero within the 64-sample decimator block. */
void kn_sound_pre(void)
{
    fade_pre = 1; int g = GAIN;
    if (kn_fade_live == 2 || g < 64) { GAIN = 0; STEP = 0; kn_fade_live = 2; }
    else { int step = g >> 6; STEP = (int16_t)-(step < 256 ? step : 256); }
}
void kn_sound_block_end(void)
{
    if (!kn_fade_live) return;
    if (!fade_pre) kn_fade_live = 2;
    if (kn_fade_live == 2) GAIN = 0;
    fade_pre = 0;
}
int kn_sound_adsr_stock(void *, int16_t *, const int16_t *, const int16_t *);
int kn_sound_adsr(void *self, int16_t *env, const int16_t *words, const int16_t *vel)
{
    extern const op1_samplerplus_t *op1_sampler;
    if(kn_fade_live)kn_sound_pre();
    uint32_t t0=op1_cycles();
    int r=op1_sampler?op1_sampler->adsr(self,env,words,vel):kn_sound_adsr_stock(self,env,words,vel);
    sm_cy[SMC_ENV]+=op1_cycles()-t0;return r;
}
void op1_sound_apply(int *patch) { ((void (*)(int *))0x01A010F8)(patch); }
extern int se_is_open(void);
int op1_sound_editor_open(void) { return se_is_open() || op1_text_entry_open(); }
