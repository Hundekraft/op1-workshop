/*
 * The R246 state kennel/kn_sampler.c reads, for host tests (OP1_HOST): a test fills kn_sampler_host before acting.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_SAMPLER_HOST_H
#define KN_SAMPLER_HOST_H
#include <stdint.h>
typedef struct {
    int screen;                 /* current screen id (6 synth sampler, 0x10 drum) */
    int stock;                  /* the stock screen object is shown */
    int synth_slot, drum_slot;
    int synth_type, drum_type;  /* 6 sampler, 8 drum sampler */
    int key;                    /* drum key played last */
    int busy;
    int16_t *data;              /* the audio (cap samples) */
    int16_t words[8];           /* synth knob words */
    int16_t pads[24 * 8];       /* drum pad table */
    uint32_t sound;             /* stands for the overview hash: change it to "load another sound" */
    int commits, audio_commits;
    int has_bf;
    uint32_t bf[2], bf32;
    uint32_t cycles;
} kn_sampler_host_t;
extern kn_sampler_host_t kn_sampler_host;
#endif
