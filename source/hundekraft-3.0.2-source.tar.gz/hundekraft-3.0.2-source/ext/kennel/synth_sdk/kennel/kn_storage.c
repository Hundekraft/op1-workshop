/*
 * Storage walk (op1_feature.h op1_storage / op1_storage_refresh), for the FILE view: bytes on the flash per
 * category. A walk of /yaffs2 runs on the main loop a few directory entries per pass (kn_core_service), never on the
 * Gfx or KeyHandler thread; the totals stay cached until the next disk mode ends or a feature asks again.
 *
 * R246 / YAFFS2 Direct (docs/firmware/storage.md in the full project): yaffs_opendir 0x01A9B450, yaffs_readdir 0x01A9B648
 * (dirent = handle + 4: name at +11, the entry's object at +0x10C), yaffs_closedir 0x01A9B74C, yaffs_total_space
 * 0x01A9B284 / yaffs_free_space 0x01A9B1C0 (bytes). Object: type at +0x64 (1 file, 3 directory), file size at +0x68,
 * data chunks at +0x2C (2 KiB each; tape_c.raw is sparse, so its chunks, not its size, are what it takes). Device: the
 * mount entry yaffs uses for its stats dump (0x01A98E52(path), mounted at +0xC0, [[+0xD7C] + 8] = the device):
 * blocks +0xCC..+0xD0, block info +0x114 (8 bytes per block, state = word 0 bits 20..23, 9 = dead), chunks per
 * block +0x0C, chunk bytes 2048. Disk mode: disk_mode_active 0xFF906EF9 (set and cleared by disk_mode_toggle).
 * Categories: tape = /user/tape_c.raw, /user/tape.db and /user/tape2..4/ (four tapes); sounds = the rest of /user; mods = /plugins and plugin
 * files (.knl, .op1p) in /content; factory = the rest of /content; system = everything else (the firmware files,
 * ...); bad = dead blocks; free = yaffs_free_space; overhead = what is left of the total (object headers, chunks
 * waiting for garbage collection, the reserved blocks' share, checkpoints).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_feature.h"

#define CHUNK        2048u
#define DEPTH        8
#define PATH_MAX_    192
#define PER_PASS     8                                  /* directory entries per main loop pass */

#ifdef OP1_HOST                                         /* harness/storage_test.c */
void *host_opendir(const char *path);
void *host_readdir(void *dir);
void host_closedir(void *dir);
uint32_t host_total(void), host_free(void), host_dead_blocks(void);
extern volatile uint8_t host_disk_mode;
#define OPENDIR(p)   host_opendir(p)
#define READDIR(d)   ((uint8_t *)host_readdir(d))
#define CLOSEDIR(d)  host_closedir(d)
#define TOTAL()      host_total()
#define FREE()       host_free()
#define DISK_MODE    host_disk_mode
static uint32_t dead_blocks(uint32_t *block_bytes) { *block_bytes = 64 * CHUNK; return host_dead_blocks(); }
#define ALLOC(n)     op1_alloc(n)
#else
#define OPENDIR(p)   (((void *(*)(const char *))0x01A9B450)(p))
#define READDIR(d)   (((uint8_t *(*)(void *))0x01A9B648)(d))
#define CLOSEDIR(d)  (((int (*)(void *))0x01A9B74C)(d))
#define TOTAL()      ((uint32_t)((int (*)(const char *))0x01A9B284)("/yaffs2"))
#define FREE()       ((uint32_t)((int (*)(const char *))0x01A9B1C0)("/yaffs2"))
#define DISK_MODE    (*(volatile uint8_t *)0xFF906EF9)        /* disk_mode_active (disk_mode_toggle 0x0199742C) */
static uint32_t dead_blocks(uint32_t *block_bytes)
{
    uint8_t rest[8];
    uint8_t *m = ((uint8_t *(*)(const char *, void *))0x01A98E52)("/yaffs2", rest);
    *block_bytes = 64 * CHUNK;
    if (!m || !*(uint32_t *)(m + 0xC0)) return 0;
    uint8_t *ctx = *(uint8_t **)(m + 0xD7C);
    uint8_t *dev = ctx ? *(uint8_t **)(ctx + 8) : 0;
    if (!dev) return 0;
    int32_t first = *(int32_t *)(dev + 0xCC), last = *(int32_t *)(dev + 0xD0), per = *(int32_t *)(dev + 0x0C);
    const uint32_t *bi = *(const uint32_t **)(dev + 0x114);
    if (!bi || last < first || per <= 0 || per > 1024) return 0;
    *block_bytes = (uint32_t)per * CHUNK;
    uint32_t n = 0;
    for (int32_t b = 0; b <= last - first; b++) if (((bi[2 * b] >> 20) & 0xF) == 9) n++;
    return n;
}
#define ALLOC(n)     op1_alloc(n)
#endif
#define DIRENT_NAME  11
#define DIRENT_OBJ   0x10C
#define OBJ_CHUNKS   0x2C
#define OBJ_TYPE     0x64
#define OBJ_SIZE     0x68

typedef struct { void *dir; int len; } level;
static struct {
    level stack[DEPTH];
    char path[PATH_MAX_];
    int depth;
} *w;                                                   /* in the arena, made at the first walk */
static uint32_t acc[OP1_STORE_N], acc_files, acc_size;
static op1_storage_t cache;
static volatile int walking, want;

static int starts(const char *s, const char *p) { while (*p) if (*s++ != *p++) return 0; return 1; }
static int ends(const char *s, int n, const char *x)
{
    int m = 0; while (x[m]) m++;
    if (n < m) return 0;
    for (int i = 0; i < m; i++) if (s[n - m + i] != x[i]) return 0;
    return 1;
}
static int category(const char *path, int n)
{
    if (starts(path, "/yaffs2/user/")) {
        if ((starts(path, "/yaffs2/user/tape_c.raw") && n == 23) || (starts(path, "/yaffs2/user/tape.db") && n == 20))
            return OP1_STORE_TAPE;
        if (n > 19 && starts(path, "/yaffs2/user/tape") && path[17] >= '2' && path[17] <= '4' && path[18] == '/')
            return OP1_STORE_TAPE;                                  /* tapes 2..4 (kn_tapes.c): everything in tape<N>/ */
        return OP1_STORE_SOUNDS;
    }
    if (starts(path, "/yaffs2/plugins/")) return OP1_STORE_MODS;
    if (starts(path, "/yaffs2/content/")) {
        int slash = 0;
        for (int i = 16; i < n; i++) if (path[i] == '/') slash = 1;
        if (!slash && (ends(path, n, ".knl") || ends(path, n, ".op1p"))) return OP1_STORE_MODS;
        return OP1_STORE_FACTORY;
    }
    return OP1_STORE_SYSTEM;
}

static int push(const char *name)                       /* append /name and open it; 0 if not possible */
{
    if (w->depth >= DEPTH) return 0;
    int len = w->depth ? w->stack[w->depth - 1].len : 0, n = len;
    if (name) {
        if (n + 1 >= PATH_MAX_) return 0;
        w->path[n++] = '/';
        for (; *name; name++) { if (n >= PATH_MAX_ - 1) return 0; w->path[n++] = *name; }
    }
    w->path[n] = 0;
    void *d = OPENDIR(w->path);
    if (!d) { w->path[len] = 0; return 0; }
    w->stack[w->depth].dir = d; w->stack[w->depth].len = n; w->depth++;
    return 1;
}

static void finish(void)
{
    uint32_t block, bad = dead_blocks(&block) * block, total = TOTAL(), free_ = FREE();
    acc[OP1_STORE_BAD] = bad;
    acc[OP1_STORE_FREE] = free_;
    uint32_t used = acc[OP1_STORE_TAPE] + acc[OP1_STORE_SOUNDS] + acc[OP1_STORE_FACTORY] + acc[OP1_STORE_SYSTEM] +
                    acc[OP1_STORE_MODS] + bad + free_;
    acc[OP1_STORE_OVERHEAD] = total > used ? total - used : 0;
    cache.ready = 0;                                    /* readers see ready last */
    for (int i = 0; i < OP1_STORE_N; i++) cache.bytes[i] = acc[i];
    cache.total = total; cache.files = acc_files; cache.file_size = acc_size;
    cache.gen++;
    cache.ready = 1;
    walking = 0;
}

static void start(void)
{
    if (!w && !(w = ALLOC(sizeof *w))) return;
    for (int i = 0; i < OP1_STORE_N; i++) acc[i] = 0;
    acc_files = acc_size = 0;
    int n = 0;
    for (const char *s = "/yaffs2"; *s; s++) w->path[n++] = *s;          /* the root, without a trailing slash */
    w->path[n] = 0;
    w->depth = 0;
    void *d = OPENDIR(w->path);
    if (!d) return;
    w->stack[0].dir = d; w->stack[0].len = n; w->depth = 1;
    walking = 1;
}

static void step(void)
{
    for (int k = 0; k < PER_PASS && w->depth; k++) {
        level *l = &w->stack[w->depth - 1];
        uint8_t *e = READDIR(l->dir);
        if (!e) {                                       /* this directory is done */
            CLOSEDIR(l->dir);
            w->depth--;
            if (w->depth) w->path[w->stack[w->depth - 1].len] = 0;
            continue;
        }
        const char *name = (const char *)e + DIRENT_NAME;
        if (!name[0] || (name[0] == '.' && (!name[1] || (name[1] == '.' && !name[2])))) continue;
        const uint8_t *obj = *(const uint8_t *const *)(e + DIRENT_OBJ);
        if (!obj) continue;
        int32_t type = *(const int32_t *)(obj + OBJ_TYPE);
        if (type == 3) { push(name); continue; }      /* a directory: walk into it (too deep: skipped) */
        if (type != 1) continue;                        /* links and specials: their header only (overhead) */
        int n = l->len;
        char *p = w->path;
        if (n + 1 < PATH_MAX_) { p[n] = '/'; int m = n + 1; for (const char *s = name; *s && m < PATH_MAX_ - 1; s++) p[m++] = *s; p[m] = 0; n = m; }
        acc[category(p, n)] += (uint32_t)*(const int32_t *)(obj + OBJ_CHUNKS) * CHUNK;
        acc_files++;
        acc_size += (uint32_t)*(const int32_t *)(obj + OBJ_SIZE);
        p[l->len] = 0;
    }
    if (!w->depth) finish();
}

/* main loop (kn_core_service) */
void kn_storage_service(void)
{
    static int disk;
    if (DISK_MODE) disk = 1;
    else if (disk) { disk = 0; cache.ready = 0; }       /* a disk sync may have changed everything */
    if (DISK_MODE) return;                              /* never while the host owns the disk */
    if (walking) { step(); return; }
    if (want) { want = 0; start(); }
}

int op1_storage(op1_storage_t *out)
{
    if (out) {                                          /* field by field: no memcpy in the firmware */
        out->ready = 0;
        for (int i = 0; i < OP1_STORE_N; i++) out->bytes[i] = cache.bytes[i];
        out->total = cache.total; out->files = cache.files; out->file_size = cache.file_size; out->gen = cache.gen;
        out->ready = cache.ready;
    }
    if (!cache.ready && !walking) want = 1;
    return cache.ready;
}

void op1_storage_refresh(void) { want = 1; }
