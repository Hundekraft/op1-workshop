/* st_fit.h - sampler "fit to length": change the used part [a, b) of the sample buffer to exactly l_out samples
 * and place it at [0, l_out), in place, in chunks. Pure C, integers only (Blackfin, no FPU, no libc).
 *
 *   ST_FIT_TAPE  speed change (linear interpolation, Q16 read position, pitch moves)
 *   ST_FIT_KEEP  time stretch keeping pitch (WSOLA, 1024 window, 512 hop, +-256 search)
 *
 * Usage (firmware main loop, never the audio thread):
 *   st_fit_begin(&w, buf, cap, a, b, l_out, mode);      pick l_out in [st_fit_min_len(b-a), st_fit_max_len(cap, b-a, mode)]
 *   while (st_fit_step(&w, budget)) { draw st_fit_progress(&w); }
 *   st_fit_map(&w, old_pos) for moving markers.
 * Work struct is about 1.5 KB, caller-owned, no malloc, no big statics. See st_fit.c for the in-place proof.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef ST_FIT_H
#define ST_FIT_H
#include <stdint.h>

#define ST_FIT_KEEP 0
#define ST_FIT_TAPE 1
#define ST_FIT_MIN_IN 2205              /* shortest used range: 0.05 s at 44100 Hz */
#define ST_FIT_HOP 512
#define ST_FIT_NCMP 128                 /* decimated (every 4th) comparison points */

typedef struct st_fit_work {
    int16_t *buf;                       /* the sample buffer (capacity cap) */
    int16_t *out;                       /* write target; == buf. TEST HOOK: point elsewhere for an out-of-place run */
    int32_t cap, a, b, l_in, l_out;
    int32_t tail;                       /* cap - l_in: where the input lives while it is read */
    int mode, phase;
    int32_t mv_left, mv_total;          /* initial move: input samples still to move / in total (0 if none) */
    int32_t o, zpos;                    /* next output index; next index to zero */
    int32_t ip, fr, stepi, stepf;       /* TAPE: read position (integer part, 16-bit fraction) and step */
    int32_t S, rsh, dec, ncmp;          /* KEEP: frame size (hop), rise-table stride shift, comparison decimation and count */
    int32_t k, j, A, B, p_prev;         /* KEEP: frame number, index in frame, chosen/continuation input offsets */
    int64_t ha, cq;                     /* KEEP: analysis hop and nominal position, Q16 */
    uint32_t ops;                       /* diagnostic: abs-diff terms + output samples so far (cost estimate) */
    int16_t tgt[ST_FIT_NCMP];           /* KEEP: decimated comparison target of the current frame */
    int16_t rise[ST_FIT_HOP];           /* KEEP: Q15 Hann rising half; the falling half is 32768 - rise */
} st_fit_work;

int32_t st_fit_min_len(int32_t l_in);                               /* smallest l_out (ratio 1/8) */
int32_t st_fit_max_len(int32_t cap, int32_t l_in, int mode);        /* largest safe l_out (0 = nothing allowed) */
int st_fit_begin(st_fit_work *w, int16_t *buf, int32_t cap, int32_t a, int32_t b, int32_t l_out, int mode);
int st_fit_step(st_fit_work *w, int32_t budget);                    /* 1 = more to do, 0 = done */
int32_t st_fit_progress(const st_fit_work *w);                      /* 0..1024 */
int32_t st_fit_map(const st_fit_work *w, int32_t pos);              /* old position in [a, b] -> new in [0, l_out] */

#endif
