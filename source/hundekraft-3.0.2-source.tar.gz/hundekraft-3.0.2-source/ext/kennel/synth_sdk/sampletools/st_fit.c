/* st_fit.c - sampler "fit to length", in place, integers only. API and use: st_fit.h.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 *
 * IN-PLACE SCHEME (cap = buffer size, L = used length b - a, T = cap - L):
 *   1. MOVE: the input [a, b) goes to the tail [T, cap), copied from the top down (T >= a always, because
 *      b <= cap, so a descending copy is a correct memmove). Skipped when T == a. Input sample i now sits at buf[T + i].
 *   2. GEN: the output is written forwards from buf[0]; it only reads the tail.
 *   3. FADE the last 64 output samples, then ZERO [l_out, cap) (the tail is dead by then).
 *
 * TAPE proof. Output i reads input ip(i) and ip(i)+1, ip(i) = floor(i*step / 2^16), then writes buf[i]. Every later
 * read is at buf index >= T + ip(i+1), so the write is safe if i < T + ip(i+1). With step >= 1 (shrinking)
 * ip(i+1) >= i+1, so it holds. With step < 1 (stretching), step is the exact (L-1)/(l_out-1) rounded down by < 2^-16,
 * so (i+1)*step loses < 8.1 (i+1 < 2^19) plus 1 for the floor. The worst case is i = l_out-2:
 * i - ip(i+1) <= l_out - L - 1 + 9.1 < T = cap - L  <=>  l_out < cap - 8.1. Margin 16 is used; the host test also
 * checks the inequality exhaustively at l_out = max_len and compares sample-exact with an out-of-place reference.
 *
 * KEEP proof (S = frame size, 512 unless compressing by >1.5x; Ha = S*L/l_out, the analysis hop). Frame k (S output
 * samples at [S*k, S*k+S)) reads input offsets only >= F_k = S*k - T: the search window start, the continuation
 * (previous choice + S >= F_{k-1} + S = F_k) and the crossfade sources. The code enforces this by clamping the
 * search range (lo = max(c-256, F_k, 0)) and, when no search is possible, p = max(c, F_k). A read at buffer index
 * T + r with r >= F_k is at index >= S*k, while all earlier frames wrote only indices < S*k; inside frame k, output
 * j is written after reading its own inputs, and the later reads of the frame are at T + A + j' > S*k + j for
 * j' > j. So no read ever sees an overwritten sample, for ANY l_out and ANY data. The margin only decides how often
 * the clamp bites. Stretching (L <= l_out, so Ha <= S <= 512): the nominal position c_k at the last frame is
 * >= L - Ha, so the clamp leaves the whole +-256 window free when l_out <= cap - Ha - 258; margin 1024 covers
 * that. For l_out < L the reader runs ahead of the writer and the clamp only touches the first frames when T is small.
 *
 * WSOLA: output frame k is a Hann crossfade over its S samples between the tail of the previous chosen
 * segment (input at p_{k-1}+S..) and the head of the new segment (input at p_k..), the new segment's start p_k is
 * the position within c_k +- 256 (c_k = k*Ha, Ha = S*L/l_out) whose head is most similar (sum of absolute
 * differences, every 4th sample, coarse step 2 then +-1) to that continuation. Needs no accumulation buffer. Reads
 * past the end of the input are zero. Frame 0 is copied unfaded.
 *
 * Cost: see the header of harness/st_fit_test.c. Known WSOLA limits: stretching repeats a hit once per overlapping
 * segment (flams 512 samples apart), compressing by >4x can drop short hits.
 */
#include <stdint.h>
#include "st_fit.h"

#define HOP ST_FIT_HOP
#define SRCH 256
#define DEC 4
#define NCMP ST_FIT_NCMP
#define KEEP_MARGIN 1024
#define TAPE_MARGIN 16
#define FADE 64
#define GEN_W 4                         /* progress weight of one generated sample vs one moved/zeroed sample */

enum { PH_MOVE, PH_GEN, PH_ZERO, PH_DONE };

static int32_t imin(int32_t x, int32_t y) { return x < y ? x : y; }
static int32_t imax(int32_t x, int32_t y) { return x > y ? x : y; }
static int16_t sat16(int32_t v) { return (int16_t)(v > 32767 ? 32767 : (v < -32768 ? -32768 : v)); }

int32_t st_fit_min_len(int32_t l_in) { return (l_in + 7) >> 3; }

int32_t st_fit_max_len(int32_t cap, int32_t l_in, int mode)
{
    int32_t m;
    if (cap <= 0 || l_in < ST_FIT_MIN_IN || l_in > cap) return 0;
    m = cap - (mode == ST_FIT_TAPE ? TAPE_MARGIN : KEEP_MARGIN);
    m = imin(m, l_in * 8);
    return m < 0 ? 0 : m;
}

int st_fit_begin(st_fit_work *w, int16_t *buf, int32_t cap, int32_t a, int32_t b, int32_t l_out, int mode)
{
    int32_t l_in, j;
    int64_t c, c1, k2;
    if (!w || !buf || cap <= 0 || a < 0 || b > cap || a >= b) return -1;
    l_in = b - a;
    if (l_in < ST_FIT_MIN_IN) return -1;
    if (l_out < st_fit_min_len(l_in) || l_out > st_fit_max_len(cap, l_in, mode)) return -1;
    w->buf = buf; w->out = buf;
    w->cap = cap; w->a = a; w->b = b; w->l_in = l_in; w->l_out = l_out;
    w->tail = cap - l_in;
    w->mode = mode == ST_FIT_TAPE ? ST_FIT_TAPE : ST_FIT_KEEP;
    w->mv_total = w->tail == a ? 0 : l_in;
    w->mv_left = w->mv_total;
    w->phase = w->mv_total ? PH_MOVE : PH_GEN;
    w->o = 0; w->zpos = l_out;
    w->ip = 0; w->fr = 0; w->stepi = 0; w->stepf = 0;
    w->S = HOP; w->rsh = 0; w->dec = DEC; w->ncmp = NCMP; w->k = 0; w->j = 0; w->A = 0; w->B = 0; w->p_prev = 0; w->ha = 0; w->cq = 0; w->ops = 0;
    if (w->mode == ST_FIT_TAPE) {
        int64_t step = (((int64_t)(l_in - 1)) << 16) / (l_out - 1);   /* >= 2^13, < 2^19 */
        w->stepi = (int32_t)(step >> 16);
        w->stepf = (int32_t)(step & 0xffff);
    } else {
        /* frame size S: 512 (window 1024) unless compressing by more than 1.5x, where S shrinks (256/128/64) so that
         * the unavoidable dropped input stays in short pieces and short hits are not lost wholly */
        w->rsh = 0; w->S = HOP;
        while (w->rsh < 3 && (int64_t)l_in * 2 > (int64_t)l_out * (3 << w->rsh)) { w->rsh++; w->S >>= 1; }
        w->dec = w->S >= 128 ? w->S / 128 : 1;
        w->ncmp = w->S / w->dec;
        w->ha = ((((int64_t)w->S * l_in)) << 16) / l_out;
        /* Hann rising half, rise[j] = 32768*(1-cos(pi*j/512))/2, cos by the Q30 Chebyshev recurrence
         * c[j+1] = 2cos(pi/512) c[j] - c[j-1]; the falling half is the exact complement, so the crossfade sums to 1 */
        k2 = 2147443222;                /* round(2*cos(pi/512)*2^30) */
        c = 1073741824;                 /* cos(0) */
        c1 = 1073721611;                 /* cos(pi/512) */
        for (j = 0; j < HOP; j++) {
            int32_t r = (int32_t)(((1073741824 - c) + 32768) >> 16);
            w->rise[j] = (int16_t)(r < 0 ? 0 : (r > 32767 ? 32767 : r));
            { int64_t cn = ((k2 * c1) >> 30) - c; c = c1; c1 = cn; }
        }
    }
    return 0;
}

/* input sample r (zero outside the used range) */
static int32_t rdz(const st_fit_work *w, int32_t r)
{
    return (r < 0 || r >= w->l_in) ? 0 : w->buf[w->tail + r];
}

/* sum of absolute differences of 128 samples (every 4th) against the target, stops once it cannot win */
static int32_t sad(st_fit_work *w, int32_t p, int32_t best)
{
    const int16_t *x = w->buf + w->tail + p;
    int32_t s = 0, m, q, dec = w->dec;
    for (m = 0; m < w->ncmp; m += 16) {
        for (q = m; q < m + 16; q++) {
            int32_t d = x[q * dec] - w->tgt[q];
            s += d < 0 ? -d : d;
        }
        if (s >= best) { w->ops += (uint32_t)(m + 16); return s; }
    }
    w->ops += (uint32_t)w->ncmp;
    return s;
}

static void keep_frame_start(st_fit_work *w)
{
    int32_t k = w->k, c, floorv, lo, hi, p, m, center, best, bp, d, u, v, s, q, S = w->S;
    c = (int32_t)(w->cq >> 16);
    w->cq += w->ha;
    if (k == 0) { w->A = 0; w->B = 0; return; }
    floorv = k * S - w->tail;                         /* nothing below this input offset is still intact */
    w->B = w->p_prev + S;
    lo = imax(imax(c - SRCH, floorv), 0);
    hi = imin(c + SRCH, w->l_in - S);
    if (lo > hi) { w->A = imax(c, floorv); return; }
    for (m = 0; m < w->ncmp; m++) w->tgt[m] = (int16_t)rdz(w, w->B + m * w->dec);
    center = c < lo ? lo : (c > hi ? hi : c);
    best = sad(w, center, 0x7fffffff);
    bp = center;
    for (d = 2; ; d += 2) {
        u = center + d; v = center - d;
        if (u > hi && v < lo) break;
        if (u <= hi) { s = sad(w, u, best); if (s < best) { best = s; bp = u; } }
        if (v >= lo) { s = sad(w, v, best); if (s < best) { best = s; bp = v; } }
    }
    p = bp;
    for (q = -1; q <= 1; q += 2) {
        int32_t t = p + q;
        if (t >= lo && t <= hi) { s = sad(w, t, best); if (s < best) { best = s; bp = t; } }
    }
    w->A = bp;
}

static void keep_run(st_fit_work *w, int32_t n)
{
    while (n > 0) {
        int32_t run, q, j;
        int16_t *o;
        if (w->j == 0) keep_frame_start(w);
        j = w->j;
        run = imin(n, w->S - j);
        o = w->out + w->o;
        if (w->k == 0) {
            for (q = 0; q < run; q++) o[q] = (int16_t)rdz(w, w->A + j + q);
        } else {
            for (q = 0; q < run; q++) {
                int32_t r = w->rise[(j + q) << w->rsh];
                int32_t x1 = rdz(w, w->B + j + q), x2 = rdz(w, w->A + j + q);
                o[q] = sat16((x1 * (32768 - r) + x2 * r + 16384) >> 15);
            }
        }
        w->o += run; w->j += run; w->ops += (uint32_t)run; n -= run;
        if (w->j == w->S) { w->j = 0; w->p_prev = w->A; w->k++; }
    }
}

static void tape_run(st_fit_work *w, int32_t n)
{
    const int16_t *x = w->buf + w->tail;
    int16_t *o = w->out + w->o;
    int32_t ip = w->ip, fr = w->fr, last = w->l_in - 1, q;
    for (q = 0; q < n; q++) {
        int32_t v;
        if (ip >= last) v = x[last];
        else {
            int32_t s0 = x[ip];
            v = s0 + (((x[ip + 1] - s0) * (fr >> 1)) >> 15);
        }
        o[q] = sat16(v);
        fr += w->stepf;
        ip += w->stepi + (fr >> 16);
        fr &= 0xffff;
    }
    w->ip = ip; w->fr = fr; w->o += n; w->ops += (uint32_t)n;
}

int st_fit_step(st_fit_work *w, int32_t budget)
{
    if (budget < 1) budget = 1;
    while (budget > 0 && w->phase != PH_DONE) {
        int32_t n, i;
        if (w->phase == PH_MOVE) {
            n = imin(budget, w->mv_left);
            for (i = 0; i < n; i++) { w->mv_left--; w->buf[w->tail + w->mv_left] = w->buf[w->a + w->mv_left]; }
            budget -= n;
            if (w->mv_left == 0) w->phase = PH_GEN;
        } else if (w->phase == PH_GEN) {
            n = imin(budget, w->l_out - w->o);
            if (w->mode == ST_FIT_TAPE) tape_run(w, n); else keep_run(w, n);
            budget -= n;
            if (w->o == w->l_out) {
                for (i = 0; i < FADE; i++) {    /* gain (64 - i) / 64 on the last 64 samples */
                    int16_t *p = w->out + w->l_out - FADE + i;
                    *p = (int16_t)((*p * (FADE - i)) >> 6);
                }
                w->phase = PH_ZERO;
            }
        } else {
            n = imin(budget, w->cap - w->zpos);
            for (i = 0; i < n; i++) w->out[w->zpos + i] = 0;
            w->zpos += n; budget -= n;
            if (w->zpos >= w->cap) w->phase = PH_DONE;
        }
    }
    return w->phase != PH_DONE;
}

int32_t st_fit_progress(const st_fit_work *w)
{
    int64_t total = (int64_t)w->mv_total + (int64_t)GEN_W * w->l_out + (w->cap - w->l_out), done;
    if (w->phase == PH_DONE) return 1024;
    done = (int64_t)(w->mv_total - w->mv_left) + (int64_t)GEN_W * w->o + (w->zpos - w->l_out);
    return (int32_t)((done << 10) / total);
}

int32_t st_fit_map(const st_fit_work *w, int32_t pos)
{
    if (pos <= w->a) return 0;
    if (pos >= w->b) return w->l_out;
    return (int32_t)(((int64_t)(pos - w->a) * w->l_out) / w->l_in);
}
