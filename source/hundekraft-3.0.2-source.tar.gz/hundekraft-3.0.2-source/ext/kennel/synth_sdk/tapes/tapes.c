/* Four tapes (docs/tapes.md): hold tape and press T1..T4 to switch tapes (the core's op1_tape_switch, kennel/kn_tapes.c
 * does the work on the main loop); a popup over the reels shows the tape and its tempo (screens/tape_popup.h, as undo's). REC does nothing but say "flash full" when
 * less than 32 MB is free: a take that runs out of flash would be lost.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../op1_feature_tape.h"
#include "../screens/tape_popup.h"

#define REC_MIN_FREE (32u << 20)                  /* one full-length track take is 31.8 MB */

static uint8_t tape_held, swallow[0x40];
#define POP_FRAMES 90                             /* about 1.5 s of tape screen frames */
static char pop1[8], pop2[16];                     /* "TAPE 2", "125 BPM" / "120.5 BPM" */
static volatile uint8_t pop_left;

static void show(int tape)
{
    char *o = pop1;
    for (const char *h = "TAPE "; *h; h++) *o++ = *h;
    *o++ = (char)('1' + tape);
    *o = 0;
    o = pop2;
    int32_t v = op1_tape_bpm10(), w = v / 10;
    char d[6]; int k = 0;
    do { d[k++] = (char)('0' + w % 10); w /= 10; } while (w && k < 5);
    while (k) *o++ = d[--k];
    if (v % 10) { *o++ = '.'; *o++ = (char)('0' + v % 10); }
    for (const char *h = " BPM"; *h; h++) *o++ = *h;
    *o = 0;
    pop_left = POP_FRAMES;
}

static void tp_draw(void)                         /* tape screen draw (Gfx thread) */
{
    if (!pop_left) return;
    tape_popup(op1_raster(), pop1, pop2, 1, 1);
    pop_left--;
}

static int tp_input(const op1_input *in)
{
    if (in->type != OP1_IN_KEY || in->code >= 0x40) return 0;
    int code = in->code;
    if (code == 0x04) tape_held = in->pressed;                    /* the tape key itself stays stock */
    if (!in->pressed) { if (swallow[code]) { swallow[code] = 0; return 1; } return 0; }
    if (tape_held && code >= 0x06 && code <= 0x09) {              /* tape + T1..T4 */
        int r = op1_tape_switch(code - 0x06);
        if (r == OP1_TAPE_SW_SAME) show(code - 0x06);
        else if (r == OP1_TAPE_SW_RECORDING) op1_toast("stop recording first");
        else if (r == OP1_TAPE_SW_DISK) op1_toast("not in disk mode");
        else if (r == OP1_TAPE_SW_BUSY) op1_toast("tape is busy, try again");
        else if (r == OP1_TAPE_SW_FULL) op1_toast("a new tape needs 64 mb free");
        swallow[code] = 1;
        return 1;
    }
    if (code == 0x21 && op1_flash_free() < REC_MIN_FREE) {        /* REC: flash full */
        op1_toast("flash full");
        swallow[code] = 1;
        return 1;
    }
    return 0;
}

static void tp_event(int id, int32_t arg)
{
    if (id == OP1_EV_TAPE_SWITCH && !(arg >> 16 & 1) && ((arg >> 8) & 0xFF) != (arg & 0xFF)) show((arg >> 8) & 3);
}

static const char *const tp_claims[] = { "key:tape:tape+t1", "key:tape:tape+t2", "key:tape:tape+t3", "key:tape:tape+t4", 0 };
static const struct op1_tape_hooks tp_tape = { .draw = tp_draw };
const op1_feature_t FEATURE_tapes = { .api = OP1_FEATURE_API, .priority = 440, .name = "tapes", .event = tp_event,
                                      .input = tp_input, .tape = &tp_tape, .claims = tp_claims };
