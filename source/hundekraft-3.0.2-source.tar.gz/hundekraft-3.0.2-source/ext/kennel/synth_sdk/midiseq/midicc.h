/* MIDI CC automation map (op1r 35 midi/mx.c): CC 53-60 engine knobs / envelope, CC 72-79 FX / LFO knobs of the current
 * synth slot. Static, so midicc.c and midiseq.c can each ship as their own plugin file.
 * Copyright (C) 2026 Hundekraft, pcppcp. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef MIDICC_H
#define MIDICC_H
#include "../op1_feature_midi.h"
static inline int midicc_index(int cc)                    /* group * 4 + knob, -1: not in the map */
{
    if (cc >= 53 && cc <= 60) return cc - 53;
    if (cc >= 72 && cc <= 79) return cc - 64;
    return -1;
}
static inline int midicc_set(int cc, int value)           /* op1_param_set for a mapped CC; 1 if mapped. Any thread */
{
    int i = midicc_index(cc);
    if (i < 0) return 0;
    op1_param_set(i >> 2, i & 3, value);
    return 1;
}
#endif
