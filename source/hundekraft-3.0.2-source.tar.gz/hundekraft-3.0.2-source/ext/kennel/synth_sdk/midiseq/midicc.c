/*
 * MIDI CC automation of the current synth slot, as a kennel feature (op1r 35, op1r-src 5c90efb midi/mx.c, pcppcp):
 * absolute CCs on the OP-1's MIDI channel set knobs like turning them, saved in the sound.
 *   CC 53-56  engine knobs 1-4      CC 57-60  envelope A D S R
 *   CC 72-75  synth FX knobs 1-4    CC 76-79  synth LFO knobs 1-4
 * The CCs come through midi_in (dispatcher.c midi_cc_hook: the OP-1's channel only, as stock receives them); the
 * values go to op1_param_set, which applies them on the KeyHandler thread like a knob turn. These CCs are taken
 * (op1_midi_take_cc), so they no longer press keys through the core's CC -> key mapping. The MIDI sequencer
 * (midiseq.c) plays recorded CCs into the same map (midicc.h).
 * Copyright (C) 2026 Hundekraft, pcppcp. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_feature_midi.h"
#include "midicc.h"

static void mc_midi_in(const uint8_t *m, int len)
{
    if (len == 3 && (m[0] & 0xF0) == 0xB0) midicc_set(m[1], m[2]);
}
static void mc_event(int id, int32_t arg)
{
    (void)arg;
    if (id != OP1_EV_BOOT_DONE) return;
    for (int cc = 53; cc <= 79; cc++) if (midicc_index(cc) >= 0) op1_midi_take_cc(cc, 1);
}
static const char *const mc_claims[] = { "midi:cc53-60", "midi:cc72-79", 0 };
const op1_feature_t FEATURE_midicc = { .api = OP1_FEATURE_API, .priority = 1000, .name = "midicc",
                                       .event = mc_event, .midi_in = mc_midi_in, .claims = mc_claims };
