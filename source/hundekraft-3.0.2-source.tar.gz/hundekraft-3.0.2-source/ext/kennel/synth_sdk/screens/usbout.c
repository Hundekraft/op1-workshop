/* USB out page (clock screen + T2, docs/21), in the style of the synth playmode page: blue label "USB OUT", value
 * "MASTER" or "MASTER / + TRACKS". Blue turns between them; applies at once (USB stays 6 channels, the track channels
 * are silent and the track work is skipped with "MASTER"). Saved in the DB table op1rsettings by the core
 * (screens/settings_store.c), which also applies the saved value at USB start; this page is a feature
 * (plugins/usbout, FEATURE_usbout on clock T2). */
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "stroke_font.h"

extern volatile uint8_t usb_tracks_live;                    /* core: screens/usbtrack.c */
extern void usbout_save(int on);                            /* core: screens/settings_store.c */

static int32_t acc;
void usbout_turn(int delta)                                 /* blue: one detent each way switches */
{
    if ((acc > 0 && delta < 0) || (acc < 0 && delta > 0)) acc = 0;
    acc += delta;
    int st = acc / 1024; if (!st) return;
    acc = 0;
    uint8_t v = st > 0;
    if (v == usb_tracks_live) return;
    usb_tracks_live = v;                                    /* at once */
    usbout_save(v);
}

/* ---- screen: stroke-font text like the stock playmode page (label column, value column, 1.5 px lines) ---- */
static const uint8_t c_blue[4] = { 0x4D, 0x9E, 0xFF, 0xFF };
#define US_S   OP1_Q10(5) / 2                               /* 2.5 px per grid unit: 15 px caps, 15 px advance */
#define US_W   0x600                                        /* 1.5 px */
#define US_LX  OP1_Q10(24)
#define US_VX  OP1_Q10(164)
#define US_Y0  OP1_Q10(40)
#define US_DY  OP1_Q10(28)

static void us_init(void *scr) { (void)scr; }

static void us_update(void *scr, int dt)
{
    op1_screen_draw(scr, dt);
    void *r = op1_raster();
    sf_text(r, US_LX, US_Y0, US_S, "USB OUT", US_W, c_blue);
    sf_text(r, US_VX, US_Y0, US_S, "MASTER", US_W, c_blue);
    if (usb_tracks_live) sf_text(r, US_VX, US_Y0 + US_DY, US_S, "+ TRACKS", US_W, c_blue);
}

const op1_screen_t SCREEN_usbout = { us_init, us_update };

/* the feature: clock page T2, blue turns */
static void us_page_turn(int knob, int delta) { if (knob == 0) usbout_turn(delta); }
static const op1_page_t us_page = { 2, "usbout.svg", &SCREEN_usbout, 0, us_page_turn };   /* empty svg: drawn in code */
static const char *const us_claims[] = { "page:t2", 0 };
const op1_feature_t FEATURE_usbout = { .api = OP1_FEATURE_API, .priority = 1000, .name = "usbout", .page = &us_page, .claims = us_claims };
