/* Saved settings of the clock pages, kept in the core (docs/feature-hooks.md "Clock pages"): the USB out page (T2)
 * and the settings page (T3) are features that may ship as files, but what they set must apply at boot whether or
 * not the page is there. Rows in the DB table op1rsettings (key, val): 'usbtracks' 0 / 1, 'countin' 0..2 (index
 * into 4 / 8 / 16 beats). Loaded here at USB start / screen load; the pages call the save functions on a change
 * (KeyHandler thread). Moved out of screens/usbout.c and screens/settings.c (op1r-src 175ca8c); rows unchanged.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_synth.h"

extern uint8_t ci_beats;                                        /* tape/countin.c */
static const uint8_t ss_beats[3] = { 4, 8, 16 };

#ifdef OP1_HOST
int usbout_host_saved, settings_host_saved = -1;
int usbout_load(void) { return usbout_host_saved; }
void usbout_save(int on) { usbout_host_saved = on; }
void countin_load(void) { if (settings_host_saved >= 0) ci_beats = ss_beats[settings_host_saved]; }
void countin_save(int idx) { settings_host_saved = idx; }
#else
#define DB_HANDLE ((void *(*)(void))0x0196DD44)
#define DB_EXEC   ((void (*)(void *, const char *))0x0196F950)
#define DB_GET    ((void (*)(void *, void *, const char *))0x0196FBD0)
typedef struct { uint32_t alloc; union { char buf[16]; char *ptr; } u; uint32_t size, cap; uint32_t pad; } ss_dstr;
static const char SS_CREATE[] = "CREATE TABLE IF NOT EXISTS op1rsettings (key TEXT PRIMARY KEY, val INTEGER NOT NULL)";
static char ss_get(const char *q)                               /* first char of the value, 0 if no row */
{
    void *db = DB_HANDLE();
    DB_EXEC(db, SS_CREATE);
    ss_dstr s = { 0 };
    DB_GET(&s, db, q);
    const char *p = s.cap > 15 ? s.u.ptr : s.u.buf;             /* (heap copy for long strings, not freed: 1 char) */
    return s.size ? p[0] : 0;
}
/* at USB start (boot, after the DB is up; also when USB restarts after disk mode): screens/usbtrack.c */
int usbout_load(void) { return ss_get("SELECT val FROM op1rsettings WHERE key='usbtracks'") == '1'; }
void usbout_save(int on)
{
    void *db = DB_HANDLE();
    DB_EXEC(db, SS_CREATE);
    DB_EXEC(db, on ? "INSERT OR REPLACE INTO op1rsettings VALUES ('usbtracks',1)"
                   : "INSERT OR REPLACE INTO op1rsettings VALUES ('usbtracks',0)");
}
void countin_load(void)                                         /* boot, screen load (dispatcher.c) */
{
    char c = ss_get("SELECT val FROM op1rsettings WHERE key='countin'");
    if (c >= '0' && c <= '2') ci_beats = ss_beats[c - '0'];
}
void countin_save(int idx)
{
    static char q[] = "INSERT OR REPLACE INTO op1rsettings VALUES ('countin',0)";
    q[sizeof q - 3] = (char)('0' + idx);
    void *db = DB_HANDLE();
    DB_EXEC(db, SS_CREATE);
    DB_EXEC(db, q);
}
#endif
