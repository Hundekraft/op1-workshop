/* Settings page (clock / card + T3, docs/25), in the style of the playmode page like the USB out page: blue
 * "COUNT-IN" with 4 / 8 / 16 beats (tape/countin.c). Blue turns through the values; saved in op1rsettings
 * (key 'countin') by the core (screens/settings_store.c), which also loads it at boot, so count-in keeps its value
 * when this page is not installed. Green, white and red are the features' on / off switches (op1_switch), in the
 * order they registered. This page is a feature
 * (plugins/settings, FEATURE_settings on clock T3). */
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "stroke_font.h"

extern uint8_t ci_beats;                                    /* core: tape/countin.c */
extern void countin_save(int idx);                          /* core: screens/settings_store.c (loads it at boot) */
static const uint8_t ci_vals[3] = { 4, 8, 16 };
static uint8_t ci_idx;                                      /* index into ci_vals */

/* feature switches (op1_switch, kennel/kn_midi.c) on green, white, red: right on, left off */
int kn_switch_count(void), kn_switch_get(int i);
const char *kn_switch_label(int i);
void kn_switch_set(int i, int on);
static int32_t acc, sw_acc[3];
static void switch_turn(int i, int delta)
{
    if ((sw_acc[i] > 0 && delta < 0) || (sw_acc[i] < 0 && delta > 0)) sw_acc[i] = 0;
    sw_acc[i] += delta;
    int st = sw_acc[i] / 1024; if (!st) return;
    sw_acc[i] = 0;
    kn_switch_set(i, st > 0);
}
void settings_turn(int knob, int delta)                     /* blue: one value per detent, clamped */
{
    if (knob >= 1 && knob <= 3) { if (knob - 1 < kn_switch_count()) switch_turn(knob - 1, delta); return; }
    if (knob != 0) return;
    if ((acc > 0 && delta < 0) || (acc < 0 && delta > 0)) acc = 0;
    acc += delta;
    int st = acc / 1024; if (!st) return;
    acc = 0;
    int v = ci_idx + (st > 0 ? 1 : -1);
    if (v < 0 || v > 2) return;
    ci_idx = (uint8_t)v; ci_beats = ci_vals[ci_idx];
    countin_save(ci_idx);
}

static const uint8_t c_blue[4] = { 0x4D, 0x9E, 0xFF, 0xFF }, c_green[4] = { 0x00, 0xED, 0x95, 0xFF },
                     c_white[4] = { 0xFF, 0xFF, 0xFF, 0xFF }, c_red[4] = { 0xFF, 0x4E, 0x3F, 0xFF };
#define ST_S   OP1_Q10(5) / 2                               /* as the USB out page: 15 px caps */
#define ST_W   0x600
#define ST_LX  OP1_Q10(24)
#define ST_VX  OP1_Q10(164)
#define ST_Y0  OP1_Q10(40)
#define ST_DY  OP1_Q10(24)

static void st_init(void *scr) { (void)scr; ci_idx = ci_beats >= 16 ? 2 : ci_beats >= 8 ? 1 : 0; }
static void st_update(void *scr, int dt)
{
    op1_screen_draw(scr, dt);
    void *r = op1_raster();
    static const char *const txt[3] = { "4", "8", "16" };
    sf_text(r, ST_LX, ST_Y0, ST_S, "COUNT-IN", ST_W, c_blue);
    sf_text(r, ST_VX, ST_Y0, ST_S, txt[ci_idx], ST_W, c_blue);
    static const uint8_t *const col[3] = { c_green, c_white, c_red };
    for (int i = 0; i < kn_switch_count() && i < 3; i++) {
        char lb[13]; const char *s = kn_switch_label(i); int n = 0;
        for (; s[n] && n < 12; n++) lb[n] = s[n] >= 'a' && s[n] <= 'z' ? (char)(s[n] - 32) : s[n];   /* stroke font: caps */
        lb[n] = 0;
        sf_text(r, ST_LX, ST_Y0 + (i + 1) * ST_DY, ST_S, lb, ST_W, col[i]);
        sf_text(r, ST_VX, ST_Y0 + (i + 1) * ST_DY, ST_S, kn_switch_get(i) ? "ON" : "OFF", ST_W, col[i]);
    }
}
const op1_screen_t SCREEN_settings = { st_init, st_update };

/* the feature: clock page T3, blue turns */
static const op1_page_t st_page = { 3, "usbout.svg", &SCREEN_settings, 0, settings_turn };   /* empty svg: drawn in code */
static const char *const st_claims[] = { "page:t3", 0 };
const op1_feature_t FEATURE_settings = { .api = OP1_FEATURE_API, .priority = 1000, .name = "settings", .page = &st_page, .claims = st_claims };
