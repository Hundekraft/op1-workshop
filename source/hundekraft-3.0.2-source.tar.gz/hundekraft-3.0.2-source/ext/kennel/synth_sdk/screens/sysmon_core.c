/* Resource monitor sources, kept in the core (docs/feature-hooks.md "Clock pages"): the monitor page (screens/sysmon.c)
 * is a feature that may ship as a file, but these two hooks are patched into R246 by make_firmware.py (IMM_PATCHES
 * 0x0191AB52: the audio DMA callback pointer; HOOKS 0x01911B98: the kTE_Idle vtable run slot), so they must be core
 * symbols. The page reads the counters through kennel/kn_exports.c. Moved out of screens/sysmon.c (op1r-src 175ca8c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_synth.h"

#ifdef OP1_HOST
extern uint32_t sm_host_cycles;
#define READ_CYCLES()            (sm_host_cycles)
#define AUDIO_CB(a, b, c)        ((void)0)
#else
static inline uint32_t READ_CYCLES(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
#define AUDIO_CB(a, b, c)        (((void (*)(void *, void *, void *))0xFFA04804)((a), (b), (c)))
#endif

volatile uint32_t sm_cy[SMC_N];
volatile uint32_t sm_aud_busy, sm_aud_max, sm_aud_last_t0, sm_aud_max_period;   /* ISR side, reset by the GUI */
extern void kn_audio_begin(void) __attribute__((weak));
extern void kn_audio_end(uint32_t used) __attribute__((weak));
extern void kn_sound_block_end(void);
void sm_audio_cb(void *a, void *b, void *c)                  /* replaces the callback pointer (audio::init) */
{
    uint32_t t0 = READ_CYCLES();
    extern void kn_input_clock(uint32_t),kn_input_end(void);
    kn_input_clock(t0);
    if (kn_audio_begin) kn_audio_begin();
    AUDIO_CB(a, b, c);
    kn_input_end();
    kn_sound_block_end();
    uint32_t d = READ_CYCLES() - t0, p = t0 - sm_aud_last_t0;
    if (kn_audio_end) kn_audio_end(d);
    sm_aud_last_t0 = t0;
    sm_aud_busy += d;
    if (d > sm_aud_max) { sm_aud_max = d; sm_aud_max_period = p; }
}

void *volatile sm_idle_obj;                                  /* kTE_Idle thread object (VDK thread) */
#ifndef OP1_HOST
void sm_idle_run(void *self)                                 /* kTE_Idle vtable run slot; never returns */
{
    sm_idle_obj = self;
    ((void (*)(void *))0x01A5E240)(self);
}
#endif

/* optional profile counters for the page's last line: weak in the core, so the pointers are 0 when absent */
#ifdef OP1_HOST
volatile uint32_t *const sm_ps_prof = 0, *const sm_dp_prof = 0;
volatile int32_t *const sm_db_err = 0;
#else
extern volatile uint32_t ps_prof[7] __attribute__((weak));   /* paulstretch phase cycles (shelved/paulstretch) */
extern volatile uint32_t dp_prof[2] __attribute__((weak));   /* drum+ voice render cycles (drumplus/dp_fw.c) */
extern int32_t op1_db_last_err __attribute__((weak));        /* last DB write error (op1_db_write) */
volatile uint32_t *const sm_ps_prof = ps_prof, *const sm_dp_prof = dp_prof;
volatile int32_t *const sm_db_err = &op1_db_last_err;
#endif
