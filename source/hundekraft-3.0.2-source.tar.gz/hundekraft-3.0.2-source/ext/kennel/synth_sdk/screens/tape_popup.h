/* The popup over the tape screen, shared by the tape switch (plugins/tapes: "TAPE 2" / "125 BPM") and undo / redo
 * (plugins/undo: "UNDO", "REDO", "BOUNCE", ...): a box centred over the reels, a red tile with a cassette on a white
 * disc, and a black panel with one or two lines of capitals; undo adds its progress under the text while a job runs.
 * Drawn with kennel's own lines and stroke font (screens/stroke_font.h), no stock Text object, from a tape `draw`
 * hook (inside R246's tape screen draw, Gfx thread).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef TAPE_POPUP_H
#define TAPE_POPUP_H
#include "stroke_font.h"

#define TPP_X0 96                                   /* box, screen units (320 x 160) */
#define TPP_Y0 38
#define TPP_X1 224
#define TPP_Y1 82
#define TPP_TILE 40                                 /* the red tile's width */
static const uint8_t tpp_red[4] = { 0xFF, 0x38, 0x5A, 255 }  /* the OP-1 red: R246's own red, as its REC dot */, tpp_white[4] = { 0xFF, 0xFF, 0xFF, 255 },
    tpp_frame[4] = { 0xD8, 0xD2, 0xC8, 255 }, tpp_black[4] = { 0x01, 0x01, 0x01, 255 },
    tpp_cream[4] = { 0xE4, 0xDD, 0xD3, 255 }, tpp_ink[4] = { 0x3A, 0x38, 0x3C, 255 },
    tpp_dark[4] = { 0x38, 0x35, 0x72, 255 };

static void tpp_ln(void *r, int x0, int y0, int x1, int y1, int32_t w, const uint8_t *c)
{
    sf_line(r, x0 << 10, y0 << 10, x1 << 10, y1 << 10, w, c);
}
/* a filled rectangle with its corners cut by k units (rounded at this size): 2-unit bands */
static void tpp_fill(void *r, int x0, int y0, int x1, int y1, int k, const uint8_t *c)
{
    for (int y = y0; y < y1; y += 2) {
        int d = y < y0 + k ? y0 + k - y : y + 2 > y1 - k ? y + 2 - (y1 - k) : 0;
        if (d > k) d = k;
        sf_line(r, (x0 + d) << 10, (y << 10) + 0x400, (x1 - d) << 10, (y << 10) + 0x400, 0xC00, c);   /* 3 units: the bands overlap */
    }
}
/* a rectangle outline with cut corners */
static void tpp_box(void *r, int x0, int y0, int x1, int y1, int k, int32_t w, const uint8_t *c)
{
    tpp_ln(r, x0 + k, y0, x1 - k, y0, w, c); tpp_ln(r, x1 - k, y0, x1, y0 + k, w, c);
    tpp_ln(r, x1, y0 + k, x1, y1 - k, w, c); tpp_ln(r, x1, y1 - k, x1 - k, y1, w, c);
    tpp_ln(r, x1 - k, y1, x0 + k, y1, w, c); tpp_ln(r, x0 + k, y1, x0, y1 - k, w, c);
    tpp_ln(r, x0, y1 - k, x0, y0 + k, w, c); tpp_ln(r, x0, y0 + k, x0 + k, y0, w, c);
}
/* a circle as 16 chords, centre and radius in Q10 */
static void tpp_circle(void *r, int32_t cx, int32_t cy, int32_t rad, int32_t w, const uint8_t *c)
{
    static const int16_t u[17][2] = { {1024, 0}, {946, 392}, {724, 724}, {392, 946}, {0, 1024}, {-392, 946}, {-724, 724},
        {-946, 392}, {-1024, 0}, {-946, -392}, {-724, -724}, {-392, -946}, {0, -1024}, {392, -946}, {724, -724},
        {946, -392}, {1024, 0} };
    for (int i = 0; i < 16; i++)
        sf_line(r, cx + ((u[i][0] * rad) >> 10), cy + ((u[i][1] * rad) >> 10), cx + ((u[i + 1][0] * rad) >> 10),
                cy + ((u[i + 1][1] * rad) >> 10), w, c);
}
/* text width in Q10 at scale s (sf_text's advances) */
static int32_t tpp_width(const char *t, int32_t s)
{
    int32_t x = 0;
    for (; *t; t++) x += (*t == '1' || *t == '.' ? 4 : 6) * s;
    return x - 2 * s;                               /* no gap after the last char */
}
/* l2 may be 0 (one line, larger); total > 1 draws the progress (done of total) */
static void tape_popup(void *r, const char *l1, const char *l2, int done, int total)
{
    tpp_fill(r, TPP_X0, TPP_Y0, TPP_X1, TPP_Y1, 4, tpp_black);                       /* clear, then the frame */
    tpp_box(r, TPP_X0, TPP_Y0, TPP_X1, TPP_Y1, 4, 0xA00, tpp_frame);
    int tx0 = TPP_X0 + 4, tx1 = TPP_X0 + TPP_TILE, ty0 = TPP_Y0 + 4, ty1 = TPP_Y1 - 4;
    tpp_fill(r, tx0, ty0, tx1, ty1, 3, tpp_red);                                      /* the tile */
    int32_t cx = (tx0 + tx1) << 9, cy = (ty0 + ty1) << 9;
    for (int32_t k = 0x300; k < 13 << 10; k += 0x300) tpp_circle(r, cx, cy, k, 0x800, tpp_cream);   /* the disc */
    tpp_circle(r, cx - (5 << 10), cy, 3 << 10, 0x600, tpp_ink);                       /* the cassette: two reels on */
    tpp_circle(r, cx + (5 << 10), cy, 3 << 10, 0x600, tpp_ink);                       /* their tape */
    sf_line(r, cx - (5 << 10), cy + (3 << 10), cx + (5 << 10), cy + (3 << 10), 0x600, tpp_ink);
    int px0 = tx1 + 4, px1 = TPP_X1 - 4;                                              /* the text panel */
    tpp_box(r, px0, ty0, px1, ty1, 3, 0x600, tpp_frame);
    int32_t pmid = ((px0 + px1) << 10) >> 1, s = l2 ? 1536 : 1792;                    /* 9 or 10.5 units high */
    if (l2) {
        sf_text(r, pmid - (tpp_width(l1, s) >> 1), (ty0 + 7) << 10, s, l1, 0x500, tpp_white);
        sf_text(r, pmid - (tpp_width(l2, s) >> 1), (ty0 + 20) << 10, s, l2, 0x500, tpp_white);
    } else {
        sf_text(r, pmid - (tpp_width(l1, s) >> 1), (ty0 + 13) << 10, s, l1, 0x500, tpp_white);
    }
    if (total > 1) {                                                                  /* progress: dark, white part done */
        int32_t by = (ty1 - 6) << 10, bx0 = (px0 + 8) << 10, bx1 = (px1 - 8) << 10;
        sf_line(r, bx0, by, bx1, by, 0x800, tpp_dark);
        sf_line(r, bx0, by, bx0 + (bx1 - bx0) * (done > total ? total : done) / total, by, 0x800, tpp_white);
    }
}
#endif
