/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission. */
#include "op1_plugin.h"
#include "father_dsp.h"
_Static_assert(sizeof(mw_state)<=OP1_FX_SCRATCH_BYTES,"Father scratch overflow");
volatile uint32_t father_blocks[3];
volatile int16_t father_live[3][4];
volatile int32_t father_peak[3];
volatile int16_t father_gate[3];
static int16_t raw_params[3][4];
static int32_t normalized[3][4];
static uint8_t params_valid[3];
static mw_state *state(int p){return (mw_state *)op1_fx_scratch(p);}
static void init(int p){mw_state *s=state(p);if(s)mw_init(s);params_valid[p]=0;}
static void stereo(int p,int16_t *l,int16_t *r,const int16_t *params){
 mw_state *s=state(p);if(!s)return;int32_t q[4];
 /* Range conversion divides; cache each unchanged word, including master FX.
    LFO/encoder changes still normalize on their first affected callback. */
 for(unsigned i=0;i<4;i++){
  if(!params_valid[p]||raw_params[p][i]!=params[i]){
   raw_params[p][i]=params[i];normalized[p][i]=op1_fx_param_q15(params,i);
  }
  father_live[p][i]=(int16_t)(q[i]=normalized[p][i]);
 }
 params_valid[p]=1;
 mw_process(s,l,r,q);father_peak[p]=s->peak;father_gate[p]=(int16_t)s->gate_gain;father_blocks[p]++;
}
static void mono(int p,int16_t *b,const int16_t *q){stereo(p,b,0,q);}
const op1_fx_stereo_t FX_father={{init,mono,{0,0,0,0}},stereo};
