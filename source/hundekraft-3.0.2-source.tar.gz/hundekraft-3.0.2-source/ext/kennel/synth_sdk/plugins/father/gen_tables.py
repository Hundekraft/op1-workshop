#!/usr/bin/env python3
# Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""Generate original per-line feedback gains; no firmware inputs."""
from pathlib import Path
import math
P=Path(__file__).resolve().parent
lengths=(641,887,1153,1429,1867,2131,2683,3163)
rows=[]
for index in range(129):
    rt60=.35+7.65*(index/128)**2
    rows.append([round(32768*math.exp(-math.log(1000)*n/(22050*rt60))) for n in lengths])
text='''/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission. */
/* Generated analytically: g=10^(-3*delay/(22050*RT60)), RT60=.35+7.65*(index/128)^2 seconds. */
static const int16_t mw_decay[129][8]={
'''+''.join('{'+','.join(map(str,row))+'},\n' for row in rows)+'};\n'
(P/'father_tables.h').write_text(text)
