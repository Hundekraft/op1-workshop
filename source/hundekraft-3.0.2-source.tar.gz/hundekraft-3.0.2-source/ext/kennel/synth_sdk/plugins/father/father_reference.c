/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission. */
/* Frozen pre-optimization 3.0 voicing: differential reference, not production. */
#include "father_dsp.h"
#include "father_tables.h"
_Static_assert(641-8>64,"Father block schedule requires taps older than one callback");
static const unsigned delays[8]={641,887,1153,1429,1867,2131,2683,3163};
static int32_t sat(int32_t v){return v>32767?32767:v< -32768?-32768:v;}
/* Round toward zero: silence cannot sustain a negative one-LSB limit cycle. */
static int32_t mul(int32_t a,int32_t b){int32_t v=a*b;return (v+((v>>31)&32767))>>15;}
void mw_ref_init(mw_state *s){
 uint8_t *p=(uint8_t *)s;for(unsigned i=0;i<sizeof *s;i++)p[i]=0;
 s->mix=-1;s->pre_samples=-1;s->gate_gain=32767;
 for(unsigned i=0;i<8;i++)s->phase[i]=0x9E3779B9u*(i+1u);
}
static int32_t half(int32_t v){return (v+(int32_t)((uint32_t)v>>31))>>1;}
static void diffuse_block(int16_t ring[1024],unsigned start,unsigned delay,int32_t samples[64]){
 for(unsigned n=0;n<64;n++){
  unsigned h=(start+n)&1023;int32_t d=ring[(h-delay)&1023];
  int32_t v=sat(samples[n]-half(d));ring[h]=(int16_t)v;
  samples[n]=sat(d+half(v));
 }
}
static __attribute__((noinline)) void tank_read(int16_t *tank,int32_t *output,uint32_t *phasep,int32_t *dampp,unsigned start,unsigned delay_base,int32_t depth,uint32_t speed,int32_t damping){
  uint32_t phase=*phasep;int32_t damp=*dampp;
  /* Slow independent delay motion is evaluated at eight-sample endpoints
     and interpolated; the damping and feedback still run at the full rate. */
  for(unsigned group=0;group<64;group+=8){
   uint32_t ph=phase+speed;
   int32_t tri0=(int32_t)(((ph>>15)^(0u-(ph>>31)))&65535)-32768;
   ph+=speed*8;
   int32_t tri8=(int32_t)(((ph>>15)^(0u-(ph>>31)))&65535)-32768;
   int32_t mod0=mul(tri0,depth),mod8=mul(tri8,depth);
   int32_t delay_acc=((int32_t)(delay_base*256)+mod0)*8;
   int32_t delta=mod8-mod0;
   for(unsigned j=0;j<8;j++){
    unsigned n=group+j,h=(start+n)&4095,delay=(unsigned)(delay_acc>>3);
    unsigned rd=(h-(delay>>8))&4095;int32_t v=tank[rd];
    v+=((tank[(rd-1)&4095]-v)*(int32_t)(delay&255))>>8;
    damp=v+mul(damp-v,32768-damping);output[n]=damp;
    delay_acc+=delta;
   }
   phase+=speed*8;
  }
  *phasep=phase;*dampp=damp;
}
void mw_ref_process(mw_state *s,int16_t *l,int16_t *r,const int32_t q[4]){
 unsigned ix=((unsigned)q[0]*128+16383)>>15;if(ix>128)ix=128;
 int32_t damping=1800+mul(q[2],20000),target_pre=mul(q[0],662);
 /* Green shapes duration, not detection level. Thresholds stay low and use
    hysteresis. Detector work is once per block, even while Gate is off, so
    enabling it does not mistake an existing tail for a new input event. */
 const int gated=q[1]!=0;
 int32_t free=32767-q[1];
 const uint32_t hold_samples=1764u+(uint32_t)mul(mul(free,free),37926);
 const int32_t close_rate=64+mul(q[1],192); /* ~160..40ms to -60dB */
 int32_t target_mix=q[3];if(s->mix<0)s->mix=target_mix;
 if(s->pre_samples<0)s->pre_samples=target_pre;
 /* Slew predelay by one sample per callback; coefficient changes stay bounded. */
 if(s->pre_samples<target_pre)s->pre_samples++;else if(s->pre_samples>target_pre)s->pre_samples--;
 int32_t mix=s->mix*64,step=target_mix-s->mix;s->peak=0;
 /* Every tank delay exceeds a callback: all reads precede this block's writes.
    Line-major reads keep the phase and damping recurrence in registers, instead
    of spilling eight independent recurrences in a large unrolled sample loop. */
 int32_t (*block)[64]=s->block,*left=s->left,*right=s->right;unsigned start=s->head;
 int32_t input_peak=0;
 for(unsigned n=0;n<64;n++){
  unsigned h=(start+n)&4095;int32_t a=l[n],b=r?r[n]:a;
  s->pre[0][h]=(int16_t)a;s->pre[1][h]=(int16_t)b;
  int32_t pa=a<0?-a:a,pb=b<0?-b:b;
  if(pa>input_peak)input_peak=pa;if(pb>input_peak)input_peak=pb;
 }
 /* Hold follows dry activity; onset/retrigger requires a low-level crossing
    or a clear new attack. Quiet fluctuations cannot chatter between states. */
 int32_t previous_env=s->gate_env;int was_active=s->gate_active;
 if(input_peak>s->gate_env)s->gate_env=input_peak;
 else s->gate_env-=(s->gate_env+3)>>2;
 if(!s->gate_active && s->gate_env>=32)s->gate_active=1;
 else if(s->gate_active && s->gate_env<=16)s->gate_active=0;
 int onset=(!was_active && s->gate_active) ||
           (input_peak>=32 && input_peak>previous_env+(previous_env>>1)+32);
 if(!gated){s->gate_enabled=0;s->gate_armed=0;s->gate_hold=0;}
 else {
  if(!s->gate_enabled){s->gate_enabled=1;s->gate_armed=0;s->gate_hold=0;}
  if(onset)s->gate_armed=1;
  if(s->gate_armed){
   if(s->gate_active)s->gate_hold=hold_samples+(unsigned)s->pre_samples;
   else s->gate_hold=s->gate_hold>64?s->gate_hold-64:0;
  }
 }
 const int32_t gate_target=(!gated || !s->gate_armed || s->gate_hold)?32767:0;
 const int apply_gate=gate_target!=32767 || s->gate_gain!=32767;
 for(unsigned n=0;n<64;n++){
  unsigned ph=(start+n-(unsigned)s->pre_samples)&4095;
  left[n]=s->pre[0][ph];right[n]=s->pre[1][ph];
 }
 diffuse_block(s->diff[0][0],start,227,left);diffuse_block(s->diff[0][1],start,541,left);
 diffuse_block(s->diff[1][0],start,337,right);diffuse_block(s->diff[1][1],start,719,right);
 s->head+=64;
 for(unsigned i=0;i<8;i++)
  tank_read(s->tank[i],block[i],s->phase+i,s->damp+i,start,delays[i],1024+(int32_t)i*73,17000u+i*2473u,damping);
 for(unsigned n=0;n<64;n++){
  int32_t a=l[n],b=r?r[n]:a;
  if(apply_gate){
   if(gate_target>s->gate_gain)s->gate_gain+=(32767-s->gate_gain+31)>>5;
   else if(gate_target<s->gate_gain)s->gate_gain-=(s->gate_gain*close_rate+32767)>>15;
  }
  int32_t d0=block[0][n],d1=block[1][n],d2=block[2][n],d3=block[3][n];
  int32_t d4=block[4][n],d5=block[5][n],d6=block[6][n],d7=block[7][n];
  /* Two normalized four-way Hadamard butterflies, interleaved at the
     destinations: every line reaches all eight paths within two passes.
     Unlike I-J/4, no feedback path has a dominant 3/4 self coefficient.
     This orthogonal scattering uses only additions and halves. */
  int32_t a0=d0+d1,a1=d0-d1,a2=d2+d3,a3=d2-d3;
  int32_t b0=d4+d5,b1=d4-d5,b2=d6+d7,b3=d6-d7;
  block[0][n]=half(a0+a2);block[2][n]=half(a1+a3);
  block[4][n]=half(a0-a2);block[6][n]=half(a1-a3);
  block[1][n]=half(b0+b2);block[3][n]=half(b1+b3);
  block[5][n]=half(b0-b2);block[7][n]=half(b1-b3);
  /* Early returns bridge the dry transient into the late network. All taps
     exceed one block and reuse the input predelay rings (no new delay storage).
     Unequal L/R spacing and a quiet inverted tap avoid a single slap echo.
     Absolute tap gains sum to 1/2 per channel before the Color lowpass. */
  unsigned eh=start+n-(unsigned)s->pre_samples;
  int32_t el=(s->pre[0][(eh-149)&4095]>>2)+(s->pre[1][(eh-263)&4095]>>3)
             -(s->pre[0][(eh-421)&4095]>>4)+(s->pre[1][(eh-631)&4095]>>4);
  int32_t er=(s->pre[1][(eh-173)&4095]>>2)+(s->pre[0][(eh-307)&4095]>>3)
             -(s->pre[1][(eh-487)&4095]>>4)+(s->pre[0][(eh-733)&4095]>>4);
  s->early[0]+=mul(el-s->early[0],damping);
  s->early[1]+=mul(er-s->early[1],damping);
  /* Retain a stronger return than the original voicing (+3.5dB), but leave
     more output headroom than the prior +6dB revision for the denser tail. */
  int32_t tl=d0+d2-d4-d6,tr=d1+d3-d5-d7;
  int32_t wl=sat(half(tl+half(tl))+s->early[0]),wr=sat(half(tr+half(tr))+s->early[1]);
  if(apply_gate){wl=mul(wl,s->gate_gain);wr=mul(wr,s->gate_gain);}
  mix+=step;int32_t wet=mix>>6;
  int32_t out_l=sat(a+mul(wl-a,wet));
  int32_t out_r=sat(b+mul(wr-b,wet));
  l[n]=(int16_t)out_l;if(r)r[n]=(int16_t)out_r;
  int32_t pk=out_l<0?-out_l:out_l;if(pk>s->peak)s->peak=pk;
  pk=out_r<0?-out_r:out_r;if(pk>s->peak)s->peak=pk;
 }
 /* The reads above are complete before any current-block tank write. */
 for(unsigned i=0;i<8;i++){
  int32_t gain=mw_decay[ix][i];int32_t *input=(i&1)?right:left;
  for(unsigned n=0;n<64;n++){
   int32_t in=input[n];if(i&2)in=-in;
   int32_t feedback=mul(sat(block[i][n]),gain);
   s->tank[i][(start+n)&4095]=(int16_t)sat(feedback+(in>>2));
  }
 }
 s->mix=target_mix;
}
