/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission. */
#ifndef FATHER_DSP_H
#define FATHER_DSP_H
#include <stdint.h>
#define MW_LINES 8
#define MW_RING 4096
#define MW_TANK_STRIDE (MW_RING+16)
typedef struct {
 /* One cache line of padding separates the otherwise aliased tank heads. */
 int16_t tank[8][MW_TANK_STRIDE],pre[2][4096],diff[2][2][1024];
 uint32_t head,phase[8];
 int32_t damp[8],mix,pre_samples,peak;
 int32_t gate_env,gate_gain;
 int32_t early[2]; /* color-filtered early reflections, per output channel */
 uint32_t gate_hold;
 uint8_t gate_enabled,gate_active,gate_armed;
 /* Callback workspace lives in the existing per-instance FX scratch, not ISR stack. */
 int32_t block[8][64],left[64],right[64];
} mw_state;
void mw_init(mw_state *s);
void mw_process(mw_state *s,int16_t *l,int16_t *r,const int32_t q[4]);
#endif
