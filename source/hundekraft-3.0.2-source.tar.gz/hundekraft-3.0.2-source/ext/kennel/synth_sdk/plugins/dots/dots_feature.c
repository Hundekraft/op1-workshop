/* dots as a sequencer-type feature (op1_feature_seq.h): the source lives in seq/dots.c; this folder makes it a
 * plugin (compiled in, or content/dots.knl when "loadable").
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../seq/dots.c"
#include "../../op1_feature_seq.h"

static int dt_key_ev(int mode, int code, int pressed, int shift)
{
    if (code >= 0x0A && code <= 0x0C) {                         /* lift / drop / scissors (Shift: whole pattern) */
        if (pressed) dt_clip(mode, code == 0x0A ? 0 : code == 0x0B ? 1 : 2, shift);
        return 1;
    }
    if (code == 0x21) { if (pressed) dt_rec_key(mode); return 1; }   /* REC: step / live record (tape REC not armed) */
    return 0;
}
static void dt_press_ev(int mode, int knob, int shift) { (void)shift; dt_press(mode, knob); }   /* red: REC / LIVE */
static void dt_turn_ev(int mode, int knob, int delta, int shift)
{
    if (knob == 2 && shift) dt_select(mode, delta);
    else dt_turn(mode, knob, delta, shift);                     /* blue, green / white (record mode), red */
}
static const op1_seq_type_t dt_type = {
    .name = "dots", .player = dt_player_get, .svg = "dots.svg", .screen = &SCREEN_dots,
    .key = dt_key_ev, .press = dt_press_ev, .turn = dt_turn_ev, .shift_wants = dt_shift_wants, .midi_start = dt_midi_start };
const op1_feature_t FEATURE_dots = { .api = OP1_FEATURE_API, .priority = 1000, .name = "dots", .seq = &dt_type };
