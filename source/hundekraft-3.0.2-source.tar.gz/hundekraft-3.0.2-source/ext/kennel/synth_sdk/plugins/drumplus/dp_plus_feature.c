/* drum+ as a feature plugin (kind 3, drum type): the source lives in drumplus/dp_plus.c; this folder makes it a plugin.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../drumplus/dp_plus.c"
