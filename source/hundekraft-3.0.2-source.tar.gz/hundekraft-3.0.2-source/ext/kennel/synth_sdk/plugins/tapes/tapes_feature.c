/* four tapes as a feature plugin (kind 3): the source lives in tapes/tapes.c; this folder makes it a plugin. The
 * switching itself is a core service (kennel/kn_tapes.c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../tapes/tapes.c"
