/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* "taffy": phase distortion in the style of Casio's CZ synths. A cosine is read through a bent phase: the
 * further the phase is bent, the brighter the wave, with no filter involved.
 * blue   (knob 0): wave, morphing saw -> square -> pulse -> saw-pulse (the CZ shapes, each bent its own way)
 * green  (knob 1): distortion (DCW): 0 = pure cosine, full = the bright end of the shape
 * white  (knob 2): envelope depth: how much extra distortion each note starts with, falling over ~0.2 s
 * red    (knob 3): resonance: mixes in the CZ resonant wave (a sine at 1..16x, windowed by a falling ramp),
 *                  its frequency following the distortion
 * Follows note velocity. Int-only; per sample: 2 bent phases, 3 interpolated cosine reads, a few multiplies.
 */
#include "hk/engine.h"
#include "taffy_tables.h"

typedef struct {
    uint32_t ph;
    int32_t env;   /* Q15, 32767 at note on */
    int32_t wave, dcw, resonance;
    int control_ready;
    int32_t dc_q10; /* per-voice mean estimate, before native voice mixing */
} voice_t;

static voice_t voices[ENGINE_VOICES];
volatile uint32_t taffy_blocks;   /* rendered blocks, the screen moves while this counts */
volatile int32_t taffy_dcw;       /* last distortion (Q15) and envelope, for the screen */
volatile int32_t taffy_env;

/* cosine of a Q15 phase (32768 = one turn) */
static inline int32_t cosq(int32_t p)
{
    p &= 0x7FFF;
    const int32_t i = p >> 5, f = (p & 31) << 10;
    const int32_t a = tf_cos[i];
    return a + (((tf_cos[i + 1] - a) * f) >> 15);
}

/* the CZ bend: phase x (Q15) reaches half a turn at d, the rest of the turn over the remainder;
   inv1 = 16384 * 32768 / d, inv2 = 16384 * 32768 / (32768 - d) */
static inline int32_t bend(int32_t x, int32_t d, int32_t inv1, int32_t inv2)
{
    return x < d ? (x * inv1) >> 15 : 16384 + (((x - d) * inv2) >> 15);
}

/* shape s at phase x, bend point d (16384 = no bend) */
static inline int32_t shape(int s, int32_t x, int32_t d, int32_t inv1, int32_t inv2)
{
    switch (s) {
    case 0:   /* saw: one bend per turn */
        return cosq(bend(x, d, inv1, inv2));
    case 1: { /* square: each half falls (rises) quickly, then holds */
        const int32_t h = x >> 14, xl = (x << 1) & 0x7FFF;
        const int32_t w = xl < 2 * d ? (xl * inv1) >> 16 : 16384;   /* xl / (2d) of half a turn */
        return cosq((h << 14) + w);
    }
    case 2: { /* pulse: a full cosine squeezed into the first 2d of the turn, then held */
        return x < 2 * d ? cosq((x * inv1) >> 15) : 32767;
    }
    default:  /* saw-pulse: a bent turn in the first half, held for the second */
        return x < 16384 ? cosq(bend(x << 1, d, inv1, inv2)) : 32767;
    }
}

/* everything that depends on the knobs, once per block */
typedef struct {
    int sa, sb;
    int32_t frac, d, inv1, inv2, rr, k3;
} setup_t;

static inline void setup(setup_t *p, int32_t k0, int32_t dcw, int32_t k3)
{
    p->d = 16384 - ((dcw * 15872) >> 15);                    /* 0.5 .. 1/64 of a turn */
    p->inv1 = (16384 << 15) / p->d;
    p->inv2 = (16384 << 15) / (32768 - p->d);
    const int32_t pos = k0 * 3;                              /* shape index in the high bits, Q15 fraction */
    p->sa = pos >> 15;
    p->sb = p->sa + (p->sa < 3);
    p->frac = pos & 0x7FFF;
    p->rr = 256 + ((dcw * 3840) >> 15);                      /* resonance ratio, Q8, 1..16 */
    p->k3 = k3;
}

static inline int32_t sample(const setup_t *p, int32_t x)
{
    const int32_t a = shape(p->sa, x, p->d, p->inv1, p->inv2);
    int32_t y = a + (((shape(p->sb, x, p->d, p->inv1, p->inv2) - a) * p->frac) >> 15);
    /* resonance: sine at rr times the pitch, windowed by a ramp falling over the turn */
    const int32_t reso = (cosq(((x * p->rr) >> 8) - 8192) * (32767 - x)) >> 15;
    return y + (((reso - y) * p->k3) >> 15);
}

/* one point of the wave at phase x (Q15), for the screen */
int32_t taffy_wave_at(int32_t k0, int32_t dcw, int32_t k3, int32_t x)
{
    setup_t p;
    setup(&p, k0, dcw, k3);
    return sample(&p, x & 0x7FFF);
}

void engine_note_on(void *self, const int16_t *knobs)
{
    voice_t *v = &voices[ENGINE_VOICE(self)];
    (void)knobs;
    v->control_ready = 0;
    v->ph = 0;
    v->dc_q10 = 0;
    v->env = 32767;
}

void engine_note_off(void *self, const int16_t *knobs)
{
    (void)self;
    (void)knobs;
}

/* the knobs as this block hears them (after the slot LFO), for the screen */
volatile int16_t taffy_knobs[4];

void engine_render(void *self, int16_t *out, const int16_t *knobs)
{
    for (int i = 0; i < 4; i++) taffy_knobs[i] = knobs[i];
    const int vi = ENGINE_VOICE(self);
    voice_t *v = &voices[vi];
    int vel = ENGINE_VELOCITY(vi);
    if (vel < 1 || vel > 127) vel = 100;
    const int32_t k0 = knobs[0] < 0 ? 0 : knobs[0];
    const int32_t k1 = knobs[1] < 0 ? 0 : knobs[1];
    const int32_t k2 = knobs[2] < 0 ? 0 : knobs[2];
    const int32_t k3 = knobs[3] < 0 ? 0 : knobs[3];

    int32_t dcw = k1 + ((k2 * v->env) >> 15);
    if (dcw > 32767) dcw = 32767;
    v->env -= v->env >> 6;                                  /* ~0.19 s time constant */
    setup_t p, previous = {0};
    setup(&p, k0, dcw, k3);
    int changing = v->control_ready && (v->wave != k0 || v->dcw != dcw || v->resonance != k3);
    if (changing) setup(&previous, v->wave, v->dcw, v->resonance);
    v->wave = k0;
    v->dcw = dcw;
    v->resonance = k3;
    v->control_ready = 1;
    const int32_t gain = (13000 * vel) >> 7;                 /* Q15 output gain with velocity; TE's voice level, so
                                                                chords stay under the voice-sum bus's rail */

    uint32_t ph = v->ph;
    int32_t dc_q10 = v->dc_q10;
    for (int i = 0; i < ENGINE_BLOCK; i++) {
        ph += ENGINE_PITCH[i];
        const int32_t x = (int32_t)(ph >> 17);
        int32_t y = sample(&p, x);
        if (changing) {
            /* Crossfade complete phase shapes: interpolating bend reciprocals independently
             * creates a discontinuity where the two phase segments meet. Only changing blocks
             * take the second evaluation; phase and envelope state continue uninterrupted. */
            const int32_t before = sample(&previous, x);
            y = before + (((y - before) * i) >> 7);
        }
        /* ~6.86Hz DC rejection at44.1kHz, before gain/voice summing. Q10
         * estimate avoids a coarse integer dead band. No division or 64-bit
         * sample operations; |y-mean| <=65535 keeps the gain product safe. */
        dc_q10 += (y * 1024 - dc_q10) >> 10;
        y -= dc_q10 >> 10;
        out[i] = engine_sat16((y * gain) >> 15);
    }
    v->ph = ph;
    v->dc_q10 = dc_q10;
    taffy_blocks++;
    taffy_dcw = dcw;
    taffy_env = v->env;
}
