/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* The taffy puller screen (taffy.svg, docs/design/engine-screens/round5/build_round5.py) in motion. iter's draw
 * turns the hidden bar0..bar3; on top (screen px):
 *   ribbon   the drawn ribbon is hidden; the live wave (two turns: the knobs' shape, distortion with the note's
 *            envelope, resonance) is drawn as a 3 px blue band between the rollers, x 77.8..236.6 about y 80.8
 *   roll0/1  the green rollers turn while notes play, opposite ways, faster with more distortion
 *   spring   the red spring's coils are 35 .. 120 % tall with the resonance, about its axis (160, 31), and
 *            bounce while notes play
 *   spark    flashes at each note's start (the envelope) when the resonance is up
 *   crank    the white crank on the right roller turns 300 degrees with the envelope depth, about (257.3, 74.5)
 */
#ifndef ENGINE_HOST_TEST
#include "hk/engine.h"

int32_t taffy_wave_at(int32_t k0, int32_t dcw, int32_t k3, int32_t x);
extern volatile uint32_t taffy_blocks;
extern volatile int32_t taffy_dcw, taffy_env;
extern volatile int16_t taffy_knobs[4];

#define PX(v) ((int32_t)(v) << 10)
#define ONE 1024
#define Q(v) ((int32_t)((v) * 1024))   /* screen px -> Q10 */

static void *e_ribbon, *e_roll[2], *e_spring, *e_spark, *e_crank;
static uint32_t last_blocks, roll, bounce;
static int32_t act;
/* a knob as the voices hear it (after the slot LFO) while notes play, else as set */
#define K(i) screen_knob_live(taffy_knobs, (i), act > 64)

static const uint8_t blue[4] = {0x69, 0x8E, 0xFF, 0xFF};

void engine_screen_load(void *screen)
{
    e_ribbon = SVG_FIND(screen, "ribbon");
    e_roll[0] = SVG_FIND(screen, "roll0");
    e_roll[1] = SVG_FIND(screen, "roll1");
    e_spring = SVG_FIND(screen, "spring");
    e_spark = SVG_FIND(screen, "spark");
    e_crank = SVG_FIND(screen, "crank");
}

void engine_screen_animate(void *screen)
{
    (void)screen;
    const uint32_t blocks = taffy_blocks;
    const int on = blocks != last_blocks;
    last_blocks = blocks;
    act += ((on ? ONE : 0) - act) >> 3;

    /* rollers: up to ~1/40 turn per frame with full distortion */
    roll += (uint32_t)(((60 + (taffy_dcw >> 7)) * act) >> 10);
    svg_turn(e_roll[0], roll, Q(62.67), Q(72.21));
    svg_turn(e_roll[1], -roll, Q(257.33), Q(72.21));

    /* spring: 35 .. 120 % with the resonance, plus a bounce of up to 6 % while playing */
    bounce += (uint32_t)((300 * act) >> 10);
    svg_scale(e_spring, ONE, 358 + ((K(3) * 870) >> 15) + ((SVG_SIN(bounce) * act) >> 19), 0, Q(31.01));
    svg_move(e_spark, 0, on && taffy_env > 9000 && K(3) > 8192 ? 0 : PX(400));

    /* crank: -40 .. 260 degrees (8192 per turn) over the envelope knob about the roller hub */
    svg_turn(e_crank, (uint32_t)(((K(2) * 6827) >> 15) - 910), Q(257.33), Q(74.48));
    svg_move(e_ribbon, 0, PX(400));
}

static void line(void *canvas, int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    const svg_pt a = {x0, y0}, b = {x1, y1};
    SVG_LINE(canvas, &a, &b, 0xC00, blue);                 /* 3 px */
}

void engine_screen_draw(void *screen, void *canvas)
{
    (void)screen;
    if (!canvas) return;
    /* the ribbon: one 3 px band over x 77.8..236.6, centre y 80.8, +-15 px, tied to the rollers at both ends;
       distortion as the voices hear it, else the knob alone. 128 points over the two turns: at full resonance
       the wave has 16 cycles a turn, and fewer points alias it (64 land on its zero crossings: a flat line) */
    const int32_t dcw = act > 64 ? taffy_dcw : K(1);
    const int32_t k0 = K(0), k3 = K(3);
    enum { N = 128 };
    int32_t px = Q(72.11), py = Q(58.2);
    for (int i = 0; i <= N; i++) {
        const int32_t x = Q(77.78) + i * (Q(236.55) - Q(77.78)) / N;
        const int32_t y = Q(80.76) - (taffy_wave_at(k0, dcw, k3, (i * 65536 / N)) * 15 >> 5);
        line(canvas, px, py, x, y);
        px = x;
        py = y;
    }
    line(canvas, px, py, Q(248.26), Q(58.2));
}
#endif
