# in a room — "I am sitting in a room" (FX)

In 1969/70 Alvin Lucier recorded himself reading a short text, played the tape back into the room, and recorded
that playback. He then played the new recording back into the room and recorded it again, and kept going.
Each pass reinforced the room's resonant frequencies and wore away everything else. After about thirty
generations the words were gone and only the room's chord was left.

`in a room` does the same on a loop. Press orange and it records the input (generation 0). After that, every pass
of the loop plays the recording through a room model, normalises it, and writes it back in place. You hear
the loop. The counter shows how many times the recording has gone through the room. The loop can be free
(seconds) or locked to the OP-1 tempo (1/16 note up to 2 bars), so the melting loop stays on the beat.

The FX list shows it as **in a room**. The source folder, the C symbols (`FX_sitting`, `SCREEN_sitting`) and
`"order": 7` keep the old name, so sounds saved with the old FX still pick the same effect (see "Name" below).

## Knobs

| knob | page 1 | page 2 (press) |
|---|---|---|
| blue | **SIZE**: longest wall 0.8–8 m (log); 6.1 m at 88 % | **LOOP**: length of the next capture. First 40 %: FREE 0.5–3.9 s. Then 6 synced lengths: 1/16, 1/8, 1/4 (1 beat), 1/2 (2 beats), 1 BAR, 2 BARS (4/4) |
| green | **SHAPE**: CUBE 1:1:1, GOLDEN 2.618:1.618:1, BOLT 1.59:1.26:1, LUCIER 6.1 × 4.3 × 2.6 m | **ABSORB**: high-frequency loss per generation (none to a ~1.3 kHz one-pole) |
| white | **ERODE**: how hard each pass is filtered (resonator Q 8–80, room share 12–100 %; the rest is direct sound plus early reflections) | – |
| orange | **MIX**: dry to wet (wet = the loop) | press = **LATCH**: each toggle starts a new capture; with a synced length it **arms** it (press again to cancel) |

The "Lucier" dimensions (20' × 14' × 8.5') are a plausible guess for his Middletown living room. They were not
measured. Before the first capture the wet signal is silence, and the dirty scratch buffer is never played.
The page-2 LOOP default is FREE 2.6 s.

## Tempo sync

- **Arming.** With a synced length selected, an orange press arms the capture. The old loop keeps playing (or
  silence before the first capture). The capture starts on the next grid point that fits the length:
  - 1/16 starts on any 1/16 note.
  - 1/8 starts on an 1/8 note.
  - 1/4 starts on a beat.
  - 1/2 starts on beat 1 or 3.
  - 1 BAR and 2 BARS start on beat 1.

  The screen shows ARMED (blinking) and a blinking dot next to MIX.
- **Exact length.** The capture stops exactly the chosen number of 1/16 grid points later, at the output sample
  of the grid point. From then on every generation starts on the grid point that follows. The loop length
  follows the clock to the sample (44.1 kHz) and never drifts. At 97 BPM, 1 beat is 27278.35 samples, so
  generations alternate between 27278 and 27279 samples, and every start is within 1 sample of the ideal time.
- **The clock.** It is the stock metronome's beat clock, read once per block through `op1_beat_clock()`
  (`op1_plugin.h`). This clock exists whether or not the click is on. It runs at the OP-1 tempo (BPM setting or
  MIDI clock), restarts on a beat when the tape starts, and moves with the tape speed while the metronome follows
  the tape. It is the same clock the count-in and the bar accent use.

  The op1r sequencers (euclid, dots, oracle, peal) take their tempo from the same OP-1 tempo (player ticks, 96 per
  beat). However, each one counts its steps from where it was started, through a private counter that only
  advances while it is the current mode's player. So there is no shared step phase to lock to. The metronome clock
  is the OP-1's only global beat phase.
- **Bars.** While the clock follows the tape, beat 1 comes from the tape position (beat number = round(tape
  position / beat), a bar line every 4 beats, the same rule as the accent click). Otherwise, the first synced
  capture defines beat 1, and later captures keep that bar grid.
- **Stopped tape.** If the clock follows the tape and the tape is stopped, the clock stands still. A copy of it
  then runs on at the tempo, so arming and looping keep working. When the tape plays again, the loop follows the
  tape's clock.
- **Tape speed.** At a different tape speed the clock runs at that speed, and the loop follows it (at half speed,
  a 1/4 loop lasts 44100 samples).
- **Long loops.** A loop that does not fit in 3.9 s at 22.05 kHz is recorded at **11.025 kHz** (7.8 s, more
  lo-fi; the screen shows 11K). At 120 BPM, 2 BARS (4 s) needs 11.025 kHz. 1 BAR fits at 22.05 kHz down to
  65 BPM, and 2 BARS down to 33 BPM at 11.025 kHz. A length that does not fit even then is halved (LOOP page shows
  `LONG`), for example 2 BARS at 50 BPM runs as 1 BAR.
- **Tempo changes while a loop plays.** The loop keeps its recorded material and stays on the grid. Each
  generation still starts on the counted grid point.
  - If the tempo gets faster, the end of each pass is cut. A 256-sample de-click covers the step.
  - If the tempo gets slower, the material runs out before the next grid point. It fades out over about 1.5 ms,
    then there is silence until the grid point.
  - Re-capture (two presses) to fit the new tempo.

  A jump of the clock (tape relocation, MIDI START) can lengthen or shorten one generation by the jump.
- **Fades.** A free capture fades 10 ms at both ends, as before. A synced capture fades only 1.5 ms, which keeps
  the downbeat's attack.

## How it works

- **Loop.** Up to 86016 int16 samples in the FX scratch buffer, plus a 2048-sample early-reflection line (176128
  of 176460 bytes).
  - 22.05 kHz: capture uses a [1 3 3 1]/8 decimator, and playback uses linear 2× upsampling.
  - 11.025 kHz: the same decimator twice, and linear 4× upsampling.

  The room coefficients (SVF frequencies, reflection taps, DC blocker, absorption) are computed for the loop's
  rate.
- **Room.** The direct sound plus 3 early reflections (round trips across L, W and H, gain 0.36 each) feed 6
  resonators.
  - The resonators are tuned to the room's axial modes f = n·c/2D (c = 343 m/s): the 6 lowest modes of the three
    dimensions at or above 110 Hz.
  - Modes within 0.8 % of each other count as one degenerate peak and get a stronger weight.
  - Each resonator is a Chamberlin SVF with 32-bit state and a Q15 coefficient 2·sin(πf/fs). The coefficient is
    a Taylor series, computed only when the knobs change.
  - At 11.025 kHz, modes above 1.7 kHz (only in tiny rooms) are clamped to 1.7 kHz.
- **Each pass** then goes through a DC blocker (27 Hz), the absorption low-pass and the normalisation gain:
  - The gain is G·(T/S)·(P/S) per generation. S is the peak this pass wrote (before the knee), P is the peak it
    read, and T is −6 dBFS.
  - Each ratio is limited to ×4 / ×¼.
  - A soft knee above −2.5 dBFS limits overshoot.
  - A silent capture is never boosted.
- **Multiplies.** They are 16×16 (Blackfin MAC, forced with a small inline asm). At 22.05 kHz both output samples
  of a loop sample are made together, as before. Odd grid points and 11.025 kHz use a one-sample-at-a-time path.

## Screen (`lucierroom.svg`, `gen_svg.py`, geometry in `sitting_geom.h`)

- **Counter and tags.** The counter reads "GEN 07" ("REC" while capturing, "GEN --" before the first capture).
  Next to it, the loop length is shown in blue ("1 BAR", "1/16", "2.6 SEC"), and below that ARMED (blinking) or
  11K.
- **Info lines.** They show the shape (green), the dimensions (blue), and the loudest room mode (white). While a
  page-2 knob is edited, the third line shows `LOOP 2.6 SEC`, `SYNC 1 BAR [11K | LONG]` or `ABSORB nn%`. While
  idle it shows `PRESS ORANGE` or `STARTS ON BEAT`.
- **Floor plan.** An L × W rectangle in blue that grows with the size knob, with a side section for H. The nodal
  lines of the active axial modes light up with their resonator's energy.
- **Loop waveform.** The loop fills the lane (min/max of 128 buckets). The part already rewritten is white, the
  rest is grey, the head is red, and the recording is red.
  - Under the lane, a synced loop shows its 1/16 grid points (up to 1 beat) or its beats, with bar lines long.
    A free loop shows seconds.
- **Knobs.** The knob row sits above the bottom edge. Each knob has a short label in its colour (SIZE, SHAPE,
  ERODE, MIX; on page 2: LOOP, ABSORB) and a 5-px bar on a dim track of the same colour.
  - Page-2 values are dashed.
  - The page-2 LOOP bar has ticks for FREE and the 6 synced lengths.
- **Previews.** `sitting_preview.png` comes from `python -I plugins/in_a_room/preview.py`. It shows 8 states (idle,
  armed, recording, synced generations, 2 BARS at 11K, free, 1/16, deep erosion), run through
  `harness/sitting_test.c` with a modelled beat clock. The stock `harness/render.py "in a room"` still works but
  only shows the idle screen, because it never presses the latch.

## Name

`"in a room"` (with spaces) is safe end to end:
- `make_firmware.py` checks `islower()` (spaces allowed) and length ≤ 15.
- The `fx_types` row is a plain SQLite text value.
- The FX name compare (`fx_name_eq` → `streq_n`) compares exact bytes with the string's length.
- The OP-1 stores the FX name in the sound's JSON, and no file paths are built from FX names.

Sounds store the FX **by name**, and an unknown name asserts in `fx_types.cpp:42` ("unknown fx name"), which
locks the OP-1 at boot. For that reason `dispatcher.c` keeps accepting the old name "sitting" (`fx_old_names`).
The effect itself is chosen by the selector word (knobs[4] = MAGIC + order 7), which the rename keeps.

## Limitations

- **Clock offset.** If the FX renders after the metronome in the audio callback, every loop is shifted by a
  constant 64 samples (1.45 ms). Check by ear against the click and against a sequencer started with the tape.
- **Clock mode.** Whether the metronome follows the tape (`follows_tape`) depends on the OP-1's tempo/sync
  mode. Check bar alignment with the tape playing and stopped.
- **Count-in.** After a count-in recording, the accent click counts bars from the count-in position. This FX
  counts them from tape position 0.
- **MIDI clock.** Under MIDI clock the phase runs at the derived tempo, as the metronome does.
- **Other checks.** The CPU figure still needs measuring with the resource monitor, including AUDIO peak and all
  three positions running the FX. The GUI draws about 270–410 lines per frame.
- **Loop length** is taken when a capture starts (or arms), so turning LOOP while a loop plays only affects the
  next capture.
- **Large rooms** cluster in a low hum (112–169 Hz for the real Lucier room). Smaller rooms, CUBE or GOLDEN give
  clearer chords on the speaker.
- **Master position** assumes `op1_fx_scratch(2)` is a full 176460-byte area, like the other positions.
