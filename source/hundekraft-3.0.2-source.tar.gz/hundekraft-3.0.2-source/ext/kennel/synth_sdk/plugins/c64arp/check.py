#!/usr/bin/env python3
"""Focused c64arp logic/text tests; actual loading/audio/restart are separate gates."""
from pathlib import Path
import subprocess,tempfile
P=Path(__file__).resolve().parent;SDK=P.parents[1]
with tempfile.TemporaryDirectory(prefix='c64arp-check-') as tmp:
    out=Path(tmp);flags=['cc','-O1','-g','-fsanitize=address,undefined','-fno-sanitize-recover=undefined']
    subprocess.run(flags+[str(P/'arp.c'),str(P/'arp_test.c'),'-o',str(out/'logic')],check=True)
    subprocess.run([str(out/'logic')],check=True)
    subprocess.run(flags+['-DOP1_HOST','-DFX=FX_dummy','-DSCREEN=SCREEN_c64arp','-I'+str(SDK),str(P/'geometry_test.c'),str(P/'c64arp.c'),str(P/'arp.c'),'-lm','-o',str(out/'geometry')],check=True)
    subprocess.run([str(out/'geometry')],check=True)
