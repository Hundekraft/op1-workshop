# C64 arpeggiator

Original Hundekraft musical-clock arpeggiator inspired by relative C64 pitch tables. It emits normal OP-1 notes; it does not emulate SID oscillators or register playback.

The standard sequencer switch controls run/stop. Orange controls note length (Gate). Editable steps store pitch offset and dwell; preserve the note ledger so stopping, changing slots or resetting releases the notes actually emitted.

Primary references are Lasse Öörni’s [GoatTracker manual](https://github.com/leafo/goattracker2/blob/master/readme.txt) (pitch-table behavior) and Linus Walleij’s [SID-player pseudocode](https://codebase64.net/doku.php?id=base:a_sid_player_routine). `gen_svg.py` generates the screen and uses `display/compact_svg.py`; preserve drawing order, separate contours, named edit groups, readable strokes and the established upward offset.

Plugin code and authored artwork are by Hundekraft under kennel’s license. No C64 player code, TE font or firmware asset is included.
