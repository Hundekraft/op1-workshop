#!/usr/bin/env python3
"""Output passes through display/compact_svg.py: equivalent explicit M/L paths,
unchanged coordinate strings, per-shape paint and animation IDs; no simplification.
Contour original art with the screen placement and line-weight constraints:
move all artwork up 4 screen px; normalize thin ink to the measured 1.6 px SID
bottom-lead weight, preserving broad fills, holes/gaps and the source palette.
Native text is unchanged. Minimum-width processing is deterministic and bounded.
"""
import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'display'))
from svgart import rounded,shape
from compact_svg import compact_svg
from lineweight import minimum_width
import cv2
import numpy as np
from PIL import Image
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parents[3]/'docs/design/c64/c64arp-art.png'
# Caller supplies the root reference because kennel is a separate repository.
def generate(source,output):
    a=np.asarray(Image.open(source).convert('RGB')).astype(float)
    if a.shape[:2]!=(887,1774):raise ValueError('expected exact generated 1774x887 canvas')
    palette=np.array([[243,244,245],[87,142,241],[1,240,188],[246,85,100]],float)
    # Assign by chromatic direction: antialiased pixels retain the nearest color,
    # with a half-strength boundary. Palette is measured from bright source ink.
    direction=palette/np.linalg.norm(palette,axis=1)[:,None]
    norms=np.linalg.norm(a,axis=2);unit=a/np.maximum(norms[:,:,None],1)
    labels=np.argmax(np.einsum('...c,kc->...k',unit,direction),axis=2)
    out=['<svg xmlns="http://www.w3.org/2000/svg" width="320" height="160" viewBox="0 0 320 160">']
    counts=[];vertex_counts=[]
    for i,col in enumerate(palette):
        strength=np.einsum('...c,c->...',a,col)/sum(col*col)
        mask=(labels==i)&(strength>.5)
        mask=minimum_width(mask).astype(np.uint8)*255
        contours,hierarchy=cv2.findContours(np.repeat(np.repeat(mask,2,axis=0),2,axis=1),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        emitted=0
        def emit(index,depth):
            nonlocal emitted
            contour=contours[index]
            # Preserve thin white wires; simplify other contour noise more strongly.
            epsilon=(.12 if i==0 else .2)*1774/160
            points=cv2.approxPolyDP(contour,epsilon,True).reshape(-1,2)
            if abs(cv2.contourArea(points)-cv2.contourArea(contour))>max(1,cv2.contourArea(contour)*.05):
                points=cv2.approxPolyDP(contour,.8,True).reshape(-1,2)
            if len(points)<3:
                x,y,w,h=cv2.boundingRect(contour)
                points=np.array([[x-.5,y-.5],[x+w-.5,y-.5],[x+w-.5,y+h-.5],[x-.5,y+h-.5]])
            xy=rounded([((x+.5)*160/1774,(y+.5)*80/887-4) for x,y in points],True)
            if len(xy)>=3:
                color=('#'+''.join(f'{int(v):02x}' for v in col)) if depth%2==0 else '#010101'
                out.append(shape(xy,'none',0,True,color));emitted+=1;vertex_counts.append(len(xy))
            child=hierarchy[0,index,2]
            while child!=-1:
                emit(child,depth+1);child=hierarchy[0,child,0]
        if hierarchy is not None:
            for index,h in enumerate(hierarchy[0]):
                if h[3]==-1:emit(index,0)
        counts.append(emitted)
    assert sum(counts)<=445, 'native path budget exceeded'
    assert sum(vertex_counts)<=7253, 'native vertex budget exceeded'
    out.append('</svg>');Path(output).write_text(compact_svg('\n'.join(out)+'\n'))
    print(json.dumps({'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'canvas':[1774,887],'mapping':320/1774,'palette':palette.tolist(),'contours':counts,'vertices':sum(vertex_counts),'minimum_ink_width':1.6,'deviations':'measured flat palette; owner -4px y and 1.6px minimum useful-ink width; broad fills and half-pixel black channels preserved; no added paths'}))
if __name__=='__main__':generate(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else HERE/'c64arp.svg')
