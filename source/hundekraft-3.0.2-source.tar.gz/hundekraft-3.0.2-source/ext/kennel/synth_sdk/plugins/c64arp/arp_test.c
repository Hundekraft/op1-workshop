/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "arp.h"
#include <assert.h>
#include <stdio.h>
static int ons,offs,last,ids;
int arp_output_on(int m,int n,int k,int v){(void)m;(void)k;(void)v;ons++;last=n;return ids++;}
void arp_output_off(int id){assert(id>=0);offs++;}
int main(void){
 arp_state s,t;arp_init(&s);arp_init(&t);assert(s.root==-1&&s.sounding==-1&&!s.run);
 s.run=1;for(int i=0;i<200;i++)arp_tick(&s,0);assert(!ons);
 arp_key(&s,0,60,1);arp_tick(&s,0);assert(last==60&&ons==1);
 for(int i=0;i<24;i++)arp_tick(&s,0);assert(last==64&&ons==2&&offs==1);
 for(int i=0;i<24;i++)arp_tick(&s,0);assert(last==67&&ons==3&&offs==2);
 arp_key(&s,0,60,0);assert(s.root==-1&&s.sounding==-1&&offs==3);
 s.cfg.latch=1;arp_key(&s,0,60,1);arp_key(&s,0,60,0);arp_tick(&s,0);assert(s.root==60&&s.sounding>=0);
 arp_stop(&s);assert(s.root==-1&&s.sounding==-1&&!s.run);int count=ons;
 for(int i=0;i<100;i++)arp_tick(&s,0);assert(ons==count);
 arp_init(&s);s.run=1;s.cfg.dwell[0]=2;arp_key(&s,0,60,1);arp_tick(&s,0);
 for(int i=0;i<47;i++)arp_tick(&s,0);assert(last==60);arp_tick(&s,0);assert(last==64);
 arp_stop(&s);assert(ons==offs);
 arp_init(&s);s.run=1;s.cfg.rate=7;s.cfg.offset[0]=-24;s.cfg.octaves=4;arp_key(&s,0,12,1);arp_tick(&s,0);assert(s.sounding==-1);
 for(int i=0;i<1000;i++)arp_tick(&s,0);arp_stop(&s);assert(ons==offs);
 arp_init(&s);s.run=1;s.cfg.octaves=4;s.octave=3;arp_key(&s,0,60,1);arp_tick(&s,0);assert(last==96);
 s.cfg.octaves=1;int offbefore=offs;arp_bounds_changed(&s);assert(offs==offbefore+1&&s.sounding==-1&&s.octave==0&&!s.started);
 arp_tick(&s,0);assert(last==60&&s.run&&s.root==60);arp_stop(&s);assert(ons==offs);
 assert(t.root==-1&&t.sounding==-1&&!t.run);
 puts("c64arp timing, dwell, offsets, latch/release, stop and mode isolation PASS");
}
