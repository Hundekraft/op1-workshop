/* sampler tools as a feature plugin: the source lives in sampletools/st_pitch.c; this folder makes it a plugin.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../sampletools/st_pitch.c"
