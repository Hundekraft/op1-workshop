# palme — Ondes Martenot diffuseurs (FX, order 6)

Maurice Martenot did not trust a plain loudspeaker with his instrument. Next to the "Principal" he built
*diffuseurs* that colour the sound acoustically. The **Palme** (1950) is a palm-leaf shaped soundboard with 12
strings, tuned chromatically and excited by a speaker at its foot, so every note blooms into sympathetic
resonance. The **Métallique** replaced the membrane with a gong. Ondistes press a pedal or lever to lift the
dampers and let the Palme ring on. This FX models the strings with Karplus-Strong loops that you can morph into
gong modes, and the LATCH lifts the dampers for good.



## Knobs

| knob | page 1 | page 2 (press) |
|---|---|---|
| blue | **tuning**: root note C2 … B4 (the 12 strings are root … root + 11) | **métallique**: morph palme → gong (8 free-plate modes 1, 1.73, 2.33, 3.91, 4.11, 6.30, 6.71, 7.34 + 4 detuned twins that beat; the sum drives a soft clip whose residue blooms back into the strings while they are struck) |
| green | **sustain**: string T60 0.25 s … 30 s | **damping**: loop filter colour, dark felt … bright wire |
| white | **excite**: input drive into the strings + brightness of the excitation | **spread**: detune 0 … ±35 cents (fixed pattern per string) |
| red | **mix**: dry … dry + strings … strings | press = **LATCH, "étouffoir off"** (not saved) |

LATCH: while input plays, the loops sit at unity gain and collect what they hear. About 0.3 s after the input
stops, each string's *fundamental* is held indefinitely by an AGC (16-point DFT energy, PI control on top of
the computed loss compensation). Harmonics still fade with the damping, so the chord turns into a drone. New
input adds to it, and releasing LATCH lets everything decay. Every loop has a soft limiter, a proportional DC
servo and saturating arithmetic, so nothing can run away.

Screen (`palmediff.svg` + `gen_svg.py`): the palm leaf with its 12 strings fanning out from the loudspeaker.
Each string is drawn from its own delay line: one period of what it rings, laid along the string under a
standing-wave window, with amplitude and brightness following its level. Métallique fades in the gong behind
the leaf. The felt damper sits across the strings, and LATCH swings it open like two red wings. The speaker
cone breathes with the input. The root note, PALME / METAL, and page-aware dials are on screen too.

## DSP in short
- 3-tap loop kernel per string: linear-interpolated fractional delay ⊗ KS averager (1 − b, b) with the decay
  gain folded into the taps (Q24, sigma-delta to Q15 across blocks). The averager's delay b is taken off the
  line length, so tuning is exact.
- Ring buffers, 1024 samples per string (the longest look-back is 682: C2 = 674.2 samples + taps + the gate
  clear), with a 2-sample mirror of each ring's end in front of it. Writes never wrap (the write index is a
  multiple of 64). A string's block is one run, or two where its reads cross the ring's start, so the
  string-major inner loop has no masks (Blackfin fract16 builtins, 17 instructions per string-sample).
- Analysis, pitch glide, gain and latch AGC for 2 strings per block (each string every 8.7 ms).
- No block is expensive. There is no periodic bulk work. The FX's `init` runs inside the audio interrupt
  (the dispatcher calls it on the first render after the FX is selected), so it only resets state; the
  scratch is cleared over the first 8 blocks (12 ms) while the strings are silent and the dry part passes.
  The gate's history clear (at most 2 strings per block) uses 32-bit stores and is skipped while a gated
  string is still zero. Filling the DC servo window skips samples known to be zero, so there is no burst
  of reads at the start or after a gate.

## Limitations
- The CPU figure is an instruction count. The rings live in the SDRAM scratch buffer (24 sequential streams
  over 25.7 KB), so cache behaviour on the device decides the real load. Check on the T1 monitor.
- When the FX is selected, the strings start after 8 blocks (12 ms), during the scratch clear. The dry part
  passes meanwhile.
- Uses `__builtin_bfin_mult_fr1x16/1x32` and `add/sub_fr1x16/1x32` (plain C on the host).
- Scratch use: 25,728 of 176,460 bytes. The screen reads the rings from the GUI thread (racy, harmless).
- With latch on and input playing continuously, energy accumulates up to the per-string limiter (by design: the
  damper is up). Max excite + max métallique + latch is a loud, clipped roar (bounded).
- Low-level tails below about −42 dB fade faster (release), and strings under −68 dB are gated to zero, to
  avoid fixed-point limit cycles.
- Retuning and morphing glide (at most P/128 per 8.7 ms) instead of jumping.

Source and musical demonstration: https://github.com/ultralazr/op1-musica-obscura.
