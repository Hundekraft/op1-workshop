/* quad LFO as a feature plugin (kind 3) on the LFO-type hook point (op1_feature_lfo.h): the source lives in
 * lfo/quadlfo.c; this folder makes it a feature. Its lfo_types row and quadlfo.svg come with the build either way.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../lfo/quadlfo.c"
#include "../../op1_feature_lfo.h"

static const op1_lfo_type quad_lfo = {
    .name = "quad", .stock_class = OP1_LFO_CLASS_MIDI, .marker = QL_MARK, .match = ql_is_quad,
    .apply_synth = ql_apply_synth, .apply_drum = ql_apply_drum, .apply_fx = ql_apply_fx,
    .trig_synth = ql_trig_synth, .trig_drum = ql_trig_drum, .trig_fx = ql_trig_fx,
    .svg = "quadlfo.svg", .screen = &SCREEN_quadlfo, .press = ql_press, .turn = ql_turn,
};

static const char *const ql_claims[] = { "lfo:quad", 0 };
const op1_feature_t FEATURE_quad = { .api = OP1_FEATURE_API, .priority = 500, .name = "quad", .lfo = &quad_lfo, .claims = ql_claims };
