/* EVA: a space choir. A warm, sung 1980s film-score pad: two slightly detuned oscillators (a saw and a soft pulse),
 * a lowpass that opens with the breath, a gentle vowel colour on top of it, slow vibrato with a little drift per voice
 * and a wide ensemble chorus; the astronaut's helmet radio is the character on top (kennel synth plugin, eva.knl).
 * blue   (knob 0) PRESSURE: brightness and attack: soft, slow and distant (low) .. bright, quick and close (high)
 * green  (knob 1) FREQ: the vowel colour, oo - ah - ee: two wide formant bands blended with the lowpass
 * white  (knob 2) OXYGEN: air and width: breath noise in the attack, the ensemble chorus's depth, a slow swell
 * orange (knob 3) COM: the radio as a colour. Up to 40 %: a warm band-limit and soft saturation. Above 40 %: the
 *                  channel gets thinner (300 Hz .. 3 kHz), hiss rises, the carrier drops out now and then, and the
 *                  Key-pitched radio tones come in, louder with COM, for 250 ms when a note starts with no other note
 *                  held, the same pitch for 250 ms and a squelch tail when the last note is released (in the voice's
 *                  release, so a short release cuts it). Above 75 % the signal is crushed (sample rate and bits).
 * The engine never sees the voice sum, so the "shared" radio is shared state (the swell, dropouts, the beep), one owner
 * voice for each beep, advanced once per block by the first voice rendered (voices render in ascending order).
 * Everything runs at 22.05 kHz (half the output rate, which halves the cost; the oscillators are polyBLEP, the pad's
 * lowpass ends below 6 kHz), the output is interpolated 2x. Every knob-driven value moves from the previous block's
 * value to the new one in steps (the first at the old value): 8 for the level and the carrier, 4 for the filters
 * and the noises, so a knob step never jumps at the first sample; the
 * crush's hold and step change at block boundaries behind the stepped mix. Phases and LFOs are uint32 that wrap by
 * design (2^32 is one cycle), nothing else counts. Follows note velocity.
 * Cost: the block is built in passes over a buffer (source, pad, ensemble, radio), each with only its own state; the
 * divisions run when FREQ, COM or the pitch change; the polyBLEP runs only near an edge; the delay line is kept twice
 * so the taps read on through plain pointers.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "op1_plugin.h"
#include "eva_tables.h"
#include "eva_geom.h"

#define FS 32768
#define HALF (OP1_BLOCK / 2)           /* the voice runs at 22.05 kHz, HALF samples per block */
#define QLEN 5512                         /* Quindar beep, 250 ms (22.05 kHz samples) */
#define QFADE 32                          /* 1.5 ms fade in and out (a power of two: no division per sample) */
#define SQLEN 2048                        /* squelch tail after the end beep, 93 ms (a power of two) */
#define SUB 8                             /* 22.05 kHz samples per parameter step (16 output samples) */
#define DLY 512                           /* chorus delay line per voice, 23 ms */

enum { P_LPA, P_F1, P_F2, P_D1, P_D2, P_G1, P_G2, P_NOISE, P_AMP, P_CHO, P_HP, P_RLP, P_SAT, P_HISS, P_CRUSH,
       P_GATE, NP };

typedef struct {
    uint32_t ph1, ph2, vph, noise, c1ph, c2ph;
    int32_t vib, drift, dtarget, env;     /* vibrato depth, pitch drift and its target (Q15), attack envelope (Q15) */
    int32_t a1, a2;                       /* the pad's lowpass, two one-poles */
    int32_t lo1, bd1, lo2, bd2;           /* the vowel's formant bands */
    int16_t dl[2 * DLY];                  /* chorus delay line, kept twice */
    uint32_t dw;                          /* its write index (wraps on DLY: a power of two) */
    int32_t hs1, hs2, l1, l2;             /* radio band-limit */
    int32_t last;                         /* last 22.05 kHz output sample, for the interpolation */
    int32_t held_s, cnt, hold_n, step;    /* crush: held sample, counter, hold length and quantiser step */
    int32_t p[NP];                        /* previous block's targets */
    int32_t com;                          /* last COM seen, for the end beep (note_off gets no knobs) */
    int32_t kf, vc[6];                    /* the vowel's coefficients (F1, F2, dampings, gains) for FREQ = kf */
    uint32_t kinc;                        /* the pitch inv is for */
    int32_t inv;                          /* (2^30 / dt) >> 8 at that pitch */
} voice_t;

static voice_t voices[OP1_VOICES];
static uint8_t held[OP1_VOICES];
static int last_voice = OP1_VOICES;
static uint32_t rng = 0x2545F491u;
static uint32_t br_ph, br_inc = 1495000u; /* the slow swell, 2^32 per cycle */
static int32_t drop_left;                 /* blocks left in a dropout */
static int32_t gate_s = FS - 1;           /* the carrier, smoothed per block (~10 ms) */
/* Quindar: one owner voice */
static int q_owner = -1;
static uint32_t q_ph, q_inc;
static int32_t q_left, q_level, sq_left, sq_level;

#define QUINDAR_FROM 13107                /* COM 40 %: below it the radio colours the voice but stays quiet */
#define CRUSH_FROM 24576                  /* COM 75 % */
/* COM's ranges as multiply-and-shift (a division by a constant is a library call on the Blackfin) */
static inline int32_t com_warm(int32_t c) { return c < QUINDAR_FROM ? (c * 5) >> 1 : 32767; }                  /* 0..1 over 0 .. 40 % */
static inline int32_t com_radio(int32_t c) { return c > QUINDAR_FROM ? ((c - QUINDAR_FROM) * 27307) >> 14 : 0; } /* 0..1 above */
static inline int32_t beep_level(int32_t c) { return c > QUINDAR_FROM ? 1500 + (((c - QUINDAR_FROM) * 15834) >> 15) : 0; }

static volatile uint32_t eva_blocks;      /* for the screen: rendered blocks, breath swell, carrier gate, beep */
static volatile int32_t eva_breath, eva_gate = FS - 1, eva_beep;

static inline int32_t clamp(int32_t x, int32_t lo, int32_t hi) { return x < lo ? lo : x > hi ? hi : x; }
/* Orange page: three compact repeating bands, two detents per octave. Zero from existing sounds means +1. */
static unsigned beep_octave(const int16_t *k) { return k[7] > 0 ? ((unsigned)k[7] >> 9) % 3 : 1; }
static uint32_t beep_increment(uint32_t inc, unsigned oct) {
    const uint32_t ceiling=0x60000000u; /* 8.27 kHz at22.05k: no phase overflow/alias fold */
    return inc > (ceiling >> oct) ? ceiling : inc << oct;
}
static inline int32_t knob(const int16_t *k, int i) { return k[i] < 0 ? 0 : k[i]; }
static inline int32_t sinq(uint32_t ph)  /* Q15 */
{
    const uint32_t i = ph >> 22;
    const int32_t a = ev_sin[i];
    return a + (((ev_sin[i + 1] - a) * (int32_t)((ph >> 7) & 0x7FFF)) >> 15);
}
static inline uint32_t lcg(uint32_t *s) { return *s = *s * 1664525u + 1013904223u; }

/* soft clip: identity near 0, reaches +-32768 with zero slope at +-1.5 full scale */
static inline int32_t sclip(int32_t x)
{
    x = clamp(x, -49151, 49151);
    const int32_t h = x >> 1;
    const int32_t x2 = (h * h) >> 13;
    const int32_t x3 = ((x2 >> 1) * h) >> 13;
    return x - ((x3 * 4855) >> 15);
}

/* polyBLEP saw, Q15 (+-32768): t = the phase as Q15, dt = the phase step as Q15, inv8 = (2^30 / dt) >> 8 */
static inline int32_t blep_saw(uint32_t ph, int32_t dt, int32_t inv8)
{
    const int32_t t = (int32_t)(ph >> 17);
    int32_t s = (int32_t)(ph >> 16) - 32768;
    if (t < dt) {
        const int32_t x = (t * inv8) >> 7;
        s -= x + x - ((x * x) >> 15) - 32768;
    } else if (t > 32768 - dt) {
        const int32_t x = ((t - 32768) * inv8) >> 7;
        s -= ((x * x) >> 15) + x + x + 32768;
    }
    return s;
}

/* a one-pole coefficient (Q15) from a brightness 0..32767: about 300 Hz .. 5.6 kHz at 22.05 kHz */
static inline int32_t lp_coef(int32_t b) { return 2600 + ((((((b * b) >> 15) + b) >> 1) * 23600) >> 15); }

static void targets(voice_t *v, const int16_t *knobs, int32_t *t)
{
    const int32_t p = knob(knobs, 0), f = knob(knobs, 1), o = knob(knobs, 2), c = knob(knobs, 3);
    /* PRESSURE and the attack: the lowpass opens with both */
    const int32_t bright = 8192 + ((p * 24575) >> 15);                 /* 0.25 .. 1 */
    const int32_t bloom = 13107 + ((v->env * 19660) >> 15);             /* 0.4 .. 1 while the note swells in */
    t[P_LPA] = lp_coef((bright * bloom) >> 15);
    /* FREQ: oo .. ah .. ee (worked out when FREQ moves: two divisions) */
    if (f != v->kf) {
        v->kf = f;
        const int32_t pos = f * 2;
        int vi = pos >> 15;
        int32_t fr = pos & 0x7FFF;
        if (vi >= 2) { vi = 1; fr = FS - 1; }
        for (int k = 0; k < 2; k++) {
            const int a = vi * 2 + k, b = a + 2;
            const int32_t hz = ev_hz[a] + (((ev_hz[b] - ev_hz[a]) * fr) >> 15);
            const int32_t bw = ev_bw[a] + (((ev_bw[b] - ev_bw[a]) * fr) >> 15);
            const int32_t x = (hz * 4781) >> 10;                        /* pi hz / 22050, Q15 */
            const int32_t x3 = (((x * x) >> 15) * x) >> 15;
            v->vc[k] = x - x3 / 6;                                      /* 2 sin(pi hz / 22050), Q14 */
            v->vc[2 + k] = (bw << 14) / hz;                             /* damping 1/Q, Q14 */
            v->vc[4 + k] = ((ev_level[a] + (((ev_level[b] - ev_level[a]) * fr) >> 15)) * v->vc[2 + k]) >> 14;  /* unity peak */
        }
    }
    for (int k = 0; k < 2; k++) {
        t[P_F1 + k] = v->vc[k];
        t[P_D1 + k] = v->vc[2 + k];
        t[P_G1 + k] = v->vc[4 + k];
    }
    /* OXYGEN: breath in the attack, the chorus, the swell */
    t[P_NOISE] = (o * (1600 + (((32767 - v->env) * 9000) >> 15))) >> 15;
    t[P_CHO] = 13107 + ((o * 19660) >> 15);                             /* 0.4 .. 1 */
    const int32_t sw = 16384 + (sinq(br_ph) >> 1);                      /* 0..1 */
    t[P_AMP] = (v->env * (FS - 1 - ((((o * sw) >> 15) * 8192) >> 15))) >> 15;   /* the swell dips 25 % at most */
    /* COM: warm up to 40 %, then the radio (the same for every voice: worked out when COM or the dropout changes) */
    static int32_t kc = -1, kdrop, com_t[5];
    if (c != kc || (drop_left != 0) != kdrop) {
        kc = c;
        kdrop = drop_left != 0;
        const int32_t w = com_warm(c), r = com_radio(c);
        com_t[0] = ((30 + ((w * 130) >> 15) + ((r * 170) >> 15)) * 4781) >> 10;               /* 30 .. 160 .. 330 Hz */
        com_t[1] = 32767 - ((w * 7800) >> 15) - ((r * 11000) >> 15);                         /* open .. ~5 kHz .. ~2.6 kHz */
        com_t[2] = 4096 + ((w * 3000) >> 15) + ((r * 3500) >> 15);                           /* Q12: 1 .. 1.7 .. 2.6 */
        com_t[3] = r ? 200 + ((r * 1600) >> 15) + (drop_left ? (r * 2500) >> 15 : 0) : 0;
        com_t[4] = c > CRUSH_FROM ? (c - CRUSH_FROM) * 4 : 0;                                 /* 0..1 above 75 % */
    }
    t[P_HP] = com_t[0];
    t[P_RLP] = com_t[1];
    t[P_SAT] = com_t[2];
    t[P_HISS] = com_t[3];
    t[P_CRUSH] = com_t[4];
    t[P_GATE] = gate_s;
    v->com = c;
}

static void eva_note_on(void *self, const int16_t *knobs)
{
    const int vi = op1_voice_index(self);
    voice_t *v = &voices[vi];
    int alone = 1;
    for (int i = 0; i < OP1_VOICES; i++) if (i != vi && held[i]) alone = 0;
    held[vi] = 1;
    v->noise = 0x9E3779B9u ^ ((uint32_t)vi * 0x85EBCA6Bu);   /* per voice, not per address: reproducible */
    v->ph1 = lcg(&v->noise);                                   /* free-running phases: the voices don't line up */
    v->ph2 = lcg(&v->noise);
    v->c1ph = (uint32_t)vi * 0x2AAAAAAAu;
    v->c2ph = (uint32_t)vi * 0x15555555u + 0x40000000u;
    v->vph = 0;
    v->vib = 0;
    v->drift = v->dtarget = 0;
    v->env = 0;
    v->a1 = v->a2 = v->lo1 = v->bd1 = v->lo2 = v->bd2 = 0;
    for (int i = 0; i < 2 * DLY; i++) v->dl[i] = 0;
    v->dw = 0;
    v->hs1 = v->hs2 = v->l1 = v->l2 = v->last = 0;
    v->held_s = v->cnt = 0;
    v->kf = -1;
    v->kinc = 0;
    v->inv = 0;
    targets(v, knobs, v->p);
    v->hold_n = 1 + ((v->p[P_CRUSH] * 3) >> 15);
    v->step = 1 << (3 + ((v->p[P_CRUSH] * 6) >> 15));
    if (alone && beep_level(v->com)) {                           /* key up: start beep */
        q_owner = vi;
        q_ph = 0;
        q_inc = 0;                                       /* Set from the owner voice pitch in render (after VoiceCtl writes it). */
        q_left = QLEN;
        q_level = (beep_level(v->com) * 7) / 5;  /* Restore beep gain independently of pad/squelch. */
        sq_left = 0;
    }
}

static void eva_note_off(void *self)
{
    const int vi = op1_voice_index(self);
    held[vi] = 0;
    for (int i = 0; i < OP1_VOICES; i++) if (held[i]) return;
    const int32_t c = voices[vi].com;
    if (!beep_level(c)) return;
    q_owner = vi;                                                 /* key down: end beep, then squelch */
    q_ph = 0;
    q_inc = 0;                                           /* Release beep follows the last played voice pitch too. */
    q_left = QLEN;
    q_level = (beep_level(c) * 7) / 5;
    sq_left = SQLEN;
    sq_level = (beep_level(c) * 2) / 3;
}

/* radio: a 2+2 pole band-limit and the saturation, ramped per sub-block; fin: also the crush (crush: on) and
 * velocity and the 2x interpolation into out (when no beep follows) */
static inline void radio(voice_t *v, int32_t *x, const int32_t *p0, const int32_t *d, int fin, int crush, int16_t *out,
                         int32_t gain)
{
    int32_t hs1 = v->hs1, hs2 = v->hs2, l1 = v->l1, l2 = v->l2, last = v->last, cnt = v->cnt, held_s = v->held_s;
    const int32_t hold_n = v->hold_n, step = v->step;
    for (int sb = 0; sb < 4; sb++) {                                  /* 4 steps of 16: these move only with COM */
        const int32_t hp = p0[P_HP] + ((d[P_HP] * sb) >> 2), rlp = p0[P_RLP] + ((d[P_RLP] * sb) >> 2);
        const int32_t sat = p0[P_SAT] + ((d[P_SAT] * sb) >> 2), cr = p0[P_CRUSH] + ((d[P_CRUSH] * sb) >> 2);
        for (int i = sb * 16; i < sb * 16 + 16; i++) {
            int32_t y = clamp(x[i], -65535, 65535);
            hs1 += ((y - hs1) * hp) >> 14;
            y -= hs1;
            hs2 += ((y - hs2) * hp) >> 14;
            l1 += ((y - hs2 - l1) * rlp) >> 15;                          /* within +-2^17: l2 * sat stays in 2^31 */
            l2 += ((l1 - l2) * rlp) >> 15;
            y = sclip((l2 * sat) >> 12);
            if (fin) {                                                  /* sclip and gain: within +-15000, no clamp */
                if (crush) {
                    if (++cnt >= hold_n) {
                        cnt = 0;
                        held_s = y & ~(step - 1);
                    }
                    y += ((held_s - y) * cr) >> 15;
                }
                y = (y * gain) >> 15;
                out[2 * i] = (int16_t)((last + y) >> 1);
                out[2 * i + 1] = (int16_t)y;
                last = y;
            } else x[i] = y;
        }
    }
    v->hs1 = hs1; v->hs2 = hs2; v->l1 = l1; v->l2 = l2;
    if (fin) v->last = last;
    if (crush) { v->cnt = cnt; v->held_s = held_s; }
}

static void eva_render(void *self, int16_t *out, const int16_t *knobs)
{
    const int vi = op1_voice_index(self);
    voice_t *v = &voices[vi];

    /* shared state: once per block */
    if (vi <= last_voice) {
        br_ph += br_inc;
        const int32_t o = knob(knobs, 2);
        br_inc = 1495000u + (uint32_t)((o * 1500) >> 15) * 1024u;    /* the swell: 0.12 .. 0.24 Hz */
        const int32_t c = knob(knobs, 3);
        const int32_t r = com_radio(c);
        if (drop_left) drop_left--;
        else if (r && (int32_t)((lcg(&rng) >> 17) & 0x7FFF) < ((((r * r) >> 15) * 120) >> 15))
            drop_left = 6 + (int32_t)((lcg(&rng) >> 27) + (lcg(&rng) >> 28));          /* 17 .. 140 ms */
        gate_s += ((drop_left ? FS - 1 - ((r * 29000) >> 15) : FS - 1) - gate_s) >> 2;
    }
    last_voice = vi;

    /* the attack: PRESSURE sets how fast the note swells in (~0.6 s soft .. ~15 ms close) */
    const int32_t pr = knob(knobs, 0), ka = 158 + ((((pr * pr) >> 15) * 6200) >> 15);
    v->env += ((FS - 1 - v->env) * ka) >> 15;

    int32_t t[NP], d[NP];
    targets(v, knobs, t);
    const int32_t *p0 = v->p;
    for (int k = 0; k < NP; k++) d[k] = t[k] - p0[k];
#define RAMP(k, sb) (p0[k] + ((d[k] * (sb)) >> 3))   /* sub-block sb (0..7) of 8: the first at the old value */
#define RAMP4(k, sb) (p0[k] + ((d[k] * (sb)) >> 2))  /* the same in 4 sub-blocks of 16 */
    eva_breath = knob(knobs, 2);
    eva_gate = t[P_GATE];
    eva_beep = q_left > 0 && q_owner >= 0;

    /* pitch: slow vibrato (fades in over ~0.5 s) and a little random drift per voice */
    if (v->vib < 20480) v->vib += 120;
    if ((lcg(&v->noise) >> 24) < 2) v->dtarget = (int32_t)(lcg(&v->noise) >> 17) - 16384;   /* new target ~ every 0.4 s */
    v->drift += (v->dtarget - v->drift) >> 6;
    const int32_t m = ((sinq(v->vph) * v->vib) >> 15) + ((v->drift * 9830) >> 15);   /* Q15 of +-0.4 % */
    v->vph += 62300000u;                                          /* 5 Hz per block */
    v->c1ph += 4600000u;                                          /* chorus LFOs: 0.37 Hz, 0.53 Hz */
    v->c2ph += 6600000u;
    const int32_t cm1 = sinq(v->c1ph), cm2 = sinq(v->c2ph);
    /* chorus taps (Q8 samples): 10 ms +- 2.5 ms and 14 ms +- 3 ms, set per block */
    const int32_t dd1 = (221 << 8) + ((cm1 * (55 << 8)) >> 15), dd2 = (309 << 8) + ((cm2 * (66 << 8)) >> 15);

    const uint32_t inc0 = (uint32_t)OP1_PITCH_INC[0] + (uint32_t)OP1_PITCH_INC[1];
    if(vi==q_owner && q_left>0)q_inc=beep_increment(inc0,beep_octave(knobs)); /* 22.05 kHz: sum of two 44.1 kHz increments. */
    const uint32_t i1 = inc0 + (uint32_t)(((int32_t)(inc0 >> 16) * m) >> 7);
    const uint32_t i2 = i1 + (i1 >> 9) + (i1 >> 11);              /* the pulse ~6 cents up */
    const int32_t dt1 = (int32_t)(i1 >> 17), dt2 = (int32_t)(i2 >> 17);
    /* the polyBLEP's 1 / dt: one division when the pitch changes (the vibrato's +-0.4 % doesn't matter at the edge),
     * the pulse's from it (6 cents up: 1 / (1 + 2^-9 + 2^-11) ~ 1 - 2^-9 - 2^-11) */
    if (inc0 != v->kinc) {
        v->kinc = inc0;
        const int32_t dt0 = (int32_t)(inc0 >> 17);
        v->inv = dt0 > 0 ? ((1 << 30) / dt0) >> 8 : 0;
    }
    const int32_t inv1 = v->inv, inv2 = inv1 - (inv1 >> 9) - (inv1 >> 11);

    /* the voice is built in passes over the block (22.05 kHz), each with only its own state in registers */
    int32_t x[HALF];
    uint32_t noise = v->noise;
    /* the source: a saw and a soft pulse, detuned */
    {
        uint32_t ph1 = v->ph1, ph2 = v->ph2;
        if (i2 < 0x40000000u)                                     /* below 5.5 kHz: one test per oscillator for an edge */
            for (int i = 0; i < HALF; i++) {
                ph1 += i1;
                ph2 += i2;
                /* away from an edge the polyBLEP saw is the plain ramp and the pulse a plain square (+-16384, so its
                 * 12000 / 32768 share is +-6000 exactly) */
                const int32_t saw = ph1 + i1 < i1 + i1 ? blep_saw(ph1, dt1, inv1) : (int32_t)(ph1 >> 16) - 32768;
                const uint32_t q = ph2 << 1;
                if (q + i2 + i2 < (i2 << 2)) {                     /* near the up edge (ph2 ~ 0) or the down edge */
                    const int32_t pul = ph2 + i2 < i2 + i2 ? (blep_saw(ph2, dt2, inv2) - ((int32_t)((ph2 + 0x80000000u) >> 16) - 32768)) >> 1
                                                          : (((int32_t)(ph2 >> 16) - 32768) - blep_saw(ph2 + 0x80000000u, dt2, inv2)) >> 1;
                    x[i] = (saw * 19000 + pul * 12000) >> 15;
                }
                else
                    x[i] = ((saw * 19000) >> 15) + (ph2 & 0x80000000u ? 6000 : -6000);
            }
        else
            for (int i = 0; i < HALF; i++) {
                ph1 += i1;
                ph2 += i2;
                const int32_t saw = blep_saw(ph1, dt1, inv1);
                const int32_t pul = (blep_saw(ph2, dt2, inv2) - blep_saw(ph2 + 0x80000000u, dt2, inv2)) >> 1;
                x[i] = (saw * 19000 + pul * 12000) >> 15;
            }
        v->ph1 = ph1; v->ph2 = ph2;
    }
    /* the pad: breath, two one-pole lowpasses, then the vowel's two bands added (each fed a quarter of the source: no clamps
     * needed), one pass each */
    int32_t pb[HALF];                                             /* the pad, then the voice from here on */
    {
        int32_t a1 = v->a1, a2 = v->a2;
        if (p0[P_NOISE] | t[P_NOISE])                               /* with breath, added to the source here */
            for (int sb = 0; sb < 8; sb++) {
                const int32_t lpa = RAMP(P_LPA, sb), nz = RAMP(P_NOISE, sb);
                for (int i = sb * SUB; i < sb * SUB + SUB; i++) {
                    const int32_t in = x[i] + ((((int32_t)lcg(&noise) >> 16) * nz) >> 15);
                    x[i] = in;
                    a1 += ((in - a1) * lpa) >> 15;
                    a2 += ((a1 - a2) * lpa) >> 15;
                    pb[i] = a2;
                }
            }
        else
            for (int sb = 0; sb < 8; sb++) {
                const int32_t lpa = RAMP(P_LPA, sb);
                for (int i = sb * SUB; i < sb * SUB + SUB; i++) {
                    a1 += ((x[i] - a1) * lpa) >> 15;
                    a2 += ((a1 - a2) * lpa) >> 15;
                    pb[i] = a2;
                }
            }
        v->a1 = a1; v->a2 = a2;
        for (int k = 0; k < 2; k++) {
            int32_t lo = k ? v->lo2 : v->lo1, bd = k ? v->bd2 : v->bd1;
            for (int sb = 0; sb < 4; sb++) {                          /* 4 steps of 16: these move only with FREQ */
                const int32_t f = RAMP4(P_F1 + k, sb), q = RAMP4(P_D1 + k, sb);
                const int32_t g = (RAMP4(P_G1 + k, sb) * 26000) >> 15;         /* the vowel: peaks on the lowpass */
                for (int i = sb * 16; i < sb * 16 + 16; i++) {
                    lo += (f * bd) >> 14;
                    bd += (f * ((x[i] >> 2) - lo - ((q * bd) >> 14))) >> 14;
                    pb[i] += (bd * g) >> 13;
                }
            }
            if (k) { v->lo2 = lo; v->bd2 = bd; } else { v->lo1 = lo; v->bd1 = bd; }
        }
    }
    /* the ensemble: two modulated taps of a 23 ms delay; then the level (attack, swell) and the carrier */
    {
        /* the line is kept twice (dl[w] = dl[w + DLY]), so a tap reads on from one pointer for the whole block: the
         * taps sit 166 samples back or more, past the block's 64 */
        uint32_t dw = v->dw;
        int16_t *dl = v->dl;
        const int32_t fa = dd1 & 255, fb = dd2 & 255;
        const int16_t *ra = dl + DLY + (dw & (DLY - 1)) - (dd1 >> 8), *rb = dl + DLY + (dw & (DLY - 1)) - (dd2 >> 8);
        for (int sb = 0; sb < 8; sb++) {
            const int32_t cho = RAMP(P_CHO, sb) >> 1, ag = (RAMP(P_AMP, sb) * RAMP(P_GATE, sb)) >> 15;
            for (int i = sb * SUB; i < sb * SUB + SUB; i++) {
                int32_t y = pb[i];
                const int16_t w = (int16_t)clamp(y, -32768, 32767);
                const uint32_t wi = dw & (DLY - 1);
                dl[wi] = w;
                dl[wi + DLY] = w;
                dw++;
                const int32_t a = *ra, b = *rb;
                const int32_t ta = a + (((ra[-1] - a) * fa) >> 8);
                const int32_t tb = b + (((rb[-1] - b) * fb) >> 8);
                ra++;
                rb++;
                y += ((((ta + tb) >> 1) - y) * cho) >> 15;
                pb[i] = (y * ag) >> 15;
            }
        }
        v->dw = dw;
    }
    /* radio: hiss, a 2+2 pole band-limit, saturation */
    if (p0[P_HISS] | t[P_HISS])
        for (int sb = 0; sb < 4; sb++) {                          /* noise: 4 steps are enough */
            const int32_t hiss = RAMP4(P_HISS, sb);
            for (int i = sb * 16; i < sb * 16 + 16; i++) pb[i] += (((int32_t)lcg(&noise) >> 16) * hiss) >> 15;
        }
    const int crushing = (p0[P_CRUSH] | t[P_CRUSH]) != 0, beeping = vi == q_owner && (q_left > 0 || sq_left > 0);
    const int32_t gain = (15000 * op1_voice_vel_gain(self)) >> 15;
    if (beeping) radio(v, pb, p0, d, 0, 0, out, gain);
    else if (crushing) radio(v, pb, p0, d, 1, 1, out, gain);      /* nothing follows: straight into out */
    else radio(v, pb, p0, d, 1, 0, out, gain);
    /* crush: sample-and-hold and coarse steps, mixed in above 75 % */
    if (beeping && crushing) {
        int32_t cnt = v->cnt, held_s = v->held_s;
        const int32_t hold_n = v->hold_n, step = v->step;
        for (int sb = 0; sb < 8; sb++) {
            const int32_t crush = RAMP(P_CRUSH, sb);
            for (int i = sb * SUB; i < sb * SUB + SUB; i++) {
                if (++cnt >= hold_n) {
                    cnt = 0;
                    held_s = pb[i] & ~(step - 1);
                }
                pb[i] += ((held_s - pb[i]) * crush) >> 15;
            }
        }
        v->cnt = cnt; v->held_s = held_s;
    }
    /* the Quindar tones and the squelch, on the owner voice */
    if (vi == q_owner && (q_left > 0 || sq_left > 0))
        for (int i = 0; i < HALF; i++) {
            if (q_left > 0) {
                const int32_t env = q_left < QFADE ? q_left : QLEN - q_left < QFADE ? QLEN - q_left : QFADE;
                pb[i] += (((sinq(q_ph) * q_level) >> 15) * env) >> 5;
                q_ph += q_inc;
                q_left--;
            } else if (sq_left > 0) {
                pb[i] += ((((int32_t)lcg(&noise) >> 16) * sq_level >> 15) * sq_left) >> 11;
                sq_left--;
            }
        }
    if (beeping) {                                               /* out: velocity, interpolated 2x */
        int32_t last = v->last;
        for (int i = 0; i < HALF; i++) {
            const int32_t y = (pb[i] * gain) >> 15;
            out[2 * i] = (int16_t)clamp((last + y) >> 1, -32768, 32767);
            out[2 * i + 1] = (int16_t)clamp(y, -32768, 32767);
            last = y;
        }
        v->last = last;
    }
#undef RAMP
#undef RAMP4
    for (int k = 0; k < NP; k++) v->p[k] = t[k];
    v->hold_n = 1 + ((t[P_CRUSH] * 3) >> 15);
    v->step = 1 << (3 + ((t[P_CRUSH] * 6) >> 15));
    v->noise = noise;
    eva_blocks++;
}

const op1_engine_t ENGINE_eva = { eva_note_on, eva_render, eva_note_off,
                                  { OP1_PRESS_NONE, OP1_PRESS_NONE, OP1_PRESS_NONE, OP1_PRESS_PAGE } };

/* ======================= screen (GUI thread) =======================
 * eva.svg (gen_svg.py, from the artist's drawing eva-art.svg; numbers in eva_geom.h):
 *   m0..m3  the four meters (blue PRESSURE, green FREQ, white OXYGEN, red COM): 0..16 lit ticks with the knob. Each
 *           mask (black box + dim ticks) slides right one tick per lit tick; a full meter moves it off screen; the
 *           SVG's black cover hides the dim ticks pushed past the last one
 *   cross   the visor crosshair follows FREQ across the visor, from the left eye to the right eye
 *   fog     the visor fogs up from its bottom edge with the breathing: the engine's breath level while notes play,
 *           else a slow breath scaled by OXYGEN
 *   strip   the red radio strip on the visor: off at COM 0, blinks while a Quindar beep plays, drops out with the
 *           carrier; the red meter flickers with COM (and falls to 0..2 ticks during a dropout) */
#define ONE 1024
static void *e_mask[4], *e_cross, *e_fog, *e_strip;
static uint32_t last_blocks, frame, seed = 0x1234567u;
static int32_t act, fog;
static void *e_com_label, *e_beep[3];

static void move(void *e, int32_t tx, int32_t ty)                  /* Q10 */
{
    if (!e) return;
    const int32_t m[9] = { ONE, 0, 0, 0, ONE, 0, tx, ty, ONE };
    op1_node_set_transform(e, m);
}

static void eva_screen_init(void *scr)
{
    static const char *const masks[4] = { "m0", "m1", "m2", "m3" };
    for (int i = 0; i < 4; i++) e_mask[i] = op1_find_node(scr, masks[i]);
    e_cross = op1_find_node(scr, "cross");
    e_fog = op1_find_node(scr, "fog");
    e_strip = op1_find_node(scr, "strip");
    e_com_label=op1_find_node(scr,"com-label");
    static const char *const labels[]={"beep0","beep1","beep2"};
    for(int i=0;i<3;i++)e_beep[i]=op1_find_node(scr,labels[i]);
}

static inline uint32_t rnd(void) { return (seed = seed * 1664525u + 1013904223u) >> 16; }

static void eva_screen_update(void *scr, int dt)
{
    int16_t kn[4];
    op1_synth_knobs_live(OP1_SCREEN_SLOT & 7, kn);
    int32_t k[4];
    for (int i = 0; i < 4; i++) k[i] = kn[i] < 0 ? 0 : kn[i];
    const uint32_t blocks = eva_blocks;
    const int on = blocks != last_blocks;
    last_blocks = blocks;
    act += ((on ? ONE : 0) - act) >> 3;
    frame++;

    const int dropout = on && eva_gate < 24000;
    /* red flicker: a few frames out of many at low COM, often near the top; any dropout */
    const int flick = dropout || (on && k[3] > 4096 && (int32_t)(rnd() & 0x7FFF) < ((k[3] - 4096) >> 3));
    for (int i = 0; i < 4; i++) {
        int32_t n = (k[i] * 16 + 16383) >> 15;
        if (i == 3 && flick) n = dropout ? (int32_t)(rnd() % 3) : n - 1 - (int32_t)(rnd() % 3);
        if (n < 0) n = 0;
        move(e_mask[i], n >= 16 ? OP1_Q10(200) : n * EVA_TICK_DX, 0);
    }

    /* crosshair: from the left eye (FREQ 0, the artist's spot) to the right eye (100 %) */
    move(e_cross, k[1] * EVA_CROSS_SPAN / 32767, 0);

    /* fog: 0..1 (Q10), scaled up from the visor's bottom edge */
    int32_t target;
    if (act > ONE / 2) {
        target = eva_breath >> 5;
    } else {                                                        /* resting breath, ~0.25 Hz at 60 frames/s */
        const int32_t s = OP1_SINE_TABLE[(frame * 34) & 8191], inh = s > 0 ? s : 0;
        target = ((k[2] >> 5) * (128 + ((inh * 896) >> 15))) >> 10;
    }
    fog += (target - fog) >> 2;
    const int32_t f = fog < 20 ? 20 : fog > ONE ? ONE : fog, sxf = 154 + ((f * 870) >> 10);
    if (e_fog) {
        const int32_t m[9] = { sxf, 0, 0, 0, f, 0, EVA_FOG_X - ((sxf * EVA_FOG_X) >> 10),
                               EVA_FOG_Y - ((f * EVA_FOG_Y) >> 10), ONE };
        op1_node_set_transform(e_fog, m);
    }

    /* radio strip: off at COM 0, blinks with a beep, gone with the carrier */
    const int show = k[3] > 0 && !dropout && !(on && eva_beep && (frame & 4)) && !(flick && (frame & 1));
    move(e_strip, 0, show ? 0 : OP1_Q10(-200));

    unsigned bo=beep_octave(op1_synth_knobs(OP1_SCREEN_SLOT & 7));
    int page=op1_eng_page[3]!=0;
    op1_node_set_visible(e_com_label,!page);
    for(int i=0;i<3;i++)op1_node_set_visible(e_beep[i],page && (unsigned)i==bo);
    if(page)move(e_mask[3],(bo==0?1:bo==1?8:15)*EVA_TICK_DX,0);
    op1_screen_draw(scr, dt);
}

const op1_screen_t SCREEN_eva = { eva_screen_init, eva_screen_update };
