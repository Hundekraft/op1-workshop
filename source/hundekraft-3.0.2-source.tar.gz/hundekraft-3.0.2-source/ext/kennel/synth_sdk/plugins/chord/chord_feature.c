/* chord mode as a feature plugin (kind 3): the source lives in chord/chord.c; this folder makes it a plugin.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../chord/chord.c"
