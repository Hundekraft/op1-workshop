/* peal as a sequencer-type feature (op1_feature_seq.h): the source lives in seq/peal.c; this folder makes it a
 * plugin (compiled in, or content/peal.knl when "loadable").
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../seq/peal.c"
#include "../../op1_feature_seq.h"

static int pl_key_ev(int mode, int code, int pressed, int shift)
{
    (void)mode; (void)pressed; (void)shift;
    return code >= 0x0A && code <= 0x0C;                        /* lift / drop / scissors: nothing (finger is not running) */
}
static const op1_seq_type_t pl_type = {
    .name = "peal", .player = pl_player_get, .svg = "peal.svg", .screen = &SCREEN_peal,
    .key = pl_key_ev, .press = pl_press,                        /* gap, that's all, Bob (Shift: Single), look to */
    .turn = pl_turn,                                            /* method rate call rough; Shift: oct gate level run */
    .shift_wants = pl_shift_wants, .midi_start = pl_midi_start };
const op1_feature_t FEATURE_peal = { .api = OP1_FEATURE_API, .priority = 1000, .name = "peal", .seq = &pl_type };
