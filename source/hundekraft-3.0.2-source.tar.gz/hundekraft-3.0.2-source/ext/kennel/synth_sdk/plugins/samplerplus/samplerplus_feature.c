/* Native sampler+ registration. Copyright (C) 2026 Hundekraft; GPL-3.0-or-later + OP-1 firmware permission. */
#include "../../op1_synth.h"
#include "../../op1_feature.h"
extern const op1_samplerplus_t SAMPLERPLUS;
static void event(int id,int32_t arg){(void)arg;if(id==OP1_EV_REGISTER)op1_sampler_register(&SAMPLERPLUS);}
static const char *const claims[]={"sampler:synth",0};
const op1_feature_t FEATURE_samplerplus={.api=OP1_FEATURE_API,.priority=550,.name="samplerplus",.event=event,.claims=claims};
