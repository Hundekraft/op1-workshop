/* MBIRA: a thumb piano. Each note plucks a steel tine: four decaying partials (modal synthesis, sines with their own
 * decay) plus a short click, through a wooden box, with optional bottle-cap buzz.
 *   blue   STRIKE   soft thumb (dark, round) .. hard nail (bright click, strong upper partials)
 *   green  TINE     the tine's material: wood bar (1 : 4 : 9.8 : 17) .. steel tine (1 : 2 : 6.2 : 15.6, the kalimba's
 *                   weak octave from the box) .. glass (1 : 2.76 : 5.40 : 8.93, bell-like)
 *   white  BOX      the box resonance (a low band-pass about 220 Hz fed by the tine) and its thump
 *   red    BUZZ     bottle caps on a wire rattle against the tine while it swings wide (sizzle that follows the
 *                   fundamental and dies with it)
 * Page 2 (press the encoder; the words are saved with the sound, 0 = off / natural):
 *   blue   word 5  RING     how long the tine rings: 1.6 s (0) .. 8 s
 *   green  word 6  DOUBLE   a second tine tuned up to 12 cents sharp: slow beating, a chorus of two tines
 *   white  word 7  WAH      the player's hand over the sound hole: a band-pass sweeping 400 Hz .. 1.5 kHz at
 *                           5 Hz, depth = word
 * The partial decays and pitches are set once per block; amplitudes ramp across the block, so knob changes never
 * jump at the first sample. Notes above the tine's range lose the partials that would pass 19 kHz.
 * Cost (the unit adds SDRAM stalls to bcore's count, so the budget is tight): the block is built in passes over a
 * buffer, two partials per pass; a partial 60 dB under the fundamental (or under -80 dBFS) is dropped for the rest of
 * the note; the divisions run only when TINE, RING, DOUBLE or the pitch change; the box runs at 5.5 kHz, the wah at
 * 22 kHz, the buzz contact every 8 samples (the noise skipped while the caps are off the tine). A restrike resets
 * the voice's partials (no second set rings on). Coefficient and increment caches survive restrikes when their
 * control/pitch keys match, so the first render does not repeat unchanged divisions.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "op1_plugin.h"

#define NP 5                                  /* partials 0..3 + the double tine */
#define Q24 (1 << 24)

typedef struct {
    uint32_t ph[NP];                          /* partial phases */
    uint32_t pinc[NP];                        /* previous block's phase increments (ramped from) */
    int fresh;                                /* first block of a note: no ramp */
    int coeff_valid;                          /* cached across restrikes; keys below own invalidation */
    int32_t amp[NP];                          /* partial amplitudes, Q24 */
    int32_t click;                            /* click envelope, Q15 */
    uint32_t noise;
    int32_t clp, nprev, zlp;                  /* click low-pass, previous noise sample (buzz high-pass), buzz low-pass */
    int32_t blo, bbd, bo, bp;                 /* box band-pass, its last two outputs */
    int32_t wlo, wbd, wo, wp;                 /* wah band-pass, its last two outputs */
    uint32_t wph;                             /* wah LFO */
    int32_t box, buzz, wah, dmix;             /* previous block's mix levels, Q15 */
    int32_t level;                            /* screen: fundamental amplitude, Q15 */
    int32_t rat[NP], dk[NP];                  /* partial ratios (Q16) and decay factors (Q15) ... */
    int32_t kt, kring, kdbl, khz, knew;       /* ... for these TINE, RING, DOUBLE and pitch (knew: changed) */
    uint32_t inc[NP], kinc0;                  /* partial phase increments for this pitch */
} voice_t;

static voice_t voices[OP1_VOICES];
static volatile int32_t mb_click[OP1_VOICES], mb_level[OP1_VOICES];   /* for the screen */
static volatile uint32_t mb_pitch[OP1_VOICES], mb_blocks;

/* partial ratios (Q16) and levels (Q15) of the three tines: wood, steel, glass */
static const int32_t RATIO[3][4] = {
    { 65536, 262144, 642253, 1114112 },
    { 65536, 131072, 406323, 1022362 },
    { 65536, 180879, 353894, 585236 },
};
static const int32_t LEVEL[3][4] = {
    { 32767, 9830, 4915, 1638 },
    { 32767, 5243, 13107, 4915 },
    { 32767, 16384, 9830, 6554 },
};

static inline int32_t clampi(int32_t x, int32_t lo, int32_t hi) { return x < lo ? lo : x > hi ? hi : x; }
/* op1_sat16 as min / max: gcc turns op1_sat16 of a product into compares and branches */
static inline int16_t sat16(int32_t x) { return (int16_t)clampi(x, -32768, 32767); }
static inline int32_t knob(const int16_t *p, int i) { return p[i] < 0 ? 0 : p[i]; }
static inline int32_t sine(uint32_t ph) { return OP1_SINE_TABLE[ph >> 19]; }
static inline uint32_t lcg(uint32_t *s) { return *s = *s * 1664525u + 1013904223u; }

/* tine morph: TINE 0..32767 across wood -> steel -> glass */
static void tine(int32_t t, int k, int32_t *ratio, int32_t *level)
{
    const int a = t < 16384 ? 0 : 1;
    const int32_t f = t < 16384 ? t * 2 : (t - 16384) * 2;                 /* 0..32767 within the pair */
    /* Exact signed Q15 product, decomposed to avoid the 64-bit helper. */
    const int32_t d=RATIO[a+1][k]-RATIO[a][k];
    *ratio = RATIO[a][k] + (d>>15)*f + (((d&32767)*f)>>15);
    *level = LEVEL[a][k] + (((LEVEL[a + 1][k] - LEVEL[a][k]) * f) >> 15);
}

/* per-block decay factor (Q15) for a decay time tau in ms (amplitude falls by e over tau) */
static inline int32_t decay(int32_t tau_ms)
{
    if (tau_ms < 20) tau_ms = 20;
    return 32768 - 95108 / tau_ms;                                         /* 1 - 128 / (tau * 44.1) */
}

static void mb_note_on(void *self, const int16_t *p)
{
    const int vi = op1_voice_index(self);
    voice_t *v = &voices[vi];
    const int32_t strike = knob(p, 0), t = knob(p, 1);
    const int32_t bright = 6554 + ((strike * 26214) >> 15);               /* 0.2 .. 1.0 */
    for (int k = 0; k < 4; k++) {
        /* note_on needs the level only; avoid calculating an unused ratio. */
        const int bank=t<16384?0:1;
        const int32_t f=t<16384?t*2:(t-16384)*2;
        int32_t a = LEVEL[bank][k] + (((LEVEL[bank+1][k]-LEVEL[bank][k])*f)>>15);
        for (int j = 0; j < k; j++) a = (a * bright) >> 15;               /* upper partials follow the strike */
        v->amp[k] = a << 9;
        v->ph[k] = 0;
    }
    v->amp[4] = (v->amp[0] >> 4) * 11;                                     /* the double tine, 0.69 of the first */
    v->ph[4] = 0x40000000u;
    v->fresh = 1;
    v->click = 32767;
    v->noise = 0x9E3779B9u ^ ((uint32_t)vi * 0x85EBCA6Bu);
    v->clp = v->nprev = v->zlp = 0;
    v->blo = v->bbd = v->bo = v->bp = v->wlo = v->wbd = v->wo = v->wp = 0;
    v->box = knob(p, 2);
    v->buzz = knob(p, 3);
    v->wah = p[7] < 0 ? 0 : p[7];
    v->dmix = p[6] > 0 ? 11469 + ((p[6] * 4000) >> 15) : 0;
}

static void mb_note_off(void *self) { (void)self; }   /* the firmware's release envelope ends the note */

/* Share a small, bounded history across voice slots: fast melodies often
 * reuse a pitch on a different slot. The voice-local fast path stays unchanged. */
#define COEFF_CACHE 16
static struct {int valid;int32_t t,ring,dbl,hz,rat[NP],dk[NP];} coeff_cache[COEFF_CACHE];
static unsigned coeff_next;

/* the partials' ratios and per-block decay factors, recomputed only when TINE, RING, DOUBLE or (above 262 Hz, to
 * 8 Hz) the pitch changes, so the divisions stay out of the steady state */
static void coeffs(voice_t *v, int32_t t, int32_t ring, int32_t dbl, int32_t hz)
{
    const int32_t hk = hz > 262 ? hz & ~7 : 0;
    if (v->coeff_valid && t == v->kt && ring == v->kring && dbl == v->kdbl && hk == v->khz) return;
    v->coeff_valid = 1;
    v->kt = t; v->kring = ring; v->kdbl = dbl; v->khz = hk; v->knew = 1;
    for(unsigned i=0;i<COEFF_CACHE;i++){
        if(coeff_cache[i].valid && coeff_cache[i].t==t && coeff_cache[i].ring==ring &&
           coeff_cache[i].dbl==dbl && coeff_cache[i].hz==hk){
            for(int k=0;k<NP;k++){v->rat[k]=coeff_cache[i].rat[k];v->dk[k]=coeff_cache[i].dk[k];}
            return;
        }
    }
    int32_t tau0 = 1600 + ((ring * 6400) >> 15);                           /* ms: 1.6 .. 8 s */
    if (hk) tau0 = (tau0 * 262) / hk + tau0 / 4;                            /* high tines ring shorter */
    for (int k = 0; k < NP; k++) {
        int32_t r, l;
        tine(t, k < 4 ? k : 0, &r, &l);
        if (k == 4) r += (r >> 10) * ((dbl * 7) >> 15);                    /* up to +0.7 %: 12 cents */
        v->rat[k] = r;
        const int32_t tau = k == 0 || k == 4 ? tau0 : (tau0 * 131072) / (r + 65536) + 40;   /* ~2 / (ratio + 1) */
        v->dk[k] = decay(tau);
    }
    unsigned slot=coeff_next++&(COEFF_CACHE-1);
    coeff_cache[slot].t=t;coeff_cache[slot].ring=ring;
    coeff_cache[slot].dbl=dbl;coeff_cache[slot].hz=hk;
    for(int k=0;k<NP;k++){coeff_cache[slot].rat[k]=v->rat[k];coeff_cache[slot].dk[k]=v->dk[k];}
    coeff_cache[slot].valid=1;
}

/* the live partials into the block, two per pass (one load and store of the block for both): phases gliding to the
 * new pitch (only when it moved), amplitudes ramping (Q24) in steps of 8 samples (a step is under 0.4 % of the level,
 * even for the fastest decay), each at half level (four partials: headroom); the first
 * pass writes the block, the others add */
typedef struct { uint32_t *ph, c; int32_t d, a, st; } part_t;
static inline void pass2(int32_t *acc, part_t *x, part_t *y, int first, int glide)
{
    uint32_t pa = *x->ph, ca = x->c, pb = *y->ph, cb = y->c;
    int32_t aa = x->a, ab = y->a;
    const int32_t da = x->d, db = y->d, sa = x->st, sb = y->st;
    for (int i = 0; i < OP1_BLOCK; i += 8) {
        const int32_t ga = aa >> 10, gb = ab >> 10;                        /* Q14: the two products sum within 2^30 */
        for (int j = i; j < i + 8; j++) {
            pa += ca;
            pb += cb;
            if (glide) { ca += (uint32_t)da; cb += (uint32_t)db; }
            const int32_t s = (sine(pa) * ga + sine(pb) * gb) >> 15;
            acc[j] = first ? s : acc[j] + s;
        }
        aa += sa * 8;
        ab += sb * 8;
    }
    *x->ph = pa;
    *y->ph = pb;
}
static inline void pass1(int32_t *acc, part_t *x, int first, int glide)
{
    uint32_t pa = *x->ph, ca = x->c;
    int32_t aa = x->a;
    const int32_t da = x->d, sa = x->st;
    for (int i = 0; i < OP1_BLOCK; i += 8) {
        const int32_t ga = aa >> 9;
        for (int j = i; j < i + 8; j++) {
            pa += ca;
            if (glide) ca += (uint32_t)da;
            const int32_t s = (sine(pa) * ga) >> 16;
            acc[j] = first ? s : acc[j] + s;
        }
        aa += sa * 8;
    }
    *x->ph = pa;
}
static void partials(int32_t *acc, part_t *l, int n, int glide)
{
    for (int i = 0; i < n; i += 2) {
        const int first = i == 0;
        if (i + 1 < n) {
            if (glide) { if (first) pass2(acc, &l[i], &l[i + 1], 1, 1); else pass2(acc, &l[i], &l[i + 1], 0, 1); }
            else { if (first) pass2(acc, &l[i], &l[i + 1], 1, 0); else pass2(acc, &l[i], &l[i + 1], 0, 0); }
        } else {
            if (glide) { if (first) pass1(acc, &l[i], 1, 1); else pass1(acc, &l[i], 0, 1); }
            else { if (first) pass1(acc, &l[i], 1, 0); else pass1(acc, &l[i], 0, 0); }
        }
    }
}

static void mb_render(void *self, int16_t *out, const int16_t *p)
{
    const int vi = op1_voice_index(self);
    voice_t *v = &voices[vi];
    const int32_t strike = knob(p, 0), t = knob(p, 1), box = knob(p, 2), buzz = knob(p, 3);
    const int32_t ring = p[5] < 0 ? 0 : p[5], dbl = p[6] < 0 ? 0 : p[6], wah = p[7] < 0 ? 0 : p[7];
    const uint32_t inc0 = (uint32_t)OP1_PITCH_INC[0];
    coeffs(v, t, ring, dbl, (int32_t)(((inc0 >> 16) * 44100u) >> 16));
    /* partial pitches and amplitude steps for this block */
    uint32_t inc[NP];
    int32_t end[NP], step[NP], dinc[NP];
    if (inc0 != v->kinc0 || v->knew) {                                    /* the partials' pitches, when they change */
        v->kinc0 = inc0;
        v->knew = 0;
        for (int k = 0; k < NP; k++) {
            const uint64_t f = ((uint64_t)inc0 * (uint32_t)v->rat[k]) >> 16;
            v->inc[k] = f > 0x70000000u ? 0 : (uint32_t)f;                   /* past ~19 kHz: silent */
        }
    }
    for (int k = 0; k < NP; k++) {
        inc[k] = v->inc[k];
        if (!inc[k]) v->amp[k] = 0;
        const int32_t a = v->amp[k];
        const int32_t e = (int32_t)((((uint32_t)a >> 8) * (uint32_t)v->dk[k]) >> 7);
        step[k] = (e - a) >> 7;
        end[k] = a + step[k] * OP1_BLOCK;
        if (v->fresh) v->pinc[k] = inc[k];                                 /* pitches glide across the block */
        dinc[k] = (int32_t)(inc[k] - v->pinc[k]) >> 7;
    }
    v->fresh = 0;
    /* mix levels ramp from the previous block's values */
    const int32_t dmix1 = dbl > 0 ? 11469 + ((dbl * 4000) >> 15) : 0;      /* double tine level, Q15 */
    const int32_t dmix0 = v->dmix;
    const int32_t box0 = v->box, dbox = (box - box0) >> 7, buzz0 = v->buzz, dbuzz = (buzz - buzz0) >> 7;
    const int32_t wah0 = v->wah, dwah = (wah - wah0) >> 7;
    const int32_t vg = op1_voice_vel_gain(self);

    /* the tine: partial 0 always (it writes the block), the others while they sound (a partial below -80 dBFS is
     * dropped for the rest of the note), the double tine scaled by its mix level */
    int32_t acc[OP1_BLOCK];
    const uint32_t ph0 = v->ph[0], c0 = v->pinc[0];
    part_t live[NP];
    int n = 0, glide = 0;
    for (int k = 0; k < 4; k++)
        if (!k || v->amp[k]) {
            live[n++] = (part_t){ &v->ph[k], v->pinc[k], dinc[k], v->amp[k], step[k] };
            glide |= dinc[k];
        }
    if ((v->amp[4] | end[4]) && (dmix0 | dmix1)) {                       /* level x mix as one ramp */
        const int32_t a0 = ((v->amp[4] >> 8) * dmix0) >> 7, a1 = ((end[4] >> 8) * dmix1) >> 7;
        live[n++] = (part_t){ &v->ph[4], v->pinc[4], dinc[4], a0, (a1 - a0) >> 7 };
        glide |= dinc[4];
    } else v->ph[4] += v->pinc[4] * OP1_BLOCK + (uint32_t)dinc[4] * (OP1_BLOCK * (OP1_BLOCK - 1) / 2);
    partials(acc, live, n, glide != 0);

    /* click: noise burst through a low-pass, while it lasts */
    int32_t click = v->click, clp = v->clp;
    uint32_t noise = v->noise;
    if (click > 8 || clp) {
        const int32_t cf = 32034 + (((32767 - strike) * 586) >> 15);       /* click per sample: 1 ms (hard) .. 5 ms */
        const int32_t clp_a = 3000 + ((strike * 24000) >> 15);              /* click low-pass, Q15 */
        for (int i = 0; i < OP1_BLOCK; i++) {
            const int32_t n = (int32_t)lcg(&noise) >> 16;
            if (click > 8) {
                clp += ((((n * click) >> 15) - clp) * clp_a) >> 15;
                click = (click * cf) >> 15;
            } else {
                clp -= clp >> 4;
            }
            acc[i] += clp >> 1;
        }
        if (click <= 8 && clp > -16 && clp < 16) clp = 0;                    /* the tail's last LSBs: done */
    }
    /* box: band-pass about 220 Hz (f = 0.25 at 5.5 kHz, damping 0.25), run on the average of 8 samples (its nulls at
     * 5.5 kHz keep the decimation clean) and interpolated back between its last two outputs, 8 samples late */
    int32_t blo = v->blo, bbd = v->bbd, bo = v->bo, bp = v->bp;
    if (box0 | box) {
        int32_t bx = box0;
        for (int i = 0; i < OP1_BLOCK; i += 8) {
            int32_t *q = acc + i, in = 0;
            for (int j = 0; j < 8; j++) in += q[j];
            const int32_t d = (bo - bp) >> 3;
            int32_t o = bp;
            for (int j = 0; j < 8; j++) { o += d; q[j] += o; }
            bp = bo;
            blo = clampi(blo + (bbd >> 2), -131071, 131071);
            bbd = clampi(bbd + (((in >> 3) - blo - (bbd >> 2)) >> 2), -131071, 131071);
            bo = (((bbd * (bx >> 2)) >> 13) * 3) >> 2;
            bx += dbox * 8;
        }
    } else bo = bp = 0;
    /* buzz: band-passed noise (high-pass difference, low-pass ~7 kHz) while the fundamental swings past 70 %; the
     * caps' contact rises smoothly from 0 at 70 % to full at the peak, so the sizzle has no hard on / off edges; the
     * contact (with the tine's level and BUZZ) is set every 8 samples, and the noise skipped while it is 0 (half of
     * each swing; the filter's state then waits, which the contact's slow rise hides) */
    int32_t nprev = v->nprev, zlp = v->zlp;
    if (buzz0 | buzz) {
        uint32_t ph = ph0, c = c0;
        int32_t a = v->amp[0], bz = buzz0;
        for (int i = 0; i < OP1_BLOCK; i += 8) {
            const int32_t s = sine(ph + c), as = s < 0 ? -s : s;
            const int32_t g = as > 22937 ? ((as - 22937) * 3) + ((as - 22937) >> 3) : 0;   /* 0 .. ~32700, Q15 */
            const int32_t gz = (((((a + step[0]) >> 10) * g) >> 15) * bz) >> 15;
            ph += c << 3;
            c += (uint32_t)dinc[0] << 3;
            a += step[0] * 8;
            bz += dbuzz * 8;
            if (!gz) continue;                                              /* caps off the tine: silent */
            for (int j = i; j < i + 8; j++) {
                const int32_t n = (int32_t)lcg(&noise) >> 16;
                zlp += (((n - nprev) >> 1) - zlp) >> 1;
                acc[j] += (zlp * gz) >> 15;
                nprev = n;
            }
        }
    }
    /* wah: band-pass sweep, mixed in by depth; centre this block 400 Hz .. 1.5 kHz (Chamberlin 2 sin(pi f / 22050),
     * Q13), run on sample pairs at half scale (the sum in the update then stays under 2^31 without a clamp), its output
     * interpolated between the last two (one pair late); then the voice's gain into out */
    int32_t wlo = v->wlo, wbd = v->wbd, wo = v->wo, wp = v->wp;
    const int32_t g = vg >> 2;                                              /* about -10 dBFS a note */
    const int32_t wf = 933 + (((sine(v->wph) + 32768) * 2562) >> 16);     /* Q13 */
    v->wph += 62144000u;                                                    /* 5 Hz per block */
    if (wah0 | wah) {
        int32_t w = wah0;
        for (int i = 0; i < OP1_BLOCK; i += 2) {
            const int32_t y0 = acc[i], y1 = acc[i + 1], wm = w >> 3;
            out[i] = sat16(((y0 + (((((wp + wo) >> 1) - y0) * wm) >> 12)) * g) >> 15);
            out[i + 1] = sat16(((y1 + (((wo - y1) * wm) >> 12)) * g) >> 15);
            wlo = clampi(wlo + ((wf * wbd) >> 13), -131071, 131071);
            wbd = clampi(wbd + ((wf * (((y0 + y1) >> 2) - wlo - ((2500 * wbd) >> 13))) >> 13), -131071, 131071);
            wp = wo;
            wo = wbd * 3;
            w += dwah * 2;
        }
    } else {
        wo = wp = 0;
        for (int i = 0; i < OP1_BLOCK; i++) out[i] = sat16((acc[i] * g) >> 15);   /* about -10 dBFS a note */
    }

    for (int k = 0; k < NP; k++) {
        v->pinc[k] = inc[k];
        v->amp[k] = end[k] < (4 << 9) || (k && end[k] < (end[0] >> 10)) ? 0 : end[k];   /* -80 dBFS, or 60 dB under the fundamental: gone */
    }
    v->click = click; v->clp = clp; v->nprev = nprev; v->zlp = zlp; v->noise = noise;
    v->blo = blo; v->bbd = bbd; v->bo = bo; v->bp = bp; v->wlo = wlo; v->wbd = wbd; v->wo = wo; v->wp = wp;
    v->box = box; v->buzz = buzz; v->wah = wah; v->dmix = dmix1;
    mb_level[vi] = v->amp[0] >> 9;
    mb_click[vi] = v->click;
    mb_pitch[vi] = inc0;
    mb_blocks++;
}

const op1_engine_t ENGINE_mbira = { mb_note_on, mb_render, mb_note_off,
                                    { OP1_PRESS_PAGE, OP1_PRESS_PAGE, OP1_PRESS_PAGE, OP1_PRESS_NONE } };

/* ======================= screen (GUI thread) =======================
 * mbira.svg and mbira_geom.h (OP1-Emulator docs/design/engine-screens/night/build_night2.py): a kalimba in three-
 * quarter view with a thumb plucking a tine, traced from the night concept, and four meters on the right (labels and
 * 12 dim ticks each). Drawn here:
 *   the meters' lit ticks: STRIKE (blue), TINE (green), BOX (white), BUZZ (red), 0 .. 12 with the knob as the voices
 *     hear it (op1_synth_knobs_live: LFO included); page 2 of a knob: its label turns to RING / DOUBLE / WAH (nodes
 *     l0..l2 / p0..p2) and its meter shows the page-2 word
 *   while a note rings: white vibration arcs by the plucked tine's tip (bigger with the level), sound rings
 *     spreading from the sound hole, and with BUZZ the caps rattle (red ticks round them) */
#include "mbira_geom.h"
#pragma GCC push_options
#pragma GCC optimize("Os")                             /* GUI code: size, not speed */
#define QP(v) ((int32_t)((v) * 1024))
static const uint8_t M_BLUE[4] = { 0x69, 0x8E, 0xFF, 0xFF }, M_GREEN[4] = { 0x00, 0xED, 0x95, 0xFF },
                     M_WHITE[4] = { 0xFF, 0xFF, 0xFF, 0xFF }, M_RED[4] = { 0xFF, 0x3A, 0x5D, 0xFF };
static const uint8_t *const M_COL[4] = { M_BLUE, M_GREEN, M_WHITE, M_RED };
static const int32_t M_ROW[4][2] = { { MB_ROW0_Y0, MB_ROW0_Y1 }, { MB_ROW1_Y0, MB_ROW1_Y1 }, { MB_ROW2_Y0, MB_ROW2_Y1 },
                                     { MB_ROW3_Y0, MB_ROW3_Y1 } };
static void *mb_lab[3][2];                                    /* page-1 / page-2 labels of the first three meters */
static uint32_t mb_frame, mb_rng = 7;

static void ln(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, const uint8_t *c)
{
    const op1_pt a = { x0, y0 }, b = { x1, y1 };
    op1_raster_line(r, &a, &b, w, c);
}

static void arc_of(void *r, int32_t cx, int32_t cy, int32_t rad, int32_t a0, int32_t a1, int32_t w, const uint8_t *c)
{                                                            /* arc, Q10 centre / radius, angles 0..8192 (y down) */
    int32_t px = cx + ((rad * OP1_SINE_TABLE[(a0 + 2048) & 8191]) >> 15), py = cy + ((rad * OP1_SINE_TABLE[a0 & 8191]) >> 15);
    for (int32_t a = a0 + 512; a <= a1; a += 512) {
        const int32_t x = cx + ((rad * OP1_SINE_TABLE[(a + 2048) & 8191]) >> 15), y = cy + ((rad * OP1_SINE_TABLE[a & 8191]) >> 15);
        ln(r, px, py, x, y, w, c);
        px = x; py = y;
    }
}

static void mb_screen_init(void *scr)
{
    static const char *const ids[3][2] = { { "l0", "p0" }, { "l1", "p1" }, { "l2", "p2" } };
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 2; j++) {
            mb_lab[i][j] = op1_find_node(scr, ids[i][j]);
            op1_node_set_visible(mb_lab[i][j], j == 0);
        }
}

static void mb_screen_update(void *scr, int dt)
{
    int16_t kn[4];
    op1_synth_knobs_live(OP1_SCREEN_SLOT & 7, kn);
    const int16_t *words = op1_synth_knobs(OP1_SCREEN_SLOT & 7);
    int32_t v[4];
    for (int i = 0; i < 4; i++) {
        const int page2 = i < 3 && op1_eng_page[i];
        v[i] = page2 ? words[5 + i] : kn[i];
        if (v[i] < 0) v[i] = 0;
        if (i < 3) { op1_node_set_visible(mb_lab[i][0], !page2); op1_node_set_visible(mb_lab[i][1], page2); }
    }
    op1_screen_draw_cached(scr, dt, mb_lab[0][0]);
    void *r = op1_raster();
    mb_frame++;

    /* the meters: 0 .. 12 lit ticks */
    for (int i = 0; i < 4; i++) {
        const int n = (v[i] * 12 + 16383) >> 15;
        for (int t = 0; t < n && t < 12; t++) {
            const int32_t x = MB_TICK_X0 + t * MB_TICK_DX;
            ln(r, x, M_ROW[i][0], x, M_ROW[i][1], 0x6CC, M_COL[i]);
        }
    }

    /* the loudest voice drives the vibration, the sound rings and the caps */
    int32_t loud = 0;
    for (int vo = 0; vo < OP1_VOICES; vo++) if (mb_level[vo] > loud) loud = mb_level[vo];
    if (loud < 256) return;
    const int32_t lv = loud > 32767 ? 32767 : loud;
    /* white vibration arcs by the tip: two, 3 .. 9 px out, shimmering */
    const int32_t sh = (OP1_SINE_TABLE[(mb_frame * 2600) & 8191] * QP(1)) >> 15;
    for (int a = 0; a < 2; a++) {
        const int32_t rad = QP(4) + a * QP(3) + ((lv * QP(3)) >> 15) + sh;
        arc_of(r, MB_TIP_X, MB_TIP_Y, rad, 6144 + 512, 8192 + 1024, 0x600, M_WHITE);
    }
    /* sound rings from the hole: one ring spreading 6 .. 26 px over 20 frames, again while it rings */
    const int32_t ph = (int32_t)(mb_frame % 20);
    arc_of(r, MB_HOLE_X, MB_HOLE_Y, QP(6) + ph * QP(1), 2048 + 1024, 4096 + 2048, 0x500, M_WHITE);
    /* caps: up to 6 red rattle ticks round each, with BUZZ */
    const int ticks = (kn[3] < 0 ? 0 : kn[3]) * 6 >> 15;
    for (int c = 0; c < 2; c++) {
        const int32_t cx = c ? MB_CAP1_X : MB_CAP0_X, cy = c ? MB_CAP1_Y : MB_CAP0_Y;
        for (int t = 0; t < ticks; t++) {
            mb_rng = mb_rng * 1664525u + 1013904223u;
            const int32_t a = (int32_t)(t * 1365 + (mb_rng >> 22)) & 8191;
            const int32_t s = OP1_SINE_TABLE[a], co = OP1_SINE_TABLE[(a + 2048) & 8191];
            ln(r, cx + ((QP(11) >> 5) * co >> 10), cy + ((QP(11) >> 5) * s >> 10),
               cx + ((QP(14) >> 5) * co >> 10), cy + ((QP(14) >> 5) * s >> 10), 0x500, M_RED);
        }
    }
}
#pragma GCC pop_options

const op1_screen_t SCREEN_mbira = { mb_screen_init, mb_screen_update };
