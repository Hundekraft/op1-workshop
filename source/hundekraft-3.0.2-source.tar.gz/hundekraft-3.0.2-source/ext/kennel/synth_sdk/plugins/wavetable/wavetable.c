/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* "wavetable": two detuned wavetable oscillators into an analog-style 4-pole ladder filter.
 * blue   (knob 0): wave position, morphing sine -> warm -> triangle -> saw -> square -> pulse -> vocal -> digital
 * green  (knob 1): detune between the two oscillators, 0 to about +-14 cents
 * white  (knob 2): cutoff, 30 Hz to 16 kHz (exponential)
 * orange (knob 3): resonance up to self-oscillation, with the drive into the filter rising alongside
 * Follows note velocity like op1r's engines. Int-only; per sample: 2 x (2 interpolated table reads + crossfade),
 * 4 filter stages, 2 soft clips.
 */
#include "hk/engine.h"
#include "wavetable_dsp.h"

static WavetableState voices[ENGINE_VOICES];
volatile uint32_t wavetable_blocks; /* legacy screen's activity counter */

void engine_note_on(void *self, const int16_t *knobs)
{
    (void)knobs;
    wavetable_dsp_on(&voices[ENGINE_VOICE(self)]);
}

void engine_note_off(void *self, const int16_t *knobs)
{
    (void)self;
    (void)knobs;
}

/* the knobs as this block hears them (after the slot LFO), for the screen */
volatile int16_t wavetable_knobs[4];

void engine_render(void *self, int16_t *out, const int16_t *knobs)
{
    for (int i = 0; i < 4; i++) wavetable_knobs[i] = knobs[i];
    const int vi = ENGINE_VOICE(self);
    wavetable_dsp_render(&voices[vi], out, knobs, ENGINE_PITCH, ENGINE_VELOCITY(vi));
    wavetable_blocks++;
}

int32_t wavetable_shape(int32_t k0, uint32_t ph)
{
    return wavetable_dsp_shape(k0, ph);
}
