/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* The wave factory screen (wavetable.svg, docs/design/engine-screens/round5/build_round5.py) in motion. iter's
 * draw turns the hidden bar0..bar3; on top (screen px):
 *   active   the hopper's front card: its drawn sine is hidden and the wave being read (blue knob, the morph
 *            sine .. digital) is drawn live, one cycle over x 33.2..58.4 about y 33.4
 *   dots     the belt marks run toward the press while notes play
 *   gear0/1  the green gears turn while notes play, faster with more detune; at rest they sit at an angle
 *            set by the detune
 *   press    the white press sinks up to 10 px as the cutoff closes and pumps while notes play
 *   coil     the red spring in its tower squeezes to 55 % with the resonance, about its top (242.6, 53.4)
 */
#ifndef ENGINE_HOST_TEST
#include "hk/engine.h"

int32_t wavetable_shape(int32_t k0, uint32_t ph);
extern volatile uint32_t wavetable_blocks;
extern volatile int16_t wavetable_knobs[4];

#define PX(v) ((int32_t)(v) << 10)
#define ONE 1024
#define Q(v) ((int32_t)((v) * 1024))   /* screen px -> Q10 */

static void *e_active, *e_dots, *e_gear[2], *e_press, *e_coil;
static uint32_t last_blocks, gear_angle, pump;
static int32_t act, belt, press;
/* a knob as the voices hear it (after the slot LFO) while notes play, else as set */
#define K(i) screen_knob_live(wavetable_knobs, (i), act > 64)

static const uint8_t blue[4] = {0x69, 0x8E, 0xFF, 0xFF};

void engine_screen_load(void *screen)
{
    e_active = SVG_FIND(screen, "active");
    e_dots = SVG_FIND(screen, "dots");
    e_gear[0] = SVG_FIND(screen, "gear0");
    e_gear[1] = SVG_FIND(screen, "gear1");
    e_press = SVG_FIND(screen, "press");
    e_coil = SVG_FIND(screen, "coil");
}

void engine_screen_animate(void *screen)
{
    (void)screen;
    const uint32_t blocks = wavetable_blocks;              /* a voice rendered since the last frame */
    const int on = blocks != last_blocks;
    last_blocks = blocks;
    act += ((on ? ONE : 0) - act) >> 3;

    const int32_t detune = K(1), reso = K(3);
    /* belt marks: up to half a pixel per frame, back every 4 px (the marks are further apart than that) */
    belt = (belt + (act >> 1)) % PX(4);
    svg_move(e_dots, belt, 0);
    /* gears: the small one turns twice as fast the other way; the detune also sets a resting angle (a quarter
       turn over the knob) */
    gear_angle += (uint32_t)(((20 + (detune >> 8)) * act) >> 10);
    const uint32_t g = gear_angle + (uint32_t)((detune * 2048) >> 15);
    svg_turn(e_gear[0], g, Q(91.59), Q(113.46));
    svg_turn(e_gear[1], -2 * g, Q(139.07), Q(116.26));

    /* press: 0 px at the open cutoff, 10 px down when closed; eases toward it and pumps 1.5 px while playing */
    const int32_t down = (int32_t)(((int64_t)(32767 - K(2)) * PX(10)) >> 15);
    press += (down - press) >> 2;
    pump += (uint32_t)((160 * act) >> 10);
    const int32_t bob = (int32_t)(((int64_t)(SVG_SIN(pump) + 32767) * act) >> 15) * 3 / 4;
    svg_move(e_press, 0, press + bob);

    /* spring: 100 % .. 55 % long about its top with resonance */
    svg_scale(e_coil, ONE, ONE - ((reso * 461) >> 15), 0, Q(53.36));
    svg_move(e_active, 0, PX(400));                        /* drawn live */
}

static void line(void *canvas, int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    const svg_pt a = {x0, y0}, b = {x1, y1};
    SVG_LINE(canvas, &a, &b, 0x733, blue);                 /* 1.8 px */
}

void engine_screen_draw(void *screen, void *canvas)
{
    (void)screen;
    if (!canvas) return;
    /* the front card: one cycle of the morphed wave, +-3 px */
    const int32_t k0 = K(0);
    enum { N = 24 };
    int32_t px = 0, py = 0;
    for (int i = 0; i <= N; i++) {
        const int32_t x = Q(33.16) + i * (Q(58.39) - Q(33.16)) / N;
        const uint32_t ph = (uint32_t)(((uint64_t)i << 32) / N);
        const int32_t y = Q(33.35) - wavetable_shape(k0, ph) * 3 * ONE / 30000;
        if (i) line(canvas, px, py, x, y);
        px = x;
        py = y;
    }
}
#endif
