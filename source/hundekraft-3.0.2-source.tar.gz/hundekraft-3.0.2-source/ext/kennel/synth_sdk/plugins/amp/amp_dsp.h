/* Original fixed-point input strip; no TE algorithm or artwork. GPL-3.0-or-later with OP-1 permission. */
#ifndef AMP_DSP_H
#define AMP_DSP_H
#include <stdint.h>
typedef struct { int32_t dc_x,dc_y,low,env,gain,volume,tilt,drive,previous,shaped;uint32_t rate;int fade; } amp_dsp;
static inline int32_t amp_clip(int32_t x){return x>32767?32767:x< -32768?-32768:x;}
static inline int32_t amp_abs(int32_t x){return x<0?-x:x;}
/* Operands bounded to |a|<=131072 and nonnegative b<=8*32768. No 64-bit helper in audio. */
static inline int32_t amp_mul(int32_t a,int32_t b){return a*(b>>15)+(a>>15)*(b&32767)+(((a&32767)*(b&32767)+16384)>>15);}
static inline int32_t amp_soft(int32_t x){x=amp_clip(x);int32_t x2=(x*x)>>15;return (3*x-((x2*x)>>15))>>1;}
static inline void amp_dsp_reset(amp_dsp *s,uint32_t rate){
 s->dc_x=s->dc_y=s->low=s->env=s->previous=s->shaped=0;s->gain=32768;s->volume=32768;s->tilt=s->drive=0;s->rate=rate;s->fade=0;
}
static inline void amp_dsp_process(amp_dsp *s,const int16_t *in,int16_t *out,const int16_t *p){
 int32_t vol=2*(p[0]<0?0:p[0]),amt=p[1]<0?0:p[1],tilt=p[2]-16384,drive=p[3]<0?0:p[3];
 int32_t threshold=28000-((amt*24000)>>15),target=32768;
 if(amt&&s->env>threshold){int32_t desired=threshold+((s->env-threshold)>>2);target=(desired<<15)/s->env;}
 int32_t pole=s->rate==44100?32724:32680,lp=s->rate==44100?3353:6083;
 for(int i=0;i<64;i++){
  s->volume+=(vol-s->volume)>>6;s->tilt+=(tilt-s->tilt)>>6;s->drive+=(drive-s->drive)>>6;s->gain+=(target-s->gain)>>4;
  int32_t x=in[i],dc=x-s->dc_x+((s->dc_y*pole+16384)>>15);s->dc_x=x;s->dc_y=amp_clip(dc);x=s->dc_y;
  int32_t a=amp_abs(x);s->env+=(a-s->env)>>(a>s->env?4+(s->rate==44100):11+(s->rate==44100));
  x=(x*s->gain)>>15;s->low+=((x-s->low)*lp)>>15;
  /* complementary low/high tilt, centre unity, bounded intermediate */
  int32_t gl=32768-s->tilt,gh=32768+s->tilt;
  x=amp_mul(s->low,gl)+amp_mul(x-s->low,gh);
  int32_t pre=32768+7*s->drive;
  int32_t sh=amp_soft(amp_mul(x,pre));
  int32_t mid=amp_soft(amp_mul((x+s->previous)>>1,pre));
  int32_t wet=(s->shaped+2*mid+sh)>>2;s->shaped=sh;s->previous=x;
  /* Linear interpolation + three-tap decimation at 2x only around drive.
   * Amount blends smoothly to exact clean input, no discontinuity at zero. */
  x=amp_mul(x,32768-s->drive)+amp_mul(wet,s->drive);
  x=amp_mul(x,s->volume);
  if(s->fade<64)s->fade++;
  out[i]=(int16_t)amp_clip((x*s->fade)>>6);
 }
}
#endif
