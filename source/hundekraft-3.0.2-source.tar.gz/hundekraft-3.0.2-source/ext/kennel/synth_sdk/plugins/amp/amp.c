/* Optional Amp input instrument, original design inspired by Field's workflow.
 * GPL-3.0-or-later with OP-1 firmware permission. */
#include "../../op1_input.h"
#include "../../sampletools/st_pitch.h"
#include "../../seq/seq_text.h"
#include "amp_dsp.h"
#define BARRIER() __asm__ volatile("" ::: "memory")
static amp_dsp dsp;
static struct { int16_t x[ST_PITCH_N];volatile uint32_t state,epoch,rate; } capture[2];
static volatile uint32_t epoch,enabled,result_epoch,display;
static volatile int32_t input_peak,output_peak;
static uint32_t capture_pos,capture_which;
static st_pitch_work work;
static int job=-1;
static int tuning;
static uint32_t job_epoch;
static void reset(int slot,uint32_t rate){
 enabled=slot>=0;epoch++;capture_pos=0;input_peak=output_peak=0;
 /* Only audio writes FREE buffers; never reset a READY/BUSY worker-owned window. */
 amp_dsp_reset(&dsp,rate);
}
static void process(const int16_t *in,int16_t *out,const int16_t *p,uint32_t rate){
 if(dsp.rate!=rate)reset(0,rate);
 amp_dsp_process(&dsp,in,out,p);
 int32_t ip=0,op=0;for(int i=0;i<64;i++){int32_t a=amp_abs(in[i]),b=amp_abs(out[i]);if(a>ip)ip=a;if(b>op)op=b;}
 input_peak=ip;output_peak=op;
 int requested=op1_input_tuner_active();
 if(tuning!=requested){tuning=requested;epoch++;capture_pos=0;}
 if(!tuning)return;
 unsigned b=capture_which;
 if(capture[b].state){b^=1;capture_which=b;capture_pos=0;}
 if(!capture[b].state){
  if(!capture_pos){capture[b].epoch=epoch;capture[b].rate=rate;}
  for(unsigned i=0;i<64;i++)capture[b].x[capture_pos+i]=in[i];
  capture_pos+=64;
  if(capture_pos==ST_PITCH_N){BARRIER();capture[b].state=1;capture_which^=1;capture_pos=0;}
 }
}
static void service(void){
 if(job<0){
  for(int b=0;b<2;b++)if(capture[b].state==1){
   BARRIER();if(!enabled||capture[b].epoch!=epoch){capture[b].state=0;continue;}
   capture[b].state=2;job=b;job_epoch=capture[b].epoch;
   st_pitch_begin_rate(&work,capture[b].x,0,ST_PITCH_N,capture[b].rate);break;
  }
 }
 if(job<0)return;
 if(!st_pitch_step(&work,4)){
  st_pitch_result r;st_pitch_result_get(&work,&r);
  if(enabled&&job_epoch==epoch){display=(r.valid?0x10000u:0)|((uint32_t)(uint8_t)r.cents<<8)|r.note;BARRIER();result_epoch=job_epoch;}
  BARRIER();capture[job].state=0;job=-1;
 }
}
static void voice_on(void *self,const int16_t *p){(void)self;(void)p;}
static void voice_render(void *self,int16_t *out,const int16_t *p){(void)self;(void)p;for(int i=0;i<128;i++)out[i]=0;}
static void voice_off(void *self){(void)self;}
static const uint8_t colors[4][4]={{105,142,255,255},{0,237,149,255},{245,245,245,255},{255,82,75,255}};
static const uint8_t grey[4]={160,166,174,255};
static void *dials[4],*wave;
static void init(void *s){
 const char *names[4]={"dial0","dial1","dial2","dial3"};
 for(int i=0;i<4;i++)dials[i]=op1_find_node(s,names[i]);
 wave=op1_find_node(s,"input_wave");
}
static void tuner_init(void *s){(void)s;}
static void text(void *r,int x,int y,int scale,const char *s,const uint8_t *c){sq_text(r,x<<10,y<<10,scale, s,900,c);}
static void update(void *s,int dt){
 int16_t k[4];op1_synth_knobs_live(OP1_SCREEN_SLOT,k);
 for(int i=0;i<4;i++)if(dials[i]){int a=-3072+(k[i]*6144>>15);op1_node_rotate(dials[i],(112+31*i)<<10,43<<10,OP1_SINE_TABLE[a&8191],OP1_SINE_TABLE[(a+2048)&8191]);}
 if(wave){int scale=256+(input_peak*768>>15);int32_t m[9]={1024,0,0,0,scale,0,0,43*(1024-scale),1024};op1_node_set_transform(wave,m);}
 op1_screen_draw(s,dt);void *r=op1_raster();
 const char *labels[4]={"VOL","COMP","TONE","DRIVE"};
 for(int i=0;i<4;i++){
  char b[16];int v=i==2?(k[i]-16384)*100/32768:k[i]*100/32767;
  char *o=b;if(v<0){*o++='-';v=-v;}sq_num(o,(unsigned)v,1);
  text(r,103+31*i,26,768,labels[i],colors[i]);text(r,107+31*i,142,1024,b,colors[i]);
 }
 text(r,238,12,640,"T2 TUNER",grey);
}
static void tuner_update(void *s,int dt){
 op1_screen_draw(s,dt);void *r=op1_raster();text(r,18,14,1536,"AMP TUNER",colors[2]);
 uint32_t d=display;char name[8],cents[12];
 if(enabled&&result_epoch==epoch&&(d&0x10000)){
  st_pitch_name(d&255,name);if(name[0]>='a'&&name[0]<='g')name[0]-='a'-'A';int c=(int8_t)(d>>8);char *o=cents;*o++=c<0?'-':'+';sq_num(o,c<0?-c:c,1);
  text(r,130,48,4096,name,colors[1]);text(r,116,94,1536,cents,colors[2]);text(r,176,96,1024,"CENTS",grey);
  int x=160+c*2;sq_line(r,x<<10,125<<10,x<<10,140<<10,2<<10,colors[3]);
 }else{text(r,110,55,3072,"--",grey);text(r,92,100,1024,"PLAY ONE NOTE",grey);}
 sq_line(r,60<<10,130<<10,260<<10,130<<10,1024,grey);sq_line(r,160<<10,120<<10,160<<10,143<<10,1024,colors[1]);
}
const op1_screen_t SCREEN_amp={init,update};
static const op1_screen_t tuner={tuner_init,tuner_update};
const op1_input_engine_t ENGINE_amp={{voice_on,voice_render,voice_off,{0,0,0,0}},reset,process,service,&tuner};
