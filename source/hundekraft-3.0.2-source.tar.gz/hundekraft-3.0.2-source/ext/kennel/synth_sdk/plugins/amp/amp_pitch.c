/* Reuse the GPL kennel incremental detector privately; no imports from sampletools plugin. */
#include "../../sampletools/st_pitch.c"
