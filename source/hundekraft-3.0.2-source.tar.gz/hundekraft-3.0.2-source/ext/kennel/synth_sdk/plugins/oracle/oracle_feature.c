/* oracle as a sequencer-type feature (op1_feature_seq.h): the source lives in seq/oracle.c; this folder makes it a
 * plugin (compiled in, or content/oracle.knl when "loadable").
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../seq/oracle.c"
#include "../../op1_feature_seq.h"

static int ora_key_ev(int mode, int code, int pressed, int shift)
{
    if (code < 0x0A || code > 0x0C) return 0;                   /* lift / drop / scissors (Shift: whole pattern) */
    if (pressed) ora_clip(mode, code == 0x0A ? 0 : code == 0x0B ? 1 : 2, shift);
    return 1;
}
static void ora_turn_ev(int mode, int knob, int delta, int shift)   /* Mothers; Shift: rate gate lane run */
{
    if (shift) ora_shift_turn(mode, knob, delta); else ora_turn(mode, knob, delta);
}
static const op1_seq_type_t ora_type = {
    .name = "oracle", .alias = "shield",                        /* (shield: its pre-release name) */
    .player = ora_player_get, .svg = "oracle.svg", .screen = &SCREEN_oracle,
    .key = ora_key_ev, .press = ora_press, .turn = ora_turn_ev,  /* press: re-cast; Shift: white EDIT, red voicing */
    .shift_wants = ora_shift_wants, .midi_start = ora_midi_start };
const op1_feature_t FEATURE_oracle = { .api = OP1_FEATURE_API, .priority = 1000, .name = "oracle", .seq = &ora_type };
