/* the USB out page (clock T2) as a feature plugin (kind 3): the source lives in screens/usbout.c; this folder makes it a plugin.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../screens/usbout.c"
