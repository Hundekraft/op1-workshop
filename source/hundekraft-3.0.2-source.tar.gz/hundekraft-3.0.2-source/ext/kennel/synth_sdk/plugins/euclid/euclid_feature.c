/* euclid as a sequencer-type feature (op1_feature_seq.h): the source lives in seq/euclid.c; this folder makes it a
 * plugin (compiled in, or content/euclid.knl when "loadable").
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../seq/euclid.c"
#include "../../op1_feature_seq.h"

static int eu_key_ev(int mode, int code, int pressed, int shift)
{
    if (code < 0x0A || code > 0x0C) return 0;                   /* lift / drop / scissors = copy / paste / cut */
    if (pressed) eu_clip(mode, code == 0x0A ? 0 : code == 0x0B ? 1 : 2, shift);   /* Shift: whole pattern */
    return 1;
}
static void eu_press_ev(int mode, int knob, int shift) { (void)shift; eu_press(mode, knob); }   /* page 2 */
static void eu_turn_ev(int mode, int knob, int delta, int shift)
{
    if (knob == 2 && shift) eu_select(mode, delta);             /* Shift + white: select slot 1..6 (wraps) */
    else if (knob == 3 && shift) eu_run_all(mode, delta);       /* Shift + red: start / stop all */
    else eu_turn(mode, knob, delta);
}
static const op1_seq_type_t eu_type = {
    .name = "euclid", .player = eu_player_get, .svg = "euclid.svg", .screen = &SCREEN_euclid,
    .key = eu_key_ev, .press = eu_press_ev, .turn = eu_turn_ev, .shift_wants = eu_shift_wants, .midi_start = eu_midi_start };
const op1_feature_t FEATURE_euclid = { .api = OP1_FEATURE_API, .priority = 1000, .name = "euclid", .seq = &eu_type };
