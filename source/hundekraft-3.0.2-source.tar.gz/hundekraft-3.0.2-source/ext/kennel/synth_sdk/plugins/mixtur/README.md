# mixtur — subharmonic organ (Mixtur-Trautonium)

Oskar Sala's Mixtur-Trautonium (1952) played the *undertone* series: frequency dividers locked to the
oscillator produced f/2, f/3, f/4 … below the played pitch, and the mixture was coloured by resonant formant
circuits into the dark, vocal, slightly unearthly sound of Hitchcock's *The Birds* (1963). Where the overtone
series gives a major chord, the undertone series gives a minor one. In `mixtur` the key you play is the top note.
Four sawtooth dividers sound its undertones f/n, all derived from one master phase so they never drift, and two
parallel band-passes shape the result into vowels.

## Knobs

| knob | page 1 | page 2 (encoder press) |
|---|---|---|
| blue | divider A undertone n: OFF, 1 … 24 | formant 1: 180 Hz … 4.07 kHz (unset = 392 Hz) |
| green | divider B undertone n | formant 2: 500 Hz … 5.66 kHz (unset = 917 Hz) |
| white | divider C undertone n | resonance Q 0.7 … 22 (unset = 3.2) |
| red | divider D undertone n | (no page 2: white and red share word 7) |

Defaults: A 1, B 2, C 3, D 5. For C4 that gives C4, C3, F2 and Ab1, an F-minor undertone chord under the key.
Duplicate n values are muted, because identical saws would only add up coherently (+6 dB). The level is
normalised to the number of distinct undertones. Changing an n while a note sounds fades that divider out and back
in (~12 ms each way), so there are no clicks. Velocity scales the level.

**Sub-audio undertones fade out.** An undertone below the audible range is not a tone: under a low C, f/5 is 13 Hz,
which is 13 clicks a second, and each one rings the formants. That sounds like crackle. So every undertone's level
follows its own frequency: full above 40 Hz, fading to silence at 25 Hz. On the lowest keys you hear fewer
undertones; from the middle of the keyboard up nothing changes. (Found on hardware: the defaults crackled on the
lowest C.) Undertones fade in over ~12 ms at note on, while the key's own saw (n = 1) starts at once.

Screen: the *undertone ladder*. Twenty-four strings hang from a bridge, and string n has length 1/n, so the ends
trace the hyperbola of the undertone series. The four selected strings are coloured. While keys are held, a slowed
master clock ticks: each divider's bead steps one notch down its string per tick, and the string flashes when the
divider wraps. These are the real divider counters, slowed down to a speed you can follow. Below the hyperbola are
the two formant curves on a log-frequency axis (150 Hz … 6 kHz): grey on page 1, blue and green on page 2. The
bottom row shows n per knob, or F1, F2 and RES on page 2.

## How it works

* Master phase `p` (u32). Each divider counts master wraps in `c_k` (0 … n−1). Its phase is
  `c_k·⌊2³²/n⌋ + (p>>16)·⌊2¹⁶/n⌋`, using table constants, which never exceeds 2³² − 65536/n. The dividers are exact
  and stay locked forever, with no division per sample.
* Between two master wraps every saw is linear in `p`, so the whole mixture is a single ramp `A + (p>>16)·B`. That
  costs one multiply per sample; `A` and `B` are recomputed only at wraps and at gain steps. All saw resets fall on
  master wraps, so one 2-sample polyBLEP (with a lookahead for the sample before the step) band-limits all four
  dividers at once. It removes 15–28 dB of aliasing compared with naive saws.
* The two Chamberlin SVFs run in parallel with Q13 coefficients. The input is scaled by the damping, so the
  band-pass has unity peak gain. A makeup gain over Q keeps the loudness roughly constant, and a soft knee (linear up to 0.7 of full scale,
  rounded above; it replaced a cubic soft clip that distorted at every level) sits
  at the output. The worst-case L1 norms of the filter (Q 0.7 at 5.6 kHz: lp 1.54, bp 2.24, hp 5.06) bound every
  state for the largest possible input. Because of that bound, the sample loop needs no clamps and every multiply
  is a 16 × 16 MAC.
* The voice memory is shared with the other engines. A per-voice signature (static array) tells a voice we left,
  which keeps its phase and filters (continuous on retrigger), from one another engine overwrote, which starts
  clean.

## Limitations

* The polyBLEP reciprocal comes from each block's first pitch increment. Fast pitch bends inside a block make the
  band-limiting slightly less exact, but not out of tune.
* The 2-point polyBLEP is mild. With wide-open formants (F1/F2 at maximum, Q 0.7), the alias energy stays about
  −25 dB below the harmonics at any pitch. At the default formants it is −46 … −51 dB for mixtures; a lone n = 1
  saw reaches −36 dB at G7.
* The fixed-point integrators leave a tiny DC offset (about −61 dBFS per voice).
* The screen's master clock is a fixed visual tempo (140 ms per tick), not the note's pitch.
* Snapping the resonance from minimum to maximum in one step (preset load, not encoder turns) gives a short
  overshoot, which the soft clip limits.
