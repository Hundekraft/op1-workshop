/* fast tape erase as a feature plugin (kind 3, tape hook point): the source lives in tape/erase.c; this folder makes it a plugin.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../tape/erase.c"
