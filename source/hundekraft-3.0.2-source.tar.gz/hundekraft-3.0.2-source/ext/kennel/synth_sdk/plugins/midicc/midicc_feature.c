/* MIDI CC automation (op1r 35) as a feature plugin: the source lives in midiseq/midicc.c.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../midiseq/midicc.c"
