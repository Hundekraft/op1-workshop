/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* "pew": a drawbar organ through a rotary speaker.
 * blue   (knob 0): low drawbars   16', 8', 5 1/3'   (sub, fundamental, fifth)
 * green  (knob 1): middle drawbars 4', 2 2/3', 2'   (octave, twelfth, fifteenth)
 * white  (knob 2): high drawbars  1 3/5', 1 1/3', 1' (and a little key click)
 * red    (knob 3): rotor speed, slow (~0.7 Hz) to fast (~6.7 Hz); the horn spins up in about half a second,
 *                  the heavier drum takes a couple of seconds, like the real cabinet
 * Three fixed drawbar-group waves avoid rebuilding tables in the audio callback. Their levels ramp
 * across each block per voice, preventing a knob step from instantly replacing the sounding waveform.
 * The rotor is shared: horn = amplitude and pitch wobble on the upper drawbars, drum = slower, deeper
 * amplitude wobble on the low ones. Follows note velocity.
 */
#include "hk/engine.h"
#include "pew_tables.h"

#define WAVE 512

typedef struct {
    uint32_t ph, hph;   /* drum side, horn side (the horn's pitch wobbles) */
    int32_t click;   /* Q15 key click level */
    uint32_t noise;
    int32_t level[3]; /* Q15 drawbar levels, previous block target */
} voice_t;

static voice_t voices[ENGINE_VOICES];
static uint32_t horn_ph, drum_ph;                     /* rotor angles, 2^32 per turn */
static int32_t horn_speed, drum_speed;                /* phase per block */
static int last_voice = ENGINE_VOICES;
volatile uint32_t pew_blocks;                         /* rendered blocks, for the screen */
volatile uint32_t pew_horn, pew_drum;                 /* rotor angles, for the screen */

static inline int32_t read(const int16_t *w, uint32_t ph)
{
    const uint32_t i = ph >> 23;                          /* 512 points */
    const int32_t f = (int32_t)((ph >> 8) & 0x7FFF);
    const int32_t a = w[i];
    return a + (((w[i + 1] - a) * f) >> 15);
}

static inline int32_t rsin(uint32_t ph) { return pw_sin[ph >> 22]; }   /* coarse sine, enough for an LFO */

void engine_note_on(void *self, const int16_t *knobs)
{
    voice_t *v = &voices[ENGINE_VOICE(self)];
    for (int k = 0; k < 3; k++) v->level[k] = knobs[k] < 0 ? 0 : knobs[k];
    v->ph = v->hph = 0;
    v->click = 32767;
    v->noise = 0x9E3779B9u ^ (uint32_t)(uintptr_t)self;
}

void engine_note_off(void *self, const int16_t *knobs)
{
    (void)self;
    (void)knobs;
}

/* the knobs as this block hears them (after the slot LFO), for the screen */
volatile int16_t pew_knobs[4];

void engine_render(void *self, int16_t *out, const int16_t *knobs)
{
    for (int i = 0; i < 4; i++) pew_knobs[i] = knobs[i];
    const int vi = ENGINE_VOICE(self);
    voice_t *v = &voices[vi];
    int vel = ENGINE_VELOCITY(vi);
    if (vel < 1 || vel > 127) vel = 100;
    int32_t level[3], delta[3];
    for (int k = 0; k < 3; k++) {
        int32_t target = knobs[k] < 0 ? 0 : knobs[k];
        level[k] = v->level[k] * ENGINE_BLOCK;
        delta[k] = target - v->level[k];
        v->level[k] = target;
    }

    /* rotor: advance once per block (voices render in ascending order within a block) */
    if (vi <= last_voice) {
        const int32_t k3 = knobs[3] < 0 ? 0 : knobs[3];
        /* 0.7 .. 6.7 Hz as phase per 128-sample block: 2^32 * f * 128 / 44100 */
        const int32_t target = 8726000 + (int32_t)(((int64_t)k3 * 74800000) >> 15);
        horn_speed += (target - horn_speed) >> 6;                  /* ~0.2 s */
        drum_speed += ((target * 7 / 8) - drum_speed) >> 8;        /* ~0.75 s, a bit slower */
        horn_ph += (uint32_t)horn_speed;
        drum_ph += (uint32_t)drum_speed;
        pew_horn = horn_ph;
        pew_drum = drum_ph;
    }
    last_voice = vi;

    /* horn: tremolo 0.7..1, vibrato a few cents; drum: tremolo 0.55..1 */
    const int32_t hs = rsin(horn_ph), hc = rsin(horn_ph + 0x40000000u), ds = rsin(drum_ph);
    const int32_t horn_amp = 27852 + ((hs * 4915) >> 15);          /* Q15 0.70 .. 1.0 */
    const int32_t drum_amp = 25395 + ((ds * 7372) >> 15);          /* Q15 0.55 .. 1.0 */
    const int32_t click_lvl = knobs[2] < 0 ? 0 : knobs[2] >> 2;
    const int32_t gain = (30000 * vel) >> 7;

    uint32_t ph = v->ph, hph = v->hph;
    int32_t click = v->click;
    uint32_t noise = v->noise;
    for (int i = 0; i < ENGINE_BLOCK; i++) {
        const uint32_t inc = ENGINE_PITCH[i] >> 1;                 /* table = 16' = an octave below */
        ph += inc;
        hph += inc + (uint32_t)(((int32_t)(inc >> 10) * hc) >> 15);   /* Doppler wobble on the horn */
        const int32_t lo = (read(pw_low, ph) * (level[0] >> 7)) >> 15;
        const int32_t hi = ((read(pw_mid, hph) * (level[1] >> 7)) >> 15)
                         + ((read(pw_high, hph) * (level[2] >> 7)) >> 15);
        int32_t y = (lo * drum_amp + hi * horn_amp) >> 15;
        for (int k = 0; k < 3; k++) level[k] += delta[k];
        if (click > 64) {
            noise = noise * 1664525u + 1013904223u;
            y += (((int32_t)(noise >> 17) - 16384) * ((click * click_lvl) >> 15)) >> 15;
            click -= click >> 5;
        }
        /* gentle overdrive like a pushed tube amp */
        if (y > 24000) y = 24000 + ((y - 24000) >> 2);
        if (y < -24000) y = -24000 + ((y + 24000) >> 2);
        out[i] = engine_sat16((y * gain) >> 15);
    }
    v->ph = ph;
    v->hph = hph;
    v->click = click;
    v->noise = noise;
    pew_blocks++;
}
