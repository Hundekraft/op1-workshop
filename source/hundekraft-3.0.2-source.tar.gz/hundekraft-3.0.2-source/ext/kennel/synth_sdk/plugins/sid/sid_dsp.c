/* SID primitives adapted from cRSID 1.58, Hermit (Mihaly Horvath).
 * License is still WTF: Do what the frick you want with this code, but
 * it would be nice mentioning me as the original author.
 * Local changes: six independent plugin instances; native OP-1 envelope;
 * block-cached edge coefficients; selected pure waveforms; bounded 8580 LPF.
 * No CPU/player/register bus/digi emulation. */
#include "sid_dsp.h"
#include "sid_filter_tables.h"
#define MASK 0x0fffffffu
#define MSB 0x08000000u
static int clamp(int x,int lo,int hi){return x<lo?lo:x>hi?hi:x;}
/* Smooth in extended precision. At 44.1 kHz the 1/256 pole has a ~5.8 ms
 * time constant. Split products keep both filter multiplies in signed 32 bits:
 * |high| <= 170496 and |band| <= 65536 under the existing state bounds. */
static inline int cutoff_target(int q) {
 unsigned u=(unsigned)clamp(q,0,32767),i=u>>9,f=u&511;
 if(u==32767)return sid_cutoff_log[64];
 return sid_cutoff_log[i]+((sid_cutoff_log[i+1]-sid_cutoff_log[i])*(int)f>>9);
}
static inline int cutoff_smooth(int live,int target) { return live+((target-live+128)>>8); }
static inline int cutoff_mul(int x,int c) {
 return (x*(c>>12)+((x*(c&4095))>>12))>>12;
}

void sid_reset(sid_state *s) {
 volatile unsigned char *bytes=(volatile unsigned char *)s;
 for(unsigned i=0;i<sizeof(*s);i++)bytes[i]=0;
 for(int j=0;j<3;j++)s->noise[j]=0x7fffff;
}
void sid_configure(sid_state *s,uint32_t inc,const int16_t *q) {
 unsigned same=s->configured && s->cached_inc==inc;
 for(int j=0;j<4;j++)if(s->cached_q[j]!=q[j])same=0;
 if(same)return;
 unsigned first=!s->configured;
 s->configured=1;s->cached_inc=inc;for(int j=0;j<4;j++)s->cached_q[j]=q[j];
 s->mode=sid_wave_mode(q[0]);
 s->secondary=q[1]>>7;
 s->width=2048+((int)q[1]*61440>>15); /* 3..97% duty, before high-pitch protection */
 s->cutoff=cutoff_target(q[2]);
 if(first)s->cutoff_live=s->cutoff; /* a fresh note starts at the chosen tone */
 s->resonance=cRSID_Resonances8580[(unsigned)q[3]>>11];
 /* Pure modes use root, octave and fifth: a SID mini-chip, not unison padding.
  * Sync/ring modes sweep source interval 1..4 while retaining a root carrier. */
 uint32_t root=inc>>4;if(root>0x06000000u)root=0x06000000u;
 s->step[0]=root;
 if(s->mode>=4) {
   unsigned ratio=256u+((unsigned)q[1]*768u>>15);
   s->step[1]=(root>>8)*ratio;s->step[2]=root;
 } else {s->step[1]=root*2;s->step[2]=root+(root>>1);}
 for(int j=0;j<3;j++) {
  uint32_t step=s->step[j];if(step>0x06000000u)step=0x06000000u;s->step[j]=step;
  s->pulse_steep[j]=step>=4096?MASK/(step?step:1):65535;
  unsigned steep=(step>>4)/288;if(!steep)steep=1;s->saw_steep[j]=steep;
  s->saw_recip[j]=(1u<<20)/steep;
 }
}
int16_t sid_sample(sid_state *s) {
 int sum=0;
 for(int j=0;j<3;j++) {
  uint32_t step=s->step[j],old=s->phase[j],phase;
  if(s->mode==4 && j!=1 && s->sync_rise)phase=0;
  else phase=(old+step)&MASK;
  s->phase[j]=phase;
  unsigned msb=phase&MSB;s->sync_rise=msb>(s->previous[j]&MSB);
  uint32_t wave=0;int mode=s->mode;
  if(mode==3) {
   uint32_t n=s->noise[j];
   if(((phase^s->previous[j])&0x01000000u)||step>=0x01000000u) {
    unsigned feedback=((n&0x400000u)^((n&0x20000u)<<5))!=0;
    n=((n<<1)|feedback)&0x7fffff;s->noise[j]=n;
   }
   wave=((n&0x100000)>>5)|((n&0x40000)>>4)|((n&0x4000)>>1)|((n&0x800)<<1)
       |((n&0x200)<<2)|((n&0x20)<<5)|((n&4)<<7)|((n&1)<<8);
  } else if(mode==2) {
   uint32_t pw=(unsigned)s->width,limit=step>>13;
   if(pw && pw<limit)pw=limit;if(pw>(limit^65535u))pw=limit^65535u;
   uint32_t t=phase>>12,steep=s->pulse_steep[j];int v;
   if(t<pw){int peak=(65535-pw)*steep;if(peak>65535)peak=65535;v=peak-(pw-t)*steep;if(v<0)v=0;}
   else {int peak=pw*steep;if(peak>65535)peak=65535;v=(65535-t)*steep-peak;if(v>=0)v=65535;}
   wave=(unsigned)v&65535;
  } else if(mode==1 || mode==4) {
   wave=phase>>12;wave+=(wave*s->saw_steep[j])>>16;
   if(wave>65535)wave=65535-(((wave-65536)*s->saw_recip[j])>>4);
   wave&=65535;
  } else {
   uint32_t t=phase^(mode==5?s->ring_msb:0);
   wave=((t^((t&MSB)?MASK:0))>>11)&65535;
  }
  s->previous[j]=phase;s->ring_msb=msb;
  int sample=((int)wave-32768)/8;
  if(j && (mode==0 || mode==1 || mode==3))sample=(sample*s->secondary)/256;
  sum+=sample;
 }
 /* cRSID 8580 state-variable lowpass; bounded states prevent numeric runaway
  * under extreme live cutoff/resonance changes. Extended-precision cutoff. */
 int high=sum+(s->band*s->resonance)/4096+s->low;
 s->cutoff_live=cutoff_smooth(s->cutoff_live,s->cutoff);
 s->band=clamp(s->band-cutoff_mul(high,s->cutoff_live),-65536,65536);
 s->low=clamp(s->low+cutoff_mul(s->band,s->cutoff_live),-65536,65536);
 /* Board output coupling: remove pulse/sync DC before native ADSR. */
 int output=s->low;s->dc+=(output*256-s->dc)/1024;
 return (int16_t)clamp(output-s->dc/256,-32768,32767);
}

/* Full-rate block path: constant waveform per loop, scalar local oscillator state.
 * sid_sample above remains a numerical reference for the host equivalence check. */
#include "sid_noise_tables.h"
typedef struct {uint32_t phase,previous,noise,step,pulse,saw,recip;} osc;
#define INLINE static inline __attribute__((always_inline))
INLINE int oscillator(osc *o,unsigned mode,unsigned sync_enabled,unsigned *rise,uint32_t *ring) {
 uint32_t p=sync_enabled && *rise?0:(o->phase+o->step)&MASK;o->phase=p;
 uint32_t msb=p&MSB;*rise=msb>(o->previous&MSB);uint32_t w;
 if(mode==3){
  uint32_t n=o->noise;
  if(((p^o->previous)&0x1000000u)||o->step>=0x1000000u){unsigned b=((n&0x400000u)^((n&0x20000u)<<5))!=0;n=((n<<1)|b)&0x7fffff;o->noise=n;}
  w=noise_low[n&1023]|noise_high[(n>>10)&2047];
 }else if(mode==2){
  /* Width is passed through ring's high-independent companion below. */
  w=0;
 }else if(mode==1||mode==4){
  w=p>>12;w+=(w*o->saw)>>16;
  if(w>65535)w=65535-(((w-65536)*o->recip)>>4);w&=65535;
 }else {uint32_t t=p^(mode==5?*ring:0);w=((t^((t&MSB)?MASK:0))>>11)&65535;}
 o->previous=p;*ring=msb;return ((int)w-32768)/8;
}
INLINE int pulse_oscillator(osc *o,unsigned width,unsigned *rise,uint32_t *ring){
 uint32_t p=(o->phase+o->step)&MASK;o->phase=p;uint32_t msb=p&MSB;*rise=msb>(o->previous&MSB);
 uint32_t pw=width,limit=o->step>>13;if(pw&&pw<limit)pw=limit;if(pw>(limit^65535u))pw=limit^65535u;
 uint32_t t=p>>12;int v;
 if(t<pw){int peak=(65535-pw)*o->pulse;if(peak>65535)peak=65535;v=peak-(pw-t)*o->pulse;if(v<0)v=0;}
 else {int peak=pw*o->pulse;if(peak>65535)peak=65535;v=(65535-t)*o->pulse-peak;if(v>=0)v=65535;}
 o->previous=p;*ring=msb;return ((int)((unsigned)v&65535)-32768)/8;
}
#define LOAD(j) (osc){s->phase[j],s->previous[j],s->noise[j],s->step[j],s->pulse_steep[j],s->saw_steep[j],s->saw_recip[j]}
#define SAVE(o,j) s->phase[j]=o.phase;s->previous[j]=o.previous;s->noise[j]=o.noise
#define DEFINE_RENDER(M) \
static void render_##M(sid_state *s,int16_t *out,unsigned count){ \
 osc a=LOAD(0),b=LOAD(1),c=LOAD(2); \
 unsigned rise=s->sync_rise;uint32_t ring=s->ring_msb; \
 int band=s->band,low=s->low,dc=s->dc,cutoff=s->cutoff_live,target=s->cutoff,res=s->resonance,gain=s->secondary;unsigned width=s->width; \
 for(unsigned i=0;i<count;i++){ \
  int x,y,z; \
  if(M==2){x=pulse_oscillator(&a,width,&rise,&ring);y=pulse_oscillator(&b,width,&rise,&ring);z=pulse_oscillator(&c,width,&rise,&ring);} \
  else{x=oscillator(&a,M,M==4,&rise,&ring);y=oscillator(&b,M,0,&rise,&ring);z=oscillator(&c,M,M==4,&rise,&ring);} \
  if(M==0||M==1||M==3){y=(y*gain)/256;z=(z*gain)/256;} \
  cutoff=cutoff_smooth(cutoff,target); \
  int high=x+y+z+(band*res)/4096+low;band=clamp(band-cutoff_mul(high,cutoff),-65536,65536);low=clamp(low+cutoff_mul(band,cutoff),-65536,65536); \
  dc+=(low*256-dc)/1024;out[i]=(int16_t)clamp(low-dc/256,-32768,32767); \
 } \
 SAVE(a,0);SAVE(b,1);SAVE(c,2);s->sync_rise=rise;s->ring_msb=ring;s->band=band;s->low=low;s->dc=dc;s->cutoff_live=cutoff; \
}
DEFINE_RENDER(0)
DEFINE_RENDER(1)
DEFINE_RENDER(2)
DEFINE_RENDER(3)
DEFINE_RENDER(4)
DEFINE_RENDER(5)
void sid_render_samples(sid_state *s,int16_t *out,unsigned count){
 switch(s->mode){case 0:render_0(s,out,count);break;case 1:render_1(s,out,count);break;case 2:render_2(s,out,count);break;case 3:render_3(s,out,count);break;case 4:render_4(s,out,count);break;default:render_5(s,out,count);break;}
}
