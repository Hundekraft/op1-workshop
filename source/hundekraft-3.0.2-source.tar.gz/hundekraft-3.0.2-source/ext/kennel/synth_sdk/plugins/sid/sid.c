/* Six OP-1 voices, each a three-oscillator cRSID-derived mini-chip. */
#include "op1_plugin.h"
#include "sid_dsp.h"
static sid_state voices[OP1_VOICES];
volatile int16_t sid_live[4];
static void note_on(void *self,const int16_t *q){(void)q;sid_reset(&voices[op1_voice_index(self)]);}
static void render(void *self,int16_t *out,const int16_t *q){
 int voice=op1_voice_index(self);sid_state *s=&voices[voice];
 for(int i=0;i<4;i++)sid_live[i]=q[i];
 for(int i=0;i<OP1_BLOCK;i+=32){
  sid_configure(s,(uint32_t)OP1_PITCH_INC[i],q);
  sid_render_samples(s,out+i,32);
 }
}
const op1_engine_t ENGINE_sid={note_on,render,0,{OP1_PRESS_NONE,OP1_PRESS_NONE,OP1_PRESS_NONE,OP1_PRESS_NONE}};
