/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission; Maiko #250 port authorized by the project maintainer. See plugins/warble/README.md. */
#include "op1_synth.h"
#include "warble_dsp.h"
/* OLED correction: total lift 12px; lower 40px readouts get another 4px. */
#define SCREEN_LIFT 12
/* #250 procedural geometry in sixteenths of a pixel, re-rendered through
 * kennel's vector raster. Static custom alpha art is in warble.svg. */
static uint32_t hub_phase,tape_phase,previous_blocks;
static unsigned idle_frames,previous_pos=3;
extern volatile uint32_t warble_blocks[3];
static void line(void *r,int x,int y,int xx,int yy,const uint8_t *c) {
 op1_pt a={x*64,(y-SCREEN_LIFT*16)*64},b={xx*64,(yy-SCREEN_LIFT*16)*64};op1_raster_line(r,&a,&b,768,c);
}
static void circle(void *r,int x,int y,int radius,const uint8_t *c) {
 int px=x+radius,py=y;
 for(unsigned n=1;n<=32;n++){
  uint32_t a=n*0x08000000u;int xx=x+(wb_sine(a+0x40000000u)*radius>>15),yy=y+(wb_sine(a)*radius>>15);
  line(r,px,py,xx,yy,c);px=xx;py=yy;
 }
}
/* Small original stroke lettering; no firmware font data. */
#ifdef OP1_HOST
static const char letters[]="0123456789RATEDEPTHONMIXFZ.";
static const uint8_t glyph[][5]={
 {31,17,17,17,31},{0,18,31,16,0},{29,21,21,21,23},{21,21,21,21,31},
 {7,4,4,4,31},{23,21,21,21,29},{31,21,21,21,29},{1,1,1,1,31},
 {31,21,21,21,31},{23,21,21,21,31},
 {31,5,13,21,18},{30,5,5,5,30},{1,1,31,1,1},{31,21,21,21,17},
 {31,17,17,17,14},{31,21,21,21,17},{31,5,5,5,7},{1,1,31,1,1},
 {31,4,4,4,31},{31,17,17,17,31},{31,2,4,8,31},{31,2,4,2,31},
 {17,17,31,17,17},{27,4,4,4,27},{31,5,5,5,1},{25,21,21,21,19},{0,0,16,0,0}};
#endif
static unsigned text_slot;
#ifndef OP1_HOST
static uint8_t text_objects[12][OP1_TEXT_SIZE] __attribute__((aligned(4)));
static uint8_t text_made[12];
static char text_cached[12][16];
#endif
#ifdef WARBLE_SCREEN_TEST
void warble_test_text(int x,int y,const char *t,const uint8_t *c);
#endif
static void text(void *r,int x,int y,const char *t,const uint8_t *c){
#ifdef WARBLE_SCREEN_TEST
 warble_test_text(x,y-SCREEN_LIFT,t,c);
#endif
#ifndef OP1_HOST
 unsigned n=text_slot++;if(n>=12)return;
 static const int32_t ident[9]={1024,0,0,0,1024,0,0,0,1024};
 int numeric=(*t>='0'&&*t<='9');int size=numeric?40:14;
 static const uint8_t white[4]={255,255,255,255};if(numeric)c=white;
 if(!text_made[n]){op1_text_ctor(text_objects[n],OP1_Q10(x),y-SCREEN_LIFT,size,c);text_made[n]=1;}
 unsigned j=0;while(j<15&&text_cached[n][j]==t[j]&&t[j])j++;
 if(text_cached[n][j]!=t[j]){op1_text_set(text_objects[n],t);j=0;while(j<15&&t[j]){text_cached[n][j]=t[j];j++;}text_cached[n][j]=0;}
 op1_text_draw(text_objects[n],r,ident);
#else
 /* Host-only geometry lettering; actual firmware uses its native font above. */
 for(;*t;t++,x+=6){unsigned i=0;char ch=*t;if(ch>='a'&&ch<='z')ch-=32;while(letters[i]&&letters[i]!=ch)i++;
  if(!letters[i])continue;
  for(int col=0;col<5;col++)for(int row=0;row<5;row++)if(glyph[i][col]&(1u<<row))
   line(r,(x+col)*16,(y+row)*16,(x+col+1)*16,(y+row)*16,c);
 }
#endif
}
static void number(void *r,int x,int y,unsigned n,const uint8_t *c){
 char b[4];b[0]=(char)('0'+n/100);b[1]=(char)('0'+n/10%10);b[2]=(char)('0'+n%10);b[3]=0;
 text(r,x,y,n>=100?b:n>=10?b+1:b+2,c);
}
static void init(void *scr){(void)scr;hub_phase=tape_phase=0;idle_frames=0;previous_blocks=warble_blocks[(unsigned)op1_fx_screen_pos()%3];}
static void update(void *scr,int dt){
 int16_t k[4];op1_fx_knobs_live(k);int32_t depth=k[1]*k[1]>>15;
 uint32_t rate=wb_rate(k[0]);tape_phase+=rate*1064u;
 hub_phase+=(uint32_t)(((wb_sine(tape_phase)*depth)>>15)*600)+30000000u;
 op1_screen_draw_cached(scr, dt, 0);void *r=op1_raster();
 const uint8_t grey[4]={123,121,148,255},blue[4]={107,142,255,255},green[4]={0,239,148,255};
 text_slot=0;
 text(r,14,16,"rate",blue);number(r,14,34,((unsigned)k[0]*99u+16383u)>>15,blue);
 text(r,14,92,"depth",green);number(r,14,110,((unsigned)k[1]*99u+16383u)>>15,green);
 const uint8_t white[4]={255,255,255,255};
 text(r,246,16,"tone",white);number(r,246,34,((unsigned)k[2]*99u+16383u)>>15,white);
 const uint8_t orange[4]={255,0,0,255};
 text(r,246,92,"mix",orange);number(r,246,110,((unsigned)k[3]*99u+16383u)>>15,orange);
 circle(r,132*16,61*16,17*16,grey);circle(r,188*16,61*16,12*16,grey);
 for(unsigned c=0;c<2;c++){
  int x=c?188*16:132*16,y=61*16;circle(r,x,y,7*16,blue);
  for(unsigned n=0;n<6;n++){
   uint32_t ph=hub_phase+n*0x2aaaaaabu;int sn=wb_sine(ph),cs=wb_sine(ph+0x40000000u);
   line(r,x+(cs*48>>15),y+(sn*48>>15),x+(cs*96>>15),y+(sn*96>>15),blue);
  }
 }
 int amp=(depth*5>>11)+16,period=64-(k[0]*52>>15);
 uint32_t step=0xffffffffu/(unsigned)period; /* screen only; never in audio */
 int py=136*16;
 for(int x=118;x<=202;x+=2){
  int envelope=x<126?(x-118):x>194?(202-x):8;
  int yy=136*16+((wb_sine(tape_phase+(uint32_t)(x-118)*step)*(envelope*amp>>3))>>15);
  if(x>118)line(r,(x-2)*16,py,x*16,yy,green);
  py=yy;
 }
 unsigned pos=(unsigned)op1_fx_screen_pos()%3;
 uint32_t blocks=warble_blocks[pos];
 if(pos!=previous_pos){idle_frames=0;previous_blocks=blocks;previous_pos=pos;}
 if(blocks==previous_blocks)idle_frames++;else idle_frames=0;
 previous_blocks=blocks;
 if(idle_frames>3){
  const uint8_t dim[4]={0,0,0,90};
  for(int y=0;y<160;y++)line(r,0,(y+SCREEN_LIFT)*16,320*16,(y+SCREEN_LIFT)*16,dim);
  text(r,110,76,"fx off",blue);
 }
}
const op1_screen_t SCREEN_warble={init,update};
