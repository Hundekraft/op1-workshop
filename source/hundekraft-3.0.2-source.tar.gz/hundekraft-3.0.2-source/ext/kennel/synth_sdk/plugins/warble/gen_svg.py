#!/usr/bin/env python3
"""Convert only Maiko #250 custom Warble alpha art; requires private decrypted region.
No stock SVG/font is read. Project-maintainer-authorized Maiko artwork reconstruction; see PROVENANCE.md.
Screen placement: translate static art up twelve logical pixels.
Usage: gen_svg.py PRIVATE/OP1_vdk/01e40000.bin [OUTPUT]
"""
import hashlib
import struct
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'display'))
from pixel_svg import pixel_svg
REGION_SHA='09c22c233dc9a84b6e9674f0a1670f5c8f0ca8331dc819d97d4133fd58681c7a'
def generate(source,output,index=1):
 p=Path(source).read_bytes()
 if hashlib.sha256(p).hexdigest()!=REGION_SHA: raise ValueError('wrong private #250 region')
 base=0x1ea0df0-0x1e40000;pal=struct.unpack_from('<8H',p,0x60de0)
 pixels=[[(0,0,0) for x in range(320)] for y in range(160)]
 for j in range(6):
  c,x,y,w,h,ptr=struct.unpack_from('<6I',p,base+0x39c+index*0x90+j*24)
  if c==0xffffffff:continue
  v=pal[c];rgb=((v>>11)*255//31,((v>>5)&63)*255//63,(v&31)*255//31)
  data=p[ptr-0x1e40000:ptr-0x1e40000+(w*h+1)//2]
  for row in range(h):
   for col in range(w):
    k=row*w+col;a=(data[k//2]>>((k&1)*4))&15
    old=pixels[y+row][x+col]
    pixels[y+row][x+col]=tuple((rgb[c]*a+old[c]*(15-a)+7)//15 for c in range(3))
 label=('Crush','Warble','Plate')[index]
 Path(output).write_text(pixel_svg(pixels,f'Maiko #250 custom {label} art, owner-authorized port. No TE SVG/font.',y_offset=-12))

if __name__=='__main__':generate(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else Path(__file__).with_name('warble.svg'))
