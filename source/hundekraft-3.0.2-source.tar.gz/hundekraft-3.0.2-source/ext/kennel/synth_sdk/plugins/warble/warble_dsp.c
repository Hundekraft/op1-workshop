/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission; Maiko #250 port authorized by the project maintainer. See plugins/warble/README.md. */
#include "warble_dsp.h"
#include "warble_tables.h"

int32_t wb_sine(uint32_t p) {
 unsigned i=p>>24; int32_t a=wb_sin[i];
 return a+(((wb_sin[i+1]-a)*(int32_t)((p>>8)&65535))>>16);
}
uint32_t wb_rate(int32_t q) {
 uint32_t x=(uint32_t)((q*15655)>>15), i=(x>>6)&31;
 uint32_t e=(uint32_t)(wb_exp[i]+(((wb_exp[i+1]-wb_exp[i])*(int32_t)(x&63))>>6));
 e <<= x>>11;
 return ((e>>6)*4870u)>>10;
}
void wb_init(wb_state *s) {
 s->phase[0]=0;s->phase[1]=0x40000000u;s->write=0;
 s->lp[0]=s->lp[1]=0;s->mix=-1;s->depth=0;
 for(unsigned c=0;c<2;c++)for(unsigned i=0;i<WB_RING;i++)s->ring[c][i]=0;
}
static int16_t clip(int32_t x) { return x>32767?32767:x<-32768?-32768:(int16_t)x; }
void wb_process(wb_state *s,int16_t *l,int16_t *r,const int32_t q[4]) {
 uint32_t inc=wb_rate(q[0]), inc2=inc+((inc*21u)>>4);
 int32_t dep=((q[1]*q[1])>>15)*25>>3, mix=q[3];
 int32_t tone=3000+(((q[2]*q[2])>>15)*29767>>15);
 if(s->mix<0){s->mix=mix;s->depth=dep;}
 int32_t dm=mix-s->mix,dd=dep-s->depth;
 for(unsigned c=0;c<(r?2u:1u);c++) {
  int16_t *buf=c?r:l;uint32_t a=s->phase[0]+(c?0x40000000u:0),b=s->phase[1]+(c?0x40000000u:0),w=s->write;
  int32_t m=s->mix*64,d=s->depth*64,lp=s->lp[c];
  for(unsigned n=0;n<WB_BLOCK;n++) {
   int32_t dry=buf[n];s->ring[c][w]=buf[n];m+=dm;d+=dd;
   int32_t wave=(3*wb_sine(a)+wb_sine(b))>>2;
   uint32_t delay=(uint32_t)((wave*(d>>7)>>14)+(d>>6)+56320);
   unsigned rd=(w-(delay>>8))&(WB_RING-1);
   int32_t v=s->ring[c][rd];v+=((s->ring[c][(rd-1)&(WB_RING-1)]-v)*(int32_t)(delay&255))>>8;
   lp+=(((v-lp)>>1)*tone)>>14;
   buf[n]=clip(dry+((((lp-dry)>>1)*(m>>6))>>14));
   w=(w+1)&(WB_RING-1);a+=inc;b+=inc2;
  }
  s->lp[c]=lp;
 }
 s->write=(s->write+WB_BLOCK)&(WB_RING-1);s->phase[0]+=inc*WB_BLOCK;s->phase[1]+=inc2*WB_BLOCK;s->mix=mix;s->depth=dep;
}
