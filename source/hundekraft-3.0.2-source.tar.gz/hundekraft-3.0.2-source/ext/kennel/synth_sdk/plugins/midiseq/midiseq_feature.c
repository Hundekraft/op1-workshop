/* MIDI sequencer (op1r 35) as a feature plugin: the sources live in midiseq/; this folder makes it a plugin.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../midiseq/midiseq.c"
#include "../../midiseq/ms_core.c"
#include "../../midiseq/ms_draw.c"
