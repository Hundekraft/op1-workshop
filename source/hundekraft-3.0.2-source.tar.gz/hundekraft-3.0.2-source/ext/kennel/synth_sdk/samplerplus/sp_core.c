/* sampler+ core part (docs/46): what stays in the firmware for the sampler+ plugin file (plugins/samplerplus, kind
 * "sampler"). SynthSampler vtable slots render / note_on / note_off and the Adsr_render entry (hook.S) go to the
 * plugin if one is loaded, else to the stock functions (a plain sampler, unchanged); synth patches' "op1r" objects
 * reach the plugin through dp_keep_op1r (drumplus/dp_core.c, kept also without the plugin); the synth type browser
 * job is the plugin's (its 'sampler+' row) or the stock one. */
#include "../op1_synth.h"

const op1_samplerplus_t *op1_sampler;                             /* set by the plugin loader (plugload.c) */

#define STOCK_RENDER   ((void (*)(void *, int16_t *, const int16_t *))0x01A51A7C)
#define STOCK_NOTE_ON  ((void (*)(void *, const int16_t *))0x01A518F4)
#define STOCK_NOTE_OFF ((void (*)(void *))0x01A51964)
#define STOCK_TYPE_JOB ((void (*)(void *))0x0193FFAC)
int kn_sound_adsr_stock(void *, int16_t *, const int16_t *, const int16_t *);
void sp_fw_render(void *self, int16_t *out, const int16_t *k)
{
    const op1_samplerplus_t *s = op1_sampler;
    uint32_t t0 = op1_cycles();
    if (s) s->render(self, out, k); else STOCK_RENDER(self, out, k);
    sm_cy[SMC_SAMPLER] += op1_cycles() - t0;
}
void sp_fw_note_on(void *self, const int16_t *k) { if (op1_sampler) op1_sampler->note_on(self, k); else STOCK_NOTE_ON(self, k); }
void sp_fw_note_off(void *self) { if (op1_sampler) op1_sampler->note_off(self); else STOCK_NOTE_OFF(self); }
int sp_adsr_stock(void *a, int16_t *b, const int16_t *c, const int16_t *d) { return kn_sound_adsr_stock(a,b,c,d); }
void kn_samplerplus_gate(void)
{
    extern volatile uint8_t kn_sampler_adsr_live;
    int s=op1_current_slot();
    kn_sampler_adsr_live=(uint8_t)(op1_sampler && (unsigned)s<8 && ((const volatile int32_t *)0xFF8016E4)[s]==6);
}
void sp_slot_loaded(int slot, void *op1r) { if (op1_sampler) op1_sampler->slot_loaded(slot, op1r); }
/* the boot loads the synth patches before the plugins: once the plugin is in, it gets every slot's "op1r" */
#define SYNTH_PATCHES 0x01DDD7E8
#define JV_CGET ((const void *(*)(const void *, const char *))0x019BEB70)
#define JV_KEY  ((void *(*)(void *, const char *))0x019BFEB4)
void sp_replay(void)
{
    for (int slot = 0; slot < 8; slot++) {
        void *json = (uint8_t *)(SYNTH_PATCHES + slot * 0x38) + 4;
        const void *c = JV_CGET(json, "op1r");                   /* const lookup: no member added */
        sp_slot_loaded(slot, c && ((const uint8_t *)c)[8] == 7 ? JV_KEY(json, "op1r") : 0);
    }
}
void spc_ui_build(void) { if (op1_sampler) op1_sampler->ui_build(); }
void spc_ui_load(void) { if (op1_sampler) op1_sampler->ui_load(); }
void *spc_screen_for(int id) { return op1_sampler ? op1_sampler->screen_for(id) : 0; }
void spc_sync(int editor_open_on_6) { if (op1_sampler) op1_sampler->sync(editor_open_on_6); }
int spc_knob(int knob, int delta) { return op1_sampler ? op1_sampler->knob(knob, delta) : 0; }
int spc_key(int code, int pressed) { return op1_sampler ? op1_sampler->key(code, pressed) : 0; }
void sp_type_job(void *job) { if (op1_sampler) op1_sampler->type_job(job); else STOCK_TYPE_JOB(job); }

int op1_sampler_register(const op1_samplerplus_t *type)
{
    if(op1_sampler || !type || !type->render || !type->note_on || !type->note_off || !type->adsr || !type->slot_loaded || !type->is_plus || !type->type_job || !type->ui_build || !type->ui_load || !type->screen_for || !type->sync || !type->knob || !type->key) return -1;
    if(op1_db_write(((void *(*)(void))0x0196DD38)(),"INSERT OR REPLACE INTO synth_types VALUES(100,'sampler+','[0,0,0,0,0,0,0,0]')"))return -1;
    op1_sampler=type; sp_replay(); kn_samplerplus_gate(); return 0;
}

/* The builder patches R246's checked table loads for the 300-preset option. Read that
 * same load/count, so the browser works with both the stock and relocated table. */
int op1_sampler_preset_count(void)
{
    int n=*(const volatile int32_t *)0x018B6114;
    unsigned cap=*(const volatile uint16_t *)0x01A05FFC;
    return n>=0 && (unsigned)n<=cap && cap<=1024 ? n:0;
}
const void *op1_sampler_preset(int index)
{
    if(index<0 || index>=op1_sampler_preset_count())return 0;
    uint32_t base=*(const volatile uint16_t *)0x01940032;
    base|=(uint32_t)*(const volatile uint16_t *)0x01940036<<16;
    return (const uint8_t *)base+index*0x38+4;
}
