/* Tape undo / redo, as Maiko Pruett's #249 does: every recording and tape edit can be taken back, seven steps, kept on
 * flash across reboots; hold tape and press left (undo) or right (redo). A clean re-implementation from the behaviour
 * and design in docs/maiko-rebuild.md (no #249 code or bytes).
 *
 * A step runs from an OP1_EV_TAPE_EDIT before event to the next OP1_EV_TAPE_DRAINED and keeps, as they were before it,
 * the 64 KiB chunks it rewrote and the clip rows of the tracks it touched:
 * - a take: the first writeback of each (track, chunk) copies the old chunk (op1_tape_read_old) into a staging slot of
 *   the undo area; later writebacks of it are ignored (about 240 a second). The main loop writes staged slots to the
 *   step's file, one per pass, so a long take is not limited by the 1.5 MiB area.
 * - lift / drop write the file themselves: their before event (cache flushed by the core) reads the range
 *   (op1_tape_read) and writes it to the step's file there and then.
 * - clip rows: a base of every track's clips is taken on the main loop (boot, after each step, undo and redo); a step
 *   keeps the base of its tracks (a take's before event runs on KeyHandler, where clips can't be read).
 * Files in /yaffs2/user/kn_undo: sNNN.dat (records: track, chunk, 64 KiB), sNNN.clp (the clip rows), index.bin (the
 * steps, oldest first, and how many are done). Undo swaps the step with the tape in place, record by record, one per
 * main loop pass (read the record, read the tape's chunk, restore the record's, write the tape's back into the
 * record): the file then holds the step's later state and redo is the same swap. A new step drops the redo steps;
 * an eighth drops the oldest. A step that can't be kept whole (erase, the free space reserve, staging overrun) clears
 * the history: undoing older steps over an unrecorded change would mix states. Disk mode clears it too (#249 did).
 * State lives in the undo area (op1_undo_area), not in .bss: the core has little .bss left.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../op1_feature.h"
#include "../op1_feature_tape.h"
#include "undo.h"
#include "../screens/tape_popup.h"

#define TAPE_END 0xF23FA0                                       /* samples on a track */
#define COPY_MAX 0xF23FA                                        /* the clipboard holds this much of all four */
#define KEY_SHIFT 0x26
#define KEY_DROP 0x0B
#define KEY_LIFT 0x0A
enum { OP_BOUNCE = 0x40, OP_MERGE, OP_PASTE };                  /* our own edits: step ops above R246's */
#define MIN_CLIP 0xDC8                                          /* R246's shortest clip */
#define LIM_T 24576                                             /* the soft limiter: linear below, a knee above */
#define LIM_K (32767 - LIM_T)

#define CLIPS_MAX 512               /* R246's clip pool, all four tracks together */
typedef struct { int16_t n[4]; op1_tape_clip c[4][CLIPS_MAX]; } clip_set_t;      /* per track, the whole pool each */

#define CHUNK_BYTES 0x10000
#define REC_BYTES (4 + CHUNK_BYTES) /* a record: track, 0, chunk (u16), the chunk */
#define KEY_TAPE 0x04
#define KEY_LEFT 0x24
#define KEY_RIGHT 0x25
#define DIR "/yaffs2/user/kn_undo"
#define POPUP_FRAMES 45             /* the popup stays about a second after the last chunk */
enum { POP_UNDO, POP_REDO, POP_BOUNCE, POP_MERGE, POP_COPY, POP_PASTE };

typedef struct {
    uint32_t magic, n, done, next_id;               /* steps kept (oldest first), how many are done, the next id */
    uint16_t id[UNDO_STEPS];
    uint32_t recs[UNDO_STEPS];                      /* records in each step's .dat */
    uint8_t tracks[UNDO_STEPS];                     /* tracks each step touched (bits) */
} undo_index_t;
#define INDEX_MAGIC 0x4B4E5549                      /* "KNUI" */

/* the undo area: this header in the first 64 KiB, then UNDO_SLOTS staging slots and a spare, 64 KiB each */
typedef struct {
    uint32_t magic;
    undo_index_t idx;
    /* the step being captured */
    uint8_t open, op, track, not_undoable;
    uint8_t step_tracks, overrun, low_space, clips_ok;
    uint16_t slots, spilled;                        /* staged; of those, written to the file */
    uint16_t cur_id;                                /* its id (files sNNN) */
    int16_t fd;                                     /* its .dat, -1 not open */
    uint32_t recs;                                  /* records in its .dat */
    uint32_t written, written_gen;                  /* bytes written since the storage numbers of that walk */
    int32_t start, stop;
    uint8_t seen[4][(UNDO_CHUNKS + 7) / 8];         /* first writeback of (track, chunk) in this step */
    struct { uint8_t track; uint8_t pad; uint16_t chunk; } slot[UNDO_SLOTS];
    /* keys and the undo / redo job */
    uint8_t tape_held, busy, clips_done, redo;
    volatile uint8_t req;                           /* asked on the keys: 1 undo, 2 redo; 0xFF an edit cut a job */
    int16_t job_fd;
    uint32_t job_rec, job_recs;
    uint16_t job_id;
    uint8_t job_tracks, ready;
    uint32_t reserve;                               /* free space kept (bytes), from the setting at boot */
    char dir[32];                                   /* this tape's history folder: DIR, or DIR/t1..t3 */
    volatile uint8_t popup, popup_kind;             /* frames left to show the popup (Gfx); what it says (POP_*) */
    uint8_t shift_held, ej, ej_kind, ej_limit;      /* an edit job: 1 peak scan, 2 write; OP_*; limiter on */
    uint8_t ej_mask, ej_src, ej_t, ej_move;         /* target tracks; paste: the clipboard track for a single one;
                                                     * the track at hand; after: 1 move the loop, 2 the playhead */
    int32_t ej_in, ej_out, ej_c, ej_peak;           /* the target range, the chunk at hand, the sum's peak */
    uint32_t steps;                                 /* steps closed since boot */
    clip_set_t base;                                /* every track's clips now */
    clip_set_t step_clips;                          /* the open step's tracks before it; a job's scratch */
    op1_tape_clip tmp[CLIPS_MAX];
} undo_head_t;
#define MAGIC 0x4B4E5544                            /* "KNUD" */
#define SPARE UNDO_SLOTS                            /* the slot after the staging slots: a scratch chunk */

static undo_head_t *H;
static uint8_t *slots;

undo_head_t *undo_state(void) { return H; }
static uint8_t *slot_p(int i) { return slots + (uint32_t)i * CHUNK_BYTES; }

/* ---- small helpers: names, files, clips ---- */
static char *cat(char *d, const char *s) { while (*s) *d++ = *s++; *d = 0; return d; }
static void step_path(char *out, uint16_t id, const char *ext)
{
    char *p = cat(cat(out, H->dir), "/s");
    *p++ = (char)('0' + id / 100 % 10); *p++ = (char)('0' + id / 10 % 10); *p++ = (char)('0' + id % 10);
    cat(p, ext);
}
static void del_step(uint16_t id) { char p[48]; step_path(p, id, ".dat"); op1_file_unlink(p); step_path(p, id, ".clp"); op1_file_unlink(p); }
static int write_all(int fd, const void *src, int len) { return op1_file_write(fd, src, len) == len; }
static int read_all(int fd, void *dst, int len) { return op1_file_read(fd, dst, len) == len; }
static void save_index(void)
{
    char p[48];
    cat(cat(p, H->dir), "/index.bin");
    int fd = op1_file_open(p, OP1_FILE_WRITE | OP1_FILE_CREATE | OP1_FILE_TRUNC);
    if (fd < 0) return;
    write_all(fd, &H->idx, sizeof H->idx);
    op1_file_close(fd);
}
static void clear_history(void)
{
    for (uint32_t i = 0; i < H->idx.n; i++) del_step(H->idx.id[i]);
    H->idx.n = H->idx.done = 0;
    save_index();
}
static void take_base(void)                         /* main loop */
{
    H->clips_ok = 1;
    for (int t = 0; t < 4; t++) {
        int n = op1_tape_clips_get(t, H->base.c[t], CLIPS_MAX);
        if (n < 0) { H->clips_ok = 0; n = 0; }
        H->base.n[t] = (int16_t)(n > CLIPS_MAX ? CLIPS_MAX : n);
    }
}

static int area(void)
{
    if (H) return 1;
    uint32_t size = 0;
    uint8_t *a = op1_undo_area("undo", &size);
    if (!a || size < (UNDO_SLOTS + 2) * CHUNK_BYTES) return 0;
    H = (undo_head_t *)a;
    slots = a + CHUNK_BYTES;
    uint8_t *p = (uint8_t *)H;
    for (uint32_t i = 0; i < sizeof *H; i++) p[i] = 0;
    H->magic = MAGIC; H->fd = H->job_fd = -1;
    return 1;
}

/* boot: the history on flash */
static void load(void)
{
    char p[48];
    op1_file_mkdir(DIR);
    if (!H->dir[0]) cat(H->dir, DIR);               /* boot is always tape 1 (feat-tapes) */
    op1_file_mkdir(H->dir);
    H->idx.n = H->idx.done = 0;
    cat(cat(p, H->dir), "/index.bin");
    int fd = op1_file_open(p, OP1_FILE_READ);
    if (fd >= 0) {
        if (!read_all(fd, &H->idx, sizeof H->idx) || H->idx.magic != INDEX_MAGIC || H->idx.n > UNDO_STEPS ||
            H->idx.done > H->idx.n) H->idx.n = H->idx.done = 0;
        op1_file_close(fd);
    }
    H->idx.magic = INDEX_MAGIC;
    H->reserve = (uint32_t)op1_setting_get("undo", "reserve_mb", 24) << 20;
    H->ready = 1;
}

/* ---- capture ---- */
static void clear_seen(void) { uint8_t *p = &H->seen[0][0]; for (uint32_t i = 0; i < sizeof H->seen; i++) p[i] = 0; }

static void open_step(int op, int track)            /* any thread: RAM only */
{
    H->open = 1; H->op = (uint8_t)op; H->track = (uint8_t)track;
    H->not_undoable = H->overrun = H->low_space = 0;
    H->slots = H->spilled = 0; H->recs = 0; H->start = H->stop = 0; H->cur_id = 0xFFFF;   /* no file yet */
    H->step_tracks = (uint8_t)(track == OP1_TAPE_ALL ? 0xF : track < 4 ? 1u << track : 0);
    H->step_clips = H->base;                        /* the clips as they were before this edit */
    if (H->busy) H->req = 0xFF;                     /* an edit during an undo: the main loop gives the job up */
    clear_seen();
}

static int room(void)                               /* main loop: space left above the reserve for one more record */
{
    op1_storage_t s;
    if (!op1_storage(&s)) return 1;                 /* no numbers yet: go on */
    if (s.gen != H->written_gen) { H->written_gen = s.gen; H->written = 0; }
    return s.bytes[OP1_STORE_FREE] > H->written + REC_BYTES + H->reserve;
}

static int ensure_file(void)                        /* main loop: the open step's .dat */
{
    if (H->fd >= 0) return 1;
    char p[48];
    H->cur_id = (uint16_t)(H->idx.next_id % 1000);
    step_path(p, H->cur_id, ".dat");
    H->fd = (int16_t)op1_file_open(p, OP1_FILE_RDWR | OP1_FILE_CREATE | OP1_FILE_TRUNC);
    return H->fd >= 0;
}

static int put_record(int track, int chunk, const void *data)   /* main loop: append to the step's file */
{
    if (H->low_space || H->not_undoable) return 0;
    if (!room()) { H->low_space = 1; return 0; }
    uint8_t hd[4] = { (uint8_t)track, 0, (uint8_t)chunk, (uint8_t)(chunk >> 8) };
    if (!ensure_file() || !write_all(H->fd, hd, 4) || !write_all(H->fd, data, CHUNK_BYTES)) { H->low_space = 1; return 0; }
    H->written += REC_BYTES; H->recs++;
    return 1;
}

static int first(int track, int chunk)
{
    uint8_t bit = (uint8_t)(1u << (chunk & 7));
    if (H->seen[track][chunk >> 3] & bit) return 0;
    H->seen[track][chunk >> 3] |= bit;
    return 1;
}

static void on_write(int32_t arg)                   /* OP1_EV_TAPE_WRITE: main loop, keep it to the copy */
{
    int track = arg & 0xFF, chunk = arg >> 8 & 0xFFFF;
    if (!H->open || track > 3 || chunk >= UNDO_CHUNKS || !first(track, chunk)) return;
    if (H->slots >= UNDO_SLOTS) { H->overrun = 1; return; }   /* the main loop fell behind */
    if (op1_tape_read_old(slot_p(H->slots), 0, CHUNK_BYTES) < 0) { H->overrun = 1; return; }
    H->slot[H->slots].track = (uint8_t)track; H->slot[H->slots].chunk = (uint16_t)chunk;
    H->slots++;
}

static void spill_one(void)                         /* main loop: the next staged slot to the file */
{
    int i = H->spilled;
    put_record(H->slot[i].track, H->slot[i].chunk, slot_p(i));
    if (++H->spilled == H->slots) H->slots = H->spilled = 0;   /* all out: the slots are free again */
}

static void on_edit(int32_t arg)                    /* OP1_EV_TAPE_EDIT: the editing thread */
{
    int op = OP1_TAPE_EDIT_OP(arg), track = OP1_TAPE_EDIT_TRACK(arg);
    if (OP1_TAPE_EDIT_BEFORE(arg)) {
        if (!H->open) open_step(op, track);
        else H->step_tracks |= (uint8_t)(track == OP1_TAPE_ALL ? 0xF : track < 4 ? 1u << track : 0);   /* lift all
                                                     * after its loop splits: the step opened on one track's split */
        if (op == OP1_TAPE_ERASE) H->not_undoable = 1;
        if (op == OP1_TAPE_LIFT || op == OP1_TAPE_LIFT_ALL || op == OP1_TAPE_DROP || op == OP1_TAPE_DROP_ALL) {
            const op1_tape_edit_t *e = op1_tape_edit_now(arg);    /* main loop, cache flushed by the core */
            int16_t *buf = (int16_t *)slot_p(SPARE);
            if (e && e->stop > e->start)
                for (int t = 0; t < 4; t++)
                    if (track == OP1_TAPE_ALL || t == track)
                        for (int c = e->start / UNDO_CHUNK_SAMPLES; c <= (e->stop - 1) / UNDO_CHUNK_SAMPLES && c < UNDO_CHUNKS; c++)
                            if (first(t, c)) {
                                if (op1_tape_read(t, c * UNDO_CHUNK_SAMPLES, UNDO_CHUNK_SAMPLES, buf) < 0) H->overrun = 1;
                                else put_record(t, c, buf);
                            }
        }
    } else if (H->open) {
        const op1_tape_edit_t *e = op1_tape_edit_now(arg);
        if (e) { H->start = e->start; H->stop = e->stop; }
    }
}

static int write_clips(uint16_t id, const clip_set_t *c)   /* a step's clips into sNNN.clp */
{
    char p[48];
    step_path(p, id, ".clp");
    int fd = op1_file_open(p, OP1_FILE_WRITE | OP1_FILE_CREATE | OP1_FILE_TRUNC);
    if (fd < 0) return 0;
    int ok = write_all(fd, c->n, sizeof c->n);
    for (int t = 0; ok && t < 4; t++)
        if (c->n[t] > 0) ok = write_all(fd, c->c[t], c->n[t] * (int)sizeof(op1_tape_clip));
    op1_file_close(fd);
    return ok;
}

static void finish_step(void);
static void on_drained(void)                        /* main loop: the step is complete on the tape */
{
    if (!H->open || H->ej) return;                  /* an edit job closes its own step */
    finish_step();
}

static void finish_step(void)                       /* main loop: keep the step (or say why not) */
{
    while (H->slots) spill_one();                   /* what is still staged (at most UNDO_SLOTS) */
    H->open = 0;
    H->steps++;
    clear_seen();
    int keep = !H->not_undoable && !H->overrun && !H->low_space;
    if (keep && !ensure_file()) keep = 0;           /* a split or join: rows only, an empty .dat */
    if (H->fd >= 0) { op1_file_close(H->fd); H->fd = -1; }
    if (keep && !write_clips(H->cur_id, &H->step_clips)) keep = 0;
    if (!keep) {
        if (H->cur_id != 0xFFFF) del_step(H->cur_id);
        clear_history();
        op1_toast(H->not_undoable ? "erase: no undo" : H->low_space ? "undo off: low on space" : "too long to undo");
    } else {
        H->idx.next_id++;
        while (H->idx.n > H->idx.done) del_step(H->idx.id[--H->idx.n]);   /* the redo steps go */
        if (H->idx.n == UNDO_STEPS) {                                     /* the oldest goes */
            del_step(H->idx.id[0]);
            for (int i = 1; i < UNDO_STEPS; i++) {
                H->idx.id[i - 1] = H->idx.id[i]; H->idx.recs[i - 1] = H->idx.recs[i]; H->idx.tracks[i - 1] = H->idx.tracks[i];
            }
            H->idx.n--;
        }
        H->idx.id[H->idx.n] = H->cur_id; H->idx.recs[H->idx.n] = H->recs; H->idx.tracks[H->idx.n] = H->step_tracks;
        H->idx.done = ++H->idx.n;
        save_index();
    }
    take_base();
    op1_storage_refresh();                          /* free space after this step, for the next one's reserve check */
}

/* ---- undo / redo: swap a step with the tape, one record per main loop pass ---- */
static void job_end(const char *msg)
{
    if (H->job_fd >= 0) { op1_file_close(H->job_fd); H->job_fd = -1; }
    H->busy = 0;
    if (msg) op1_toast(msg);
    take_base();
}

static int swap_clips(void)                         /* 1 done, 0 refused (retry), -1 failed */
{
    char p[48];
    step_path(p, H->job_id, ".clp");
    int fd = op1_file_open(p, OP1_FILE_READ);
    if (fd < 0) return -1;
    clip_set_t *c = &H->step_clips;                 /* free while no step is open */
    int ok = read_all(fd, c->n, sizeof c->n);
    for (int t = 0; ok && t < 4; t++)
        if (c->n[t] < 0 || c->n[t] > CLIPS_MAX || (c->n[t] && !read_all(fd, c->c[t], c->n[t] * (int)sizeof(op1_tape_clip)))) ok = 0;
    op1_file_close(fd);
    if (!ok) return -1;
    int any = 0;
    for (int t = 0; t < 4; t++) {
        if (!(H->job_tracks >> t & 1)) continue;
        int n = op1_tape_clips_get(t, H->tmp, CLIPS_MAX);
        if (n < 0 || op1_tape_clips_set(t, c->c[t], c->n[t]) < 0) return any ? -1 : 0;   /* refused after a set: give up */
        any = 1;
        if (n > CLIPS_MAX) n = CLIPS_MAX;
        for (int i = 0; i < n; i++) c->c[t][i] = H->tmp[i];
        c->n[t] = (int16_t)n;
    }
    return write_clips(H->job_id, c) ? 1 : -1;      /* the clips now: the way back */
}

static void job_step(void)
{
    if (H->req == 0xFF) { H->req = 0; clear_history(); job_end("undo cut short"); return; }
    if (!H->clips_done) {
        int r = swap_clips();
        if (r == 0) return;
        if (r < 0) { clear_history(); job_end("undo failed"); return; }
        H->clips_done = 1;
        char p[48];
        step_path(p, H->job_id, ".dat");
        H->job_fd = (int16_t)op1_file_open(p, OP1_FILE_RDWR);
        if (H->job_fd < 0 && H->job_recs) { clear_history(); job_end("undo failed"); return; }
    }
    if (H->job_rec < H->job_recs) {
        uint8_t *rec = slot_p(0), *cur = slot_p(SPARE);
        int32_t at = (int32_t)(H->job_rec * REC_BYTES);
        if (op1_file_seek(H->job_fd, at, 0) != at || !read_all(H->job_fd, rec, REC_BYTES)) { clear_history(); job_end("undo failed"); return; }
        int track = rec[0], chunk = rec[2] | rec[3] << 8;
        int32_t s = chunk * UNDO_CHUNK_SAMPLES;
        if (op1_tape_read(track, s, UNDO_CHUNK_SAMPLES, (int16_t *)cur) < 0) return;                  /* refused: retry */
        if (op1_tape_restore(track, s, UNDO_CHUNK_SAMPLES, (const int16_t *)(rec + 4)) < 0) return;
        if (op1_file_seek(H->job_fd, at + 4, 0) != at + 4 || !write_all(H->job_fd, cur, CHUNK_BYTES)) {
            clear_history(); job_end("undo failed"); return;
        }
        H->job_rec++;                               /* the record now holds the tape as it was: the way back */
        return;
    }
    if (H->redo) H->idx.done++; else H->idx.done--;
    save_index();
    H->popup = POPUP_FRAMES;                        /* stays up a moment after the last chunk */
    job_end(0);
}

/* ---- #250's tape edits, rebuilt clean (behaviour: maikopruett.com's guide pages; docs/maiko-rebuild.md):
 * - bounce (tape + Shift + drop): tracks 1..4 over the loop summed onto the selected track;
 * - merge drop (Shift + drop): the lifted tracks in the clipboard summed onto the selected track at the playhead
 *   (one lifted track: a plain drop onto the selected track); stopped, the playhead goes to the end;
 * - copy (tape + lift): the loop's four tracks into the clipboard, nothing cut (no undo step);
 * - paste (tape + drop): the clipboard after the loop (loop off: after the last clip); the loop moves onto the copy.
 * Bounce, merge and paste are each one undo step: the old chunks and clip rows go into a step as an edit's do.
 * Sums are exact (no mixer volume or pan); if a sum clips anywhere, all of it goes through a soft limiter (linear
 * below LIM_T, a knee up to full scale). One (chunk, track) per main loop pass; a refused read / restore retries. ---- */
static int32_t soft(int32_t x)
{
    int32_t a = x < 0 ? -x : x;
    if (a > LIM_T) { int32_t e = a - LIM_T; a = LIM_T + (int32_t)((int64_t)e * LIM_K / (e + LIM_K)); }
    return x < 0 ? -a : a;
}

static void clips_with_range(int t, int32_t in, int32_t out)   /* the track's clips with [in, out) as one clip */
{
    const clip_set_t *b = &H->step_clips;           /* the clips before this step */
    int n = 0;
    for (int i = 0; i < b->n[t] && n < CLIPS_MAX - 2; i++) {
        op1_tape_clip c = b->c[t][i];
        if (c.stop <= in || c.start >= out) { H->tmp[n++] = c; continue; }
        if (in - c.start >= MIN_CLIP) H->tmp[n++] = (op1_tape_clip){ c.start, in };
        if (c.stop - out >= MIN_CLIP) H->tmp[n++] = (op1_tape_clip){ out, c.stop };
    }
    H->tmp[n++] = (op1_tape_clip){ in, out };
    for (int i = 1; i < n; i++)                     /* by start */
        for (int j = i; j > 0 && H->tmp[j - 1].start > H->tmp[j].start; j--) { op1_tape_clip x = H->tmp[j]; H->tmp[j] = H->tmp[j - 1]; H->tmp[j - 1] = x; }
    if (op1_tape_clips_set(t, H->tmp, n) < 0) H->overrun = 1;   /* not kept whole: the step is dropped, said so */
}

static int32_t clip_sum(int32_t k)                  /* merge: the lifted tracks summed at clipboard sample k */
{
    int32_t v = 0;
    for (int ch = 0; ch < 4; ch++) { const int16_t *c = op1_clipboard_slot(ch); if (c && (H->ej_src >> ch & 1)) v += c[k]; }
    return v;
}

static void ej_open(int kind, int mask, int32_t in, int32_t out, int track)
{
    open_step(kind, mask == 0xF ? OP1_TAPE_ALL : track);
    H->step_tracks = (uint8_t)mask;
    H->ej_kind = (uint8_t)kind; H->ej_mask = (uint8_t)mask; H->ej_in = in; H->ej_out = out;
    H->ej_c = in / UNDO_CHUNK_SAMPLES; H->ej_t = 0; H->ej_peak = 0; H->ej_limit = 0; H->ej_move = 0;
    while (!(H->ej_mask >> H->ej_t & 1)) H->ej_t++;
    H->ej = 2;
    H->popup_kind = (uint8_t)(kind == OP_BOUNCE ? POP_BOUNCE : kind == OP_MERGE ? POP_MERGE : POP_PASTE);
    H->popup = POPUP_FRAMES;
}

static void bounce_start(void)
{
    int on = 0; int32_t in = 0, out = 0;
    if (op1_tape_loop_get(&on, &in, &out) < 0 || !on || out - in < MIN_CLIP) { op1_toast("bounce needs the loop on"); return; }
    int t = op1_tape_track();
    if (t < 0 || t > 3) return;
    ej_open(OP_BOUNCE, 1 << t, in, out, t);
    H->ej = 1;                                      /* the sum's peak first */
}

static int clip_ready(int *mask, int32_t *len)      /* a tape lift in the clipboard, or a toast */
{
    int kind = op1_clipboard_info(mask, len);
    if (kind < 0) { op1_toast("clipboard busy, try again"); return 0; }
    if (kind != 1 || !*mask || *len < 1) { op1_toast("the clipboard is empty"); return 0; }
    return 1;
}

static void merge_start(void)                       /* Shift + drop */
{
    int mask; int32_t len;
    if (!clip_ready(&mask, &len)) return;
    int t = op1_tape_track();
    int32_t at = op1_tape_pos_get();
    if (t < 0 || t > 3 || at < 0) return;
    if (at + len > TAPE_END) { op1_toast("no room left on the tape"); return; }
    ej_open(OP_MERGE, 1 << t, at, at + len, t);
    H->ej_src = (uint8_t)mask;
    for (int32_t k = 0; k < len; k++) { int32_t v = clip_sum(k); if (v < 0) v = -v; if (v > H->ej_peak) H->ej_peak = v; }
    H->ej_limit = (uint8_t)(H->ej_peak > 32767);
    if (op1_tape_transport() == 0) H->ej_move = 2;  /* stopped: the playhead goes to the end, as after a drop */
}

static void paste_start(void)                       /* tape + drop */
{
    int mask; int32_t len;
    if (!clip_ready(&mask, &len)) return;
    int on = 0; int32_t in = 0, out = 0, at = 0;
    op1_tape_loop_get(&on, &in, &out);
    if (on && out > in) at = out;
    else for (int t = 0; t < 4; t++) {              /* after the last clip */
        int n = op1_tape_clips_get(t, H->tmp, CLIPS_MAX);
        for (int i = 0; i < n && i < CLIPS_MAX; i++) if (H->tmp[i].stop > at) at = H->tmp[i].stop;
    }
    if (at + len > TAPE_END) { op1_toast("no room left on the tape"); return; }
    int t = op1_tape_track();
    if (mask == 0xF) ej_open(OP_PASTE, 0xF, at, at + len, 0);
    else {                                          /* one lifted track: onto the selected track */
        int src = 0;
        while (!(mask >> src & 1)) src++;
        ej_open(OP_PASTE, 1 << (t < 0 || t > 3 ? src : t), at, at + len, t);
        H->ej_src = (uint8_t)src;
    }
    if (on && out > in) H->ej_move = 1;             /* the loop moves onto the copy */
}

static void copy_loop(void)                         /* tape + lift: nothing cut, not an undo step */
{
    int on = 0; int32_t in = 0, out = 0;
    if (op1_tape_loop_get(&on, &in, &out) < 0 || !on || out <= in) { op1_toast("copy needs the loop on"); return; }
    if (out - in >= COPY_MAX) { op1_toast("loop too long to copy"); return; }
    if (op1_clipboard_write(0xF, out - in) < 0) { op1_toast("clipboard busy, try again"); return; }
    for (int t = 0; t < 4; t++) {                   /* filled in this pass, before drop can read it */
        int16_t *dst = op1_clipboard_slot(t);
        if (!dst || op1_tape_read(t, in, out - in, dst) < 0) { op1_toast("copy failed"); return; }
    }
    H->popup_kind = POP_COPY; H->popup = POPUP_FRAMES;
}

static int read_four(int c)                         /* chunk c of all four tracks into slots 0..3; 0 refused */
{
    for (int t = 0; t < 4; t++)
        if (op1_tape_read(t, c * UNDO_CHUNK_SAMPLES, UNDO_CHUNK_SAMPLES, (int16_t *)slot_p(t)) < 0) return 0;
    return 1;
}

static void ej_step(void)
{
    int c = H->ej_c, last = (H->ej_out - 1) / UNDO_CHUNK_SAMPLES, t = H->ej_t;
    int32_t c0 = c * UNDO_CHUNK_SAMPLES;
    int i0 = H->ej_in > c0 ? H->ej_in - c0 : 0, i1 = H->ej_out - c0 < UNDO_CHUNK_SAMPLES ? H->ej_out - c0 : UNDO_CHUNK_SAMPLES;
    const int16_t *s0 = (const int16_t *)slot_p(0), *s1 = (const int16_t *)slot_p(1),
                  *s2 = (const int16_t *)slot_p(2), *s3 = (const int16_t *)slot_p(3);
    if (H->ej_kind == OP_BOUNCE) { if (!read_four(c)) return; }   /* refused (recording, a queued edit): retry */
    else if (op1_tape_read(t, c0, UNDO_CHUNK_SAMPLES, (int16_t *)slot_p(t)) < 0) return;
    if (H->ej == 1) {                               /* bounce, pass 1: the sum's peak */
        for (int i = i0; i < i1; i++) {
            int32_t v = (int32_t)s0[i] + s1[i] + s2[i] + s3[i];
            if (v < 0) v = -v;
            if (v > H->ej_peak) H->ej_peak = v;
        }
        if (c < last) { H->ej_c++; return; }
        H->ej = 2; H->ej_limit = (uint8_t)(H->ej_peak > 32767); H->ej_c = H->ej_in / UNDO_CHUNK_SAMPLES;
        return;
    }
    int fresh = first(t, c);                        /* pass 2: save the track's chunk, write over the range */
    if (fresh) put_record(t, c, slot_p(t));
    int16_t *dst = (int16_t *)slot_p(SPARE);
    const int16_t *old = (const int16_t *)slot_p(t);
    const int16_t *clip = H->ej_kind == OP_PASTE ? op1_clipboard_slot(H->ej_mask == 0xF ? t : H->ej_src) : 0;
    for (int i = 0; i < UNDO_CHUNK_SAMPLES; i++) {
        if (i < i0 || i >= i1) { dst[i] = old[i]; continue; }
        int32_t k = c0 + i - H->ej_in, v;
        if (H->ej_kind == OP_BOUNCE) v = (int32_t)s0[i] + s1[i] + s2[i] + s3[i];
        else if (H->ej_kind == OP_MERGE) v = clip_sum(k);
        else v = clip ? clip[k] : 0;
        dst[i] = (int16_t)(H->ej_limit ? soft(v) : v);
    }
    if (op1_tape_restore(t, c0, UNDO_CHUNK_SAMPLES, dst) < 0) {      /* refused: this (chunk, track) again */
        if (fresh) { H->seen[t][c >> 3] &= (uint8_t)~(1u << (c & 7)); if (H->recs) H->recs--; }
        return;
    }
    do H->ej_t++; while (H->ej_t < 4 && !(H->ej_mask >> H->ej_t & 1));
    if (H->ej_t < 4) return;                        /* the next track of this chunk */
    H->ej_t = 0; while (!(H->ej_mask >> H->ej_t & 1)) H->ej_t++;
    if (c < last) { H->ej_c++; return; }
    for (int k = 0; k < 4; k++) if (H->ej_mask >> k & 1) clips_with_range(k, H->ej_in, H->ej_out);
    if (H->ej_move == 1) op1_tape_loop_set(1, H->ej_in, H->ej_out);
    if (H->ej_move == 2) {                          /* a locate may turn the loop off: set it again if it was on */
        int on = 0; int32_t li = 0, lo = 0;
        op1_tape_loop_get(&on, &li, &lo);
        op1_tape_pos_set(H->ej_out);
        if (on && lo > li) op1_tape_loop_set(1, li, lo);
    }
    H->ej = 0;
    finish_step();
}

static void ud_service(void)                        /* main loop, every pass */
{
    if (!H) return;
    if (!H->ready) load();
    if (!H->clips_ok && !H->open) take_base();      /* boot: the clips before the first edit */
    if (H->open && H->spilled < H->slots) spill_one();   /* one staged slot to flash per pass */
    if (H->busy) { job_step(); return; }
    if (H->ej) { ej_step(); return; }
    int r = H->req;
    if (!r || r == 0xFF) { H->req = 0; return; }
    H->req = 0;
    if (r >= 3) {                                   /* #250's tape edits */
        if (H->open || op1_tape_transport() == 2) { op1_toast("not while recording"); return; }
        if (r == 3) bounce_start(); else if (r == 4) merge_start(); else if (r == 5) paste_start(); else copy_loop();
        return;
    }
    if (H->open || (r == 1 && !H->idx.done) || (r == 2 && H->idx.done >= H->idx.n)) return;
    int k = r == 1 ? (int)H->idx.done - 1 : (int)H->idx.done;
    H->job_id = H->idx.id[k]; H->job_recs = H->idx.recs[k]; H->job_tracks = H->idx.tracks[k];
    H->job_rec = 0; H->clips_done = 0; H->redo = (uint8_t)(r == 2); H->busy = 1;
    H->popup_kind = H->redo ? POP_REDO : POP_UNDO; H->popup = POPUP_FRAMES;
    job_step();
}

static void ud_event(int id, int32_t arg)
{
    if (!area()) return;
    if (id == OP1_EV_BOOT_DONE && !H->ready) load();
    else if (id == OP1_EV_TAPE_EDIT) on_edit(arg);
    else if (id == OP1_EV_TAPE_WRITE) on_write(arg);
    else if (id == OP1_EV_TAPE_DRAINED) on_drained();
    else if (id == OP1_EV_DISK && arg == 1) { if (!H->ready) load(); clear_history(); }   /* the host may change the tape */
#ifdef OP1_HAS_TAPE_SWITCH
    else if (id == OP1_EV_TAPE_SWITCH && H->ready) {   /* four tapes (feat-tapes): one history per tape */
        if (arg >> 16 & 1) {                        /* before: the old tape is still mounted */
            if (H->busy || H->ej || H->open) {      /* a job cut short leaves that tape half done: drop its history */
                H->busy = 0; H->ej = 0; H->open = 0; H->req = 0; H->popup = 0;   /* no word for an edit not done */
                if (H->job_fd >= 0) { op1_file_close(H->job_fd); H->job_fd = -1; }
                if (H->fd >= 0) { op1_file_close(H->fd); H->fd = -1; }
                clear_history();
            }
        } else {                                    /* after: the new tape is mounted, its clips loaded */
            int t = arg >> 8 & 0xFF;
            char *d = cat(H->dir, DIR);
            if (t > 0 && t < 4) { d = cat(d, "/t"); *d++ = (char)('0' + t); *d = 0; }
            load();
            take_base();
        }
    }
#endif
}

static int ud_key(int code, int pressed, int tape_screen)   /* KeyHandler */
{
    if (!H) return 0;
    if (code == KEY_TAPE) { H->tape_held = (uint8_t)pressed; return 0; }   /* stock still sees the tape key */
    if (code == KEY_SHIFT) { H->shift_held = (uint8_t)pressed; return 0; }
    if (tape_screen && (code == KEY_DROP || (code == KEY_LIFT && H->tape_held && !H->shift_held)) &&
        (H->tape_held || H->shift_held)) {          /* tape+Shift+drop, Shift+drop, tape+drop, tape+lift */
        int r = code == KEY_LIFT ? 6 : H->tape_held && H->shift_held ? 3 : H->shift_held ? 4 : 5;
        if (pressed) { if (H->open || H->busy || H->req || H->ej) op1_toast("still writing"); else H->req = (uint8_t)r; }
        return 1;
    }
    if (!H->tape_held || !tape_screen || (code != KEY_LEFT && code != KEY_RIGHT)) return 0;
    if (pressed) {
        if (H->open || H->busy || H->req || H->ej) op1_toast("still writing");
        else if (code == KEY_LEFT && H->idx.done) H->req = 1;
        else if (code == KEY_RIGHT && H->idx.done < H->idx.n) H->req = 2;
        else op1_toast(code == KEY_LEFT ? "nothing to undo" : "nothing to redo");
    }
    return 1;                                       /* tape + left / right: ours, press and release */
}

/* ---- the popup over the tape screen (Gfx thread): screens/tape_popup.h, shared with the tape switch ---- */
void undo_draw_popup(void *r, int kind, int done, int total)
{
    static const char *const words[] = {"UNDO", "REDO", "BOUNCE", "MERGE", "COPY", "PASTE"};
    tape_popup(r, words[kind], 0, done, total);
}
static void ud_draw(void)
{
    if (!H || !H->popup) return;
    int done = 1, total = 1;
    if (H->busy) { done = (int)H->job_rec; total = (int)H->job_recs; }
    else if (H->ej) { int n = (H->ej_out - 1) / UNDO_CHUNK_SAMPLES - H->ej_in / UNDO_CHUNK_SAMPLES + 1, two = H->ej_kind == OP_BOUNCE;
                      done = (H->ej == 2 && two ? n : 0) + H->ej_c - H->ej_in / UNDO_CHUNK_SAMPLES; total = (two ? 2 : 1) * n; }
    undo_draw_popup(op1_raster(), H->popup_kind, done, total);
    if (!H->busy && !H->ej) H->popup--;
}

static const struct op1_tape_hooks ud_tape = { .service = ud_service, .key = ud_key, .draw = ud_draw };
static const char *const ud_claims[] = { "key:tape:tape+left", "key:tape:tape+right", "key:tape:tape+shift+drop",
                                          "key:tape:shift+drop", "key:tape:tape+drop", "key:tape:tape+lift", 0 };
const op1_feature_t FEATURE_undo = {
    .api = OP1_FEATURE_API, .priority = 450, .name = "undo", .event = ud_event, .tape = &ud_tape,
    .claims = ud_claims,
};
