/* Tape undo (undo.c): sizes its tests use.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef UNDO_H
#define UNDO_H

#define UNDO_CHUNKS 485             /* 32768-sample chunks per track: the tape's length (docs/firmware/tape.md) */
#define UNDO_SLOTS 22               /* 64 KiB staging slots after the header page in the 1.5 MiB undo area (+1 spare) */
#define UNDO_CHUNK_SAMPLES 32768    /* one tape cache chunk: 64 KiB of 16-bit samples */
#define UNDO_STEPS 7                /* steps kept, as #249 */

#endif
