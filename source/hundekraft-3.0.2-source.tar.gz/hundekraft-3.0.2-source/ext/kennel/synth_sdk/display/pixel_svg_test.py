#!/usr/bin/env python3
"""Exact pixel-union geometry: holes, diagonal contacts, nested islands and mixed colors."""
import random,sys,tempfile
from pathlib import Path
import numpy as np
from pixel_svg import pixel_svg
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'harness'))
import oprender
fixtures=[]
a=np.zeros((160,320,3),dtype=np.uint8);a[10:30,20:60]=[123,121,148];a[14:25,25:55]=0;a[17:20,30:40]=[123,121,148];fixtures.append(a)
a=np.zeros_like(a)
for x,y in [(10,10),(11,11),(12,10),(13,11)]:a[y,x]=[107,142,255]
fixtures.append(a)
r=random.Random(73);a=np.zeros_like(a);palette=[[255,0,0],[0,255,0],[107,142,255],[123,121,148],[0,0,0]]
for y in range(30):
 for x in range(45):a[y+60,x+100]=r.choice(palette)
fixtures.append(a)
with tempfile.TemporaryDirectory(prefix='pixel-union-') as tmp:
 for i,a in enumerate(fixtures):
  p=Path(tmp)/f'{i}.svg';p.write_text(pixel_svg(a,'own test geometry'))
  b=oprender.render({'svg':str(p)},scale=1,stock=False).array()
  assert np.array_equal(a,b[:,:,:3]),i
 a=np.zeros((160,320,3),dtype=np.uint8);a[:12,10:15]=[107,142,255];a[150:159,20:30]=[255,0,0]
 p=Path(tmp)/'raised.svg';p.write_text(pixel_svg(a,'offset and top crop',y_offset=-4))
 b=oprender.render({'svg':str(p)},scale=1,stock=False).array()
 expected=np.zeros_like(a);expected[:-4]=a[4:]
 assert np.array_equal(expected,b[:,:,:3]), 'four-pixel lift/top crop'
print('Exact color-union holes, diagonal contacts, islands and mixed-color raster PASS')
