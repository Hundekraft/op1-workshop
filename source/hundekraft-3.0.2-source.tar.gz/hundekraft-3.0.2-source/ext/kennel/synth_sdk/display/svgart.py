#!/usr/bin/env python3
"""Screen SVG helpers for art handed to us (docs/screen-art.md): read an artist's SVG into flattened strokes, write
R246's SVG subset (line, circle, path M/L/Z, polyline; at most two decimals; no turn-backs).

    from svgart import art, element, shape, cubic, subpaths, ellipse, mix, f2

art(path) -> [(element, stroke, fill, width, [(points, closed)])] in document order, groups flattened, transforms
applied, cubic curves flattened within 0.05 px, ellipses / circles / rects as closed point lists, opacity mixed into
the colour over black, the CSS default fill (black) where a class sets none. element() and shape() write them.
Used by plugins/eva/gen_svg.py, art_trace.py and art_compare.py.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import math
import re
import xml.etree.ElementTree as ET

BLACK = '#010101'                          # R246 hides with this (stock does the same)
W = 1.5


def f2(v):
    s = f'{v:.2f}'.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s


def mix(color, a):
    """color at opacity a over black"""
    c = color.lstrip('#')
    if len(c) == 3:
        c = ''.join(ch * 2 for ch in c)
    return '#' + ''.join(f'{round(int(c[i:i + 2], 16) * a):02X}' for i in (0, 2, 4))


def no_turnback(q):
    """drop every point where the line doesn't move or turns back on itself (cos < -0.985); R246's stroke join draws
    such a turn as a spike to the screen edge (harness/svg_check.py checks the same)"""
    changed = True
    while changed:
        changed = False
        for i in range(1, len(q) - 1):
            (ax, ay), (bx, by), (cx, cy) = q[i - 1], q[i], q[i + 1]
            u, v = (bx - ax, by - ay), (cx - bx, cy - by)
            lu, lv = math.hypot(*u), math.hypot(*v)
            if not lu or not lv or (u[0] * v[0] + u[1] * v[1]) / (lu * lv) < -0.985:
                del q[i]
                changed = True
                break
    return q


def rounded(pts, closed=False):
    q = [(float(f2(x)), float(f2(y))) for x, y in pts]
    q = [p for i, p in enumerate(q) if i == 0 or p != q[i - 1]]
    if closed and len(q) > 1 and q[0] == q[-1]:
        q.pop()
    return no_turnback(q)


def shape(pts, stroke, w=W, closed=False, fill='none'):
    """pts in screen px -> line / polyline / closed path"""
    q = rounded(pts, closed)
    attrs = f'stroke="{stroke}" stroke-width="{f2(w)}" stroke-linecap="round"'
    if closed:
        d = 'M' + ' L'.join(f'{f2(x)} {f2(y)}' for x, y in q) + ' Z'
        return f'<path d="{d}" fill="{fill}" {attrs} stroke-linejoin="round"/>'
    if len(q) == 2:
        (ax, ay), (bx, by) = q
        return f'<line x1="{f2(ax)}" y1="{f2(ay)}" x2="{f2(bx)}" y2="{f2(by)}" {attrs}/>'
    return (f'<polyline points="{" ".join(f"{f2(x)},{f2(y)}" for x, y in q)}" fill="{fill}" {attrs} '
            f'stroke-linejoin="round"/>')


# ---- reading the artist's SVG ----

def styles(root):
    """class -> {property: value} from the <style> block"""
    out = {}
    for el in root.iter():
        if el.tag.endswith('style'):
            for sel, body in re.findall(r'([^{}]+)\{([^}]*)\}', el.text or ''):
                props = dict((k.strip(), v.strip()) for k, v in
                             (p.split(':', 1) for p in body.split(';') if ':' in p))
                for s in sel.split(','):
                    out.setdefault(s.strip().lstrip('.'), {}).update(props)
    return out


def matrix(tr):
    """SVG transform (translate / rotate / matrix) -> (a, b, c, d, e, f)"""
    m = (1, 0, 0, 1, 0, 0)
    for op, args in re.findall(r'(\w+)\(([^)]*)\)', tr or ''):
        v = [float(x) for x in re.split(r'[\s,]+', args.strip())]
        if op == 'translate':
            n = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0)
        elif op == 'matrix':
            n = tuple(v)
        elif op == 'rotate':
            r = math.radians(v[0])
            n = (math.cos(r), math.sin(r), -math.sin(r), math.cos(r), 0, 0)
        else:
            raise ValueError(op)
        a, b, c, d, e, f = m
        m = (a * n[0] + c * n[1], b * n[0] + d * n[1], a * n[2] + c * n[3], b * n[2] + d * n[3],
             a * n[4] + c * n[5] + e, b * n[4] + d * n[5] + f)
    return m


def apply(m, pts):
    a, b, c, d, e, f = m
    return [(a * x + c * y + e, b * x + d * y + f) for x, y in pts]


def cubic(p0, p1, p2, p3, tol=0.05):
    """flattened cubic, without p0"""
    def flat(p0, p1, p2, p3):
        ux, uy = p3[0] - p0[0], p3[1] - p0[1]
        n = math.hypot(ux, uy) or 1e-9
        return max(abs((p[0] - p0[0]) * uy - (p[1] - p0[1]) * ux) / n for p in (p1, p2)) <= tol
    if flat(p0, p1, p2, p3):
        return [p3]
    mid = lambda a, b: ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    a, b, c = mid(p0, p1), mid(p1, p2), mid(p2, p3)
    d, e = mid(a, b), mid(b, c)
    f = mid(d, e)
    return cubic(p0, a, d, f, tol) + cubic(f, e, c, p3, tol)


TOKEN = re.compile(r'[MmLlHhVvCcSsZz]|-?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')


def subpaths(d):
    """path data -> [(points, closed)]"""
    toks, i = TOKEN.findall(d), 0
    out, cur, pos, start, cmd, last_c2 = [], [], (0.0, 0.0), (0.0, 0.0), None, None

    def num():
        nonlocal i
        i += 1
        return float(toks[i - 1])

    while i < len(toks):
        if toks[i].isalpha():
            cmd = toks[i]
            i += 1
            if cmd in 'Zz':
                if cur:
                    out.append((cur, True))
                cur, pos, last_c2 = [], start, None
                continue
        rel = cmd.islower()
        ox, oy = pos if rel else (0.0, 0.0)
        c = cmd.upper()
        if c == 'M':
            if cur:
                out.append((cur, False))
            pos = start = (ox + num(), oy + num())
            cur, last_c2 = [pos], None
            cmd = 'l' if rel else 'L'                     # following pairs are line-tos
        elif c == 'L':
            pos = (ox + num(), oy + num())
            cur.append(pos)
            last_c2 = None
        elif c == 'H':
            pos = ((ox if rel else 0.0) + num(), pos[1])
            cur.append(pos)
            last_c2 = None
        elif c == 'V':
            pos = (pos[0], (oy if rel else 0.0) + num())
            cur.append(pos)
            last_c2 = None
        elif c in 'CS':
            if c == 'C':
                c1 = (ox + num(), oy + num())
            else:
                c1 = (2 * pos[0] - last_c2[0], 2 * pos[1] - last_c2[1]) if last_c2 else pos
            c2 = (ox + num(), oy + num())
            p3 = (ox + num(), oy + num())
            cur += cubic(pos, c1, c2, p3)
            pos, last_c2 = p3, c2
    if cur:
        out.append((cur, False))
    return out


def ellipse(cx, cy, rx, ry):
    n = max(16, int(math.ceil(2 * math.pi * max(rx, ry) / 1.2)))
    return [(cx + rx * math.cos(2 * math.pi * k / n), cy + ry * math.sin(2 * math.pi * k / n)) for k in range(n)]


def art(path):
    """an SVG drawing as [(element, stroke, fill, width, [(points, closed)])] in document order, groups flattened"""
    root = ET.parse(path).getroot()
    cls = styles(root)
    out = []

    def walk(el, m):
        tag = el.tag.split('}')[-1]
        m2 = m
        if el.get('transform'):
            a = matrix(el.get('transform'))
            m2 = (m[0] * a[0] + m[2] * a[1], m[1] * a[0] + m[3] * a[1], m[0] * a[2] + m[2] * a[3],
                  m[1] * a[2] + m[3] * a[3], m[0] * a[4] + m[2] * a[5] + m[4], m[1] * a[4] + m[3] * a[5] + m[5])
        if tag in ('svg', 'g'):
            for ch in el:
                walk(ch, m2)
            return
        if tag in ('defs', 'style', 'text'):
            return
        p = {k: el.get(k) for k in ('stroke', 'fill', 'stroke-width', 'opacity') if el.get(k) is not None}
        for c in (el.get('class') or '').split():          # CSS classes win over presentation attributes
            p.update(cls.get(c, {}))
        g = lambda k: float(el.get(k, 0))
        if tag == 'line':
            geo = [([(g('x1'), g('y1')), (g('x2'), g('y2'))], False)]
        elif tag == 'polyline':
            n = [float(v) for v in TOKEN.findall(el.get('points'))]
            geo = [(list(zip(n[0::2], n[1::2])), False)]
        elif tag == 'path':
            geo = subpaths(el.get('d'))
        elif tag in ('ellipse', 'circle'):
            rx, ry = (g('r'), g('r')) if tag == 'circle' else (g('rx'), g('ry'))
            geo = [(ellipse(g('cx'), g('cy'), rx, ry), True)]
        elif tag == 'rect':
            x, y, w, h = g('x'), g('y'), g('width'), g('height')
            geo = [([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], True)]
        else:
            raise ValueError(tag)
        geo = [(apply(m2, pts), closed) for pts, closed in geo]
        a = float(p.get('opacity', 1))
        stroke = p.get('stroke')
        stroke = mix(stroke, a) if stroke and stroke != 'none' else None
        fill = p.get('fill', '#000')                      # the SVG default fill is black
        fill = None if fill == 'none' else mix(fill, a)
        width = float(p.get('stroke-width', '1').rstrip('px'))
        out.append((el, stroke, fill, width, geo))

    walk(root, (1, 0, 0, 1, 0, 0))
    return out


def element(stroke, fill, width, geo):
    out = []
    for pts, closed in geo:
        if fill:                                          # black fills only (hiding what's behind)
            assert fill == '#000000', fill
            out.append(shape(pts, stroke or BLACK, width if stroke else 0.2, True, BLACK))
        else:
            out.append(shape(pts, stroke, width, closed))
    return out
