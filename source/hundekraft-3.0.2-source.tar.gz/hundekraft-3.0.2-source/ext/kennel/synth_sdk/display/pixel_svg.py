"""Exact rectangle covers for final composited pixel art.

Greedy disjoint rectangles reduce row-run objects without unsupported compound
filled paths. The exposed-boundary utility remains for geometry measurements.
R246 treats subsequent filled MOVE commands as LINE, so holes/subpaths cannot
be encoded together. Every emitted rectangle has one M/Z and preserves pixels.
No firmware data is part of this tool.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""
def boundaries(cells):
    edges=set()
    for x,y in cells:
        if (x,y-1) not in cells:edges.add(((x,y),(x+1,y)))
        if (x+1,y) not in cells:edges.add(((x+1,y),(x+1,y+1)))
        if (x,y+1) not in cells:edges.add(((x+1,y+1),(x,y+1)))
        if (x-1,y) not in cells:edges.add(((x,y+1),(x,y)))
    adjacent={}
    for a,b in edges:adjacent.setdefault(a,[]).append(b)
    direction={(1,0):0,(0,1):1,(-1,0):2,(0,-1):3}
    loops=[]
    while edges:
        a,b=min(edges);edges.remove((a,b));points=[a];start=a
        while b!=start:
            points.append(b);d=direction[(b[0]-a[0],b[1]-a[1])]
            candidates=[c for c in adjacent[b] if (b,c) in edges]
            # At diagonally touching cells turn right, keeping separate loops.
            def priority(c):
                turn=(direction[(c[0]-b[0],c[1]-b[1])]-d)%4
                return {1:0,0:1,3:2,2:3}[turn]
            c=min(candidates,key=priority);edges.remove((b,c));a,b=b,c
        corners=[]
        for i,p in enumerate(points):
            before=points[i-1];after=points[(i+1)%len(points)]
            if (p[0]-before[0],p[1]-before[1])!=(after[0]-p[0],after[1]-p[1]):corners.append(p)
        loops.append(corners)
    return loops

def rectangles(pixels):
    """Greedy maximal same-color, disjoint rectangles; every path has one M/Z.
    R246's filled-path walker treats later MOVE as LINE, so compound fills fail.
    """
    used=set();out=[];height=len(pixels);width=len(pixels[0])
    for y,row in enumerate(pixels):
        for x,color in enumerate(row):
            color=tuple(color)
            if not any(color) or (x,y) in used:continue
            w=0;best=(0,0,0);h=height-y
            while x+w<width and tuple(pixels[y][x+w])==color and (x+w,y) not in used:
                yy=y
                while yy<height and tuple(pixels[yy][x+w])==color and (x+w,yy) not in used:yy+=1
                h=min(h,yy-y);w+=1
                if w*h>best[0]:best=(w*h,w,h)
            _,w,h=best;out.append((x,y,x+w,y+h,color))
            for yy in range(y,y+h):
                for xx in range(x,x+w):used.add((xx,yy))
    return out

def pixel_svg(pixels,comment,y_offset=0):
    """Emit rectangle art at a vertical offset, cropping to the 320x160 canvas."""
    out=['<svg xmlns="http://www.w3.org/2000/svg" width="320" height="160" viewBox="0 0 320 160">',f'<!-- {comment} -->']
    for x,y,xx,yy,color in rectangles(pixels):
        y=max(0,y+y_offset);yy=min(160,yy+y_offset)
        if yy<=y:continue
        rgb='#'+''.join(f'{v:02x}' for v in color)
        out.append(f'<path fill="{rgb}" d="M {x} {y} L {xx} {y} L {xx} {yy} L {x} {yy} Z"/>')
    return '\n'.join(out+['</svg>'])+'\n'
