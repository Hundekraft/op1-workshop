"""Compact R246 SVG markup without rounding or simplifying geometry.
Equivalent line/polyline paths keep explicit M/L commands and per-shape paint.
No CSS, inherited paint, entities, relative paths or compound fills are introduced.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""
import re
import xml.etree.ElementTree as ET

NS = 'http://www.w3.org/2000/svg'
ET.register_namespace('', NS)
NUMBER = r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)'
TOKEN = re.compile(r'[MLZ]|' + NUMBER)


def path_text(value):
    tokens = TOKEN.findall(value)
    if re.sub(r'[\s,]+', '', TOKEN.sub('', value)):
        raise ValueError('Compactor accepts explicit M/L/Z paths only')
    out = ''
    for token in tokens:
        # Commands delimit numbers themselves; retain a space between two numbers.
        if out and token not in 'MLZ' and out[-1] not in 'MLZ':
            out += ' '
        out += token
    return out


def compact_svg(text):
    root = ET.fromstring(text)
    for node in root.iter():
        tag = node.tag.rsplit('}', 1)[-1]
        if node.text is not None and not node.text.strip():
            node.text = None
        node.tail = None
        if tag == 'polyline':
            value = node.attrib.pop('points')
            points = re.findall(NUMBER, value)
            if len(points) < 4 or len(points) % 2:
                raise ValueError('Invalid polyline coordinates')
            node.tag = '{' + NS + '}path'
            node.set('d', 'M' + points[0] + ' ' + points[1] + ''.join(
                'L' + points[i] + ' ' + points[i + 1] for i in range(2, len(points), 2)))
        elif tag == 'line' and 'id' not in node.attrib:
            # Keep ID-bearing lines as lines: stock/animation code may address them.
            xy = [node.attrib.pop(k) for k in ('x1', 'y1', 'x2', 'y2')]
            node.tag = '{' + NS + '}path'
            node.set('d', 'M' + xy[0] + ' ' + xy[1] + 'L' + xy[2] + ' ' + xy[3])
            node.set('fill', 'none')
        if 'd' in node.attrib:
            node.set('d', path_text(node.get('d')))
        if node.get('stroke') == 'none':
            # Stroke parameters cannot affect a shape whose stroke is disabled.
            for key in ('stroke-width', 'stroke-linecap', 'stroke-linejoin'):
                node.attrib.pop(key, None)
        width = node.get('stroke-width')
        if width and '.' in width:
            node.set('stroke-width', width.rstrip('0').rstrip('.'))
    return ET.tostring(root, encoding='unicode').replace(' />', '/>') + '\n'
