"""Deterministic configured minimum line weight for generated screen art.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission.
"""
import numpy as np
from scipy import ndimage as nd
from art_trace import thin
B=np.array([[1,2,4],[8,0,16],[32,64,128]],np.uint16)
LUT=np.zeros(256,bool)
for code in range(256):
 a=(B&code)!=0;a[1,1]=0
 if nd.label(a,np.ones((3,3)))[1]!=1:continue
 bg=~a;bg[1,1]=0;lab,n=nd.label(bg)
 adj={lab[y,x] for y,x in ((0,1),(1,0),(1,2),(2,1)) if lab[y,x]}
 LUT[code]=len(adj)==1

def minimum_width(mask, logical_width=1.6, scale=1774/320):
 """Widen useful ink around its centreline; preserve black gaps and topology.

 Existing broad fills remain. Isolated flecks shorter than two target widths
 stay at source size. Preserve half-pixel black channels where art is tight.
 """
 width=logical_width*scale
 # Do not amplify tiny isolated source-antialias flecks into broad dots.
 labels,count=nd.label(mask,np.ones((3,3)))
 sizes=nd.find_objects(labels)
 good=np.zeros(count+1,bool)
 for k,box in enumerate(sizes,1):
  good[k]=box is not None and max(t.stop-t.start for t in box)>=2*width
 target=mask|(nd.distance_transform_edt(~thin(good[labels]))<=width/2)
 # Keep a half-logical-pixel black channel where the original has a gap/hole.
 black=(~mask)&(nd.distance_transform_edt(~mask)<width*1.5)
 protected=nd.distance_transform_edt(~thin(black))<=.25*scale
 target &= ~(protected&~mask)
 a=mask.copy();yy,xx=np.indices(a.shape);phases=(yy%3)*3+xx%3
 while True:
  count=0
  for phase in range(9):
   code=nd.correlate(a.astype('uint16'),B,mode='constant')
   take=target&~a&LUT[code]&(phases==phase)
   count+=int(take.sum());a|=take
  if not count:break
 return a
