#!/usr/bin/env python3
"""Measures how close one screen drawing is to another (docs/screen-art.md): per colour, the distance from each
stroke's centre line to the nearest centre line of the same colour in the other drawing, both ways.

    python3 synth_sdk/display/art_compare.py REF.svg TEST.svg [--region X0,Y0,X1,Y1] [--overlay OUT.png]
                                             [--json OUT.json]

Either SVG may be an artist's file (curves, ellipses, transforms, opacity; read with svgart.art) or one of ours.
Strokes are sampled every 0.2 px; colours are matched to the nearest REF colour (RGB distance under 60, else left
out and listed). Black strokes and fills (cut-outs, masks) and the full-screen background are not strokes. Reported per colour
and in total: median and 95th percentile distance TEST -> REF ("placement") and REF -> TEST ("missing"), and the
share of samples within 0.5 px and 1 px. The overlay draws REF in magenta and TEST in green at 4x: white where they
agree. Note: parts of REF hidden by its own black cut-outs still count, so they show up as missing in TEST.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy.spatial import cKDTree

sys.path.insert(0, str(Path(__file__).resolve().parent))
from svgart import art   # noqa: E402

STEP = 0.2


def strokes(path, region):
    """-> {colour: N x 2 samples}"""
    out = {}
    for el, stroke, fill, width, geo in art(path):
        if not stroke or stroke.upper() in ('#000000', '#010101'):      # black: cut-outs, masks
            continue
        if el.tag.endswith('rect') and el.get('width') == '320' and el.get('height') == '160':
            continue
        for pts, closed in geo:
            q = list(pts) + ([pts[0]] if closed else [])
            for (ax, ay), (bx, by) in zip(q, q[1:]):
                n = max(1, int(math.hypot(bx - ax, by - ay) / STEP))
                t = np.linspace(0, 1, n + 1)[:, None]
                s = np.array([ax, ay]) + t * np.array([bx - ax, by - ay])
                if region:
                    x0, y0, x1, y1 = region
                    s = s[(s[:, 0] >= x0) & (s[:, 0] <= x1) & (s[:, 1] >= y0) & (s[:, 1] <= y1)]
                if len(s):
                    out.setdefault(stroke.upper(), []).append(s)
    return {c: np.vstack(v) for c, v in out.items()}


def rgb(h):
    return np.array([int(h[i:i + 2], 16) for i in (1, 3, 5)], float)


def stats(d):
    return {'n': int(len(d)), 'median': round(float(np.median(d)), 3), 'p95': round(float(np.percentile(d, 95)), 3),
            'within_0.5': round(float(np.mean(d <= 0.5)), 4), 'within_1': round(float(np.mean(d <= 1.0)), 4)}


def compare(ref_path, test_path, region=None):
    ref, test = strokes(ref_path, region), strokes(test_path, region)
    names = list(ref)
    mapped, unmatched = {}, []
    for c, s in test.items():
        d = [np.linalg.norm(rgb(c) - rgb(r)) for r in names]
        if d and min(d) < 60:
            r = names[int(np.argmin(d))]
            mapped[r] = np.vstack([mapped[r], s]) if r in mapped else s
        else:
            unmatched.append(c)
    rep, all_t, all_r = {}, [], []
    for r in names:
        t = mapped.get(r)
        if t is None:
            rep[r] = {'missing': stats(np.full(len(ref[r]), 99.0))}
            all_r.append(np.full(len(ref[r]), 99.0))
            continue
        dt = cKDTree(ref[r]).query(t)[0]
        dr = cKDTree(t).query(ref[r])[0]
        rep[r] = {'placement': stats(dt), 'missing': stats(dr)}
        all_t.append(dt)
        all_r.append(dr)
    total = {'placement': stats(np.concatenate(all_t)) if all_t else None, 'missing': stats(np.concatenate(all_r))}
    return {'colours': rep, 'total': total, 'unmatched': unmatched}, ref, test


def overlay(ref, test, out, s=4):
    im = np.zeros((160 * s, 320 * s, 3), np.uint8)
    for layer, chans in ((ref, (0, 2)), (test, (1,))):
        img = Image.new('L', (320 * s, 160 * s))
        dr = ImageDraw.Draw(img)
        for pts in layer.values():
            for x, y in pts:
                dr.ellipse((x * s - 1.5, y * s - 1.5, x * s + 1.5, y * s + 1.5), fill=255)
        a = np.asarray(img)
        for ch in chans:
            im[..., ch] = np.maximum(im[..., ch], a)
    Image.fromarray(im).save(out)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('ref', type=Path)
    ap.add_argument('test', type=Path)
    ap.add_argument('--region')
    ap.add_argument('--overlay', type=Path)
    ap.add_argument('--json', type=Path)
    a = ap.parse_args()
    region = [float(v) for v in a.region.split(',')] if a.region else None
    rep, ref, test = compare(a.ref, a.test, region)
    for c, r in list(rep['colours'].items()) + [('total', rep['total'])]:
        line = f'{c:8}'
        for k in ('placement', 'missing'):
            if r.get(k):
                v = r[k]
                line += f"  {k} median {v['median']:.2f} p95 {v['p95']:.2f} <=0.5 {v['within_0.5']:.1%} <=1 {v['within_1']:.1%}"
        print(line)
    if rep['unmatched']:
        print('unmatched colours in TEST:', ', '.join(rep['unmatched']))
    if a.overlay:
        overlay(ref, test, a.overlay)
    if a.json:
        a.json.write_text(json.dumps(rep, indent=1))
