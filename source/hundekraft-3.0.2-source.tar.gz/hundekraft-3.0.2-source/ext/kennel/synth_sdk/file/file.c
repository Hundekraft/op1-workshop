/* FILE: where the flash goes, as Maiko Pruett's #249 shows on Shift+COM. A clean re-implementation from the behaviour
 * in docs/maiko-rebuild.md (no #249 code or bytes), drawn with a wide storage layout (reference:
 * docs/design/file-view/F3.png): a tape reel whose ring is split by category, the free space in the hub, and a
 * legend with every category's size.
 *
 * The COM view (op1_feature_t.com): in COM (Shift+COM), Shift+COM again shows it. The numbers come from the core's
 * storage walk (op1_storage, kennel/kn_storage.c), cached until disk mode ends. The blue push opens the core's flash
 * check (op1_flash_*, kennel/kn_flash.c; blue again scans again); any other push goes back to FILE and walks again.
 * Drawn in lines and the stroke font only (no firmware Text), on the empty "usbout.svg" screen.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "../screens/stroke_font.h"

#define STROKE 0x600                /* 1.5 px */
static const uint8_t c_text[4] = {0xdf, 0xd9, 0xff, 255}, c_grey[4] = {0x7c, 0x79, 0x90, 255},
    c_dark[4] = {0x38, 0x35, 0x72, 255}, c_black[4] = {0, 0, 0, 255};
/* per category (OP1_STORE_*): tape blue, sounds green, factory white, system lavender, mods red, bad pink,
 * overhead grey, free navy (its value lavender, readable on black) */
static const uint8_t cat_col[OP1_STORE_N][4] = {
    {0x69, 0x8e, 0xff, 255}, {0x00, 0xed, 0x95, 255}, {0xff, 0xff, 0xff, 255}, {0xdf, 0xd9, 0xff, 255},
    {0xff, 0x3a, 0x5d, 255}, {0xff, 0x90, 0xa7, 255}, {0x7c, 0x79, 0x90, 255}, {0x38, 0x35, 0x72, 255}};
static const char *const cat_name[OP1_STORE_N] = {"TAPE", "SOUNDS", "FACTORY", "SYSTEM", "MODS", "BAD", "OVERHEAD", "FREE"};

/* cos of 128 steps round the circle, Q10; sin(i) = cos(i - 32). Screen y grows down, so rising steps go clockwise. */
#define STEPS 128
static const int16_t cos128[STEPS + 1] = {
    1024, 1023, 1019, 1013, 1004, 993, 980, 964, 946, 926, 903, 878, 851, 822, 792, 759, 724, 688, 650, 610, 569, 526,
    483, 438, 392, 345, 297, 249, 200, 150, 100, 50, 0, -50, -100, -150, -200, -249, -297, -345, -392, -438, -483,
    -526, -569, -610, -650, -688, -724, -759, -792, -822, -851, -878, -903, -926, -946, -964, -980, -993, -1004, -1013,
    -1019, -1023, -1024, -1023, -1019, -1013, -1004, -993, -980, -964, -946, -926, -903, -878, -851, -822, -792, -759,
    -724, -688, -650, -610, -569, -526, -483, -438, -392, -345, -297, -249, -200, -150, -100, -50, 0, 50, 100, 150,
    200, 249, 297, 345, 392, 438, 483, 526, 569, 610, 650, 688, 724, 759, 792, 822, 851, 878, 903, 926, 946, 964, 980,
    993, 1004, 1013, 1019, 1023, 1024};
static int32_t cosq(int i) { return cos128[((i % STEPS) + STEPS) % STEPS]; }
static int32_t sinq(int i) { return cosq(i - 32); }

#define CX 78                       /* the reel: centre, ring (mid radius and width), hub */
#define CY 78
#define RING_R 50
#define RING_W 12
#define TOP 96                      /* step at 12 o'clock */

static void ln(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, const uint8_t *c)
{
    op1_pt a = {x0, y0}, b = {x1, y1};
    op1_raster_line(r, &a, &b, w, c);
}
static int32_t px(int step, int rad) { return (CX << 10) + cosq(step) * rad; }   /* rad in px: Q10 result */
static int32_t py(int step, int rad) { return (CY << 10) + sinq(step) * rad; }
static void circle(void *r, int rad, int32_t w, const uint8_t *c)
{
    for (int i = 0; i < STEPS; i += 4) ln(r, px(i, rad), py(i, rad), px(i + 4, rad), py(i + 4, rad), w, c);
}
static void dot(void *r, int32_t x, int32_t y, const uint8_t *c)   /* 6 px disc at (x, y) Q10 */
{
    for (int i = 0; i < STEPS; i += 8)
        ln(r, x + cosq(i) * 3 / 2, y + sinq(i) * 3 / 2, x + cosq(i + 8) * 3 / 2, y + sinq(i + 8) * 3 / 2, (3 << 10) + 512, c);
}

/* steps of the ring per category: proportional (largest remainder), at least one for any non-zero category so
 * the small ones stay visible; KiB keeps the products in 32 bits */
void file_steps(const uint32_t *bytes, uint8_t *steps)
{
    uint32_t kb[OP1_STORE_N], total = 0, rem[OP1_STORE_N];
    int used = 0;
    for (int c = 0; c < OP1_STORE_N; c++) { kb[c] = bytes[c] >> 10; total += kb[c]; }
    for (int c = 0; c < OP1_STORE_N; c++) {
        uint32_t q = total ? kb[c] * STEPS / total : 0;
        rem[c] = total ? kb[c] * STEPS % total : 0;
        if (!q && bytes[c] && total) { q = 1; rem[c] = 0; }
        steps[c] = (uint8_t)q; used += (int)q;
    }
    while (total && used < STEPS) {                        /* hand the rest to the largest remainders */
        int best = 0;
        for (int c = 1; c < OP1_STORE_N; c++) if (rem[c] > rem[best]) best = c;
        steps[best]++; rem[best] = 0; used++;
    }
    while (used > STEPS) {                                 /* minimums overshot: take from the largest */
        int big = 0;
        for (int c = 1; c < OP1_STORE_N; c++) if (steps[c] > steps[big]) big = c;
        steps[big]--; used--;
    }
}

/* "256.7 MB", "7.2 MB", "1024 MB", "20 KB" (binary units, as the OP-1 counts its 512 MB) */
void file_size_text(uint32_t bytes, char *out)
{
    char t[16];
    int n = 0;
    uint32_t v;
    if (bytes < (1u << 20)) { v = (bytes + 512) >> 10; out[0] = 'K'; }
    else { v = (uint32_t)(((uint64_t)bytes * 10 + (1u << 19)) >> 20); out[0] = 'M'; }
    char unit = out[0];
    int tenth = unit == 'M' && v < 10000;                  /* one decimal below 1000 MB */
    if (unit == 'M' && !tenth) v /= 10;
    do { t[n++] = (char)('0' + v % 10); v /= 10; if (tenth && n == 1) t[n++] = '.'; } while (v || (tenth && n < 3));
    int k = 0;
    while (n) out[k++] = t[--n];
    out[k++] = ' '; out[k++] = unit; out[k++] = 'B'; out[k] = 0;
}

static int32_t text_w(const char *t, int32_t s) { int32_t w = 0; for (; *t; t++) w += (*t == '1' || *t == '.' ? 4 : 6) * s; return w; }
#define FS 1229                     /* 7 px capitals */

void file_draw(void *r, const op1_storage_t *s, int ready)
{
    uint8_t steps[OP1_STORE_N];
    char v[16];
    /* the reel: outer and inner rims, three spokes round the hub */
    circle(r, RING_R + RING_W / 2 + 1, STROKE, c_grey);
    circle(r, RING_R - RING_W / 2 - 1, STROKE, c_grey);
    circle(r, 25, STROKE, c_grey);
    for (int k = 0; k < 3; k++) {
        int a = TOP + k * STEPS / 3;
        ln(r, px(a - 4, 27), py(a - 4, 27), px(a - 6, 37), py(a - 6, 37), STROKE, c_grey);
        ln(r, px(a - 6, 37), py(a - 6, 37), px(a + 6, 37), py(a + 6, 37), STROKE, c_grey);
        ln(r, px(a + 6, 37), py(a + 6, 37), px(a + 4, 27), py(a + 4, 27), STROKE, c_grey);
    }
    /* the ring, clockwise from 12 o'clock: tape, sounds, ... free */
    if (ready) file_steps(s->bytes, steps);
    int at = TOP;
    for (int c = 0; c < OP1_STORE_N; c++) {
        int n = ready ? steps[c] : (c == OP1_STORE_FREE ? STEPS : 0);
        for (int i = 0; i < n; i++)                         /* two steps per line: they overlap, no gaps between */
            ln(r, px(at + i, RING_R), py(at + i, RING_R), px(at + (i + 2 < n ? i + 2 : n), RING_R),
               py(at + (i + 2 < n ? i + 2 : n), RING_R), RING_W << 10, cat_col[c]);
        at += n;
        if (n && n < STEPS)                                /* a dark seam where the next category starts */
            ln(r, px(at, RING_R - RING_W / 2), py(at, RING_R - RING_W / 2), px(at, RING_R + RING_W / 2),
               py(at, RING_R + RING_W / 2), 1 << 10, c_black);
    }
    /* the hub: the free space */
    if (ready) {
        file_size_text(s->bytes[OP1_STORE_FREE], v);
        for (char *p = v; *p; p++) if (*p == '.') { p[0] = ' '; p[1] = 'M'; p[2] = 'B'; p[3] = 0; break; }   /* whole MB */
    } else { v[0] = '.'; v[1] = '.'; v[2] = '.'; v[3] = 0; }
    sf_text(r, (CX << 10) - text_w(v, FS) / 2, (CY - 9) << 10, FS, v, STROKE, c_text);
    sf_text(r, (CX << 10) - text_w("FREE", FS) / 2, (CY + 3) << 10, FS, "FREE", STROKE, c_grey);
    /* the legend: dot, name, size (right aligned) */
    for (int c = 0; c < OP1_STORE_N; c++) {
        int y = 21 + c * 14;
        dot(r, 172 << 10, (y + 4) << 10, cat_col[c]);
        sf_text(r, 180 << 10, y << 10, FS, cat_name[c], STROKE, c_text);
        if (ready) file_size_text(s->bytes[c], v); else { v[0] = '-'; v[1] = '-'; v[2] = 0; }
        sf_text(r, (314 << 10) - text_w(v, FS), y << 10, FS, v, STROKE, c == OP1_STORE_FREE ? c_text : cat_col[c]);
    }
}

static void fv_update(void *scr, int dt)
{
    op1_screen_draw(scr, dt);
    if (op1_flash_shown()) { op1_flash_draw(op1_raster()); return; }
    op1_storage_t s;
    int ready = op1_storage(&s);
    file_draw(op1_raster(), &s, ready);
}
static void fv_init(void *scr) { (void)scr; }
static void fv_push(int knob)                         /* -1: shown; blue: flash check (again); others: walk again */
{
    if (knob < 0) { op1_flash_close(); return; }
    if (knob == 0) { if (op1_flash_shown()) op1_flash_push(0); else op1_flash_open(); return; }
    op1_flash_close(); op1_storage_refresh(); op1_toast("counting");
}

static const op1_screen_t fv_screen = { fv_init, fv_update };
static const op1_page_t fv_page = { 0, "usbout.svg", &fv_screen, fv_push, 0 };   /* empty svg: drawn in code */
static const char *const fv_claims[] = { "view:com", 0 };
const op1_feature_t FEATURE_file = {
    .api = OP1_FEATURE_API, .priority = 500, .name = "file", .com = &fv_page, .claims = fv_claims,
};
