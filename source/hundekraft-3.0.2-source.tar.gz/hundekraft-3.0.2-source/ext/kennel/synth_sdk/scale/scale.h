/* Scale mode (scale.c): the interface its controls and tests use.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef SCALE_H
#define SCALE_H

/* 0 OFF, then major, minor, dorian, phrygian, lydian, mixolydian, locrian, harmonic minor, melodic minor */
#define SCALE_TYPES 10

int scale_map(int note, int root, int type);    /* the note a key plays: itself, a scale note, or -1 (silent) */
void scale_set(int root, int type);             /* root 0..11 (C = 0), type 0..SCALE_TYPES-1 */
int scale_root(void);
int scale_type(void);
int scale_turn(int knob, int delta);            /* white (2) / orange (3) encoder turn: 1 = changed */
void scale_draw(void *raster);                  /* the key overlay (synth T2 with Shift held) */

#endif
