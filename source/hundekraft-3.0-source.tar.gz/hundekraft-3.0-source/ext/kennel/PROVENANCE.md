# Provenance

Every part of kennel that came from somewhere else, with the exact commit. Update this file whenever code is
imported or re-synced.

| Part | Source | Commit | License | Notes |
|---|---|---|---|---|
| Everything under `synth_sdk/`, `toolchain/`, `tools/`, `LICENSE`, `.gitignore`, `docs/op1r-src-README.md` | op1r-src (pcppcp/op1r-src), via hundekraft's branch `hk28-base` | 175ca8c60ccb9de3daa40a1e7fd2042b25af95fd | GPL-3.0-or-later + OP-1 firmware permission | Imported unchanged (kennel commit "Import op1r-src 175ca8c"). The README moved to `docs/`. |
| ↳ op1r core, engines, effects, sequencers, screens | op1r-src main | df30df0 | same | pcppcp and contributors |
| ↳ mixtur, arc, palme, in a room (`sitting`), oracle, peal | ultralazr's Musica Obscura, op1r-src #1 | merged in df30df0 | same | |
| ↳ chord mode (`synth_sdk/chord/`, hooks) | hundekraft branch `chord-hk` | edb5af3, 78c536b | same | |
| ↳ safer SysEx update (`synth_sdk/devupd/`) | hundekraft branch `devupd-safe` | 175ca8c | same | |
| Sound loading safety: `kennel/kn_patch_safe.c`, drum+ gate word (`drumplus/dp_ui.c`), `fx_name_eq` (`dispatcher.c`), hook 0x01A051F8 | hundekraft branch `hk272-base` (op1r-src, hundekraft 2.7.2) | 8f0374d, 50e1811 | same | Adapted: drum pad clamp and FX/LFO reset moved from `drumplus/dp_fw.c` / `patch_safe.c` into one core file; the drum retry runs inside kennel's drum load scope |
| `synth_sdk/plugins/eva/eva-art.svg` | The EVA screen art: an artist's vector drawing of the owner's astronaut design, supplied by the owner (astro-1.svg, 2026-10-16) | - | The owner's (added at the owner's ask) | `gen_svg.py` converts it into `eva.svg`; replaces the earlier trace of `eva-reference.png` |
| `synth_sdk/plugins/hail/hail.c` (DSP part) | Mutable Instruments Beads, pichenettes/eurorack `beads/dsp/` (https://github.com/pichenettes/eurorack, beads last changed in d8f47391, 2026-10-11) | f4cfa7697095a28d292bff758beb51deb49b5a86 | MIT (Copyright 2017 Emilie Gillet; `synth_sdk/plugins/hail/LICENSE.beads`) | Ported to fixed point and C by hundekraft (granular mode only; the list of changes is in `beads.c`'s header). MIT code may be linked into the GPL firmware. The repository's README asks derivative works not to use the "Mutable Instruments" name and recommends not keeping the module's name: shipped as HAIL (owner, 2026-10-16); the credit to Mutable Instruments Beads stays in the source, this file and LICENSE.beads |
| `kennel/kn_midi.c` (parameters like a knob turn, KeyHandler queue pushes, stock sequencer key map, SEQ + TAPE view keys and screen object), MIDI sequencer and CC automation (feat-midiseq) | op1r-src main (op1r 35: `midi/mx.c`, `seqdev/ms_*.c`) | 5c90efb4e6f15260bdf672a0a7bb6dde9f5625d4 | same | pcppcp. Fetched into OP1-Emulator `ext/op1r-src35`. Adapted to kennel's services (op1_feature_midi.h); state in the arena |
| `synth_sdk/plugins/clouds` (our changes, branch feat-clouds-cap) | op1r's Clouds port (op1r-src, row above), Mutable Instruments Clouds (MIT) | kennel main 0295b7e | same as the row above | hundekraft modification for the 3.0 audio budget: bit-exact speed-ups in `clouds_dsp.c` (32-bit `mulq15`, fused grain loops, per-block grain set-up, reverb and diffuser offsets as constants) and a grain budget while the reverb runs (`CLOUDS_GRAIN_BUDGET` in `clouds.c`). Worst case 202k -> 112k packets per FX call. Then (branch feat-clouds-cpu) the grain envelope per 64 samples, the reverb at quarter rate, dry / wet per block, the grain pool 24 / 18 (reverb / reverb and diffusion; the owner kept the dense textures): ~55k; `harness/clouds_cap_check.py` |
| `synth_sdk/plugins/reverb` (our changes, branch feat-reverb-cpu) | op1r's Reverb (op1r-src, first row), a port of Mutable Instruments Elements' reverb (MIT, Copyright 2014 Emilie Gillet) | kennel oxbow-merge 4259109 | same as the first row | hundekraft modification for the unit's CPU: bit-exact speed-ups (mirrored line, constant offsets, per-block knob scaling, 32-bit LFO step), then half rate (22.05 kHz: delay lengths and LFO sweeps halved, loop low-pass mapped to the same cutoff, two-sample mean in, linear interpolation with a small high boost out). 33.8k -> 11.1k packets per FX call; `harness/reverb_cpu_check.py` |
| `synth_sdk/plugins/{wavetable,taffy,pew,elg,washer,snowglobe}`, `synth_sdk/hk/engine.h`, `fx.h` | hundekraft's own engines and effects, OP1-Emulator `tools/engines/<name>`, `tools/fx/<name>`, `tools/engines/engine.h`, `tools/fx/fx.h`; the adapter from `tools/firmware/op1r_plugins.py` | 387a1722004c3de9943b2d4c2539e510f5d65016 | hundekraft's own code, GPL-3.0-or-later with the OP-1 firmware permission here | Imported by `tools/kennel/import_hk_engines.py`: sources byte for byte except the header include path and a licence line; packed images equal the 2.x wrappers'. The headers gained host-only `HK_SCREEN_HOST` branches |
| `synth_sdk/plugins/oxbow/` (Oxbow; `oxbow.c`, `obv_dsp.h`, `obv_programs.h`, `obv_tables.h`, `gen_tables.py`) | OberVave by zvenson (github.com/zvenson/obervave), `firmware/src/obv_engine.h`, `obv_dsp.h`, `obv_params.h`, `obv_patches.h`, `firmware/gen/obv_tables.h`, `tools/gen_tables.py` | a2fb3d0 (2026-10-15) | OberVave is GPL-3.0-only; zvenson gave the owner permission on 2026-10-15 to use this code in kennel under kennel's terms (GPL-3.0-or-later + OP-1 firmware permission). Recorded as the owner reported it; no written copy linked | The voice engine and the 32 programs, adapted to the kennel engine API (see the file headers). OberVave's FM-1 platform (Felucca / SLOOP code) is not used. `presets.py`, `harness/oxbow_check.py` and `oxbow_test.c` are new hundekraft code |
| `synth_sdk/plugins/oxbow` (our changes, branch feat-oxbow-cpu) | OberVave by zvenson (row above) | kennel oxbow-merge c19c142 | same as the row above | hundekraft modification for the OP-1's audio budget: the samples in passes over the block, no division per tick (exact table reciprocals `rcp30` / `div25`, RCP_Q / RCP_S from `gen_tables.py`), the pitch, pulse widths and LFO every 32 samples instead of 16 (envelopes, amp and filter coefficients stay at 16). Worst case 32.2k -> 17.2k packets per voice call (budget.py); every program within 0.06 dB of OberVave's control rate; `harness/oxbow_check.py` locks the result |
| `synth_sdk/plugload/op1p.h`, `op1p_load.c`, `op1p_load.h` | op1r-src main (op1r 34) | a04e3bcb23a6f5a81f1fe56468cf976327cc7093 | same | Copied unchanged; `kennel/kn_boot.c` follows `plugload/plugload.c` for the number map, DB rows, crash marker and master FX lookup |

Not imported: Maiko's #249 utilities (no licence or permission yet), TE firmware. Scale mode (`synth_sdk/scale/`) is
new hundekraft code written from #249's documented behaviour (OP1-Emulator `docs/maiko249-audit.md`, the workshop
manual, emulator screenshots), not from its code or bytes.

`synth_sdk/l1_patches.json` holds byte differences inside R246's encrypted code, as op1r-src publishes them. It is
not covered by the GPL (see NOTICE).

Baseline check (2026-10-15): building this tree with OP1-Emulator's `op1r_plugins.make_base` and the
`op1r30mo-chord-plugins` profile gives `reference.op1` SHA-1 1578db1a724f1180a56c639bef810460c3ba5d37, the same
as the build from op1r-src 175ca8c. Rerun: `python3 tools/kennel/baseline_check.py <OP1-Emulator> <new dir>
1578db1a724f1180a56c639bef810460c3ba5d37` (from the OP1-Emulator root).

This SHA-1 holds up to kennel 0bf26ae (docs only). From 34df4f3 on (type-name hook) the image differs on purpose;
the test of that change is in docs/preset-identity.md. From 782debc the check also builds with devupd off (kennel
owns 0x019F01B8), so it cannot reproduce the 2.8 base any more: the import SHA-1 above is historical. Current check
for kennel changes: the build succeeds, the host tests pass, and an emulator boot when the firmware changes.

## New current-3.0 plugins (2026-10-16)

- Crush, Warble and Plate reconstruct Maiko #250 custom DSP/art with the owner's
  explicit permission given on 2026-10-16. The private package SHA256 is
  `1fd0a0dbd25acf9c20e8eebf503a76280ef70dbc2334f8487ea8e6db723a3f17`;
  decoded custom region SHA256 is
  `09c22c233dc9a84b6e9674f0a1670f5c8f0ca8331dc819d97d4133fd58681c7a`.
  Plugin READMEs record individual function/art descriptor addresses and portable-C
  differences. Only Maiko custom art is converted; no TE generic SVG/font, firmware,
  keys or NAND is included. This is static recovery plus bounded port evidence, not
  proven original-firmware sample identity. Original runtime cadence is unmeasured.
- SID adapts selected oscillator/filter primitives and 8580 tables from Hermit
  (Mihaly Horvath)'s cRSID 1.58, original source archive
  `https://hermit.cucumalac.hu/cRSID-1.58-with-source-code.tar.gz`. The author's
  permissive notice and credit are retained in the plugin source/README. OP-1 voice
  management, coefficient caching, state bounds and output coupling are local adapter
  choices; no C64 CPU/tune player or cycle-exact/6581 claim is made.
- C64arp is original code informed by documented relative pitch tables, not copied
  C64 player code. Its README links the GoatTracker manual and authored SID-player
  explanation. SID/C64arp reference PNGs were generated at the owner's request;
  prompts and generation provenance are in root `docs/design/c64/`. Flat palette,
  contour simplification and native black-cutout conversion are documented deviations.
- `display/pixel_svg.py` is original exact composited-pixel rectangle-cover tooling.
  The root workshop card SVGs are illustrative source artwork, not emulator captures.
  Native renderer restrictions and actual allocation/rendering checks remain separate
  from browser/host raster fidelity.

Father is original kennel reverb DSP and original measured vector reconstruction
from the owner's supplied Father video, matching xylograph's public demonstration.
It is not covered by or attributed to the separate Maiko permission above. The
private video's hash, frame bounds, projection observations and deliberate limits
are recorded in root `docs/design/father/README.md`. No raw video, extracted frame,
TE font or original Father DSP is imported. Julius O. Smith's FDN description and
the official Mother control guide inform the separate sound design; no source code
from those references is copied. Plugin README and generated-table comments record
local algorithm/geometry choices.

## op1r 36–40 native feature import, 2026-10-18

Source pcppcp/op1r-src `7cf11afc2bade31f0fb08d3af877b9bb04f970bd`, packaged docs
pcppcp/op1r `bd87d3653979f74929ec14b3b1b11efae56b3224`. GPL-3.0-or-later with
OP-1 firmware permission (upstream LICENSE/NOTICE); original file copyright lines
retained. Imported `plugins/aether/*` (satellite art DAN76/Rackes),
`plugins/clouds/clouds_dsp.{c,h}`, `plugins/reverb/{reverb.c,gen_svg.py,kali_geom.h,
kalireverb.svg}`, upstream `plugins/sitting/sitting.c` into `plugins/in_a_room/`,
`samplerplus/*`, `seqdev/ms_draw.c` into `midiseq/`, detailed `screens/sysmon.c`,
and public envelope/drawing helpers. Native integration by Hundekraft under same
terms; existing kennel plugin identities, claims, loader/recovery and owner screen
corrections retained. Reverb uses two decimals (native packer repeated-vertex guard),
MIDI drawing keeps existing controls, In a Room keeps compact selectors, sampler
browser uses core relocated-table readers and native feature registration.

Randomiser `rn_{core,draw}.{c,h}` and `rn_fw.c` from upstream `randomiser/`, original
Lewis-Clayton/pcppcp. Rewritten as native feature, not tool ABI. Fade derived from
`screens/overlay.c`, ADSR idle path from upstream `hook.S`/`samplerplus/sp_core.c`.
Core sound services and native sampler descriptor/event registration are kennel
code. Upstream preview images copied into parent manual/cards with provenance
captions; they are not newly captured kennel frames.

Owner feedback changes: EVA pitch-linked beeps, STUTTER stable selector mapping,
C64arp Gate replacing Run, Oxbow neutral voice/normal presets (original OberVave
copyright/permission retained), physical key octave identity tracking and explicit
note-stage reset. No test or runtime acceptance claim for these edits. Details in
parent `docs/op1r-36-40-port-2026-10-18.md`.

## MIDI Tape completion (2026-10-18)

Imported `synth_sdk/seqdev/ms_core.{c,h}`, quantize/width additions in `ms_draw.{c,h}`, and core regression cases from pcppcp/op1r-src `7cf11afc2bade31f0fb08d3af877b9bb04f970bd` (op1r40), GPL-3.0-or-later with OP-1 firmware permission. Adapted first-note start/count-in/quantization glue to native kennel services; retained bounded MIDI queue/source ownership, independent screen construction, optional count-in provider registration and deferred main-loop editing. Quantize insertion preserves the original note if allocation fails. EVA octave selector is local code, retaining existing artist geometry.

## op1r parity completion —2026-10-18

Source pcppcp/op1r-src `7cf11afc2bade31f0fb08d3af877b9bb04f970bd`, GPL-3.0-or-later with OP-1 firmware permission: restored Quad LFO slot enable guards/display neutral state from `lfo/quadlfo.c`; adapted sound JSON preflight from `patch_repair.c` to native selective error repair with existing pad clamping/logging; imported three checked preset parse hook sites and boot-volume byte plus collision range checking from `make_firmware.py`/`hook.S`. Dispatcher counters cover complete stock/plugin dispatch, keeping plugin overload budgets separate. Native tape write safety now reserves a full64KiB core BSS snapshot rather than allocating from the plugin arena, preserving undo's complete-write event semantics. Parent report `docs/op1r-parity-audit-2026-10-18.md`.

2026-10-18 follow-up review: native JSON conversion preflight, bounded tape I/O/seek validation, cache-source ownership/retry and nested-write guard are Hundekraft changes under the same GPL-3.0-or-later + OP-1 firmware permission. R246 call behavior was checked against private decompiler exports, not copied as firmware bytes. Parent report `docs/op1r-fix-review-2026-10-18.md`.


## Gin native drum synth (2026-10-19; local port)

Instrument/DSP/editor/factory source: SquareWave Studio, `joseph-holland/op1r-src` commit `ec5d6f722df05b77f80706db239352992937f4d7`, `synth_sdk/experimental/gin/standalone`, referenced by `squarewave-studio/op1-mods` Gin1.0 release `1a6385a4a2ba76bab3758eecf1bb289c9c09bd94`. Imported matched native source at `synth_sdk/plugins/gin/vendor/`, preserving NOTICE/LICENSE/component MIT and GCC runtime notices plus `PRESET_CREDITS.json`. Native host/editor GPL-3.0-or-later with OP-1 permission; synthesis/libpo32 MIT. CNTR RNDM kit permission records retained. Core native register/DAG/loop preservation in `kennel/kn_drum_synth.S` derives from the same source. Kennel changes replace standalone hook/stack ownership with core services and scope input/save/screen integration. No extracted stock prefixes/font bytes imported: generated privately from qualified owner R246. Four-voice limit and matched rate/fixed-point/gain profiles retained. Combined firmware/hardware acceptance is separate from upstream standalone acceptance.

Gin local lifecycle fixes (2026-10-19) alter the vendored snapshot and native UI
save-status code: identity-checked transactions, per-slot retry state, malformed
state quarantine and save capture refusal while the provider is faulted. These
local changes do not alter the original source receipt or its component licenses.

Gin native activation also invalidates its kit cache on patch replacement; a
matching factory marker alone cannot identify an edited/saved kit.
