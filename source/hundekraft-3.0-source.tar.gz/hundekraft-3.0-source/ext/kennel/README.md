# kennel

Custom firmware runtime for the Teenage Engineering OP-1 (firmware R246). Synth engines, effects and features
such as chord mode will be separate files in a folder on the OP-1's disk that the firmware loads at
boot. You pick what you want by copying files, not by building a new firmware for every combination.

kennel starts from [op1r-src](https://github.com/pcppcp/op1r-src) by pcppcp (GPL) and carries its engines,
effects, sequencers and screens, plus the Musica Obscura plugins by ultralazr and hundekraft's chord mode.

**Status:** working 3.0 candidate runtime. Synths, effects and feature files load at boot; settings stays in
core. Native drum synths, sequencers, LFOs, tape/sampler services and reviewed USB updates are supported.
The API is still changing before release; use the SDK source matching your installed core.

## Make a plugin

The complete author walkthrough is in the containing project's manual, **Make your own plugin**
(`tools/manual/manual.md`, anchor `make-plugins`; rendered as `manual.html#make-plugins` in the workshop).
It covers prerequisites, examples, descriptors, core services, threads, claims, saved state, screens and sharing.
Start with `synth_sdk/template/synth` or `synth_sdk/template/fx`. From this checkout:

```sh
python3 tools/kennel/pack.py synth_sdk/plugins/your_id -o build/your_id.knl
```

Use an ID matching your folder/manifest/output and order0 for a new file. Put the Blackfin tools on PATH,
or pass `--toolchain` (see `pack.py --help`). Packing one plugin needs no original TE firmware.
Install through the workshop's Your own plugins → Review / Send plugin changes. A missing core service
requires a full core update; plugin upload alone cannot add hooks.

## Layout

| Path | What |
|---|---|
| `synth_sdk/` | the firmware code as imported from op1r-src (dispatcher, hooks, plugins, screens, sequencers) |
| `synth_sdk/plugins/` | synth engines and effects, one folder each; numbers in `plugins/ORDERS.md` |
| `synth_sdk/harness/` | host tests and renderers (no firmware needed) |
| `docs/` | design notes; `docs/op1r-src-README.md` is op1r-src's own README (build steps still apply) |
| `PROVENANCE.md` | where each imported part comes from, with commits |

## Building

For a full firmware image, build it the op1r-src way (`docs/op1r-src-README.md`), or from the OP1-Emulator workshop with
`source` set to this checkout. This repository contains no Teenage Engineering firmware; you need your own
`op1_246.op1`.

## License

GPL-3.0-or-later with the OP-1 firmware permission inherited from op1r-src. See [NOTICE](NOTICE) and
[LICENSE](LICENSE). Contributors keep their copyright lines in their files.
