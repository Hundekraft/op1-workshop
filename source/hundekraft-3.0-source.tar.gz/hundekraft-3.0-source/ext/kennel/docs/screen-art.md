# Screen art from reference art

How a plugin screen is made from art someone hands us: an artist's drawing or the owner's design, as a vector file
or as a PNG. The rule for both: **the art is the spec**. The screen should match it shape for shape, colour for
colour, at the same coordinates. Changes are allowed only where the firmware or a moving part forces them, and
each one is written down. Owner-requested placement corrections below are part of the current spec.

Worked example: EVA (`synth_sdk/plugins/eva`, 2026-10-16): the artist's `eva-art.svg` -> `gen_svg.py` -> `eva.svg`
+ `eva_geom.h`. The same drawing as a PNG traced with `art_trace.py` lands within 0.1 px of it (section 3b).

Tools (`synth_sdk/display/`, numpy + scipy + PIL):
- `svgart.py`: reads an SVG (classes, curves, ellipses, transforms, opacity) into flattened strokes and writes
  R246's subset. Plugin generators import it.
- `art_trace.py REF.png -o OUT.svg [--report OUT.json]`: traces a PNG into R246's subset.
- `art_compare.py REF.svg TEST.svg [--region ...] [--overlay OUT.png]`: how far one drawing's lines are from
  another's, per colour.

## 1. Get the art

- **Ask for the vector file first** (SVG, or PDF/AI exported to SVG). It converts 1:1 and needs no guessing. A PNG is
  fine when that's what exists. Then ask for it **lossless, at an exact multiple of the screen (at least 4x: 1280 x
  640), flat colours on black, no glow, blur or JPEG**, and the whole screen as the canvas.
- Keep the file unchanged in the plugin folder (`<name>-art.svg` / `<name>-art.png`) and list it in PROVENANCE.md
  (source, date, licence as the owner states it).
- **The canvas is the screen.** Our screens are 320 x 160 units, so the art maps with one uniform scale (320 /
  width) and no offset. Never pick a scale or offsets by eye: EVA's first trace did (`S = 0.42` and a hand-placed
  origin on a 735 x 365 PNG) and came out about 5 px off. If the canvas isn't 2:1, or the screen is only part of
  it, ask how it maps (`art_trace.py --frame X0,Y0,X1,Y1`). Don't re-lay the art out on our own.

## Placement and OLED bottom margin

The logical canvas is 320 × 160. Fitting inside that canvas in a browser or emulator
has not guaranteed that the lower artwork/readouts are visible on the owner's OLED.
The owner reported this for SID/C64arp, then again for Plate/Warble/Crush/Father.
Current total lifts: **SID/C64arp 4px; Plate/Warble/Crush/Father 12px**.
The first four-pixel FX correction was installed but the owner still saw clipping on
Plate/Warble/Crush. Those three now also move the lower readouts an extra 4px:
40px numbers start at y98 instead of the earlier y110. Father’s earlier placement was accepted; the owner then requested the same 12px total lift for consistency. Preserve it when regenerating
or replacing art. This is an explicit exception to the unshifted-reference rule
above; apply it once, not again to already corrected coordinates.

| Screens | Where the correction lives |
|---|---|
| SID, C64arp | SVG generators translate emitted art; native text helpers subtract four from y. |
| Crush, Warble | `gen_svg.py` passes `y_offset=-12` to `pixel_svg`; live line/text helpers apply the same 12px lift; lower label/value anchors also move up 4px. Crush's hanging cable is intentionally cropped at the top. |
| Plate | `plate_art.svg` / `plate_art.h` retain reference coordinates; `plate_screen.c` translates shared raster vertices, live lines and text by 12px; lower text anchors move up 4px. |
| Oxbow | The uniform 80% shrink was rejected as too small. `gen_svg.py` restores width with SX=160/852 and fits height separately with SY=132/852, centred x and y=6+(reference_y-89)*SY (bottom y138). Regenerate SVG and `oxbow_geom.h` together; bird dx uses SX, dy uses SY. Circles/stars keep equal-axis proportions. No extra translation; preserve readable strokes, native-safe rounded joins and compaction. |
| Father | `gen_svg.py` translates emitted static paths; `father_geom.h` retains reference coordinates, and `father_screen.c` translates live lines and native text by 12px after projection. The green `gate_person` and door bars follow Gate duration/audio-gate gain. |

For new layouts, keep essential artwork/readouts comfortably inside the canvas;
use the project's y≈14..138 composition target as a starting point. Include the
whole native glyph, stroke width and maximum animation travel, not just the text
anchor or the default pose. The per-screen corrections above belong to those six
screens; it is not a measured universal OLED crop or an automatic extra offset for
every plugin. The first correction has host/native evidence, but the owner accepted only Father on the OLED.
The subsequent three-screen correction and green-person feedback were rebuilt without tests;
their hardware result remains open.

When changing placement:

- Move static SVG/shared-raster art, procedural geometry, text/readouts, pivots,
  clip bounds and moving masks together. Apply each offset once at the appropriate
  emission/drawing boundary, and keep generators consistent with checked-in output.
- Full-canvas bypass/dimming veils keep their 320 × 160 coverage. Record intentional
  edge crops, such as Crush's cable and Father's near-distance extrapolation.
- Check defaults and min/max controls, widest readouts and animation extremes with
  glyph/stroke extents included. Compare actual native captures for static/live
  alignment and lower-edge clearance; host bounds alone do not prove OLED visibility.
- Keep hardware acceptance separate until the owner checks the corrected files on
  the unit. Record that result before calling the physical clipping resolved.

The project design authority is
[engine-screen spec, decisions 36–42](../../../docs/design/engine-screens/spec.md).
The dated implementation and bounded evidence are in the containing project's
`docs/log/2026-10.md`, entry “Four FX screens raised; Father green/white feedback”.

## Compacting existing SVG markup

`display/compact_svg.py` is used by the C64arp and Oxbow generators. It preserves
coordinate strings and precision, IDs/group structure, drawing order, colours and
active stroke widths/caps/joins. It removes whitespace, spells line/polyline geometry
as equivalent explicit M/L paths (ID-bearing lines stay lines), and removes stroke
parameters only where the stroke is explicitly `none`. It does not simplify points,
merge filled contours, introduce inherited paint/CSS, shorten hex colours or change
the existing OLED placement correction. Keep compaction in the generator so later
regeneration preserves it. Serialization equivalence is separate from pixel comparison;
the owner requested no tests for the 2026-10-17 C64arp/Oxbow update.

## 2. Compare before building

Render the art and our current screen side by side, whole and zoomed (4-10x) on the details, with headless Chrome:

```
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --disable-gpu \
  --window-size=960,968 --screenshot=out.png file:///path/compare.html
```

`compare.html` holds two `<img>` tags (art, ours) on black. Chrome lacks the artist's fonts (EVA: Flama), so an
SVG's text falls back to a serif; compare the letter shapes from a PNG or PDF of the art instead. When there is a
screen already, measure it too: `art_compare.py ART.svg|TRACE.svg OURS.svg --region ...`. Write the differences
down (position, size, colours, line quality, details) before changing anything.

## 3a. From a vector file: convert, don't redraw

R246 draws only `line`, `circle`, `path` with M/L/Z, `polyline` and `g`, with fills; no curves, ellipses, transforms,
opacity or text (spec: OP1-Emulator `docs/design/engine-screens/spec.md`, "Medium limits"). `svgart.art()` reads the
art and `svgart.element()` / `shape()` write those:

For new generated filled artwork, use one contour (one `M`) per `<path>`.
R246's fill walker at `0x01A25240` sends later move and line vertices through the
same edge accumulator; disconnected subpaths in one filled path are joined rather
than filled independently. This produced large filled triangles in the actual Plate
screen on 2026-10-16 despite an exact browser/host raster. The path parser at
`0x019FCA1C` handles `M` and `Z`, but that does not give the fill walker independent
contours. Separate simple paths avoid this behavior. This finding does not establish
an equivalent restriction for stroked paths.

Generators and focused checks for the new filled art should assert one `M` per filled
path, then verify actual native rendering and allocation limits. Do not apply a new
blanket rejection to stock SVGs or existing plugins: this is a scoped preflight rule
for newly generated art. Host raster equality alone cannot prove native rendering.

| In the art | On the screen |
|---|---|
| `<style>` classes, presentation attributes | read per element (classes win); the CSS default fill (black) applies when nothing sets one |
| cubic `C`/`S`, relative or absolute, `H`/`V`/`L` | flattened to polylines, adaptive, within 0.05 px of the curve |
| `ellipse`, `circle`, `rect`, `transform` (translate, rotate, matrix) | closed M/L/Z paths, points about 1.2 px apart, transform applied |
| `opacity` on a stroke | the colour mixed over black (`#4E4A9E` at 60 % -> `#2F2C5F`) |
| black fills (the artist hides lines with them) | `#010101` fill (and a 0.2 px stroke), as stock does |
| the full-screen black `rect` | left out; the screen is black |
| `<text>` | drawn with our stroke font at the art's place and cap height (Flama 12 px -> 8.5 px caps) |

Keep the art's draw order, stroke widths (1.5 px) and round caps. Write at most two decimals (R246 halts on more
than four), then drop points where the line doesn't move or turns back on itself (`no_turnback`; R246 draws such a
turn as a spike to the screen edge). Pick elements out by something stable in the file (a path's start point, an
id, the distance from a known centre), never by their index.

## 3b. From a PNG: trace, then measure

`art_trace.py` does what a careful hand would, and writes what it measured (`--report`):

- **Colours are measured, not chosen.** It reads the colours at the centre lines (where antialiasing doesn't
  reach), clusters them, and writes them as found, unless the owner asks for the stock palette. Colours that are only
  another colour's antialiased edge are dropped. Check the palette in the report against the art. A real colour that
  is a 50-95 % copy of another one (the same hue, darker) looks like an edge to the tracer: give the palette with
  `--colors` then. The old EVA trace wrote `#698EFF` (the stock blue) for the artist's `#4D9EFF`. That came from
  the code, not the PNG.
- **Stroke width is measured** from the antialiased coverage across each line (EVA: 1.5 px at both sizes below),
  not guessed. The old trace used 1.8.
- **Lines are fitted, not followed.** Centre lines (Zhang-Suen) are split at junctions. Thinning spurs are
  dropped (short branches whose pixels the rest of the line already covers; a small plus of the art's own stays).
  Straight continuations are joined, and free ends are moved out to where the colour ends. Each line is smoothed
  along its length and split at corners, then fitted: a circle or a straight line where it is one, else
  least-squares cubic Beziers (within 0.15 px), flattened within 0.05 px. The old trace followed the pixel
  staircase and simplified it, which is where its wobble came from.

Measured on EVA, the artist's SVG rasterized by Chrome and traced back, against the vector lines, in screen px over
the astronaut (x < 180; the meters are rebuilt anyway and their text is a font fallback in Chrome):

| PNG | traced line -> art (median / 95 % / within 1 px) | art -> traced line (median / 95 % / within 1 px) |
|---|---|---|
| 1280 x 640 | 0.10 / 0.30 / 100 % | 0.10 / 0.44 / 99.1 % |
| 736 x 368 | 0.11 / 0.40 / 100 % | 0.12 / 0.55 / 98.5 % |
| the artist's own export, 735 x 365 | 0.26 / 0.66 / 99.7 % | 0.28 / 0.80 / 97.9 % |
| the same, aligned (see below) | 0.12 | |
| old trace of that export (hand-placed) | 2.16 / 7.3 / 22.2 % | 2.31 / 7.5 / 20.7 % |

The artist's export traces as well as Chrome's raster once aligned: its drawing sits 0.6 px right and 0.2 px low
of the vectors (scale 0.998). A 735 x 365 canvas isn't an exact multiple of 320 x 160 (the export rounded the
artboard's millimetres to pixels). That framing error is the export's, and no tracer can see it. So ask for an
exact multiple (1280 x 640, 1920 x 960). When only an odd size exists, say the screen may be up to about a pixel
off, and check the art's edge-to-edge parts (horizon, frame) against the screen edges.

**The bar for a PNG screen:** traced line -> art within 1 px for at least 99 % and a 95th percentile under 0.5 px,
measured with `art_compare.py` against the trace of the reference. Whatever falls outside goes on the list in step
6. To check the tracer itself, rasterize a vector drawing and trace it back:

```
# art.png: the SVG at 1280 x 640 (headless Chrome screenshot of an <img> that size)
python3 synth_sdk/display/art_trace.py art.png -o trace.svg --report trace.json
python3 synth_sdk/display/art_compare.py art.svg trace.svg --region 0,0,180,160 --overlay overlay.png
```

The overlay draws the art in magenta and the trace in green, white where they agree: an offset or a missing line
shows at once.

What a PNG can't give you, and what to do about it:
- **Details under about three stroke widths** (EVA's crosshair: ring pieces cut square by black shapes, a 2-px
  ring whose hole is under a pixel) come out approximate: shorter and straighter pieces, a blob for a tiny ring.
  These show as "missing" in the comparison (EVA green: 95 % of the art within 1 px, the rest is the crosshair).
  Measure them in the PNG (centre, radius, gaps, at the art's size) and draw them as primitives, as EVA's
  `cross()` does.
- **Cut-outs vs gaps**: in a PNG an artist's black cut-out and a real gap look the same. For a moving part, draw
  gaps (section 4).
- **Text**: identify the font with the owner. Measure cap height and baseline in the PNG, and draw it with our
  stroke font. Don't keep the traced letters.
- **Occlusion**: which line is on top where two cross. The tracer draws darker colours first; check crossings in
  the overlay.

## 4. Moving parts

Every part the screen code moves is built from the art's own geometry at the art's own place, and the numbers the C
code needs go to `<name>_geom.h` from the same script, so the SVG and the code can't drift apart.

- **Meters**: rebuild the art's ticks as a lit row plus a sliding mask (a black box with the dim ticks). The mask
  slides by one fixed step, so use one even spacing that fits the art's ticks (EVA: 5.66 px, within 0.11 px of
  every tick). Dim ticks: the art's colour at its opacity, mixed over black.
- **Black cut-outs in a moving part**: the artist may cut gaps with black shapes drawn on top (EVA's crosshair had
  a black ring and eight black boxes). Once the part moves, those would blank out whatever is under it, so draw the
  gaps as real gaps instead. Where the art has butt-ended cuts, use filled shapes with straight edges: round caps
  make the gaps look wider than the artist's.
- **What a part hides**: if moving a part uncovers something the art never drew (EVA's left eye under the
  crosshair), draw it from the nearest matching thing in the art (the other eye, moved), hide it under the part at the
  art's position, and pick the travel so both ends land somewhere that reads well (EVA: left eye to right eye).
- **Shapes we add** (EVA's fog): keep them inside the art's own edges, in the art's colours.

## 5. Check

- Render the art and the new screen side by side again, whole and zoomed. At the art's own state (`--state
  design`, the art's lit ticks) they should be hard to tell apart; any difference left is one of the forced changes.
  For a PNG, also `art_compare.py` the screen against the trace of the reference (the bar in 3b).
- Render every state the code can reach (all knobs at 0, at max, the defaults) and look at each moving part
  zoomed.
- `python3 synth_sdk/harness/svg_check.py <plugin dir>` (decimals, turn-backs).
- The plugin's own check (EVA: `harness/eva_check.py`, which writes the previews), then `harness/golden.py`: look
  at `build/golden/out/engine_<name>.png` (R246's raster as `oprender.py` draws it) before `--update`.
- `make -C synth_sdk/harness check`.

## 6. Write it down

In the generator's header: the source file, what is converted 1:1 or traced (with the measured numbers for a
PNG), and every deliberate change and why. In OP1-Emulator's `docs/design/engine-screens/spec.md`: a decision row.
FILE_MAP.md: the art file and what generates the screen.

## Native static-prefix cache (2026-10-19)

`op1_screen_draw_cached(scr, dt, first_live)` is an opt-in Gfx-thread service. Use it instead of
`op1_screen_draw` only when the SVG draws first on a cleared raster and every top-level child before
`first_live` is immutable and always visible. Resolve `first_live` by ID in init; pass NULL only when the
entire SVG is static. The cache retains pixels, not a simplified vector approximation. Never include
knob-dependent transforms, visibility, recolouring or live readouts in the static prefix. Leave all those
nodes in the original suffix order, followed by procedural animation as usual. MBIRA's boundary is `l0`,
HAIL's `primary0`, and STUTTER's `reel`; C64arp/Warble have entirely static SVGs. Source art is unchanged.

Two 96 KiB run buffers are allocated after plugin loading, only with 64 KiB arena headroom left. Storage is
outside the TE drawing heap. A full arena, an oversized prefix or unsupported panel uses ordinary SVG;
there is no extra allocation in update. Successful capture frees static vector raster caches through the
normal document reset, then the mutable suffix is drawn. Repeated calls and page returns replay exact
native RGB565 pixels. The current cache handles only the verified default raster (198 active columns,
400 rows,512-byte stride); other display variants keep the native renderer. Shared-screen retirement,
stock ID-change resets and pressure cleanup must stay enabled. Reordering shapes or caching interleaved
moving artwork such as Oxbow/EVA is not safe under this contract.

Native measurements and pixel acceptance: parent `docs/screen-optimization-2026-10-19.md`.
