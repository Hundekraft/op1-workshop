# Feature hooks

<!-- Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). -->

Engines and effects fill fixed slots. A feature (chord mode, a sequencer, the quad LFO, tape tools) reaches into
several places of R246 at once. Rule: **the core owns every R246 patch site**; a feature never patches R246, it
registers callbacks at named hook points and the core calls them. A feature can be compiled into the core or
shipped as a plugin file of kind 3 (`docs/plugin-format.md`); both register the same `op1_feature_t`
(`synth_sdk/op1_feature.h`). Since 3.0 every feature ships as a file (`"loadable"`) except settings, which stays
compiled in because it hosts the switches; harness/matrix.py's "builtin" build compiles op1r's set in again.

## Hook map (2026-10-15, kennel core)

Every patch site in `synth_sdk/link.ld` / `hook.S` / `make_firmware.py`, grouped by the hook point it belongs to.
"Built" = a feature can register there; chord mode is the first user (host test and emulator checks passed
2026-10-15, compiled in and as a plugin file).

| Hook point | R246 sites (core handler) | Used by | State |
|---|---|---|---|
| **Note pipeline** | VoiceCtl key_down / key_up `CALL voicectl_synth_note_on/_off` 0x01A85828 / 0x01A858D0 (`note_pipe_on/off`). Keyboard, MIDI in and every sequencer reach the synth through these. | scale (100), chord (200); later melody, arp | **built** |
| **Music context** | none (core data `op1_music`): key root, scale mask, who set it | chord publishes; scale / melody read | **built** (nobody reads it yet) |
| **Clock pages** | KeyHandler key event 0x019C2D3E (`key_event_hook`), encoder event 0x019C2E94 (`knob_event_hook`), screen construction 0x01A3BD58 / load 0x019F07D2 (`screens_ctor_hook`, `screens_load_hook`); clock mode T1..T4 and Shift+Help (`kennel/kn_pages.c`) | features: sysmon (T1), USB out (T2), settings (T3), chord (T4), Oblique Strategies (clock view) | **built**: T1..T4 + the clock view, compiled in or as files |
| **Key sync** | key event hook: called on every key event (KeyHandler thread) | chord (save settings once per change) | **built** |
| Settings storage | SQLite `op1rsettings` through R246's db2 helpers (no patch site) | chord, settings, sequencers | per feature today; service later |
| **Sequencer types** | `SeqIds::from_name` 0x01A42A2E / 0x01A42BDC / 0x01A42CE0, `SeqIds::name` 0x01A422EC, `PlayerManager::create_player` case 3 0x01A0D150 (`kennel/kn_seq.c`), finger screen slot 0x2D, key / encoder events on it, MIDI START, `seq_types` rows (build) | euclid, dots, oracle, peal (features, `op1_feature_seq.h`) | **built** |
| **LFO types** | `lfo_types` name compares 0x019C9C3A / 0x019C9BE2 (`lfo_name_eq`), every `read_lfo_param` (7 sites, `read_lfo_param_safe`), patch LFO range check 0x01A042A2 (`lfo_range_ok`), LfoMidi vtable apply (`ql_vt_*` stubs -> `kn_lfo_apply_*`) and note-on trigger (`kn_lfo_trig_*`), ScreenId::for_lfo case 4 (`lfo_screen_select`), LFO page press / turn; MIDI CC / START call-outs (`kennel/kn_lfo.c`, `dispatcher.c`) | quad LFO | **built** (one type, MIDI class) |
| Synth / FX engines | iter / filter vtables, `instr_types` / `fx_types` name compares, `read_fx_param` (8 sites), iter read 0x019B9EF8, ScreenId cases, patch type lookups 0x01A03884 / 0x01A04030 | engines and effects (plugin kinds 1, 2) | built (plugin files) |
| Sampler record | input "sampler?" checks 0x019AC8B4 / 0x019ACC7C, record end 0x019DEEF2, sample path check 0x01A01844 | granular (uses_sample) | built in (flag) |
| **Tape** | metronome render in the L1 audio callback (L1 vector `l1v_metro` -> `ci_metro_render`), main loop `CALL tape_c::service(0)` 0x019F0A24 (`ci_service`), tape screen draw vtable slot 0x01911B78 (`tm_screen_draw`), erase `CALL 0x01A54B08` 0x0191B9F0 (`fast_tape_erase`), key and encoder hooks (`kn_tape_key` / `kn_tape_knob`), VoiceCtl key_down / key_up entries 0x01A85750 / 0x01A85840 (note input observers), recording-state CALL 0x01A5CFA8 (`kn_tape_pre`), chunk lookup entry 0x01A54D5C (`kn_tape_lookup`); tape edit events: main loop CALL audio_clipboard_service 0x019F0A2A (`kn_clip_service`), in the service CALL tape_clips_add 0x0191B65A / 0x0191B730 and CALL lift / lift all 0x0191B89C / 0x0191B974 (`kn_clip_*`), CALL tape_clips_split 0x01A56F24 / 0x01A57690 / 0x01A5769C (`kn_tape_split`), CALL tape_clips_join 0x01A577C6 (`kn_tape_join`), set_mode's CALL tape_clips_add at record end 0x01A5828A / 0x01A5830C / 0x01A5838E / 0x01A58432 / 0x01A5857E (`kn_rec_clip_add`); core: `kennel/kn_tape.c`. L1 resampler / wow call-outs and mix-loop meters stay core-only | count-in, punch, markers, fast erase (features); wow (core); tape undo (planned) | **built** |
| **Drum types** | parse keep 0x01A044A8 (`dp_keep_op1r`), load 0x01A04BC0 (`dp_load_parse`), browser start row 0x01977900 (`dp_browser_id`), type job (vtable 0x0190F34C, `dp_type_job`), DrumSampler vtable render / note_on / note_off (0x0190FAC4, `dp_fw_*`), drum_types row id 2, T1 / T2 screen objects 0x10 / 0x17 (`dpu_*`, `SCREEN_drumplus`): all in `kennel/kn_drum.c` | drum+ | **built** (one type) |
| Sound loading safety | synth slot loader CALL parse_patch_json 0x01A051F8 (`synth_load_parse`), drum load 0x01A04BC0 (shared with drum types), fx name compare 0x019AAD8E (`fx_name_eq`): `kennel/kn_patch_safe.c`, `dispatcher.c` | core only (no feature) | **built** |
| MIDI | MIDI START 0x019E39D6, CC 0x01A85C8A, SysEx rx 0x019E3CC8 (dev), OP-Z host mode 0x019E0CFC / 0x019E3540 | sequencer restart, CC mapping, devupd, OP-Z mode; LFO types get CC / START (quad uses neither) | compiled in |
| USB | descriptors 0x01A6ED96, iso IN 0x019E151C / 0x019E161C / 0x019E1812, buffers 0x01A69730 / 0x01A69740 | six-channel USB audio | compiled in |
| **COM view** | the clock pages' sites (key / encoder hooks, screen construction and load); COM slot 0x26, mode 11 (`kennel/kn_pages.c`) | FILE (planned) | **built** |
| **Text entry** | input filter (first), `kn_screens_update` 0x019B2690, main loop (`kennel/kn_text.c`) | naming (planned) | **built** |
| **Four tapes** | no patch site: R246's tape image path buffers 0x01AABCE4 / 0x01AAC934, descriptor 0x018C180C, mount and index 0x01996F38, tape.db box 0x01BAB72C under the db2 lock 0x01BAB718, clip pool reload 0x0195CE88; service in `ci_service` (`kennel/kn_tapes.c`, `docs/tapes.md`) | tapes (keys, toast, REC flash full) | **built** |
| **Tape writeback** | the cache's CALL yaffs_write 0x01A54842 (`kn_tape_write`), COM's CALL disk_mode_toggle 0x01964336 / 0x0196443E / 0x01964616 / 0x01964CFE (`kn_disk_toggle`); drained and flush in `ci_service` (`kennel/kn_tape.c`) | undo (planned) | **built** |
| **Sampler** | none: R246 state (screens 6 / 0x10 and their stock objects, slots, engine types, sample buffers, knob words, the drum pad table) and R246's own setters (patch knobs, drum pad table to patch, the background saver, `sampler_set_base_freq` 0x01A51A08, the JSON `base_freq`); jobs on the main loop (`kn_core_service`); `kennel/kn_sampler.c` | sampler tools (zoom, pitch, fit) | **built** |
| **Storage walk** | none: YAFFS calls from the main loop (`kn_core_service`), `kennel/kn_storage.c` | FILE | **built** |
| **Snapshot save** | main loop CALL of the hold-to-save pass 0x019F0A3C (`kn_save_service`), the date-stamp snprintf CALLs 0x019AD220 (synth) / 0x019AD5A6 (drum) (`_kn_stamp_stub`) (`kennel/kn_save.c`) | naming (`synth_sdk/naming/`, claim `snapshot.save`) | **built** |
| Boot / system | boot access 0x019F01B8 (plugin loader), SQLite page cache 0x0196F942, audio callback immediate 0x0191AB52 and kTE_Idle vtable run 0x01911B98 (sysmon's measuring, `screens/sysmon_core.c`) | loader, sysmon page, cache cap | core |

## API (`op1_feature.h`)

No versions before the first release: `OP1_FEATURE_API` (and `OP1_PLUGIN_API`) stay 1. They only make the loader
refuse a file built against a different core layout; after a layout change, rebuild the plugin files.

A feature exports one `op1_feature_t` (designated initializers; unused fields 0):

| Field | When it runs | What for |
|---|---|---|
| `api`, `priority`, `name` | | version check; order everywhere (lower first: scale 100, chord 200, ...); identity: the plugin's id (`docs/plugin-format.md` "Names"), as `kennel.off` and the inventory use it |
| `note_on`, `note_off` | any thread that plays a note | note pipeline stage |
| `key_sync` | every key event (KeyHandler) | e.g. save changed settings |
| `page`, `view` | clock mode | a T1..T4 page, the Shift+Help clock view (`kennel/kn_pages.c`) |
| `tick(beat)` | audio thread, every 64-sample block | clock-driven features (rolls, melody, loops); short! |
| `seq`, `lfo`, `drum`, `tape` | | hook points with their own headers (`op1_feature_<point>.h`) |
| `event(id, arg)` | main loop (`_TAPE_EDIT`: the editing thread) | `OP1_EV_BOOT_DONE`, `_MODE`, `_SLOT`, `_TRANSPORT`, `_TEMPO`, `_KEY_HOLD` (600 ms), `_TAPE_EDIT` (before and after each edit) |
| `input(in)` | KeyHandler, every key / encoder event before the core | the input filter: return 1 to consume |
| `midi_in(msg, len)` | MIDI CC / START hooks | MIDI in (look, don't change) |
| `note_in` | VoiceCtl key_down / key_up entries | note input observers (synth and drum, before the pipeline) |
| `claims` | boot | exclusive resources (below) |
| `overlay(raster, screen)` | Gfx thread, every frame after all screens | draw over a screen |
| `com` | COM (Shift+COM), toggled by Shift+COM | the COM view, an `op1_page_t` (claim `view:com`) |

Services (core exports): `op1_note_on/off` (next stage), `op1_key_down/up` (play through VoiceCtl), `op1_alloc`,
`op1_toast`, `op1_midi_send`, `op1_setting_get/set(_str)` (op1rsettings, "<feature>.<key>"),
`op1_music_publish` (one owner for the key: the last feature that published on purpose; chord publishes only when
its key, scale or on/off changes), `op1_text_entry` / `_close` / `_open` (text entry screen), `op1_undo_area` (the
SDRAM block for tape undo), `op1_tape_edit_now(arg)` (the tape edit being reported).

- **Text in the stock font is lowercase.** Strings for `op1_toast`, `op1_text_set` and other firmware Text: write
  them lowercase (`a`..`z`, digits, punctuation); the font draws them as capitals. The capitals in `opfont.svg` are
  coloured icons (with yellow width boxes), so an uppercase letter shows an icon on the device, not a letter.
  Our own stroke font (`screens/stroke_font.h`) takes capitals. Host check: `harness/oprender.py` draws the stock
  font (`golden.py`).

- **Note pipeline.** The core sorts features by priority at boot. A stage receives a note and the index `next` of
  the stage after it, and passes notes on with `op1_note_on(next, n)` / `op1_note_off(next, n)` (zero, one or several
  per input note). Past the last stage the note goes to R246's VoiceCtl. The chain is fixed after boot.
- **Note-off rule.** A stage routes a `note_off` by its own record of what it emitted for that input note, never by
  transforming the off event again (chord: `held[n].tone`; scale does the same).
- **Clock pages.** In clock mode a T key toggles its page; while it is shown the four encoder pushes and turns go to
  it. The view (Shift+Help) toggles against the stock clock and is the base view a page returns to; when the core
  shows a page or the view it calls `push(-1)` once.
- **Claims.** A 0-terminated list of names: `page:t1`..`page:t4`, `view`, `view:com`, `tape.erase`, `tape.metro`,
  `tape.lookup`, `lfo:<name>`, `seq:<name>`, `drum:<name>`, `key:<mode>:<combo>`. At boot (`kn_features_finish`)
  the core keeps one owner per claim: a built-in beats a file, then the lower priority, then the name (pairwise, in
  registration order). The loser is switched off completely, logged in `kn_log` and shown as a toast. A feature
  file named like a built-in replaces it. Plugin files carry the same list in their extension table so the
  workshop can warn before installing. Host test: `harness/claims_test.c`.
- **Switched off by the user.** `op1rsettings` key `kennel.off` ("name,name"): the loader and the registry skip
  those plugins and features. The workshop writes it over SysEx (OFF_SET, `docs/inventory.md`); the plugins page
  on the device is not built yet. Read once per boot (`kn_off_boot`).
- **Inventory.** What the registry and the loader decided (claims won / lost, the winner, switched off, replaced)
  is recorded at boot and readable over SysEx (LIST, `docs/inventory.md`).
- **Audio budget** (`dispatcher.c`): every plugin render call is timed; a synth voice over 387,000 cycles or an FX
  call over 193,000 (a third of the block at 400 MHz), 64 times in a row, mutes that plugin (its sounds play the
  stock iter / filter) with a toast.

Registration: compiled-in features through weak symbols in `kennel/kn_features.c`; kind-3 plugin files through the
loader. All before the GUI starts. Cost: a table walk per note, key or MIDI event and per audio block; nothing per
sample.

## Not built yet
Muse (chord-hk e3b569c) on `tick` with a second page state; MIDI note / clock in and a raw MIDI observer; feature
dependencies; the plugins page; crash quarantine; signed files. For tape undo: a hook before the tape cache writes a
dirty chunk back (to keep the audio a recording overwrites, chunk by chunk).

## Undo services: read, restore, clip rows, files, disk event (2026-10-15, branch feat-core-undo)
For tape undo with its history on disk (`docs/maiko-rebuild.md`). API in `op1_feature_tape.h` (tape) and
`op1_feature.h` (files, `OP1_EV_DISK`); all main loop.

- **Read and restore** (`kennel/kn_tape.c`): `op1_tape_read(track, at, len, dst)` and `op1_tape_restore(track, at,
  len, data)` (samples) go through the tape file, as R246's own lift and drop do: the read flushes the cache
  (`op1_tape_flush`) and reads `track base + at * 2` from the tape file (descriptor 0x01B4EF44); the restore flushes
  (every node clean), writes there and calls R246's `tape_cache_invalidate_clean_range` (0x01A540C0; it drops nodes
  without modified tracks in the range and marks the loop seams stale), so playback reloads the restored audio and no
  later writeback can bring the old back. A restore never goes through the cache: no `OP1_EV_TAPE_WRITE` for it. A
  chunk that is playing plays silence until the next cache step reloads it (a few ms); R246's lift and drop are the
  same. Refused (-1) while recording, while R246's clipboard queue has commands (except inside their own
  `OP1_EV_TAPE_EDIT` events), or out of range (track 0..3, samples 0..0xF28000). The LIFT, LIFT_ALL, DROP, DROP_ALL
  and ERASE before events now fire after a flush (`clip_before`, `fast_tape_erase`), so a plain read in them sees the
  current audio.
- **Clip rows** (`kennel/kn_clips.c`): `op1_tape_clips_get(track, out, max)` (count; the first `max` by start) and
  `op1_tape_clips_set(track, clips, n)` (replace-all). R246's pool (`tape_clips_instance` 0x0195BBB4 = 0x01AA8D70: 512
  records {channel, start, stop}, has_clip at +0x1800, free count at +0x1A00); set calls `tape_clips_remove_channel`
  0x0195D688 and `tape_clips_add` 0x0195CCEC per range, which queue the `DELETE` / `INSERT INTO clips` statements for
  R246's background file job, so tape.db stays in step. `tape_clips_add` panics on a range it does not accept, so set
  checks every range first (start >= 0, stop > start, at least the minimum clip length at 0x01AA7360 (0xDC8), start
  <= 0xF23F9F, stop <= 0xF23FA0) and the free rows, and refuses (-1, nothing changed) while recording or with commands
  waiting. Ids are new; ranges come back exactly.
- **Files** (`kennel/kn_files.c`): `op1_file_open / read / write / seek / close / unlink / mkdir` under
  `/yaffs2/user/` only (names of `[A-Za-z0-9 ._-]`, single slashes, no `.` / `..` part, under 120 characters; flags
  `OP1_FILE_READ / WRITE / RDWR | CREATE | TRUNC`, Linux values as R246 uses them, mode 0x180), on R246's YAFFS calls
  (yaffs_open 0x01A997F4, close 0x01A99908, read 0x01A99C90, write 0x01A99F84, lseek 0x01A9A0E4, unlink 0x01A9A3FC,
  mkdir 0x01A9A886). Only handles the service opened are accepted (8 at a time).
- **`OP1_EV_DISK`**: arg 1 from `ci_service` right after the flush `kn_disk_toggle` asks for on the way into disk mode
  (before `disk_mode_toggle` starts USB); arg 0 when `disk_mode_active` (0xFF906EF9) goes back to 0 (the sync of the
  host's changes follows).

Checks: `harness/tape_undo_test.c`, `clips_test.c`, `files_test.c` on the fake core (and `tape_write_test.c` for
`OP1_EV_DISK`). Emulator (OP1-Emulator `run/kennel-undo/check-undo.json`, probe `kntest6/`): a 3 s take on track 0
with a synth note; at the drained event the probe read the first chunk (peak 1600), wrote it to
`/yaffs2/user/kntest/chunk0.bin` and read it back the same, restored silence (read back: peak 0), cleared track 0's
clip (0..141792) and set it back exactly; tape.db on the NAND afterwards has `(0, 0, 0, 141792)`; a USB disk session
gave `OP1_EV_DISK` 1 and 0.

## Tape writeback, drained, flush (2026-10-15, branch feat-core-maiko2)
For tape undo (`docs/maiko-rebuild.md`): a take overwrites the old audio chunk by chunk while it records, so undo has
to keep each chunk's old bytes before the tape cache writes it. `kennel/kn_tape.c`; API in `op1_feature_tape.h`.

R246: the tape cache (24 nodes of 32768 samples x 4 tracks) is written back by `tape_cache_io_step` 0x01A54710 on the
main loop (`tape_c::service`, the CALL at 0x019F0A24 kennel already wraps as `ci_service`; also at 0x019F0BE2 at
power-off): per modified node and track it seeks to `track base (0x018C1810[t]) + chunk * 0x10000` and writes 64 KiB
(CALL `yaffs_write` 0x01A99F84 at 0x01A54842). That is the only way recorded audio reaches the tape file (lift, drop
and erase write the file themselves and have `OP1_EV_TAPE_EDIT` before events). The node list starts at 0x01B4EF3C
(+2 flush request, +0x14 next). Not the audio thread: the record node in L1 only marks nodes modified.

- `OP1_EV_TAPE_WRITE` (arg = track | chunk << 8): the hooked write (`kn_tape_write`) reads the position the stock
  seek set (`yaffs_lseek(fd, 0, 1)`), finds the track and chunk and sends the event before writing.
  `op1_tape_write_now()` has track, chunk, file offset, length (65536) and the new data; `op1_tape_read_old(dst, at,
  len)` reads the old bytes from the file during the event (the core seeks back before the write).
- `OP1_EV_TAPE_DRAINED`: after any tape edit's after event (REC included), once the main loop finds the tape not
  recording, R246's clipboard queue empty and no node with a flush request (checked in `ci_service`).
- `op1_tape_flush()` (main loop): calls `tape_cache_io_step(0)` until it has nothing left (one node per call; at most
  96). Disk mode: COM's four CALL `disk_mode_toggle` (0x01964336, 0x0196443E, 0x01964616, 0x01964CFE, KeyHandler)
  go to `kn_disk_toggle`: on the way in (`disk_mode_active` 0xFF906EF9 is 0) it asks the main loop to flush (the main
  loop owns the tape file's position) and sleeps (`delay_ms` 0x0193E5C0, 10 ms steps, at most 3 s) until it has,
  then enters. The host reads the tape file directly, so a take's end that was still in the cache is no longer lost.

Cost (emulator, 400 MHz): the hook itself is a seek and a table walk. Recording rewrites the same chunk over and over
(about 240 writebacks per second of a take: two takes of 3 and 2 s gave 1223); one 64 KiB `op1_tape_read_old` took
137,000 cycles on average (0.34 ms), 276,000 at most. Reading every writeback would cost the main loop about 8 %; an
undo should copy a chunk only the first time it is written in a step (a bitmap of 4 x 485 chunks) and skip the rest.

R246 also leaves a take's last samples out of the file for a while (emulator, 2026-10-16; stock 2.8 the same, so not
kennel's write path): what the record pass puts into a cache node after that node's final writeback is not marked
modified, so `tape_cache_io_step` and `op1_tape_flush()` don't write it; it reaches the file when the next take on any
track dirties the same node (writeback log: the previous track's chunk, 51..56 samples at its clip end; on 2.8 also
~990 samples at a chunk start, zero in the file before). Until then a power loss or a disk-mode export lacks those
samples (a few ms to ~23 ms of the take's end). The tape session's overdub check compares other tracks by energy for
this reason.
Checks: `harness/tape_write_test.c` on the fake core (old bytes in the event, the new in the file after, drained once,
not while recording or with a queued command, flush, disk mode waits for the flush). Emulator (OP1-Emulator
`run/kennel-maiko2/check-wb.json`, probe `kntest5/`): two takes with a synth note held, lift and drop, a USB disk
session; 1223 writebacks, the old 64 KiB read on every one and different from the new data on 1064; drained 4 times
(each after the last writeback); `kn_disk_toggle` before `disk_mode_toggle` on the way in and out.

## Storage walk (2026-10-15, branch feat-core-maiko2)
For the FILE view (`docs/maiko-rebuild.md`): `op1_storage(&s)` gives bytes on the flash per category,
`op1_storage_refresh()` asks for a new walk. `kennel/kn_storage.c`, no patch site.

- The walk runs on the main loop (`kn_core_service`), 8 directory entries per pass, never on the Gfx or KeyHandler
  thread: `yaffs_opendir` 0x01A9B450 / `yaffs_readdir` 0x01A9B648 / `yaffs_closedir` 0x01A9B74C over `/yaffs2`,
  up to 8 levels deep (deeper directories are skipped). State (a path and 8 open directories) is in the arena.
- Per file it adds the object's data chunks x 2 KiB, not its size: R246's dirent has the object at +0x10C (name at
  +11), the object its type at +0x64 (1 file, 3 directory), data chunks at +0x2C and size at +0x68. `tape_c.raw` (the
  384 MiB FAT image with the tracks and the album) is sparse: about 257 MB on a fresh install.
- Bad = dead blocks x block bytes: the mount entry yaffs' stats dump uses (`0x01A98E52("/yaffs2")`, mounted at +0xC0,
  device = [[+0xD7C] + 8]), blocks +0xCC..+0xD0, block info +0x114 (8 bytes per block; state = word 0 bits 20..23,
  9 dead, 5 full), chunks per block +0x0C. Free = `yaffs_free_space` 0x01A9B1C0, total = `yaffs_total_space`
  0x01A9B284; overhead = total minus everything else (object headers, chunks waiting for garbage collection, the
  reserved blocks' share, checkpoints), so the eight categories add up to the total.
- Categories: tape = `user/tape_c.raw` + `user/tape.db`; sounds = the rest of `user/` (audio, snapshots, op1.db);
  mods = `plugins/` and `.knl` / `.op1p` files directly in `content/`; factory = the rest of `content/`; system =
  everything else (firmware files).
- Cached until disk mode ends (`disk_mode_active` 0xFF906EF9 goes 1 -> 0: the host may have changed anything; nothing
  is walked while it is 1) or `op1_storage_refresh`; the old numbers stay readable during a new walk. The first
  `op1_storage` call starts the first walk (returns 0 until it is done).

Checks: `harness/storage_test.c` on the fake core (a fake tree with R246's layouts: categories, a sparse file, too
deep, disk mode, refresh). Emulator (OP1-Emulator `run/kennel-maiko2/`, probe `kntest3/`, `check-storage.json`):
165 files, tape 256.7 MB, sounds 7.2, factory 23.1, system 2.4, mods 0.02, bad 0, overhead 6.3, free 199.2 MB,
adding up to YAFFS's total (518,914,048); disk mode entered and left through a USB/IP upload (`qa_usb_put.py`,
disk_mode_toggle hit twice, the flag 1 in between) and the walk ran again afterwards (gen 2). In disk mode COM's T3
only shows the DISK page; `disk_mode_toggle` runs when a host attaches (0x01AAA788 is not the disk flag).

## Snapshot save hook (2026-10-15, branch feat-core-maiko2)
For sound naming (`docs/maiko-rebuild.md`): a feature holds back R246's hold-to-save of a sound and finishes it later
under its own name. `kennel/kn_save.c`; API in `op1_feature.h`: `OP1_EV_SAVE_HOLD`, `op1_snapshot_defer()`,
`op1_snapshot_save(kind, slot, name)`, `op1_snapshot_name_exists(kind, name)`.

R246 (global controller `FUN_019AD090`, called every main loop pass at 0x019F0A3C): while exactly one sound key is
held (one byte per key at 0x01AACDBC..C3), help (0xFF9077F4) and Shift (0x01DD7F78) are up and the core is not stopped
(0xFF801040 != 1), a countdown (0x01AACDC8) runs from 400 per pass with a running flag (0x01AACDC4). At 320 it checks
16 MB free on /yaffs2 and the bank's save gate (else it gives up: flags cleared); below 320 it draws the progress;
when it goes below 0 it saves the slot of the bank 0x01DE4C40 (0 synth, 1 drum) as
`/yaffs2/user/audio/preset_<synth|drum>/snapshot/<name>.raw` with `<name>` = the date stamp
`%i%02i%02i_%02i%02i` (snprintf 0x01A9CE04 at 0x019AD220 into a 16-byte buffer, at 0x019AD5A6 into 256 bytes),
`<name>_1`, `_2`... while the file exists (yaffs_access 0x01A9A6B0), then clears the held bytes and the running flag.
Releasing the key early clears the running flag and hides the progress (FUN_01A3AA58).

Core:
- `kn_save_service` wraps the pass. In the pass where stock would save (one held, running, countdown 0, help and
  Shift up, core running) every feature gets `OP1_EV_SAVE_HOLD` (kind << 8 | slot). A feature that calls
  `op1_snapshot_defer()` there holds the save back: the core clears the held bytes and stock takes its "released"
  branch (progress hidden), as after its own save. The bank's gate has already passed by then.
- `op1_snapshot_save(kind, slot, name)` (any thread) finishes a held-back save: on a later main loop pass with help
  and Shift up the core sets the bank to `kind` for that one call (a mode key that ends the naming may have changed
  it), the slot's held byte, the countdown at its last step, arms the name and calls the stock pass; R246 saves as it
  would have (file, JSON name, its own `_1`), and the core puts the bank and the other held bytes back. The forged
  bank lasts that one call (file writes, a few hundred ms); KeyHandler code reading the bank meanwhile sees `kind`.
  Name 0 or "" = R246's date stamp. Refused (-1): no held-back save for that kind / slot, another save waiting, a
  name over 15 characters (`OP1_SNAPSHOT_NAME_MAX`, R246's synth stamp buffer) or with a character outside
  `[A-Za-z0-9 ._,-]`. A newer hold-back replaces an unfinished one.
- The name: the two stamp CALLs go to `_kn_stamp_stub` (hook.S): with no name armed it jumps to snprintf with the
  arguments untouched; armed, `kn_snap_name(dst, size)` writes the name. Path, `_N` loop and the JSON name all read
  that buffer, so R246's own uniqueness rule applies (a feature's `naming_unique` is not needed, but harmless).
- `op1_snapshot_name_exists(kind, name)`: yaffs_access on the snapshot path (main loop; a name with `/` is never
  found).

For the naming feature: open the grid in `OP1_EV_SAVE_HOLD` (and defer there), not on `OP1_EV_KEY_HOLD`: the stock
countdown (400 passes of 1..8 ms) can end before or after 600 ms, and without a deferral stock saves under its stamp.
`OP1_EV_KEY_HOLD` fires again for the key that confirms the name (the core's hold timer sees the press the entry
takes): ignore it while the entry is open.

Checks: `harness/save_test.c` on the fake core (a stand-in of the stock pass's branches: no deferral = stamp, held
back = no file and the progress hidden, named / `_1` / drum / empty name / wait while Shift is held / a second key
held during the forged pass stays flagged). Emulator (OP1-Emulator `run/kennel-maiko2/`, probe `kntest2/`): four
holds held back and finished from T4: `preset_synth/snapshot/abc.raw`, `abc_1.raw`, `preset_drum/snapshot/drm.raw` and
a date-stamp name for "", nothing else saved; `op1_snapshot_name_exists(0, "abc")` 1 after the first save, "zzz" 0.

## Core services for the Maiko rebuild (2026-10-15, branch feat-core-maiko)
Three services the rebuilt naming, FILE and undo features (`docs/maiko-rebuild.md`) build on.
`op1_feature_t` takes `com` from `reserved[0]` (a feature built against the older header has 0 there).
Host tests: `harness/text_entry_test.c`, `com_view_test.c`, `tape_edit_test.c` (and `tape_hooks_test.c` counts the
erase events). Emulator: OP1-Emulator `run/kennel-maiko-core/` (probe feature `kntest/`, `check.py`).

**Text entry** (`kennel/kn_text.c`, `op1_text_entry(const op1_text_entry_t *)`): a modal screen drawn after the
overlays on every screen (black, the title, the text with a cursor, a 4-row grid of the character set, the selected
character boxed). While it is open `kn_features_input` gives it every key and encoder event before any feature.
Controls (ours, the naming spec's grid): blue turns one character, green one row (both wrap); blue or white push adds
the character, left deletes the last one, red push finishes with ok 1; a mode key (help, tempo, synth, drum, tape,
mixer, sequencer, mic, COM) finishes with ok 0 and then acts as usual; every other press is taken. The opener's
`key(code, pressed, shift)` sees each key first and may take it (a naming feature's "same sound key again saves":
call `op1_text_entry_close(1)` there). Releases of keys that were already down when it opened (the sound key it was
opened from, Shift) go to R246, so their held flags clear; a release whose press the entry took is taken too, also
after it closed. `done(text, ok)` runs once on the main loop (`kn_core_service`), trailing spaces and dots trimmed.
Characters: the default set is `a`..`z`, `0`..`9`; a feature's own set may use `[A-Za-z0-9 ._,-]` (what
`op1_setting_set_str` accepts, minus `:`, which FAT names refuse). R246's own snapshot names are
`%i%02i%02i_%02i%02i` (`_%d` added for a taken name, strings 0x018DDF94 / 0x018DDC00), so digits and `_` cover them.
Shown uppercase (stroke font; J, Q, W, `_` and `,` added). Up to `OP1_TEXT_MAX` (24) characters. Known gap: with
the sample editor open the encoders go to the editor first (`knob_event_hook` order).

**COM view** (`op1_feature_t.com`, claim `view:com`, `kennel/kn_pages.c`). R246: COM is key 0x2C; plain COM is the
album (mode 6, screen 47), Shift+COM is COM (mode 11, screen 0x26, controller 0x01AAA7AC: key down 0x01963DBC, knob
0x01962D30; its tabs are T1..T4, page variable 0x01AAA784; `docs/firmware/ui.md` in OP1-Emulator). R246's COM has
no fifth tab and blue does not page, so (ours) in COM Shift+COM again toggles the view against the stock COM screen
(the view's object replaces slot 0x26, as the clock pages do with 0x2A); COM always opens on the stock screen. While
the view is shown: the encoder pushes go to its `push`, every encoder turn to its `turn`, mode keys and T1..T4 first
bring the stock COM back and then act as usual, Shift goes on, every other press is taken (with its release), so
R246's COM controller never runs while its slot holds the view. Leaving COM any other way restores the slot at the
next key or turn. One view: the first feature in priority order with `com` (claims resolve conflicts first). Plain
COM (album) has no slot: the FILE spec needs only Shift+COM.

**Tape edit events** (`OP1_EV_TAPE_EDIT`, `op1_feature_tape.h`, `kennel/kn_tape.c`). Every feature's `event`
gets each edit twice, before it changes audio or clip rows and after it is complete, synchronously on the thread
that makes it; arg = op | track << 8 | before << 16 (`OP1_TAPE_EDIT_OP/_TRACK/_BEFORE`), details (track, range
[start, stop) in samples, the lifted clip id, the slide flag) from `op1_tape_edit_now(arg)` (one record per
thread). R246's edits:

| Op | R246 | Thread | Site (core function) | Range |
|---|---|---|---|---|
| `LIFT` | lift key: clipboard command 2 | main loop | CALL lift 0x01A5485C at 0x0191B89C (`kn_clip_lift`, args channel, start, stop) | the clip, clip id from the queue entry |
| `LIFT_ALL` | Shift+lift (loop range): command 3 | main loop | CALL lift all 0x01A54984 at 0x0191B974 (`kn_clip_lift_all`) | the loop range, track 0xF |
| `DROP` | drop key, the end of a clip slide (flag): command 0 | main loop | CALL tape_clips_add 0x0195CCEC at 0x0191B65A (`kn_clip_drop_add`): before the clip row is added | position .. + clipboard length |
| `DROP_ALL` | Shift+drop: command 1 | main loop | first CALL tape_clips_add at 0x0191B730 (`kn_clip_dropall_add`) | as DROP, track 0xF |
| `ERASE` | erase tape: command 4 | main loop | `fast_tape_erase` (0x0191B9F0, as before) | whole tape |
| `SPLIT` | scissors; the splits at the loop points Shift+lift makes before it queues LIFT_ALL | KeyHandler | CALL tape_clips_split 0x0195CF9C at 0x01A56F24, 0x01A57690, 0x01A5769C (`kn_tape_split`) | the position |
| `JOIN` | Shift+scissors | KeyHandler | CALL tape_clips_join 0x0195D7E8 at 0x01A577C6 (`kn_tape_join`) | the position |
| `REC` | before: the tape goes into recording; after: R246 has added the finished recording's clip row | the thread that calls set_mode (KeyHandler for the keys) | before: CALL tape_record_extent_reset 0x01A54C1C at 0x01A584D0, set_mode's way into recording, before it sets the run state the audio thread records on (`kn_rec_start`); after: CALL tape_clips_add at 0x01A5828A, 0x01A5830C, 0x01A5838E, 0x01A58432, 0x01A5857E (`kn_rec_clip_add`) | before: the track and position (start = stop); after: the clip R246 adds (the recorded extent with its minimum length 0xDC8 and the tape end applied). A recording that wrote nothing gets no clip and no after event |

The clipboard commands come from a 16-entry queue (0x01AA7130, consume / produce 0x01AA7330 / 0x01AA7334) that
`audio_clipboard_service` (0x0191B560) drains on the main loop. Each command's before event is at its first change
(the clip row a drop adds comes before its audio, so the hook is on that add; a lift's audio comes before its clip
row is removed); its after event comes at the next command's before or when the service returns (hook at the
service's call, 0x019F0A2A, whose result the main loop still gets). REC's range is the clip, not R246's recorded
extent (0xFF8029E4 / E8): set_mode resets the extent right after the add, so a later read finds INT_MAX / INT_MIN
(the first version polled it from the main loop and mostly got that). REC's before comes before the first recorded
sample (the audio thread starts on the run state set_mode writes after the hooked call); undo has to keep what the
recording overwrites itself (the range is only known at the end). All fifteen sites are plain CALLs; their original
bytes are checked by `make_firmware.py`. Reverse is a playback direction in R246, not an edit.

**Undo area** (`op1_undo_area(owner, &size)`): 0x02800000..0x02980000 (1.5 MiB). R246's last BSS block ends at
0x027FFB03 (OP1-Emulator `docs/firmware/clocks-memory.md`; the tape clipboard ends at 0x027D1FE0), the plugin arena
(`kn_alloc`) starts at 0x02980000 and nothing else in kennel addresses the block. One owner: the first caller (its
`owner` pointer); other callers get 0. Emulator check: a probe filled it after boot and found it unchanged after a
recording, lift, drop, split and join.

## Chord mode on the API (2026-10-15)
Source `synth_sdk/chord/chord.c`, plugin folder `synth_sdk/plugins/chord/` (kind "feature", `FEATURE_chord`,
priority 200). Shipped as `content/chord.knl` (`"loadable"`; compiled in when the flag is off) (30 KB, imports
`op1_note_on`, `op1_note_off`, `op1_music`). The core finds a compiled-in chord through a weak `FEATURE_chord`.
Checks: `harness/chord_test.c` passes; OP1-Emulator `run/kennel-chord/chord_check.py` (voicectl_synth_note_on hits for
one key, chord page): compiled in and from the file both give a 3-note C major chord, the page drawn, and one note
after the orange push (the test NAND had chord mode saved on, so the counts read off 3 / on 1). With the file
corrupted: single notes, no feature page on T4, normal boot.

## Clock pages on the API (2026-10-15, branch feat-pages)
`kennel/kn_pages.c` owns clock mode's T1..T4 and Shift+Help: `kn_pages_finish` (called from `kn_features_finish`)
picks one page per key and one view; `dispatcher.c` calls `kn_pages_ctor` / `_load` (one screen object per page in
slot 0x2A) and `kn_pages_key` / `_knob`. op1r's four built-in pages are features now, each a plugin folder
(`plugins/<name>/`, kind "feature", a wrapper that includes `screens/<name>.c`); sysmon, USB out and Oblique ship as
files, settings stays compiled in (`"builtin"`: it hosts the switches):

| Feature | Slot | Controls | Core side (stays compiled in, exported in `kn_exports.c`) |
|---|---|---|---|
| `sysmon` | T1 | none | `screens/sysmon_core.c`: `sm_audio_cb` (IMM_PATCHES 0x0191AB52) and `sm_idle_run` (kTE_Idle vtable) and their counters; pointers to the optional profile counters (`ps_prof`, `dp_prof`, `op1_db_last_err`, weak in the core) |
| `usbout` | T2 | blue turn | `usb_tracks_live`, six-channel descriptor and iso hooks (`screens/usbtrack.c`); the `usbtracks` row: `usbout_load` at USB start, `usbout_save` (`screens/settings_store.c`) |
| `settings` | T3 | blue turn | `ci_beats` (`tape/countin.c`); the `countin` row: `countin_load` at screen load, `countin_save` |
| `oblique` | clock view | none (`push(-1)`: new card) | none; the cards (`build/oblique_data.c`) are generated at build time and go into the file (plugin.json `"generated"`) |

What the settings and USB out pages set is loaded by the core at boot, so with a page file missing or broken the saved
count-in and USB-out values still apply (only the page to change them is gone). DB rows unchanged. A page with a
`turn` now takes all four turns while shown: the USB out page used to pass green, white and red to the stock clock.
Host tests: `harness/sysmon_test.c`, `usbout_test.c`, `settings_test.c`, `oblique_test.c` (each also checks its
`FEATURE_<name>`; `settings_test` runs on the fake core in `make tier1` and checks the switch rows too), render scripts `render_monitor.py`, `render_usbout.py`, `render_oblique.py`. Emulator (OP1-Emulator
`run/kennel-pages/pages_check.py`): compiled in and with all four as files, Shift+Help (card, clock, new card),
T1, T2 (+ tracks), T3 (count-in 4 -> 16) and T4 (chord) each show their page; with settings.knl corrupted the boot
goes on and T3 has no page (the key goes to stock).
## LFO types (API v2, 2026-10-15)
`synth_sdk/op1_feature_lfo.h`: a feature sets `op1_feature_t.lfo` to an `op1_lfo_type`:

```c
typedef struct op1_lfo_type {
    const char *name;            /* lfo_types row name, saved in sounds */
    uint8_t stock_class;         /* OP1_LFO_CLASS_MIDI (4), the only class in v1 */
    uint8_t marker;              /* high byte of word 7 in the type's words, 0x80..0xFF */
    int (*match)(const int16_t *w);
    int (*apply_synth / apply_drum / apply_fx)(void *self, const int16_t *w, int pass);
    void (*trig_synth / trig_drum / trig_fx)(void *self, const int16_t *w);
    const char *svg; const op1_screen_t *screen;
    void (*press)(int pos, int knob);
    void (*turn)(int16_t *w, int pos, int knob, int delta, int shift);
    void (*midi_cc)(int cc, int value); void (*midi_start)(void);
} op1_lfo_type;
```

- **Runs in a stock class.** The type's `lfo_types` row resolves to the MIDI LFO class: `lfo_name_eq` lets "midi"
  match the registered type's name. Its 8 words are saved with the sound under that class, so the words say whose
  they are: word 7's high byte is `marker`, which no stock MIDI LFO word has.
- **Core sites** (`kennel/kn_lfo.c`, `dispatcher.c`, `hook.S`): the patch range check accepts a word set whose
  word 7 carries a known marker; `read_lfo_param_safe` hands out a neutral vector for claimed words (they would trip
  the range assert); the LfoMidi apply stubs and note-on triggers call the type for words its `match` claims and
  the stock code for everything else; ScreenId::for_lfo shows the type's screen object (built at screen
  construction on `svg`) while the page's words match; encoder pushes and turns on that page go to `press` / `turn`,
  and the core writes changed words into the sound (`patch::set_lfo_params`). MIDI CC (after the stock CC table)
  and MIDI START reach `midi_cc` / `midi_start`.
- **One type** in v1: the first registered feature with a usable type (MIDI class, marker >= 0x80, `match` set).
  The screen object is the core's (slot 0x1C).
- **Reserved, without the feature.** quad's name and words (marker 0xA5, and op1r <= 15 quad words) are known to
  the core even when no quad is registered (file missing or broken): "quad" still resolves to the MIDI class, the
  range check passes, `read_lfo_param` is never fed quad words and the LfoMidi apply does nothing for them. A sound
  saved with quad loads as stock and its LFO is silent. A type that is released later gets its name and marker
  added there the same way.
- **The build** adds the `lfo_types` row and the screen SVG (`make_firmware.patch_db`, `display/quadlfo.svg`)
  whether the type is compiled in or shipped as a file: loader v1 cannot add DB rows or serve SVGs.

Cost: per LfoMidi apply call (once per active voice and block) one marker compare in the stub and one in the core
before the type's own code; nothing when no LFO is a feature type.

## quad LFO on the API (2026-10-15)
Source `synth_sdk/lfo/quadlfo.c` (unchanged), plugin folder `synth_sdk/plugins/quad/` (kind "feature",
`FEATURE_quad`, `quad_feature.c` fills the `op1_lfo_type` from quadlfo.c's functions). Shipped as
`content/quad.knl` (`"loadable"`) (16 KB, imports nothing but libgcc). The core finds a compiled-in
quad through a weak `FEATURE_quad`. Host tests: `harness/kn_lfo_test.c` (core routing, reserved words, no type),
`harness/quadlfo_test.c` and `render_quadlfo.py` (quad itself).
Emulator (OP1-Emulator `run/kennel-lfo/lfo_check.py`, log 2026-10-15): compiled in and from the file the Shift+T4
browser picks quad, its page draws, and with LFO 1's amount raised a held C4 drives about 3,700 knob_range_synth
calls (none at amount 0). With the file corrupted, boot goes on, a sound saved with quad loads, T4 shows the stock
MIDI LFO page and nothing is modulated.
## Tape on the API (2026-10-15)
`synth_sdk/op1_feature_tape.h`, core side `synth_sdk/kennel/kn_tape.c`. A feature points `op1_feature_t.tape` at:

```c
struct op1_tape_hooks {
    void (*block)(void);                          /* audio thread, every block, before the metronome render */
    void (*metro)(void (*render)(void));          /* wraps the stock metronome render; one owner */
    void (*service)(void);                        /* main loop, after tape_c::service(0) */
    int (*key)(int code, int pressed, int tape_screen);   /* key thread, before the stock key; 1 = consumed */
    int (*knob)(int knob, int delta, int tape_screen);    /* encoder turn; 1 = consumed */
    void (*draw)(void);                           /* tape screen, after the stock draw */
    void (*erase)(void);                          /* replaces the stock whole-file erase; one owner */
    void (*note_down)(const op1_note *n, int param);  /* note input observers: VoiceCtl key_down / key_up entries */
    void (*note_up)(const op1_note *n);
    void (*pre_draw)(void *scr);                  /* tape screen, after the stock recording-state update */
    void *(*lookup)(int32_t pos, int32_t *direction, void *(*stock)(int32_t, int32_t *));  /* chunk lookup; one owner */
};
void op1_key_down(const op1_note *n, int param);  /* play a note as the keyboard does (observers, pipeline, synth) */
void op1_key_up(const op1_note *n);
static inline int32_t op1_tape_zoom_q10(void);    /* tape zoom px/s, Q10 (header inline, no feature needed) */
```

- The core keeps the op1r names of the patch targets (`ci_metro_render`, `ci_service`, `tm_screen_draw`,
  `fast_tape_erase`), so `hook.S`, `link.ld` and `make_firmware.py`'s tables did not change. Each target runs the
  hooks in priority order and then (or instead, for `metro` / `erase`) the stock code. No tape feature: stock R246
  at every site (`harness/tape_hooks_test.c`).
- Shared data is core data (`tm_pos` / `tm_n`, `pu_mode`, `ci_beats`, exported for plugin files): punch reads the
  markers, markers draw the punch mode, the settings page (still `screens/settings.c`) writes the count-in length.
  Each feature works without the others; punch without markers never punches.
- Features: markers 400 (red press / Shift + red press / Shift + red turn on the tape screen, the ticks), punch 410
  (tape held + REC, PLAY / STOP while punching, marker crossings on the audio thread), count-in 420 (REC held +
  metronome, STOP; owns `metro`), fast erase 430 (owns `erase`). Punch runs before count-in in the key chain, as
  the old dispatcher order did (a REC press punch consumes never reaches count-in's REC-held state).
- **Outside contract**: `fast_tape_erase` is a `void(void)` function in the core image (0x01E13D78 in the test
  builds, all variants). OP1-Emulator's Maiko #249 undo bundle wraps the site 0x0191B9F0 and JUMP.Ls to whatever
  the site called (`tools/firmware/maiko249.py` ERASE_CHAIN, it must lie in 0x01E00000..0x01E40000). With the erase
  feature missing or broken it runs the stock erase.
- Saved data is unchanged: markers stay in `op1rmarkers`, the count-in length in `op1rsettings`.

### Hooks for op1r-src PRs #6 (MIDI track) and #4 (polymetric loops) (2026-10-15)
Designed so both PRs (ultralazr, open on pcppcp/op1r-src) can be ported as tape features; not ported yet. Core side
built and host-tested (`harness/tape_hooks_test.c`); the stubs with no owner run the stock entry instruction.

| PR need | Hook | R246 site (core) |
|---|---|---|
| #6 records every note, synth and drum, before chord etc. | `note_down` / `note_up` observers (look, don't change) | VoiceCtl key_down entry 0x01A85750 (LINK 0x10) / key_up 0x01A85840 (LINK 0x20) -> `_kn_vcdown_stub` / `_kn_vcup_stub` (hook.S) -> `kn_note_input_down/_up`. Stock path while no observer: `kn_note_obs == 0` |
| #6 plays its notes back through chord and the current instrument | export `op1_key_down(n, param)` / `op1_key_up(n)` (calls the hooked entries) | the observers see these notes too: the feature guards its own (the PR's `mt_in_play`) |
| #6 red tape theme while the MIDI track records | `pre_draw(scr)` (set `scr + 0x93 = 1`, clear `+0x98` / `+0x9C`, as `mt_tape_pre`) | CALL 0x01A5C728 at 0x01A5CFA8 -> `kn_tape_pre` (R0 is dead after the call; P3 = scr survives) |
| #6 needs the zoom (`tm_zoom_q10` was static in markers) | `op1_tape_zoom_q10()` inline in `op1_feature_tape.h` (reads R246's float at 0x018C183C) | none |
| #6 releases notes on stop, locate, loop wrap | **features detect transport events in `block`** (no core event) | `ci_metro_render` |
| #6 block / service / key / draw | as is | `mt_block` -> `block`, `mt_service` -> `service`, `mt_key` -> `key` (shift: read 0x01DD7F78), `mt_draw` -> `draw` |
| #4 replaces tape_c's chunk lookup | `lookup(pos, &direction, stock)`, one owner | entry 0x01A54D5C (LINK 0) -> `_kn_lookup_stub`: owner 0 = `LINK 0; jump 0x01A54D60` (stock); else ASTAT, RETS, LC0/LT0/LB0/LC1/LT1/LB1 saved around `kn_tape_lookup`. `stock` = `_kn_lookup_orig` (the PR's `tl_lookup_orig`) |
| #4 blue press, indicator, service | `key` (code 0x3B, tape screen), `draw`, `service` | as is |

Transport events: decided per feature in `block`. Each user needs its own thresholds (punch's 16x jump limit and
loop-wrap crossing, the MIDI track's spin-up window, tapeloop's 2048 / 4096 wrap / locate limits), and a core
detector would run every block for nobody when no feature listens. Revisit if a third feature repeats the logic.

Note input is placed on the tape hook point because the MIDI track is its only user; a general input point
(arpeggiator, looper) would need a slot of its own in `op1_feature_t` (`reserved[0]`), which this branch does not
take.

Where the PRs' edits land after the move: their `countin.c` additions (`mt_block` / `tl_service` /
`mt_service` calls) become `block` / `service` hooks in their own plugin folders (`plugins/miditrack`,
`plugins/tapeloop`); their `markers.c` additions (`tm_screen_draw` calling `mt_draw` / `tl_draw`, `tm_zoom_q10`
made global) become `draw` hooks and `op1_tape_zoom_q10()`; their `dispatcher.c` key lines become `key` hooks;
their hook.S / link.ld / make_firmware.py entries are already in the core (above). Count-in, punch and markers
need no change for either PR. Key order matters: #6's `mt_key` ran before the markers' red press and #4's blue
press before it too: give both a priority below markers (400), e.g. 300 / 350.

## Scale mode on the API (2026-10-15)
A clean rebuild of Maiko #249's scale utility (no #249 code; spec `docs/maiko-rebuild.md`): `synth_sdk/scale/scale.c`,
plugin folder `synth_sdk/plugins/scale/` (`FEATURE_scale`, priority 100, `"loadable"`: `content/scale.knl`, 7.7 KB).
Each white key plays the scale note with its letter (C lydian: F plays F#), black keys play only if in the scale;
nine 7-note scales and OFF. Uses: note pipeline, settings service (`scale.root`, `scale.type`, read at
`OP1_EV_BOOT_DONE`), `op1_music_publish` when the user changes the key, input filter (white / orange turns with
Shift on synth T2, claim `key:synth:shift+t2`), `op1_toast` for each change, and an overlay on that view (screen 40, `playmode.svg`, emulator-checked) drawn as #249
did: stock keeps its PLAYMODE / PORTAMENTO text on top (y up to 70; blue and green still turn them), and below it
scale draws (owner's pick P1: a framed keyboard 8 px under the stock text, narrower black keys, larger dots) a two-octave keyboard from F (green dots on keys that play, root keys lavender,
a red sharp / flat over a white key that plays its letter's sharp / flat, silent black keys dark) and the KEY and
SCALE lanes under the white and red encoders. A full-screen version that covered the stock text was tried and
dropped (owner): it had to redraw play mode and portamento and the cover showed seams in the emulator. Mockups:
OP1-Emulator `docs/design/scale-overlay/concepts/`. Differences from #249: it sits at VoiceCtl, so MIDI in and
the sequencers are mapped too, and Shift + key sequencer shortcuts read the key before VoiceCtl, so they should be
untouched (workshop issue #1; emulator: Shift+C#5 reaches the sequencer's run with scale on). With chord on as well, scale runs first, so out-of-scale black keys never reach
chord's LEAD / PASS / BORR chords (by design: priority 100 before 200).
Open, for the emulator: the KEY lane's sharp / flat placed by an estimate of the font width (`LANE_CW`); one knob
tick (2 quadrature edges, 1024) moves one step, as stock and chord: an emulator `turn ... 16` is 8 steps. Emulator (OP1-Emulator `run/kennel-scale/result.json`, built from 28e5dc2, the same mapping code, setting seeded, chord off): C major
C4 -> 60, C#4 and D#4 silent; C lydian F4 -> 66; kn_log "scale.knl: loaded"; a corrupted scale.knl logs "CRC mismatch"
and C#4 plays 61. Screen 40 check of the view: `run/kennel-scale40/`. Check:
`harness/scale_test.c` passes (map, stage, settings, controls, overlay strokes inside the screen).
## Drum types (`op1_feature_drum.h`, 2026-10-15)
A feature that runs a kind of sampled drum kit points `op1_feature_t.drum` at a `struct op1_drum_type`:
`api` (`OP1_DRUM_API` 1), `id` (the drum_types row, `OP1_DRUM_TYPE_ID` 2), `name` ("drum+": the saved name in kits and the drum_types row; the feature's id is `drumplus`), `load(slot, obj)`,
voice `render` / `note_on` / `note_off`, and the T1 / T2 pages (`page_init`, `page_draw(page, slot, raster)`,
`page_turn(page, slot, knob, delta)` -> consumed, `page_press(page, slot, knob)`). The core (`kennel/kn_drum.c`)
keeps every R246 site and the names hook.S, `make_firmware.py` SLOTS and `dispatcher.c` call; each one calls the
registered type or does the stock thing. v1: one drum type, the first registered feature whose `drum` has the right
`api` and `id` 2.

- **Kits.** A drum patch with an `"op1r"` object (`OP1_DRUM_KEY`) belongs to the type. The core keeps the key across
  load, so the stock writer saves it again; on load it calls `load(slot, obj)` (or `load(slot, 0)` for a stock kit).
  In the emulator `kn_features_finish` runs before the first drum patch parse; `kn_drum_finish` still replays kits
  loaded before the type registered, as a safety net.
- **Load scope** (`kennel/kn_drum_scope.h`). R246's drum load site parses the 8 slot patches and the kit table
  (0x01DE20FC, factory and user kits, 24 entries in the emulator): every parse through it is a drum patch
  (`dp_is_loading_patch`), and only a slot object's own keep step reaches the type. Nested calls restore the outer
  scope, also after an error return. This is the scope op1r-src PR #5 (drum-aware fallback for unknown instrument
  names, draft) reads: it lives in the core, so it works with drum+ missing or loaded from a file; the PR's
  `instr_name_eq` change and `preset_compat.h` are not ported. Unlike the PR's slot-address test it also covers the
  kit table. With the PR, an unknown or synth-engine type name in a drum patch resolves to dbox, so
  `patch_type_hook` (it rewrites `knobs[4]` only for type 14) leaves it alone; without it such a name loads as iter
  and a compiled-in engine name even gets its selector. `harness/kn_drum_test.c` checks the scope and both lookups.
- **Type name rule.** A drum type's kits stay `"type": "drum"` with the type's data under `"op1r"`; a type never
  saves a type name of its own (under PR #5 an unknown name in a drum patch loads as dbox, which has no samples).
- **Browser.** Shift + T1 starts on the type's row for a slot of the type; picking the row on a sampled kit adds
  `"op1r": {"engine": name}` and saves the slot; any other row drops the key (stock job).
- **Voices.** The DrumSampler vtable slots call the type for every voice; the type calls `OP1_DRUM_STOCK_*` for the
  pads it leaves alone (drum+: pads without extras, every stock kit).
- **Pages.** While the current drum slot is of the type, the core swaps its own screen objects into slots 0x10 / 0x17,
  draws the empty screen and calls `page_draw`; encoder turns and presses on those pages go to the type.
- **No type registered** (drum+ not built, its file missing or broken): a drum+ kit loads as the stock sampled kit
  it also is (its type name is the stock "drum", so PR #5's dbox fallback never applies to it) (same samples, regions and pad words; the extras are not played), shows the stock pages and browser
  row, and keeps its `"op1r"` data when saved, so it is drum+ again once the type is back. The DRUM+ row is still in
  the browser (the drum_types row is built either way); picking it does nothing.
- The resource monitor's drum+ line (`dp_prof`, a weak pointer in `screens/sysmon_core.c`) is there only when drum+
  is compiled in.
- **Keys**: the features' input filter (`kn_features_input`) runs first; drum+ page presses and turns then go
  through the core (`dpu_key` / `dpu_knob` in `dispatcher.c`, after the T1 / T2 swap), not through drum+'s own
  `input`: the core knows which page object is shown, and the swap must run before the page check. A feature that
  takes encoder events in its `input` while a drum+ page is shown wins over drum+.

Drum+ on it: `synth_sdk/drumplus/` (sources, host tests unchanged), plugin folder `synth_sdk/plugins/drumplus/`
(kind "feature", `FEATURE_drumplus`, four wrapper files), shipped as
`content/drumplus.knl` (`"loadable"`) (22.5 KB, 20 KB bss, no imports).
Checks (2026-10-15): host `kn_drum_test` (scope and type lookup), `dp_plus_test`, `dp_ui_test`, `render_dpui.py` and the plugin-format tests pass
(`dp_voice_test` needs an emulator dump and skipped). OP1-Emulator `run/kennel-drum/` (`drum_check.py`, `chain.sh`):
compiled in, the browser's DRUM+ row turns the kit into drum+, T1 / T2 pages drawn, a T2 decay edit plays through
`dp_plus_note_on` and the fast path, and after a reboot the kit is drum+ with the edit. As a file (installed over
that NAND): loaded at 0x02980000, the same hits (`dpf_load` x8, note on x2, fast path x168). File corrupted: loader
log "CRC mismatch", the kit loads and plays as a stock kit with the stock pages, picking DRUM+ leaves it unchanged;
the file firmware installed over that NAND makes it drum+ again with the edit. With the core load scope (b785f15,
over the same NAND): parses 32 (8 slots + 24 kits), type `load` 8 (slots only), the kit plays as drum+.
After merging main (common hooks, loader 2, claims; feat-drum 16e0316, `run/kennel-drum/chain4.sh`): the same results
compiled in (make and play), as a file (loaded at 0x0298264C after scale.knl) and corrupted (DRUM+ pick keeps the
kit), and the file firmware brings the edited drum+ kit back; hit counts unchanged.

## Sequencer types (`op1_feature_seq.h`, `kennel/kn_seq.c`, 2026-10-15)
A feature sets `op1_feature_t.seq` to an `op1_seq_type_t`:

```c
typedef struct op1_seq_type {
    const char *name;            /* seq_types row and saved name, <= 15 chars; never changes meaning */
    const char *alias;           /* older name that also selects it (oracle: "shield"), or 0 */
    void *(*player)(void);       /* player object for create_player case 3 (ok_player vtable layout) */
    const char *svg;             /* screen file in content/display */
    const op1_screen_t *screen;  /* drawn in slot 0x2D while the type is the mode's sequencer */
    int  (*key)(int mode, int code, int pressed, int shift);   /* on its screen; 1 = consumed */
    void (*press)(int mode, int knob, int shift);             /* encoder push */
    void (*turn)(int mode, int knob, int delta, int shift);   /* encoder turn */
    int  (*shift_wants)(int key);                             /* Scale-mode Shift shortcuts */
    void (*midi_start)(void);
} op1_seq_type_t;
```

- **Name and type.** All kennel sequencers run as R246's type 3 (finger) plus an "active type" per mode (synth,
  drum). `eu_seq_from_name` (the three from_name CALLs) matches registered names and aliases first, then the six
  stock names (to the stock lookup). Any other name, such as a sequencer whose file is missing or broken, runs as
  finger and is remembered per mode, so `eu_seq_name` gives it back and the sound keeps it; the stock lookup
  (0x01A42344) would call its assert (0x01919AA8) on an unknown name. The hook symbol names keep op1r's (`eu_*`,
  `seq_player_get`) so `hook.S` and `link.ld` are unchanged.
- **Player.** `seq_player_get` (create_player case 3) returns the active type's `player()`, else finger's
  (0x019ED460). The type's player gets key_down / key_up / tick / reset / stop like a stock sequencer.
- **Screen and controls.** One screen object per type with a screen, built at screen construction and loaded with
  the stock screens; `kn_seq_sync_screen` swaps slot 0x2D between finger's and the active type's. While it is
  shown, left / right change the keyboard octave (as SeqManager does; the core), encoder pushes go to `press`, other
  keys to `key`, turns to `turn`. `kn_seq_key` / `kn_seq_turn` are one `dispatcher.c` line each, after the features'
  input filter, tape and clock pages (like `kn_tape_key` / `kn_pages_key`), so tape-held + REC keeps working on the dots
  screen; a sequencer type needs no `input` callback of its own. After each key event the core presses PLAY if a type asked for it
  (`op1_seq_press_play`, start with REC held) and re-syncs the screen.
- **Services.** `op1_seq_note_on(mode, note, key, vel)` / `op1_seq_note_off(id)` play through `op1_key_down` /
  `op1_key_up` (VoiceCtl key_down / key_up), so sequenced notes reach the note input observers and the note pipeline
  (scale, chord). The core also holds the firmware copy of
  `seq/seq_text.h` (stroke text, `sq_store_*` persistence) and exports it with the services.
- **Persistence.** Each type's own SQLite table through R246's background saver (euclidseq, dotsseq, oracleseq,
  pealseq), loaded on the first `player()` call. Unchanged from op1r.
- **DB rows.** `make_firmware.patch_db` writes the four `seq_types` rows and copies the four SVGs whether the
  sequencer is compiled in or a file, so a file can be added or removed without changing the database.
- **Shift shortcuts.** `seq_shift_wants(key)` stays a core symbol (OP1-Emulator's builder reads its address into
  base.json for the workshop's Scale-mode adapter) and asks the active type's `shift_wants`.

Fake core: `harness/seq_test.c` runs `kn_seq.c` (its `OP1_HOST` block) with three fake types and euclid's feature:
names, aliases, stock names, unknown names per mode, players, `seq_shift_wants`, key / encoder routing only on the
type's screen in slot 0x2D (left / right to the core's octave), `op1_seq_press_play`, MIDI START, the note services
and duplicate names. It found that `kn_seq_finish`'s duplicate check never matched (a second type with the same name
took a slot, a screen object and MIDI START; lookups still chose the first); fixed 2026-10-15.

Checks (2026-10-15, merged with kennel main dd2edbf): `make -C synth_sdk/harness check` passes (tier 2 loads and
relocates all four files); host tests `harness/euclid_test.c`, `dots_test.c`, `oracle_test.c`, `peal_test.c` pass (their
PNG renderers need libcairo). Emulator (OP1-Emulator `run/kennel-seq/check.py`, NAND from `run/kennel-hook/nand`): each
sequencer selected with Shift + SEQ, its screen drawn, and it plays (voicectl_synth_note_on hits: euclid 24, dots 18,
oracle 158, peal 72), the same compiled in and with all four as `*.knl` (kn_log "loaded" x 4). A NAND whose synth sequencer was saved as dots boots into dots with the file; with `dots.knl`
corrupted: "dots.knl: CRC mismatch", boot goes on, from_name("dots") at boot runs as finger (finger screen), notes
play, euclid / oracle / peal unchanged.

## Tape services: loop, track, playhead, transport, clipboard (2026-10-15, branch feat-tape-services)
For Maiko #250's tape edits rebuilt in undo (copy loop, paste at the end, merge drop, bounce). `kennel/kn_tapesvc.c`,
API in `op1_feature_tape.h`; no patch site, R246's own setters and variables (addresses in the file header):
- `op1_tape_loop_get(&on, &in, &out)` / `op1_tape_loop_set(on, in, out)`: as R246's loop keys (0x2D / 0x2E / 0x2F in
  the tape key handler 0x01A589A8): the setters tape_set_loop_in / _out (they drop the loop seams; out is stored
  clamped to 0xF23F90), on = effective = on && in != out, the tape controller marked dirty (the background saver
  writes the tape row), the tape screen redrawn (0x01B6039C). Any thread; works while playing.
- `op1_tape_track()` (0xFF802964), `op1_tape_pos_get()` (0xFF802974 >> 6), `op1_tape_pos_set(samples)`
  (tape_locate 0x01A55024; it clears loop effective, as every R246 locate does), `op1_tape_transport()`
  (`OP1_TAPE_STOPPED / _PLAYING / _RECORDING` from the tape state 0x018C17D4 and run state 0xFF802960;
  `OP1_EV_TRANSPORT` only reports changes).
- Clipboard (main loop): `op1_clipboard_info(&chmask, &len)` (content 0 empty, 1 tape lift, 4 / 5 synth / drum
  sample), `op1_clipboard_read(ch, at, len, dst)`, `op1_clipboard_write(chmask, len)` and `op1_clipboard_slot(ch)`.
  Write leaves R246's clipboard as its own lift would (one track: the four slot pointers at 0x02040000 zeroed and that
  track's pointing at 0x02040010, length below 0x3C8FE8; all four: slots 0x1E47F4 bytes apart, up to 0xF23F9 samples
  each; channel 0x01AA7100, length 0x01AA7104, content 0x01AA7108 = 1) without touching the tape; the feature fills
  the slots in the same pass (e.g. `op1_tape_read(t, in, len, op1_clipboard_slot(t))`) and R246's drop / drop-all
  then pastes it. Refused (-1) while R246's clipboard queue has commands. The buffer is shared with the sampler
  editors, as with R246's own lift.
Write also sets the enqueue side's copy that the drop key reads (0x01AA710C channel, -1 = drop-all; 0x01AA7110
length, 0 = nothing to drop; 0x01AA7114 = 1), as a queued lift does: without it drop ignores the content.
Checks: `harness/tapesvc_test.c` on the fake core. Emulator (OP1-Emulator `run/kennel-tapesvc/`, probe `kntsvc/`): while
playing at 15168, a loop set 1..2 s ahead (59268..103368) caught the playhead (68732 three seconds later); the loop
copied into the clipboard while playing (4 x 44100 samples, info kind 1 mask 0xF); stopped, R246's drop pasted it on
all four tracks (clip rows 1/0/0/0 -> 2/1/1/1, the pasted audio's peak equal to the source's).

## Four tapes (2026-10-15, branch feat-tapes)
Design and R246 facts: `docs/tapes.md`. Core: `kennel/kn_tapes.c`; API in `op1_feature_tape.h`:
`op1_tape_switch(tape)` (any thread: 0 = asked, else `OP1_TAPE_SW_SAME / _RECORDING / _DISK / _BUSY / _FULL / _BAD`),
`op1_tape_current()` (0..3, 0 from boot), `op1_tape_bpm10()`, `op1_flash_free()`; event `OP1_EV_TAPE_SWITCH` (arg =
old | new << 8 | before << 16; `OP1_HAS_TAPE_SWITCH` for code that must build without it). The switch runs in
`ci_service` (`kn_tapes_service`): STOP first when playing, the old tape's row and tempo saved, the BgFile worker
idle, the cache flushed, before event, tape.db swapped inside db2's box under its lock, cache dropped, FAT unmounted,
image closed, both path buffers set, the new image opened, bound, mounted and indexed by R246's own mount check,
clip pool reloaded, tape row and tempo applied, after event. A new tape (tapes 2..4) is a sparse image: R246's boot
sector, then our FAT16 metadata and AIFC headers (byte-identical to an installed R246 image apart from timestamps,
`harness/tapes_image_test.c` with `KENNEL_TAPE_REF`), the factory tape.db, marker "0", `ready`; about 130 KB written.
Feature `tapes` (`tapes/tapes.c`, `plugins/tapes/`, loadable): tape + T1..T4 (claims `key:tape:tape+t1..4`), the
toast "tape 2, 125 bpm", refusals, REC held back with "flash full" under 32 MB. Undo clears (or keeps per tape) its
history on the event (`op1_tape_current` names the tape). Tests: `tapes_test.c` (sequence, refusals, STOP, remake
on a raised marker), `tapes_image_test.c`, `tapes_feature_test.c` (fake core).
Emulator (OP1-Emulator `run/kennel-tapes/`, `tapes_check.py`, fresh install): a take on tape 1 track 1; tape + T2
made tape 2 on the first try (toast "tape 2, 125 bpm", no error), a take on its track 2; back to tape 1 (its clip
there, toast "tape 1, 125 bpm"), to tape 2 again; disk mode on tape 2: the USB disk's TRACK_1 silent, TRACK_2 not.
tape.db rows: tape 1 (0, 0..143072), tape 2 (1, 0..142944); tape 2's image takes 14.8 MB of flash (the take plus
what disk mode copies into it). Not checked there: REC's flash full, a tempo that differs between tapes.
R246 calling details found on the way (the decompiler shows fewer arguments): `f_mount` 0x01998E74 is (volume,
fs); sqlite open 0x019D73C8 takes the VFS name as a 4th, stack argument (0); `tape_clips_remove_channel` is
(pool, track). FatFs keeps one sector window per volume (fs + 0x2C sector, + 4 dirty): the switch writes a dirty one
to the old image and forgets its sector before mounting the new one.
## Sampler services and the sampler tools (2026-10-15, branch feat-sampler)
`synth_sdk/op1_feature_sampler.h`, core side `synth_sdk/kennel/kn_sampler.c` (exported for plugin files). No patch
site: TE's sampler screens are read, not hooked, and the tools draw with the common `overlay` hook and take keys with
`input`.

| Service | What |
|---|---|
| `op1_sampler_now(&s)` | 1 while TE's own sampler screen is shown: screen 6 with a sampler sound (engine 6) or 0x10 with a sampler kit (engine 8), and the slot's screen object is the stock one (vtable 0x01911424 / 0x0190FAF4: not the sample editor, not drum+ pages). Fills kind, slot, drum key (0xFF801044), the audio (after the 8 guard samples), capacity, `busy` (tape run 0xFF802960 == 1, or keyboard-to-sample's flags 0x01DD84F5 / F6) and `gen` (kind, slot, key, a hash of the buffer's overview, commits with audio) |
| `op1_sampler_marker` / `_set_marker` | markers in samples: synth knob words 0..3 (start, loop a, loop b, end; fractions of the 6 s buffer), drum keys' start / end in the live pad table (fractions x 2^31 of 12 s) |
| `op1_sampler_commit(audio)` | markers into the patch (`set_knobs` 0x01A00D14 / pad table to patch 0x019FFC50); with audio also the overview (as SampleBuffer::load_file) and the background saver's `synth_<slot>.raw` / `drum_<slot>.raw` (0x019412AC / 0x01941286) |
| `op1_sampler_base_freq` / `_set_base_freq` | synth: the patch's root `"base_freq"` (a double: the key frequency in Hz that plays the sample at its own speed; patch_load 0x01A010F8 reads it) and the live read step (`sampler_set_base_freq` 0x01A51A08 on the slot's entry in 0x01DF6F78, as patch_load does). Written with Value(double) 0x019BD854 (low word R1, high word R2, as R246's callers) |
| `op1_sampler_job(step, ctx)` | `step` once per main loop pass until it returns 0; cycles measured, "sampler: job N cycles, max M" in kn_log |

Tools (`synth_sdk/sampletools/`, plugin folder `plugins/sampletools/`, `FEATURE_sampletools`, loadable: `content/sampletools.knl`):
our own code after the behaviour of Maiko's #250 guide (fit, zoom, pitch pages); no Maiko code (no licence).
- **Zoom**: white press 2x .. 32x around the marker turned last (turns are watched, not taken), Shift + white back
  towards TE's view. The overlay covers TE's waveform area and draws the view (positive peak per 2 px column, cached
  per view, at most ~64 reads a column), the markers in TE's colours, arrows for markers off the view, a bracket
  under the overview strip and the level. Resets when `gen` changes. Synth: blue held + turned moves the start 8
  samples per quarter detent.
- **Pitch** (synth): an integer YIN (`st_pitch.c`, ~240k inner operations per analysis, 9 KB work) runs as a job when
  the start, end or sound changes; the overlay shows the note (middle C = c3, TE's numbering) and a tuner (-50..+50
  cents, green within 3). Shift + green sets base_freq to the note's 12-TET frequency (`st_notes.h`: double and float
  bit patterns), so that key plays the sample at its own speed; a green line under the name says base_freq is that
  note. Shift + green again puts the old value back (until the sound changes).
- **Fit**: orange opens the panel (bars 1 / 2 / 4 / 8 on blue, keep pitch / tape on green, tempo shown); lengths that
  don't fit the buffer say "full" and are skipped. Orange fits the used part (synth start..end; drum: earliest start
  .. latest end of the 24 keys) to bars x 4 beats at the current beat length, in place in the buffer
  (`st_fit.c`: the input moves to the buffer's end, the output is written from 0; keep pitch = WSOLA, tape = linear
  resampling; 128 output samples or 8192 moved / zeroed samples per main loop pass). The overview is rebuilt after
  the commit in 32k-sample chunks, then the sample file is saved. Markers follow (`st_fit_map`); then commit with audio. Refused
  while sampling or recording, under 0.05 s, or when nothing fits. Keys and knobs are taken while it runs.
- **Look** (owner, 2026-10-16: like Maiko's #250, drawn ourselves; #250 doesn't boot in our emulator, so the target is
  the guide pages' descriptions in kennel's style): the zoom view keeps TE's waveform style (positive-peak line in the
  instrument's colour, TE's marker colours as round dots), off-view markers as arrows at the edges, a white bracket
  under the overview strip, a magnifier and "4x" at the bottom; fine start rings the start (our view also at TE's
  zoom while blue is held). Pitch: the note (lowercase stock font) and a -50..+50 cent line with the needle green
  within 3 cents; the name turns green once the sound is tuned to it. Fit panel: "bars 2" and "125 bpm" on top, four
  cells (1 / 2 / 4 / 8 under them) filled blue up to the choice and filling while it fits, "full" over the first cell
  that doesn't fit, "keep pitch" / "tape" with the chosen one lit and the other dimmed, "fit" in orange; dots in the
  knob colours mark blue (bars), green (mode) and orange (fit). Goldens: `sampler_zoom4_pitch`,
  `sampler_fine_start`, `sampler_tuned`, `sampler_fit_panel`.
- Claims: `key:synth:white`, `key:synth:shift+white`, `key:synth:blue`, `key:synth:shift+green`, `key:synth:orange`,
  `key:drum:white`, `key:drum:shift+white`, `key:drum:orange`.
- Memory: one `op1_alloc` at boot (`st_state`, ~12 KB); the plugin's own `.bss` is the text objects only.
- Tests: `harness/sampletools_test.c` (fake core + `kn_sampler.c`'s host backend: zoom, fine start, pitch, retune and
  back, fit synth and drum, refusals, keys off the screens), `st_pitch_test.c`, `st_fit_test.c`.
- Emulator (OP1-Emulator `run/kennel-sampler/`, `sampler_check.py`, 2026-10-16, firmware from 05af989 with
  sampletools.knl): on a synth sampler sound (ACIDRONE) zoom 2x / 4x with edge arrows, following the loop marker,
  Shift + white back, fine start; pitch "c1" with the tuner (3.65M cycles per analysis, max 164k per main loop pass);
  Shift + green "tuned to c1", again "tuning put back"; fit to 2 bars at 125 BPM, keep pitch (40.9M cycles, max 262k
  per pass over 1338 passes; before the chunked overview one pass took 2.5M). Drum sampler kit (a factory kit picked in
  the browser): green turns the start, white the end (as mapped), zoom 2x / 4x, fit to 2 bars (the kit's audio now
  fills the first third of the 12 s buffer, keys moved with it). Open: after the keep-pitch fit the drone read d2
  instead of c1 (an ambiguous low drone; not checked further); kn_log (1 KB) was full before the drum fit's cycle line.

## Bad block fix and flash check (2026-10-16, branch feat-badblock)
**The bug (R246).** The tape cache writes a modified 64 KiB chunk with yaffs_write straight from the cache node
(io_step 0x01A54710, the CALL at 0x01A54842, kennel's `kn_tape_write`). YAFFS2's yaffs_write_new_chunk
(FUN_01A91556) programs the page, reads it back and compares it with the caller's buffer (memcmp at 0x01A9173E). On
a mismatch it counts a retry and marks the block for retiring (0x01A91858); the block is dead after the next garbage
collection. While recording, the node being written can still be filled with new samples, so the compare fails on a
good page and a good block is retired for good.
**The fix.** `kn_tape_write` copies the chunk into a 64 KiB buffer in the arena (word copy, no libc) and passes the
copy to yaffs_write and to `OP1_EV_TAPE_WRITE`. YAFFS compares against bytes nobody changes, so only a real program
failure still fails the compare and retires the block. Cost: one 64 KiB copy per chunk write on the main loop. If
the arena is full or the buffer odd, it writes from the node as before. `-DKN_NO_STABLE_WRITE` builds R246's path.
**Proof.** `harness/tape_write_test.c` (built twice): the stand-in yaffs_write programs, lets the record thread
refill the node, then compares as YAFFS does. R246's path (`tape_write_stock_test`) retires a good block; the copy
retires none, and a flipped bit in the page (a real failure) still retires one. In op1emu the race never shows: a
60 s take of three held keys, probe `kntest7` reading YAFFS's counters (retries +0xE34, retired blocks +0xE38) and
every block's state, gave 0 retries, 0 blocks to retire, 0 dead on both kennel main (about 462k page writes) and
the fix (about 444k) (OP1-Emulator `run/badblock/`). The emulator's NAND program completes at once, so the record
side has no time to change the node between program and read-back (most likely; on real NAND a page program takes
a typical 200..700 us).
**Cost (measured, OP1-Emulator `run/badblock/check-cyc.out`, a throwaway build with CYCLES around the copy).** The 60 s
take made 14502 writebacks (about 240 a second: R246 rewrites the chunk being recorded on every pass). A copy took
39967 cycles on average (max 270823, with interrupts), the write itself (event, seek, yaffs_write) 201870. At 240 a
second that is 9.6M cycles a second, 2.4 % of 400 MHz. The emulator counts one cycle per packet with no cache or
SDRAM stalls; on the unit, 64 KiB through a 16 KB data cache from SDRAM likely makes a copy 250k..500k cycles
(estimate, not measured). There the writeback rate is bound by NAND time instead (32 page programs, about 7 ms a
chunk), so the copy makes each writeback roughly a tenth longer and there are that many fewer of them. Copying only
for the node being recorded would save little: the writebacks come with the take (14502 in about 60 s), so nearly all
of them should be that node (inferred from the count, not traced).
**Flash check (`kennel/kn_flash.c`).** Read-only: pages are read through the NAND driver's read hook (device +0x5C,
args device, chunk, data, tags) under yaffs_lock (0x01A98B3C / 0x01A98B78), not yaffs_rd_chunk_tags_nand, which
flags a block on an ECC event. ECC result at tags +0x10: 1 clean, 2 corrected, 3 uncorrectable. Per block: dead if
YAFFS retired it (block state 9, not read), errors if a page could not be corrected, fixed if one was corrected,
else healthy. 16 pages per main loop pass (`kn_flash_service` from `kn_core_service`); the scan waits while the
check is hidden, while the tape runs (0xFF802960) and in disk mode (0xFF906EF9). Arena: 4 KiB of block states and a
page buffer. API (`op1_feature.h`): `op1_flash_open` (show; start a scan unless one runs), `op1_flash_push(knob)`
(while shown: blue starts or restarts, the others close it and return 1), `op1_flash_close`, `op1_flash_shown`,
`op1_flash_draw(r)` and `op1_flash_counts(out[4])` (0 idle, 1 scanning, 2 done). Screen as #250's guide shows its
check, our own drawing: HEALTHY / FIXED / ERRORS / DEAD with their counts and a coloured dot, SCAN with a percentage,
DONE or PAUSED, and a map of one 2 px dot per block (blue healthy, white fixed, red errors, pink dead, navy not
read). FILE (Maiko's file.c) opens it on a blue push. Tests: `harness/flash_test.c`, golden `flash_check`.

## MIDI and synth services (`op1_feature_midi.h`, `kennel/kn_midi.c`, 2026-10-15, branch feat-midi-core)
Core hooks for op1r 35's MIDI sequencer and CC automation (op1r-src 5c90efb); any feature can use them.

| Service | How | Thread |
|---|---|---|
| `op1_feature_t.midi_raw(msg, len)` | every USB-MIDI channel message (notes, CC, program change, pressure, pitch bend) and real-time byte (F8, FA, FB, FC), channel in the status byte, from the RX ring in `du_rx_poll` before the stock parser | timer |
| `op1_note_source()` | `OP1_SRC_KEYS / PLAYER / MIDI (+ channel) / FEATURE` for the note an observer or pipeline stage is handling, from VoiceCtl key_down / key_up's caller (hook.S passes RETS); kennel sequencer types count as players | caller's |
| `op1_param_set(group, knob, 0..127)` | engine, envelope, FX or LFO knob of the current synth slot, scaled to the knob's range and set with the patch setter on the KeyHandler thread (private key code 0x3F), saved in the sound; skips sample start / end pairs, packed LFO types, FX / LFO off | any |
| `op1_midi_take_cc(cc, 1)` | the CC still reaches `midi_in`, but `midi_cc_hook` no longer turns it into a key press or encoder turn | any |
| `op1_stock_seq_key(note, down)` | the note as a keyboard key through the KeyHandler queue (24 keys, octaves folded), so the current mode's stock sequencer gets it in order; no second down of a held key | any |
| `op1_feature_t.tape_view` | SEQ held + TAPE opens a full screen over the tape screen (claim `view:seqtape`), TAPE alone or a mode key closes it; plain SEQ still reaches stock (late, on release); encoder pushes and turns that the input filter and the tape features leave go to the page; tape markers keep working in it; `op1_tape_view_open()` / `_close()`, `op1_tape_view_enable(0)` leaves SEQ and TAPE stock | KeyHandler |
| `op1_switch(feature, label)` | an on / off row on the settings page (clock T3: green, white, red), setting `<feature>.on`, read with `op1_switch_on` | boot / any |

Limits: `midi_raw` needs the RX hook at 0x019E3CC8 (the dev-update site): OP1-Emulator's builder always installs it,
`make_firmware.py` only with `--dev`. The note source is set at the key_down / key_up entry and read later in the
same call, so a note from another thread in between can overwrite it (rare: keyboard and sequencer notes on two
threads at the same instant). Checks: `harness/midi_core_test.c` (raw packets, source ranges, parameters, keys, view,
switches, taken CCs) in `make check`; fake core has all of them for feature tests.

## MIDI sequencer and CC automation (op1r 35, 2026-10-15, branch feat-midiseq)
op1r 35's features (op1r-src 5c90efb, pcppcp) on the MIDI and synth services, as plugins `midiseq` and `midicc`
(loadable: compiled in, op1r's view statics would leave the core 2 KB of `.bss`). `midiseq/ms_core.c` and `ms_draw.c`
are op1r's, unchanged; `midiseq/midiseq.c` replaces op1r's firmware glue `seqdev/ms_fw.c`:

| op1r 35 | kennel |
|---|---|
| VoiceCtl key_down / key_up stubs of its own, source by caller | note input observers + `op1_note_source()` |
| `ms_midi_rx` in `du_rx_poll` (packet peek) | `midi_raw` |
| `ci_metro_render` / `ci_service` calls | tape hooks `block` / `service` |
| `ms_key` / `ms_knob` in dispatcher.c, its own SEQ + TAPE chord and screen swap | `tape_view` page + input filter (`op1_tape_view_open()`) |
| switch on clock T2 green (usbout.c), `op1rsettings` key `midiseq` | `op1_switch("midiseq", "midi seq")`: settings page T3 green, setting `midiseq.on` |
| `mx_cc` in `midi_cc_hook`, MX_KEY 0x3F | `midicc`: `midi_in` + `op1_param_set` (same key code in the core) + `op1_midi_take_cc` |
| kb_push of its own | `op1_stock_seq_key` |
| NEW_ARR heap, YAFFS calls | `op1_alloc`, `op1_file_*` |

The switch moved from clock T2 (the USB out page owns it in kennel) to the settings page; op1r 35's saved switch
(`op1rsettings` key `midiseq`) is not read, so it starts off once. The song file is the same. Checks:
`harness/midiseq_test.c` (fake core, 51 checks: the switch, recording from keys / players / a MIDI channel / CCs,
REC held and latched, playback to the instrument / stock sequencer / MIDI out / synth knobs, mute, lift / drop, the
file, switching off, the CC map) and op1r's `mseq_test.c`, both in `make check`.
Emulator (OP1-Emulator `run/kennel-midi/check_h2.py`, both as files, NAND from `run/kennel-hook/nand`): the
settings page shows "midi seq" off, green turns it on; SEQ held + TAPE opens the view; with REC held and the tape
playing, three keys are recorded on track 1 (keyboard source, 6 key_down / key_up calls) and an envelope CC sent over
USB-MIDI (USB/IP) during the take is applied live; after a rewind the take plays back: the same 9 note-ons (chord
mode is on in that NAND), from kennel code, and the recorded CC applied again.


### Shared screen drawing-cache lifetime

Core screen selection may replace a table slot from the input thread. `kn_screens_frame` takes a fixed copy of all68 slots for each Gfx frame; requests made during the frame are drawn on the next frame. Documents removed since the previous rendered table have their stock reset invoked on Gfx before the next draw, unless another slot still refers to that document. This releases drawing buffers, while preserving the parsed SVG and node pointers initialized by the plugin. Keep screen objects and documents alive until reboot; do not free drawing state from key/audio callbacks or bypass the core frame wrapper. Stock screen-ID and heap-pressure resets still apply to the current frame.
