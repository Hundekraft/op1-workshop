# Maiko #249 utilities, rebuilt on kennel's hooks

<!-- Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). -->

Maiko Pruett's firmware #249 adds four utilities to the OP-1: scale mode, sound naming, a FILE storage view and tape
undo/redo. #249 has no licence, so kennel takes none of its code or bytes (PROVENANCE.md). The owner decided on
2026-10-15 to rebuild them as kennel features from their **behaviour**. This file is that behaviour: what a user sees
and what the tests observed. The sources are OP1-Emulator's `docs/maiko249-audit.md` (emulator probes), the workshop
manual and emulator screenshots. The code is written from this file, not from #249's disassembly. Where #249's
choice was unclear or unobservable, the decision here is ours and is marked **ours**.

The lists below describe implemented behavior and its contracts. The emulator checks
are bounded representatives, not proof of every utility branch, MIDI delivery or
power-loss behavior. Current scope is recorded in OP1-Emulator's
`docs/harness-user-flows.md` and dated log.

Credit in the manual and release notes: "after Maiko Pruett's #249".

## Scale mode (`synth_sdk/scale/`, built)

- Locks the keyboard to a key and scale. Nine scales: major, minor, dorian, phrygian, lydian, mixolydian, locrian,
  harmonic minor, melodic minor, plus OFF (the default).
- Each white key plays the scale note with its letter (C lydian: F plays F#). Black keys play only if they are in
  the scale; the rest are silent. Root letters for black roots: Db, Eb, F#, Ab, Bb (**ours**: #249 was only
  observed with C).
- Controls (#249): synth mode, T2 page, hold Shift: an overlay shows KEY (big letter) and a strip of 14 keys from F
  with the note each white key plays (a dot marks a sharp) and the scale name in a red box. White turns the key,
  orange the scale. Release Shift to play.
- Saved across reboots.
- Differences from #249 (**ours**): it acts on every note into the synth (MIDI in and the sequencers too), and
  Shift + key sequencer shortcuts keep working (workshop issue #1).

Hooks: note pipeline (stage 100), settings service, input filter (Shift on synth T2), overlay, toast, music
context. Built. The earlier screen-id question is resolved by the bounded native
layout checks: screen 40, including the D-flat-major/OFF pair and declared protected
stock regions. Real-input scale checks cover C major/lydian mapping, an excluded
black key, shared held-note release, OFF restoration and a sequencer source. These
do not establish all scales, MIDI delivery or restart behavior. Evidence and limits:
OP1-Emulator `docs/harness-user-flows.md`, `run/layout-db-major/` and
`run/scale-chord-retry/result.json`.

## Sound naming

- Hold a sound key (1..8) to save as usual; keep holding and a naming screen with a letter grid appears.
- Characters: `a`..`z`, `0`..`9`, `-`, `_` and space (39; #249 had the 36 letters and digits), shown uppercase in a
  13 x 3 grid. Blue moves one character, green one row (13), both wrap. Blue or white push adds the character; left
  arrow deletes the last one. At most 12 characters.
- Pressing the same sound key again saves under the typed name. Synth and drum sounds both work.
- An existing name gets `_1` added (`aa` -> `aa_1`, the original stays). An empty name gives the stock
  date-stamp name. A mode key (synth, drum, tape, mixer) saves with the stock name (it does not cancel).
- The name is the snapshot's name in the sound browser and survives reboot; the sound's settings (custom engines
  and effects included) save and load as with a stock save.

Built (`synth_sdk/naming/`, `harness/naming_test.c`) on the core's snapshot save hook (`kennel/kn_save.c`): when R246's
hold-to-save is about to save (`OP1_EV_SAVE_HOLD`) naming holds it back and opens the text entry (a..z, 0..9, '-',
'_', space, 13 per row, the owner's wide grid; #249 had a..z 0..9); the same sound key saves under the name
(`op1_snapshot_save`, R246 adds `_1`); a mode key or an empty name gives the date stamp. Claim `snapshot.save`.
Emulator (OP1-Emulator `run/kennel-naming/check-naming.json`): typed "ab" saved as `preset_synth/snapshot/ab.raw`,
again as `ab_1.raw`; an empty name and a mode key (drum) gave date-stamp files. Rechecked on kennel main 191a40a
(OP1-Emulator `run/night-3.0/cross`).

## FILE storage view

- #249: Shift + COM, then turn blue to a fifth FILE tab: a breakdown of storage into tape, sounds, factory, system,
  mods, bad, overhead and free, each with its size (KB/MB), as a bar. Its COM screen showed traces of the stock tabs
  under its five tabs.
- **Ours** (3.0, owner's decision 2026-10-16): COM keeps the stock four tabs, and blue does what it does in stock
  (nothing in OP-1 / CTRL / DISK, the USB charge in OPT). FILE is a second Shift + COM while COM is shown; Shift + COM
  again goes back to the stock COM.

Built (`synth_sdk/file/`, `harness/file_test.c`) on the COM view (`op1_feature_t.com`, claim `view:com`) and the core's
storage walk (`op1_storage`): in COM, Shift+COM again shows it, drawn as the owner's pick F3 (OP1-Emulator
`docs/design/file-view/F3.png`): a tape reel whose ring is split by category (128 steps, proportional, one step at least
for a non-zero category), the free space in the hub, a legend with each size (KB under 1 MB, MB with one decimal,
binary units); a push other than blue walks again. Lines and the stroke font only.
Blue push: the flash check (G1), blue again scans again; another push goes back to FILE and recounts.
Emulator (OP1-Emulator `run/kennel-file/`, screenshots `file-sheet4.png`): plain COM still opens the album; Shift+COM
opens the stock COM, again the FILE view with the walk's numbers; a push recounts ("counting"); again the stock COM
and its OPT tab; a mode key leaves COM, which opens on the stock screen next time.

## Tape undo / redo

- Every recording, punch-in, overdub, loop take, lift, drop, slide, split and join can be undone, up to seven
  steps. Hold tape and press left to undo, right to redo. A popup shows UNDO / REDO.
- Recording or editing after an undo drops the redo steps (branching).
- Undo restores the tape audio and the clip layout exactly; redo restores the later state exactly. It works while
  stopped or playing, on all four tracks, and right after a recording (a request while the tape is still writing
  is refused or deferred, never half-done).
- History survives a normal reboot.
- With little free storage, undo turns itself off and recording carries on: a step that would leave less free
  space than the reserve is not kept, the history is cleared and a toast says "undo off: low on space". #249
  stopped offering undo at about 16 MB free. Our reserve is a setting (**ours**, `undo.reserve_mb`), default 24 MB,
  read at boot.
- Disk mode (USB) sync clears the history; new history works afterwards.
- Historical #249 observation: a disk sync can lose the last 64 samples of a take
  still in the tape cache. The earlier extra-flush proposal is not an implemented fix
  or current approved scope. The owner defers changes to this inherited boundary and
  keeps the existing take-ending flush behavior. Normal-restart tests after legitimate
  drain do not prove every disk-sync/tail case; no firmware fix is claimed here.
- Forced power loss during a write is out of scope (owner: the OP-1 runs on its battery).

Design (**ours**, the owner chose #249's way: history on flash, not only in RAM; `synth_sdk/undo/`):
- A step runs from an `OP1_EV_TAPE_EDIT` before event to the next `OP1_EV_TAPE_DRAINED`. It keeps what that edit
  changed, as it was before: the audio of the chunks it rewrote and the clip rows of the tracks it touched.
- REC: the before event opens the step. On every `OP1_EV_TAPE_WRITE` of a (track, chunk) not yet seen in this step,
  `op1_tape_read_old` copies the old 64 KiB into a staging slot and a bitmap (4 x 485 chunks) marks it; later writes of
  the same chunk are ignored (a take rewrites a chunk about 240 times a second). The event only copies: flash writes
  happen later, on the main loop, outside any event. DRAINED closes the step and clears the bitmap.
- LIFT / DROP: the before event copies the clip rows and the audio range the edit will write (lift, drop and erase
  write the file themselves, so the copy is a core read of that range). SPLIT / JOIN change rows only.
- ERASE (the whole tape, about 384 MiB): not undoable; the history is cleared, with the toast "erase: no undo".
- Redo: undo first copies the current content of the same chunks and rows, then restores the old; redo swaps back.
  Recording or editing after an undo drops the redo steps.
- Space: the staging area is `op1_undo_area` (1.5 MiB: a 64 KiB header, 22 staging slots of 64 KiB and a spare);
  staged chunks are written to the step's file on flash one slot per main loop pass. Seven steps; the oldest goes
  first. A step that would push free space below the reserve (setting, default 24 MB) is not kept and the history
  is cleared ("undo off: low on space"); one that outruns the staging slots likewise ("too long to undo"); never
  half-kept. History files under `/yaffs2/user/kn_undo/` (tape 1) and `kn_undo/t1`..`t3` (tapes 2..4), own names
  (not #249's).
- Keys: tape mode, hold tape, left = undo, right = redo (`op1_tape_hooks.key`, codes 0x24 / 0x25; claims
  `key:tape:tape+left`, `key:tape:tape+right`). A popup over the tape screen (`op1_tape_hooks.draw`) shows UNDO or
  REDO with an arrow and a progress bar while the job runs and about a second after. A request while the tape is
  still writing (no DRAINED yet) is refused with the toast "still writing"; with no step, "nothing to undo" /
  "nothing to redo".
- State: nothing in `.bss` (the core has about 8 KB left): the index, bitmap and slots live in the undo area.

Built (`synth_sdk/undo/`, `harness/undo_test.c`): seven steps on flash in `/yaffs2/user/kn_undo` (`sNNN.dat` records of
track, chunk and 64 KiB; `sNNN.clp` clip rows; `index.bin`), read back at boot. Takes are staged from writebacks and
written out one slot per main loop pass; lift / drop ranges are read and written in their before event; clip rows
come from a base taken on the main loop. Undo / redo swap a step with the tape in place, clip rows first, then one
record per pass; a refused call is retried. A new step drops the redo steps, an eighth the oldest. A step that can't
be kept whole (erase, the free space reserve `undo.reserve_mb` default 24, staging overrun, a file error) clears the
history with a toast; an edit during an undo gives the job up and clears it ("undo cut short"); disk mode
(`OP1_EV_DISK` 1) clears it. Four tapes: each tape keeps its own history (reloaded after `OP1_EV_TAPE_SWITCH`); a job
cut short by a switch drops that tape's history and can leave audio no clip refers to.
Emulator on flash: OP1-Emulator `run/kennel-undo-m/check2-undo.json`: three takes, undo twice (= after take 2, after
take 1); reboot (still after take 1); redo (= after take 2); a new take drops the redo step; undo (= after take 2);
track 0's 24 chunk hashes and clip rows compared each time. `check3-undo.json`: a take, lift (audio blanked, clip
gone), undo (both back), redo, drop, undo (back to lifted). Night 3.0 (OP1-Emulator `run/night-3.0/undo-*`): lift /
drop, split / join, seven levels, low space and disk mode all pass; four tapes (`run/night-3.0/tapes`, `tapes-cut`):
each tape's own history across switches, and a job cut short by a switch, pass.
Emulator, one step in RAM (the first version): OP1-Emulator `run/kennel-undo-m/check-undo.json` (two takes on track 0,
the second starting inside the first's last chunk; undo, redo, undo: track 0's first 24 chunk hashes and clip rows
equal after take 1, take 2, take 1).

Core services it uses (feat-core-undo, on main): `op1_tape_read`, `op1_tape_restore`, `op1_tape_clips_get` / `_set`,
`op1_file_*`, `OP1_EV_DISK`.

Acceptance (from the #249 audit, to repeat on kennel): record/undo/redo exact, restart, playback, overdub, punch,
loop, all four tracks, edits, seven levels and branching, immediate requests, low storage, disk sync.

## Maiko #250 tape edits (G2, inside undo, `synth_sdk/undo/undo.c`)

Behaviour from maikopruett.com's guide pages (merge-drop, loop-copy, bounce; read as text), no #250 code or art:
- Merge drop, Shift + drop: the lifted tracks in the clipboard summed onto the selected track at the playhead (one
  lifted track: a plain drop onto it); overwrites what was there; stopped, the playhead goes to the end. Replaces
  stock's Shift + drop (drop all), as #250 does.
- Copy, tape + lift: the loop's four tracks into the clipboard, nothing cut, while playing; not an undo step;
  needs the loop on and under 22.5 s.
- Paste, tape + drop: the clipboard after the loop (loop off: after the last clip); a copy or lift-all goes onto
  all four tracks, one lifted track onto the selected one; the loop moves onto the copy, so pasting again builds a
  song while it plays. Undo takes back the audio and clips; the loop stays where it moved (as #250).
- Bounce, tape + Shift + drop: tracks 1..4 over the loop summed onto the selected track; the other tracks stay.
- Sums are exact (no mixer volume or pan); if a sum clips anywhere, all of it goes through a soft limiter (**ours**:
  linear below 24576, a knee to full scale). Bounce, merge and paste are each one undo step. A done edit shows the undo popup with its word
  (MERGE, COPY, PASTE, BOUNCE) for about a second after it ends, as #250. Refusals are toasts
  (**ours**; #250 shows no popup): loop off, empty clipboard, no room on the tape, recording.
- Uses the core tape services in `op1_feature_tape.h` (loop, track, playhead, transport, clipboard). Host test:
  `harness/undo_test.c`. Emulator (OP1-Emulator `run/night-3.0/g2`, again on main 191a40a in `cross`): bounce,
  paste and merge each write only their tracks and undo cleanly; paste moves the loop.

## Order of work
1. Scale controls, once the T2 overlay draw exists.
2. Naming, once the text-entry screen and the save-name hook exist.
3. FILE, once a COM tab or view and a storage-walk service exist.
4. Undo, the largest: needs the tape pre/post edit events and the history store.
