/* Relocated plugin descriptor validation. Native instructions remain trusted.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "kn_validate.h"
#include "kn_load.h"
typedef struct { const uint8_t *p; uint32_t base, size, text; } view;
static uint32_t word(const view *v, uint32_t p)
{
    const uint8_t *d = v->p + (p - v->base);
    return d[0] | d[1] << 8 | d[2] << 16 | (uint32_t)d[3] << 24;
}
static int span(const view *v, uint32_t p, uint32_t n)
{
    return !(p & 3) && p >= v->base && (uint64_t)p + n <= (uint64_t)v->base + v->size;
}
static int str(const view *v, uint32_t p, unsigned max)
{
    if (p < v->base || (uint64_t)p >= (uint64_t)v->base + v->size) return 0;
    uint32_t off = p - v->base;
    for (unsigned i = 0; i <= max && (uint64_t)off + i < v->size; i++) {
        unsigned c = v->p[off + i];
        if (!c) return 1;
        if (c < 32 || c > 126) return 0;
    }
    return 0;
}
static int callback(const view *v, uint32_t p, int required)
{
    if (!p) return !required;
    return !(p & 1) && p >= v->base && (uint64_t)p + 2 <= (uint64_t)v->base + v->text;
}
static int calls(const view *v, uint32_t p, unsigned start, unsigned end)
{
    for (unsigned off = start; off < end; off += 4) if (!callback(v, word(v, p + off), 0)) return 0;
    return 1;
}
static int screen(const view *v, uint32_t p)
{
    return !p || (span(v, p, 8) && callback(v, word(v, p), 1) && callback(v, word(v, p + 4), 1));
}
static int page(const view *v, uint32_t p)
{
    return !p || (span(v, p, 20) && str(v, word(v, p + 4), 95) && word(v, p + 8)
        && screen(v, word(v, p + 8)) && calls(v, p, 12, 20));
}
static int named(const view *v, uint32_t p) { return str(v, p, 15) && v->p[p - v->base]; }
static int feature(const view *v, uint32_t p)
{
    if (!span(v, p, 88) || (word(v, p) & 65535) != 1 || !named(v, word(v, p + 4))) return 0;
    const unsigned cb[] = { 8, 12, 16, 24, 48, 52, 56, 68, 76 };
    for (unsigned i = 0; i < sizeof cb / sizeof *cb; i++) if (!callback(v, word(v, p + cb[i]), 0)) return 0;
    if (!!word(v, p + 8) != !!word(v, p + 12)) return 0;
    const unsigned pages[] = { 20, 44, 72, 80 };
    for (unsigned i = 0; i < sizeof pages / sizeof *pages; i++) if (!page(v, word(v, p + pages[i]))) return 0;
    uint32_t q = word(v, p + 60);
    if (q && (!span(v, q, 8) || !calls(v, q, 0, 8))) return 0;
    q = word(v, p + 64);
    if (q) {
        unsigned i;
        for (i = 0; i <= 64; i++, q += 4) {
            if (!span(v, q, 4)) return 0;
            uint32_t c = word(v, q);
            if (!c) break;
            if (i == 64 || !str(v, c, 159)) return 0;
        }
    }
    q = word(v, p + 28);                        /* sequencer descriptor */
    if (q && (!span(v, q, 40) || !named(v, word(v, q)) ||
        (word(v, q + 4) && !str(v, word(v, q + 4), 15)) || !callback(v, word(v, q + 8), 1) ||
        (word(v, q + 12) && !str(v, word(v, q + 12), 95)) || !screen(v, word(v, q + 16)) || !calls(v, q, 20, 40))) return 0;
    q = word(v, p + 32);                        /* LFO descriptor */
    if (q && (!span(v, q, 60) || !named(v, word(v, q)) || !callback(v, word(v, q + 8), 1) ||
        !calls(v, q, 12, 36) || (word(v, q + 36) && !str(v, word(v, q + 36), 95)) ||
        !screen(v, word(v, q + 40)) || !calls(v, q, 44, 60))) return 0;
    q = word(v, p + 36);                        /* drum descriptor */
    if (q && (!span(v, q, 40) || (word(v, q) & 65535) != 1 || !named(v, word(v, q + 4)) || !calls(v, q, 8, 40))) return 0;
    q = word(v, p + 40);                        /* tape hooks: nine optional callbacks */
    if (q && (!span(v, q, 36) || !calls(v, q, 0, 36))) return 0;
    q = word(v, p + 84);                       /* native drum-synth descriptor */
    if(q){
        if(!span(v,q,92)||word(v,q)!=(1u|(92u<<16))||!named(v,word(v,q+4))||!str(v,word(v,q+8),31)||!calls(v,q,12,92))return 0;
        for(unsigned off=12;off<40;off+=4)if(!callback(v,word(v,q+off),1))return 0;
    }
    return 1;
}
int kn_validate(const uint8_t *image, uint32_t base, uint32_t size, uint32_t text,
                int kind, int stereo, uint32_t entry, uint32_t scr, const char **err)
{
    view v = { image, base, size, text };
    uint32_t n = kind == KN_KIND_SYNTH ? 16 : stereo ? 16 : 12;
    if (text > size || (uint64_t)base + size > 0x100000000ULL || (uint64_t)base + entry > 0xffffffffu) goto bad;
    uint32_t p = base + entry;
    if (kind == KN_KIND_FEATURE) { if (!feature(&v, p)) goto bad; }
    else if (!span(&v, p, n) || !callback(&v, word(&v, p), 1) || !callback(&v, word(&v, p + 4), 1) ||
        (kind == KN_KIND_SYNTH && !callback(&v, word(&v, p + 8), 0)) ||
        (stereo && !callback(&v, word(&v, p + 12), 1))) goto bad;
    if (scr != KN_NONE && ((uint64_t)base + scr > 0xffffffffu || !screen(&v, base + scr))) goto bad;
    return 0;
bad:
    *err = "invalid plugin descriptor or callback";
    return -1;
}
