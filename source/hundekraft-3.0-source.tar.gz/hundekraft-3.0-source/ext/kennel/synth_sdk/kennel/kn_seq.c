/*
 * Sequencer types (op1_feature_seq.h, docs/feature-hooks.md "Sequencer types"): the core side. Every sequencer
 * kennel adds runs as R246's type 3 (finger) plus "which type is active" per mode; the R246 patch sites stay here:
 *   SeqIds::from_name CALLs 0x01A42A2E / 0x01A42BDC / 0x01A42CE0 -> eu_seq_from_name   (hook.S hook_seqname1..3)
 *   SeqIds::name entry 0x01A422EC                               -> eu_seq_name        (hook.S hook_seqtoname)
 *   PlayerManager::create_player case 3 0x01A0D150              -> seq_player_get     (hook.S hook_euplayer)
 * plus the finger screen slot 0x2D, the key / encoder routing on that screen (dispatcher.c calls kn_seq_key /
 * kn_seq_turn / kn_seq_after_key) and MIDI START. Types come from the feature registry (kn_seq_finish, after the
 * loader). The hook symbol names keep op1r's (eu_*), and seq_shift_wants keeps its name: OP1-Emulator's builder
 * reads it from the core's ELF for the workshop's Scale-mode Shift shortcuts (maiko249.py SHIFT_STUB).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_synth.h"
#include "../op1_feature_seq.h"
#include "../op1_feature_midi.h"
#ifndef OP1_HOST                          /* (host builds get seq_text.h's private static copy) */
#define OCC_TEXT_IMPL                     /* the one firmware copy of seq/seq_text.h (stroke text, sq_store_*) */
#endif
#include "../seq/seq_text.h"

int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);

#define KN_SEQ_MAX     8
#define FINGER_TYPE    3
#define SEQ_SCREEN_ID  0x2D                                      /* finger's screen slot */
typedef struct { const char *name; int type; } kn_seq_stock;    /* SeqIds' name table entry */

#ifdef OP1_HOST                                                 /* harness/seq_test.c: the R246 state below as host data */
#include "../harness/fake_core.h"
extern uint8_t host_shift;                                          /* fake_core.c (fc_shift) */
extern int32_t host_bank, host_drum_oct;                        /* bank 1 = drum (as kn_save.c's host_bank) */
extern const kn_seq_stock host_seq_table[6];
extern void *host_screen_table[0x40];
extern const uintptr_t host_iter_screen_vt[10];
int host_seq_from_name(const void *s);
void *host_finger_player(void);
void *host_screen_ctor(void *o, int id, const char *svg);
void *host_svg_load(void *svg);
void host_key_dispatch(int code, int pressed);
void host_seq_octave(int dir);
#define SEQ_FROM_NAME  host_seq_from_name
#define SEQ_TABLE      host_seq_table
#define FINGER_PLAYER  host_finger_player
#define CUR_MODE()     (host_bank == 1)
#define SHIFT_BYTE     host_shift
#define CURRENT_SCREEN fc_screen
#define SCREEN_TABLE   host_screen_table
#define SCREEN_CTOR    host_screen_ctor
#define ITER_SCREEN_VT host_iter_screen_vt
#define SVG_LOAD       host_svg_load
#define KEY_DISPATCH   host_key_dispatch
#define DRUM_OCT()     host_drum_oct
#define seq_octave     host_seq_octave
#else
#define SEQ_FROM_NAME  ((int (*)(const void *))0x01A42344)       /* stock: asserts on an unknown name */
#define SEQ_TABLE      ((const kn_seq_stock *)0x018FA634)       /* 6 stock entries */
#define FINGER_PLAYER  ((void *(*)(void))0x019ED460)
#define CUR_MODE()     (*(volatile int *)0x01DE4C40 == 1)
#define SHIFT_BYTE     (*(volatile uint8_t *)0x01DD7F78)
#define CURRENT_SCREEN (*(volatile int *)0x018B65C8)
#define SCREEN_TABLE   ((void **)0x01DF4E54)
#define SCREEN_CTOR    ((void *(*)(void *, int, const char *))0x01A3BAB0)
#define ITER_SCREEN_VT ((const uintptr_t *)0x019103FC)
#define SVG_LOAD       ((void *(*)(void *))0x01A503D8)
#define KEY_DISPATCH   ((void (*)(int, int))0x019B6C74)
#define DRUM_OCT()     (((const int *)0x01DFE500)[*(volatile int *)0xFF8016D8 & 7])
#endif
#define SHIFT_HELD()   (SHIFT_BYTE)

typedef struct { uint32_t alloc; union { char buf[16]; char *ptr; } u; uint32_t size, cap; } kn_dstr;   /* R246 */

static const op1_seq_type_t *types[KN_SEQ_MAX];
static int n_types;
static volatile uint8_t active[2];                  /* per mode: index + 1 of the active type, 0 = stock */
static char missing[2][OP1_SEQ_NAME_MAX + 1];       /* per mode: saved name with no registered type (runs as finger) */
static uintptr_t scr[KN_SEQ_MAX][32], scr_vt[KN_SEQ_MAX][10];   /* (32-bit words on the OP-1) */
static uint8_t scr_ready[KN_SEQ_MAX];
static void *finger_screen;
static volatile uint8_t play_pending;

static int streq_n(const char *a, const char *b, uint32_t n)
{
    if (!b) return 0;
    for (uint32_t i = 0; i < n; i++) if (a[i] != b[i] || !b[i]) return 0;
    return b[n] == 0;
}

void kn_seq_finish(void)
{
    for (int i = 0; i < kn_feature_count() && n_types < KN_SEQ_MAX; i++) {
        const op1_seq_type_t *t = kn_feature_at(i)->seq;
        if (!t || !t->name || !t->player) continue;
        uint32_t len = 0;
        while (t->name[len] && len <= OP1_SEQ_NAME_MAX) len++;
        int dup = 0;                                             /* same name twice (a file and a built-in): first wins */
        for (int j = 0; j < n_types; j++) if (streq_n(t->name, types[j]->name, len)) dup = 1;
        if (!dup) types[n_types++] = t;
    }
}

static const op1_seq_type_t *cur(void)
{
    int a = active[CUR_MODE()];
    return a ? types[a - 1] : 0;
}

/* SeqIds::from_name (the 3 CALLs): a registered name -> type 3 and active; a stock name -> stock; anything else
 * (a type that is not loaded) -> finger, remembering the name so the sound keeps it */
int eu_seq_from_name(const kn_dstr *s)
{
    const char *p = s->cap > 15 ? s->u.ptr : s->u.buf;
    int m = CUR_MODE();
    missing[m][0] = 0;
    for (int i = 0; i < n_types; i++)
        if (streq_n(p, types[i]->name, s->size) || streq_n(p, types[i]->alias, s->size)) {
            active[m] = (uint8_t)(i + 1);
            return FINGER_TYPE;
        }
    active[m] = 0;
    for (int i = 0; i < 6; i++)
        if (streq_n(p, SEQ_TABLE[i].name, s->size)) return SEQ_FROM_NAME(s);
    if (s->size && s->size <= OP1_SEQ_NAME_MAX) {
        for (uint32_t i = 0; i < s->size; i++) missing[m][i] = p[i];
        missing[m][s->size] = 0;
    }
    return FINGER_TYPE;
}

/* SeqIds::name(type) (JUMP at its entry) */
const char *eu_seq_name(int type)
{
    int m = CUR_MODE();
    if (type == FINGER_TYPE && active[m]) return types[active[m] - 1]->name;
    if (type == FINGER_TYPE && missing[m][0]) return missing[m];
    for (int i = 0; i < 6; i++) if (SEQ_TABLE[i].type == type) return SEQ_TABLE[i].name;
    return "pattern";
}

/* PlayerManager::create_player case 3 */
void *seq_player_get(void)
{
    const op1_seq_type_t *t = cur();
    return t ? t->player() : FINGER_PLAYER();
}

/* Shift + keyboard key (0..23) is a shortcut of the current mode's sequencer. Not called by kennel itself: the
 * workshop's Scale-mode adapter calls it while Shift is held, so only these keys skip the scale snapping. */
int seq_shift_wants(int key) __attribute__((used));
int seq_shift_wants(int key)
{
    const op1_seq_type_t *t = cur();
    return t && t->shift_wants ? t->shift_wants(key) : 0;
}

/* ---- screens: one object per type with a screen, swapped into slot 0x2D while that type is active ---- */
void kn_seq_screens_ctor(void)                                  /* screens_ctor_hook */
{
    for (int i = 0; i < n_types; i++) {
        const op1_seq_type_t *t = types[i];
        if (!t->screen || !t->svg) continue;
        void *saved = SCREEN_TABLE[SEQ_SCREEN_ID];
        SCREEN_CTOR(scr[i], SEQ_SCREEN_ID, t->svg);
        SCREEN_TABLE[SEQ_SCREEN_ID] = saved;
        for (int j = 0; j < 10; j++) scr_vt[i][j] = ITER_SCREEN_VT[j];     /* is_visible: id == 0x2D */
        scr_vt[i][3 * 2 + 1] = (uintptr_t)t->screen->update;
        scr_vt[i][4 * 2 + 1] = (uintptr_t)t->screen->init;
        scr[i][3] = (uintptr_t)scr_vt[i];
    }
}

void kn_seq_sync_screen(void)
{
    if (!finger_screen) return;
    int a = active[CUR_MODE()];
    SCREEN_TABLE[SEQ_SCREEN_ID] = a && scr_ready[a - 1] ? (void *)scr[a - 1] : finger_screen;
}

void kn_seq_screens_load(void)                                  /* screens_load_hook, after the stock screens */
{
    finger_screen = SCREEN_TABLE[SEQ_SCREEN_ID];
    for (int i = 0; i < n_types; i++) {
        if (!scr[i][2]) continue;
        scr[i][0] = (uintptr_t)SVG_LOAD((void *)scr[i][2]);
        if (scr[i][0]) { types[i]->screen->init(scr[i]); scr_ready[i] = 1; }
    }
    kn_seq_sync_screen();
}

/* the active type if its screen is shown */
static const op1_seq_type_t *seq_page(void)
{
    kn_seq_sync_screen();
    int a = active[CUR_MODE()];
    return a && scr_ready[a - 1] && CURRENT_SCREEN == SEQ_SCREEN_ID ? types[a - 1] : 0;
}

#ifndef OP1_HOST
/* octave down / up as SeqManager's key handler does it (0x01A4272E..; with a kennel sequencer active, finger's
 * controller would get the left / right keys first): new octave, octave popup, store in the instrument patch, notify. */
int kn_keys_octave(int dir);
static void seq_octave(int dir)
{
    int drum = CUR_MODE();
    int oct = drum ? ((int (*)(int))0x01A84348)(dir) : kn_keys_octave(dir);
    int slot = *(volatile int *)(drum ? 0xFF8016D8 : 0xFF8016D4) & 7;
    uint8_t *patch = (uint8_t *)(drum ? 0x01DDD9A8 : 0x01DDD7E8) + slot * 0x38;
    ((void (*)(void))0x019EC0C4)();
    ((void (*)(int))0x019EC07C)(oct);
    ((void (*)(void *, int))0x019FF36C)(patch, oct);
    const uint32_t *vt = *(const uint32_t **)(patch + 0x34);
    ((void (*)(void *))vt[0x34 / 4])(patch + (int16_t)vt[0x30 / 4]);
}
#endif

/* key_event_hook: 1 = handled (not passed on) */
int kn_seq_key(int code, int pressed)
{
    const op1_seq_type_t *t = seq_page();
    if (!t) return 0;
    int m = CUR_MODE();
    if (code == 0x24 || code == 0x25) { if (pressed) seq_octave(code == 0x25 ? 1 : -1); return 1; }
    if (code >= 0x3B && code <= 0x3E && t->press) {             /* encoder push: blue green white red */
        if (pressed) t->press(m, code - 0x3B, SHIFT_HELD());
        return 1;
    }
    return t->key && t->key(m, code, pressed, SHIFT_HELD());
}

/* knob_event_hook: knob 0..3; 1 = handled */
int kn_seq_turn(int knob, int delta)
{
    const op1_seq_type_t *t = seq_page();
    if (!t || !t->turn) return 0;
    t->turn(CUR_MODE(), knob, delta, SHIFT_HELD());
    return 1;
}

/* key_event_hook, after the stock dispatch: a sequencer started with REC held presses PLAY like the user would
 * (without Shift: else it is Shift + PLAY); then the screen follows mode / sequencer changes */
void kn_seq_after_key(void)
{
    if (play_pending) {
        play_pending = 0;
        uint8_t sh = SHIFT_BYTE; SHIFT_BYTE = 0;
        KEY_DISPATCH(0x22, 1); KEY_DISPATCH(0x22, 0);
        SHIFT_BYTE = sh;
    }
    kn_seq_sync_screen();
}

void kn_seq_midi_start(void)                                    /* midi_start_hook: every type, active or not */
{
    for (int i = 0; i < n_types; i++) if (types[i]->midi_start) types[i]->midi_start();
}

/* ---- services (op1_feature_seq.h) ----
 * notes go through VoiceCtl key_down / key_up (op1_key_down / op1_key_up: note input observers, then the note pipeline)
 * like the stock sequencers (ok_player). A part stores the absolute pitch taken when its key was pressed
 * (key + 0x35 + octave * 12), so later octave changes do not move it.
 *  synth: record {midi, vel, send midi = 1, 0} -> note_on_synth (uses midi as is).
 *  drums: note_on_drum takes the SOUND from record midi - 0x35 (key 0..23) and the PITCH (semitones) from the
 *         param, to which key_down adds the current drum octave * 12 -> param = pitch - current drum octave * 12. */
int op1_seq_note_on(int mode, int note, int key, int vel)
{
    int midi = mode ? key + 0x35 : note, param = mode ? note - 0x35 - DRUM_OCT() * 12 : 0;
    if (midi < 0 || midi > 127) return -1;
    op1_note n = { midi, vel, 1, { 0 }, 0 };
#ifndef OP1_HOST
    extern volatile int kn_src_force;                  /* kn_midi.c: op1_note_source() = a player for this note */
    int prior_source=kn_src_force; kn_src_force = OP1_SRC_PLAYER;
#endif
    op1_key_down(&n, param);
#ifndef OP1_HOST
    kn_src_force = prior_source;
#endif
    return midi;                                                   /* note-off uses this */
}
void op1_seq_note_off(int id)
{
    op1_note n = { id, 0, 1, { 0 }, 0 };
#ifndef OP1_HOST
    extern volatile int kn_src_force;
    int prior_source=kn_src_force; kn_src_force = OP1_SRC_PLAYER;
#endif
    op1_key_up(&n);
#ifndef OP1_HOST
    kn_src_force = prior_source;
#endif
}
void op1_seq_press_play(void) { play_pending = 1; }
