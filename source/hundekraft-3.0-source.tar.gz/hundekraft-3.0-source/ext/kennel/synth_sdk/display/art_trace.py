#!/usr/bin/env python3
"""Traces a PNG reference (line art on black) into R246's screen SVG subset, as exactly as a raster allows
(docs/screen-art.md, "From a PNG").

    python3 synth_sdk/display/art_trace.py REF.png -o OUT.svg [--colors '#4D9EFF,#FFFFFF'] [--frame X0,Y0,X1,Y1]
                                                 [--report OUT.json]

Steps (all numbers in the PNG's own pixels until the end, then x 320 / frame width):
  frame    the PNG (or --frame, a crop the owner names) is the whole 320 x 160 screen: one uniform scale, no
           offsets picked by hand; a frame that isn't 2:1 is refused (ask how it maps)
  palette  --colors, else measured: the colours at the ink's centre lines (where antialiasing doesn't reach),
           clustered; a colour that is only another one's antialiased edge is dropped; the colours are written as
           measured, not snapped to a stock palette
  masks    each ink pixel goes to the colour it is a 45..100 % strength copy of; a darker colour loses the pixels
           next to a brighter line that are a faint copy of that line's colour (its antialiased edge)
  width    per colour: the antialiased coverage summed across the line (median over points away from ends and
           junctions); twice the distance to the mask's edge when no line is long enough
  lines    per colour: centre lines (Zhang-Suen), split at junctions, thinning spurs dropped (short branches the rest already covers),
           straight continuations joined, free ends moved out to where the colour ends (less the round cap),
           smoothed along the line (Gaussian, 0.35 widths), split at corners; each piece fitted: a circle or a straight line where it is one (residual
           under 0.1 screen px), else least-squares cubic Beziers (Schneider) within 0.15 screen px, flattened
           within 0.05 px
  output   polylines / closed paths / circles per colour, darkest colour first, two decimals, no turn-backs
Needs numpy, scipy (ndimage) and PIL. Import trace() to build a plugin's screen from the result.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image
from scipy import ndimage

sys.path.insert(0, str(Path(__file__).resolve().parent))
from svgart import cubic, f2, shape   # noqa: E402

INK = 40              # max channel above this = ink
STRENGTH = 0.45       # a pixel belongs to colour c when it is a STRENGTH..1 copy of c
MATCH = 45            # and no further than this from that copy (RGB units)
FIT_EPS = 0.15        # Bezier fit tolerance, screen px
PRIM_EPS = 0.1        # circle / line residual, screen px


def hexc(c):
    return '#' + ''.join(f'{int(round(v)):02X}' for v in c)


def rgb(h):
    h = h.lstrip('#')
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)


def load(path, frame=None):
    im = Image.open(path)
    if im.mode in ('RGBA', 'LA', 'P'):
        im = im.convert('RGBA')
        bg = Image.new('RGBA', im.size, (0, 0, 0, 255))
        im = Image.alpha_composite(bg, im)
    a = np.asarray(im.convert('RGB')).astype(float)
    if frame:
        x0, y0, x1, y1 = frame
        a = a[y0:y1, x0:x1]
    h, w = a.shape[:2]
    if abs(w / h - 2) > 0.02:
        raise SystemExit(f'{path}: the frame is {w} x {h}, not 2:1. Ask how it maps onto the 320 x 160 screen '
                         '(give --frame X0,Y0,X1,Y1 for the screen part).')
    return a


# ---- centre lines ----

def thin(img):
    """Zhang-Suen thinning, vectorised"""
    img = np.pad(img.astype(np.uint8), 1)
    while True:
        changed = False
        for step in (0, 1):
            p = img
            P2, P3, P4 = p[:-2, 1:-1], p[:-2, 2:], p[1:-1, 2:]
            P5, P6, P7 = p[2:, 2:], p[2:, 1:-1], p[2:, :-2]
            P8, P9 = p[1:-1, :-2], p[:-2, :-2]
            nb = [P2, P3, P4, P5, P6, P7, P8, P9]
            B = sum(n.astype(int) for n in nb)
            A = sum(((nb[i] == 0) & (nb[(i + 1) % 8] == 1)).astype(int) for i in range(8))
            if step == 0:
                c = (P2 * P4 * P6 == 0) & (P4 * P6 * P8 == 0)
            else:
                c = (P2 * P4 * P8 == 0) & (P2 * P6 * P8 == 0)
            rm = (p[1:-1, 1:-1] == 1) & (B >= 2) & (B <= 6) & (A == 1) & c
            if rm.any():
                img[1:-1, 1:-1][rm] = 0
                changed = True
        if not changed:
            return img[1:-1, 1:-1].astype(bool)


NB = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


def chains(sk):
    """skeleton -> (paths [[(x, y)...]], set of junction pixels as (x, y)); paths split at junctions"""
    pix = set(zip(*np.nonzero(sk)))

    def linked(q, dy, dx):   # m-connectivity: a diagonal step only where no orthogonal pixel already links the two
        if (q[0] + dy, q[1] + dx) not in pix:
            return False
        return not (dy and dx and ((q[0] + dy, q[1]) in pix or (q[0], q[1] + dx) in pix))
    nbrs = {q: [(q[0] + dy, q[1] + dx) for dy, dx in NB if linked(q, dy, dx)] for q in pix}
    nodes = {q for q, n in nbrs.items() if len(n) != 2}
    seen, out = set(), []

    def walk(a, b):
        path = [a, b]
        seen.add(frozenset((a, b)))
        while path[-1] not in nodes:
            nxt = [n for n in nbrs[path[-1]] if n != path[-2] and frozenset((path[-1], n)) not in seen]
            if not nxt:
                break
            seen.add(frozenset((path[-1], nxt[0])))
            path.append(nxt[0])
        return path

    for a in sorted(nodes):
        for b in nbrs[a]:
            if frozenset((a, b)) not in seen:
                out.append(walk(a, b))
    for a in sorted(pix):                 # loops without nodes
        for b in nbrs[a]:
            if frozenset((a, b)) not in seen:
                out.append(walk(a, b))
    junctions = {(x, y) for y, x in nodes if len(nbrs[(y, x)]) > 2}
    return [[(x, y) for y, x in c] for c in out], junctions


def length(c):
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(c, c[1:]))


def prune(cs, junctions, mask, wpx):
    """drop thinning spurs: a piece under 2 stroke widths from a junction to a free end whose pixels the rest of the
    line already covers (every mask pixel near its free end lies within half a width of the other centre lines).
    A short line of the art's own (a small plus, a tick) covers pixels nothing else does and stays."""
    cand = [i for i, c in enumerate(cs) if length(c) < 2 * wpx
            and ((tuple(c[0]) in junctions) != (tuple(c[-1]) in junctions))]
    if not cand:
        return cs
    rest = np.zeros(mask.shape, bool)
    for i, c in enumerate(cs):
        if i not in cand:
            for x, y in c:
                rest[y, x] = True
    for i in cand:                                   # their junction pixels belong to the rest too
        c = cs[i]
        x, y = c[0] if tuple(c[0]) in junctions else c[-1]
        rest[y, x] = True
    dist = ndimage.distance_transform_edt(~rest)
    ys, xs = np.nonzero(mask)
    r, out = wpx / 2 + 1.5, []
    for i, c in enumerate(cs):
        if i in cand:
            fx, fy = c[-1] if tuple(c[0]) in junctions else c[0]
            near = (xs - fx) ** 2 + (ys - fy) ** 2 <= r * r
            if near.any() and dist[ys[near], xs[near]].max() <= wpx / 2 + 1.5:
                continue
        out.append(c)
    return out


def merge(cs, tol=1.5, w=4):
    """join pieces whose ends meet in a nearly straight line (thinning splits lines at every junction); the
    direction is taken over w pixels, so the junction's own kink doesn't decide"""
    cs = [list(c) for c in cs if len(c) > 1]

    def end_dir(c):
        k = min(len(c) - 1, w)
        return (c[-1][0] - c[-1 - k][0], c[-1][1] - c[-1 - k][1])
    while True:
        best = None
        for i in range(len(cs)):
            for j in range(i + 1, len(cs)):
                for ci in (cs[i], cs[i][::-1]):
                    for cj in (cs[j], cs[j][::-1]):
                        if math.hypot(ci[-1][0] - cj[0][0], ci[-1][1] - cj[0][1]) > tol:
                            continue
                        v1, v2 = end_dir(ci), end_dir(cj[::-1])
                        v2 = (-v2[0], -v2[1])
                        cos = (v1[0] * v2[0] + v1[1] * v2[1]) / ((math.hypot(*v1) or 1) * (math.hypot(*v2) or 1))
                        if cos > 0.7 and (best is None or cos > best[0]):
                            best = (cos, i, j, ci + cj[1:])
        if best is None:
            return cs
        _, i, j, c = best
        cs = [x for k, x in enumerate(cs) if k not in (i, j)] + [c]


def corners(P, w, angle=60):
    """indices where the direction over w points turns by more than angle degrees (local maxima)"""
    n = len(P)
    if n < 2 * w + 3:
        return []
    a = np.zeros(n)
    for i in range(w, n - w):
        u, v = P[i] - P[i - w], P[i + w] - P[i]
        c = np.dot(u, v) / ((np.linalg.norm(u) * np.linalg.norm(v)) or 1)
        a[i] = math.degrees(math.acos(max(-1, min(1, c))))
    out = []
    for i in range(w, n - w):
        if a[i] > angle and a[i] == a[max(0, i - w):i + w + 1].max() and (not out or i - out[-1] > w):
            out.append(i)
    return out


# ---- fitting ----

def smooth(P, sigma, closed):
    """Gaussian along the line (sigma in points), ends kept: takes out the pixel staircase"""
    if sigma < 0.5 or len(P) < 5:
        return P
    mode = 'wrap' if closed else 'nearest'
    Q = np.c_[ndimage.gaussian_filter1d(P[:, 0], sigma, mode=mode), ndimage.gaussian_filter1d(P[:, 1], sigma, mode=mode)]
    if not closed:
        n = min(len(P) // 2, int(math.ceil(2 * sigma)))
        for i in range(n):                 # blend back to the true ends (smoothing pulls them inwards)
            t = i / n
            Q[i] = P[i] * (1 - t) + Q[i] * t
            Q[-1 - i] = P[-1 - i] * (1 - t) + Q[-1 - i] * t
    return Q


def bez(p, t):
    t = t[:, None]
    return ((1 - t) ** 3) * p[0] + 3 * ((1 - t) ** 2) * t * p[1] + 3 * (1 - t) * t * t * p[2] + t ** 3 * p[3]


def unit(v):
    n = np.linalg.norm(v)
    return v / n if n else v


def fit_bezier(P, t1, t2, eps, depth=0):
    """Schneider: least-squares cubic Beziers through P (N x 2) with end tangents t1, t2 -> [4 x 2 control arrays]"""
    n = len(P)
    if n == 2:
        d = np.linalg.norm(P[1] - P[0]) / 3
        return [np.array([P[0], P[0] + t1 * d, P[1] + t2 * d, P[1]])]
    u = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))])
    u = u / u[-1] if u[-1] else np.linspace(0, 1, n)
    for _ in range(4):
        b = gen(P, u, t1, t2)
        err = np.linalg.norm(bez(b, u) - P, axis=1)
        if err.max() <= eps:
            return [b]
        u = reparam(b, P, u)
    b = gen(P, u, t1, t2)
    err = np.linalg.norm(bez(b, u) - P, axis=1)
    if err.max() <= eps or depth > 12 or n < 4:
        return [b]
    i = int(np.clip(np.argmax(err), 1, n - 2))
    tc = unit(P[i - 1] - P[i + 1])
    return fit_bezier(P[:i + 1], t1, tc, eps, depth + 1) + fit_bezier(P[i:], -tc, t2, eps, depth + 1)


def gen(P, u, t1, t2):
    p0, p3 = P[0], P[-1]
    b1, b2 = 3 * (1 - u) ** 2 * u, 3 * (1 - u) * u ** 2
    A1, A2 = b1[:, None] * t1, b2[:, None] * t2
    tmp = P - bez(np.array([p0, p0, p3, p3]), u)
    C = np.array([[np.sum(A1 * A1), np.sum(A1 * A2)], [np.sum(A1 * A2), np.sum(A2 * A2)]])
    X = np.array([np.sum(A1 * tmp), np.sum(A2 * tmp)])
    det = C[0, 0] * C[1, 1] - C[0, 1] ** 2
    seg = np.linalg.norm(p3 - p0)
    if abs(det) < 1e-12:
        a1 = a2 = seg / 3
    else:
        a1 = (X[0] * C[1, 1] - X[1] * C[0, 1]) / det
        a2 = (C[0, 0] * X[1] - C[0, 1] * X[0]) / det
    if a1 < 1e-6 * seg or a2 < 1e-6 * seg:
        a1 = a2 = seg / 3
    return np.array([p0, p0 + t1 * a1, p3 + t2 * a2, p3])


def reparam(b, P, u):
    """one Newton step per point towards the curve's closest parameter"""
    d1 = 3 * np.diff(b, axis=0)
    d2 = 2 * np.diff(d1, axis=0)
    t = u[:, None]
    q = bez(b, u)
    q1 = (1 - t) ** 2 * d1[0] + 2 * (1 - t) * t * d1[1] + t * t * d1[2]
    q2 = (1 - t) * d2[0] + t * d2[1]
    num = np.sum((q - P) * q1, axis=1)
    den = np.sum(q1 * q1, axis=1) + np.sum((q - P) * q2, axis=1)
    out = u - np.where(np.abs(den) > 1e-12, num / np.where(den == 0, 1, den), 0)
    out = np.clip(out, 0, 1)
    out[0], out[-1] = 0, 1
    return np.maximum.accumulate(out)


def circle_fit(P):
    """Kasa fit -> (cx, cy, r, rms residual)"""
    x, y = P[:, 0], P[:, 1]
    A = np.c_[2 * x, 2 * y, np.ones(len(P))]
    c, *_ = np.linalg.lstsq(A, x * x + y * y, rcond=None)
    r = math.sqrt(max(c[2] + c[0] ** 2 + c[1] ** 2, 0))
    res = np.hypot(x - c[0], y - c[1]) - r
    return c[0], c[1], r, float(np.sqrt(np.mean(res ** 2))), float(np.abs(res).max())


def line_fit(P):
    """-> (end a, end b, max residual)"""
    m = P.mean(0)
    _, _, vt = np.linalg.svd(P - m)
    d = vt[0]
    s = np.einsum('ij,j->i', P - m, d)
    res = np.abs(np.einsum('ij,j->i', P - m, np.array([-d[1], d[0]])))
    return m + d * s.min(), m + d * s.max(), float(res.max())


def tangent(P, k):
    return unit(P[min(k, len(P) - 1)] - P[0])


def fit_piece(P, closed, k, w):
    """P in PNG px -> ('circle', cx, cy, r) | ('poly', points, closed); k = screen px per PNG px"""
    if closed and len(P) >= 8:
        cx, cy, r, rms, mx = circle_fit(P)
        if mx * k < PRIM_EPS * 2.5 and rms * k < PRIM_EPS and r * k < 40:
            return ('circle', cx, cy, r)
    if not closed and len(P) >= 2:
        a, b, mx = line_fit(P)
        if mx * k < PRIM_EPS:
            return ('poly', [a, b], False)
    eps = max(FIT_EPS / k, 0.6)
    tk = max(2, int(round(w)))
    if closed:
        P = np.vstack([P, P[:1]])
        t = unit(P[1:tk + 1].mean(0) - P[-tk - 1:-1].mean(0)) if len(P) > 2 * tk + 2 else tangent(P, tk)
        bs = fit_bezier(P, t, -t, eps)
    else:
        bs = fit_bezier(P, tangent(P, tk), tangent(P[::-1], tk), eps)
    pts = [tuple(bs[0][0])]
    for b in bs:
        pts += cubic(*[tuple(p) for p in b], tol=0.05 / k)
    if closed:
        pts = pts[:-1]
    return ('poly', [np.array(p) for p in pts], closed)


# ---- colours and masks ----

def palette(a, ink):
    """colours at the ink's centre lines, clustered greedily (within 14 % of the colour's brightness, at least 10)"""
    sk = thin(ink)
    c = a[sk]
    cores = len(c)
    out = []
    while len(c):
        q = (c // 16).astype(int)
        keys, counts = np.unique(q[:, 0] * 256 + q[:, 1] * 16 + q[:, 2], return_counts=True)
        k = keys[np.argmax(counts)]
        m = c[(q[:, 0] * 256 + q[:, 1] * 16 + q[:, 2]) == k].mean(0)
        for _ in range(3):
            near = np.linalg.norm(c - m, axis=1) < max(10, 0.14 * np.linalg.norm(m))
            m = c[near].mean(0)
        if near.sum() < max(30, 0.003 * cores):
            break
        out.append(m)
        c = c[~near]
    return out


def masks(a, ink, pal):
    x = a[ink]
    best, bd = np.full(len(x), -1), np.full(len(x), 1e9)
    for i, p in enumerate(pal):
        al = np.clip(np.einsum('ij,j->i', x, p) / np.dot(p, p), STRENGTH, 1.0)
        d = np.linalg.norm(x - al[:, None] * p, axis=1)
        sel = d < bd
        best[sel], bd[sel] = i, d[sel]
    best[bd > MATCH] = -1
    out = []
    for i in range(len(pal)):
        m = np.zeros(ink.shape, bool)
        m[ink] = best == i
        out.append(m)
    # a darker colour's pixels next to a brighter colour's line that are a faint copy of that colour (residual
    # under 20) are the brighter line's antialiased edge, not a line of their own
    for i, p in enumerate(pal):
        near = ndimage.binary_dilation(out[i], iterations=2)
        al = np.clip(np.einsum('ijk,k->ij', a, p) / np.dot(p, p), 0, 1)
        faint = np.linalg.norm(a - al[..., None] * p, axis=2) < 20
        for j, q in enumerate(pal):
            if i != j and np.linalg.norm(q) < np.linalg.norm(p):
                out[j] &= ~(near & faint)
    return out


def parallel(p, q):
    return np.dot(p, q) / ((np.linalg.norm(p) * np.linalg.norm(q)) or 1) > 0.99


def drop_edges(a, ink, pal):
    """palette colours that are a 50..95 % copy of a brighter one, or a 35..50 % copy lying mostly (over half their
    pixels) within 2 px of it, are that colour's antialiased edge: a thin line's centre doesn't reach full strength
    at small sizes. A real colour in that band must be given with --colors."""
    while True:
        ms = masks(a, ink, pal)
        drop = None
        for j, q in enumerate(pal):
            for i, p in enumerate(pal):
                r = np.linalg.norm(q) / np.linalg.norm(p)
                if i != j and parallel(p, q) and 0.35 <= r <= 0.95:
                    near = ndimage.binary_dilation(ms[i], iterations=2)
                    if r >= 0.5 or not ms[j].any() or (ms[j] & near).sum() > 0.5 * ms[j].sum():
                        drop = j
        if drop is None:
            return pal, ms
        pal = [p for j, p in enumerate(pal) if j != drop]


def widths(al, cs, w0):
    """stroke width from the antialiased coverage: across the line at points away from ends and junctions, the
    colour's strength (0..1) summed over the central run; median, PNG px"""
    out = []
    step, half = 0.25, 1.6 * w0
    ts = np.arange(-half, half + step / 2, step)
    for c in cs:
        P = np.array(c, float)
        if length(c) < 4 * w0:
            continue
        e = int(math.ceil(w0)) + 2
        for i in range(e, len(P) - e, 3):
            t = unit(P[min(i + 2, len(P) - 1)] - P[max(i - 2, 0)])
            nrm = np.array([-t[1], t[0]])
            q = P[i][None, :] + ts[:, None] * nrm[None, :]
            v = ndimage.map_coordinates(al, [q[:, 1], q[:, 0]], order=1, mode='constant')
            mid = len(v) // 2
            lo, hi = mid, mid
            while lo > 0 and v[lo - 1] > 0.02 and v[lo - 1] <= v[lo] + 0.05:
                lo -= 1
            while hi < len(v) - 1 and v[hi + 1] > 0.02 and v[hi + 1] <= v[hi] + 0.05:
                hi += 1
            if lo > 0 and hi < len(v) - 1:               # the run ended inside the window: a clean profile
                out.append(v[lo:hi + 1].sum() * step)
    return float(np.median(out)) if out else None


def strength(a, p, m):
    """how much of colour p each pixel holds (0..1), only around p's own mask"""
    al = np.clip(np.einsum('ijk,k->ij', a, p) / np.dot(p, p), 0, 1)
    al[~ndimage.binary_dilation(m, iterations=3)] = 0
    return al


def extend(P, al, wpx, free0, free1):
    """thinning stops short of a line's end: move each free end out along the line to where the colour drops under
    half strength, less half a stroke width (the round cap drawn there covers the rest)"""
    P = list(P)
    for at_start, free in ((True, free0), (False, free1)):
        if not free or len(P) < 3:
            continue
        k = min(len(P) - 1, max(2, int(round(wpx))))
        e, b = (P[0], P[k]) if at_start else (P[-1], P[-1 - k])
        t = unit(np.array(e) - np.array(b))
        d = 0.0
        while d < 2 * wpx:
            q = np.array(e) + t * (d + 0.25)
            if ndimage.map_coordinates(al, [[q[1] - 0.5], [q[0] - 0.5]], order=1)[0] < 0.5:
                break
            d += 0.25
        ext = d - wpx / 2
        if ext > 0.25:
            q = np.array(e) + t * ext
            if at_start:
                P.insert(0, q)
            else:
                P.append(q)
    return np.array(P, float)


def trace(path, colors=None, frame=None):
    """-> {'size', 'scale', 'palette': [{color, width, pixels}], 'strokes': [(color, width, piece)]} in screen px"""
    a = load(path, frame)
    h, w = a.shape[:2]
    k = 320 / w
    ink = a.max(2) > INK
    if colors:
        pal = [rgb(c) for c in colors]
        ms = masks(a, ink, pal)
    else:
        pal, ms = drop_edges(a, ink, palette(a, ink))
    order = sorted(range(len(pal)), key=lambda i: float(np.dot(pal[i], [0.2126, 0.7152, 0.0722])))
    report = {'size': [w, h], 'scale': k, 'palette': [], 'strokes': []}
    for i in order:
        m = ms[i]
        lab, n = ndimage.label(m, np.ones((3, 3)))
        sizes = ndimage.sum(m, lab, range(1, n + 1))
        sk = thin(m)
        if not sk.any():
            continue
        dist = ndimage.distance_transform_edt(m)
        wpx = max(2 * float(np.median(dist[sk])) - 0.5, 1.0)
        small = max(4.0, wpx * wpx)
        keep = np.isin(lab, 1 + np.nonzero(sizes >= small)[0])
        sk &= keep
        cs, junctions = chains(sk)
        al = strength(a, pal[i], m)
        wa = widths(al, cs, wpx)
        if wa:
            wpx = wa
        width = round(round(wpx * k / 0.05) * 0.05, 2)
        color = hexc(pal[i])
        report['palette'].append({'color': color, 'width': width, 'pixels': int(m.sum())})
        cs = prune(cs, junctions, m, wpx)
        cs = merge(cs, 1.5, max(3, int(round(wpx))))
        for c in cs:
            if length(c) < 2.0:
                continue
            P = np.array(c, float) + 0.5          # pixel centres
            closed = len(c) > 4 * wpx and math.hypot(*(P[0] - P[-1])) <= 1.5
            if closed:
                P = P[:-1] if np.allclose(P[0], P[-1]) else P
            else:
                P = extend(P, al, wpx, tuple(c[0]) not in junctions, tuple(c[-1]) not in junctions)
            P = smooth(P, 0.35 * wpx, closed)
            cut = [] if closed else corners(P, max(3, int(round(wpx))))
            for a0, a1 in zip([0] + cut, cut + [len(P) - 1]):
                piece = fit_piece(P[a0:a1 + 1], closed and not cut, k, wpx)
                report['strokes'].append((color, width, scale_piece(piece, k)))
    return report


def scale_piece(piece, k):
    if piece[0] == 'circle':
        return ('circle', piece[1] * k, piece[2] * k, piece[3] * k)
    return ('poly', [(float(x) * k, float(y) * k) for x, y in piece[1]], piece[2])


def write(strokes):
    out = []
    for color, width, piece in strokes:
        if piece[0] == 'circle':
            _, cx, cy, r = piece
            out.append(f'<circle cx="{f2(cx)}" cy="{f2(cy)}" r="{f2(r)}" fill="none" stroke="{color}" '
                       f'stroke-width="{f2(width)}"/>')
        else:
            pts, closed = piece[1], piece[2]
            if len(pts) >= 2:
                out.append(shape(pts, color, width, closed))
    return out


def svg(strokes):
    return ('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="320px" height="160px" viewBox="0 0 320 160">\n'
            + '\n'.join(write(strokes)) + '\n</svg>\n')


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('png', type=Path)
    ap.add_argument('-o', '--output', type=Path, required=True)
    ap.add_argument('--colors', help='comma-separated #RRGGBB, else measured')
    ap.add_argument('--frame', help='X0,Y0,X1,Y1: the screen part of the PNG')
    ap.add_argument('--report', type=Path)
    a = ap.parse_args()
    r = trace(a.png, a.colors.split(',') if a.colors else None,
              [int(v) for v in a.frame.split(',')] if a.frame else None)
    a.output.write_text(svg(r['strokes']))
    kinds = {}
    for _, _, p in r['strokes']:
        kinds[p[0]] = kinds.get(p[0], 0) + 1
    print(f"{a.output}: {r['size'][0]} x {r['size'][1]} px, x {r['scale']:.4f}; "
          + ', '.join(f"{p['color']} {p['width']} px" for p in r['palette']) + f'; {kinds}')
    if a.report:
        a.report.write_text(json.dumps({k: v for k, v in r.items() if k != 'strokes'}, indent=1))
