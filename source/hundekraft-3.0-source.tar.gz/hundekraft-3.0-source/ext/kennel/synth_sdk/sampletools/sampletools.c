/*
 * Sampler tools on TE's sampler screens (synth with a sampler sound, drum with a sampler kit), a feature on the core's
 * sampler services (op1_feature_sampler.h). Our own code: the behaviour follows Maiko's #250 guide pages (fit, zoom,
 * pitch); none of his code.
 *   zoom   white press zooms 2x .. 32x around the marker moved last, Shift + white zooms out (back to TE's view).
 *          Markers off the view show as arrows at its edges; a bracket under the overview strip marks the view.
 *          Resets when the slot, sound or drum key changes. Synth: blue held + turned moves the start ~8 samples
 *          per step.
 *   pitch  synth: the note of the used part (start..end) with a -50..+50 cent tuner, green within 3 cents (middle C
 *          is c3). Shift + green sets the sound's base frequency to that note (its key then plays the sample at its
 *          own speed; the name turns green); Shift + green again puts the old one back.
 *   fit    orange opens the fit panel: blue 1 / 2 / 4 / 8 bars, green keep pitch / tape, orange again fits the used
 *          part (synth start..end, drum: earliest start .. latest end of the 24 keys) to that many bars at the OP-1
 *          tempo, at the start of the buffer. Lengths that don't fit the buffer aren't offered. Refused while the
 *          slot samples, the tape records, or for parts under 0.05 s. Changes the slot's sound only (TE's reload,
 *          Shift + synth / drum, brings back the saved one). Any other key closes the panel and acts as usual.
 * Work runs on the main loop in chunks (op1_sampler_job); the waveform columns are cached per view.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_synth.h"
#include "../op1_feature_sampler.h"
#include "../screens/stroke_font.h"
#include "st_pitch.h"
#include "st_fit.h"
#include "st_notes.h"

/* ---- layout (raster px; measured on the stock screens, run/kennel-sampler in OP1-Emulator) ---- */
#define WX0 16                      /* waveform x range */
#define WX1 306
#define COLS ((WX1 - WX0) / 2)      /* one column every 2 px */
#define BASE_Y 133                  /* waveform baseline */
#define AMP 78                      /* full scale height */
#define TOP_Y 55                    /* synth loop dots */
#define COVER_Y0 36                 /* area we repaint while zoomed or with the panel open */
#define COVER_Y1 146
#define STRIP_Y 30                  /* the view bracket under the overview strip */
#define TEXT_Y 147                  /* bottom line: zoom level, note, tuner */
#define ST_FINE 8                   /* fine start: samples per step */
#define ST_SPC_MIN 2                /* zoom stops at about 2 samples per column */

enum { K_BLUE = 0x3B, K_GREEN = 0x3C, K_WHITE = 0x3D, K_ORANGE = 0x3E };
static const uint8_t c_white[4] = {0xff, 0xff, 0xff, 255}, c_grey[4] = {0x7c, 0x79, 0x90, 255},
    c_dark[4] = {0x38, 0x35, 0x72, 255}, c_black[4] = {0x00, 0x00, 0x00, 255}, c_green[4] = {0x00, 0xed, 0x95, 255},
    c_red[4] = {0xff, 0x3a, 0x5d, 255}, c_synth[4] = {0x6b, 0x8e, 0xff, 255}, c_orange[4] = {0xff, 0x8c, 0x1a, 255},
    c_drum[4] = {0x00, 0xef, 0x94, 255};
static const int32_t ident[9] = {1024, 0, 0, 0, 1024, 0, 0, 0, 1024};
static const uint8_t bars_of[4] = {1, 2, 4, 8};

typedef struct {
    uint32_t gen;                   /* the sound this state belongs to */
    uint8_t zsh;                    /* zoom 1 << zsh (0 = TE's view) */
    int8_t follow;                  /* marker followed by the zoom (OP1_SM_*) */
    uint8_t blue_down, swallow[4];  /* blue held; releases of presses we took (blue, green, white, orange) */
    int32_t acc;                    /* fine start: delta accumulator */
    int32_t v0, vlen;               /* the view drawn last (samples) */
    /* columns */
    int32_t c_v0, c_len; uint32_t c_gen; uint8_t c_ok;
    int16_t col[COLS];
    /* pitch */
    st_pitch_work pw;
    uint8_t p_run, p_ok;            /* analysis running, result valid for (p_gen, p_a, p_b) */
    uint32_t p_gen; int32_t p_a, p_b;
    st_pitch_result pr;
    uint8_t rt_on; uint32_t rt_old[2], rt_gen;   /* retune: the base_freq before it */
    /* fit */
    uint8_t panel, bars_i, mode, fitting;
    int32_t f_a, f_b, f_beat;       /* range and beat length (samples) of the panel */
    uint8_t f_kind;
    int32_t f_keys[24][2];          /* drum keys' start / end before the fit */
    int32_t f_loop[2];              /* synth loop points before */
    st_fit_work fw;
} st_state;
static st_state *S;

/* ---- text ---- */
enum { T_ZOOM, T_NOTE, T_NOTE_G, T_BARS, T_BPM, T_KEEP, T_KEEP_G, T_TAPE, T_TAPE_G, T_FIT, T_FULL, T_N = T_FULL + 4 };   /* _G: dimmed / green twin */
static uint32_t txt[T_N][OP1_TEXT_SIZE / 4];
static char shown[T_N][16];
static uint8_t made;
static int same(const char *a, const char *b) { while (*a && *a == *b) a++, b++; return *a == *b; }
static void tx(int i, const char *s, void *r)                   /* set only on change: op1_text_set reallocates */
{
    if (!same(shown[i], s)) {
        int k = 0;
        for (; s[k] && k < 15; k++) shown[i][k] = s[k];
        shown[i][k] = 0;
        op1_text_set(txt[i], shown[i]);
    }
    op1_text_draw(txt[i], r, ident);
}
static char *put(char *o, const char *s) { while (*s) *o++ = *s++; *o = 0; return o; }
static char *num(char *o, int32_t v)
{
    char d[12]; int k = 0;
    if (v < 0) { *o++ = '-'; v = -v; }
    do d[k++] = (char)('0' + v % 10); while (v /= 10);
    while (k) *o++ = d[--k];
    *o = 0;
    return o;
}
static void texts(void)
{
    if (made) return;
    op1_text_ctor(txt[T_ZOOM], OP1_Q10(WX0 + 16), TEXT_Y, 12, c_white);
    op1_text_ctor(txt[T_NOTE], OP1_Q10(150), TEXT_Y, 12, c_white);
    op1_text_ctor(txt[T_NOTE_G], OP1_Q10(150), TEXT_Y, 12, c_green);
    op1_text_ctor(txt[T_BARS], OP1_Q10(24), 52, 16, c_white);
    op1_text_ctor(txt[T_BPM], OP1_Q10(240), 52, 12, c_grey);
    op1_text_ctor(txt[T_KEEP], OP1_Q10(24), 112, 12, c_green);
    op1_text_ctor(txt[T_KEEP_G], OP1_Q10(24), 112, 12, c_dark);
    op1_text_ctor(txt[T_TAPE], OP1_Q10(120), 112, 12, c_green);
    op1_text_ctor(txt[T_TAPE_G], OP1_Q10(120), 112, 12, c_dark);
    op1_text_ctor(txt[T_FIT], OP1_Q10(250), 112, 12, c_orange);
    for (int i = 0; i < 4; i++) op1_text_ctor(txt[T_FULL + i], OP1_Q10(24 + i * 70 + 12), 77, 12, c_grey);   /* "full" per cell */
    made = 1;
}

/* ---- drawing helpers (px) ---- */
static void ln(void *r, int x0, int y0, int x1, int y1, int w, const uint8_t *c) { sf_line(r, x0 << 10, y0 << 10, x1 << 10, y1 << 10, w, c); }
static void fill(void *r, int x0, int y0, int x1, int y1, const uint8_t *c)
{
    sf_line(r, x0 << 10, ((y0 + y1) << 10) / 2, x1 << 10, ((y0 + y1) << 10) / 2, (y1 - y0) << 10, c);
}
static void ring_w(void *r, int cx, int cy, int rad_q10, int w, const uint8_t *c);
static void dot(void *r, int x, int y, int rad, const uint8_t *c) { ring_w(r, x, y, rad << 9, rad << 10, c); }   /* filled: a ring at half the radius */
static void arrow(void *r, int x, int y, int dir, const uint8_t *c)    /* dir -1 left edge, +1 right edge */
{
    ln(r, x, y, x - 5 * dir, y - 4, 0x600, c);
    ln(r, x, y, x - 5 * dir, y + 4, 0x600, c);
}

/* a ring (16-gon), as TE rings the marker its knob moves */
static const int16_t ring_x[17] = {1024, 946, 724, 392, 0, -392, -724, -946, -1024, -946, -724, -392, 0, 392, 724, 946, 1024};
static void ring_w(void *r, int cx, int cy, int rad_q10, int w, const uint8_t *c)   /* centre px, radius Q10 */
{
    for (int i = 0; i < 16; i++) {
        int j = (i + 4) % 16, k = (i + 5) % 16;
        sf_line(r, (cx << 10) + (ring_x[i] * rad_q10 >> 10), (cy << 10) + (ring_x[j] * rad_q10 >> 10),
                (cx << 10) + (ring_x[i + 1] * rad_q10 >> 10), (cy << 10) + (ring_x[k] * rad_q10 >> 10), w, c);
    }
}
static void ring(void *r, int cx, int cy, int rad, const uint8_t *c) { ring_w(r, cx, cy, rad << 10, 0x400, c); }

/* ---- markers ---- */
static int n_markers(const op1_sampler_t *s) { return s->kind == OP1_SAMPLER_SYNTH ? 4 : 2; }
static int marker_id(const op1_sampler_t *s, int i) { return s->kind == OP1_SAMPLER_SYNTH ? i : (i ? OP1_SM_END : OP1_SM_START); }
static const uint8_t *marker_col(const op1_sampler_t *s, int m)
{
    if (s->kind == OP1_SAMPLER_DRUM) return m == OP1_SM_START ? c_green : c_white;
    return m == OP1_SM_START ? c_synth : m == OP1_SM_LOOP_A ? c_green : m == OP1_SM_LOOP_B ? c_white : c_red;
}
/* which marker a knob turn moves on the stock screen (observed, never taken) */
static int knob_marker(const op1_sampler_t *s, int knob)
{
    if (s->kind == OP1_SAMPLER_SYNTH) return knob;                  /* blue start, green / white loop, red end */
    return knob == 1 ? OP1_SM_START : knob == 2 ? OP1_SM_END : -1;   /* drum: green start, white end */
}

static void reset_for(const op1_sampler_t *s)
{
    if (S->gen == s->gen) return;
    S->gen = s->gen;
    S->zsh = 0; S->follow = OP1_SM_START; S->c_ok = 0;
    S->panel = 0;
    if (S->rt_gen != s->gen) S->rt_on = 0;
}

/* ---- the zoomed view ---- */
static void view_of(const op1_sampler_t *s, int32_t *v0, int32_t *vlen)
{
    int32_t a = op1_sampler_marker(OP1_SM_START, -1), b = op1_sampler_marker(OP1_SM_END, -1);
    if (b <= a) b = a + 1;
    int32_t len = (b - a) >> S->zsh, m = op1_sampler_marker(S->follow, -1);
    if (len < COLS * ST_SPC_MIN) len = COLS * ST_SPC_MIN;
    if (len > s->cap) len = s->cap;
    int32_t x = m - len / 2;
    if (x < 0) x = 0;
    if (x + len > s->cap) x = s->cap - len;
    *v0 = x; *vlen = len;
}
static void columns(const op1_sampler_t *s, int32_t v0, int32_t vlen)
{
    if (S->c_ok && S->c_v0 == v0 && S->c_len == vlen && S->c_gen == s->gen) return;
    for (int c = 0; c < COLS; c++) {                                /* positive peak per column, as TE's overview */
        int32_t p0 = v0 + (int32_t)((int64_t)vlen * c / COLS), p1 = v0 + (int32_t)((int64_t)vlen * (c + 1) / COLS);
        int32_t step = (p1 - p0) >> 6, pk = 0;                     /* at most ~64 reads per column */
        if (step < 1) step = 1;
        for (int32_t i = p0; i < p1; i += step) if (s->data[i] > pk) pk = s->data[i];
        S->col[c] = (int16_t)pk;
    }
    S->c_v0 = v0; S->c_len = vlen; S->c_gen = s->gen; S->c_ok = 1;
}
static int32_t x_of(int32_t pos, int32_t v0, int32_t vlen) { return WX0 + (int32_t)((int64_t)(pos - v0) * (WX1 - WX0) / vlen); }

static void draw_zoom(void *r, const op1_sampler_t *s)
{
    int32_t v0, vlen;
    view_of(s, &v0, &vlen);
    S->v0 = v0; S->vlen = vlen;
    columns(s, v0, vlen);
    fill(r, 4, COVER_Y0, 316, COVER_Y1, c_black);
    const uint8_t *wc = s->kind == OP1_SAMPLER_SYNTH ? c_synth : c_drum;
    int32_t px = WX0, py = BASE_Y - (S->col[0] * AMP >> 15);
    for (int c = 1; c < COLS; c++) {
        int32_t x = WX0 + 2 * c, y = BASE_Y - (S->col[c] * AMP >> 15);
        ln(r, px, py, x, y, 0x600, wc);
        px = x; py = y;
    }
    for (int i = 0; i < n_markers(s); i++) {
        int m = marker_id(s, i);
        int32_t pos = op1_sampler_marker(m, -1), x = x_of(pos, v0, vlen);
        int y = s->kind == OP1_SAMPLER_SYNTH && (m == OP1_SM_LOOP_A || m == OP1_SM_LOOP_B) ? TOP_Y : BASE_Y;
        const uint8_t *c = marker_col(s, m);
        if (x < WX0) arrow(r, 8, y, -1, c);
        else if (x > WX1) arrow(r, 312, y, 1, c);
        else {
            if (m == S->follow) ln(r, x, COVER_Y0 + 4, x, BASE_Y, 0x400, c_dark);
            dot(r, x, y, 3, c);
            if (m == OP1_SM_START && S->blue_down) ring(r, x, y, 7, c);   /* fine start: the start ringed */
        }
    }
    /* the bracket: where the view is in the whole buffer (synth overview strip x 16..306; drum: same span) */
    int32_t b0 = WX0 + (int32_t)((int64_t)v0 * (WX1 - WX0) / s->cap), b1 = WX0 + (int32_t)((int64_t)(v0 + vlen) * (WX1 - WX0) / s->cap);
    if (b1 < b0 + 2) b1 = b0 + 2;
    ln(r, b0, STRIP_Y, b1, STRIP_Y, 0x400, c_white);
    ln(r, b0, STRIP_Y - 3, b0, STRIP_Y, 0x400, c_white);
    ln(r, b1, STRIP_Y - 3, b1, STRIP_Y, 0x400, c_white);
    /* magnifier and level */
    sf_line(r, OP1_Q10(WX0 + 4), OP1_Q10(TEXT_Y + 5), OP1_Q10(WX0 + 4) + 1, OP1_Q10(TEXT_Y + 5), 7 << 10, c_white);
    sf_line(r, OP1_Q10(WX0 + 4), OP1_Q10(TEXT_Y + 5), OP1_Q10(WX0 + 4) + 1, OP1_Q10(TEXT_Y + 5), 4 << 10, c_black);
    ln(r, WX0 + 7, TEXT_Y + 8, WX0 + 10, TEXT_Y + 11, 0x600, c_white);
    if (!S->zsh) return;                                          /* fine start at TE's zoom: no level */
    char t[16], *o = num(t, 1 << S->zsh); put(o, "x");
    tx(T_ZOOM, t, r);
}

/* ---- pitch (synth) ---- */
static int pitch_step(void *ctx)
{
    (void)ctx;
    if (st_pitch_step(&S->pw, 24)) return 1;
    st_pitch_result_get(&S->pw, &S->pr);
    S->p_ok = 1; S->p_run = 0;
    return 0;
}
static void pitch_poll(const op1_sampler_t *s)                    /* Gfx thread: start an analysis when needed */
{
    int32_t a = op1_sampler_marker(OP1_SM_START, -1), b = op1_sampler_marker(OP1_SM_END, -1);
    if (S->p_run || S->fitting || (S->p_ok && S->p_gen == s->gen && S->p_a == a && S->p_b == b)) return;
    if (op1_sampler_job_running()) return;
    S->p_ok = 0; S->p_gen = s->gen; S->p_a = a; S->p_b = b;
    /* the loudest of 16 windows in the used part (a sound often ends in silence before its end marker) */
    int32_t w0 = a, best = -1, span = b - a - ST_PITCH_N;
    if (span > 0)
        for (int k = 0; k < 16; k++) {
            int32_t x = a + (int32_t)((int64_t)span * k / 15), e = 0;
            for (int32_t i = x; i < x + ST_PITCH_N; i += 8) e += s->data[i] < 0 ? -s->data[i] : s->data[i];
            if (e > best) { best = e; w0 = x; }
        }
    st_pitch_begin(&S->pw, s->data, w0, span > 0 ? w0 + ST_PITCH_N : b);
    S->p_run = 1;
    if (op1_sampler_job(pitch_step, 0)) S->p_run = 0;
}
static int retuned(void)
{
    uint32_t b[2];
    return S->p_ok && S->pr.valid && op1_sampler_base_freq(b) &&
           b[0] == (uint32_t)st_note_f64[S->pr.note] && b[1] == (uint32_t)(st_note_f64[S->pr.note] >> 32);
}
static void draw_pitch(void *r)
{
    if (!S->p_ok || !S->pr.valid) return;
    char t[8];
    st_pitch_name(S->pr.note, t);
    int tuned = retuned();
    tx(tuned ? T_NOTE_G : T_NOTE, t, r);                         /* green: the sound is tuned to this note */
    int cx = 240, c = S->pr.cents, ok = c >= -3 && c <= 3;      /* tuner: -50 .. +50 cents over 100 px */
    ln(r, cx - 50, TEXT_Y + 6, cx + 50, TEXT_Y + 6, 0x400, c_dark);
    ln(r, cx, TEXT_Y + 2, cx, TEXT_Y + 10, 0x400, c_grey);
    ln(r, cx + c, TEXT_Y, cx + c, TEXT_Y + 12, 0x800, ok ? c_green : c_white);
}
static void retune(void)                                          /* KeyHandler: Shift + green */
{
    op1_sampler_t s;
    if (!op1_sampler_now(&s) || s.kind != OP1_SAMPLER_SYNTH) return;
    if (S->rt_on && S->rt_gen == s.gen) {                         /* again: back */
        uint32_t f32 = 0;
        /* the old value as a float: from the double bits (normal numbers; base_freq is > 0) */
        uint32_t hi = S->rt_old[1], lo = S->rt_old[0];
        int e = (int)((hi >> 20) & 0x7FF) - 1023 + 127;
        if (e > 0 && e < 255) f32 = (uint32_t)e << 23 | (hi & 0xFFFFF) << 3 | lo >> 29;
        if (f32 && !op1_sampler_set_base_freq(S->rt_old, f32)) op1_toast("tuning put back");
        S->rt_on = 0;
        return;
    }
    if (!S->p_ok || !S->pr.valid) { op1_toast("no note to tune to"); return; }
    uint32_t old[2];
    if (!op1_sampler_base_freq(old)) return;
    int n = S->pr.note;
    uint32_t nb[2] = { (uint32_t)st_note_f64[n], (uint32_t)(st_note_f64[n] >> 32) };
    if (op1_sampler_set_base_freq(nb, st_note_f32[n])) return;
    S->rt_old[0] = old[0]; S->rt_old[1] = old[1]; S->rt_on = 1; S->rt_gen = s.gen;
    char t[24], nm[8];
    st_pitch_name(n, nm);
    put(put(t, "tuned to "), nm);
    op1_toast(t);
}

/* ---- fit ---- */
static int32_t beat_samples(void) { op1_beat_t b; op1_beat_clock(&b); return b.len > 0 ? b.len >> 14 : 22050; }
static void fit_range(const op1_sampler_t *s, int32_t *a, int32_t *b)
{
    if (s->kind == OP1_SAMPLER_SYNTH) { *a = op1_sampler_marker(OP1_SM_START, -1); *b = op1_sampler_marker(OP1_SM_END, -1); return; }
    int32_t lo = s->cap, hi = 0;
    for (int k = 0; k < 24; k++) {
        int32_t x = op1_sampler_marker(OP1_SM_START, k), y = op1_sampler_marker(OP1_SM_END, k);
        if (y <= x) continue;
        if (x < lo) lo = x;
        if (y > hi) hi = y;
    }
    *a = lo < hi ? lo : 0; *b = lo < hi ? hi : 0;
}
static int32_t len_of(int i) { return (int32_t)bars_of[i] * 4 * S->f_beat; }
static int fits(const op1_sampler_t *s, int i)
{
    int32_t l = len_of(i), in = S->f_b - S->f_a;
    return in >= ST_FIT_MIN_IN && l <= st_fit_max_len(s->cap, in, S->mode) && l >= st_fit_min_len(in);
}
static int fit_step(void *ctx)
{
    (void)ctx;
    /* output: 128 samples a pass (a WSOLA search fits); the move and the zeroing are cheap: 8192, the move capped at
     * what is left of it so the pass never runs on into the output (st_fit_step continues across phases) */
    int32_t b = S->fw.phase == 0 ? (S->fw.mv_left < 8192 ? S->fw.mv_left : 8192) : S->fw.phase == 1 ? 128 : 8192;
    if (st_fit_step(&S->fw, b > 0 ? b : 1)) return 1;
    /* markers follow the audio: synth start 0, end l_out, loop points mapped; drum every key mapped */
    if (S->f_kind == OP1_SAMPLER_SYNTH) {
        op1_sampler_set_marker(OP1_SM_START, -1, 0);
        op1_sampler_set_marker(OP1_SM_END, -1, S->fw.l_out);
        op1_sampler_set_marker(OP1_SM_LOOP_A, -1, st_fit_map(&S->fw, S->f_loop[0]));
        op1_sampler_set_marker(OP1_SM_LOOP_B, -1, st_fit_map(&S->fw, S->f_loop[1]));
    } else {
        for (int k = 0; k < 24; k++) {
            if (S->f_keys[k][1] <= S->f_keys[k][0]) continue;
            op1_sampler_set_marker(OP1_SM_START, k, st_fit_map(&S->fw, S->f_keys[k][0]));
            op1_sampler_set_marker(OP1_SM_END, k, st_fit_map(&S->fw, S->f_keys[k][1]));
        }
    }
    op1_sampler_commit(1);
    S->fitting = 0; S->panel = 0;
    char t[24], *o = num(put(put(t, "fit to "), ""), bars_of[S->bars_i]);
    put(o, bars_of[S->bars_i] == 1 ? " bar" : " bars");
    op1_toast(t);
    return 0;
}
static void fit_start(void)                                       /* KeyHandler: orange in the panel */
{
    op1_sampler_t s;
    if (!op1_sampler_now(&s)) return;
    if (s.busy) { op1_toast("not while sampling or recording"); return; }
    if (S->f_b - S->f_a < ST_FIT_MIN_IN) { op1_toast("too short to fit"); return; }
    if (!fits(&s, S->bars_i)) { op1_toast("that doesn't fit the sample"); return; }
    if (op1_sampler_job_running()) return;
    S->f_kind = s.kind;
    if (s.kind == OP1_SAMPLER_SYNTH) {
        S->f_loop[0] = op1_sampler_marker(OP1_SM_LOOP_A, -1); S->f_loop[1] = op1_sampler_marker(OP1_SM_LOOP_B, -1);
    } else
        for (int k = 0; k < 24; k++) { S->f_keys[k][0] = op1_sampler_marker(OP1_SM_START, k); S->f_keys[k][1] = op1_sampler_marker(OP1_SM_END, k); }
    if (st_fit_begin(&S->fw, s.data, s.cap, S->f_a, S->f_b, len_of(S->bars_i), S->mode == 1 ? ST_FIT_TAPE : ST_FIT_KEEP)) {
        op1_toast("that doesn't fit the sample");
        return;
    }
    S->fitting = 1; S->c_ok = 0; S->p_ok = 0;
    if (op1_sampler_job(fit_step, 0)) S->fitting = 0;
}
static void panel_open(const op1_sampler_t *s)
{
    S->f_beat = beat_samples();
    fit_range(s, &S->f_a, &S->f_b);
    if (!fits(s, S->bars_i)) for (int i = 3; i >= 0; i--) if (fits(s, i)) { S->bars_i = (uint8_t)i; break; }
    S->panel = 1; S->acc = 0;
}
static void draw_panel(void *r, const op1_sampler_t *s)
{
    fill(r, 4, COVER_Y0, 316, COVER_Y1, c_black);
    char t[16];
    put(num(put(t, "bars "), bars_of[S->bars_i]), "");
    tx(T_BARS, t, r);
    int32_t bpm = S->f_beat > 0 ? (2646000 + S->f_beat / 2) / S->f_beat : 0;
    put(num(t, bpm), " bpm");
    tx(T_BPM, t, r);
    int first_full = -1;
    for (int i = 0; i < 4; i++) {                                 /* cells: 1, 2, 4, 8 bars */
        int x = 24 + i * 70, ok = fits(s, i), on = i <= S->bars_i;
        int prog = S->fitting ? st_fit_progress(&S->fw) : 1024;   /* while fitting the cells fill */
        if (!ok) { if (first_full < 0) first_full = i; }
        else if (on) {
            int w = S->fitting ? 60 * prog / 1024 : 60;
            if (w > 0) fill(r, x, 74, x + w, 92, c_synth);
        }
        ln(r, x, 74, x + 60, 74, 0x400, ok ? c_grey : c_dark); ln(r, x, 92, x + 60, 92, 0x400, ok ? c_grey : c_dark);
        ln(r, x, 74, x, 92, 0x400, ok ? c_grey : c_dark); ln(r, x + 60, 74, x + 60, 92, 0x400, ok ? c_grey : c_dark);
    }
    for (int i = 0; i < 4; i++) {                                 /* bar counts under the cells (stroke font digits) */
        char d[2] = { (char)('0' + bars_of[i]), 0 };
        sf_text(r, OP1_Q10(24 + i * 70 + 28), OP1_Q10(97), 1229, d, 0x500, c_grey);
    }
    tx(S->mode ? T_KEEP_G : T_KEEP, "keep pitch", r);            /* the chosen mode lit, the other dimmed */
    tx(S->mode ? T_TAPE : T_TAPE_G, "tape", r);
    tx(T_FIT, S->fitting ? "fitting" : "fit", r);
    dot(r, 12, 83, 3, c_synth);                                   /* knob colours: blue bars, green mode, orange fit */
    dot(r, 12, 118, 3, c_green);
    dot(r, 242, 118, 3, c_orange);
    if (first_full >= 0) tx(T_FULL + first_full, "full", r);      /* in the first cell that doesn't fit (a text per
                                                                    * cell: a moved text's translation isn't in px) */
}

/* ---- hooks ---- */
static void st_event(int id, int32_t arg)
{
    (void)arg;
    if (id == OP1_EV_BOOT_DONE && !S) S = (st_state *)op1_alloc(sizeof(st_state));
}

static void st_overlay(void *r, int32_t screen)
{
    op1_sampler_t s;
    if (!S || (screen != 6 && screen != 0x10) || !op1_sampler_now(&s)) return;
    texts();
    reset_for(&s);
    if (S->panel) { draw_panel(r, &s); return; }
    if (S->fitting) return;                                       /* the buffer moves under the view */
    if (S->zsh || (S->blue_down && s.kind == OP1_SAMPLER_SYNTH)) draw_zoom(r, &s);   /* fine start: our view, start ringed */
    if (s.kind == OP1_SAMPLER_SYNTH) { pitch_poll(&s); draw_pitch(r); }
}

static int st_input(const op1_input *in)
{
    op1_sampler_t s;
    if (!S) return 0;
    int k = in->type == OP1_IN_KEY && in->code >= K_BLUE && in->code <= K_ORANGE ? in->code - K_BLUE : -1;
    if (k >= 0 && !in->pressed && S->swallow[k]) {                /* the release of a press we took */
        S->swallow[k] = 0;
        if (k == 0) S->blue_down = 0;
        return 1;
    }
    if (!op1_sampler_now(&s)) { S->blue_down = 0; if (S->panel && !S->fitting) S->panel = 0; return 0; }
    reset_for(&s);
    if (S->fitting) return 1;                                     /* keys and knobs wait for the fit */
    if (S->panel) {
        if (in->type == OP1_IN_KNOB) {
            int32_t *a = &S->acc;
            if ((*a > 0 && in->delta < 0) || (*a < 0 && in->delta > 0)) *a = 0;
            *a += in->delta;
            int st = *a / 1024;
            if (!st) return 1;
            *a -= st * 1024;
            if (in->code == 0) {                                  /* blue: bars, only lengths that fit */
                int i = S->bars_i;
                for (int n = st < 0 ? -st : st; n; n--) {
                    int j = i + (st > 0 ? 1 : -1);
                    while (j >= 0 && j < 4 && !fits(&s, j)) j += st > 0 ? 1 : -1;
                    if (j < 0 || j > 3) break;
                    i = j;
                }
                S->bars_i = (uint8_t)i;
            } else if (in->code == 1) {                           /* green: keep pitch / tape */
                S->mode = st > 0;
                if (!fits(&s, S->bars_i)) for (int i = 3; i >= 0; i--) if (fits(&s, i)) { S->bars_i = (uint8_t)i; break; }
            }
            return 1;
        }
        if (k >= 0) {
            if (in->pressed) { S->swallow[k] = 1; if (k == 3) fit_start(); }
            return 1;
        }
        if (in->type == OP1_IN_KEY && in->pressed) S->panel = 0;  /* any other key closes it and acts as usual */
        return 0;
    }
    if (in->type == OP1_IN_KNOB) {
        if (in->code == 0 && S->blue_down && s.kind == OP1_SAMPLER_SYNTH) {   /* fine start */
            S->acc += in->delta;
            int st = S->acc / 256;
            if (st) {
                S->acc -= st * 256;
                int32_t p = op1_sampler_marker(OP1_SM_START, -1) + st * ST_FINE, e = op1_sampler_marker(OP1_SM_END, -1);
                if (p < 0) p = 0;
                if (p > e - 1) p = e - 1;
                op1_sampler_set_marker(OP1_SM_START, -1, p);
                op1_sampler_commit(0);
                S->follow = OP1_SM_START;
            }
            return 1;
        }
        int m = knob_marker(&s, in->code);
        if (m >= 0 && !(s.kind == OP1_SAMPLER_DRUM && in->code == 0)) S->follow = (int8_t)m;   /* follow, don't take */
        return 0;
    }
    if (k < 0 || !in->pressed) return 0;
    if (k == 2) {                                                 /* white: zoom in, Shift + white: out */
        if (in->shift) { if (S->zsh) S->zsh--; }
        else if (S->zsh < 5) S->zsh++;
        S->swallow[2] = 1;
        return 1;
    }
    if (k == 1 && in->shift && s.kind == OP1_SAMPLER_SYNTH) { retune(); S->swallow[1] = 1; return 1; }
    if (k == 0 && !in->shift && s.kind == OP1_SAMPLER_SYNTH) { S->blue_down = 1; S->acc = 0; S->swallow[0] = 1; return 1; }
    if (k == 3 && !in->shift) { panel_open(&s); S->swallow[3] = 1; return 1; }
    return 0;
}

static const char *const st_claims[] = { "key:synth:white", "key:synth:shift+white", "key:synth:blue",
    "key:synth:shift+green", "key:synth:orange", "key:drum:white", "key:drum:shift+white", "key:drum:orange", 0 };
const op1_feature_t FEATURE_sampletools = {
    .api = OP1_FEATURE_API, .priority = 600, .name = "sampletools",
    .event = st_event, .input = st_input, .overlay = st_overlay, .claims = st_claims,
};
