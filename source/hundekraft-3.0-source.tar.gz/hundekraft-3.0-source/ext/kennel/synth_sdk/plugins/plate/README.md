# Plate

Independent loadable kennel effect, canonical name `plate`, with no legacy order.
The owner authorized the Maiko #250 algorithm and custom artwork port on 2026-10-16.
This is a source reconstruction, not a binary-identical build. No TE firmware,
font, generic screen, keys or NAND data is included.

Controls follow the [Maiko #250 Plate guide](https://maikopruett.com/op-1/guide/plate):
blue decay, green tone, white pre-delay, orange mix. The guide describes approximately
0.1–12 seconds of decay and 0–186 ms pre-delay. Values on screen are the original
normalized 00–99 controls, not measured seconds. The original saved raw defaults
7296/14746/7389/15565 normalize to approximately 50/60/33/30 percent. The plugin
uses that normalized default. Synth/drum process mono; master receives independent
left/right dry inputs and a stereo reverb tank. Center mix has both dry and wet
at full gain; the endpoints are dry and wet respectively.

The integer network follows the recovered original Plate DSP (Jon Dattorro topology):
four input diffusers, two cross-coupled modulated delay/allpass branches, separate
low-pass damping states, and seven output taps per channel. The 65,536-sample ring
and state use 131,116 bytes, within each position's 176,460-byte scratch allowance.
Every position owns its state. There is no allocation or per-sample division.
Pre-delay is squared and slews by at most 16 samples per block; dry/wet gains ramp
over each 64-sample block. The sine table is regenerated mathematically. The native
master call operates at the firmware output block rate; the same integer delay
lengths are retained rather than silently retuning the original network.

Private reference: local `firmware/op1_250.op1`, decoded region SHA256
`09c22c233dc9a84b6e9674f0a1670f5c8f0ca8331dc819d97d4133fd58681c7a`.
Plate init/render addresses are 0x01e501ec/0x01e5021c, parameter normalization
0x01e4f648, shared screen 0x01e51566 branch 2. Static artwork comes only from
Maiko's six custom shape descriptors at 0x01ea0df0 + 0x4bc; the shared
`../warble/gen_svg.py` extractor with index 2 reproduces coordinates and RGB565
alpha composition on black, using the firmware-supported absolute M/L/Z subset. Disjoint final-color pixel runs are coalesced into 657 maximal rectangles in
`plate_art.svg`. `gen_art.py` writes the same rectangle bounds and colors to
`plate_art.h`; the runtime SVG is empty. The screen draws those rectangles with
the firmware's shared filled quad, so it does not allocate a separate
SVG raster path for every rectangle. It uses the same transform, Q5 vertices and
fill routine as the firmware raster. The original artwork remains the source.

The owner reported a native heap failure entering Plate on synth (2026-10-17).
The photographed stack allocates a 2 KB raster chunk; the second exception is the
panic stack printer following a misaligned frame pointer. A bounded exact-rc-3.0x
all-50-file emulator census measured an 8,517,688-byte heap high-water mark while
entering Plate, out of the stock 8,650,752-byte pool. Repeated entry and dwell did
not show a sustained leak. This fixes the art's temporary heap pressure; audio
watchdog muting and hardware CPU acceptance are separate gates.

The private all-50-file package with only Plate replaced passed the bounded native
regression: exact relocated plugin text, 480 display frames and five T1/T3
reentries, with normal exit. Entry high-water fell to 7,036,672 bytes; the entire
run peaked at 7,039,872 bytes and steady Plate use remained 6,827,648 bytes.
A 16,685-pixel static frame/spring mask matches the original native capture
exactly; this does not claim equality of animated content or the whole frame.
The 120-frame dwell intervals took roughly 3.6–3.9 host seconds after the first
interval, versus roughly 7.8–8.2 seconds before, so this run shows no large GUI
cost regression. These host timings are not hardware CPU measurements.

The plate ripples, felt hatch and coiling cable are redrawn as vectors. Native
runtime text uses the firmware font without including its bytes.

Known differences: portable C arithmetic and saturation, eager ring clearing,
vector raster antialiasing and clipped procedural primitives, standard kennel
screen/parameter handling. Peak-driven ripple brightness and the felt erasure are reproduced through the vector raster. Exact original-firmware audio
identity and hardware CPU load remain unverified; no original #250 reference boot
has been accepted.

Focused host verification:

```sh
cc -O2 -fsanitize=undefined plate_test.c plate_dsp.c -o /tmp/plate-test
/tmp/plate-test
```

This checks dry bit identity, silence, independent instance memory, stereo
asymmetry, short/long/dark impulse response and maximum-feedback sustained-DC
recovery. Maximum-feedback arithmetic limit cycles remain below 100 PCM units
in this bounded test; it does not assert a mathematically zero infinite tail.

## Screen placement (2026-10-17)

Owner hardware polish raises the static art, live geometry and native readouts twelve
logical pixels, plus another four pixels for lower labels/readouts (40px values now y98). The full-screen bypass veil keeps its canvas
bounds.
