# Father

Father is a stereo ambience effect for the original OP-1 running the current kennel 3.0 core. Its sound is an original feedback delay network, inspired by the spacious role of OP-1 Field Mother. Its screen follows the owner's supplied video of **Father**, whose original controls were distance, mod, color and mix; green now controls a wet gate. These are separate references; Father does not reproduce or contain Teenage Engineering's DSP.

| Encoder | Control | Behavior |
|---|---|---|
| Blue | distance | More predelay and a longer decay. Predelay spans 0–30 ms; the ideal unfiltered network's decay target spans 0.35–8 seconds. Damping makes the audible decay shorter. |
| Green | gate | Zero disables gating; turn up to shorten the tail hold from about 1.8 s to 80 ms, followed by a rounded fade. Enabling waits for a new input attack before shaping the existing tail. Stereo-linked; predelay is included. |
| White | color | Dark, heavily damped reflections through to a brighter tail. |
| Orange | mix | Linear dry/wet blend. Zero is exactly dry when settled. |

Metadata defaults correspond to about distance 50, gate off, color 54 and mix 30 on a normalized 0–99 scale. Native filter-range conversion can round the initial distance to 49; these are not a claim that selecting an existing effect resets its saved controls. There are no extra pages or encoder-push controls. The ordinary OP-1 FX switch enables or bypasses the effect. Synth and drum effects use the mono callback; the master uses independent stereo input/output through the current stereo FX API.

## DSP

Eight unequal delay lines use interleaved normalized four-way Hadamard scattering. Each line spreads into four destinations per pass and all eight after two passes; the feedback paths have no dominant 3/4 self-return. Shorter, more widely spread delays increase the early tail density. Every line starts at a different modulation phase and moves slowly by about 4–6 samples at an independent rate. Two input allpasses per channel feed the tank; the existing short, crossfed early-reflection path bridges into the late tail. Color filters the early reflections and damps the tank, with a softer bright endpoint.

Gate is off by default. Green controls hold duration (about 1.8 s near zero, 80 ms at maximum), with a smooth closing fade (roughly 160–40 ms to −60 dB) and fast rounded opening. A shared stereo dry-input detector runs once per block at fixed low thresholds (32 to activate, 16 to release, about −60/−66 dBFS), with a clear rise retriggering it. Dry activity refreshes the hold. Enabling Gate leaves the current tail open until a new input attack arms it; disabling opens smoothly. Both early and late wet output share the gate, while the dry path and tank continue unaffected.

Predelay still spans 0–30 ms. The shortest late path now starts around 44 ms at default Distance, overlapping the early-reflection cluster rather than arriving separately. The late-return gain is +3.5 dB relative to the original voicing, trimmed from the previous +6 dB for more output headroom with the denser tail. Early/late output limiting, the linear mix law and callback mix ramp remain.

The implementation uses 64-sample callbacks at 22,050 Hz. The SDK declares both FX callbacks with 64-sample buffers, and the documented R246 mono call at `0xFFA02B34` operates after decimation (`OP1-Emulator/docs/firmware/findings/audio-graph.json`). The 44,100 Hz synth voice rate is separate. State fits in the existing 176,460-byte scratch area at each of the three FX positions. No heap allocation, floating point or division runs in the audio loop. All delay, filter, interpolation and modulation state belongs to its instance.

`gen_tables.py` generates feedback coefficients analytically from line lengths and the target decay. The network topology and implementation are original. State occupies 93,032 bytes per FX position, including 2,560 bytes of callback workspace in the existing per-instance scratch (no new ISR stack arrays). The textbook reference is Julius O. Smith's [FDN Reverberation](https://dsprelated.com/freebooks/pasp/FDN_Reverberation.html), particularly lossless feedback matrices and damping. No source code was copied from that reference. A public [Father demonstration by xylograph](https://www.reddit.com/r/OP1users/comments/1x422ip/father_a_stereo_algorithmic_reverb_running_on_the/) describes a separately developed OG-1 reverb; no code or DSP from that project is included here.

Teenage Engineering's [OP-1 Field guide v1.7](https://assets.teenage.engineering/_img/69f248938d433104c4dd1846_original.pdf), page 24, lists Mother's controls as distance, gate, color and mix; it does not disclose the DSP algorithm or parameter ranges. The owner requested replacing **mod** with **gate** to approach Mother's documented controls. The exact TE detector/timing are unpublished. Our gate approximation is the duration-based design described above; it is not a reproduction of an unpublished TE algorithm. Zero disables gating, and the tank is never cleared when the wet envelope closes.

[Media Integration's Mother demonstration](https://www.minet.jp/contents/article/op-1-field-feat-yumi-iwaki-vol5/) describes gated tails, especially with short envelopes/drums. This informs the behavior, not an exact recreation of Mother's DSP. No matched listening or tests were run for the gate change.

## Historical checks and remaining acceptance

The evidence below predates the Gate control; it does not validate the new wet gate.

Run `python3 ext/kennel/synth_sdk/plugins/father/check.py run/father-host` from the containing OP1-Emulator checkout. The focused host checks exercise full-scale endpoint combinations under ASan/UBSan, exact dry output, silent input, separate instance state, stereo decorrelation, distance-dependent decay and an audible modulation change. The output folder contains a stereo wet impulse WAV and numeric evidence. These checks do not establish native screen rendering, Blackfin CPU headroom or real OP-1 sound.

Targeted emulator evidence in the containing OP1-Emulator checkout:

- `run/father-native/result.json`: 17/17 functional checks pass, 128.022 seconds, normal exit zero. It checks selected identity and exact relocated code, synth/drum/master callbacks and audio, bypass, four controls and mix maximum. This tested the earlier `7ac0cd60…` art pack.
- `run/father-visual-final/result.json`: 10/10 final-motion checks pass, 77.261 seconds, normal exit zero, pack `a2e7c5a1…`. Actual default/near/far frames show head movement, an unchanged declared room strip and idle bypass. The subsequent footer-only cleanup removes our duplicate FX-off lettering in favor of the stock overlay.
- `run/father-clean-native/result.json`: 6/6 footer-cleanup checks pass, 48.352 seconds, normal exit zero. Final pack SHA-256 is `13929fcbe42c2d87d516a2b74ee28d859a3c4491a38cbfad119084c322242046` (`build/father-clean/father.knl`). Actual normal and idle-off frames have contained artwork and labels, with only the stock FX-off overlay. This supplements the earlier motion checks; it does not repeat audio or cost checks. `build/father-clean/cost-audio-equivalence.json` records equal allocated audio-object sections and normalized relocations against the measured budget pack.
- The first visual run retains its failure in `run/father-visual-native`: the test compared a raw distance word with a normalized Q15 endpoint. The corrected runner reads the SDK-documented native filter table and reaches its exact endpoints, raw 64 and 14528, through real encoder input. No FX change was needed.
- `run/father-budget-opt/cost.json`: six separate mono/master default/min/max cases measure 62,748.9–63,055.2 packets per 64-sample callback, after settling. The focused optimization preserves every output sample and persistent state byte against `father_reference.c` for 6,000 changing-control stereo blocks. Father is heavier than Plate's roughly 35k packets. Packets omit cache and SDRAM stalls; physical sysmon measurements remain necessary, and heavy synth/FX combinations are not accepted by this result.

The inherited native audio fixture is quiet: synth peak 0.001117, drum 0.055015 and cascaded master 0.000210. Wet correlation 0.44388 versus the dry repeat's 0.64546 establishes the bounded comparison, not representative musical gain. The separate host dry/mix/wet chord WAVs and full-scale endpoint checks cover the DSP itself. No all-plugin or hardware-performance claim is made.

## Audio budget follow-up (2026-10-17)

The owner's `FATHER MUTED - TOO SLOW` report is the core's existing 64-consecutive-call,
193,000-CCLK FX guard. That guard and fallback are unchanged. The earlier packet
fixture does not model the unit's cache/SDRAM stalls and did not establish hardware
headroom.

Tank reads and writes now run line by line across a callback, keeping recurrence state
in registers and accessing nearby samples together. The shortest nominal tank delay remains
1,493 samples (at least 1,481 with modulation), longer than the 64-sample callback, so every current read precedes any
write it could observe. Diffusers use the same block scheduling. Audio, damping,
feedback and phase advancement still run at the full sample rate. The slow fractional
delay modulation is evaluated every eight samples and linearly interpolated between
exact endpoints. This is an approximation, with a conservative delay error bound of
5/256 sample; every modulation word swept around both triangle cusps observes at most
2/256 sample. Controls, line count, feedback coefficients and delay lengths are unchanged.

`run/father-budget-fix/settled/cost.json` in the parent checkout measures six independent
mono/master default/min/max cases at 50,374–51,015.8 packets per callback, versus the
previous settled 62,748.9–63,055.2. The 35,040-packet development target remains unmet;
this reduction and improved locality require physical-unit validation before calling
the hardware mute fixed. No watchdog relaxation is part of this change.

The focused sanitizer check compares 6,000 changing-control full-scale blocks,
alternating mono/stereo, with the retained full-rate reference: worst difference
59 LSB and RMS difference 0.0001072 of full scale. The deterministic chord comparison
has an exact dry endpoint, at most 1 LSB at mix 30 and 3 LSB at full wet; respective
RMS differences are 0.00000808 and 0.00001546 of full scale. It also checks exact phase,
predelay/diffuser state, silence, per-instance isolation, all control endpoints, tail,
stereo separation and color response. These are signal/error bounds, not a listening
claim or hardware CPU acceptance.

The exact rc-3.0x all-50 fixture passes the same bounded native journey before
(20/20, 102.295 s) and after (20/20, 108.570 s): original core image unchanged,
exact relocated Father text, sustained notes beyond 64 callbacks, enabled/bypassed
post-release tail, zero mute flags (and zero recorded strikes after). Afterward wet
RMS is 0.000172 versus bypass 0.000008. Actual native pixels retain the room, person,
cassette, bust, grid and labels. Tested file: SHA-256
`c1749f60834aa650271c573a22566f8117348b456e333f791dd3f4947447ba7b`,
`run/father-budget-fix/packages/father.knl` in the parent checkout. The emulator also
passes before the change, so these gates do not reproduce or close the owner's
physical watchdog failure. The private installer changes only `content/father.knl`;
no published package, pin or site changes.


## Screen reference and measured motion

The owner supplied `m2-res_1080p.mp4`, a filmed demonstration of Father. The matching
public demonstration is credited to xylograph (link above). The vector scene here
is an original reconstruction from that video, not imported Maiko or TE artwork.
The Maiko permission used by other plugins is not the provenance for Father.
The raw video and extracted frames stay private and are not distributed.

`gen_svg.py` maps the measured filmed display bounds, approximately x620–1255 and
y66–370, to 320×160. Perspective, illumination and video compression limit accuracy;
this is not an exact digital-screen trace. Frames at 2, 3 and 4 seconds show distance
49, 99 and 80. The central cap/glasses head and shoulders retain a fixed vanishing
anchor near (156,94), with measured footprint ratios about 1, .40 and .63. The live
screen interpolates those ratios. Values below the observed range extrapolate the
projection and clip intentionally to the viewport; they are not measured video states.

The fixed ceiling/floor/back-wall grid and cassette remain at their
reference locations; the small person is green and follows Gate. The grid is visible through the face and bust; only glasses
lenses occlude it. The cap curve, hem, pupil strokes and cassette button strip, lower
holes and loose tape follow identifying details visible in the lossless source frames.
Owner screen polish (2026-10-17) raises the complete scene and native readouts twelve
logical pixels, matching the other three FX scene lifts. Green now shifts the small green person with shorter gate duration. Green door bars
close around it as the audio gate closes. The bust follows Distance. White changes the
bust from dark cyan to pale bright cyan, reflecting dark damping through bright tails;
the original cyan is retained at the default color value. This is new control feedback,
not motion measured from the reference video. MIX drives the right bar;
all four sound controls remain active even where the source does not isolate a visual
change. DISTANCE and labels use runtime native fonts, cached until text changes;
no firmware font is copied. The existing native FX overlay owns bypass dimming and its central FX OFF label;
the illustration adds no duplicate indicator or silence-based inference.

The generated SVG uses the established `svgart.shape`/`rounded` helpers, separate
filled contours, `#010101` lens cutouts and at most two decimal places. The C geometry
contains only original measured points. `screen_check.py` checks 18 observed-distance,
endpoint, mix and enabled/bypass states under sanitizers and an unclipped native-font
layout model. This is host evidence; installed rendering is a separate gate.

### Phase audition pair

Run `python3 synth_sdk/plugins/father/presets.py OUT` from the kennel repository root to generate `father-ab.zip` and two original Phase presets. Both use the same voice, envelope and Father controls; only their names and saved effect on/off setting differ. The files contain no stock audio. Copy `father_ab` into the OP-1's `synth/` folder, eject and sync. In the synth browser, select FATHER_AB and FATHER-OFF or FATHER-ON, then press 1. T3 opens the effect page; pressing it again toggles the effect. Keep the global master effect off for comparison.

`run/father-presets-audition/result.json` passed 26/26 checks in 117.289 seconds, with normal exit 0 and the source NAND unchanged. Actual browser loads selected Phase (runtime type 7), byte-matched the final Father plugin, retained identical voice/envelope controls, restored the two saved effect states, and passed T3 off/on checks. Native mono note RMS was 0.032471 off and 0.023430 on; released-tail RMS was 0.000008 off and 0.000178 on. A read-only database check after normal quit confirmed that only the names and effect on/off settings differed.

The USB transfer and indexing occurred in an earlier setup phase. The accepted audition resumed clones of that imported NAND; it is not a seamless import/restart pass. Retained failed setup attempts exposed boot-readiness/sync waits, a missing prerequisite after the safety fallback, a whitespace dump filename, and a database-ID versus runtime-type oracle error. No Father DSP or acceptance thresholds changed. Physical hardware performance remains unverified.

## Earlier reverb voicing update (2026-10-17, superseded)

Gate now defaults to zero, allowing the natural tail to decay. Existing loaded
slot controls remain their current values: turn green to zero to hear the
ungated reverb. The generated Phase audition pair also uses Gate off.

Predelay spans 0–30 ms instead of 0–80 ms. Four early-reflection taps per output
use offsets149/263/421/631 samples on the left and173/307/487/733 on the right,
plus the current predelay, at22,050 Hz. At default Distance the first return
is about22 ms and the last early tap about48 ms; the shortest late-tank path
starts about83 ms. The tap gains are1/4,1/8,-1/16,1/16, with crossfeed on the
second and fourth taps; Color filters their sum. Absolute gains total1/2 per
output before that lowpass.

Late output gain rises by6 dB without raising feedback injection or changing
the decay table, tank delays, damping law or feedback stability. Linear mix
scaling and its callback ramp stay unchanged. Output remains limited to the
16-bit range after the early/late sum. Two color-filter states add8 bytes per
instance; the early taps reuse existing rings and allocate no new delay buffer.
When Gate is off, its peak detector, hold and gain calculations are skipped.

Rebuilt and updated in the local webapp without tests. All earlier audio/error
and budget results above describe older voicings; they do not validate this
wet gain, early path or hardware load. Sound, peak behavior and hardware
headroom remain for owner acceptance.

## Lusher tail and duration Gate (2026-10-17)

The owner reported metallic ringing and an immediate tail cut when Gate was
enabled. The current design above supersedes the threshold-controlled gate
and previous tail matrix. Tank lengths are641/887/1153/1429/1867/2131/2683/3163
samples; `gen_tables.py` regenerates the same0.35–8 s nominal decay curve for
those lengths. The interleaved four-way scattering uses additions and halves,
with no new feedback multiplier or extra delay line. Two independent groups
cross through their permuted destinations. Color's damping coefficient now
spans1800..21800 rather than1800..29300. Independent slow phase offsets and
4–6 sample delay motion replace the old shared-phase two-sample motion.

The block-rate detector stays aware of input while Gate is off. On enable,
the wet envelope stays open until a fresh threshold crossing or clear attack;
thereafter dry activity refreshes the selected hold. Enabling during silence
therefore preserves a tail instead of closing it. Trigger thresholds do not
rise with green. Closing rates and hold times vary smoothly with green;
reopening is rounded. Gate defaults remain off.

The old mean workspace is removed; three gate flags add four aligned bytes,
for a net252-byte scratch reduction per instance. No new allocation, sample
rate, voice limit or combination budget policy is introduced. Existing
Oxbow+Father crackling remains an open hardware report; these changes do not
establish CPU headroom or guarantee crackle-free playback.

Only builds/package and served-file comparisons were performed, as requested.
No tests, audio rendering/listening or hardware measurements. The intent is
a denser, softer stereo reverb, with no claimed sound match to Field Mother.

## Exact-sound performance update (2026-10-19)

The current eight-line voicing is unchanged. Contiguous delay-read spans, a separate feedback pass, padded tank heads and per-position normalization caching reduce default Blackfin instruction work from60,073 to51,302 packets per64-sample render with real filter ranges (~14.6%). Changed controls normalize immediately, including LFO and master edits. Padding adds256 bytes within the existing scratch. No half-rate processing, shorter tail, reduced voice count or changed watchdog is used.

`father_reference.c` now freezes the immediately preceding current voicing. `check.py` runs exact-output differential and cached-wrapper edit/re-init checks as well as signal/sanitizer coverage. The retained integer network has a roughly one-LSB tail floor; the decay check bounds it explicitly. See parent `docs/father-mbira-performance-2026-10-19.md`. Hardware rapid-note/combination acceptance remains open.
