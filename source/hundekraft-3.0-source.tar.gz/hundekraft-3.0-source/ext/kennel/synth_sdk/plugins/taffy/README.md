# TAFFY

### Output polish (2026-10-17)

Per-voice mean removal (~6.86Hz) precedes gain and native voice mixing; native bus high-pass is unchanged. Current kennel only; historical2.x engine sources and preset controls remain unchanged. Method, calibration and native emulator evidence: parent `docs/engine-level-polish-2026-10-17.md`. Physical CPU/listening acceptance remains separate.
