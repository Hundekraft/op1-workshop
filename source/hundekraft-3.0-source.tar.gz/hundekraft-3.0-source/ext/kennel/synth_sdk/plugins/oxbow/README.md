# Oxbow

Current design (2026-10-18): no internal program bank. T2 is the only amplitude
envelope; the former hidden program amp envelope could end before T2 Sustain or
Release and mask those controls. The neutral two-oscillator voice retains its
filter envelope and vintage drift. Page-2 blue selects Wave (saw, pulse, both,
sync, cross-mod, fifth), green Filter, white Drive. Normal OP-1 patch files store
these controls; 16 bundled presets have explicit T2 envelopes and oscillator/filter
choices. Their FX/LFO additions remain in the parent workshop generator.

`obv_params.h` contains parameter definitions/defaults, with no program lists.
`presets.py` emits explicit metadata instead of parsing a bank. The source header
and historical performance notes below describe the earlier voice implementation;
they are not measurements of this revision. No tests/audio renders were run for
this change. Hardware envelope, sound variation and six-voice/FX load remain open.

### Oxbow OLED fit and repeated-chord work (2026-10-17)

The owner reported lower-screen clipping and crackles during fast successive triads.
The owner rejected the uniform 80% fit as too small. Oxbow now restores its
broad horizontal composition with SX=160/852 (about288px of reference width),
while SY=132/852 maps reference y89..941 to y6..138 for the earlier FX's lower
clearance. Circles and star rays retain equal-axis proportions about their new
centres. Static art, horns/birds, bell/breath pivots and bird travel paths all
regenerate with these axis maps. Preserve readable strokes and compact SVG
serialization. Do not restore S=128/852 or add the FX's12px translation.

The engine reuses program-only derived values until PROGRAM changes, including its
LFO fade division. Per-card envelope coefficients and other fixed voice values cache
by exact program, DETUNE, note and velocity; changing any key rebuilds them. Fresh
attacks use a binary search over the same monotone note thresholds, at most seven
probes rather than a descending scan from MIDI127. Envelope, filter, oscillator,
random sequence and control rates retain their formulas. Cache storage costs 456
bytes of BSS plus a one-byte program-dirty flag. This removes work but has no measured hardware speed-up
or crackle-resolution claim. Fast triads can overlap release tails and use all six
voices; effect choice and the actual overload/discontinuity cause remain unknown.

The earlier uniform fit was installed as `a8a235320ffe50ae` and is superseded
by the wider layout above. Other plugins and core overlays are preserved. No tests, audio comparison or emulator runs. Physical fit,
sound and CPU benefit need the owner's confirmation.

### Faster selectors (2026-10-17)

Press-blue PROGRAM now repeats the 32 programs in 512-unit bands (twice the former speed); press-green FILTER repeats its seven choices in the same band width (about nine times faster). Main-page controls are unchanged. The bundled 32 program presets use the new encoding; no saved-patch migration is required.

### Width follow-up (2026-10-17)

The full reference span is now25% wider than the rejected fit, with a slightly
taller132px vertical composition and the essential bottom held near y138.
The same generator writes SVG coordinates and Q10 animation geometry. Horn
roots, bell/breath pivots and both components of the bird travel paths use
the new axes. Stars and circles retain their shape; mapped strokes use the
shared native-safe join helper after rounding. This avoids sharp joins that
R246 can turn into spikes. No new art layer or extra SVG complexity is added.

The preview is regenerated from the SVG. Repacked and updated only Oxbow in
the local webapp, without tests or emulator runs. The DSP, fast selectors,
setup caching and preset pack stay unchanged. Physical OLED fit and maximum
animation travel remain for owner acceptance.

### Curated preset bundle (2026-10-17)

`presets.py` now emits16 factory files selected for contrasting bass, lead, keys, brass, pad, pluck and X-MOD roles. It preserves original program IDs and all32 selectable engine programs, and removes only known omitted factory filenames. The parent workshop adds selected missing FX/LFO in its current kennel bundle. Selection/rationale and dry source/mono-FX evidence: parent `docs/preset-review-2026-10-17.md`. No conclusion about the reported hardware crackle follows from this review.
