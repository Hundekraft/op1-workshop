# SID

`sid` is a six-voice OP-1 synth. Each OP-1 voice owns three SID-style oscillators
and one shared 8580-derived lowpass. It adapts the integer light renderer from
cRSID 1.58 by Hermit (Mihaly Horvath), with no C64 CPU, tune player or register
bus. It does not claim cycle-exact SID emulation or a 6581 analog model.

Blue cycles through triangle, saw, pulse, noise, sync and ring in repeating
512-unit bands, about 11 times narrower than the original bands. Audio and the
screen share this selector. The default remains saw. No earlier patch-value
compatibility is needed during development; green/white/red retain their sensitivity. Green changes with mode:
triangle/saw/noise blend the octave and fifth oscillators into the root; pulse
sets approximately 3–97% duty; sync/ring sweep the source/carrier frequency ratio
from 1.00× to approximately 4.00×. The screen labels that meaning. White controls the common
lowpass cutoff, red its resonance. All encoder presses do nothing; there is no
page or Shift parameter bank. Native OP-1 ADSR and gain apply after this engine,
so SID ADSR bugs are not reproduced. Settings use normal saved synth knobs and
the dynamic type name `sid`, with no assigned legacy order.

The oscillator phase, noise LFSR taps, pulse trapezoid, asymmetric saw edge,
sync/ring relationships and 8580 filter tables come from cRSID's light model.
Each voice owns all persistent state. Pitch follows the current voice's firmware
pitch array every 32 samples. Frequency-dependent divisions are cached when
pitch or controls change; the sample loop uses integer multiplies and constant
shifts/divisions. Mode-specialized full-rate block loops keep three oscillator states in scalar locals.
Two exact bit-mapping tables replace noise DAC mask/shift chains. The retained
`sid_sample` implementation provides a sample-at-a-time counterpart to the
optimized path, including the same cutoff mapping and smoothing. The saw's reciprocal approximation replaces its variable
sample-loop division. Oscillator frequency is bounded below Nyquist; filter
state clamps prevent numeric runaway at extreme live settings. A roughly 7 Hz
DC estimator removes pulse/sync offset before native ADSR: an explicit adapter
output-coupling choice, not an exact reproduction of a physical SID board.

Source: https://hermit.cucumalac.hu/cRSID-1.58-with-source-code.tar.gz
The author's README notice is preserved in the adapted source/table headers:

> License is still WTF: Do what the frick you want with this code, but
> it would be nice mentioning me as the original author.

Only selected oscillator/filter primitives and two 8580 coefficient tables are
adapted. Local code separates configuration from sampling, bounds arithmetic,
removes tune/digi/ADSR/combined-wave dependencies, adds the OP-1 adapter and
renders native controls. Attribution and the complete art prompts/references
also appear in the parent repository's `docs/design/c64/`.

`gen_svg.py` contours the original generated 1774×887 reference at a uniform
320/1774 scale. Filled pins and separate `#010101` cutouts retain the drawing's
palette; every filled path has one MOVE (native R246 joins compound contours).
The owner's 2026-10-17 hardware review moves art and native readouts up four
logical pixels. The follow-up asks for both synth and sequencer graphics to match
the synth's bottom leads, measured at about 1.6 logical pixels from native-frame
coverage. `display/lineweight.py` widens thin useful ink around its centreline;
already-wide fills remain. It preserves half-pixel black channels and local
topology, and leaves tiny source flecks alone. The generated figure keeps 95 paths
while reducing vertices. This replaces the first 0.45 px SID-only outline.

`art_check.py` reverses the translation and compares source/raster boundaries both
ways, allowing the deliberate width growth (p95 below one logical pixel, at least
99% within one pixel). The figure is static; native size-12 controls are unchanged.
No firmware font or TE asset is included.

`python3 check.py` runs ASan/UBSan endpoint/pitch/state tests, each green/white/red
control's audible effect in every mode, the production six-voice render wrapper
with changing pitch, and 49 unclipped native-font screen fixtures. `sid_audio.c`
produces dry host samples for representative listening/spectrum checks. These
checks do not establish hardware CPU budget or native ADSR release behavior;
`budget_check.py OUT` measures all six modes plus defaults on the real Blackfin
loader/voice-loop guest, six voices at C7–C8. It must run in a coordinated emulator
window; `--prepare-only` only compiles the fixture. Packet counts exclude
cache/SDRAM stalls and the calibrated CPU percentage is an estimate.
Targeted actual-emulator selection, sound, release and native screen acceptance
passed in the bounded journey below. No hardware load measurement is claimed.

`sid_journey.py NAND OUT --elf CORE_ELF --plugin SID.knl --content CONTENT_DIR`
observes the exact installed plugin text and prerequisite filter identities, selects SID
through real controls, plays six physical keys, and checks native release/silence.
The caller supplies a private same-core fixture; run through the coordinated queue.
`--prepare-only` rebuilds metadata without starting an emulator.

The first real-Blackfin six-voice fixture exceeded the calibrated model budget
(defaults about 111%, worst noise about 158%). The output-equivalent full-rate
optimization reduced defaults to 16,570 packets/voice (about 63% estimated CPU),
pulse endpoints to 19,196–21,774 (70–78%), and noise to 26,529–27,265 (91–93%).
Noise therefore has little modeled headroom for effects at six voices. A second
allocator/shift experiment regressed and was discarded; the retained plugin is
byte-identical to the better measured file, SHA256
`8c7b124422f860e799861efd32f5bee0b95dc5878d186a9af40b33759c3c1c82`.
The subsequent SVG-only correction changes the file hash but preserves the entire
initialized plugin image byte for byte, so these cost measurements still describe
the retained audio code.
These are packet-based estimates, not hardware load measurements.

The first actual SID selection stalled in AGG at `agg.cpp:339`, “alloc failed,
too many blocks”. The finite diagnostic confirmed a native geometry issue, not
a DSP failure. The corrected connected contours/cutouts passed actual selection and visual
review; host raster fidelity alone did not establish native acceptance.


On 2026-10-16, `run/sid-final/result.json` passed 18/18 checks in 76.20 s:
exact loaded plugin code; actual UI-selected SID; native POLY; one physical note
with a strong fundamental near its live phase increment (130.67 Hz observed,
130.81 expected, while the intended octave was the stronger spectral peak);
six distinct held notes assigned to six voices, with all six oscillator states
advancing and actual audio; individually paced releases reducing the native
held list 5→0; all native envelope states/active flags returning to zero; and
post-tail peak 0.000021, below the unchanged 0.0001 silence threshold. The SID
state then stayed unchanged. The source NAND remained unchanged.

The initial release test chose the wrong native envelope endpoint: stored
release 64 is long. Read-only snapshots proved every key had released and all
voices were in native release state 5, still decaying. The final real-UI setup
sets and verifies short release 16320. This was a harness correction, not a DSP
change. `pitch_check.py` likewise permits the deliberately voiced octave to be
stronger than the root, with wrong-octave-only and silence negative controls.

Accepted runtime file SHA256:
`25f7a6a029ab501d737a5d806393bb2fadfd9c2599d8771a7a1bee6bddcf3b11`.
Its entire initialized image SHA256 is
`29bb4483d2f67b010e86baab64a540b7cd0f7ba91dbe1fccb291adea85374315`,
byte-equal to the final 25-case cost file. The exact core ELF SHA256 is
`6c7926ed0aced050c0f33a2b3612d0902ff4d6a7d8cfd2fa53aaeb9e67487675`;
the snapshot emulator SHA256 is
`a6e4121267e9a1103f39f4d2c55d66a59a2e832bfa88b1a819a2b729d629bde9`.
Private evidence also remains under `run/sid-budget-final/`,
`run/sid-host/` and the earlier failed runtime/diagnostic directories. This
bounded default-sound journey does not claim an emulator sweep of every mode,
restart persistence or safe hardware headroom with heavy effects.

Private author archive SHA256: `98bc2da927b65ab8781b46dc5341b1113967b0b61aa05406877c0e5dcffa8b9d`.

The first translation check covered default and long native readouts. Its five
framebuffer-pixel upward shift is retained. The follow-up line-weight check uses
fresh default native captures for both artworks; no audio or performance claim is
added. The owner's OLED retest remains open.

### White cutoff response (2026-10-17)

White uses a logarithmic coefficient sweep over the original 8580 table's
6..3385 endpoints, rather than a linear index through that table. A 65-point
local response table is interpolated with all 15 control bits. Each coefficient
retains 12 additional fractional bits throughout the filter multiplication,
so the dark end is not quantized to whole Q12 coefficient values.

Every voice smooths live changes with a 1/256 per-sample pole (about 5.8 ms
time constant at 44.1 kHz). The first configuration after note reset starts at
the requested coefficient; it does not sweep up from zero on every note.
Extended-precision products split into bounded signed 32-bit multiplies; no
float, variable division or 64-bit multiply is added to the sample loop.
The default white value is now32136, keeping approximately the former default
coefficient2996. The screen's0..99 remains control position, not hertz.

This changes the knob law and interpolation, while retaining the cRSID-derived
filter topology and resonance table. The original cutoff table is retained as
reference source; the compiler can omit it from the plugin. No legacy patch
conversion is required. Built and updated locally without tests; listening and
hardware CPU acceptance remain open.

### Presets (2026-10-17)

`presets.py` writes8 settings-only AIFC sounds spanning all6 modes with the current controls: Round Bass, Chip Bass, Saw Lead, Pulse Keys, Soft Triangle, Sync Bite, Ring Bell and Noise Hats. The parent current-kennel bundle adds selected Plate/Warble/Crush and shallow Value LFO motion through `tools/presets/polish.py`. Native ADSR gates this engine; a dry host source continuing after note-off is expected. Source/FX spectrogram evidence and native acceptance limits are in the parent `docs/preset-review-2026-10-17.md`.

### Round Bass preset follow-up (2026-10-17)

SID Round Bass preset revoiced from near-solo triangle (blue256,green1500) to a half-duty three-oscillator pulse (blue1280,green16384), retaining white23000 lowpass cutoff and octave−1. Resonance red4500→0; native sustain20000→28000; attack/decay/release unchanged. FX/LFO remain off. This targets the prior native level outlier without changing SID DSP or plugin bytes. No tests or audio renders; resulting loudness/tone still needs listening acceptance.

Canonical authoring is `presets.py`; its generated `presets/round bass.aif` is read by the parent workshop. Existing native-review recordings predate this retune.
