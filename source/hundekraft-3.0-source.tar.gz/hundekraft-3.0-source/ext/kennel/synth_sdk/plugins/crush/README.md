# Crush

Loadable kennel effect `crush`, with no legacy order. Maiko #250's original algorithm
and custom artwork are ported under the owner's explicit permission given on
2026-10-16. This is reconstructed C, not a binary-identical firmware build. No TE
firmware, generic SVG, font, OTP or NAND is included.

Blue sets 1–16 bits; green sets sample rate from about 345 Hz to 44.1 kHz;
white sets 0–24 dB drive; red sets dry/wet mix. Defaults are 6 bits, about
8 kHz, 6 dB and fully wet. The drive has a soft knee before rounded bit
quantization and sample holding. Gain and mix ramp over each 64-sample block.
Synth/drum process mono. Master keeps separate left/right held samples with the
same reduction cadence. Each effect position owns independent state.

The DSP was reconstructed from the private #250 init at 0x01e4fd3c and render
at 0x01e4fd60; parameter normalization is at 0x01e4f648. Its exponential table
is regenerated mathematically. Portable saturation and explicit fixed-width
arithmetic replace machine-specific arithmetic. No sample-loop division or
64-bit arithmetic is required. Actual target performance remains unverified.

The three custom bitmap layers were recovered from descriptors at
0x01ea0df0+0x39c. `gen_svg.py` accepts only the private decoded region SHA256
`09c22c233dc9a84b6e9674f0a1670f5c8f0ca8331dc819d97d4133fd58681c7a`.
The original package is privately held as `firmware/op1_250.op1`, SHA256
`1fd0a0dbd25acf9c20e8eebf503a76280ef70dbc2334f8487ea8e6db723a3f17`.
The generator preserves layer coordinates and RGB565/4-bit-alpha composition,
clips the original negative top coordinate (the recovered draw helper uses descriptor
pixels directly on a 319/160 canvas, with no inferred inward translation), and emits absolute M/L/Z paths.
The rails and animated plots reconstruct screen 0x01e511a0's geometry. Kennel's
native font supplies the four parameter corners, with original labels and white values.
Rate uses the recovered compact decimal-kHz format; mix displays 00–99.
Font bytes are not bundled.
Raster antialiasing and reconstructed animation mean pixel identity is not claimed.

Run `python3 check.py` for ASan/UBSan DSP properties and 20 active/idle endpoint/default
full-screen layout fixtures. They exercise dry/full-resolution identity, hold
cadence, mono/stereo agreement and channel/instance independence. Screen bounds
use the native-font host model; sizes 14/40 are not device calibrated. These
checks do not establish original-firmware audio identity, actual emulator text
rendering or hardware CPU load. Targeted actual boot/selection/audio/screens are
still pending.

## Screen placement (2026-10-17)

Owner hardware polish raises the static art, live geometry and native readouts twelve
logical pixels, plus another four pixels for lower labels/readouts (40px values now y98). The full-screen bypass veil keeps its canvas
bounds. Crush’s hanging cable is cropped at the top edge after translation.
