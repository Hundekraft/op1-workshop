# C64 arp

A musical-clock arpeggiator inspired by C64 player pitch tables. This plugin sends
ordinary OP-1 notes to the selected instrument. It does not emulate SID oscillators,
register waveforms or 50 Hz pitch-register writes.

Primary references: Lasse Öörni's [GoatTracker v2.72 manual, section 3.4.1](https://github.com/leafo/goattracker2/blob/master/readme.txt)
describes relative/negative/absolute pitch entries, frame delays and looping table
rows. Linus Walleij's authored [SID-player pseudocode](https://codebase64.net/doku.php?id=base:a_sid_player_routine)
explains MIDI-root-relative arpeggio macros. These inform the table concept; the
kennel implementation is original C, not copied player source.

Choose `c64arp` in the sequencer browser, use the standard SEQ button to enable it,
and hold a root key. The orange knob changes Gate (10–100%) without restarting.
PLAY is not required. Releasing the last held key silences it unless latch is on.
A new root takes priority; on release the highest remaining physical key becomes
root. STOP and player reset release the output and clear held/latch roots.
A fresh root is needed after STOP. Playback follows the stock player's delivery
of keys/ticks; there is no second Run control.

Default encoder page:

| Encoder | Control |
|---|---|
| Blue | Major, minor, major 7, minor 7, fifth, sus4, major up/down, minor up/down presets |
| Green | 1/4, 1/8, 1/8 triplet, 1/16, 1/16 triplet, 1/32, 1/32 triplet, 1/64 |
| White | One to four octave cycles |
| Orange | Note length (Gate), 10–100%; same setting on both pages |

Press any encoder to switch the whole screen between play and edit pages. On the
edit page, blue selects a row, green edits its relative semitone offset (−24 to +24),
white edits dwell (1–8 base steps), and orange edits note gate (10–100%). Shift
plus blue changes length (1–16 rows); Shift plus orange enables/disables latch.
Table/length/dwell edits mark the preset `custom`; selecting a preset replaces its
rows. Shortening a table past its current playback position releases immediately
and restarts its position at row 1. Notes outside MIDI 0–127 are silent steps.

Each mode (synth/drum) keeps its own settings and table in versioned SQLite rows
`c64arpseq`. Loading validates every range. Playback, note IDs, held keys and a
latched root are never saved. A normal synth save/restart journey verifies the
settings and table return with playback stopped and no held or latched root.
Drum settings are independent; drum restart persistence has not been exercised.

The unchanged owner-requested image `c64arp-art.png` was generated on 2026-10-16
with OpenAI image generation; original reference and prompt are in OP1-Emulator
`docs/design/c64/`. Its entire 1774×887 canvas maps uniformly to 320×160, followed by the owner-requested four-pixel upward translation
(2026-10-17 hardware review). The right readouts and footer move by the same amount. The SVG starts with measured flat colors and half-strength source boundaries,
then applies the owner-requested line weight and screen translation; raster
antialiasing differs.
The live controls occupy the reserved right region; a footer shows the current row.
The illustration is static. No TE fonts, screens or firmware bytes are included.

Current validation: focused sanitizer timing/release tests, 36 stroke-text
endpoint states and the source/contour raster comparison (undoing the four-pixel translation; four colors, both directions,
95th-percentile distance below one logical pixel after the requested width growth and at least 99% within 1 pixel). The Blackfin .knl packs
without unresolved libc imports. The real-input emulator journey verifies the
selected plugin's code and embedded SVG path, major-table notes/audio, release and
latch behavior, mode-change and STOP cleanup, maximum row editing, and a normal
synth save/restart with exact settings and replay. Native play/edit/restart screens
are reviewed separately. The write session and matched-NAND restart are separate
recorded phases; an earlier harness screenshot after normal exit failed before
launching its restart. No MIDI delivery or hardware load claim is made.

The 2026-10-17 hardware polish is checked against actual default, long-footer and
edit-page frames (row 16, offset −24, dwell 8, gate 100). The default framebuffer
is exactly the earlier frame shifted up five framebuffer pixels (four screen
units), including the footer. That translation is retained. The owner's follow-up
matches both artworks' thin ink to the synth's bottom leads (about 1.6 logical px
from native-frame coverage). `display/lineweight.py` preserves broad fills,
black channels and topology instead of uniformly inflating already-bold leads.
The palette and original 445 path count remain; vertices decrease. Native fonts
and readouts are unchanged. Fresh default native captures check this refinement;
the owner's hardware OLED review remains open.


## SVG text compaction (2026-10-17)

`gen_svg.py` finishes with the shared `display/compact_svg.py` serializer. It keeps
all coordinates, colours, contours, IDs and the four-pixel raise. It removes unused
stroke parameters from unstroked fills and whitespace around explicit M/L/Z commands.
The SVG text drops from 137,207 to 101,613 bytes; the plugin file is 110,616 bytes.
No tests or rendered comparisons were run for this owner-requested text-only change.

2026-10-18 control change: Run removed at owner request. Earlier runtime evidence above predates this change; no tests or native captures were run for it.
