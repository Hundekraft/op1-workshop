/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "arp.h"
static const int8_t presets[8][8]={
 {0,4,7},{0,3,7},{0,4,7,11},{0,3,7,10},{0,7,12},{0,5,7},{0,4,7,12,7,4},{0,3,7,12,7,3}};
static const uint8_t lengths[8]={3,3,4,4,3,3,6,6};
static const uint8_t ticks[8]={96,48,32,24,16,12,8,6};
static void silence(arp_state *s){if(s->sounding>=0){arp_output_off(s->sounding);s->sounding=-1;}}
void arp_stop(arp_state *s){silence(s);s->run=s->started=0;s->step=s->octave=0;s->elapsed=0;s->root=-1;s->rootkey=0;for(unsigned i=0;i<24;i++)s->keys[i]=-1;}
void arp_bounds_changed(arp_state *s){
 if(s->step>=s->cfg.length||s->octave>=s->cfg.octaves){silence(s);s->step=s->octave=s->started=0;s->elapsed=0;}
}
void arp_preset(arp_state *s,unsigned n){
 silence(s);n&=7;s->cfg.preset=n;s->cfg.length=lengths[n];s->cfg.select=0;
 for(unsigned i=0;i<ARP_STEPS;i++){s->cfg.offset[i]=i<lengths[n]?presets[n][i]:0;s->cfg.dwell[i]=1;}
 s->started=0;s->step=s->octave=0;s->elapsed=0;
}
void arp_init(arp_state *s){
 s->sounding=-1;s->root=-1;s->rootkey=0;s->run=s->started=s->step=s->octave=0;s->elapsed=0;
 for(unsigned i=0;i<24;i++)s->keys[i]=-1;
 s->cfg.rate=3;s->cfg.octaves=1;s->cfg.gate=75;s->cfg.latch=0;arp_preset(s,0);
}
void arp_key(arp_state *s,unsigned key,int note,int pressed){
 if(key>=24)return;
 if(pressed){s->keys[key]=(int16_t)note;s->root=(int16_t)note;s->rootkey=(int16_t)key;}
 else{
  s->keys[key]=-1;
  if(s->cfg.latch)return;
  s->root=-1;for(unsigned i=0;i<24;i++)if(s->keys[i]>=0){s->root=s->keys[i];s->rootkey=(int16_t)i;}
  if(s->root<0){silence(s);s->started=0;s->step=s->octave=0;s->elapsed=0;}
 }
}
void arp_tick(arp_state *s,int mode){
 if(!s->run||s->root<0)return;
 unsigned duration=ticks[s->cfg.rate]*s->cfg.dwell[s->step];
 if(s->started){
  s->elapsed++;
  if(s->elapsed>=duration){s->elapsed=0;s->step++;
   if(s->step>=s->cfg.length){s->step=0;if(++s->octave>=s->cfg.octaves)s->octave=0;}
   s->started=0;
  }else if(s->elapsed>=duration*s->cfg.gate/100)silence(s);
 }
 if(!s->started){
  silence(s);int note=s->root+s->cfg.offset[s->step]+s->octave*12;
  if(note>=0&&note<=127)s->sounding=(int16_t)arp_output_on(mode,note,s->rootkey,100);
  s->started=1;
 }
}
