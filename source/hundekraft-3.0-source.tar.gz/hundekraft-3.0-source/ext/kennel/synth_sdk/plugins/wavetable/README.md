# WAVETABLE

### Output polish (2026-10-17)

Bounded static level compensation across wave/cutoff/resonance, ramped after the waveshaper; no automatic gain detector. Current kennel only; historical2.x engine sources and preset controls remain unchanged. Method, calibration and native emulator evidence: parent `docs/engine-level-polish-2026-10-17.md`. Physical CPU/listening acceptance remains separate.
