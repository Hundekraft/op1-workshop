# ELG

### Output polish (2026-10-17)

Bounded base-timbre/interval gain compensation preserves the internal moving cutoff, swell and quieter drones. Current kennel only; historical2.x engine sources and preset controls remain unchanged. Method, calibration and native emulator evidence: parent `docs/engine-level-polish-2026-10-17.md`. Physical CPU/listening acceptance remains separate.
