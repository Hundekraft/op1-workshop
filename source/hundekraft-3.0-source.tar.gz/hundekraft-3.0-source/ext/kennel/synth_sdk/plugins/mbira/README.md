# MBIRA

Original Hundekraft modal thumb-piano engine for kennel. Four decaying partials, a strike transient and wooden-box resonance form each note; optional Double, Wah and Buzz add processing. The core supplies six voices and the normal T2 amplitude envelope. The engine does not allocate additional voices or extend the stock release.

## Rapid-note setup update (2026-10-19)

Note-on calculates only the tine levels it needs. Ratio interpolation uses an exact 32-bit decomposition instead of a 64-bit helper. A bounded 16-entry audio-thread coefficient history lets different voice slots reuse matching TINE/RING/DOUBLE/pitch-bucket settings; existing voice-local caches remain.

Rendered output, envelope behavior, presets and six-voice allocation are unchanged. The first three-note attack falls from 42,110 to 40,806 instruction packets (~3.1%); steady-state cost is essentially unchanged. These are emulator instruction counts, not hardware deadline acceptance.

The real-key fixture rises from one to six active release tails, stays capped at six, then releases every voice. The owner's dry homemade-patch red-peak/crackle report remains a hardware acceptance item; it is not attributed to Father or an observed note leak.

`harness/mbira_check.py` covers sanitizer/audio/continuity and exact cached/recomputed behavior. Parent report: `docs/father-mbira-performance-2026-10-19.md` in OP1-Emulator; evidence: `run/father-opt-2026-10-19/`.
