/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission; Maiko #250 port authorized by the owner. See plugins/warble/README.md. */
/* Maiko #250 Warble algorithm port; see README.md for provenance and limits. */
#ifndef WARBLE_DSP_H
#define WARBLE_DSP_H
#include <stdint.h>
#define WB_RING 2048
#define WB_BLOCK 64
typedef struct {
 uint32_t phase[2], write;
 int32_t lp[2], mix, depth;
 int16_t ring[2][WB_RING];
} wb_state;
void wb_init(wb_state *s);
void wb_process(wb_state *s,int16_t *left,int16_t *right,const int32_t q15[4]);
uint32_t wb_rate(int32_t q15);
int32_t wb_sine(uint32_t phase);
#endif
