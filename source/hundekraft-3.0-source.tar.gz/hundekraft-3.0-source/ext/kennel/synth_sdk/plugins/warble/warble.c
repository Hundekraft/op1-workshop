/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission; Maiko #250 port authorized by the owner. See plugins/warble/README.md. */
#include "op1_plugin.h"
#include "warble_dsp.h"
/* Scratch is owned by the active effect at each position. State+two2048-sample
 * delay lines use <9KiB of the176460-byte area. No allocation or shared voice. */
volatile uint32_t warble_blocks[3];
static wb_state *state(int pos) { return (wb_state *)op1_fx_scratch(pos); }
static void init(int pos) { wb_state *s=state(pos);if(s)wb_init(s); }
static void render_stereo(int pos,int16_t *l,int16_t *r,const int16_t *p) {
 wb_state *s=state(pos);if(!s)return;int32_t q[4];
 for(int i=0;i<4;i++)q[i]=op1_fx_param_q15(p,i);
 wb_process(s,l,r,q);warble_blocks[pos%3]++;
}
static void render(int pos,int16_t *b,const int16_t *p) { render_stereo(pos,b,0,p); }
const op1_fx_stereo_t FX_warble={{init,render,{0,0,0,0}},render_stereo};
