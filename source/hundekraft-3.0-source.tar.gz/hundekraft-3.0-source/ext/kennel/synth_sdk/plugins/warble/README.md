# Warble

Independent loadable kennel effect, canonical name `warble`. No legacy order is assigned.
The original Maiko #250 algorithm and custom cassette artwork are ported with the owner's
explicit permission on 2026-10-16. This is a source reconstruction, not a binary-identical build.
No TE firmware, generic screen, font, OTP or NAND is included.

The four controls are exponential rate, squared depth, wet tone and dry/wet mix.
The original guide gives about .05–10 Hz and 0–9 ms; those are reference units,
not measured current hardware ranges. Half mix gives chorus; full mix gives
vibrato. Synth/drum use mono processing. Master processes separate left/right delay
lines with both right modulation phases one quarter-cycle ahead. Each position owns
its entire state in its effect scratch buffer.

The recovered modulation combines two interpolated sine waves, weighted 3:1, whose
increments have ratio 37:16. The long combined wobble replaces a simple single-period
LFO. The 2048-sample delay, Q8 interpolation, per-block depth/mix ramps and tone pole
follow the recovered integer algorithm. Mathematical sine/exp tables are regenerated.
Differences: portable C saturation/arithmetic; eager small-buffer clearing; vector-raster
antialiasing rather than the original private raster; runtime font for the parameter chrome (the host screen test uses geometry lettering).
Parameter readouts use rounded 00–99 values; rate remains exponential across that range.

Private reference: original package `firmware/op1_250.op1`, decrypted only locally under
`build/warble250-private`. DSP init 0x01e4ff90/render 0x01e4ffb8; param normalization
0x01e4f648; screen 0x01e51566 (index 1); six custom-alpha-art descriptors at
0x01ea0df0 + 0x42c. Only the custom Warble art was converted to SVG, preserving its
coordinates, RGB565 colors and alpha. Dynamic hubs/tape retain the procedural geometry.
Private decoded-region SHA256: `09c22c233dc9a84b6e9674f0a1670f5c8f0ca8331dc819d97d4133fd58681c7a`.
`gen_svg.py` accepts only that region and extracts the six custom art descriptors.
The SVG composites alpha into RGB and uses only the firmware-supported absolute
M/L/Z path subset. The artwork extraction excludes the firmware's font and generic SVG.

Static recovery and focused host checks do not establish original-firmware audio identity
or current hardware performance. Original #250 reference boot is not yet accepted.

Accepted private runtime evidence: corrected 300-preset fixture, core ELF SHA256
`6c7926ed0aced050c0f33a2b3612d0902ff4d6a7d8cfd2fa53aaeb9e67487675`.
`run/new-plugins-warble300/journey/result.json` proves selected Warble, synth audio and
FX OFF bypass. Its label OCR gate fails on TONE while the actual image clearly shows it;
that image was reviewed. `followup/result.json` proves all four real knob changes, maximum
raw mix, drum/master audio and independent per-position callback counters.
`followup/stereo-proof.json` records 2962 direct stereo-callback return blocks; 1452 contain
distinct L/R buffers (maximum channel difference 940). The inspected boundary is the
actual master callback return before output mixing, not the mono SPORT recording.

The original maximum readout was 98 due to flooring; the GUI-only rounding correction
has focused host string/position/bypass tests. The corrected actual 99 capture is
`run/fx-crush-final/work/ui/warble-max99.png`, reviewed by the lead. The final
simple-rectangle cassette artwork is contained and native-safe in that capture.
No pristine Maiko #250 runtime or hardware CPU/load measurement is claimed.

Clock scope: the recovered original mono/master wrappers and the port process
64 samples per channel. All 257 sine and 33 exp entries match the original, as
does the minimum phase increment of 4870. Current master traces advance 2.9024 ms
per block (about 22.05 kHz). Original Maiko runtime cadence remains unmeasured;
this does not prove an inherited hardware discrepancy. No DSP retuning was applied.

## Screen placement (2026-10-17)

Owner hardware polish raises the static art, live geometry and native readouts twelve
logical pixels, plus another four pixels for lower labels/readouts (40px values now y98). The full-screen bypass veil keeps its canvas
bounds.
