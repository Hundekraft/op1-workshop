/* Sound naming: hold a sound key to save, keep holding and a letter grid opens; press the same sound key again to
 * save under the typed name, as Maiko Pruett's #249 does. A clean re-implementation from the behaviour in
 * docs/maiko-rebuild.md (no #249 code or bytes).
 *
 * When R246's hold-to-save is about to save (OP1_EV_SAVE_HOLD, kennel/kn_save.c) naming holds the save back
 * (op1_snapshot_defer) and opens the core's text entry: the wide grid below, up to 12 characters (#249's limit).
 * The same sound key pressed again finishes it and R246 saves that sound under the name (op1_snapshot_save; R246
 * adds _1, _2 when the name is taken). A mode key or an empty name saves under R246's own date stamp. Releases are
 * not presses, so the release of the key that opened the grid does nothing.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../op1_feature.h"

#define NAMING_MAX 12
/* key codes of sound keys 1..8: 1..3 are 0x2D..0x2F, 4..8 are 0x10..0x14 (op1emu gui/ui.json, docs/firmware/input.md;
 * seq is 0x15 right after sound key 8). Found in the emulator: a table in key order missed the confirm. */
static const uint8_t sound_key[8] = {0x2D, 0x2E, 0x2F, 0x10, 0x11, 0x12, 0x13, 0x14};

static volatile int nm_kind = -1, nm_slot;     /* the held-back save; -1: none */

static void nm_done(const char *text, int ok)  /* main loop */
{
    int kind = nm_kind;
    nm_kind = -1;
    if (kind < 0) return;
    if (op1_snapshot_save(kind, nm_slot, ok ? text : "")) op1_toast("sound not saved");
}

static int nm_entry_key(int code, int pressed, int shift)   /* KeyHandler, before the entry's own handling */
{
    (void)shift;
    if (!pressed || nm_kind < 0 || code != sound_key[nm_slot]) return 0;   /* releases and other keys: the entry's */
    op1_text_entry_close(1);                    /* the same sound key again: save under the name */
    return 1;
}

/* the wide knob-coded grid (owner): 13 per row, a..z, then digits, '-', '_' and space. R246 takes all three: factory
 * presets use space and '-' ("low end", "k-pulse"), its own snapshot names '_' (%i%02i%02i_%02i%02i, _%d). */
static const char nm_charset[] = "abcdefghijklm" "nopqrstuvwxyz" "0123456789-_ ";
static const op1_text_entry_t nm_entry = { "NAME", 0, nm_charset, NAMING_MAX, 13, nm_done, nm_entry_key };

static void nm_event(int id, int32_t arg)       /* main loop */
{
    if (id != OP1_EV_SAVE_HOLD || op1_text_entry_open()) return;
    int kind = arg >> 8 & 0xff, slot = arg & 0xff;
    if (kind > 1 || slot > 7) return;
    nm_kind = kind; nm_slot = slot;
    if (op1_text_entry(&nm_entry)) { nm_kind = -1; return; }   /* no grid: stock saves under its stamp */
    op1_snapshot_defer();
}

static const char *const nm_claims[] = { "snapshot.save", 0 };   /* one feature holds the hold-to-save back */
const op1_feature_t FEATURE_naming = {
    .api = OP1_FEATURE_API, .priority = 600, .name = "naming", .event = nm_event, .claims = nm_claims,
};
