/* Scale mode: locks the keyboard to a key and scale, as Maiko Pruett's #249 scale utility does. A clean
 * re-implementation from the behaviour documented in hundekraft's OP1-Emulator repo (docs/maiko249-audit.md, the
 * manual's Scale mode section, emulator screenshots); no #249 code or bytes.
 *
 * Rule: each white key plays the scale note with its letter (C lydian: the F key plays F#; D major: the C key plays
 * C#), the key spelled from the root (Db, Eb, F#, Ab, Bb for black roots), so the seven white keys of an octave
 * play the seven degrees. A black key plays if it is in the scale, else it is silent. OFF passes every note.
 *
 * A stage of the core's note pipeline (op1_feature.h, priority 100: before chord), so it also shapes MIDI in and the
 * sequencers, which reach VoiceCtl through the same calls. Shift + key sequencer shortcuts read the key before
 * VoiceCtl, so they should stay untouched (#249 snapped the key index itself, workshop issue #1).
 * Settings: the core's settings service (scale.root, scale.type), read at boot. Controls: the input filter (#249:
 * synth T2 with Shift held, white = key, orange = scale); the key is published to the music context (op1_music).
 * Behaviour spec: docs/maiko-rebuild.md.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "../screens/stroke_font.h"
#include "scale.h"

#ifdef OP1_HOST
extern void (*host_vc_note_on)(const op1_note *), (*host_vc_note_off)(const op1_note *);
extern uint8_t host_shift;
void host_text_align(void *t, int a);
#define SC_NOTE_ON(next, n)   host_vc_note_on(n)
#define SC_NOTE_OFF(next, n)  host_vc_note_off(n)
#define SC_SHIFT              host_shift
#define T_SET_ALIGN(t, a)     host_text_align((t), (a))
#else
#define SC_NOTE_ON(next, n)   op1_note_on(next, n)
#define SC_NOTE_OFF(next, n)  op1_note_off(next, n)
#define SC_SHIFT              (*(volatile uint8_t *)0x01DD7F78)
#define T_SET_ALIGN(t, a)     (*(int32_t *)((uint8_t *)(t) + 0x60) = (a))    /* 1 = centred on x (screens/oblique.c) */
#endif

/* semitones of the seven degrees above the root; index = scale_type - 1 */
static const uint8_t degrees[SCALE_TYPES - 1][7] = {
    { 0, 2, 4, 5, 7, 9, 11 },   /* major */
    { 0, 2, 3, 5, 7, 8, 10 },   /* minor */
    { 0, 2, 3, 5, 7, 9, 10 },   /* dorian */
    { 0, 1, 3, 5, 7, 8, 10 },   /* phrygian */
    { 0, 2, 4, 6, 7, 9, 11 },   /* lydian */
    { 0, 2, 4, 5, 7, 9, 10 },   /* mixolydian */
    { 0, 1, 3, 5, 6, 8, 10 },   /* locrian */
    { 0, 2, 3, 5, 7, 8, 11 },   /* harmonic minor */
    { 0, 2, 3, 5, 7, 9, 11 },   /* melodic minor */
};
static const int8_t white_letter[12] = { 0, -1, 1, -1, 2, 3, -1, 4, -1, 5, -1, 6 };   /* C..B = 0..6, black -1 */
static const uint8_t root_letter[12] = { 0, 1, 1, 2, 2, 3, 3, 4, 5, 5, 6, 6 };       /* C Db D Eb E F F# G Ab A Bb B */

static volatile uint8_t sc_root, sc_type;       /* 0..11; 0 = OFF, 1..9 = degrees[] */
static uint8_t held[128];                       /* per input note: emitted note + 1, 0 = none (silent or not held) */
static uint8_t count[128];                      /* inputs holding each output note (F and F# keys -> F# in D major) */

int scale_map(int n, int root, int type)
{
    if (n < 0 || n > 127 || type <= 0 || type >= SCALE_TYPES) return n;
    const uint8_t *iv = degrees[type - 1];
    int pc = n % 12;
    if (white_letter[pc] < 0) {
        for (int d = 0; d < 7; d++)
            if (iv[d] == (pc - root + 12) % 12) return n;
        return -1;
    }
    int target = (root + iv[(white_letter[pc] - root_letter[root] + 7) % 7]) % 12;
    int out = n + (target - pc + 18) % 12 - 6;  /* nearest note with that pitch class */
    return out < 0 || out > 127 ? -1 : out;
}

void scale_set(int root, int type)
{
    sc_root = (uint8_t)(((root % 12) + 12) % 12);
    sc_type = (uint8_t)(type > 0 && type < SCALE_TYPES ? type : 0);
}
int scale_root(void) { return sc_root; }
int scale_type(void) { return sc_type; }

#define SC_SILENT 0xFF                          /* held[]: a key this stage silenced (outputs are 1..128) */
static void sc_note_on(const op1_note *n, int next)
{
    (void)next;
    int k = n->note;
    if (k >= 0 && k <= 127 && held[k] == SC_SILENT) return;                /* silenced and held: stays silent */
    if (k < 0 || k > 127 || held[k]) { SC_NOTE_ON(next, n); return; }      /* out of range or already held: as is */
    int out = scale_map(k, sc_root, sc_type);
    if (out < 0) { held[k] = SC_SILENT; return; }                           /* silent: its note off is dropped too */
    held[k] = (uint8_t)(out + 1);
    if (count[out]++) return;
    op1_note copy = *n;
    copy.note = out;
    SC_NOTE_ON(next, &copy);
}

static void sc_note_off(const op1_note *n, int next)
{
    (void)next;
    int k = n->note;
    /* not ours: as is. A silenced key's off is dropped: passed on, it would end a note another key or a later
     * stage (chord) sounds at that pitch. */
    if (k < 0 || k > 127 || !held[k]) { SC_NOTE_OFF(next, n); return; }
    if (held[k] == SC_SILENT) { held[k] = 0; return; }
    int out = held[k] - 1;
    held[k] = 0;
    if (--count[out]) return;
    op1_note copy = *n;
    copy.note = out;
    SC_NOTE_OFF(next, &copy);
}

/* ---- controls (#249: synth T2 with Shift held, white turns the key, orange the scale) ----
 * The input filter takes white and orange turns on that view; each detent changes the setting, saves it, publishes
 * the key to the music context and shows it as a toast; the overlay below shows the whole key while Shift is held. */
#define SC_SCREEN 40                /* synth T2 with Shift held: playmode.svg (docs/firmware/ui.md); emulator check open */
#define DETENT 1024                 /* encoder delta per tick (2 quadrature edges, docs/firmware/input.md): stock's unit */
static const char *const root_names[12] = {"c", "db", "d", "eb", "e", "f", "f#", "g", "ab", "a", "bb", "b"};
static const char *const type_names[SCALE_TYPES] = {"off", "major", "minor", "dorian", "phrygian", "lydian",
    "mixolydian", "locrian", "harm minor", "mel minor"};

static uint16_t sc_mask(void)
{
    uint16_t m = 0;
    if (sc_type)
        for (int d = 0; d < 7; d++) m |= (uint16_t)(1u << degrees[sc_type - 1][d]);
    return m;
}

static void sc_show(void)
{
    char t[32];
    int k = 0;
    for (const char *s = "scale "; *s; s++) t[k++] = *s;
    if (sc_type) { for (const char *s = root_names[sc_root]; *s; s++) t[k++] = *s; t[k++] = ' '; }
    for (const char *s = type_names[sc_type]; *s; s++) t[k++] = *s;
    t[k] = 0;
    op1_toast(t);
}

/* the user changed the key or scale: save, publish, show */
static void sc_changed(void)
{
    op1_setting_set("scale", "root", sc_root);
    op1_setting_set("scale", "type", sc_type);
    op1_music_publish("scale", sc_type != 0, sc_root, sc_mask());
    sc_show();
}

static int32_t knob_acc[2];
int scale_turn(int knob, int delta)         /* knob 2 white (key), 3 orange (scale); 1 = a step was taken */
{
    int32_t *acc = &knob_acc[knob - 2];
    if ((*acc > 0 && delta < 0) || (*acc < 0 && delta > 0)) *acc = 0;   /* direction change: start over */
    *acc += delta;
    if (*acc > -DETENT && *acc < DETENT) return 0;
    int st = *acc > 0 ? 1 : -1;
    *acc = 0;
    if (knob == 2) scale_set(sc_root + st, sc_type);
    else {
        int t = sc_type + st;
        scale_set(sc_root, t < 0 ? 0 : t >= SCALE_TYPES ? SCALE_TYPES - 1 : t);
    }
    sc_changed();
    return 1;
}

static int sc_input(const op1_input *in)
{
    if (in->type != OP1_IN_KNOB || !in->shift || in->screen != SC_SCREEN || in->code < 2 || in->code > 3) return 0;
    scale_turn(in->code, in->delta);
    return 1;                               /* consumed: stock does nothing with these on that view */
}

/* ---- the scale view: drawn under the stock PLAYMODE / PORTAMENTO text of synth T2 with Shift held (Gfx thread) ----
 * As #249: stock keeps the top of the screen (its text ends at y 70; blue and green still turn play mode and
 * portamento), we draw below it in the chord page's style (chord/chord.c): a two-octave keyboard from F (the OP-1's
 * lowest key) with green dots on the keys that play, the root's keys lavender, a red sharp or flat over a white key
 * that plays its letter's sharp or flat, the silent black keys dark; then the KEY and SCALE lanes under the white
 * and red encoders. */
#define STROKE 0x600                /* 1.5 px */
#define PART 0x800                  /* 2 px knob parts */
static const uint8_t c_white[4] = {0xff, 0xff, 0xff, 255}, c_text[4] = {0xdf, 0xd9, 0xff, 255},
    c_grey[4] = {0x7c, 0x79, 0x90, 255}, c_dark[4] = {0x38, 0x35, 0x72, 255},
    c_green[4] = {0x00, 0xed, 0x95, 255}, c_red[4] = {0xff, 0x3a, 0x5d, 255}, c_fill[4] = {0x01, 0x01, 0x01, 255};
static const int32_t ident[9] = {1024, 0, 0, 0, 1024, 0, 0, 0, 1024};
static const uint8_t strip_pc[14] = {5, 7, 9, 11, 0, 2, 4, 5, 7, 9, 11, 0, 2, 4};     /* white keys F..E, F..E */
static const char *const type_lower[SCALE_TYPES] = {"off", "major", "minor", "dorian", "phrygian", "lydian",
    "mixolyd", "locrian", "h.minor", "m.minor"};       /* <= 7 characters: the lane is 70 px (as chord) */
/* The firmware font has one case, so "db" would read DB: the root is its letter (Text) and a sharp or flat in
 * strokes after it as a superscript (lane() below). */
static const char *const root_letter_s[7] = {"c", "d", "e", "f", "g", "a", "b"};
static int root_acc(int root) { return (root - (int)degrees[0][root_letter[root]] + 18) % 12 - 6; }   /* -1, 0, 1 */
#define LANE_CW 8

enum { T_KEY, T_SCALE, T_COUNT };
static uint32_t sc_txt[T_COUNT][OP1_TEXT_SIZE / 4];
static char sc_shown[T_COUNT][16];
static int sc_made;
static int same(const char *a, const char *b) { while (*a && *a == *b) a++, b++; return *a == *b; }
static void tx(int i, const char *s, void *r)               /* set only on change: op1_text_set reallocates */
{
    if (!same(sc_shown[i], s)) {
        int k = 0;
        for (; s[k] && k < 15; k++) sc_shown[i][k] = s[k];
        sc_shown[i][k] = 0;
        op1_text_set(sc_txt[i], sc_shown[i]);
    }
    op1_text_draw(sc_txt[i], r, ident);
}

static void ln(void *r, int x0, int y0, int x1, int y1, int w, const uint8_t *c) { sf_line(r, x0, y0, x1, y1, w, c); }
static void fill(void *r, int x0, int y0, int x1, int y1, const uint8_t *c)   /* px, butt-capped band */
{
    if (x1 - x0 > y1 - y0) ln(r, x0 << 10, ((y0 + y1) << 10) / 2, x1 << 10, ((y0 + y1) << 10) / 2, (y1 - y0) << 10, c);
    else ln(r, ((x0 + x1) << 10) / 2, y0 << 10, ((x0 + x1) << 10) / 2, y1 << 10, (x1 - x0) << 10, c);
}
static void box(void *r, int x, int y, int w, int h, const uint8_t *c)        /* px */
{
    ln(r, x << 10, y << 10, (x + w) << 10, y << 10, STROKE, c); ln(r, (x + w) << 10, y << 10, (x + w) << 10, (y + h) << 10, STROKE, c);
    ln(r, (x + w) << 10, (y + h) << 10, x << 10, (y + h) << 10, STROKE, c); ln(r, x << 10, (y + h) << 10, x << 10, y << 10, STROKE, c);
}
/* 16-gon (chord.c); filled = one ring at half the radius as wide as the radius (AGG block budget) */
static const int16_t ring_x[17] = {1024, 946, 724, 392, 0, -392, -724, -946, -1024, -946, -724, -392, 0, 392, 724, 946, 1024};
static void ring(void *r, int cx, int cy, int rad, int w, const uint8_t *c)   /* Q10 */
{
    for (int i = 0; i < 16; i++) {
        int j = (i + 4) % 16, k = (i + 5) % 16;
        ln(r, cx + ring_x[i] * (rad >> 10), cy + ring_x[j] * (rad >> 10), cx + ring_x[i + 1] * (rad >> 10), cy + ring_x[k] * (rad >> 10), w, c);
    }
}
/* a sharp (acc > 0) or flat h px tall, centred on cx, its foot at y (px) */
static void accidental(void *r, int cx, int y, int h, int acc, const uint8_t *c)
{
    int u = (h << 10) / 8;                                  /* Q10: an 8-unit glyph */
    int32_t X = cx << 10, Y = y << 10;
    if (acc > 0) {
        ln(r, X - u, Y - 8 * u, X - u, Y, STROKE, c); ln(r, X + u, Y - 8 * u, X + u, Y, STROKE, c);
        ln(r, X - 3 * u, Y - 5 * u, X + 3 * u, Y - 6 * u, STROKE, c); ln(r, X - 3 * u, Y - 2 * u, X + 3 * u, Y - 3 * u, STROKE, c);
    } else if (acc < 0) {
        ln(r, X - 2 * u, Y - 9 * u, X - 2 * u, Y, STROKE, c);
        ln(r, X - 2 * u, Y - 4 * u, X + u, Y - 5 * u, STROKE, c); ln(r, X + u, Y - 5 * u, X + 2 * u, Y - 3 * u, STROKE, c);
        ln(r, X + 2 * u, Y - 3 * u, X - 2 * u, Y, STROKE, c);
    }
}

/* the keyboard (owner pick P1, docs/design/scale-overlay/concepts/P1.png): one thin frame, white keys as dividers,
 * narrower black keys, larger dots on one baseline with the sharp / flat above them */
#define KEY_X 6
#define KEY_W 22
#define KEY_TOP 78                  /* 8 px under the stock text (it ends at y 70) */
#define KEY_BOT 110
#define BLACK_BOT 96
#define BLACK_HW 6                  /* black key half width */
#define DOT_Y (KEY_BOT - 5)
static void keyboard(void *r, int root, int type)
{
    for (int i = 0; i < 14; i++) {                          /* white keys F..E, F..E */
        int x0 = KEY_X + i * KEY_W, pc = strip_pc[i], out = scale_map(60 + pc, root, type) % 12;
        int is_root = type && out == root, acc = (out - pc + 18) % 12 - 6;
        if (is_root) fill(r, x0 + 2, KEY_TOP + 2, x0 + KEY_W - 2, KEY_BOT - 2, c_text);
        if (i) ln(r, x0 << 10, KEY_TOP << 10, x0 << 10, KEY_BOT << 10, STROKE, c_grey);
        ring(r, (x0 + KEY_W / 2) << 10, DOT_Y << 10, 3 << 9, 3 << 10, is_root ? c_fill : c_green);   /* 3 px dot */
        if (acc) accidental(r, x0 + KEY_W / 2, DOT_Y - 5, 7, acc, c_red);
    }
    box(r, KEY_X, KEY_TOP, 14 * KEY_W, KEY_BOT - KEY_TOP, c_grey);
    for (int i = 0; i < 13; i++) {                          /* black keys between white keys i and i + 1 */
        int pc = (strip_pc[i] + 1) % 12;
        if (white_letter[pc] >= 0) continue;               /* E-F, B-C: no black key */
        int cx = KEY_X + (i + 1) * KEY_W, plays = scale_map(60 + pc, root, type) >= 0;
        int is_root = type && pc == root;
        fill(r, cx - BLACK_HW, KEY_TOP + 1, cx + BLACK_HW, BLACK_BOT, is_root ? c_text : c_fill);
        box(r, cx - BLACK_HW, KEY_TOP, 2 * BLACK_HW, BLACK_BOT - KEY_TOP, plays ? c_grey : c_dark);
        if (plays) ring(r, cx << 10, (BLACK_BOT - 5) << 10, 3 << 9, 3 << 10, is_root ? c_fill : c_green);
    }
}

/* a lane under its encoder (P1): ring icon, the value (size-12 Text as chord's: size 16 ran "mixolyd" off the screen),
 * the label under it; k 2 white, 3 red. LANE_CW: an estimate of the size-12 character width, to place the root's sign
 * (check on the unit) */
#define LANE_Y 116                  /* value top */
static void lane(void *r, int k, int t, const uint8_t *c, int filled, const char *value, int acc, const char *label)
{
    int x = 40 + 80 * k;
    if (filled) ring(r, (x - 30) << 10, 123 << 10, 7 << 9, (7 << 10) + (1 << 9), c);
    else ring(r, (x - 30) << 10, 123 << 10, 6 << 10, PART, c);
    tx(t, value, r);
    if (acc) accidental(r, x - 19 + LANE_CW + 3, LANE_Y + 6, 7, acc, c);   /* superscript: top at the cap top */
    sf_text(r, (x - 19) << 10, 130 << 10, 1229, label, STROKE, c_grey);   /* 7 px capitals, ends at y 137 */
}

void scale_draw(void *r)
{
    if (!sc_made) {                                         /* once, on the first frame (as the core's toast) */
        op1_text_ctor(sc_txt[T_KEY], OP1_Q10(21 + 160), LANE_Y, 12, c_white);
        op1_text_ctor(sc_txt[T_SCALE], OP1_Q10(21 + 240), LANE_Y, 12, c_red);
        sc_made = 1;
    }
    int root = sc_root, type = sc_type;
    keyboard(r, root, type);
    lane(r, 2, T_KEY, c_white, 0, root_letter_s[root_letter[root]], root_acc(root), "KEY");
    lane(r, 3, T_SCALE, c_red, type != 0, type_lower[type], 0, "SCALE");
}

static void sc_overlay(void *r, int32_t screen)
{
    if (screen == SC_SCREEN && SC_SHIFT) scale_draw(r);
}

static void sc_event(int id, int32_t arg)   /* main loop */
{
    (void)arg;
    if(id==OP1_EV_NOTES_RESET){for(int i=0;i<128;i++){held[i]=0;count[i]=0;}}
    if (id == OP1_EV_BOOT_DONE)
        scale_set(op1_setting_get("scale", "root", 0), op1_setting_get("scale", "type", 0));
}

static const char *const sc_claims[] = { "key:synth:shift+t2", 0 };    /* white / orange turns on that view */
const op1_feature_t FEATURE_scale = {
    .api = OP1_FEATURE_API, .priority = 100, .name = "scale",
    .note_on = sc_note_on, .note_off = sc_note_off, .event = sc_event, .input = sc_input,
    .claims = sc_claims, .overlay = sc_overlay,
};
