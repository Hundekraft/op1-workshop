#!/usr/bin/env python3
"""Our synths and effects as op1r-src plugins (private candidate, see docs/log 2026-10-13).

    python3 tools/firmware/op1r_plugins.py sdk DEST [--base B]   copy the base's op1r-src synth_sdk to DEST with our plugins added
    python3 tools/firmware/op1r_plugins.py build DEST   ... and compile op1r's code image with them (our toolchain)
    python3 tools/firmware/op1r_plugins.py base DEST    ... and the whole firmware with all our engines listed, as op1r
                                                        patch data plus DEST/reference.op1 and reference-cap300.op1
builder.py uses cached_base() instead: the same build without our DB rows and SVGs (variants add the selected ones).

Each engine/effect gets plugins/<id>/ in the copy: a plugin.json with order = marker - 0x5300 (so saved presets keep
their meaning), one wrapper per source file that compiles our unchanged C with the builder's per-engine renames,
and <id>_plugin.c, which adapts our callbacks to op1_plugin.h:
  synth   note_off(self) -> <id>_note_off(self, zeros)   (none of ours reads the knobs there)
  fx      init(pos) -> reset(pos); render(pos, buf[64], raw params) -> process(pos, buf, 64, knobs 0..32767)
          with the builder host's fixed filter ranges (tools/engines/op1r_host.c fx_knobs)
  screen  init = iter's on_load + <id>_screen_load; update = animate, iter's draw, draw over the canvas
          (the same wrapping op1r_host.c does today)
Under op1r's host harness (OP1_HOST) the wrapper maps voice objects to 0xFFB00000 + i*0x24 and copies the pitch
increments, so the engines run with their own ENGINE_HOST_TEST paths.
Our effects' delay lines (.fxbuf, NOLOAD) get their own section at FXBUF_ADDRESS in the copied link.ld; after
op1r's .bss they would run past 0x01EF0000.
A profile with 'plugin_region' links every plugin's code and data (op1r's and ours, build/plugins_*.o) to that
address instead (.plugtext) and loads it as its own LDR block: op1r's core image must end below Maiko's 0x01E40000,
and with all plugins in it there is no room left (docs/log 2026-10-14).
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
SDK = ROOT / 'ext/op1r-src/synth_sdk'           # the base's op1r-src and op1r (patcher) checkouts: select()
PATCHER = ROOT / 'ext/op1r27'
PLUGIN_REGION = None                             # profile 'plugin_region': plugin code outside op1r's core image
DEVUPD = False                                   # profile 'devupd': firmware update over SysEx hooked in (docs/sysex-update.md)
KENNEL = False                                   # profile 'kennel': the source is the kennel core (loadable plugins as .knl)
# Kennel names every plugin by one id ([a-z0-9_-], <= 15: folder, file stem, kennel.off, inventory; ext/kennel
# docs/plugin-format.md "Names"); its saved name is the id with '_' as ' ' (drumplus: "drum+"). A 2.x catalog id
# that is a saved name maps to the kennel id by that rule. The 2.x utility ids are bundle ids, not plugin names:
# 'files' is kennel's 'file'. Maiko #249 itself is never patched into a kennel build (kennel rebuilds the four tools).
KENNEL_UTILITY = {'files': 'file'}
# op1r-src make_firmware.DEV_HOOKS: the two calls the SysEx update needs, with R246's original bytes
DEVUPD_HOOKS = {0x019F01B8: ('_du_boot_access', bytes.fromhex('05e37c52')),   # boot: access(te-boot.op1) -> apply a staged update first
                0x019E3CC8: ('_du_rx_poll', bytes.fromhex('ffe36efa'))}       # midi_poll: CALL midi_rx_parse -> copy our SysEx first


def select(profile):
    """Use a plugins base profile's checkouts (profiles.py 'source', 'directory'); the default is op1r27-plugins."""
    global SDK, PATCHER, PLUGIN_REGION, DEVUPD, KENNEL
    SDK = ROOT / profile['source'] / 'synth_sdk'
    PATCHER = ROOT / profile['directory']
    PLUGIN_REGION = profile.get('plugin_region')
    DEVUPD = bool(profile.get('devupd'))
    KENNEL = bool(profile.get('kennel'))
    if KENNEL:                                   # make_firmware packs .knl files with <KENNEL_ROOT>/tools/kennel/pack.py
        os.environ['KENNEL_ROOT'] = str(ROOT / profile['source'])
        os.environ['KENNEL_TOOLCHAIN'] = str(ROOT / 'toolchain')   # our compiler (GCC), wherever the checkout is
MAGIC = 0x5300
FXBUF_ADDRESS = 0x01F80000
PRESET_TABLE = 0x01F00000                        # 300-preset option: the synth patch table, as a zero-fill block
PRESET_TABLE_MAX = (169 + 33 + 300 + 16) * 56    # its size at cap 300 (preset_cap)
GCC = ROOT / 'toolchain/bfin-gcc/bin/bfin-elf-gcc'
BINUTILS = ROOT / 'toolchain/bfin/bin'
SYNTH_DEFAULTS = [16384, 8192, 0, 8192]          # builder.py synth_types rows
FX_RAW_DEFAULTS = [7296, 12288, 11264, 20480]    # mkfw.FX_DEFAULTS (raw filter words)
FX_RANGES = [(64, 14528), (0, 24576), (0, 22528), (8192, 32767)]


def catalog_plugins():
    catalog = json.loads((HERE / 'catalog.json').read_text())
    out = []
    if KENNEL:
        return out                              # kennel has hundekraft's engines as its own plugins (files)
    for group, kind, folder in (('synths', 'synth', 'engines'), ('effects', 'fx', 'fx')):
        for f in catalog[group]:
            out.append({'id': f['id'], 'kind': kind, 'order': f['marker'] - MAGIC,
                        'dir': ROOT / 'tools' / folder / f['id']})
    return out


def q15_defaults(raw):
    """raw filter words -> 0..32767 that op1r's patch_db maps back to the same raw words"""
    out = []
    for v, (lo, hi) in zip(raw, FX_RANGES):
        q = ((v - lo) * 32767 + (hi - lo) - 1) // (hi - lo)
        assert lo + q * (hi - lo) // 32767 == v, (v, lo, hi)
        out.append(q)
    return out


def renames(p):
    x = p['id']
    if p['kind'] == 'fx':
        r = {'fx_reset': x + '_fx_reset', 'fx_process': x + '_fx_process'}
        r.update({'engine_screen_' + f: x + '_fx_screen_' + f for f in ('load', 'animate', 'draw')})
    else:
        r = {'engine_' + f: x + '_' + f for f in ('note_on', 'render', 'note_off')}
        r.update({'engine_screen_' + f: x + '_screen_' + f for f in ('load', 'animate', 'draw')})
    return r


SCREEN = '''
#ifndef OP1_HOST
__attribute__((weak)) void {s}_load(void *s) {{ (void)s; }}
__attribute__((weak)) void {s}_animate(void *s) {{ (void)s; }}
__attribute__((weak)) void {s}_draw(void *s, void *c) {{ (void)s; (void)c; }}
#define ITER_SCREEN_VT ((const uint32_t *)0x019103FCu)        /* +0x1C draw, +0x24 on_load */
static void screen_init(void *s)
{{
    ((void (*)(void *))ITER_SCREEN_VT[0x24 / 4])(s);
    {s}_load(s);
}}
static void screen_update(void *s, int dt)
{{
    {s}_animate(s);
    ((int (*)(void *, int))ITER_SCREEN_VT[0x1C / 4])(s, dt);
    {s}_draw(s, ((void *(*)(void))0x01A3B490)());
}}
const op1_screen_t SCREEN_{x} = {{ screen_init, screen_update }};
#endif
'''

SYNTH = '''/* Generated by tools/firmware/op1r_plugins.py: hundekraft {x} (tools/engines/{x}) as an op1r plugin. */
#include "op1_plugin.h"
void {x}_note_on(void *, const int16_t *);
void {x}_render(void *, int16_t *, const int16_t *);
void {x}_note_off(void *, const int16_t *);
#ifdef OP1_HOST
uint32_t engine_host_pitch[128];
#define VOICE(self) ((void *)(uintptr_t)(0xFFB00000u + op1_voice_index(self) * OP1_VOICE_SIZE))
#else
#define VOICE(self) (self)
#endif
static const int16_t no_knobs[8];
static void note_on(void *self, const int16_t *p) {{ {x}_note_on(VOICE(self), p); }}
static void render(void *self, int16_t *out, const int16_t *p)
{{
#ifdef OP1_HOST
    for (int i = 0; i < OP1_BLOCK; i++) engine_host_pitch[i] = (uint32_t)OP1_PITCH_INC[i];
#endif
    {x}_render(VOICE(self), out, p);
}}
static void note_off(void *self) {{ {x}_note_off(VOICE(self), no_knobs); }}
const op1_engine_t ENGINE_{x} = {{ note_on, render, note_off, {{0, 0, 0, 0}} }};
'''

FX = '''/* Generated by tools/firmware/op1r_plugins.py: hundekraft {x} (tools/fx/{x}) as an op1r plugin. */
#include "op1_plugin.h"
void {x}_fx_reset(int);
void {x}_fx_process(int, int16_t *, int, const int16_t *);
static const int16_t lo[4] = {{64, 0, 0, 8192}}, hi[4] = {{14528, 24576, 22528, 32767}};
static void init(int pos) {{ {x}_fx_reset(pos); }}
static void render(int pos, int16_t *buf, const int16_t *params)
{{
    int16_t k[8];
    for (int i = 0; i < 4; i++) {{
        int32_t v = params[i];
        if (v < lo[i]) v = lo[i];
        if (v > hi[i]) v = hi[i];
        k[i] = (int16_t)(((v - lo[i]) * 32767) / (hi[i] - lo[i]));
    }}
    for (int i = 4; i < 8; i++) k[i] = params[i];
    {x}_fx_process(pos, buf, OP1_FX_BLOCK, k);
}}
const op1_fx_t FX_{x} = {{ init, render, {{0, 0, 0, 0}} }};
'''


def write_plugins(sdk):
    sdk = Path(sdk)
    for p in catalog_plugins():
        x, d = p['id'], sdk / 'plugins' / p['id']
        if d.exists():
            raise SystemExit(f'{d} exists (an op1r plugin with our name?)')
        d.mkdir(parents=True)
        defines = ''.join(f'#define {a} {b}\n' for a, b in renames(p).items())
        sources = [x + '_plugin.c']
        for src in sorted(p['dir'].glob('*.c')):
            name = f'{x}_src_{src.stem}.c'
            (d / name).write_text('/* Generated by tools/firmware/op1r_plugins.py */\n#ifdef OP1_HOST\n'
                                  '#define ENGINE_HOST_TEST\n#define FX_HOST_TEST\n#endif\n'
                                  f'{defines}#include "{src}"\n')
            sources.append(name)
        prefix = x + ('_fx_screen' if p['kind'] == 'fx' else '_screen')
        text = (FX if p['kind'] == 'fx' else SYNTH).format(x=x) + SCREEN.format(s=prefix, x=x)
        (d / sources[0]).write_text(text)
        (d / (x + '.svg')).write_bytes(svg(p))
        meta = {'name': x, 'kind': p['kind'], 'order': p['order'],
                'symbol': ('FX_' if p['kind'] == 'fx' else 'ENGINE_') + x, 'sources': sources,
                'defaults': q15_defaults(FX_RAW_DEFAULTS) if p['kind'] == 'fx' else SYNTH_DEFAULTS,
                'screen': {'svg': x + '.svg', 'symbol': 'SCREEN_' + x}}
        (d / 'plugin.json').write_text(json.dumps(meta, indent=2) + '\n')


def svg(p):
    sys.path.insert(0, str(ROOT / 'tools/engines'))
    import mkfw
    path = p['dir'] / (p['id'] + '.svg')
    return mkfw.svg_with_bases(path.read_bytes(), path)


def patch_link(sdk):
    ld = Path(sdk) / 'link.ld'
    text = ld.read_text()
    anchor = '  .l1tramp 0xFFA0BFB4'
    assert anchor in text and '.fxbuf' not in text
    line = (f'  .fxbuf 0x{FXBUF_ADDRESS:08X} (NOLOAD) : {{ *(.fxbuf*) }}   '
            '/* hundekraft effects\' delay lines (op1r_plugins.py) */\n')
    text = text.replace(anchor, line + anchor, 1)
    if PLUGIN_REGION:
        # before .text: the first matching rule takes a section, so op1r's *(.text*) must not see the plugins
        assert PRESET_TABLE + PRESET_TABLE_MAX <= PLUGIN_REGION < FXBUF_ADDRESS
        core = '  . = 0x01E00000;\n'
        assert text.count(core) == 1 and '.plugtext' not in text
        text = text.replace(core, f'  .plugtext 0x{PLUGIN_REGION:08X} : {{ build/plugins_*.o(.text* .rodata* .data*) }}'
                                  '   /* plugins, own LDR block (op1r_plugins.py) */\n' + core, 1)
    ld.write_text(text)


def add_plugin_block(ldr_path, elf):
    """Insert .plugtext as a loaded LDR block before the FINAL block (op1r's make_firmware writes only its core)."""
    sys.path.insert(0, str(ROOT / 'tools/engines'))
    import mkfw as M
    import tempfile
    lay = layout(elf)
    start, end = lay['plugtext']
    if end == start:                             # nothing compiled in (a kennel files core): no block
        return
    assert start == PLUGIN_REGION and start < end <= FXBUF_ADDRESS, (hex(start), hex(end))
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / 'plugtext.bin'
        subprocess.run([str(BINUTILS / 'bfin-elf-objcopy'), '-O', 'binary', '-j', '.plugtext', str(elf), str(out)],
                       check=True)
        data = out.read_bytes()
    assert len(data) == end - start
    data += b'\0' * (-len(data) % 4)
    d = Path(ldr_path).read_bytes()
    blocks = M.ldr_blocks(d)
    for _, flags, a, n, _ in blocks:
        if n and not flags & 0x1000 and a < start + len(data) and a + n > start:
            raise SystemExit(f'plugin region overlaps the LDR block at {a:#x}')
    final = next(o for o, flags, _, _, _ in blocks if flags & 0x8000)
    d = M.fix_first_header(d[:final] + M.header(0x0006, start, len(data), 0) + data + d[final:])
    Path(ldr_path).write_bytes(d)


def add_devupd_hooks(ldr_path, elf, mf):
    """Poke make_firmware's DEV_HOOKS (CALL du_boot_access / du_rx_poll) into OP1_vdk.ldr, original bytes checked.
    op1r's make_firmware only does this for --dev builds, which it refuses together with --release."""
    nm = subprocess.run([str(BINUTILS / 'bfin-elf-nm'), str(elf)], capture_output=True, text=True, check=True).stdout
    syms = {n: int(a, 16) for a, _, n in (l.split() for l in nm.splitlines() if len(l.split()) == 3)}
    d = bytearray(Path(ldr_path).read_bytes())
    for pc, (name, original) in DEVUPD_HOOKS.items():
        off = (syms[name] - pc) // 2
        assert -0x800000 <= off < 0x800000, f'{name} out of CALL range'
        off &= 0xFFFFFF
        mf.ldr_poke(d, pc, struct.pack('<HH', 0xE300 | off >> 16, off & 0xFFFF), original)
    Path(ldr_path).write_bytes(d)


def make_sdk(dest):
    dest = Path(dest)
    if dest.exists():
        raise SystemExit(f'{dest} exists')
    shutil.copytree(SDK, dest, ignore=shutil.ignore_patterns('build', 'out'))
    write_plugins(dest)
    patch_link(dest)
    return dest


def compile_image(sdk):
    """op1r's code image with every plugin (make_firmware.build's commands, with our toolchain, no Docker)"""
    sdk = Path(sdk).resolve()
    # a second base built in the same process must not reuse the first SDK copy's modules (plugins, gen_oblique,
    # kennel's pack): they point at that copy, which make_base has renamed by then
    for name, mod in list(sys.modules.items()):
        path = getattr(mod, '__file__', None) or ''
        if '/synth_sdk/' in path or '/tools/kennel/' in path:
            del sys.modules[name]
    sys.path[:0] = [str(sdk), str(sdk / 'display'), str(HERE)]
    import importlib.util
    import plugins
    import runtime as R
    spec = importlib.util.spec_from_file_location('op1r_make_firmware', sdk / 'make_firmware.py')
    mf = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mf)
    engs, fxs = plugins.load()
    for lst in (engs, fxs):                      # op1r-src with MAX_ORDER indexes its tables by order (gaps allowed)
        orders = [e['order'] for e in lst if 'order' in e]   # kennel: loadable files may have none (32..63 at boot)
        if hasattr(mf, 'MAX_ORDER'):
            assert len(set(orders)) == len(orders) and all(1 <= o <= mf.MAX_ORDER for o in orders), orders
        else:
            assert orders == list(range(1, len(lst) + 1)), orders
    (sdk / 'build').mkdir(exist_ok=True)
    font = sdk / 'build/opfont.svg'
    for m, data in R.unpack((ROOT / 'firmware/op1_246.op1').read_bytes()):
        if m.name == 'content/display/opfont.svg':
            font.write_bytes(data)
    import gen_oblique
    cards, _ = gen_oblique.build(str(font), str(sdk / 'screens/oblique/cards.txt'))
    gen_oblique.emit(cards, str(sdk / 'build/oblique_data.c'))
    mf.gen_table(engs, fxs)
    env = dict(os.environ, PATH=f'{GCC.parent}:{BINUTILS}:' + os.environ['PATH'])
    # make_firmware.build runs these in Docker; run them here with our toolchain
    mf.sh = lambda cmd: subprocess.run(cmd.split("sh -c '", 1)[1].rsplit("'", 1)[0] if 'docker run' in cmd else cmd,
                                       shell=True, check=True, cwd=sdk, env=env)
    cwd = os.getcwd()
    os.chdir(sdk)
    try:
        code, hooks, syms = mf.build(engs, fxs)
    finally:
        os.chdir(cwd)
    return code, hooks, syms, sdk / 'build/synth.elf'


def make_base(dest, firmware=None, ours=False):
    """dest/synth_sdk (with our plugins) -> dest/op1_246_custom (make_firmware --opz --release, as op1r releases are
    built) -> dest/patcher/data (op1r's build_patch.py: the same manifest format as the pinned op1r releases).
    Without `ours`, our synth_types/fx_types rows and screen SVGs are taken out of the tree before the patch data is
    made: the code is in the base, and builder.py adds the rows and SVGs of the selected engines per variant, as on
    the pinned op1r bases. dest/base.json records the layout and the Maiko input chain targets of this build."""
    dest = Path(dest).resolve()
    sdk = make_sdk(dest / 'synth_sdk')
    sys.path.insert(0, str(HERE))
    import runtime as R
    original = Path(firmware or ROOT / 'firmware/op1_246.op1').resolve()
    for m, data in R.unpack(original.read_bytes()):
        if data is not None:
            target = dest / 'op1_246' / m.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    _, _, _, elf = compile_image(sdk)
    import importlib.util
    spec = importlib.util.spec_from_file_location('op1r_make_firmware_main', sdk / 'make_firmware.py')
    mf = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mf)
    env = dict(os.environ, PATH=f'{GCC.parent}:{BINUTILS}:' + os.environ['PATH'])

    def sh(cmd):
        if 'repack' in cmd:                        # the .op1 comes from build_patch / the builder instead
            return
        inner = cmd.split("sh -c '", 1)[1].rsplit("'", 1)[0] if 'docker run' in cmd else cmd
        subprocess.run(inner, shell=True, check=True, cwd=sdk, env=env, capture_output=True)
    mf.sh = sh
    cwd = os.getcwd()
    os.chdir(sdk)
    import contextlib
    try:
        with (dest / 'make_firmware.log').open('w') as log, contextlib.redirect_stdout(log):
            mf.main(opz=True, release=True)
    finally:
        os.chdir(cwd)
    tree = dest / 'op1_246_custom'
    if PLUGIN_REGION:
        add_plugin_block(tree / 'OP1_vdk.ldr', elf)
    if DEVUPD:
        add_devupd_hooks(tree / 'OP1_vdk.ldr', elf, mf)
    if not ours:
        import sqlite3
        with sqlite3.connect(tree / 'content/op1_factory.db') as db:
            for p in catalog_plugins():
                table = 'fx_types' if p['kind'] == 'fx' else 'synth_types'
                db.execute(f'DELETE FROM {table} WHERE type=?', (p['id'],))
                (tree / 'content/display' / (p['id'] + '.svg')).unlink()
        db.close()
        if KENNEL:                               # plugin files: builder.py adds the chosen ones per variant
            (dest / 'files').mkdir()
            for path in sorted((tree / 'content').glob('*.knl')):
                shutil.move(path, dest / 'files' / path.name)
    patcher = dest / 'patcher'
    patcher.mkdir()
    for name in ('build_patch.py', 'patch_op1.py'):
        shutil.copy2(PATCHER / name, patcher / name)
    subprocess.run([sys.executable, '-I', str(patcher / 'build_patch.py'), str(original), str(tree),
                    '--reference', str(dest / 'reference.op1')], check=True, cwd=patcher, capture_output=True)
    if KENNEL:
        # build_patch's "plugins" lists the factory DB's plugin rows; kennel writes rows for numbered plugins that
        # are files now. On a kennel base it names what the core really compiles in (whole.py and other readers):
        # the engines / effects whose symbol is in the core's ELF, by saved name.
        nm = subprocess.run([str(BINUTILS / 'bfin-elf-nm'), str(elf)], capture_output=True, text=True, check=True).stdout
        symbols = {line.split()[-1] for line in nm.splitlines() if line.split()}
        compiled = {'synth': [], 'fx': []}
        for pj in sorted((sdk / 'plugins').glob('*/plugin.json')):
            meta = json.loads(pj.read_text())
            if meta.get('kind') in compiled and '_' + meta['symbol'] in symbols:
                compiled[meta['kind']].append(meta.get('saved_name', meta['name'].replace('_', ' ')))
        path = patcher / 'data/manifest.json'
        manifest = json.loads(path.read_text())
        manifest['plugins'] = compiled
        path.write_text(json.dumps(manifest, indent=1))     # as build_patch writes it
    lay = layout(elf)
    (dest / 'base.json').write_text(json.dumps({
        'op1r_src_commit': git_head(SDK), 'patcher_commit': git_head(PATCHER), 'ours_in_db': ours,
        'image_end': hex(lay['image_end']), 'bss': [hex(x) for x in lay['bss']], 'fxbuf': [hex(x) for x in lay['fxbuf']],
        'plugtext': [hex(x) for x in lay['plugtext']],
        **({'lander_flag': hex(lay['lander_flag'])} if lay.get('lander_flag') else {}),
        'seq_shift_wants': hex(lay['seq_shift_wants']) if lay['seq_shift_wants'] else None, 'devupd': DEVUPD,
        'utility_chains': [[hex(h), hex(c), hex(t)] for h, c, t in input_chains(dest)]}, indent=1) + '\n')
    return dest, lay


def git_head(path):
    return subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()


def input_chains(dest):
    """Maiko #249's two input chains on this build: (hook, chain word, op1r target). The targets move with the
    compiler and with our plugin code, so they are read from the built image and must land in op1r's code."""
    sys.path[:0] = [str(HERE), str(ROOT / 'tools/engines')]
    import runtime as R, mkfw as M, maiko249 as U
    ldr = dict((m.name, d) for m, d in R.unpack((Path(dest) / 'reference.op1').read_bytes()))['OP1_vdk.ldr']
    blocks = M.ldr_blocks(ldr)
    end = next(a + n for _, f, a, n, _ in blocks if a == 0x01E00000 and not f & 0x100)
    out = []
    for hook, chain, _ in U.CHAINS:
        at = M.ldr_word(ldr, blocks, hook)
        target = M.jump_l_target(hook, ldr[at:at + 4], 0xE300)
        if not 0x01E00000 <= target < end:
            raise SystemExit(f'{hook:#x}: input target {target:#x} is outside op1r\'s code')
        out.append((hook, chain, target))
    return tuple(out)


def base_key(firmware):
    """Content key of a generated base: op1r-src and patcher commits, our plugin sources, this script, the compiler."""
    import hashlib
    h = hashlib.sha256()
    for path in [HERE / 'op1r_plugins.py', HERE / 'catalog.json', ROOT / 'tools/engines/mkfw.py',
                 ROOT / 'tools/engines/engine.h', ROOT / 'tools/fx/fx.h', Path(firmware)] + \
            sorted(f for p in catalog_plugins() for f in p['dir'].iterdir() if f.is_file()):
        h.update(str(path.relative_to(ROOT) if path.is_relative_to(ROOT) else path.name).encode() + b'\0')
        h.update(path.read_bytes())
    if PLUGIN_REGION:
        h.update(b'plugin_region %x\0' % PLUGIN_REGION)
    if DEVUPD:
        h.update(b'devupd\0')
    if KENNEL:
        h.update(b'kennel\0')
    for repo in (SDK, PATCHER):
        h.update(git_head(repo).encode())
        if subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain', '--untracked-files=no']):
            raise ValueError(f'{repo} has local changes; use the pinned commit')
    h.update(subprocess.check_output([str(GCC), '--version']))
    return h.hexdigest()[:16]


def cached_base(firmware, work):
    """The generated base for this content key under work/, built once (about a minute) and reused."""
    import fcntl
    work = Path(work)
    work.mkdir(parents=True, exist_ok=True)
    dest = work / ('op1r-plugins-' + base_key(firmware))
    with (work / '.op1r-plugins.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if not (dest / 'base.json').exists():
            temp = dest.with_name(dest.name + '.tmp')
            shutil.rmtree(temp, ignore_errors=True)
            make_base(temp, firmware)
            temp.rename(dest)
    return dest


def preset_cap(ldr, cap=300):
    """The 300 user synth preset option over the plugin base: R246's 318-entry synth patch table moves to a zero-fill
    LDR block at PRESET_TABLE (the firmware constructs it at boot) and the gate, counts, asserts and table loads are
    patched as builder.py does today (mkfw.patch_synth_table, constants checked first). Sizes as op1r_host.c."""
    sys.path.insert(0, str(ROOT / 'tools/engines'))
    import mkfw as M
    count = 169 + 33 + cap + 16
    size = count * 56
    assert size <= PRESET_TABLE_MAX
    blocks = M.ldr_blocks(ldr)
    for _, flags, start, n, _ in blocks:
        if n and not flags & 0x1000 and start < PRESET_TABLE + size and start + n > PRESET_TABLE:
            raise SystemExit(f'preset table overlaps the LDR block at {start:#x}')
    assert PRESET_TABLE + size <= FXBUF_ADDRESS
    ldr = M.patch_synth_table(ldr, blocks, PRESET_TABLE, count, cap)
    final = next(o for o, flags, _, _, _ in blocks if flags & 0x8000)
    return M.fix_first_header(ldr[:final] + M.header(0x106, PRESET_TABLE, size, 0) + ldr[final:])


def with_preset_cap(op1_in, op1_out, cap=300):
    sys.path.insert(0, str(HERE))
    import runtime as R
    members = R.unpack(Path(op1_in).read_bytes())
    out = []
    for info, data in members:
        if info.name == 'OP1_vdk.ldr':
            data = preset_cap(data, cap)
            R.validate_ldr(data)
        out.append((info, data))
    Path(op1_out).write_bytes(R.pack_op1(R.pack_tar(out)))


def layout(elf):
    nm = subprocess.run([str(BINUTILS / 'bfin-elf-nm'), str(elf)], capture_output=True, text=True, check=True).stdout
    syms = {n: int(a, 16) for a, _, n in (l.split() for l in nm.splitlines() if len(l.split()) == 3)}
    fx = subprocess.run([str(BINUTILS / 'bfin-elf-objdump'), '-h', str(elf)], capture_output=True, text=True,
                        check=True).stdout
    fxbuf = next((int(l.split()[2], 16) for l in fx.splitlines() if ' .fxbuf ' in l), 0)
    plug = next(((int(l.split()[3], 16), int(l.split()[2], 16)) for l in fx.splitlines() if ' .plugtext ' in l), (0, 0))
    return {'image_end': syms['__image_end'], 'bss': (syms['__bss_start'], syms['__bss_end']),
            'fxbuf': (FXBUF_ADDRESS, FXBUF_ADDRESS + fxbuf), 'plugtext': (plug[0], plug[0] + plug[1]),
            'seq_shift_wants': syms.get('_seq_shift_wants'), 'lander_flag': syms.get('_kn_lander_enabled')}   # maiko249.SHIFT_STUB; op1r-src hk27-base and later


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument('command', choices=['sdk', 'build', 'base'])
    ap.add_argument('dest', type=Path)
    ap.add_argument('--base', default='op1r27-plugins', help='plugins base profile (profiles.py)')
    a = ap.parse_args()
    from profiles import BASES
    select(BASES[a.base])
    if a.command == 'base':
        dest, lay = make_base(a.dest, ours=True)
        with_preset_cap(dest / 'reference.op1', dest / 'reference-cap300.op1')
    else:
        sdk = make_sdk(a.dest)
    if a.command == 'build':
        _, _, _, elf = compile_image(sdk)
        lay = layout(elf)
    if a.command != 'sdk':
        print(f'image ends {lay["image_end"]:#x} (limit 0x1e40000), bss {lay["bss"][0]:#x}-{lay["bss"][1]:#x} '
              f'(limit 0x1ef0000), fxbuf {lay["fxbuf"][0]:#x}-{lay["fxbuf"][1]:#x}, '
              f'plugins {lay["plugtext"][0]:#x}-{lay["plugtext"][1]:#x}')


if __name__ == '__main__':
    main()
