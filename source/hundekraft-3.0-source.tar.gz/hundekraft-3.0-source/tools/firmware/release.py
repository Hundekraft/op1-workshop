#!/usr/bin/env python3
"""Build the published workshop site: release data for every bundle configuration plus the web app.

    python3 tools/firmware/release.py firmware/op1_246.op1 --output build/workshop-release
    ... --base op1r30mo-chord-plugins --version 2.7   a candidate on another base, with its own product version

The output directory must not exist. It is the complete Pages tree: compare it with the Pages checkout
(`diff -r --exclude .git`) and copy it there only when publishing is requested. Never point --output at the
Pages checkout.

Configurations: every synth/effect/preset-cap combination with the Maiko utilities either all on or all off
(the web app offers #249 as one bundle), 256 variants on 2.x bases. On kennel bases every plugin file is chosen at
patch time (runtime.variant_config / patch), so the release holds only the variants those fold to. op1r's own synths/effects are chosen at patch time in the
browser (config "hidden"), so they need no variants. The release identity comes from builder.release_identity;
this script only selects configurations and adds web/firmware, so editing it does not change the release id.
"""
import argparse
from pathlib import Path
import shutil
import struct
import sys
import zlib

import builder as B

BASE = 'op1r30mo-chord-plugins'


def bundle_configs(catalog):
    utilities = [f['id'] for f in catalog['utilities']]
    for config in B.all_configs(catalog):
        if config.get('utilities', []) in ([], utilities):
            yield config
            if any(f['id'] == 'lander' for f in catalog.get('core_options', [])):
                yield {**config, 'lander': True}


def feature_metadata(read, address):
    """Read the API-1 feature ABI from a target image, including its actual exclusive claims."""
    api, priority, name = struct.unpack('<HHI', read(address, 8))
    if api != 1:
        raise ValueError(f'Unsupported feature API {api}')

    def string(ptr):
        out = bytearray()
        for i in range(512):
            c = read(ptr + i, 1)
            if c == b'\0':
                return out.decode('ascii')
            out.extend(c)
        raise ValueError('Unterminated feature metadata string')

    claims = []
    pointer, = struct.unpack('<I', read(address + 64, 4))
    if pointer:
        for i in range(256):
            claim, = struct.unpack('<I', read(pointer + i * 4, 4))
            if not claim:
                break
            claims.append(string(claim))
        else:
            raise ValueError('Unterminated feature claims')
    return {'name': string(name), 'kind': 'feature', 'claims': claims,
            'claimsKnown': True, 'priority': priority}


def image_reader(image, base=0):
    def read(address, size):
        offset = address - base
        if offset < 0 or offset + size > len(image):
            raise ValueError('Feature metadata points outside its image')
        return image[offset:offset + size]
    return read


def plugin_metadata(data, loader, file_name=None):
    """The extension is advisory; runtime feature claims and priority come from the entry object."""
    plugin = loader.parse(data, api_version=1)
    canonical = Path(file_name).stem if file_name else plugin['type_name'].replace(' ', '_')
    if canonical == 'drum+':
        canonical = 'drumplus'
    info = {'name': canonical, 'savedName': plugin['type_name'], 'kind': {1: 'synth', 2: 'fx', 3: 'feature'}[plugin['kind']],
            'claims': [], 'claimsKnown': True, 'priority': None, 'source': 'knl'}
    if plugin['kind'] == loader.KIND_FEATURE:
        image = bytearray(plugin['image'])
        base = 0x10000000  # distinguish relocated local pointers from unrelocated numeric offsets
        # Only local pointer relocations are needed to read identity/claims. External imports are callbacks,
        # and must never be followed as if they were strings in this plugin.
        pointers = {off: (sym, addend) for off, typ, sym, addend in plugin['relocs'] if typ == loader.R_ABS32}
        for off, (sym, addend) in pointers.items():
            if sym == loader.SYM_LOCAL:
                struct.pack_into('<I', image, off, base + addend)
        read_image = image_reader(image, base)
        def read(address, size):
            if any(address <= base + off < address + size and sym != loader.SYM_LOCAL
                   for off, (sym, _) in pointers.items()):
                raise ValueError('Feature metadata refers to an external import')
            return read_image(address, size)
        info.update(feature_metadata(read, base + plugin['entry_offset']))
        if info['name'] != canonical:
            raise ValueError('Feature object and plugin file names differ')
    return info


def builtin_metadata(elf):
    """Defined FEATURE_* symbols in this exact linked ELF, never a source-tree builtin guess."""
    data = elf.read_bytes()
    if data[:6] != b'\x7fELF\x01\x01':
        raise ValueError('Expected ELF32 little-endian target core')
    shoff, = struct.unpack_from('<I', data, 32)
    entsize, count = struct.unpack_from('<HH', data, 46)
    sections = [struct.unpack_from('<10I', data, shoff + i * entsize) for i in range(count)]
    def read(address, size):
        for section in sections:
            _, typ, flags, addr, off, length, *_ = section
            if typ != 8 and flags & 2 and addr <= address and address + size <= addr + length:
                return data[off + address - addr:off + address - addr + size]
        raise ValueError('Builtin metadata points outside the linked core')
    out = []
    for section in sections:
        if section[1] != 2:
            continue
        strings = sections[section[6]]
        for offset in range(section[4], section[4] + section[5], section[9]):
            name, address, _, _, _, index = struct.unpack_from('<IIIBBH', data, offset)
            start = strings[4] + name
            symbol = data[start:data.index(b'\0', start)].decode('ascii')
            if index and address and symbol.startswith('_FEATURE_'):
                out.append({**feature_metadata(read, address), 'source': 'builtin'})
    return sorted(out, key=lambda item: item['name'])


def core_identity(elf, lander=False):
    """Inventory's exact .text/.rodata range, so plugin management can check without R246."""
    data = elf.read_bytes()
    if data[:6] != b'\x7fELF\x01\x01':
        raise ValueError('Expected ELF32 little-endian target core')
    shoff, = struct.unpack_from('<I', data, 32)
    entsize, count = struct.unpack_from('<HH', data, 46)
    sections = [struct.unpack_from('<10I', data, shoff + i * entsize) for i in range(count)]
    end, lander_flag = None, None
    for section in sections:
        if section[1] != 2:
            continue
        strings = sections[section[6]]
        for offset in range(section[4], section[4] + section[5], section[9]):
            name, address, _, _, _, index = struct.unpack_from('<IIIBBH', data, offset)
            start = strings[4] + name
            if index and data[start:data.index(b'\0', start)] == b'__core_ro_end':
                end = address
            if index and data[start:data.index(b'\0', start)] == b'_kn_lander_enabled':
                lander_flag = address
    start = 0x01E00000
    if end is None or not start < end < 0x01E40000:
        raise ValueError('Target core identity range is missing or invalid')
    image = bytearray(end - start)
    covered = bytearray(end - start)
    for _, typ, flags, addr, offset, length, *_ in sections:
        lo, hi = max(start, addr), min(end, addr + length)
        if typ != 8 and flags & 2 and hi > lo:
            image[lo-start:hi-start] = data[offset+lo-addr:offset+hi-addr]
            covered[lo-start:hi-start] = b'\1' * (hi-lo)
    if not all(covered):
        raise ValueError('Target core identity has unloaded gaps')
    if lander_flag is not None:
        if not start <= lander_flag <= end - 4 or image[lander_flag-start:lander_flag-start+4] != bytes(4):
            raise ValueError('Invalid Lander core option')
        struct.pack_into('<I', image, lander_flag-start, int(lander))
    elif lander:
        raise ValueError('Core does not support Lander option')
    return {'start': start, 'len': len(image), 'crc': zlib.crc32(image)}


def release_plugin_metadata(builder):
    """All file choices plus builtins from the generated target; fail closed on incomplete metadata."""
    if not builder.profile.get('kennel'):
        return None
    loader = B.module('release_knl_loader', B.ROOT / builder.profile['source'] / 'tools/kennel/reloc.py')
    generated = builder.generated
    files = []
    for path in sorted((generated / 'files').glob('*.knl')):
        files.append({**plugin_metadata(path.read_bytes(), loader, path.name), 'path': 'content/' + path.name})
    if not files:
        raise ValueError('Kennel target has no plugin files')
    return {'schema': 1, 'complete': True, 'plugins': files,
            'builtins': builtin_metadata(generated / 'synth_sdk/build/synth.elf')}


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('firmware', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--base', default=BASE, choices=B.BASES, help='release base (default: the published one)')
    parser.add_argument('--version', help='product version for a candidate (default: runtime.PRODUCT)')
    args = parser.parse_args()
    if args.version:
        B.R.PRODUCT.update(version=args.version, label='hundekraft ' + args.version, slug='hundekraft-' + args.version)
    output = args.output.resolve()
    if output.exists():
        parser.exit(1, f'{output} exists; choose a new directory\n')
    if (output / '.git').exists() or output.name == 'op1-workshop-pages':
        parser.exit(1, 'Refusing to write into a Pages checkout\n')
    builder = B.Builder(args.firmware, args.base)
    configs = list(bundle_configs(builder.catalog))
    B.require(len(configs) == 256 or B.R.file_choices(builder.catalog), f'Expected 256 bundle configurations, got {len(configs)}')
    # kennel bases: plugin files are chosen at patch time, so only the variants they fold to are built
    folded = {}
    for config in configs:
        variant = B.R.variant_config(B.R.normalize(config, builder.catalog), builder.catalog)
        folded.setdefault(B.R.config_id(variant, builder.catalog), variant)
    configs = list(folded.values())
    index = builder.prepare(output, configs)
    metadata = release_plugin_metadata(builder)
    if metadata is not None:
        index['plugin_metadata'] = metadata
        index['core'] = core_identity(builder.generated / 'synth_sdk/build/synth.elf')
        for key, entry in index['variants'].items():
            variant = B.json.loads((output / 'variants' / key / 'manifest.json').read_text())
            entry['core'] = core_identity(builder.generated / 'synth_sdk/build/synth.elf', variant['config'].get('lander', False))
        B.json_write(output / 'release.json', index)
    web = B.ROOT / 'web/firmware'
    for path in web.iterdir():
        if path.is_dir():
            shutil.copytree(path, output / path.name)
        else:
            shutil.copy2(path, output / path.name)
    print(f'Release {index["release"]["id"]} ({index["release"]["product"]["label"]}): '
          f'{len(index["variants"])} variants -> {output}')


if __name__ == '__main__':
    sys.exit(main())
