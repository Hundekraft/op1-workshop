/* "snowglobe": shimmer reverb. Four allpass diffusers into a four-line feedback delay network (Hadamard
 * mixing, damped), with an octave-up pitch shifter fed back into the tank, so tails climb an octave at a time.
 * blue   (knob 0): snowfall: decay, feedback 0.6 .. 0.985
 * green  (knob 1): shimmer: share of the feedback (on two of the four lines) that is the octave-up tail
 * white  (knob 2): globe size: delay lengths 40 .. 100 % (about 35 .. 90 ms per line)
 * red    (knob 3): shake: mix (dry 1 -> 0.5 while the wet rises 0 -> 1); the last few percent freeze the tail
 *                  (feedback 1, no damping, no new input)
 * Per sample: 4 allpasses, 4 delay reads/writes, 2 shifter reads, ~30 multiplies.
 */
#include "../fx.h"

#define LINE 4096
#define SHIFT 4096
#define WINDOW 2048                       /* pitch shifter grain, 46 ms */
enum { AP0 = 142, AP1 = 107, AP2 = 379, AP3 = 277 };    /* allpass lengths */
static const int16_t line_len[4] = {3557, 3617, 3491, 3422};   /* at full size */

/* 32-byte aligned (one Blackfin cache line) so that every buffer starts a new line at the same w (w % 16 == 0).
   PAD (one line, unused) staggers the buffers: unpadded they sit 1 KB / 8 KB apart and their lines at the same
   w compete for the same sets of the 2-way data cache. Only the first 512 / LINE entries are used. */
#define PAD 16
typedef struct {
    int16_t ap[4][512 + PAD];
    int16_t line[4][LINE + PAD];
    int16_t shift[SHIFT];
    int32_t lp[4], dc[4];
    uint32_t w, t;
} __attribute__((aligned(32))) state_t;

/* Line touch: the Blackfin data cache does not keep (we assume, see docs/log 2026-10-14) a line that only gets
   written, so each of the nine writes per sample went to SDRAM on its own. Reading the slot about to be written
   once per 32-byte line loads the line, and the next 16 writes hit it (written back later as one burst).
   The values read are not used: the sound is unchanged. */
static inline void touch_lines(state_t *s, uint32_t w)
{
    const volatile int16_t *const ap = &s->ap[0][0], *const ln = &s->line[0][0];
    (void)ap[0 * (512 + PAD) + (w & 511)];
    (void)ap[1 * (512 + PAD) + (w & 511)];
    (void)ap[2 * (512 + PAD) + (w & 511)];
    (void)ap[3 * (512 + PAD) + (w & 511)];
    (void)ln[0 * (LINE + PAD) + (w & (LINE - 1))];
    (void)ln[1 * (LINE + PAD) + (w & (LINE - 1))];
    (void)ln[2 * (LINE + PAD) + (w & (LINE - 1))];
    (void)ln[3 * (LINE + PAD) + (w & (LINE - 1))];
    (void)((const volatile int16_t *)s->shift)[w & (SHIFT - 1)];
}

static FX_BUFFER state_t st[FX_INSTANCES];
volatile uint32_t snowglobe_blocks;       /* for the screen */
volatile int32_t snowglobe_level;         /* tail level, 0 .. ~32767 */
volatile int32_t snowglobe_freeze;

void fx_reset(int inst)
{
    state_t *s = &st[inst];
    int16_t *p = &s->ap[0][0];
    for (unsigned i = 0; i < sizeof(state_t) / 2; i++) p[i] = 0;   /* whole state, all int16-sized */
    for (int l = 0; l < 4; l++) s->lp[l] = s->dc[l] = 0;
    s->w = 0;
    s->t = 0;
}

static inline int32_t allpass(int16_t *buf, int len, uint32_t w, int32_t x)
{
    const int32_t d = buf[(w - (uint32_t)len) & 511];
    const int32_t v = x - (d >> 1);                /* g = 0.5 */
    buf[w & 511] = fx_sat16(v);
    return d + (v >> 1);
}

/* the params as each instance hears them (after the LFO), for the screen */
volatile int16_t snowglobe_knobs[FX_INSTANCES][4];
volatile uint32_t snowglobe_kblocks[FX_INSTANCES];

void fx_process(int inst, int16_t *io, int n, const int16_t *knobs)
{
    for (int i = 0; i < 4; i++) snowglobe_knobs[inst][i] = knobs[i];
    snowglobe_kblocks[inst]++;
    state_t *s = &st[inst];
    const int32_t k0 = knobs[0] < 0 ? 0 : knobs[0], k1 = knobs[1] < 0 ? 0 : knobs[1];
    const int32_t k2 = knobs[2] < 0 ? 0 : knobs[2], k3 = knobs[3] < 0 ? 0 : knobs[3];
    const int freeze = k3 > 31500;
    const int32_t fb = freeze ? 32767 : 19661 + ((k0 * 12616) >> 15);   /* Q15, 0.6 .. 0.985 */
    const int32_t damp = freeze ? 32767 : 19661;                       /* one-pole low-pass in the loop */
    const int32_t shimmer = freeze ? 0 : (k1 * 16384) >> 15;           /* share of the feedback, up to 0.5 */
    const int32_t size = 13107 + ((k2 * 19660) >> 15);                 /* Q15, 0.4 .. 1.0 */
    const int32_t in_gain = freeze ? 0 : 9830;                         /* 0.3 into the tank */
    int32_t len[4];
    for (int l = 0; l < 4; l++) len[l] = (line_len[l] * size) >> 15;
    /* energy of the wet signal for the screen, without a per-sample 64-bit multiply (__muldi3): |wet| < 2^17
       (lp stays within the int16 line values, dc >> 5 too, so |y| < 2^16 and tank = sum / 2), so with
       |wet| = h * 512 + l (h < 256, l < 512): wet^2 = (h^2 << 18) + (2 h l << 9) + l^2, each summed in 32 bits */
    uint32_t e_hh = 0, e_hl = 0, e_ll = 0;

    /* the filter state stays in locals for the block (it was loaded and stored per sample); the four lines and
       the four allpasses are written out with their fixed lengths. Same arithmetic, same order. */
    int32_t lp0 = s->lp[0], lp1 = s->lp[1], lp2 = s->lp[2], lp3 = s->lp[3];
    int32_t dc0 = s->dc[0], dc1 = s->dc[1], dc2 = s->dc[2], dc3 = s->dc[3];
    int16_t *const l0 = s->line[0], *const l1 = s->line[1], *const l2 = s->line[2], *const l3 = s->line[3];
    const uint32_t len0 = (uint32_t)len[0], len1 = (uint32_t)len[1], len2 = (uint32_t)len[2], len3 = (uint32_t)len[3];
#define SG_LINE(buf, ln, lp, dc, y)                                                                            \
    const int32_t y = ((lp) += (((buf)[(w - (ln)) & (LINE - 1)] - (lp)) * damp) >> 15,                        \
                       (dc) += ((lp) * 32 - (dc)) >> 9,       /* DC estimate, Q5, ~14 Hz: rounding in the loop */ \
                       (lp) - ((dc) >> 5))                    /* builds DC when the feedback is near 1 */

    uint32_t w = s->w, t = s->t;
    for (int i = 0; i < n; i++) {
        if (!(w & 15)) touch_lines(s, w);
        const int32_t x = io[i];
        int32_t d = (x * in_gain) >> 15;
        d = allpass(s->ap[0], AP0, w, d);
        d = allpass(s->ap[1], AP1, w, d);
        d = allpass(s->ap[2], AP2, w, d);
        d = allpass(s->ap[3], AP3, w, d);

        /* tank: read, damp, Hadamard */
        SG_LINE(l0, len0, lp0, dc0, y0);
        SG_LINE(l1, len1, lp1, dc1, y1);
        SG_LINE(l2, len2, lp2, dc2, y2);
        SG_LINE(l3, len3, lp3, dc3, y3);
        const int32_t a = y0 + y1, b = y0 - y1, c = y2 + y3, e = y2 - y3;
        const int32_t o0 = (a + c) >> 1, o1 = (b + e) >> 1, o2 = (a - c) >> 1, o3 = (b - e) >> 1;
        const int32_t tank = (y0 + y1 + y2 + y3) >> 1;

        /* shimmer: two read heads sweeping through the last WINDOW samples twice as fast as they are
           written (an octave up), half a grain apart, with triangular crossfades */
        s->shift[w & (SHIFT - 1)] = fx_sat16(tank);
        const uint32_t ta = t & (WINDOW - 1), tb = (t + WINDOW / 2) & (WINDOW - 1);
        const int32_t ga = ta < WINDOW / 2 ? ta : WINDOW - ta, gb = WINDOW / 2 - ga;   /* sum WINDOW / 2 */
        const int32_t sa = s->shift[(w - (WINDOW - ta)) & (SHIFT - 1)];
        const int32_t sb = s->shift[(w - (WINDOW - tb)) & (SHIFT - 1)];
        const int32_t up = (sa * ga + sb * gb) >> 10;                 /* / (WINDOW / 2) */
        /* the octave-up tail replaces part of the feedback on lines 0 and 2, so the loop gain stays fb */
        const uint32_t wi = w & (LINE - 1);
        l0[wi] = fx_sat16(d + (((o0 + (((up - o0) * shimmer) >> 15)) * fb) >> 15));
        l1[wi] = fx_sat16(d + ((o1 * fb) >> 15));
        l2[wi] = fx_sat16(d + (((o2 + (((up - o2) * shimmer) >> 15)) * fb) >> 15));
        l3[wi] = fx_sat16(d + ((o3 * fb) >> 15));
        w++;
        t++;

        const int32_t wet = tank;
        io[i] = fx_sat16(x - ((x * k3) >> 16) + ((wet * k3) >> 15));
        const uint32_t aw = (uint32_t)(wet < 0 ? -wet : wet), h = aw >> 9, l = aw & 511;
        e_hh += h * h;
        e_hl += 2 * h * l;
        e_ll += l * l;
    }
#undef SG_LINE
    s->lp[0] = lp0; s->lp[1] = lp1; s->lp[2] = lp2; s->lp[3] = lp3;
    s->dc[0] = dc0; s->dc[1] = dc1; s->dc[2] = dc2; s->dc[3] = dc3;
    s->w = w;
    s->t = t;
    if (inst != FX_MASTER) {
        snowglobe_blocks++;
        snowglobe_freeze = freeze;
        int32_t r = 0;   /* integer square root of the mean square */
        const int64_t energy = ((int64_t)e_hh << 18) + ((int64_t)e_hl << 9) + e_ll;
        uint32_t m = (uint32_t)(energy / (n ? n : 1));
        for (uint32_t bit = 1u << 30; bit; bit >>= 2) {
            if (m >= (uint32_t)r + bit) { m -= (uint32_t)r + bit; r = (r >> 1) + (int32_t)bit; }
            else r >>= 1;
        }
        snowglobe_level = r;
    }
}
