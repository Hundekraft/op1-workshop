/*
 * An Opus manifest's `setting` lines -> kennel's packed settings table (docs/plugin-format.md "Settings table",
 * extension tag 7), for kn_settings_add_list (the OPUS PLUGINS list page, ARCHITECTURE.md "Settings page").
 * Included by opus/opus_boot.c (settings()) and the host test harness/settings_list_test.c, so the test packs the
 * bundled files' real lines. Static functions only (no core export); no libc.
 *
 * A line: `KEY CHOICE,CHOICE,... DEFAULT ["label"]` or `KEY MIN MAX DEFAULT ["label"]` (an ` if OTHER=VALUE` tail is
 * ignored). Labels and choices: upper case, the stroke font's characters (others become a space), at most
 * KN_SL_LABEL / KN_SL_CHOICE characters (kn_setpage.h); a number range gets at most 64 steps.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef OPUS_SETTAB_H
#define OPUS_SETTAB_H
#include <stdint.h>
#include "../kennel/kn_setpage.h"

static uint8_t *ost_put8(uint8_t *p, uint32_t v) { *p++ = (uint8_t)v; return p; }
static uint8_t *ost_put32(uint8_t *p, uint32_t v) { for (int i = 0; i < 4; i++) *p++ = (uint8_t)(v >> (8 * i)); return p; }
static uint8_t *ost_label(uint8_t *p, const char *s, uint32_t n, uint32_t max)   /* upper case, the stroke font's set */
{
    uint32_t k = 0;
    for (uint32_t i = 0; i < n && k < max; i++) {
        char c = s[i];
        if (c >= 'a' && c <= 'z') c = (char)(c - 32);
        if (!((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == ' ' || c == '-' || c == '+' || c == '/' ||
              c == '.' || c == ':' || c == '#' || c == '%' || c == '_' || c == ',')) c = ' ';
        *p++ = (uint8_t)c; k++;
    }
    while (k > 0 && p[-1] == ' ') p--, k--;
    if (!k) *p++ = '-';
    *p++ = 0;
    return p;
}
static const char *ost_tok(const char *s, const char *e, const char **te)   /* next word, or "quoted text" */
{
    while (s < e && (*s == ' ' || *s == '\t')) s++;
    if (s >= e) { *te = s; return 0; }
    if (*s == '"') { const char *q = ++s; while (q < e && *q != '"') q++; *te = q; return s; }
    const char *q = s;
    while (q < e && *q != ' ' && *q != '\t') q++;
    *te = q;
    return s;
}
static int32_t ost_num(const char *s, const char *e)
{
    int neg = s < e && *s == '-';
    int32_t v = 0;
    for (s += neg; s < e && *s >= '0' && *s <= '9'; s++) v = v * 10 + (*s - '0');
    return neg ? -v : v;
}
static int ost_is_num(const char *s, const char *e) { if (s < e && *s == '-') s++; if (s >= e) return 0; for (; s < e; s++) if (*s < '0' || *s > '9') return 0; return 1; }

/* the table's head: version 1, the row count (patched by ost_row's caller at tab[1]), the title (the plugin's name) */
static uint8_t *ost_head(uint8_t *p, const char *title, uint32_t n)
{
    p = ost_put8(p, 1); p = ost_put8(p, 0);
    return ost_label(p, title, n, 14);
}
/* one `setting` line (v, len) packed at p -> the end, or 0 when the line is skipped (malformed). *key / *keyn: the
 * key inside v; *def the default (a choice: its index); *nchoice the choice count (0: a number). At most ~300 bytes. */
static uint8_t *ost_row(uint8_t *p, const char *v, uint32_t len, const char **key, int *keyn, int32_t *defo, int *nchoice)
{
    const char *e = v + len, *a, *ae, *b, *be, *c, *ce, *d = 0, *de = 0, *lab, *labe;
    a = ost_tok(v, e, &ae); b = ost_tok(ae, e, &be); c = ost_tok(be + (be < e && *be == '"'), e, &ce);
    if (!a || !b || !c || ae - a > 15) return 0;
    int number = ost_is_num(b, be) && ost_is_num(c, ce);
    if (number) d = ost_tok(ce, e, &de);
    lab = ost_tok(number ? de : ce, e, &labe);
    if (lab && lab[-1] != '"' && labe - lab == 2 && lab[0] == 'i' && lab[1] == 'f') lab = 0;   /* ` if OTHER=VALUE`
                                   * (core 2.36) with no label: kennel's settings page has no hidden rows, so the row
                                   * always shows (as on a core before 2.36); the condition itself is not kept */
    if (number && !d) return 0;
    int32_t def = 0, mn = 0, mx = 0, st = 1;
    int nc = 0;
    if (number) {
        mn = ost_num(b, be); mx = ost_num(c, ce); def = ost_num(d, de);
        if (mx <= mn) return 0;
        st = (mx - mn + 63) / 64; if (st < 1) st = 1;
        mx = mn + (mx - mn) / st * st;
        if (def < mn) def = mn;
        if (def > mx) def = mx;
        def = mn + (def - mn) / st * st;
    } else {
        for (const char *q = b; q <= be; q++) if (q == be || *q == ',') nc++;
        if (nc < 2 || nc > 8) return 0;
        const char *q = b; int i = 0;                           /* the default: the choice named by c */
        while (q < be) {
            const char *qe = q; while (qe < be && *qe != ',') qe++;
            if (qe - q == ce - c) { int k = 0; while (k < qe - q && q[k] == c[k]) k++; if (k == qe - q) def = i; }
            q = qe + 1; i++;
        }
        mx = nc - 1;
    }
    *key = a; *keyn = (int)(ae - a); *defo = def; *nchoice = nc;
    p = ost_put8(p, number ? KN_SET_NUMBER : KN_SET_CHOICE); p = ost_put8(p, 0); p = ost_put8(p, (uint32_t)nc); p = ost_put8(p, 0);
    p = ost_put32(p, (uint32_t)def); p = ost_put32(p, (uint32_t)mn); p = ost_put32(p, (uint32_t)mx); p = ost_put32(p, (uint32_t)st);
    p = ost_put32(p, 0);
    for (int i = 0; i < ae - a; i++) *p++ = (uint8_t)a[i];
    *p++ = 0;
    p = lab ? ost_label(p, lab, (uint32_t)(labe - lab), KN_SL_LABEL) : ost_label(p, a, (uint32_t)(ae - a), KN_SL_LABEL);
    for (int i = 0; i < ae - a; i++) *p++ = (uint8_t)a[i];      /* key = id */
    *p++ = 0;
    *p++ = 0;                                                   /* no unit */
    if (!number) {
        const char *q = b; int i = 0;
        while (q < be) {
            const char *qe = q; while (qe < be && *qe != ',') qe++;
            p = ost_label(p, q, (uint32_t)(qe - q), KN_SL_CHOICE); p = ost_put32(p, (uint32_t)i);
            q = qe + 1; i++;
        }
    }
    return p;
}
#endif
