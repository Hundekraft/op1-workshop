/*
 * A plugin's own SVG art (Opus bridge phase 9, opus.h): opus_art_* (a document by number: drawn, elements shown or
 * hidden, turned, its colours found and changed), opus_page_art (a page's art behind its drawing, from a file), and the
 * frame services a page keeps its pixels with (opus_page_keep / opus_page_put) and asks what it shows (opus_page_now).
 *
 * The documents are R246's own: the file is written into the plugin's folder (/yaffs2/mod/<id>/<name>, opus_art_text,
 * only when missing or different) and parsed by R246's SVG loader (svg_load 0x01A503D8 on a loader record of our own:
 * { document, name relative to /yaffs2/content/display }), the first time a page asks for it inside its draw (the Gfx
 * thread). It is drawn by R246's base screen draw (0x01A3B4C8, which reads only the document word) over the frame,
 * in the drawing's units scaled to the panel by R246's screen matrix, as R246 draws its own screens. Elements are found
 * by id with R246's non-panicking lookup (0x019EB8AC, warn 0); shown or hidden by their visible flag (+0x50); turned by
 * the transform setter (0x019EAD58, nine Q10 words, row vectors). Colours: a document keeps its fills as 4-byte RGBA
 * records (+0x5C..+0x60) and its strokes as 20-byte records starting with RGBA (+0x6C..+0x70), which R246's
 * screen_get_fill_style / _line_style index (0x01A3B96C / 0x01A3B854); opus_art_colour_slots hands out pointers to the
 * records holding a colour, opus_art_set_colour writes only through pointers that lie in a loaded document's records.
 *
 * Memory: a document is parsed once and kept for good (one per file and name; a plugin keeps pointers into it, so it
 * is never freed or evicted). Before a parse the TE heap (R246's TLSF pool, 0x840000 bytes at 0x0106B7CC, used bytes at
 * +4) must keep OA_RESERVE free after the parse's worst case (OA_PARSE_X x the file's size + the parser's 64 KB buffer),
 * and the art documents together stay under OA_CAP; otherwise the art is refused with a log line and the page draws
 * its plain form. Each parse logs its cost (TE used after minus before).
 *
 * Colours: kennel has no themes: opus_accent_now gives the stock encoder colours and opus_art_colours never moves (0).
 * The kit's theme and recolour manifest lines are not read (no file in the starter pack has them).
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../op1_synth.h"

void kn_log_line(const char *file, const char *msg);
const char *kn_svg_err(const uint8_t *s, uint32_t len);          /* kn_boot.c: R246's parser's known stops */

#define OA_MAX       16                     /* art documents for all files */
#define OA_PAGES     8                      /* opus_page_art records (file, page) */
#define OA_FILE_MAX  0x20000u               /* 128 KB, the kit's limit */
#define OA_POOL      0x840000u              /* the TE heap */
#define OA_RESERVE   (1536u * 1024u)        /* kept free for R246 after an art parse */
#define OA_PARSE_X   4u                     /* a parse's worst case per file byte (amp: 47,874 B file) */
#define OA_PARSE_BUF 0x10044u               /* svg_parse_file's own read buffer, freed after */
#define OA_CAP       (512u * 1024u)         /* all art documents together */

#ifdef OB_HOST_FS                           /* tier 2: the test supplies the file system and R246's SVG side */
int ob_open(const char *, int, int);
int ob_close(int);
int ob_read(int, void *, unsigned);
int ob_write(int, const void *, unsigned);
int ob_mkdir(const char *, int);
void *oa_host_svg_load(uint32_t *loader);
void oa_host_screen_draw(void *scr, int dt);
void *oa_host_find(void *doc, const char *id, int warn);
void oa_host_set_matrix(void *node, const int32_t *m);
uint32_t oa_host_te_used(void);
#define Y_OPEN   ob_open
#define Y_CLOSE  ob_close
#define Y_READ   ob_read
#define Y_WRITE  ob_write
#define Y_MKDIR  ob_mkdir
#define SVG_LOAD oa_host_svg_load
#define SCREEN_DRAW oa_host_screen_draw
#define NODE_FIND oa_host_find
#define SET_MATRIX oa_host_set_matrix
#define TE_USED oa_host_te_used()
#else
#define Y_OPEN   ((int (*)(const char *, int, int))0x01A997F4u)
#define Y_CLOSE  ((int (*)(int))0x01A99908u)
#define Y_READ   ((int (*)(int, void *, unsigned))0x01A99C90u)
#define Y_WRITE  ((int (*)(int, const void *, unsigned))0x01A99F84u)
#define Y_MKDIR  ((int (*)(const char *, int))0x01A9A886u)
#define SVG_LOAD ((void *(*)(uint32_t *))0x01A503D8u)            /* svg_load(loader): parses loader[1] into loader[0] */
#define SCREEN_DRAW ((void (*)(void *, int))0x01A3B4C8u)         /* screen_draw_base: the document in word 0 */
#define NODE_FIND ((void *(*)(void *, const char *, int))0x019EB8ACu)
#define SET_MATRIX ((void (*)(void *, const int32_t *))0x019EAD58u)
#define TE_USED (*(volatile uint32_t *)0x0106B7D0u)
#endif
#define O_CREATE 0x241                       /* write, create, truncate (R246's) */

typedef struct {
    const ob_file *f;                       /* its plugin */
    uint32_t loader[2];                     /* { document, rel }: R246's loader layout */
    char rel[80];                           /* "../../mod/<id>/<name>" (relative to /yaffs2/content/display) */
    uint32_t bytes;                         /* the file's size (0: not known yet) */
    uint32_t cost;                          /* TE heap bytes its parse took */
    uint8_t state;                          /* 0 not loaded, 1 loaded, 2 refused */
    uint8_t checked;                        /* 1: written by opus_art_text from the plugin's checked text */
    int8_t page;                            /* opus_page_art's page (0, 1, 3), else -1 */
} oa_art;
static oa_art art[OA_MAX];
static int n_art;
static uint32_t art_total;                  /* parsed bytes, all documents */
volatile uint32_t oa_stats[6];              /* debugger: documents, bytes, refused, draws, keeps that fit, keeps refused */

int oa_count(void) { return n_art; }
void oa_rollback(int n)                     /* a refused file's arts (never parsed: opl_init is before any page) */
{
    if (n >= 0 && n < n_art) n_art = n;
}

static void log2s(const ob_file *f, const char *a, const char *b, const char *c)
{
    char m[120], *p = m, *e = m + sizeof m - 1;
    const char *s[3] = { a, b, c };
    for (int k = 0; k < 3; k++) for (const char *q = s[k]; q && *q && p < e; q++) *p++ = *q;
    *p = 0;
    kn_log_line(f && f->self.id ? f->self.id : "art", m);
}
static void log_num(const ob_file *f, const char *what, const char *name, uint32_t a, uint32_t b)
{
    char m[120], *p = ob_cat(ob_cat(ob_cat(m, what), " "), name);
    p = ob_num(ob_cat(p, " "), a);
    p = ob_num(ob_cat(p, " bytes, TE heap used "), b);
    (void)p;
    kn_log_line(f && f->self.id ? f->self.id : "art", m);
}

/* the kit's further stops (its svgcheck.py): a point with no decimal digit after a digit; a number with an exponent */
static const char *more_err(const uint8_t *s, uint32_t n)
{
    int in_num = 0, in_col = 0;
    for (uint32_t i = 0; i < n && s[i]; i++) {
        const uint8_t c = s[i];
        if (c == '#') in_col = 1;
        else if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'))) in_col = 0;
        if (in_col) { in_num = 0; continue; }
        if (c >= '0' && c <= '9') {                             /* a number: not a digit inside a word (w3.org) */
            const uint8_t b = i ? s[i - 1] | 0x20 : ' ';
            if (in_num || !(b >= 'a' && b <= 'z')) in_num = 1;
            continue;
        }
        if (in_num && c == '.' && !(i + 1 < n && s[i + 1] >= '0' && s[i + 1] <= '9')) return "a number with a point and no decimals";
        if (in_num && (c == 'e' || c == 'E') && i + 1 < n &&
            ((s[i + 1] >= '0' && s[i + 1] <= '9') || s[i + 1] == '-' || s[i + 1] == '+')) return "a number with an exponent";
        in_num = c == '.' && in_num;
    }
    return 0;
}
static const char *svg_bad(const uint8_t *s, uint32_t n)
{
    int root = 0;
    for (uint32_t i = 0; i + 4 < n && i < 512 && !root; i++)
        root = s[i] == '<' && s[i + 1] == 's' && s[i + 2] == 'v' && s[i + 3] == 'g';
    if (!root) return "not an SVG";
    const char *e = kn_svg_err(s, n);
    return e ? e : more_err(s, n);
}

/* the file name: 1-15 of a-z A-Z 0-9 . _ - */
static int name_ok(const char *s)
{
    int n = 0;
    for (; s[n]; n++) {
        const char c = s[n];
        if (n >= 15 || !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-'))
            return 0;
    }
    return n > 0 && s[0] != '.';
}

/* the file as it should be (svg, len): 1 when it is there already */
static int same_file(const char *path, const char *svg, uint32_t len)
{
    const int fd = Y_OPEN(path, 0, 0);
    if (fd < 0) return 0;
    uint8_t b[256];
    uint32_t at = 0;
    int same = 1;
    for (;;) {
        const int r = Y_READ(fd, b, sizeof b);
        if (r <= 0) break;
        for (int i = 0; i < r && same; i++) same = at + (uint32_t)i < len && b[i] == (uint8_t)svg[at + i];
        at += (uint32_t)r;
        if (!same) break;
    }
    Y_CLOSE(fd);
    return same && at == len;
}

static int add(const ob_file *f, const char *rel_tail, int page)   /* -> art number, or -1 */
{
    if (n_art >= OA_MAX) return -1;
    oa_art *a = &art[n_art];
    char *p = ob_cat(a->rel, "../../");
    for (int i = 0; rel_tail[i] && p < a->rel + sizeof a->rel - 1; i++) *p++ = rel_tail[i];
    *p = 0;
    a->f = f; a->loader[0] = 0; a->loader[1] = (uint32_t)a->rel; a->bytes = 0; a->cost = 0; a->state = 0; a->checked = 0;
    a->page = (int8_t)page;
    return n_art++;
}

/* opus_art_text: the plugin's own SVG text written to /yaffs2/mod/<id>/<name> when missing or different (checked
 * first: what would stop R246's parser is refused), then opened. From opl_init. -> art, or -1. */
static int a_text(opl_self *self, const char *name, const char *svg, unsigned len)
{
    ob_file *f = (ob_file *)self;
    if (!f || f != ob_cur || !name || !svg || !ob_owns(f, name) || !name_ok(name)) return -1;
    if (!len || len > OA_FILE_MAX || !ob_owns(f, svg) || !ob_owns(f, svg + len - 1) || ob_len(f->self.id) > 40) {
        log2s(f, "art ", name, ": refused (its size or place)");
        return -1;
    }
    const char *why = svg_bad((const uint8_t *)svg, len);
    if (why) { log2s(f, "art ", name, ": refused"); log2s(f, "  ", why, ""); return -1; }
    char path[96], *p = ob_cat(path, "/yaffs2/mod");
    Y_MKDIR(path, 0x1FF);
    p = ob_cat(ob_cat(p, "/"), f->self.id);
    Y_MKDIR(path, 0x1FF);
    char *tail = path + 8;                                      /* "mod/<id>/<name>" */
    ob_cat(ob_cat(p, "/"), name);
    if (!same_file(path, svg, len)) {
        const int fd = Y_OPEN(path, O_CREATE, 0x180);
        int ok = fd >= 0;
        for (uint32_t at = 0; ok && at < len;) {
            const uint32_t k = len - at > 4096 ? 4096 : len - at;
            ok = Y_WRITE(fd, svg + at, k) == (int)k;
            at += k;
        }
        if (fd >= 0) Y_CLOSE(fd);
        if (!ok) { log2s(f, "art ", name, ": not written (flash full?)"); return -1; }
        log2s(f, "art ", name, ": written");
    }
    const int n = add(f, tail, -1);
    if (n < 0) { log2s(f, "art ", name, ": no room (16 documents)"); return -1; }
    art[n].bytes = len; art[n].checked = 1;
    return n;
}

/* opus_art_open: a file the plugin names (a full path under /yaffs2/mod), checked and loaded the first time it is
 * ready. -> art, or -1. */
static int file_ok(oa_art *a);
static int a_open(opl_self *self, const char *path)
{
    ob_file *f = (ob_file *)self;
    if (!f || !path || !ob_owns(f, path)) return -1;
    const char *want = "/yaffs2/mod/";
    for (int i = 0; want[i]; i++) if (path[i] != want[i]) return -1;
    for (int i = 0; path[i]; i++) if (i > 70 || (path[i] == '.' && path[i + 1] == '.')) return -1;
    return add(f, path + 8, -1);
}

/* the first show: a file not written from checked text is read and checked (into R246's heap, freed again) */
#ifdef OB_HOST_FS
void *oa_host_new(uint32_t n);
void oa_host_delete(void *p);
#define OP_NEW oa_host_new
#define OP_DELETE oa_host_delete
#else
#define OP_NEW ((void *(*)(uint32_t))0x01A5E3B0u)
#define OP_DELETE ((void (*)(void *))0x01A5E310u)
#endif
static int file_ok(oa_art *a)
{
    if (a->checked) return 1;
    char path[96];
    ob_cat(ob_cat(path, "/yaffs2/"), a->rel + 6);
    int fd = Y_OPEN(path, 0, 0);
    if (fd < 0) { log2s(a->f, "art ", a->rel + 6, ": no such file"); return 0; }
    uint32_t n = 0;
    uint8_t b[256];
    for (int r; (r = Y_READ(fd, b, sizeof b)) > 0;) n += (uint32_t)r;
    Y_CLOSE(fd);
    if (!n || n > OA_FILE_MAX) { log2s(a->f, "art ", a->rel + 6, ": empty or larger than 128 KB"); return 0; }
    if (TE_USED + n + 64 + OA_RESERVE > OA_POOL) { log2s(a->f, "art ", a->rel + 6, ": no room to check it"); return 0; }
    uint8_t *buf = OP_NEW(n + 1);
    if (!buf) return 0;
    fd = Y_OPEN(path, 0, 0);
    uint32_t got = 0;
    if (fd >= 0) {
        for (int r; got < n && (r = Y_READ(fd, buf + got, n - got)) > 0;) got += (uint32_t)r;
        Y_CLOSE(fd);
    }
    buf[got] = 0;
    const char *why = got == n ? svg_bad(buf, n) : "unreadable";
    OP_DELETE(buf);
    if (why) { log2s(a->f, "art ", a->rel + 6, ": refused"); log2s(a->f, "  ", why, ""); return 0; }
    a->bytes = n; a->checked = 1;
    return 1;
}

static oa_art *loaded(int n) { return n >= 0 && n < n_art && art[n].state == 1 ? &art[n] : 0; }

int oa_in_page;                             /* opus_engine.c / opus_fx.c: 1 while a page draws (the Gfx thread) */
static int load(oa_art *a)                  /* 1 loaded (now or before) */
{
    if (a->state) return a->state == 1;
    if (!oa_in_page) return 0;                                  /* parsed on the Gfx thread only */
    if (!file_ok(a)) { a->state = 2; oa_stats[2]++; return 0; }
    const uint32_t used = TE_USED, worst = OA_PARSE_X * a->bytes + OA_PARSE_BUF;
    if (used + worst + OA_RESERVE > OA_POOL || art_total + OA_PARSE_X * a->bytes > OA_CAP) {
        log_num(a->f, "art refused (no room):", a->rel + 6, a->bytes, used);
        a->state = 2; oa_stats[2]++;
        return 0;
    }
    a->loader[0] = 0;
    void *doc = SVG_LOAD(a->loader);
    if (!doc) { log2s(a->f, "art ", a->rel + 6, ": not parsed"); a->state = 2; oa_stats[2]++; return 0; }
    const uint32_t after = TE_USED;
    a->cost = after > used ? after - used : 0;
    art_total += a->cost;
    a->state = 1;
    oa_stats[0]++; oa_stats[1] = art_total;
    log_num(a->f, "art parsed:", a->rel + 6, a->cost, after);
    return 1;
}

static int a_ready(int n) { return n >= 0 && n < n_art && load(&art[n]); }
static void draw_doc(oa_art *a)
{
    uint32_t scr[4] = { a->loader[0], 0, 0, 0 };                /* screen_draw_base reads word 0 only */
    SCREEN_DRAW(scr, 0);
    oa_stats[3]++;
}
static void a_draw(int n) { oa_art *a = loaded(n); if (a && oa_in_page) draw_doc(a); }
static void *node(oa_art *a, const char *id)
{
    if (!a || !id) return 0;
    return NODE_FIND((void *)a->loader[0], id, 0);
}
static int a_show(int n, const char *id, int on)
{
    uint8_t *e = node(loaded(n), id);
    if (!e) return 0;
    e[0x50] = (uint8_t)(on != 0);
    return 1;
}
void oa_sincos(int turn, int *s, int *c);   /* opus_imports.c: x 4096 */
/* the element turned by t/4096 of a turn, clockwise on the screen, about (cx, cy) in units x 256 (its last turn replaced):
 * row vectors, x' = c x - s y + tx, y' = s x + c y + ty, (cx, cy) fixed */
static int a_turn(int n, const char *id, int t, int cx, int cy)
{
    void *e = node(loaded(n), id);
    if (!e) return 0;
    int s, c;
    oa_sincos(t, &s, &c);
    s >>= 2; c >>= 2;                                           /* Q10 */
    const int32_t x = cx << 2, y = cy << 2;                     /* units x 256 -> Q10 */
    const int32_t m[9] = { c, s, 0, -s, c, 0, x - ((x * c - y * s) >> 10), y - ((x * s + y * c) >> 10), 1024 };
    SET_MATRIX(e, m);
    return 1;
}
#define DOC_W(d, o) (*(uint8_t **)((uint8_t *)(d) + (o)))
static int a_colour_slots(int n, unsigned rgb, unsigned char **slots, int max)
{
    oa_art *a = loaded(n);
    if (!a || !slots || max <= 0) return 0;
    const uint8_t r = (uint8_t)(rgb >> 16), g = (uint8_t)(rgb >> 8), b = (uint8_t)rgb;
    int k = 0;
    static const uint8_t at[2][2] = { { 0x5C, 4 }, { 0x6C, 20 } };   /* fills, then strokes */
    for (int v = 0; v < 2; v++)
        for (uint8_t *p = DOC_W(a->loader[0], at[v][0]), *e = DOC_W(a->loader[0], at[v][0] + 4); p && p < e && k < max; p += at[v][1])
            if (p[0] == r && p[1] == g && p[2] == b) slots[k++] = p;
    return k;
}
static int slot_ok(const uint8_t *p)        /* inside a loaded document's fill or stroke records, at a record's start */
{
    for (int i = 0; i < n_art; i++) {
        if (art[i].state != 1) continue;
        const uint8_t *d = (const uint8_t *)art[i].loader[0];
        const uint8_t *f0 = DOC_W(d, 0x5C), *f1 = DOC_W(d, 0x60), *s0 = DOC_W(d, 0x6C), *s1 = DOC_W(d, 0x70);
        if (p >= f0 && p < f1 && !((uint32_t)(p - f0) & 3)) return 1;
        if (p >= s0 && p < s1 && (uint32_t)(p - s0) % 20 == 0) return 1;
    }
    return 0;
}
static void a_set_colour(unsigned char **slots, int n, unsigned rgb)
{
    if (!slots || n <= 0 || n > 4096) return;
    for (int i = 0; i < n; i++) {
        uint8_t *p = slots[i];
        if (!slot_ok(p)) continue;
        p[0] = (uint8_t)(rgb >> 16); p[1] = (uint8_t)(rgb >> 8); p[2] = (uint8_t)rgb;
    }
}
static unsigned a_colours(void) { return 0; }                   /* the user's colours never change here (stock) */

/* ---- opus_page_art: a page's art behind its drawing (a file the plugin names, or 0: none any more) ---- */
static int page_art_of(const ob_file *f, int page)
{
    for (int i = n_art - 1; i >= 0; i--) if (art[i].f == f && art[i].page == page) return i;
    return -1;
}
static int s_page_art(opl_self *self, int page, const char *path)
{
    ob_file *f = (ob_file *)self;
    if (!f || (page != 0 && page != 1 && page != 3)) return 0;
    const int old = page_art_of(f, page);
    if (old >= 0) art[old].page = -1;                           /* the old one stays parsed (never freed), unused */
    if (!path) return 1;
    if (!ob_owns(f, path)) return 0;
    /* the same file again: keep it (its size changed: the kit loads it again; here a changed file needs a restart) */
    for (int i = 0; i < n_art; i++)
        if (art[i].f == f && path[0] == '/' && ob_eq(art[i].rel + 6, path + 8)) { art[i].page = (int8_t)page; return 1; }
    const int n = a_open(self, path);
    if (n < 0) return 0;
    art[n].page = (int8_t)page;
    return 1;
}
/* the engine's page draw: its page's art first (which: 0 T1, 1 T2, 3 T4) */
void oa_page_art_draw(const ob_file *f, int which)
{
    const int n = page_art_of(f, which);
    if (n >= 0 && load(&art[n])) draw_doc(&art[n]);
}

/* ---- the frame: keep / put (a page's own pixels), what the page shows ---- */
void *oe_page_raster(void);                 /* opus_engine.c: R246's raster inside a page's draw, else 0 */
int oa_touched;                             /* a page wrote pixels itself this frame (the frame hash must move) */
/* runs: per lit run of a column: { row, y | (len - 1) << 8, len pixels } (row = the raster's memory row, rows - 1 - x) */
static int p_keep(unsigned short *out, unsigned cap, int x0, int x1, int y0, int y1)
{
    const uint32_t *r = oe_page_raster();
    if (!r || !out || !op1_raster_live(r)) { oa_stats[5]++; return -1; }   /* a record frame: not the picture */
    int off;                                                    /* OQ_PLACE: the placed page's rows, OQ_ROW_OFF rows on */
    const int rows = oq_page_rows(r, &off);
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > rows - 1) x1 = rows - 1;
    if (y1 > rows / 2 - 1) y1 = rows / 2 - 1;
    if (y1 > 255) y1 = 255;
    const uint16_t *pix = (const uint16_t *)(uintptr_t)r[0];
    uint32_t used = 0;
    for (int x = x0; x <= x1; x++) {
        const int row = rows - 1 - x + off;
        const uint16_t *col = pix + (row << 8);
        for (int y = y0; y <= y1;) {
            if (!col[y]) { y++; continue; }
            int e = y;
            while (e + 1 <= y1 && col[e + 1]) e++;
            const uint32_t len = (uint32_t)(e - y + 1);
            if (used + 2 + len > cap) { oa_stats[5]++; return -1; }
            out[used++] = (unsigned short)row;
            out[used++] = (unsigned short)(y | (len - 1) << 8);
            for (int k = y; k <= e; k++) out[used++] = col[k];
            y = e + 1;
        }
    }
    oa_stats[4]++;
    return (int)used;
}
/* the runs written back; the caller feeds the frame hash (oa_put: the bridge's kept still part, hashed by its key) */
void oa_put(const unsigned short *runs, int used)
{
    const uint32_t *r = oe_page_raster();
    if (!r || !runs || used <= 0) return;
    uint16_t *pix = (uint16_t *)(uintptr_t)r[0];
    const uint32_t mrows = r[3];
    for (int i = 0; i + 2 <= used;) {
        const uint32_t row = runs[i], y = runs[i + 1] & 0xFF, len = (uint32_t)(runs[i + 1] >> 8) + 1;
        i += 2;
        if (row >= mrows || y + len > 256 || i + (int)len > used) return;
        uint16_t *d = pix + (row << 8) + y;
        for (uint32_t k = 0; k < len; k++) d[k] = runs[i + k];
        i += (int)len;
    }
}
static void p_put(const unsigned short *runs, int used)
{
    oa_put(runs, used);
    if (oe_page_raster() && runs && used > 0) oa_touched = 1;
}
int oa_keep(unsigned short *out, unsigned cap, int x0, int x1, int y0, int y1) { return p_keep(out, cap, x0, x1, y0, y1); }

/* what the page shows (opus_page_now): set by the page's draw, read by the plugin inside it */
static opus_page now_pg;
static int16_t now_par[8];
static int now_on;
void oa_page_set(int kind, int t, int where, int slot, const int16_t *par8, int mark4, void *inst, const void *module)
{
    now_pg.kind = (int16_t)kind; now_pg.t = (int16_t)t; now_pg.where = (int16_t)where; now_pg.slot = (int16_t)slot;
    now_pg.on = 1; now_pg.n = 8; now_pg.key = -1;
    for (int i = 0; i < 8; i++) now_par[i] = now_pg.live[i] = par8[i];
    if (mark4) now_pg.live[4] = now_par[4] = (int16_t)mark4;
    now_pg.par = now_par;                                       /* a copy: a page's own edits are not taken back here */
    now_pg.inst = inst; now_pg.module = module;
    now_on = 1;
}
void oa_page_clear(void) { now_on = 0; }
static int p_now(opus_page *pg)
{
    if (!now_on || !pg) return 0;
    *pg = now_pg;
    return 1;
}

const ob_sym oa_imports[] = {               /* searched before the other tables */
    { "opus_art_colour_slots", (uint32_t)a_colour_slots },
    { "opus_art_colours", (uint32_t)a_colours },
    { "opus_art_draw", (uint32_t)a_draw },
    { "opus_art_open", (uint32_t)a_open },
    { "opus_art_ready", (uint32_t)a_ready },
    { "opus_art_set_colour", (uint32_t)a_set_colour },
    { "opus_art_show", (uint32_t)a_show },
    { "opus_art_text", (uint32_t)a_text },
    { "opus_art_turn", (uint32_t)a_turn },
    { "opus_page_art", (uint32_t)s_page_art },
    { "opus_page_keep", (uint32_t)p_keep },
    { "opus_page_now", (uint32_t)p_now },
    { "opus_page_put", (uint32_t)p_put },
};
const int oa_n_imports = (int)(sizeof oa_imports / sizeof oa_imports[0]);

/* tests (tier 2): an art's state and document, the parsed total */
int oa_state(int n) { return n >= 0 && n < n_art ? art[n].state : -1; }
void *oa_doc(int n) { return n >= 0 && n < n_art ? (void *)art[n].loader[0] : 0; }
const char *oa_rel(int n) { return n >= 0 && n < n_art ? art[n].rel : 0; }
uint32_t oa_total(void) { return art_total; }
