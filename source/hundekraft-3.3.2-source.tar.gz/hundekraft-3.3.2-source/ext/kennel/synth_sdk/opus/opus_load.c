/*
 * The .opmod loader (Opus bridge, opus.h): check a whole file before any byte is written, then copy, clear the zero fill
 * and relocate. Written from the Opus plugin kit's documented format (its GPL tools/op1mod reader's checks), in our own
 * code; it started as the 2026-11-11 study's proof of concept (fa_load.c). Places (patches of R246 code) are refused
 * by the caller (owner D3). No libc.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"

#define REL_ZERO (1u << 30)

static uint32_t rd32(const uint8_t *p) { return p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24; }
static uint16_t rd16(const uint8_t *p) { return (uint16_t)(p[0] | p[1] << 8); }
static void wr16(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void wr32(uint8_t *p, uint32_t v) { wr16(p, v); wr16(p + 2, v >> 16); }

int ob_len(const char *s) { int n = 0; if (s) while (s[n]) n++; return n; }
int ob_cmp(const char *a, const char *b)
{
    while (*a && *a == *b) a++, b++;
    return (int)(uint8_t)*a - (int)(uint8_t)*b;
}
int ob_eq(const char *a, const char *b) { return a && b && !ob_cmp(a, b); }
char *ob_cat(char *d, const char *s) { while (*s) *d++ = *s++; *d = 0; return d; }
char *ob_num(char *d, uint32_t v)
{
    char t[12]; int n = 0;
    do t[n++] = (char)('0' + v % 10); while (v /= 10);
    while (n) *d++ = t[--n];
    *d = 0;
    return d;
}
static uint32_t field(const char **p, const char *end)       /* one dotted number part */
{
    uint32_t v = 0;
    while (*p < end && **p >= '0' && **p <= '9') v = v * 10 + (uint32_t)(*(*p)++ - '0');
    if (*p < end && **p == '.') (*p)++;
    return v;
}
int ob_vercmp(const char *a, uint32_t alen, const char *b, uint32_t blen)
{
    const char *ae = a + alen, *be = b + blen;
    for (int k = 0; k < 4; k++) {
        uint32_t x = field(&a, ae), y = field(&b, be);
        if (x != y) return x < y ? -1 : 1;
    }
    return 0;
}

static uint32_t crc32_skip(const uint8_t *d, uint32_t n, uint32_t skip)   /* zlib CRC-32, bytes skip..skip+3 as 0 */
{
    uint32_t c = 0xFFFFFFFFu;
    for (uint32_t i = 0; i < n; i++) {
        c ^= (i >= skip && i < skip + 4) ? 0 : d[i];
        for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & -(c & 1));
    }
    return ~c;
}

static int inside(uint32_t off, uint32_t n, uint32_t size) { return off <= size && n <= size - off; }

static int name_ok(const ol_file *f, uint32_t o)               /* a NUL-terminated name inside the strings */
{
    const uint8_t *s = f->d + f->str_off;
    if (o >= f->str_len) return 0;
    for (uint32_t e = o; e < f->str_len; e++) if (!s[e]) return e > o;
    return 0;
}

const char *ol_check(const uint8_t *d, uint32_t size, ol_file *f)
{
    if (size < OPMOD_HDR || rd32(d) != OPMOD_MAGIC) return "not a plugin file";
    if (rd16(d + 4) != 1 || rd16(d + 6) < OPMOD_HDR) return "a newer file format";
    if (rd32(d + 8) != size) return "damaged: size";
    f->crc = rd32(d + 12);
    if (crc32_skip(d, size, 12) != f->crc) return "damaged: crc";
    uint32_t w[20];
    for (int i = 0; i < 20; i++) w[i] = rd32(d + 0x10 + 4 * i);
    f->d = d; f->size = size;
    f->man_off = w[0]; f->man_len = w[1]; f->img_off = w[2]; f->img_len = w[3]; f->zero = w[4]; f->entry = w[5];
    f->imp_off = w[6]; f->imp_n = w[7]; f->rel_off = w[8]; f->rel_n = w[9];
    f->str_off = w[12]; f->str_len = w[13]; f->flags = w[14]; f->exp_off = w[16]; f->exp_n = w[17]; f->pl_n = w[19];
    if (!inside(w[0], w[1], size) || !inside(w[2], w[3], size) || w[7] > size / 4 || !inside(w[6], 4 * w[7], size) ||
        w[9] > size / 12 || !inside(w[8], 12 * w[9], size) || w[11] > size / 16 || !inside(w[10], 16 * w[11], size) ||
        !inside(w[12], w[13], size) || w[17] > size / 8 || !inside(w[16], 8 * w[17], size) || w[19] > size / 24 ||
        !inside(w[18], 24 * w[19], size))
        return "damaged: a table outside the file";
    if (!f->img_len || !(f->flags & OPMOD_F_CODE)) return "has no code";
    if (f->img_len > OPMOD_MAX_IMAGE || f->zero > OPMOD_MAX_IMAGE || f->img_len < 4 || f->entry > f->img_len - 4 ||
        (f->entry & 1))
        return "damaged: image";
    if (f->imp_n > OPMOD_MAX_IMPORTS) return "too many imports";
    for (uint32_t i = 0; i < f->imp_n; i++) if (!name_ok(f, rd32(d + f->imp_off + 4 * i))) return "damaged: names";
    for (uint32_t i = 0; i < f->exp_n; i++)
        if (!name_ok(f, rd32(d + f->exp_off + 8 * i)) || rd32(d + f->exp_off + 8 * i + 4) >= f->img_len)
            return "damaged: exports";
    for (uint32_t i = 0; i < f->rel_n; i++) {                   /* every relocation before any byte is written */
        const uint8_t *r = d + f->rel_off + 12 * i;
        uint32_t word = rd32(r), tgt = rd32(r + 4), val = rd32(r + 8), site = word & 0x0FFFFFFFu, kind = (word >> 28) & 3;
        int imported = (int)(word >> 31), inz = !!(word & REL_ZERO);
        uint32_t width = kind == 0 ? 4 : 2;
        if (site + width > f->img_len || (kind == 3 && site < 2) || (site & 1)) return "damaged: a relocation";
        if (imported ? tgt >= f->imp_n : (int32_t)val < 0 || val > f->img_len + f->zero) return "damaged: a relocation";
        if (inz && (imported || kind == 3 || !(f->flags & OPMOD_F_APART))) return "damaged: a zero-fill mark";
        if (kind == 3) return "a branch relocation (this core places images anywhere)";
    }
    return 0;
}

const char *ol_import_name(const ol_file *f, uint32_t i)
{
    return (const char *)f->d + f->str_off + rd32(f->d + f->imp_off + 4 * i);
}
const char *ol_export(const ol_file *f, uint32_t i, uint32_t *offset)
{
    *offset = rd32(f->d + f->exp_off + 8 * i + 4);
    return (const char *)f->d + f->str_off + rd32(f->d + f->exp_off + 8 * i);
}

uint32_t ol_place(const ol_file *f, const uint32_t *addr, uint8_t *base, uint8_t *zero_at)
{
    const uint8_t *d = f->d;
    for (uint32_t i = 0; i < f->img_len; i++) base[i] = d[f->img_off + i];
    if (!(f->flags & OPMOD_F_APART)) zero_at = base + f->img_len;
    for (uint32_t i = 0; i < f->zero; i++) zero_at[i] = 0;
    const uint32_t b = (uint32_t)base, zdelta = (uint32_t)zero_at - f->img_len;
    for (uint32_t i = 0; i < f->rel_n; i++) {
        const uint8_t *r = d + f->rel_off + 12 * i;
        uint32_t word = rd32(r), tgt = rd32(r + 4), val = rd32(r + 8), site = word & 0x0FFFFFFFu, kind = (word >> 28) & 3;
        uint32_t full = ((word >> 31) ? addr[tgt] : (word & REL_ZERO) ? zdelta : b) + val;
        if (kind == 0) wr32(base + site, full);
        else if (kind == 1) wr16(base + site, full & 0xFFFF);
        else wr16(base + site, full >> 16);                     /* (kind 3 refused by ol_check) */
    }
    return b + f->entry;
}

const char *ol_manifest(const ol_file *f, const char *key, int n, uint32_t *len)
{
    const char *m = (const char *)f->d + f->man_off, *end = m + f->man_len;
    const int kl = ob_len(key);
    for (const char *p = m; p < end;) {
        const char *e = p;
        while (e < end && *e != '\n') e++;
        int k = 0;
        while (k < kl && p + k < e && p[k] == key[k]) k++;
        if (k == kl && p + k < e && (p[k] == ' ' || p[k] == '\t')) {
            const char *v = p + k;
            while (v < e && (*v == ' ' || *v == '\t')) v++;
            const char *ve = e;
            while (ve > v && (ve[-1] == ' ' || ve[-1] == '\t' || ve[-1] == '\r')) ve--;
            if (!n--) { *len = (uint32_t)(ve - v); return v; }
        }
        p = e + 1;
    }
    *len = 0;
    return 0;
}
