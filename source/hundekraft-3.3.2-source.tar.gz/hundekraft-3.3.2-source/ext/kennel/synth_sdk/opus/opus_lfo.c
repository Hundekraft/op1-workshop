/*
 * Opus LFO types as kennel LFO types (Opus bridge phase 4, opus.h): opus_lfo_register makes one kennel op1_lfo_type per
 * Opus type, running in R246's MIDI LFO class as kennel's own (quad, pond, matrix). Offered to the core after the stage
 * (kn_lfo_foreign_offer, kn_foreign.h): taken after the features' types, with an lfo_types row of its own (marked).
 *
 * Words (8, saved with the sound under the type's saved name, kennel form only): w[0] = the record id's low 16 bits,
 * w[1] its high bits (0: a fresh pick, the type's defaults), w[2] the saved name's 16-bit hash (several foreign types share
 * one marker), w[3..6] 0, w[7] = KN_LFO_FOREIGN_MARK << 8 (reserved by the core: once the file is gone, the words do
 * nothing and the name falls back to tremolo, off, as a missing kennel type's). The settings (nparams of 1..64) are the
 * sound's "lfo_rec" record (op1_feature_lforec.h), as kennel's matrix keeps its rows.
 *
 * What the Opus core does (its lfotypes.c, status.c lfo_place_dispatch and services.c opus_lfo_move, read in
 * OP1-Emulator ext/opus-src), and so the adapter: while the sound is in its instrument's current slot and its LFO is on,
 * apply(l) runs at each pass of the instrument (synth: 1 then 0 for each sounding voice, then 2; drum: 3 for each voice,
 * then 4, then 5) with l = {instrument, slot, voice (255 the instrument's own), pass, settings, state}; tick(l) runs once a
 * block right before the apply of pass 2 (synth) or 4 (drum); trigger(l) at a note's start for its voice (and 255 from
 * the FX object). opus_lfo_move turns a target on the pass's copy only for the l being run (kennel's matrix destination
 * map: R246's own knob, envelope and FX turns, kennel's engine and FX shift layers, the sound's volume, pitch, ring and
 * duck). State: state_size bytes a slot (8 synth, 8 drum), zeroed when another record (a load, a pick) arrives, not for
 * the page's own edits.
 * The page: kennel's LFO page slot (an empty SVG) whose update calls the type's `page` with the opus_page_* primitives;
 * turns and pushes go to turn / key (page_turn / page_key when the type has them), opus_lfo_page() is the shown slot's
 * edit copy and opus_lfo_changed stores it as a new record, whose id the core saves with the words.
 * Tempo (opus_tempo, opus_tempo_phase*): kennel's beat clock (op1_beat_clock), counted a block at a time here (kennel's
 * matrix design), or the tape position while the clock follows the tape (one division a block then).
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "../op1_feature_lfo.h"
#include "../op1_feature_lforec.h"
#include "../kennel/kn_foreign.h"

void *kn_alloc(uint32_t size);
void kn_log_line(const char *file, const char *msg);
int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);
#ifdef OB_HOST_FS
void t2_lfo_move_log(const opus_lfo *l, int group, int param, int delta);   /* tier 2: every move, as asked */
#endif

#define KNOB_RANGE_SYNTH ((void (*)(int, int16_t *, int, void *))0x01A1DFEC)
#define KNOB_RANGE_DRUM  ((void (*)(int, int16_t *, int, void *))0x01A1E57C)
#define FX_KNOB_MOD      ((void (*)(int16_t *, const int16_t *, int16_t *))0x01A1DE68)   /* (&mod, range, &param) */
#define ENV_MOD          ((void (*)(int, int16_t *, void *))0x019F69B0)
#define FX_RANGE(type, k) ((const int16_t *)(0x01DE5C50 + (type) * 0x30 + (k) * 6))
#define DRUM_ENV_RANGE(k) ((const int16_t *)(0x01DE56C8 + (k) * 6))
#define STAGE            ((int16_t *)0xFF801724)                  /* the pass's stage words (engine, envelope or FX) */
#define SYNTH_SLOT()     (*(volatile int *)0xFF8016D4 & 7)
#define DRUM_SLOT()      (*(volatile int *)0xFF8016D8 & 7)
#define SYNTH_ENGINE()   (((const int *)0xFF8016E4)[SYNTH_SLOT()])
#define DRUM_ENGINE()    (((const int *)0xFF801704)[DRUM_SLOT()])
#define SYNTH_FX_TYPE()  (((const int *)0xFF801734)[SYNTH_SLOT()])
#define DRUM_FX_TYPE()   (((const int *)0xFF801754)[DRUM_SLOT()])
#define SYNTH_LFO_OBJ    ((void *const *)0x01AAAD6C)              /* [6] per-voice synth LFO objects */
#define DRUM_LFO_OBJ     ((void *const *)0x01AAAD84)              /* [12] per-voice drum LFO objects */
#define LFO_WORDS(pos, slot) ((int16_t *)(((pos) ? 0xFF801644 : 0xFF8014C4) + (slot) * 16))
#define LFO_ON(pos)      (((volatile uint8_t *)((pos) ? 0x01AAAC38 : 0x01AAAC28))[(pos) ? (*(volatile int *)0x01AAAC10 & 7) \
                                                                                        : SYNTH_SLOT()])
#define ENV_BUF          ((int16_t *)0xFF801D50)                  /* the voice's envelope, 128 Q15 (before pass 0) */
#define PITCH_BUF        ((int32_t *)0xFF801950)                  /* the voice's phase steps, 128 (88.2 kHz) */
#define MIX_BUS          ((int16_t *)0xFF800BB4)                  /* the instrument bus, 64 samples (passes 2 / 5) */
#define PAGE_POS()       (*(volatile int *)0x01DE4C40 == 1)       /* the LFO page shows the drum's LFO */
#define SHIFT_HELD()     (*(volatile uint8_t *)0x01DD7F78)
#define TAPE_STATE       (*(volatile int *)0x018C17D4)            /* 10 playing */

#define OL_N 64                                                   /* settings a record */
typedef struct {
    const opus_lfo_type *t;
    ob_file *file;
    char saved[16];
    char row[48];                                                 /* its lfo_types default_params */
    int16_t hash;                                                 /* word 2 */
    uint32_t sbytes;                                              /* state bytes a slot (32-aligned) */
    uint8_t *state;                                               /* 16 x sbytes: synth slots 0..7, drum 8..15 */
    uint32_t st_id[16];                                           /* the record id a slot's state belongs to */
    volatile uint32_t own_id[16];                                 /* the id the page's own last store gave a slot */
    int16_t defaults[OL_N];                                       /* a fresh pick's settings (the rest 0) */
    op1_lfo_type kt;                                              /* the kennel descriptor */
    uint32_t frames;
} ol_type;
static ol_type ol[OL_TYPES];
static int n_lfo;

int ol_count(void) { return n_lfo; }
void ol_rollback(int n) { if (n >= 0 && n < n_lfo) n_lfo = n; }
const opus_lfo_type *ol_lfo(int k) { return k >= 0 && k < n_lfo ? ol[k].t : 0; }
const void *ol_kennel(int k) { return k >= 0 && k < n_lfo ? &ol[k].kt : 0; }
void *ol_state(int k, int pos, int slot) { return k >= 0 && k < n_lfo ? ol[k].state + (pos * 8 + (slot & 7)) * ol[k].sbytes : 0; }

static int has(const opus_lfo_type *t, uint32_t end) { return t->size >= end; }
static inline uint32_t w_id(const int16_t *w) { return (uint32_t)(uint16_t)w[0] | (uint32_t)(uint16_t)w[1] << 16; }
#define MATRIX_MARK 0xB3                                           /* the retired matrix port's words (kn_lfo.c): id in w0/w1 */
static int is_matrix(int k) { return ob_eq(ol[k].saved, "matrix"); }
static inline int is_mine(int k, const int16_t *w)
{
    const unsigned hi = (uint16_t)w[7] >> 8;
    if (hi == MATRIX_MARK) return is_matrix(k) && !w[2];       /* an old sound's matrix words open in the name's type */
    return hi == KN_LFO_FOREIGN_MARK && w[2] == ol[k].hash;
}

/* ---- the clock (kennel's design, as plugins/matrix): beat position Q32 and its step a block ---- */
static uint64_t bpos;                                             /* beats, Q32 */
static uint32_t bstep;                                            /* beats a block, Q32 */
static int32_t clk_len, clk_step;
static uint8_t clk_follow;
void ol_clock(const op1_beat_t *b)                                 /* the core's per-block tick (kn_lfo_foreign_offer) */
{
    const int32_t step = b->step > 0 ? b->step : 0x100000;
    if (b->len != clk_len || step != clk_step) {
        clk_len = b->len; clk_step = step;
        bstep = b->len > 0 ? (uint32_t)(((uint64_t)(uint32_t)step << 32) / (uint32_t)b->len) : 0;
    }
    clk_follow = b->follows_tape && b->step > 0;
    if (clk_follow) {                                             /* the music position: the playing tape's */
        const uint32_t spb = clk_len > 0 ? (uint32_t)clk_len >> 14 : 0;   /* samples a beat */
        bpos = spb && b->tape_pos > 0 ? ((uint64_t)(uint32_t)b->tape_pos << 32) / spb : 0;
    } else bpos += bstep;
}
static uint64_t beats_now(void) { return bpos; }                /* written by the audio thread only */
static void s_tempo(opus_tempo *t)
{
    if (!t || t->size < 8) return;
    const uint64_t ticks = beats_now() * 96u;                     /* Q32 ticks */
    const uint32_t f[6] = {
        clk_len > 0 ? (uint32_t)(((uint64_t)2646000u * 16384u * 1000u) / (uint32_t)clk_len) : 0,
        (uint32_t)(ticks >> 32), (uint32_t)(ticks >> 16) & 0xFFFFu, (uint32_t)(((uint64_t)bstep * 96u) >> 16), 0, 0 };
    t->mbpm = f[0];
    if (t->size >= 12) t->ticks = f[1];
    if (t->size >= 16) t->frac = f[2];
    if (t->size >= 20) t->step = f[3];
    if (t->size >= 21) t->external = 0;                            /* kennel's clock: not a MIDI clock here */
    if (t->size >= 22) t->playing = TAPE_STATE == 10 ? 2 : 0;
}
static unsigned s_tempo_phase(unsigned n) { return n ? (unsigned)((beats_now() * 96u) / n) : 0; }
static unsigned s_tempo_phase_step(unsigned n) { return n ? (unsigned)(((uint64_t)bstep * 96u) / n) : 0; }

/* ---- moves (kennel's matrix destination map, plugins/matrix/matrix.c) ---- */
static inline int16_t sat16(int32_t v) { return v > 32767 ? 32767 : v < -32768 ? -32768 : (int16_t)v; }
static inline int32_t sat15(int32_t v) { return v > 32767 ? 32767 : v < -32767 ? -32767 : v; }
static const uint32_t exp2_tab[65] = {                            /* 2^(i/64) in Q15 */
    32768, 33125, 33486, 33850, 34219, 34591, 34968, 35349, 35734, 36123, 36516, 36914, 37316, 37722, 38133, 38548,
    38968, 39392, 39821, 40255, 40693, 41136, 41584, 42037, 42495, 42958, 43425, 43898, 44376, 44859, 45348, 45842,
    46341, 46846, 47356, 47871, 48393, 48920, 49452, 49991, 50535, 51085, 51642, 52204, 52773, 53347, 53928, 54515,
    55109, 55709, 56316, 56929, 57549, 58176, 58809, 59449, 60097, 60751, 61413, 62081, 62757, 63441, 64132, 64830,
    65536 };
static uint32_t exp2_q15(int32_t d)                                /* 2^(d / 32768) in Q15: 0.5 .. 2 */
{
    const uint32_t t = (uint32_t)(sat15(d) + 32768);
    const uint32_t f = t & 0x7FFF, i = f >> 9, r = f & 511;
    const uint32_t b = exp2_tab[i] + (((exp2_tab[i + 1] - exp2_tab[i]) * r) >> 9);
    return t >> 15 ? b : (b + 1) >> 1;
}
static inline int32_t scale_inc(int32_t inc, uint32_t q)          /* inc x q / 32768, sign kept, saturating */
{
    const int neg = inc < 0;
    const uint32_t u = neg ? (uint32_t)-inc : (uint32_t)inc;
    const uint32_t hi = (u >> 16) * q, lo = ((u & 0xFFFF) * q) >> 15;
    const uint32_t r = hi >= 0x40000000u ? 0x7FFFFFFFu : (hi << 1) + lo;
    const uint32_t s = r > 0x7FFFFFFFu ? 0x7FFFFFFFu : r;
    return neg ? -(int32_t)s : (int32_t)s;
}
static void pitch_scale(int32_t *x, int n, uint32_t q)
{
    int32_t last_in = 0, last_out = 0;
    for (int i = 0; i < n; i++) {
        if (i == 0 || x[i] != last_in) { last_in = x[i]; last_out = scale_inc(x[i], q); }
        x[i] = last_out;
    }
}
static void pairs(int16_t *b, int n, int32_t g, int op)          /* gain x (1 + g), ring x g, duck x (1 - g) */
{
    for (int i = 0; i < n; i++) {
        const int32_t m = (b[i] * g) >> 15;
        b[i] = sat16(op == 0 ? b[i] + m : op == 1 ? m : b[i] - m);
    }
}
static int shift_move(int fx, int knob, int32_t delta)          /* a kennel engine's / FX's shift layer */
{
    int16_t *w = STAGE;
    const int n = op1_shift_steps(fx, w, knob);
    if (!n) return 0;
    if (knob < 2) {
        int16_t *wd = &w[5 + knob];
        int32_t v = (*wd > 0 ? *wd : 0) + delta;
        v = v < 0 ? 0 : v > 32767 ? 32767 : v;
        if (n > 1) {
            int32_t i = (v * n) >> 15;
            i = i > n - 1 ? n - 1 : i;
            v = ((2 * i + 1) * 32768) / (2 * n);
        }
        *wd = (int16_t)v;
        return 1;
    }
    const int sh = knob == 2 ? 0 : 8, m = n > 1 ? n : 128;
    int32_t f = (w[7] >> sh) & 127;
    f = f < m ? f : m - 1;
    f += (sat15(delta) * m + 16384) >> 15;
    f = f < 0 ? 0 : f > m - 1 ? m - 1 : f;
    w[7] = (int16_t)((w[7] & ~(127 << sh)) | f << sh);
    return 1;
}
static int sound_move(int pass, int p, int32_t d)
{
    if (p == 0 && pass == 0) { pairs(ENV_BUF, 128, sat15(d), 0); return 1; }
    if (p == 1 && pass == 0) { pitch_scale(PITCH_BUF, 128, exp2_q15(d)); return 1; }
    if ((p == 2 || p == 3) && (pass == 2 || pass == 5)) { pairs(MIX_BUS, 64, sat15(d), p == 2 ? 1 : 2); return 1; }
    return 0;
}
static opus_lfo cur;                                              /* the l being run (the Opus core's current_lfo) */
static uint8_t cur_on;
static int s_move(const opus_lfo *l, int g, int p, int delta)
{
    if (!l || l != &cur || !cur_on || p < 0) return 0;
#ifdef OB_HOST_FS
    t2_lfo_move_log(l, g, p, delta);
#endif
    const int pass = l->pass;
    int16_t mod = sat16(delta);
    switch (g) {
    case 0:                                                       /* OPUS_LFO_ENGINE */
        if (p > 3) return 0;
        if (pass == 0) { KNOB_RANGE_SYNTH(p, &mod, SYNTH_ENGINE(), STAGE); return 1; }
        if (pass == 3) { KNOB_RANGE_DRUM(p, &mod, DRUM_ENGINE(), STAGE); return 1; }
        return 0;
    case 1:                                                       /* OPUS_LFO_ENVELOPE */
        if (p > 3) return 0;
        if (pass == 1) { ENV_MOD(p, &mod, STAGE); return 1; }
        if (pass == 4) { FX_KNOB_MOD(&mod, DRUM_ENV_RANGE(p), STAGE + p); return 1; }
        return 0;
    case 2:                                                       /* OPUS_LFO_EFFECT */
        if (pass != 2 && pass != 5) return 0;
        if (p < 4) { FX_KNOB_MOD(&mod, FX_RANGE(pass == 5 ? DRUM_FX_TYPE() : SYNTH_FX_TYPE(), p), STAGE + p); return 1; }
        if (p > 7) return 0;
        {   /* a bridged effect's shift layer (opus_fx.c), else kennel's FX shift layer */
            const int r = ox_lfo_shift(STAGE, p, delta);
            return r >= 0 ? r : shift_move(1, p - 4, delta);
        }
    case 3:                                                       /* OPUS_LFO_ENGINE_SHIFT */
        return pass == 0 && p < 4 ? shift_move(0, p, delta) : 0;
    case 4:                                                       /* OPUS_LFO_SOUND */
        return sound_move(pass, p, delta);
    }
    return 0;
}

/* ---- the LfoMidi entries ---- */
static int find_obj(void *const *objs, int n, void *self)
{
    for (int i = 0; i < n; i++) if (objs[i] == self) return i;
    return 255;
}
static int voice_of(void *self, int pass)
{
    if (pass == 0 || pass == 1) return find_obj(SYNTH_LFO_OBJ, 6, self);
    if (pass == 3) return find_obj(DRUM_LFO_OBJ, 12, self);
    return 255;
}
static int16_t *params_of(int k, int pos, int slot, const int16_t *w)
{
    const int16_t *p = op1_lfo_record(pos, slot, w_id(w));
    return (int16_t *)(p ? p : ol[k].defaults);
}
static void follow_id(int k, int pos, int slot, uint32_t id)    /* a slot's state belongs to its record */
{
    ol_type *T = &ol[k];
    const int s = pos * 8 + slot;
    if (T->st_id[s] == id) return;
    if (id != T->own_id[s]) {
        uint32_t *q = (uint32_t *)(T->state + s * T->sbytes);
        for (uint32_t i = 0; i < T->sbytes / 4; i++) q[i] = 0;
    }
    T->st_id[s] = id;
}
static void set_cur(int k, int pos, int slot, int voice, int pass, int16_t *p)
{
    cur.instrument = (uint8_t)pos; cur.slot = (uint8_t)slot; cur.voice = (uint8_t)voice; cur.pass = (uint8_t)pass;
    cur.params = p; cur.state = ol[k].state + (pos * 8 + slot) * ol[k].sbytes;
}
static int x_apply(int k, void *self, const int16_t *w, int pass)
{
    if (k >= n_lfo || !is_mine(k, w) || (unsigned)pass > 5) return 0;
    const opus_lfo_type *t = ol[k].t;
    const int pos = pass >= 3;
    if (!LFO_ON(pos)) return 0;
    const int slot = pos ? DRUM_SLOT() : SYNTH_SLOT();
    follow_id(k, pos, slot, w_id(w));
    int16_t *p = params_of(k, pos, slot, w);
    if ((pass == 2 || pass == 4) && t->tick) {                    /* once a block, before that pass's apply */
        set_cur(k, pos, slot, 255, pass, p);
        t->tick(&cur);
    }
    set_cur(k, pos, slot, voice_of(self, pass), pass, p);
    cur_on = 1;
    const int r = t->apply(&cur);
    cur_on = 0;
    return r;
}
static void x_trig(int k, int pos, int voice, const int16_t *w)
{
    if (k >= n_lfo || !is_mine(k, w) || !ol[k].t->trigger) return;
    const int slot = pos ? DRUM_SLOT() : SYNTH_SLOT();
    follow_id(k, pos, slot, w_id(w));
    set_cur(k, pos, slot, voice, 0, params_of(k, pos, slot, w));
    ol[k].t->trigger(&cur);
}

/* ---- the page: the shown slot's settings in an edit copy (KeyHandler and display threads) ---- */
static int16_t edit[2][OL_N];
static uint32_t edit_id[2] = { 0xFFFFFFFFu, 0xFFFFFFFFu };
static int8_t edit_slot[2] = { -1, -1 }, edit_k[2] = { -1, -1 };
static opus_lfo page_l;
static int16_t *cur_w;                                            /* the live words of the event being handled */
static int page_type(void)                                        /* the foreign type the LFO page shows, or -1 */
{
    const int pos = PAGE_POS(), slot = pos ? DRUM_SLOT() : SYNTH_SLOT();
    const int16_t *w = LFO_WORDS(pos, slot);
    for (int k = 0; k < n_lfo; k++) if (is_mine(k, w)) return k;
    return -1;
}
static opus_lfo *s_lfo_page(void)
{
    const int k = page_type();
    if (k < 0) return 0;
    const int pos = PAGE_POS(), slot = pos ? DRUM_SLOT() : SYNTH_SLOT();
    const uint32_t id = w_id(LFO_WORDS(pos, slot));
    if (edit_slot[pos] != slot || edit_id[pos] != id || edit_k[pos] != k) {
        const int16_t *p = op1_lfo_record(pos, slot, id);
        for (int i = 0; i < OL_N; i++) edit[pos][i] = p ? p[i] : ol[k].defaults[i];
        edit_slot[pos] = (int8_t)slot; edit_id[pos] = id; edit_k[pos] = (int8_t)k;
    }
    page_l.instrument = (uint8_t)pos; page_l.slot = (uint8_t)slot; page_l.voice = 255; page_l.pass = 0;
    page_l.params = edit[pos]; page_l.state = ol[k].state + (pos * 8 + slot) * ol[k].sbytes;
    return &page_l;
}
/* after an edit (KeyHandler): the settings as the slot's record, its id into the words (the core saves them) */
static void s_lfo_changed(const opus_lfo *l)
{
    if (!l || !cur_w || l->instrument > 1 || l->slot > 7) return;
    const int pos = l->instrument, slot = l->slot, k = edit_k[pos];
    if (k < 0 || k >= n_lfo) return;
    ol_type *T = &ol[k];
    T->own_id[pos * 8 + slot] = 0;
    const uint32_t id = op1_lfo_record_store(pos, slot, l->params, T->t->nparams);
    if (!id) return;
    T->own_id[pos * 8 + slot] = id;
    edit_id[pos] = id;
    cur_w[0] = (int16_t)(id & 0xFFFF); cur_w[1] = (int16_t)(id >> 16); cur_w[2] = T->hash;
    cur_w[3] = cur_w[4] = cur_w[5] = cur_w[6] = 0;
    cur_w[7] = (int16_t)(KN_LFO_FOREIGN_MARK << 8);
}
static void fill_page(opus_page *pg, int k, opus_lfo *l)
{
    pg->kind = 3; pg->t = 4; pg->where = (int16_t)l->instrument; pg->slot = (int16_t)l->slot; pg->on = 1;
    pg->n = (int16_t)ol[k].t->nparams; pg->key = -1;
    for (int i = 0; i < 8; i++) pg->live[i] = l->params[i];
    pg->par = l->params; pg->inst = l; pg->module = ol[k].t;
}
static int32_t acc[4];
static int detents(int knob, int delta)                          /* one step a detent (1024), as kennel's matrix */
{
    int32_t *a = &acc[knob & 3];
    if ((*a > 0 && delta < 0) || (*a < 0 && delta > 0)) *a = 0;
    *a += delta;
    const int st = *a / 1024;
    *a -= st * 1024;
    return st;
}
static void x_turn(int k, int16_t *w, int pos, int knob, int delta, int shift)
{
    (void)pos; (void)shift;
    const opus_lfo_type *t = ol[k].t;
    const int d = detents(knob, delta);
    if (!d) return;
    opus_lfo *l = s_lfo_page();
    if (!l) return;
    cur_w = w;
    if (has(t, 0x3C) && t->page_turn) {
        opus_page pg;
        fill_page(&pg, k, l);
        if (t->page_turn(&pg, knob & 3, d)) s_lfo_changed(l);
    } else if (has(t, 0x24) && t->turn) t->turn(knob & 3, d);
    cur_w = 0;
}
static void x_press(int k, int pos, int knob)
{
    const opus_lfo_type *t = ol[k].t;
    const int slot = pos ? DRUM_SLOT() : SYNTH_SLOT();
    opus_lfo *l = s_lfo_page();
    if (!l) return;
    cur_w = LFO_WORDS(pos, slot);
    if (has(t, 0x38) && t->page_key) {
        opus_page pg;
        fill_page(&pg, k, l);
        if (t->page_key(&pg, 0x3B + (knob & 3), 1)) s_lfo_changed(l);
    } else if (has(t, 0x28) && t->key) t->key(0x3B + (knob & 3), 1);
    cur_w = 0;
}
void oe_page_run(void (*fn)(void));                              /* opus_engine.c: the page primitives' raster */
static void scr_init(void *scr) { (void)scr; }
static void scr_update(void *scr, int dt)
{
    op1_screen_draw(scr, dt);
    const int k = page_type();
    if (k < 0) return;
    const opus_lfo_type *t = ol[k].t;
    if (has(t, 0x20) && t->page) oe_page_run(t->page);
    op1_screen_hash(scr, ++ol[k].frames);                         /* the page draws every frame: never skipped */
}
static const op1_screen_t screen = { scr_init, scr_update };

#define TR(k) \
    static int ma##k(const int16_t *w) { return is_mine(k, w); } \
    static int ap##k(void *s, const int16_t *w, int p) { return x_apply(k, s, w, p); } \
    static void ts##k(void *s, const int16_t *w) { x_trig(k, 0, voice_of(s, 0), w); } \
    static void td##k(void *s, const int16_t *w) { x_trig(k, 1, voice_of(s, 3), w); } \
    static void tf##k(void *s, const int16_t *w) { (void)s; x_trig(k, PAGE_POS(), 255, w); }   /* (the instrument shown) */ \
    static void tu##k(int16_t *w, int pos, int knob, int d, int sh) { x_turn(k, w, pos, knob, d, sh); } \
    static void pr##k(int pos, int knob) { x_press(k, pos, knob); }
TR(0) TR(1)
static const op1_lfo_type tmpl[OL_TYPES] = {
    { .stock_class = OP1_LFO_CLASS_MIDI, .marker = KN_LFO_FOREIGN_MARK, .match = ma0, .apply_synth = ap0, .apply_drum = ap0,
      .apply_fx = ap0, .trig_synth = ts0, .trig_drum = td0, .trig_fx = tf0, .svg = "usbout.svg", .screen = &screen,
      .press = pr0, .turn = tu0 },
    { .stock_class = OP1_LFO_CLASS_MIDI, .marker = KN_LFO_FOREIGN_MARK, .match = ma1, .apply_synth = ap1, .apply_drum = ap1,
      .apply_fx = ap1, .trig_synth = ts1, .trig_drum = td1, .trig_fx = tf1, .svg = "usbout.svg", .screen = &screen,
      .press = pr1, .turn = tu1 } };

/* ---- registration (from opl_init, inside the file's transaction) ---- */
static const char *const taken_names[] = { "tremolo", "value", "random", "element", "midi", "bend", "crank",
                                           "quad", "pond", 0 };   /* R246's and kennel's names (matrix: the retired port's, free since 2026-11-17) */
static int name_taken(const char *n)
{
    for (int i = 0; taken_names[i]; i++) if (ob_eq(taken_names[i], n)) return 1;
    for (int i = 0; i < kn_feature_count(); i++)                 /* a loaded kennel file's LFO types */
        for (const op1_lfo_type *t = kn_feature_at(i)->lfo; t; t = t->next) if (t->name && ob_eq(t->name, n)) return 1;
    return 0;
}
static int name_ok(const char *s)                                 /* kennel's row names: a-z 0-9 space _ + - */
{
    int n = 0;
    for (; s[n]; n++) {
        const char c = s[n];
        if (n >= 15 || !((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == ' ' || c == '_' || c == '+' || c == '-'))
            return 0;
    }
    return n > 0;
}
static int16_t hash16(const char *s)
{
    uint32_t h = 0x811c9dc5u;
    while (*s) h = (h ^ (uint8_t)*s++) * 0x01000193u;
    h = (h ^ (h >> 16)) & 0xFFFF;
    return (int16_t)(h ? h : 1);
}
int opus_lfo_register(opl_self *self, const opus_lfo_type *t)
{
    ob_file *f = ob_cur;
    if (!f || self != &f->self) return 0;
    const char *why = 0;
    char m[80];
    if (n_lfo >= OL_TYPES) why = "too many LFO types";
    else if (!t || !ob_inside(f, t) || t->size <= 0x1b) why = "a bad LFO type struct";
    else if (!ob_inside(f, t->name) || !t->defaults || !ob_inside(f, t->defaults) || !t->apply ||
             !ob_inside(f, (const void *)t->apply) || (t->tick && !ob_inside(f, (const void *)t->tick)) ||
             (t->trigger && !ob_inside(f, (const void *)t->trigger)))
        why = "a callback outside its image";
    else if (t->nparams < 1 || t->nparams > OL_N) why = "an LFO type has 1 to 64 settings";
    else if (!name_ok(t->name)) why = "a bad LFO type name";
    else if (t->state_size > 8192) why = "an LFO type needs more memory than this core gives";
    if (why) { kn_log_line(f->self.id, why); return 0; }
    ol_type *T = &ol[n_lfo];
    for (unsigned i = 0; i < sizeof *T; i++) ((uint8_t *)T)[i] = 0;
    char *e = ob_cat(T->saved, t->name);
    if (name_taken(t->name)) {                                    /* D4: kennel's keeps the plain name */
        if (ob_len(t->name) > 13) { kn_log_line(f->self.id, "an LFO type name in use"); return 0; }
        ob_cat(e, "_o");
    }
    for (int i = 0; i < n_lfo; i++) if (ob_eq(ol[i].saved, T->saved)) { kn_log_line(f->self.id, "an LFO type name in use"); return 0; }
    T->sbytes = (t->state_size + 31) & ~31u;
    if (!T->sbytes) T->sbytes = 32;
    uint8_t *a = kn_alloc(16 * T->sbytes + 32);
    if (!a) { kn_log_line(f->self.id, "plugin memory full"); return 0; }
    T->state = (uint8_t *)(((uint32_t)a + 31) & ~31u);
    T->t = t; T->file = f; T->hash = hash16(T->saved);
    for (int i = 0; i < t->nparams; i++) T->defaults[i] = t->defaults[i];
    {   /* "[0,0,h,0,0,0,0,-15104]": a pick's words (id 0: the type's defaults) */
        char *p = ob_cat(T->row, "[0,0,");
        int v = T->hash;
        if (v < 0) { *p++ = '-'; v = -v; }
        p = ob_num(p, (uint32_t)v);
        p = ob_cat(p, ",0,0,0,0,-");
        ob_cat(ob_num(p, 0x10000u - (KN_LFO_FOREIGN_MARK << 8)), "]");
    }
    T->kt = tmpl[n_lfo];
    T->kt.name = T->saved;
    for (int i = 0; i < 16; i++) T->st_id[i] = 0xFFFFFFFFu;
    n_lfo++;
    char *p = ob_cat(ob_cat(m, "LFO type "), T->saved);
    p = ob_num(ob_cat(p, " settings "), t->nparams);
    p = ob_num(ob_cat(p, " state "), t->state_size);
    if (has(t, 0x20) && t->page) p = ob_cat(p, " page");
    kn_log_line(f->self.id, m);
    return 1;
}
/* A sound saved on Opus (opus_saved.c, before the parse): its LFO record names the Opus type `name` with n settings p
 * (-32768: the type's default, as the Opus core's lfo_json_set). -> the saved name, with rec (64: the settings, the
 * rest the defaults or 0), its id (from the settings, never 0: the same sound gets the same record) and the eight words
 * kennel saves (w0/w1 the id, w2 the hash, w7 the marker); 0 when no bridged type has that name. */
const char *ol_from_opus(const char *name, const int16_t *p, int n, int16_t *w, int16_t *rec, uint32_t *id)
{
    if (!name || !w || !rec || !id || n < 0) return 0;
    for (int k = 0; k < n_lfo; k++) {
        const ol_type *T = &ol[k];
        if (!ob_eq(T->t->name, name)) continue;
        const int np = T->t->nparams;
        uint32_t h = 0x811c9dc5u;
        for (int i = 0; i < OL_N; i++) {
            int16_t v = i < np ? T->defaults[i] : 0;
            if (i < n && p && (p[i] != -32768 || i >= np)) v = p[i];
            rec[i] = v;
            h = (h ^ (uint16_t)v) * 0x01000193u;
        }
        h &= 0x7FFFFFFFu;
        *id = h ? h : 1;
        w[0] = (int16_t)(*id & 0xFFFF); w[1] = (int16_t)(*id >> 16); w[2] = T->hash;
        w[3] = w[4] = w[5] = w[6] = 0;
        w[7] = (int16_t)(KN_LFO_FOREIGN_MARK << 8);
        return T->saved;
    }
    return 0;
}
/* after the stage: the committed types to the core (taken after the features' LFO types) */
void ol_offer(void)
{
    for (int k = 0; k < n_lfo; k++)
        if (kn_lfo_foreign_offer(&ol[k].kt, ol_clock, ol[k].row)) kn_log_line(ol[k].file->self.id, "LFO type: no room");
}

/* tests (tier 2): the l the apply runs with is checked by s_move */
const ob_sym ol_imports[] = {
    { "opus_lfo_changed", (uint32_t)s_lfo_changed },
    { "opus_lfo_move", (uint32_t)s_move },
    { "opus_lfo_page", (uint32_t)s_lfo_page },
    { "opus_lfo_register", (uint32_t)opus_lfo_register },
    { "opus_tempo", (uint32_t)s_tempo },
    { "opus_tempo_phase", (uint32_t)s_tempo_phase },
    { "opus_tempo_phase_step", (uint32_t)s_tempo_phase_step },
};
const int ol_n_imports = (int)(sizeof ol_imports / sizeof ol_imports[0]);
