/*
 * The Opus bridge's boot stage (opus.h; kennel/kn_foreign.h's two weak hooks) and its install routes.
 *
 * Files: /yaffs2/opus/<name>.opmod (the workshop's push writes `opus/<file>.opmod`) and /yaffs2/content/<name>.opmod
 * (files the workshop bundles into a firmware, beside its .knl files); a file in opus/ wins over a content/ file of the
 * same name, as plugins/ over content/ for .knl. Each plugin's own folder is /yaffs2/mod/<id> (opl_self.folder).
 *
 * kn_foreign_need: the headers only (image + zero fill + an allowance for the bridge's records, settings, inventory and
 * log lines and the effects' state) and one image record per file.
 * kn_foreign_boot: libraries first (files with exports, orbit3d), then the rest, each:
 *   read whole into KN_STAGE (the pool, cleared after the stage) -> ol_check (CRC, bounds, every relocation) -> no
 *   places (D3) -> `needs` met -> every import bound by name -> not the file that crashed its start last time
 *   (inventory record and refusal made before the transaction) -> kn_foreign_begin -> image and zero fill in the arena,
 *   relocated -> kn_foreign_sync -> crash-map record -> stage marker -> opl_init -> marker gone -> commit, or rollback
 *   on a negative return. A refused file never stops the boot and never writes a byte of the arena that stays.
 * Crash stage: /yaffs2/opus/.stage names the file whose opl_init runs. When kennel's own marker makes the next boot
 * skip every plugin file, that boot moves the name (and the file's CRC) to .crashed; the boot after it refuses that
 * file ("crashed in its start last time") until the file changes, and loads the others.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../kn_mem.h"
#include "../kennel/kn_foreign.h"
#include "../kennel/kn_inv.h"
#include "../kennel/kn_load.h"
#include "../kennel/kn_setpage.h"
#include "opus_settab.h"                                         /* the manifest's setting lines -> a settings table */

void *kn_alloc(uint32_t size);
void kn_log_line(const char *file, const char *msg);

#ifdef OB_HOST_FS                                                 /* tier 2: the test supplies the file system */
int ob_open(const char *, int, int);
int ob_close(int);
int ob_read(int, void *, unsigned);
int ob_write(int, const void *, unsigned);
int ob_unlink(const char *);
int ob_mkdir(const char *, int);
void *ob_opendir(const char *);
const uint8_t *ob_readdir(void *);
int ob_closedir(void *);
#define Y_OPEN ob_open
#define Y_CLOSE ob_close
#define Y_READ ob_read
#define Y_WRITE ob_write
#define Y_UNLINK ob_unlink
#define Y_MKDIR ob_mkdir
#define Y_OPENDIR ob_opendir
#define Y_READDIR ob_readdir
#define Y_CLOSEDIR ob_closedir
extern uint8_t *ob_stage;
#define STAGE ob_stage
#else
#define Y_OPEN     ((int (*)(const char *, int, int))0x01A997F4)
#define Y_CLOSE    ((int (*)(int))0x01A99908)
#define Y_READ     ((int (*)(int, void *, unsigned))0x01A99C90)
#define Y_WRITE    ((int (*)(int, const void *, unsigned))0x01A99F84)
#define Y_UNLINK   ((int (*)(const char *))0x01A9A3FC)
#define Y_MKDIR    ((int (*)(const char *, int))0x01A9A886)
#define Y_OPENDIR  ((void *(*)(const char *))0x01A9B450)
#define Y_READDIR  ((const uint8_t *(*)(void *))0x01A9B648)   /* dirent: +0x0B d_name */
#define Y_CLOSEDIR ((int (*)(void *))0x01A9B74C)
#define STAGE ((uint8_t *)KN_STAGE)
#endif
#define O_READ   0
#define O_CREATE 0x241                                          /* O_WRONLY | O_CREAT | O_TRUNC (as the firmware) */

#define DIR_ROOT   "/yaffs2/"                                    /* names[] are relative to it: opus/x.opmod */
#define STAGE_MARK "/yaffs2/opus/.stage"
#define CRASHED    "/yaffs2/opus/.crashed"
#define MAX_FILES  24
#define PER_FILE   6144u                                        /* arena allowance a file beyond its image: its record,
                                                                   settings, inventory and log lines, effects' state */

static char names[MAX_FILES][48];                              /* "opus/<file>" or "content/<file>" */
static int n_names;
ob_file *ob_cur;

int ob_inside(const ob_file *f, const void *p)
{
    const uint32_t a = (uint32_t)p;
    return f && a >= f->img_lo && a < f->img_hi;
}
int ob_owns(const ob_file *f, const void *p)
{
    const uint32_t a = (uint32_t)p, z = f ? (uint32_t)f->zero_at : 0;
    return ob_inside(f, p) || (f && z && a >= z && a < z + f->zero_len);
}

static int ends_opmod(const char *s)
{
    int n = ob_len(s);
    return n > 6 && ob_eq(s + n - 6, ".opmod");
}
static const char *base_of(const char *p) { const char *b = p; for (; *p; p++) if (*p == '/') b = p + 1; return b; }
static void list_dir(const char *dir, const char *rel)          /* rel: "opus/" or "content/" */
{
    void *d = Y_OPENDIR(dir);
    if (!d) return;
    const uint8_t *e;
    while ((e = Y_READDIR(d)) && n_names < MAX_FILES) {         /* names only while the folder is open */
        const char *s = (const char *)e + 11;
        if (s[0] == '.' || ob_len(s) >= 40 || !ends_opmod(s)) continue;
        int there = 0;                                          /* opus/ first: a pushed file wins over a bundled one */
        for (int i = 0; i < n_names; i++) there |= ob_eq(base_of(names[i]), s);
        if (!there) ob_cat(ob_cat(names[n_names++], rel), s);
    }
    Y_CLOSEDIR(d);
}
static void list(void)
{
    n_names = 0;
    list_dir(DIR_ROOT "opus", "opus/");
    list_dir(DIR_ROOT "content", "content/");
}
#define LFO_STATE  (20u * 1024u)                                  /* arena allowance for a file that adds an LFO type */
static int adds_lfo(const char *m, int n)                          /* a manifest line "adds ... lfo ..." */
{
    for (int i = 0; i + 4 < n; i++) {
        if ((i && m[i - 1] != '\n') || m[i] != 'a' || m[i + 1] != 'd' || m[i + 2] != 'd' || m[i + 3] != 's') continue;
        for (int k = i + 4; k + 2 < n && m[k] != '\n'; k++) if (m[k] == 'l' && m[k + 1] == 'f' && m[k + 2] == 'o') return 1;
    }
    return 0;
}
static char *path_of(char *p, const char *name) { return ob_cat(ob_cat(p, DIR_ROOT), name); }
static uint32_t rd32(const uint8_t *p) { return p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24; }

uint32_t kn_foreign_need(uint32_t *images)
{
    list();
    uint32_t need = 0;
    static uint8_t hdr[OPMOD_HDR] __attribute__((aligned(32)));
    for (int i = 0; i < n_names; i++) {
        char p[64];
        path_of(p, names[i]);
        int fd = Y_OPEN(p, O_READ, 0x100);
        if (fd < 0) continue;
        const int got = Y_READ(fd, hdr, OPMOD_HDR);
        static char man[1024];
        int mn = 0;
        if (got == (int)OPMOD_HDR && rd32(hdr) == OPMOD_MAGIC && rd32(hdr + 0x10) == OPMOD_HDR) {   /* the manifest next */
            const uint32_t ml = rd32(hdr + 0x14);
            mn = Y_READ(fd, man, ml < sizeof man - 1 ? ml : sizeof man - 1);
        }
        Y_CLOSE(fd);
        need += PER_FILE;
        if (got != (int)OPMOD_HDR || rd32(hdr) != OPMOD_MAGIC) continue;
        if (mn > 0 && adds_lfo(man, mn)) need += LFO_STATE;     /* an LFO type's state: 16 slots (matrix: 18 KB) */
        const uint32_t img = rd32(hdr + 0x1C), zero = rd32(hdr + 0x20);
        if (img <= OPMOD_MAX_IMAGE && zero <= OPMOD_MAX_IMAGE) need += ((img + 63) & ~31u) + ((zero + 63) & ~31u);
    }
    *images = (uint32_t)n_names;
    return need;
}

/* ---- the crash stage ---- */
static int read_small(const char *path, char *out, int cap)
{
    int fd = Y_OPEN(path, O_READ, 0x100);
    if (fd < 0) return -1;
    int n = Y_READ(fd, out, (unsigned)(cap - 1));
    Y_CLOSE(fd);
    if (n < 0) n = 0;
    out[n] = 0;
    return n;
}
static void write_small(const char *path, const char *s)
{
    int fd = Y_OPEN(path, O_CREATE, 0x180);
    if (fd >= 0) { Y_WRITE(fd, s, (unsigned)ob_len(s)); Y_CLOSE(fd); }
}
static char crashed[64];                                        /* "<file> <crc hex>" of the last start that crashed */
static void hex(char *d, uint32_t v) { for (int i = 0; i < 8; i++) { int x = (v >> (28 - 4 * i)) & 15; d[i] = (char)(x < 10 ? '0' + x : 'a' + x - 10); } d[8] = 0; }

/* ---- settings rows from the manifest's `setting` lines -> kennel's packed table (opus_settab.h), on the settings
 * page's OPUS PLUGINS list (kn_settings_add_list) ---- */
static void notify(void *ctx, const char *key, int32_t value)   /* main loop: a row the page changed */
{
    ob_file *f = ctx;
    if (f && f->on_setting && ob_inside(f, (const void *)f->on_setting)) f->on_setting(key, (int)value);
}
static void settings(const ol_file *of, ob_file *f, const char *title, uint32_t title_n, int add)
{
    static uint8_t tab[1024];
    f->n_set = 0;                                               /* (called twice: before opl_init, after the commit) */
    uint8_t *p = ost_head(tab, title, title_n);
    int rows = 0;
    uint32_t len;
    const char *v;
    for (int n = 0; (v = ol_manifest(of, "setting", n, &len)) && rows < OB_SETTINGS; n++) {
        if (p > tab + sizeof tab - 320) break;              /* a row's worst case: 8 choices of KN_SL_CHOICE */
        const char *k; int kn, nchoice; int32_t def;
        uint8_t *q = ost_row(p, v, len, &k, &kn, &def, &nchoice);
        if (!q) continue;
        char *key = kn_alloc((uint32_t)kn + 1);
        if (!key) break;
        for (int i = 0; i < kn; i++) key[i] = k[i];
        key[kn] = 0;
        f->set[f->n_set].key = key; f->set[f->n_set].def = def; f->set[f->n_set].choices = (uint8_t)nchoice;
        f->n_set++;
        p = q;
        rows++;
    }
    tab[1] = (uint8_t)rows;
    if (add && rows) { kn_sl_notify = notify; kn_settings_add_list(f->feat, tab, (uint32_t)(p - tab), f); }
}

/* ---- one file ---- */
static const char *msg2(const char *a, const char *b, uint32_t bn)   /* "a b" in the arena (after any rollback) */
{
    char *m = kn_alloc((uint32_t)ob_len(a) + bn + 2);
    if (!m) return a;
    char *e = ob_cat(m, a);
    *e++ = ' ';
    for (uint32_t i = 0; i < bn; i++) e[i] = b[i];
    e[bn] = 0;
    return m;
}
/* The kit's version gate (manifest.md `core`): MAJOR.MINOR[.PATCH]; loaded when the major is ours and the minor not above
 * ours, else "needs core M.N" (the file's line), as the other core refuses it. No line: "its manifest"; a bad one:
 * "its core line". Checked before needs, imports and the transaction. */
static const char *core_gate(const ol_file *of)
{
    uint32_t n;
    const char *c = ol_manifest(of, "core", 0, &n);
    if (!c) return "its manifest";
    uint32_t major = 0, minor = 0, i = 0, dm = 0, dn = 0;
    while (i < n && c[i] >= '0' && c[i] <= '9' && dm < 4) major = major * 10 + (uint32_t)(c[i++] - '0'), dm++;
    if (i < n && c[i] == '.') i++;
    while (i < n && c[i] >= '0' && c[i] <= '9' && dn < 4) minor = minor * 10 + (uint32_t)(c[i++] - '0'), dn++;
    if (i < n && c[i] == '.') { i++; while (i < n && c[i] >= '0' && c[i] <= '9') i++; }
    if (!dm || !dn || i != n) return "its core line";
    if (major != OB_CORE_MAJOR || minor > OB_CORE_MINOR) return msg2("needs core", c, n);
    return 0;
}
static int is_lib(const char *name)                            /* exports: loaded in the first pass */
{
    char p[64];
    path_of(p, name);
    int fd = Y_OPEN(p, O_READ, 0x100);
    if (fd < 0) return 0;
    static uint8_t hdr[OPMOD_HDR] __attribute__((aligned(32)));
    int got = Y_READ(fd, hdr, OPMOD_HDR);
    Y_CLOSE(fd);
    return got == (int)OPMOD_HDR && rd32(hdr) == OPMOD_MAGIC && rd32(hdr + 0x10 + 17 * 4) != 0;
}
static const char *load(int i, kn_inv_rec *r)
{
    char p[64];
    path_of(p, names[i]);
    int fd = Y_OPEN(p, O_READ, 0x100);
    if (fd < 0) return "can't be read";
    uint32_t size = 0;
    for (;;) {
        int k = Y_READ(fd, STAGE + size, KN_FILE_MAX - size > 65536 ? 65536 : KN_FILE_MAX - size);
        if (k <= 0) break;
        size += (uint32_t)k;
        if (size >= KN_FILE_MAX) { Y_CLOSE(fd); return "too big"; }
    }
    Y_CLOSE(fd);
    ol_file of;
    const char *why = ol_check(STAGE, size, &of);
    if (r) { r->size = size; r->crc = of.crc; }
    if (why) return why;
    if (of.pl_n) return "patches the OP-1 firmware (places): not supported";
    uint32_t idn, vn, nn;
    const char *id = ol_manifest(&of, "id", 0, &idn), *ver = ol_manifest(&of, "version", 0, &vn);
    const char *title = ol_manifest(&of, "name", 0, &nn);
    if (!id || idn < 1 || idn > 23) return "damaged: no id";
    const char *why_core = core_gate(&of);
    if (r) {
        uint32_t k = 0;
        for (; k < 15 && k < idn; k++) r->name[k] = id[k];
        r->name[k] = 0;
        if (ver) r->version = msg2("", ver, vn) + 1;
        uint32_t an;
        const char *au = ol_manifest(&of, "author", 0, &an);
        if (au) r->author = msg2("", au, an) + 1;
        uint32_t cn;
        const char *cpu = ol_manifest(&of, "cpu", 0, &cn);
        char *cl = cpu && cn && cpu[0] >= '0' && cpu[0] <= '9' ? kn_alloc(cn + 8) : 0;   /* a number only */                  /* "cpu N" as its one claim line (D8: shown, never */
        if (cl) {                                               /* switches a file off); kn_alloc zeroes: the list's end */
            char *e = ob_cat(cl, "cpu ");
            for (uint32_t k = 0; k < cn; k++) e[k] = cpu[k];
            r->claims = cl;
        }
    }
    if (why_core) return why_core;                              /* (after the inventory record's id, version, cpu) */
    {
        char c[16];
        hex(c, of.crc);
        int nl = ob_len(names[i]);
        if (crashed[0] && ob_len(crashed) == nl + 9) {
            int same = 1;
            for (int k = 0; k < nl; k++) same &= crashed[k] == names[i][k];
            for (int k = 0; k < 8; k++) same &= crashed[nl + 1 + k] == c[k];
            if (same) return "crashed in its start last time (install it again to retry)";
        }
    }
    uint32_t nd;
    for (int n = 0; ; n++) {                                     /* needs: id version */
        const char *v = ol_manifest(&of, "needs", n, &nd);
        if (!v) break;
        const char *e = v + nd, *a, *ae, *b, *be;
        a = ost_tok(v, e, &ae); b = ost_tok(ae, e, &be);
        if (!a) continue;
        char lid[24], lv[16];
        int k = 0;
        for (; k < 23 && a + k < ae; k++) lid[k] = a[k];
        lid[k] = 0;
        k = 0;
        for (; b && k < 15 && b + k < be; k++) lv[k] = b[k];
        lv[k] = 0;
        if (!ob_lib_has(lid, lv)) return msg2("needs", v, nd);
    }
    static uint32_t addr[OPMOD_MAX_IMPORTS];
    for (uint32_t k = 0; k < of.imp_n; k++) {
        const char *nm = ol_import_name(&of, k);
        uint32_t a = ob_import(nm);
        if (!a) a = ob_lib_import(nm);
        if (!a) return msg2("needs", nm, (uint32_t)ob_len(nm));
    }
    for (uint32_t k = 0; k < of.imp_n; k++) {
        const char *nm = ol_import_name(&of, k);
        uint32_t a = ob_import(nm);
        addr[k] = a ? a : ob_lib_import(nm);
    }
    /* checked: from here memory is taken, inside the transaction */
    const int types0 = ox_count(), engines0 = oe_count(), drums0 = od_count(), lfos0 = ol_count(), seqs0 = os_count(),
              blocks0 = ob_block_count(), inputs0 = oi_count(), leases0 = of_count(), arts0 = oa_count();
    kn_foreign_begin();
    ob_file *f = kn_alloc(sizeof *f);
    char *idc = f ? kn_alloc(idn + 1) : 0, *folder = f ? kn_alloc(idn + 13) : 0;
    const int apart = !!(of.flags & OPMOD_F_APART);
    uint8_t *base = f ? (uint8_t *)kn_foreign_alloc(of.img_len + (apart ? 0 : of.zero) + 4, 32) : 0;
    uint8_t *zero = apart && of.zero ? (uint8_t *)kn_foreign_alloc(of.zero, 32) : 0;
    if (!f || !idc || !folder || !base || (apart && of.zero && !zero)) { kn_foreign_rollback(); return "plugin memory full"; }
    for (uint32_t k = 0; k < idn; k++) idc[k] = id[k];
    idc[idn] = 0;
    ob_cat(ob_cat(folder, "/yaffs2/mod/"), idc);
    f->on_setting = 0; f->main_pass = 0; f->lease_total = 0;
    for (int k = 0; k < 4; k++) { f->laid[k] = f->lease_used[k] = 0; f->front_off[k] = 0; }
    f->self.size = sizeof f->self; f->self.id = idc; f->self.folder = folder; f->self.slot = i;
    f->img_lo = (uint32_t)base; f->img_hi = (uint32_t)base + of.img_len;
    { const char *b = base_of(names[i]); int k = 0; for (; k < 15 && b[k] && b[k] != '.'; k++) f->name[k] = b[k]; f->name[k] = 0; }
    { int k = 0; for (; k < 23 && idc[k]; k++) f->feat[k] = idc[k] == '.' ? '_' : idc[k]; f->feat[k] = 0; }
    settings(&of, f, title ? title : idc, title ? nn : idn, 0);
    const uint32_t entry = ol_place(&of, addr, base, zero ? zero : base + of.img_len);
    f->img = base; f->zero_at = zero ? zero : base + of.img_len; f->zero_len = of.zero;
    f->quirk = ob_quirk_find(&of, id, idn, ver, vn);            /* (opus_quirk.c: id, version, then the file's sha256) */
    f->vptr[0] = f->vptr[1] = 0;
    if (f->quirk) {
        for (int k = 0; k < 2 && (f->quirk->flags & OQ_VPTR); k++) {
            const uint32_t o = f->quirk->vptr[k];
            if (!o || (o & 3u) || o + 4u > of.img_len + of.zero) continue;
            f->vptr[k] = (uint32_t *)(o < of.img_len ? base + o : (zero ? zero : base + of.img_len) + (o - of.img_len));
        }
        char m[48];
        ob_cat(ob_cat(m, "quirk: "), f->quirk->what);
        kn_log_line(idc, m);
        oq_load(f);                                             /* OQ_PLACE: its rows checks (before the sync below) */
    }
    kn_foreign_sync((uint32_t)base, (uint32_t)base + of.img_len);
    {
        kn_img_rec rec;
        uint32_t *w = (uint32_t *)&rec;
        for (unsigned k = 0; k < sizeof rec / 4; k++) w[k] = 0;
        rec.base = (uint32_t)base; rec.load_size = of.img_len + of.zero; rec.image_size = of.img_len;
        rec.text_size = of.img_len; rec.crc = of.crc; rec.file_size = size; rec.kind = KN_KIND_FX;
        for (int k = 0; k < 15 && f->name[k]; k++) rec.id[k] = f->name[k];
        kn_foreign_image(&rec);
    }
    write_small(STAGE_MARK, names[i]);
    ob_cur = f;
    const int rc = ((int (*)(opl_self *))entry)(&f->self);
    ob_cur = 0;
    Y_UNLINK(STAGE_MARK);
    if (rc < 0) {
        ox_rollback(types0);
        oe_rollback(engines0);
        od_rollback(drums0);
        ol_rollback(lfos0);
        os_rollback(seqs0);
        ob_block_rollback(blocks0);
        oi_rollback(inputs0);
        of_rollback(leases0);
        oa_rollback(arts0);
        kn_foreign_rollback();
        char m[24];
        ob_num(ob_cat(m, "(-"), (uint32_t)-rc);
        return msg2("failed to start", m, (uint32_t)ob_len(m));
    }
    kn_foreign_commit();
    settings(&of, f, title ? title : idc, title ? nn : idn, 1);   /* rows after the commit: none for a refused file */
    if (of.exp_n && ver) {
        char v[16]; uint32_t k = 0;
        for (; k < 15 && k < vn; k++) v[k] = ver[k];
        v[k] = 0;
        if (ob_lib_add(idc, v, &of, (uint32_t)base)) kn_log_line(idc, "library exports: no room");
    }
    kn_log_line(idc, "loaded");
    return 0;
}

void kn_foreign_boot(int skipped)
{
    static uint8_t done[MAX_FILES];
    if (skipped) {                                              /* kennel's marker: the last boot did not reach the UI */
        char s[64];
        if (read_small(STAGE_MARK, s, sizeof s) > 0) {          /* ... in a start of ours: remember which file */
            for (int i = 0; i < n_names; i++)
                if (ob_eq(names[i], s)) {
                    char p[64], line[64];
                    path_of(p, names[i]);
                    int fd = Y_OPEN(p, O_READ, 0x100);
                    uint8_t h[16];
                    if (fd >= 0) {
                        if (Y_READ(fd, h, 16) == 16) {
                            char *e = ob_cat(ob_cat(line, names[i]), " ");
                            hex(e, rd32(h + 12));
                            write_small(CRASHED, line);
                        }
                        Y_CLOSE(fd);
                    }
                }
            Y_UNLINK(STAGE_MARK);
        }
        for (int i = 0; i < n_names; i++) {
            char p[64];
            ob_cat(p, names[i]);
            kn_inv_rec *r = kn_inv_add(KN_INV_FOREIGN, p);
            if (r) { r->state = KN_INV_SKIPPED; r->reason = "the last boot did not reach the UI"; }
        }
        return;
    }
    if (n_names) Y_MKDIR(DIR_ROOT "opus", 0x1FF);                /* the stage marker's folder, when only bundled files exist */
    if (read_small(CRASHED, crashed, sizeof crashed) < 0) crashed[0] = 0;
    for (int i = 0; i < n_names; i++) done[i] = 0;
    for (int pass = 0; pass < 2; pass++)
        for (int i = 0; i < n_names; i++) {
            if (done[i] || (pass == 0 && !is_lib(names[i]))) continue;
            done[i] = 1;
            char p[64];
            ob_cat(p, names[i]);
            kn_inv_rec *r = kn_inv_add(KN_INV_FOREIGN, p);      /* before the transaction (it survives a rollback) */
            if (r) r->kind = KN_KIND_FX;
            const char *why = load(i, r);
            if (r) { r->state = why ? KN_INV_FAILED : KN_INV_LOADED; r->reason = why; }
            if (why) kn_log_line(names[i], why);
            else if (crashed[0]) { int nl = ob_len(names[i]), same = 1; for (int k = 0; k < nl; k++) same &= crashed[k] == names[i][k];
                if (same && crashed[nl] == ' ') { Y_UNLINK(CRASHED); crashed[0] = 0; } }
        }
    od_offer();                                                 /* drum engines: to the core, activated after the features' */
    ol_offer();                                                 /* LFO types and sequencers: the same, after the features' */
    os_offer();
}

/* the core's retired-port rule (kn_foreign.h kn_foreign_has): opus/<name>.opmod or content/<name>.opmod exists */
int kn_foreign_has(const char *name)
{
    static const char *const dirs[] = { DIR_ROOT "opus/", DIR_ROOT "content/" };
    if (ob_len(name) > 23) return 0;
    for (int d = 0; d < 2; d++) {
        char p[64];
        ob_cat(ob_cat(ob_cat(p, dirs[d]), name), ".opmod");
        int fd = Y_OPEN(p, O_READ, 0x100);
        if (fd >= 0) { Y_CLOSE(fd); return 1; }
    }
    return 0;
}

/* ---- install routes ---- */
/* the workshop's push (devupd): opus/<file>.opmod, one level, a-z 0-9 _ - in the name (kn_foreign.h kn_foreign_path_ok) */
int kn_foreign_path_ok(const char *p)
{
    static const char dir[] = "opus/";
    for (int i = 0; dir[i]; i++) if (p[i] != dir[i]) return 0;
    const char *f = p + 5;
    int n = ob_len(f);
    if (n < 7 || n > 39 || !ends_opmod(f)) return 0;
    for (int i = 0; i < n - 6; i++) {
        const char c = f[i];
        if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-')) return 0;
    }
    return 1;
}
/* a bundled file (the workshop ships them as content/<file>.opmod, the same name rule): the push may delete it */
int kn_foreign_bundle_ok(const char *p)
{
    static const char dir[] = "content/";
    char q[48];
    for (int i = 0; dir[i]; i++) if (p[i] != dir[i]) return 0;
    if (ob_len(p) > 46) return 0;
    ob_cat(ob_cat(q, "opus/"), p + 8);
    return kn_foreign_path_ok(q);
}
