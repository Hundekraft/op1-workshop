/*
 * Per-file quirks (Opus bridge, opus.h ob_quirk): handling for one known file, for CPU (owner 2026-11-17: plugin-specific
 * behaviour is fine where it wins CPU). A row matches by the manifest's id and version and then the whole file's
 * sha256 (computed only when id and version match a row), so a changed or unknown file keeps the generic path. Each row
 * says what was checked in that file's code (OP1-Emulator run/opus-cpu-2026-11-17/COMPARE-quirks.md).
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "accel/oa.h"
#include "opus_place.h"
void kn_log_line(const char *file, const char *msg);

static const ob_quirk rows[] = {
    /* displayname808's castle 1.1: its 196-byte voices hold no pointers (KASTLE's 1:1 struct; tier 2 bit-exact with them
     * moving), but two zero-fill words keep pointers to voices: the last note's voice (+0x2A0F8) and the one before
     * (+0x2A0F4), compared with and copied from in voice init, note_on and render's takeover (0x2800EC0..0x2801124,
     * 0x2801F8E), never read anywhere else (relocated at 0x2800000). They move with the voices (OQ_VPTR). */
    { "displayname808.castle", "1.1",
      { 0x0e, 0x69, 0x90, 0x69, 0xa2, 0x54, 0xb1, 0xde, 0xde, 0xcd, 0x6a, 0x5e, 0x6d, 0x58, 0x3e, 0x8c,
        0xe3, 0x5a, 0x23, 0xde, 0x34, 0x02, 0x48, 0xc8, 0xe4, 0xe5, 0xc7, 0xb6, 0xae, 0xbd, 0xe2, 0x04 },
      OQ_MOVES | OQ_VPTR, { 0x2A0F4u, 0x2A0F8u }, "voices in L1", OA_NONE },
    /* opus.sim 0.1.9 (the starter pack's): render_cb at +0x1044 on kennel's kernels (accel/oa_sim.c: HIM's voice on
     * sim's 76-byte voice, the scope tap into its zero fill at +0x44, +0x5248..+0x6290) */
    { "opus.sim", "0.1.9",
      { 0x14, 0x92, 0x58, 0x8f, 0xc6, 0x63, 0xca, 0xb4, 0xc6, 0x18, 0xd1, 0x8c, 0xcd, 0xd9, 0x8b, 0x42,
        0x5f, 0xd9, 0x3a, 0xc7, 0x10, 0x51, 0x3a, 0x53, 0xb2, 0x8b, 0xbd, 0x24, 0x6e, 0xef, 0xb0, 0x50 },
      0, { 0, 0 }, "render on kennel's kernels", OA_SIM },
    /* opus.dx 0.4.1 (the starter pack's): engine_render at +0x110 on DX's voice and kernels (accel/oa_dx.c), its globals
     * and cold functions at the offsets checked in this image */
    { "opus.dx", "0.4.1",
      { 0x93, 0xf6, 0xb3, 0xe7, 0x0d, 0xce, 0xe6, 0x34, 0xd7, 0x2d, 0x72, 0xb6, 0x5d, 0xac, 0x8d, 0xab,
        0x9e, 0x7a, 0x76, 0xb9, 0xbf, 0xa0, 0xaa, 0x03, 0x72, 0xe2, 0x4e, 0x9f, 0x3b, 0x0f, 0x57, 0x62 },
      0, { 0, 0 }, "render on kennel's kernels", OA_DX },
    /* opus.dimension 1.0.4 (bundled): its T1 page runs to x 0 and to 2 px from the right, which the unit's glass hides
     * (owner 2026-11-18); laid out for rows - OQ_SHRINK and placed OQ_INSET px in (opus_place.h: the left edge 4 px
     * in, the right where it was). Its one opus_page_pixels call (image 0x1C78) accepts
     * only rows 320 / 376 / 400: the immediates at 0x1C86 (R3), 0x1C92 (R6), 0x1C9A (R7) take the placed page's rows
     * (R6 / R7 are loaded again before any later read). Everything else follows its rows: the scope trace, the kept
     * page (opus_page_keep 0..n-1) and the columns (n / 2). Its labels are R246 Text objects it makes itself through
     * the fw_text_new import (stub at 0x32FC): the stub's target becomes oq_text_new, which scales their place. */
    { "opus.dimension", "1.0.4",
      { 0x06, 0xd5, 0x87, 0x14, 0x28, 0xa1, 0x2f, 0x89, 0x22, 0x83, 0xc7, 0x9d, 0x6f, 0x21, 0x86, 0xb5,
        0x8f, 0xcd, 0xc0, 0x2e, 0x47, 0xf2, 0xf8, 0x98, 0xc5, 0x07, 0x82, 0x71, 0x3e, 0xe0, 0x55, 0x6e },
      OQ_PLACE, { 0, 0 }, "page placed 4 px in", OA_NONE, { 0x1C86u, 0x1C92u, 0x1C9Au }, 0x32FCu },
};

/* ---- OQ_PLACE: a page placed inside the panel (opus_place.h) ---- */
static const uint16_t place_rows[3] = { 320, 376, 400 };
#define FW_TEXT_NEW 0x01A61904u                                 /* R246 text_ctor (opus_imports.c fw_text_new) */
static void *oq_text_new(void *mem, int32_t x_q10, int y, int size, const uint8_t *rgba, int align);
void oq_load(ob_file *f)
{
    if (!f || !f->quirk || !(f->quirk->flags & OQ_PLACE)) return;
    for (int k = 0; k < 3; k++)                                 /* all three as checked, or none */
        if (*(const uint16_t *)(f->img + f->quirk->place_at[k]) != place_rows[k]) {
            kn_log_line(f->self.id, "place: rows check not found (not placed)");
            return;
        }
    uint16_t *t = (uint16_t *)(f->img + f->quirk->text_new_at);  /* P1.L imm at +2, P1.H imm at +6 */
    const uint32_t to = (uint32_t)oq_text_new;
    if (!f->quirk->text_new_at || t[0] != 0xE109u || t[2] != 0xE149u || t[1] != (FW_TEXT_NEW & 0xFFFFu)
        || t[3] != FW_TEXT_NEW >> 16) {
        kn_log_line(f->self.id, "place: text import not found (not placed)");
        return;
    }
    t[1] = (uint16_t)to; t[3] = (uint16_t)(to >> 16);
    for (int k = 0; k < 3; k++) *(uint16_t *)(f->img + f->quirk->place_at[k]) = (uint16_t)(place_rows[k] - OQ_SHRINK);
}
static int placed(const ob_file *f)                             /* its rows checks were patched at load */
{
    return f && f->quirk && (f->quirk->flags & OQ_PLACE)
        && *(const uint16_t *)(f->img + f->quirk->place_at[1]) == 376 - OQ_SHRINK;
}
#define SCREEN_M ((volatile int32_t *)0x01DE5E68)               /* R246's screen matrix (op1_plugin.h op1_panel_rows) */
static int32_t place_saved[9];
static int place_on, place_rows_now;
void oq_page_begin(const ob_file *f, void *raster)
{
    if (place_on || !raster || !placed(f)) return;
    int32_t m[9], out[9];
    for (int i = 0; i < 9; i++) m[i] = SCREEN_M[i];
    const int pr = oq_place_m(m, op1_panel_rows(raster), out);
    if (!pr) return;                                            /* an unknown matrix: drawn as it is (its pixels refused) */
    for (int i = 0; i < 9; i++) { place_saved[i] = m[i]; SCREEN_M[i] = out[i]; }
    place_rows_now = pr;
    place_on = 1;
}
void oq_page_end(void)
{
    if (!place_on) return;
    for (int i = 0; i < 9; i++) SCREEN_M[i] = place_saved[i];
    place_on = 0;
}
/* R246's text takes the matrix's translation but scales by the panel's own scale (measured: dimension's labels moved
 * OQ_INSET px and kept their unplaced spacing), so a text's place is scaled to the page here: unit x s / s' */
void oq_text_at(int32_t *x_q10, int *y)
{
    if (!place_on) return;
    const int32_t s = place_saved[3], sp = -SCREEN_M[1];
    *x_q10 = (*x_q10 * sp + s / 2) / s;                         /* < 2^31: 320 << 10 x 1254 */
    *y = (*y * sp + s / 2) / s;
}
/* a placed file's fw_text_new: its place scaled to the page (outside a placed draw: as it was) */
static void *oq_text_new(void *mem, int32_t x_q10, int y, int size, const uint8_t *rgba, int align)
{
    oq_text_at(&x_q10, &y);
    return ((void *(*)(void *, int32_t, int, int, const uint8_t *, int))FW_TEXT_NEW)(mem, x_q10, y, size, rgba, align);
}
int oq_page_rows(const void *raster, int *off)
{
    if (place_on) { *off = OQ_ROW_OFF; return place_rows_now; }
    *off = 0;
    return op1_panel_rows(raster);
}

ob_render_fn ob_render_for(ob_file *f, ob_render_fn own)
{
    if (!f || !f->quirk || !f->quirk->accel) return own;
    const ob_render_fn a = (ob_render_fn)oa_bind(f->quirk->accel, f->img, f->zero_at, (const void *)own);
    if (!a) { kn_log_line(f->self.id, "accel: render not bound (the file's own runs)"); return own; }
    kn_log_line(f->self.id, "accel: render on kennel's kernels");
    return a;
}

/* ---- SHA-256 (FIPS 180-4), small and slow: run only for a row's candidate at boot ---- */
static const uint32_t K[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
    0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
    0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
    0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2 };
#define ROR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))
static void block(uint32_t h[8], const uint8_t *p)
{
    uint32_t w[64];
    for (int i = 0; i < 16; i++) w[i] = (uint32_t)p[4 * i] << 24 | (uint32_t)p[4 * i + 1] << 16 | (uint32_t)p[4 * i + 2] << 8 | p[4 * i + 3];
    for (int i = 16; i < 64; i++) {
        const uint32_t s0 = ROR(w[i - 15], 7) ^ ROR(w[i - 15], 18) ^ (w[i - 15] >> 3);
        const uint32_t s1 = ROR(w[i - 2], 17) ^ ROR(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], k = h[7];
    for (int i = 0; i < 64; i++) {
        const uint32_t t1 = k + (ROR(e, 6) ^ ROR(e, 11) ^ ROR(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i];
        const uint32_t t2 = (ROR(a, 2) ^ ROR(a, 13) ^ ROR(a, 22)) + ((a & b) ^ (a & c) ^ (b & c));
        k = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += k;
}
void ob_sha256(const uint8_t *d, uint32_t n, uint8_t out[32])
{
    uint32_t h[8] = { 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 };
    uint32_t i = 0;
    for (; i + 64 <= n; i += 64) block(h, d + i);
    uint8_t t[128];
    uint32_t r = n - i, m = r < 56 ? 64 : 128;
    for (uint32_t j = 0; j < m; j++) t[j] = j < r ? d[i + j] : j == r ? 0x80 : 0;
    const uint64_t bits = (uint64_t)n * 8u;
    for (int j = 0; j < 8; j++) t[m - 1 - j] = (uint8_t)(bits >> (8 * j));
    block(h, t);
    if (m == 128) block(h, t + 64);
    for (int j = 0; j < 32; j++) out[j] = (uint8_t)(h[j >> 2] >> (24 - 8 * (j & 3)));
}

static int same(const char *a, uint32_t an, const char *b)
{
    uint32_t k = 0;
    for (; k < an; k++) if (!b[k] || b[k] != a[k]) return 0;
    return !b[k];
}
const ob_quirk *ob_quirk_find(const ol_file *of, const char *id, uint32_t idn, const char *ver, uint32_t vn)
{
    if (!id || !ver) return 0;
    uint8_t sum[32];
    int summed = 0;
    for (unsigned i = 0; i < sizeof rows / sizeof rows[0]; i++) {
        const ob_quirk *q = &rows[i];
        if (!same(id, idn, q->id) || !same(ver, vn, q->version)) continue;
        if (!summed) { ob_sha256(of->d, of->size, sum); summed = 1; }
        int eq = 1;
        for (int j = 0; j < 32; j++) eq &= sum[j] == q->sha[j];
        if (eq) return q;
    }
    return 0;
}
