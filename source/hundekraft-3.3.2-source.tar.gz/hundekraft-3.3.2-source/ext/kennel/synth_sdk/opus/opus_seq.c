/*
 * Opus sequencers as kennel sequencer types (Opus bridge phase 4, opus.h): opus_seq_register makes one kennel
 * op1_seq_type_t per Opus sequencer, hosted in finger's type as kennel's own (kennel/kn_seq.c: SeqIds, create_player
 * case 3, the screen slot 0x2D, keys and turns there). Offered to the core after the stage (kn_seq_foreign_offer): taken
 * after the features' types, with a seq_types row kept as a .knl type's. Also the sequencer-thread block handlers
 * (opus_on_block) and the note calls a sequencer plays with (fw_vc_note_on / fw_vc_note_off).
 *
 * What the Opus core does (its seq.c and handlers.c, read in the full project ext/opus-src), and so the adapter:
 *   player(mode) for the mode being made (0 synth, 1 drum): the object in R246's player layout is R246's own contract on
 *     both cores (its vtable's key_down, key_up, tick, stop ...), so it goes to kennel's create_player hook unchanged; a
 *     0 answer gives finger's player, as on Opus.
 *   key(mode, code, pressed) / turn(mode, encoder, raw delta) on its page come first (1: taken), or page_key / page_turn
 *     (opus_page, kind 4, n 0; turns summed as the Opus core does: raw delta >> 10, a step every four); the octave keys
 *     never reach it (kennel's core moves the octave). Encoder pushes reach key as codes 0x3B..0x3E.
 *   midi_start(mode) for each mode whose chosen sequencer it is; chosen(mode, on) when the mode's choice changes (asked
 *     here once a sequencer tick, the Opus core does it as the choice is made).
 *   name / alias: the row and the saved name; D4: a name kennel or R246 has gets "_o".
 *   opus_on_block handlers: once a PlayerManager tick on the sequencer thread (kennel's kn_seq_block hook, before the
 *     MIDI receive parser, where the Opus core calls them before player_midi), in load order.
 * Its page: kennel's screen slot 0x2D with an empty SVG and the sequencer's name (its own SVG screen is not drawn yet).
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "../op1_feature_seq.h"
#include "../op1_feature_midi.h"
#include "../kennel/kn_foreign.h"

void *kn_alloc(uint32_t size);
void kn_log_line(const char *file, const char *msg);
int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);
extern const char *const kn_own_seq[];                            /* the sequencer names the core was built with */
extern volatile int kn_src_force;                                 /* kennel/kn_midi.c: the next note is a player's */

#define CUR_MODE()   (*(volatile int *)0x01DE4C40 == 1)
#define SOUND_SLOT(m) (*(volatile int *)((m) ? 0xFF8016D8 : 0xFF8016D4) & 7)
#define VC_KEY_DOWN  ((void (*)(const void *, int))0x01A85750)     /* VoiceCtl key_down / key_up (kennel's hooked */
#define VC_KEY_UP    ((void (*)(const void *))0x01A85840)          /* entries: the note input observers, the pipeline) */

typedef struct {
    const opus_sequencer *d;
    ob_file *file;
    char saved[16], alias[16];
    op1_seq_type_t kt;
    uint8_t was[2];                                               /* chosen for mode, as last seen */
    int32_t acc[4];
    uint32_t frames;
} os_type;
static os_type os[OS_TYPES];
static int n_seq;

int os_count(void) { return n_seq; }
void os_rollback(int n) { if (n >= 0 && n < n_seq) n_seq = n; }
const opus_sequencer *os_seq(int k) { return k >= 0 && k < n_seq ? os[k].d : 0; }
const void *os_kennel(int k) { return k >= 0 && k < n_seq ? &os[k].kt : 0; }

static int has(const opus_sequencer *d, uint32_t end) { return d->size >= end; }

/* ---- the block handlers (opus_on_block) ---- */
#define OB_BLOCK 8
static void (*blk_fn[OB_BLOCK])(void);
static int n_blk;
int ob_block_count(void) { return n_blk; }
void ob_block_rollback(int n) { if (n >= 0 && n < n_blk) n_blk = n; }
static void s_on_block(opl_self *self, void (*fn)(void))
{
    ob_file *f = ob_cur;
    if (!f || self != &f->self || !fn || !ob_inside(f, (const void *)fn)) return;
    if (n_blk >= OB_BLOCK) { kn_log_line(f->self.id, "too many block handlers"); return; }
    blk_fn[n_blk++] = fn;
}
static void chosen_poll(void)
{
    for (int k = 0; k < n_seq; k++) {
        os_type *T = &os[k];
        for (int m = 0; m < 2; m++) {
            const uint8_t on = kn_seq_active_type(m) == (const void *)&T->kt;
            if (on == T->was[m]) continue;
            T->was[m] = on;
            if (has(T->d, 0x1C) && T->d->chosen) T->d->chosen(m, on);
        }
    }
}
volatile uint32_t ob_block_calls;                                 /* the sequencer-thread calls so far (a probe) */
void kn_seq_block(void)                                           /* kn_foreign.h: the sequencer thread, once a tick */
{
    ob_block_calls++;
    if (n_seq) chosen_poll();
    for (int i = 0; i < n_blk; i++) blk_fn[i]();
}

/* ---- notes (fw_vc_note_on / fw_vc_note_off: VoiceCtl key_down / key_up, kennel's note path) ---- */
typedef struct { int32_t note, velocity; uint8_t send_midi, pad[3]; int32_t extra; } vc_note;
static void s_note_on(void *ev, int param)
{
    const vc_note *n = ev;
    if (!n || (uint32_t)n->note > 127) return;                    /* R246 asserts 0 <= note < 128 */
    const int prior = kn_src_force;
    kn_src_force = OP1_SRC_PLAYER;
    VC_KEY_DOWN(ev, param);
    kn_src_force = prior;
}
static void s_note_off(void *ev)
{
    const vc_note *n = ev;
    if (!n || (uint32_t)n->note > 127) return;
    const int prior = kn_src_force;
    kn_src_force = OP1_SRC_PLAYER;
    VC_KEY_UP(ev);
    kn_src_force = prior;
}

/* ---- the kennel type's callbacks ---- */
static void *x_player(int k)
{
    const opus_sequencer *d = os[k].d;
    return d->player(CUR_MODE());
}
static void fill_page(opus_page *pg, int k, int mode)
{
    pg->kind = 4; pg->t = 0; pg->where = (int16_t)mode; pg->slot = (int16_t)SOUND_SLOT(mode); pg->on = 1; pg->n = 0;
    pg->key = -1;
    for (int i = 0; i < 8; i++) pg->live[i] = 0;
    pg->par = 0; pg->inst = 0; pg->module = os[k].d;
}
static int x_key(int k, int mode, int code, int pressed, int shift)
{
    (void)shift;
    const opus_sequencer *d = os[k].d;
    if (code == 0x24 || code == 0x25) return 0;
    if (has(d, 0x30) && d->page_key) {
        opus_page pg;
        fill_page(&pg, k, mode);
        return d->page_key(&pg, code, pressed) != 0;
    }
    if (has(d, 0x10) && d->key) return d->key(mode, code, pressed) != 0;
    return 0;
}
static void x_turn(int k, int mode, int knob, int delta, int shift)
{
    (void)shift;
    os_type *T = &os[k];
    const opus_sequencer *d = T->d;
    if (has(d, 0x34) && d->page_turn) {                           /* as the Opus core: delta >> 10, a step every four */
        int32_t *acc = &T->acc[knob & 3];
        const int32_t total = *acc + (delta >> 10);
        *acc = total;
        const int steps = total / 4;
        opus_page pg;
        fill_page(&pg, k, mode);
        if (d->page_turn(&pg, knob & 3, steps)) *acc -= steps * 4;
        else *acc = 0;
    } else if (has(d, 0x14) && d->turn) d->turn(mode, knob, (int16_t)delta);
}
static void x_midi_start(int k)
{
    const opus_sequencer *d = os[k].d;
    if (!has(d, 0x18) || !d->midi_start) return;
    for (int m = 0; m < 2; m++) if (kn_seq_active_type(m) == (const void *)&os[k].kt) d->midi_start(m);
}
void oe_page_title(const char *s);                               /* opus_engine.c: a centred line on the page */
static void scr_init(void *scr) { (void)scr; }
static void scr_update(int k, void *scr, int dt)
{
    op1_screen_draw(scr, dt);
    oe_page_title(os[k].saved);
    op1_screen_hash(scr, ++os[k].frames);
}

#define TR(k) \
    static void *pl##k(void) { return x_player(k); } \
    static int ke##k(int m, int c, int p, int s) { return x_key(k, m, c, p, s); } \
    static void tu##k(int m, int kn, int d, int s) { x_turn(k, m, kn, d, s); } \
    static void ms##k(void) { x_midi_start(k); } \
    static void up##k(void *scr, int dt) { scr_update(k, scr, dt); } \
    static const op1_screen_t scr##k = { scr_init, up##k };
TR(0) TR(1)
static const op1_seq_type_t tmpl[OS_TYPES] = {
    { .player = pl0, .svg = "usbout.svg", .screen = &scr0, .key = ke0, .turn = tu0, .midi_start = ms0 },
    { .player = pl1, .svg = "usbout.svg", .screen = &scr1, .key = ke1, .turn = tu1, .midi_start = ms1 } };

/* ---- registration (from opl_init, inside the file's transaction) ---- */
static const char *const stock[] = { "pattern", "endless", "tombola", "finger", "sketch", "arpeggio", 0 };
/* the Opus core's names (1-15 of a-z 0-9 space -) less the space: kennel's seq_types rows take a-z 0-9 _ - (kn_seq_rows.h),
 * so a name with a space would register without a row */
static int name_valid(const char *s)
{
    int n = 0;
    for (; s[n]; n++) {
        const char c = s[n];
        if (n >= 15 || !((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-')) return 0;
    }
    return n > 0;
}
static int name_taken(const char *n)
{
    for (int i = 0; stock[i]; i++) if (ob_eq(stock[i], n)) return 1;
    for (int i = 0; kn_own_seq[i]; i++) if (ob_eq(kn_own_seq[i], n)) return 1;
    for (int i = 0; i < kn_feature_count(); i++) {
        const op1_seq_type_t *t = kn_feature_at(i)->seq;
        if (t && ((t->name && ob_eq(t->name, n)) || (t->alias && ob_eq(t->alias, n)))) return 1;
    }
    for (int k = 0; k < n_seq; k++) if (ob_eq(os[k].saved, n)) return 1;
    return 0;
}
static const char *saved_name(const char *name, char *out)       /* D4: "dots" -> "dots_o" */
{
    if (!name_taken(name)) return ob_cat(out, name), out;
    if (ob_len(name) > 13) return 0;
    ob_cat(ob_cat(out, name), "_o");
    return name_taken(out) ? 0 : out;
}
static int opus_seq_register(opl_self *self, const opus_sequencer *d)
{
    ob_file *f = ob_cur;
    if (!f || self != &f->self) return -1;
    const char *why = 0;
    char m[80];
    if (n_seq >= OS_TYPES) why = "too many sequencers";
    else if (!d || !ob_inside(f, d) || d->size <= 0xb) why = "a bad sequencer struct";
    else if (!ob_inside(f, d->name) || !name_valid(d->name) || !d->player || !ob_inside(f, (const void *)d->player))
        why = "a bad sequencer (a name of a-z 0-9 -, no space here)";
    if (why) { kn_log_line(f->self.id, why); return -1; }
    os_type *T = &os[n_seq];
    for (unsigned i = 0; i < sizeof *T; i++) ((uint8_t *)T)[i] = 0;
    if (!saved_name(d->name, T->saved)) { kn_log_line(f->self.id, "a sequencer name in use"); return -1; }
    T->d = d; T->file = f;
    T->kt = tmpl[n_seq];
    T->kt.name = T->saved;
    if (has(d, 0x2C) && d->alias && ob_inside(f, d->alias) && name_valid(d->alias) && !name_taken(d->alias)) {
        ob_cat(T->alias, d->alias);
        T->kt.alias = T->alias;
    }
    char *p = ob_cat(ob_cat(m, "sequencer "), T->saved);
    if (T->kt.alias) p = ob_cat(ob_cat(p, " alias "), T->alias);
    if (has(d, 0x30) && d->page_key) p = ob_cat(p, " page_key");
    kn_log_line(f->self.id, m);
    return n_seq++;
}
static int s_seq_mode(void) { return CUR_MODE(); }
/* after the stage: the committed types to the core (taken after the features' sequencers) */
void os_offer(void)
{
    for (int k = 0; k < n_seq; k++)
        if (kn_seq_foreign_offer(&os[k].kt)) kn_log_line(os[k].file->self.id, "sequencer: no room");
}

const ob_sym os_imports[] = {
    { "fw_vc_note_off", (uint32_t)s_note_off },
    { "fw_vc_note_on", (uint32_t)s_note_on },
    { "opus_on_block", (uint32_t)s_on_block },
    { "opus_seq_mode", (uint32_t)s_seq_mode },
    { "opus_seq_register", (uint32_t)opus_seq_register },
};
const int os_n_imports = (int)(sizeof os_imports / sizeof os_imports[0]);
