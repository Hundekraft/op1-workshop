/*
 * Opus effects as kennel FX (Opus bridge phase 2, opus.h). opus_effect_register makes one kennel op1_fx_stereo_t per
 * Opus effect type and registers it under its saved name (kn_foreign_add); the entry's callbacks are trampolines stamped
 * per type (kennel's FX callbacks carry no context), so a type number picks the record.
 *
 * Instances: one per kennel FX position (0 synth, 1 drum: mono; 2 master: stereo when the type has `stereo`). state
 * comes from the arena at registration (the file's transaction); bulk and fast from the position's big lease
 * (op1_fx_big, 1 MiB, only the active FX of that position uses it). Opus promises cleared bulk; the lease is dirty after
 * an FX switch, and init may run on the audio thread, so the bulk is cleared OX_CLEAR bytes a block from render: the
 * position passes the dry signal until the clear is done, then the type's init runs and it renders (plate: 17 blocks,
 * 25 ms). No L1: `fast` lies after the bulk in the same lease (allowed: "else SDRAM").
 *
 * Params: an Opus type sees its own units, limits[i] = {lo, hi, step} (step: the turn's size, 0 = no knob moves it).
 * Kennel's words 0..3 are the four knobs (raw in the filter slot's ranges): per block, q15 = op1_fx_param_q15, then
 * lo + q15 * (hi - lo) / 32767 (one division per knob per block), or, for a small range (hi - lo + 1 <= 32: a
 * selector), an OP1_FX_STEPS(n) knob and lo + ((q15 * n) >> 15). A step 0 param stays at its default.
 *
 * Shift layer (params 4..7, 2026-11-18): Shift + turn of encoder 0..3 on the page of a type with `shift_knob` comes
 * here from dispatcher.c (kn_foreign_fx_shift, KeyHandler) before kennel's own op1_fx_shift path. As the Opus core
 * (fx_page_turn_stock): rest += delta >> 10, steps = rest / 4 (OX_SHIFT_UNIT a step), shift_knob(copy of the eight
 * params, encoder, steps) even for 0 steps; 1 keeps the copy's params 4..7 and the steps used, 0 drops the rest and
 * falls back, as the Opus core, to its stock Shift + turn (fine_turn: params 0..3 at 1/16 of a plain turn's step, written
 * to the knob words 0..3 as a plain turn's; also for a type without shift_knob, bitcrush). The params live in the
 * position's FX words, so the sound saves and loads them as any FX's page-2 words: word 5 = par 4, word 6 = par 5
 * (exact, 0..32767), word 7 bits 0..6 = par 6 and bits 8..14 = par 7 at 7 bits (f * 32767 / 127), bit 7 = set. With
 * bit 7 clear (a sound saved before, a fresh pick: its fx_types row has words 5..7 = 0) all four are the type's
 * defaults. Every word stays in 0..32767. Read per block in map_params (one 16-bit word each: no tearing), written
 * on the GUI side only; a type without shift_knob never reads them.
 *
 * Names (owner D4, 2026-11-17): an effect whose name kennel has (one of its own FX, loaded or not, or a stock FX) shows
 * and saves as the name plus "_o" ("plate_o"); kennel's keeps the plain name; both are listed.
 *
 * The page: kennel's FX screen slot, an empty SVG (usbout.svg, as the T2/T4 pages use) drawn in code from the type's
 * `view`: the four labels and values in the encoders' colours in the corners, up to three 128-sample waves in the
 * middle and the caption under them; an effect with its own page (`page`, core 2.34: chorus, plate) draws that instead,
 * with the page primitives, its art and opus_page_now (phase 9). Its `svg` / `screen_draw` are not used: their
 * screen is empty in both files (blank.svg), as kennel's slot is.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../op1_synth.h"
#include "../kennel/kn_foreign.h"
#include "../kennel/kn_load.h"
#include "../kn_mem.h"
#include "../op1_feature_sound.h"                       /* op1_sound_fx */

void *kn_alloc(uint32_t size);
void kn_log_line(const char *file, const char *msg);

#define OX_CLEAR 8192u                      /* bulk bytes cleared a block */

typedef struct {
    opus_fx fx;
    uint32_t clear_at, clear_n;             /* bulk + fast bytes cleared so far, to clear */
    uint8_t ready, stereo;
    int16_t par[8];                         /* the Opus params the last block used */
    of_slot slot;                           /* its claim of the position's partition (opus_fast.c) */
} ox_pos;
typedef struct {
    const opus_effect *e;
    ob_file *file;
    op1_fx_stereo_t entry;
    char saved[16];
    int16_t def_q15[4];
    uint8_t steps[4];                       /* n of an OP1_FX_STEPS knob, else 0 */
    opus_need need[2];                      /* mono, stereo */
    uint8_t *state[3];
    ox_pos pos[3];
} ox_type;
static ox_type ox[OX_TYPES];
static int n_types;

int ox_count(void) { return n_types; }
void ox_rollback(int n) { if (n >= 0 && n < n_types) n_types = n; }
const void *ox_entry(int k) { return k >= 0 && k < n_types ? &ox[k].entry : 0; }
int ox_ready(int k, int pos) { return k >= 0 && k < n_types && pos >= 0 && pos < 3 && ox[k].pos[pos].ready; }
const int16_t *ox_params(int k, int pos) { return ox[k].pos[pos].par; }
const opus_effect *ox_effect(int k) { return k >= 0 && k < n_types ? ox[k].e : 0; }

/* ---- params: per block ---- */
#define OX_SHIFT_SET 0x80                   /* word 7 bit 7: words 5..7 hold the shift layer */
static int has_shift(const ox_type *t) { return t->e->shift_knob && ob_inside(t->file, (const void *)t->e->shift_knob); }
static int16_t dec7(int f) { return (int16_t)((f * 32767 + 63) / 127); }
static int enc7(int v) { v = v < 0 ? 0 : v > 32767 ? 32767 : v; return (v * 127 + 16383) / 32767; }
static void map_params(const ox_type *t, const int16_t *words, int16_t *par)
{
    const opus_effect *e = t->e;
    const int sh = (words[7] & OX_SHIFT_SET) && has_shift(t);
    for (int i = 0; i < 8; i++) {
        const int32_t lo = e->limits[i][0], hi = e->limits[i][1], st = e->limits[i][2];
        if (i >= 4) {
            if (!sh) par[i] = e->defaults[i];
            else if (i < 6) par[i] = words[i + 1] < 0 ? 0 : words[i + 1];
            else par[i] = dec7((words[7] >> (i == 6 ? 0 : 8)) & 127);
            continue;
        }
        if (st <= 0 || hi <= lo) { par[i] = e->defaults[i]; continue; }
        const int32_t q = op1_fx_param_q15(words, i);
        int32_t v;
        if (t->steps[i]) {
            int32_t k = (q * t->steps[i]) >> 15;
            if (k >= t->steps[i]) k = t->steps[i] - 1;
            v = lo + k;
        } else v = lo + q * (hi - lo) / 32767;
        par[i] = (int16_t)v;
    }
}

/* ---- instances ---- */
static void clear_words(uint8_t *p, uint32_t n) { for (uint32_t i = 0; i + 4 <= n; i += 4) *(volatile uint32_t *)(p + i) = 0; }
static void x_init(int k, int pos)
{
    if (k >= n_types || pos < 0 || pos > 2) return;
    ox_type *t = &ox[k];
    ox_pos *p = &t->pos[pos];
    p->ready = 0;
    p->stereo = (uint8_t)(pos == OP1_FX_MASTER && t->e->stereo);
    const opus_need *n = &t->need[p->stereo];
    clear_words(t->state[pos], (n->state + 3) & ~3u);
    p->fx.state = n->state ? t->state[pos] : 0;
    p->fx.bulk = p->fx.fast = 0;
    p->fx.stereo = p->stereo;
    p->clear_at = 0;
    p->clear_n = ((n->bulk + 31) & ~31u) + ((n->fast + 31) & ~31u);
    if (!p->clear_n) { t->e->init(&p->fx); p->ready = 1; }
}
/* Fast memory (opus_fast.c): the position's L1 partition around a call, with a moving `fast` part (fast_moves:
 * OPUS_FAST_SCRATCH + 1 or OPUS_FAST_STATE + 1) at its start (kept with STATE) and the file's leases after it. The
 * SDRAM copy (home) lies after the bulk in the position's big lease. -> where fast lies for this call. */
static uint8_t *fx_enter(ox_type *t, int pos, uint8_t *home, uint32_t *tk)
{
    const opus_need *nd = &t->need[t->pos[pos].stereo];
    const uint32_t front = nd->fast && nd->fast_moves && home ? (nd->fast + 3u) & ~3u : 0;
    const uint32_t state = front && nd->fast_moves == 3 ? front : 0;
    uint8_t *at = of_enter(&t->pos[pos].slot, t->file, op1_l1_fx_part(pos), home, front, state, tk);
    return front ? at : home;
}
static uint8_t *fast_home(ox_type *t, int pos)
{
    const opus_need *nd = &t->need[t->pos[pos].stereo];
    uint32_t size;
    uint8_t *lease = op1_fx_big(pos, &size);
    return nd->fast && lease ? lease + ((nd->bulk + 31) & ~31u) : 0;
}
static int x_settle(ox_type *t, int pos)                        /* the bulk cleared a slice a block; 1 ready */
{
    ox_pos *p = &t->pos[pos];
    uint32_t size;
    uint8_t *lease = op1_fx_big(pos, &size);
    if (!lease || size < p->clear_n) return 0;                  /* (no pool yet: dry) */
    uint32_t n = p->clear_n - p->clear_at;
    if (n > OX_CLEAR) n = OX_CLEAR;
    clear_words(lease + p->clear_at, n);
    p->clear_at += n;
    if (p->clear_at < p->clear_n) return 0;
    const opus_need *nd = &t->need[p->stereo];
    p->fx.bulk = nd->bulk ? lease : 0;
    p->fx.fast = nd->fast ? lease + ((nd->bulk + 31) & ~31u) : 0;
    uint32_t tk;
    uint8_t *f = fx_enter(t, pos, p->fx.fast, &tk);
    if (f != p->fx.fast) clear_words(f, (nd->fast + 3u) & ~3u);   /* the moving part in L1: cleared there (a holder
                                                                 * that stayed one keeps its old bytes, never copied) */
    p->fx.fast = f;
    t->e->init(&p->fx);
    of_leave(tk);
    p->ready = 1;
    return 1;
}
static void x_render(int k, int pos, int16_t *buf, const int16_t *words)
{
    if (k >= n_types || pos < 0 || pos > 2) return;
    ox_type *t = &ox[k];
    ox_pos *p = &t->pos[pos];
    if (!p->ready && !x_settle(t, pos)) return;
    map_params(t, words, p->par);
    uint32_t tk;
    p->fx.fast = fx_enter(t, pos, fast_home(t, pos), &tk);
    t->e->mono(&p->fx, buf, p->par);
    of_leave(tk);
}
static void x_render_st(int k, int pos, int16_t *l, int16_t *r, const int16_t *words)
{
    if (k >= n_types || pos < 0 || pos > 2) return;
    ox_type *t = &ox[k];
    ox_pos *p = &t->pos[pos];
    if (!p->ready && !x_settle(t, pos)) return;
    map_params(t, words, p->par);
    uint32_t tk;
    p->fx.fast = fx_enter(t, pos, fast_home(t, pos), &tk);
    t->e->stereo(&p->fx, l, r, p->par);
    of_leave(tk);
}

/* ---- the shift layer: Shift + turn on the page (KeyHandler) ---- */
#define OX_SHIFT_UNIT 4                     /* steps of delta >> 10 a shift_knob detent (the Opus core's) */
static int32_t shift_rest[4];
/* the Opus core's stock Shift + turn (fx_page_turn_stock, not handled by a shift layer): param enc moves by
 * step x (delta >> 4) >> 15, rounded half to even, kept in its limits; written back as the raw knob word that maps
 * closest to it (ties: the one nearer the word it had). A selector knob (OP1_FX_STEPS) or a step 0 param: not taken. */
static int32_t raw_param(const ox_type *t, int i, int32_t raw)
{
    int16_t tmp[8];
    for (int j = 0; j < 8; j++) tmp[j] = 0;
    tmp[i] = (int16_t)raw;
    const int32_t lo = t->e->limits[i][0], hi = t->e->limits[i][1];
    return lo + op1_fx_param_q15(tmp, i) * (hi - lo) / 32767;
}
static int fine_turn(const ox_type *t, int16_t *w, int enc, int delta)
{
    const int32_t lo = t->e->limits[enc][0], hi = t->e->limits[enc][1], st = t->e->limits[enc][2];
    if (st <= 0 || hi <= lo || t->steps[enc]) return 0;
    int16_t par[8];
    map_params(t, w, par);
    const int32_t x = st * (delta >> 4);
    int32_t q = x >> 15;
    const int32_t frac = x & 0x7fff;
    if (frac > 0x4000 || (frac == 0x4000 && (q & 1))) q++;
    int32_t r = q + par[enc];
    r = r > 0x7fff ? 0x7fff : r < -0x8000 ? -0x8000 : r;
    r = r < lo ? lo : r > hi ? hi : r;
    const int16_t *rg = (const int16_t *)(0x01DE5C50 + 5 * 0x30 + enc * 6);   /* the filter type's raw range */
    int32_t rlo = rg[0], rhi = rg[1];
    if (rhi <= rlo) { rlo = 0; rhi = 32767; }
    int32_t est = rlo + ((r - lo) * 32767 / (hi - lo)) * (rhi - rlo) / 32767;
    int32_t best = w[enc], bd = 0x7fffffff;
    for (int32_t c = est - 4; c <= est + 4; c++) {
        if (c < rlo || c > rhi) continue;
        int32_t d = raw_param(t, enc, c) - r;
        d = d < 0 ? -d : d;
        const int32_t far = c - w[enc] < 0 ? w[enc] - c : c - w[enc], bfar = best - w[enc] < 0 ? w[enc] - best : best - w[enc];
        if (d < bd || (d == bd && far < bfar)) { bd = d; best = c; }
    }
    if (best == w[enc]) return 1;
    w[enc] = (int16_t)best;
    return 2;
}
/* A plain turn on a bridged effect's page (dispatcher.c, before the shift paths): its page_turn (core 2.31, +0x70) with
 * what the page shows (kind 0, T 3, its position, the params mapped from the words, a copy), detents as the Opus core
 * counts them (rest += delta >> 10, a detent every four), even 0. The page's feedback only (chorus: the turned knob's
 * digits flash): the turn goes on to kennel's knob handling whatever it answers, and the copy's params are dropped. */
#define FX_PAGE_TURN_AT 0x70u
static int32_t turn_rest[4];
void kn_foreign_fx_turn(const void *fx, const int16_t *w, int knob, int delta)
{
    if (!fx || !w || knob < 0 || knob > 3) return;
    int k = 0;
    while (k < n_types && (const void *)&ox[k].entry.mono != fx) k++;
    if (k >= n_types) return;
    ox_type *t = &ox[k];
    if (t->e->size < FX_PAGE_TURN_AT + 4) return;
    int (*fn)(opus_page *, int, int) = *(int (*const *)(opus_page *, int, int))((const uint8_t *)t->e + FX_PAGE_TURN_AT);
    if (!fn || !ob_inside(t->file, (const void *)fn)) return;
    const int pos = op1_fx_screen_pos();
    if (pos < 0 || pos > 2) return;
    turn_rest[knob] += delta >> 10;
    const int n = turn_rest[knob] / 4;
    turn_rest[knob] -= n * 4;
    static int16_t par[8];
    static opus_page pg;
    map_params(t, w, par);
    pg.kind = 0; pg.t = 3; pg.where = (int16_t)pos; pg.slot = (int16_t)(pos == 2 ? 0 : OP1_SCREEN_SLOT & 7);
    pg.on = 1; pg.n = 8; pg.key = -1;
    for (int i = 0; i < 8; i++) pg.live[i] = par[i];
    pg.par = par; pg.inst = &t->pos[pos].fx; pg.module = t->e;
    (void)fn(&pg, knob, n);
}
/* params 4..7 into words 5..7 (the layer's storage, above): 1 when a word changed */
static int put_shift(int16_t *w, const int16_t *par)
{
    const int16_t w5 = (int16_t)(par[4] < 0 ? 0 : par[4]), w6 = (int16_t)(par[5] < 0 ? 0 : par[5]);
    const int16_t w7 = (int16_t)(enc7(par[6]) | enc7(par[7]) << 8 | OX_SHIFT_SET);
    if (w[5] == w5 && w[6] == w6 && w[7] == w7) return 0;
    w[5] = w5; w[6] = w6;                   /* 5 and 6 before the set bit (the audio thread reads per block) */
    w[7] = w7;
    return 1;
}
int kn_foreign_fx_shift(const void *fx, int16_t *w, int knob, int delta)
{
    if (!fx || !w || knob < 0 || knob > 3) return 0;
    int k = 0;
    while (k < n_types && (const void *)&ox[k].entry.mono != fx) k++;
    if (k >= n_types) return 0;
    const ox_type *t = &ox[k];
    if (!has_shift(t)) return fine_turn(t, w, knob, delta);
    int16_t par[8];
    map_params(t, w, par);
    const int32_t rest = shift_rest[knob] + (delta >> 10);
    shift_rest[knob] = rest;
    const int steps = rest / OX_SHIFT_UNIT;
    if (!t->e->shift_knob(par, knob, steps)) { shift_rest[knob] = 0; return fine_turn(t, w, knob, delta); }
    shift_rest[knob] -= steps * OX_SHIFT_UNIT;
    return put_shift(w, par) ? 2 : 1;
}
/* An LFO type's move of a bridged effect's shift layer (opus_lfo.c s_move, group 2, params 4..7; the audio thread, on
 * the pass's stage copy of the FX words, never the sound's stored ones). As the Opus core's opus_lfo_move for a param
 * whose step is 0 (every shift param in the pack): add, clamp to the limits; then kept as the layer keeps it (par 6 / 7
 * at 7 bits), with the other three taken from the words (or the type's defaults while bit 7 is clear) and bit 7 set. */
int ox_lfo_shift(int16_t *w, int p, int32_t delta)
{
    if (!w || p < 4 || p > 7) return -1;
    const void *fx = op1_sound_fx(w[4] - OP1_ENGINE_MAGIC);
    int k = 0;
    while (fx && k < n_types && (const void *)&ox[k].entry.mono != fx) k++;
    if (!fx || k >= n_types) return -1;
    const ox_type *t = &ox[k];
    if (!has_shift(t)) return 0;
    const int32_t lo = t->e->limits[p][0], hi = t->e->limits[p][1];
    if (hi <= lo) return 0;
    int16_t par[8];
    map_params(t, w, par);
    const int32_t d = delta > 32767 ? 32767 : delta < -32768 ? -32768 : delta;
    int32_t v = par[p] + d;
    par[p] = (int16_t)(v < lo ? lo : v > hi ? hi : v);
    put_shift(w, par);
    return 1;
}

/* ---- a sound saved on Opus (opus_saved.c, before the parse): its effect in kennel's words ---- */
#define FX_ALIASES_AT 0x74u                 /* aliases (core 2.33): a space separated list ("opus1:10") */
static int alias_of(const ox_type *t, const char *name)
{
    if (t->e->size < FX_ALIASES_AT + 4) return 0;
    const char *a = *(const char *const *)((const uint8_t *)t->e + FX_ALIASES_AT);
    if (!a || !ob_inside(t->file, a)) return 0;
    for (;;) {                              /* as the Opus core's fx_type_id_by_name */
        while (*a == ' ') a++;
        if (!*a) return 0;
        const char *q = name;
        while (*a && *a != ' ' && *a == *q) { a++; q++; }
        if (!*q && (*a == ' ' || !*a)) return 1;
        while (*a && *a != ' ') a++;
    }
}
/* the raw knob word whose param (map_params) is nearest p (ties: the lower word) */
static int16_t word_for(const ox_type *t, int i, int32_t p)
{
    const int32_t lo = t->e->limits[i][0], hi = t->e->limits[i][1], st = t->e->limits[i][2];
    const int16_t *rg = (const int16_t *)(0x01DE5C50 + 5 * 0x30 + i * 6);   /* the filter type's raw range */
    int32_t rlo = rg[0], rhi = rg[1];
    if (rhi <= rlo) { rlo = 0; rhi = 32767; }
    if (st <= 0 || hi <= lo) return (int16_t)rlo;          /* (map_params gives the default whatever the word) */
    p = p < lo ? lo : p > hi ? hi : p;
    int32_t q;
    if (t->steps[i]) q = ((2 * (p - lo) + 1) * 32768) / (2 * t->steps[i]);
    else q = ((p - lo) * 32767 + (hi - lo) / 2) / (hi - lo);
    q = q > 32767 ? 32767 : q;
    const int32_t est = rlo + (q * (rhi - rlo) + 16383) / 32767;
    int32_t best = est, bd = 0x7fffffff;
    for (int32_t c = est - 4; c <= est + 4; c++) {
        if (c < rlo || c > rhi) continue;
        int16_t tmp[8];
        for (int j = 0; j < 8; j++) tmp[j] = 0;
        tmp[i] = (int16_t)c;
        int32_t v;
        if (t->steps[i]) { int32_t k = (op1_fx_param_q15(tmp, i) * t->steps[i]) >> 15; v = lo + (k >= t->steps[i] ? t->steps[i] - 1 : k); }
        else v = raw_param(t, i, c);
        const int32_t d = v - p < 0 ? p - v : v - p;
        if (d < bd) { bd = d; best = c; }
    }
    return (int16_t)best;
}
/* An effect a sound names by its Opus name or one of its aliases (the Opus core's fx_type_id_by_name), whose words are
 * the Opus core's (each param in the type's own units, param 4 in word 4): the saved name it opens as here, its words
 * made kennel's in w (the knob words 0..3 that map nearest, word 4 the selector, the shift layer in words 5..7). 0 when
 * no bridged type has the name, or when it is a sound kennel saved: its type is the saved name and word 4 a selector
 * (0x5300 band: kennel's PLATE for "plate", the bridged chorus for "chorus"); an alias with a selector is only renamed. */
const char *ox_from_opus(const char *name, int16_t *w)
{
    if (!name || !*name || !w) return 0;
    const int sel = (uint16_t)w[4] >> 8 == OP1_ENGINE_MAGIC >> 8;
    for (int k = 0; k < n_types; k++) {
        const ox_type *t = &ox[k];
        const int own = ob_eq(t->e->name, name), alias = !own && alias_of(t, name);
        if (!own && !alias) continue;
        if (sel && (own || ob_eq(t->saved, name))) return 0;   /* kennel's sound (its own type or this one) */
        if (sel) return t->saved;                               /* an alias kennel's words already carry */
        int16_t par[8];
        for (int i = 0; i < 8; i++) par[i] = w[i];
        for (int i = 0; i < 4; i++) w[i] = word_for(t, i, par[i]);
        w[4] = (int16_t)(OP1_ENGINE_MAGIC + kn_plugin_order(1, t->saved));
        w[5] = w[6] = w[7] = 0;
        if (has_shift(t)) {
            for (int i = 4; i < 8; i++) {
                const int32_t lo = t->e->limits[i][0], hi = t->e->limits[i][1];
                if (hi > lo) par[i] = (int16_t)(par[i] < lo ? lo : par[i] > hi ? hi : par[i]);
            }
            put_shift(w, par);
        }
        return t->saved;
    }
    return 0;
}

/* ---- the generic page from `view` ---- */
#define PAGE_TEXTS 9
static uint8_t texts[PAGE_TEXTS][OP1_TEXT_SIZE] __attribute__((aligned(4)));
static uint8_t made[PAGE_TEXTS];
static char shown[PAGE_TEXTS][16];
static const uint8_t col[5][4] = { { 107, 142, 255, 255 }, { 0, 239, 148, 255 }, { 255, 255, 255, 255 }, { 255, 65, 57, 255 },
                                   { 160, 160, 160, 255 } };
static void text(void *r, int n, int x, int y, int size, const char *s, const uint8_t *c)
{
    static const int32_t identity[9] = { 1024, 0, 0, 0, 1024, 0, 0, 0, 1024 };
    if (!s) s = "";
    if (!made[n]) { op1_text_ctor(texts[n], x << 10, y, size, c); made[n] = 1; }
    int i = 0;
    while (s[i] && i < 15 && shown[n][i] == s[i]) i++;
    if ((s[i] && i < 15) || shown[n][i]) {
        for (i = 0; i < 15 && s[i]; i++) shown[n][i] = s[i];
        shown[n][i] = 0;
        op1_text_set(texts[n], shown[n]);
    }
    op1_text_draw(texts[n], r, identity);
}
/* the effect's own page (core 2.34: `page`, +0x78, inside its image), else 0 */
#define FX_PAGE_AT 0x78u
static void (*own_page(const ox_type *t))(void)
{
    if (t->e->size < FX_PAGE_AT + 4) return 0;
    void (*fn)(void) = *(void (*const *)(void))((const uint8_t *)t->e + FX_PAGE_AT);
    return fn && ob_inside(t->file, (const void *)fn) ? fn : 0;
}
void oe_page_frame(void *scr, const ob_file *f, int which, void (*fn)(void));   /* opus_engine.c */
static void page(int k, void *scr, int dt)
{
    op1_screen_draw(scr, dt);
    if (k >= n_types) return;
    ox_type *t = &ox[k];
    void *r = op1_raster();
    const int pos = op1_fx_screen_pos();
    int16_t par[8];
    map_params(t, op1_fx_knobs(pos), par);
    void (*fn)(void) = own_page(t);
    if (fn && pos >= 0 && pos <= 2) {                           /* its own page, with what it shows (opus_page_now) */
        oa_page_set(0, 3, pos, pos == 2 ? 0 : OP1_SCREEN_SLOT & 7, par, 0, &t->pos[pos].fx, t->e);
        oe_page_frame(scr, 0, 0, fn);
        return;
    }
    opus_fx_view v;
    {
        uint32_t *w = (uint32_t *)&v;
        for (unsigned i = 0; i < sizeof v / 4; i++) w[i] = 0;
    }
    if (t->e->view) t->e->view(par, &v);
    static const int16_t xy[4][2] = { { 14, 16 }, { 14, 92 }, { 246, 16 }, { 246, 92 } };
    for (int i = 0; i < 4; i++) {
        text(r, i, xy[i][0], xy[i][1], 14, v.label[i] ? v.label[i] : "", col[i]);
        text(r, 4 + i, xy[i][0], xy[i][1] + 18, 24, v.value[i] ? v.value[i] : "", col[2]);
    }
    text(r, 8, 112, 126, 14, v.caption ? v.caption : t->saved, col[0]);
    for (int w = 0; w < v.waves && w < 3; w++) {
        const int16_t *s = v.wave[w];
        if (!s) continue;
        int py = 76 - (s[0] >> 11);
        for (int i = 1; i < OPUS_FX_WAVE; i++) {
            int y = 76 - (s[i] >> 11);
            op1_pt a = { (96 + i - 1) << 10, py << 10 }, b = { (96 + i) << 10, y << 10 };
            op1_raster_line(r, &a, &b, 768, col[w == 0 ? 2 : w]);
            py = y;
        }
    }
}
static void page_init(void *scr) { (void)scr; }

/* ---- trampolines: kennel's callbacks per type ---- */
#define TR(k) \
    static void in##k(int pos) { x_init(k, pos); } \
    static void re##k(int pos, int16_t *b, const int16_t *p) { x_render(k, pos, b, p); } \
    static void st##k(int pos, int16_t *l, int16_t *r, const int16_t *p) { x_render_st(k, pos, l, r, p); } \
    static void up##k(void *scr, int dt) { page(k, scr, dt); }
TR(0) TR(1) TR(2) TR(3) TR(4) TR(5) TR(6) TR(7)
static void (*const t_init[OX_TYPES])(int) = { in0, in1, in2, in3, in4, in5, in6, in7 };
static void (*const t_render[OX_TYPES])(int, int16_t *, const int16_t *) = { re0, re1, re2, re3, re4, re5, re6, re7 };
static const op1_fx_stereo_render_t t_stereo[OX_TYPES] = { st0, st1, st2, st3, st4, st5, st6, st7 };
static const op1_screen_t t_screen[OX_TYPES] = { { page_init, up0 }, { page_init, up1 }, { page_init, up2 },
    { page_init, up3 }, { page_init, up4 }, { page_init, up5 }, { page_init, up6 }, { page_init, up7 } };

/* ---- names (D4) ---- */
static const char *const kennel_fx[] = {                        /* kennel's FX plugins' saved names (plugins/ fx) and */
    "clouds", "crush", "ente", "father", "hail", "in a room", "juni chorus", "nostromo", "palme", "plate",
    "rackverb", "reverb", "sister", "snowglobe", "steve", "stutter", "tape", "warble", "washer",
    "delay", "grid", "punch", "phone", "spring", "filter", "nitro", "cwo", 0 };   /* R246's own */
static int name_ok(const char *s)
{
    int n = 0;
    for (; s[n]; n++) {
        const char c = s[n];
        if (n >= 13 || !((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == ' ' || c == '_' || c == '+' || c == '-'))
            return 0;                                           /* 13: room for "_o" within 15 */
    }
    return n > 0;
}
const char *ox_saved_name(const char *name, char *out)
{
    if (!name_ok(name)) return 0;
    int clash = kn_plugin_order(1, name) != 0;
    for (int i = 0; kennel_fx[i] && !clash; i++) clash = ob_eq(kennel_fx[i], name);
    char *e = ob_cat(out, name);
    if (clash) ob_cat(e, "_o");
    return out;
}

/* ---- registration (from opl_init) ---- */
int opus_effect_register(opl_self *self, const opus_effect *e)
{
    ob_file *f = ob_cur;
    if (!f || self != &f->self) return -4;
    const char *why = 0;
    char m[64];
    if (n_types >= OX_TYPES) why = "too many effect types";
    else if (!e || !ob_inside(f, e) || e->size < OPUS_EFFECT_V2) why = "a bad effect struct";
    else if (!ob_inside(f, e->name) || !ob_inside(f, (const void *)e->need) || !ob_inside(f, (const void *)e->init) ||
             !ob_inside(f, (const void *)e->mono) || (e->stereo && !ob_inside(f, (const void *)e->stereo)) ||
             (e->view && !ob_inside(f, (const void *)e->view)))
        why = "a callback outside its image";
    if (why) { kn_log_line(f->self.id, why); return -1; }
    ox_type *t = &ox[n_types];
    if (!ox_saved_name(e->name, t->saved)) { kn_log_line(f->self.id, "a bad effect name"); return -1; }
    {
        uint32_t *w = (uint32_t *)t->need;
        for (unsigned i = 0; i < sizeof t->need / 4; i++) w[i] = 0;
    }
    e->need(0, &t->need[0]);
    if (e->stereo) e->need(1, &t->need[1]);
    for (int s = 0; s < 2; s++) {
        const opus_need *n = &t->need[s];
        if (n->state > 65536 || n->bulk > KN_FX_BIG_SIZE - 64 || n->fast > 65536 ||
            ((n->bulk + 31) & ~31u) + ((n->fast + 31) & ~31u) > KN_FX_BIG_SIZE) {
            kn_log_line(f->self.id, "an effect needs more memory than a position has");
            return -2;
        }
    }
    for (int p = 0; p < 3; p++) {
        uint32_t n = t->need[p == OP1_FX_MASTER && e->stereo].state;
        uint8_t *a = n ? kn_alloc(n + 32) : 0;
        if (n && !a) { kn_log_line(f->self.id, "plugin memory full"); return -2; }
        t->state[p] = a ? (uint8_t *)(((uint32_t)a + 31) & ~31u) : 0;
        t->pos[p].ready = 0;
        t->pos[p].slot.c.f = 0; t->pos[p].slot.c.base = 0; t->pos[p].slot.ret = 0; t->pos[p].slot.tick = 0;
    }
    t->e = e; t->file = f;
    for (int i = 0; i < 4; i++) {
        const int32_t lo = e->limits[i][0], hi = e->limits[i][1], st = e->limits[i][2];
        int32_t d = e->defaults[i];
        t->steps[i] = 0;
        if (st > 0 && hi > lo && hi - lo + 1 <= 32) t->steps[i] = (uint8_t)(hi - lo + 1);   /* a small range: a selector */
        if (d < lo) d = lo;
        if (d > hi) d = hi;
        if (hi <= lo || st <= 0) t->def_q15[i] = 0;
        else if (t->steps[i]) t->def_q15[i] = (int16_t)(((2 * (d - lo) + 1) * 32768) / (2 * t->steps[i]));
        else t->def_q15[i] = (int16_t)(((d - lo) * 32767 + (hi - lo) / 2) / (hi - lo));
        t->entry.mono.press[i] = t->steps[i] ? (uint8_t)OP1_FX_STEPS(t->steps[i]) : OP1_PRESS_NONE;
    }
    const int k = n_types;
    t->entry.mono.init = t_init[k];
    t->entry.mono.render = t_render[k];
    t->entry.render_stereo = e->stereo ? t_stereo[k] : 0;
    kn_foreign_desc d = { 1, 1, 0, e->stereo ? KN_FLAG_STEREO : 0u, t->saved, &t->entry, &t_screen[k], "usbout.svg",
                          t->def_q15, 0 };
    const char *err = kn_foreign_add(&d);
    if (err) {
        ob_cat(ob_cat(ob_cat(m, t->saved), ": "), err);
        kn_log_line(f->self.id, m);
        return -3;
    }
    n_types++;
    ob_cat(ob_cat(m, "effect "), t->saved);
    kn_log_line(f->self.id, m);
    return 8 + k;
}
