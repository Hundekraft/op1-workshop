/*
 * Fast memory for .opmod files (Opus bridge, opus.h): opus_fast_lease / opus_fast_use (core 2.21) over kennel's L1 pool
 * (kennel/kn_l1.h kn_l1_claim_ex), and the adapters' moving state (an engine's voices with OPUS_ENGINE_STATE_MOVES, an
 * effect's `fast` with fast_moves) in the same claim.
 *
 * kennel's pool has one partition per audio position (synth engine 8,192 B, synth / drum FX 8,320 B, master FX 4,160 B,
 * drum 512 B), each a lease: its holder keeps it while it claims it every block, anyone else gets it after two idle
 * blocks. The bridge claims the position's partition for a file around each audio call into it (of_enter / of_leave):
 *   [0, front)              the adapter's own: the engine's voices or the effect's fast part; [0, state) of it is kept
 *                           (kennel copies it from home in and back out), the rest scratch;
 *   [OF_AL(front), ...)     the file's leases in the order taken, each 32-byte aligned, as many as fit.
 * A lease that fits is in L1 while the claim holds: opus_fast_use gives its L1 copy, else its own copy (`slow`). On a
 * fresh claim the CONST and STATE leases are copied in; when the partition goes (another owner takes over, page 7's
 * switch), kennel calls of_gone, which copies the STATE leases back to their own copies. So a file sees the other core's
 * contract: fast when there is room, its own copy otherwise, its bytes kept across moves. Unlike the other core there is
 * no priority between files (kennel's rule: the one that plays holds it) and a lease is per position, so an effect
 * file playing at the synth FX and at the master has a copy in each partition's turn, never both at once.
 * opus_fast (fast memory for good) still answers 0 ("none left"): kennel lends L1 only by lease.
 *
 * Threads: of_enter on the audio thread (render, the voice-sum block, an effect's render) or around an engine's
 * note_on / release / init on the key thread (kn_l1_thread_enter holds off takeovers while that call runs; a claim there
 * gets the partition only for its holder). Each context has its own record: the callback's is the claimant's slot (its
 * first call in a block claims, the later ones reuse that claim inline: opus.h of_enter), a thread's is `thr`; of_now
 * points at the one in use. OQ_VPTR files (castle) keep pointers to their voices: rebased with the voices on a fresh
 * claim and in of_gone.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../kennel/kn_l1.h"
#include "../kn_mem.h"

void kn_log_line(const char *file, const char *msg);

#define OF_LEASES 32
#define OF_AL(n) (((uint32_t)(n) + 31u) & ~31u)
#define OF_SCRATCH 0
#define OF_CONST 1
#define OF_STATE 2
#define OF_NONE 0xFFFFu

typedef struct of_lease {
    ob_file *f;
    uint8_t *slow;
    uint32_t bytes;
    uint16_t place[OP1_L1_PARTS];           /* where it lies in each partition's lease area, OF_NONE when it doesn't fit */
    uint8_t kind;
} of_lease;
static of_lease lz[OF_LEASES];
static int n_lz;
static const uint32_t CAP[OP1_L1_PARTS] = { KN_L1_SYNTH_BYTES, KN_L1_FX_BYTES, KN_L1_MASTER_BYTES, KN_L1_DRUM_BYTES };

of_ctx *of_now[2];                                              /* opus.h */
static of_ctx thr;                                              /* a thread's call (all threads share it) */
typedef struct { ob_file *f; uint32_t lease_at; int part; uint8_t *home; uint32_t vbytes; } of_hold;   /* what a
                                                                 * partition's holder put where (for of_gone) */
static of_hold hold[OP1_L1_PARTS];

#ifdef OB_HOST_FS
uint32_t of_stat[2];                                            /* tests: claims granted, claims refused */
#define OF_STAT(i) (of_stat[i]++)
#else
#define OF_STAT(i) ((void)0)
#endif
int of_count(void) { return n_lz; }
void of_rollback(int n) { if (n >= 0 && n < n_lz) n_lz = n; }

/* opus_fast_lease: from opl_init; bytes, slow (4-byte aligned, the file's own copy) and kind checked; 0 refuses */
static of_lease *s_lease(opl_self *self, unsigned bytes, int kind, void *slow)
{
    ob_file *f = (ob_file *)self;
    if (!f || f != ob_cur || !bytes || !slow || ((uint32_t)slow & 3u) || kind < OF_SCRATCH || kind > OF_STATE ||
        bytes > KN_L1_FX_BYTES || n_lz >= OF_LEASES)
        return 0;
    of_lease *l = &lz[n_lz];
    l->f = f; l->slow = slow; l->bytes = bytes; l->kind = (uint8_t)kind;
    for (int p = 0; p < OP1_L1_PARTS; p++) l->place[p] = OF_NONE;
    for (int p = 0; p < OP1_L1_PARTS; p++) f->laid[p] = 0;
    f->lease_total += OF_AL(bytes);
    n_lz++;
    char m[40], *e = ob_cat(m, "fast lease ");
    e = ob_num(e, bytes);
    ob_cat(ob_cat(e, " kind "), kind == OF_STATE ? "state" : kind == OF_CONST ? "const" : "scratch");
    kn_log_line(f->self.id, m);
    return l;
}
/* opus_fast_use: the lease's L1 copy while this context's claim holds it and it fits, else its own copy. The callback
 * reads its record only while it runs (kn_l1_live.cb: nothing else runs then); a thread its own, set for its call. */
static void *s_use(of_lease *l)
{
    if (!l) return 0;
    const of_ctx *c = of_now[1];
    if (kn_l1_live.cb) {                                        /* the callback's: only its claimant's, claimed this block
                                                                 * (a call into the file outside of_enter gets slow) */
        const of_slot *s = (const of_slot *)of_now[0];          /* (the context is the slot's first member) */
        c = s && s->tick == kn_l1_live.tick + 1u ? &s->c : 0;
    }
    if (c && c->f == l->f) return c->base && l->place[c->part] != OF_NONE ? c->base + l->place[c->part] : l->slow;
    return l->slow;
}
void *ob_fast_use(void *l) { return s_use((of_lease *)l); }      /* accelerators (accel/oa_dx.c): the file's own call */
static void *s_fast(opl_self *self, unsigned bytes) { (void)self; (void)bytes; return 0; }   /* "none left" */

static void copy(uint8_t *d, const uint8_t *s, uint32_t n)
{
    uint32_t i = 0;
    if (!(((uint32_t)d | (uint32_t)s) & 3u)) for (; i + 4 <= n; i += 4) *(uint32_t *)(d + i) = *(const uint32_t *)(s + i);
    for (; i < n; i++) d[i] = s[i];
}
/* OQ_VPTR (castle): words in the file that hold a pointer to one of its voices' state, rebased from one copy of the six
 * voices to the other (a pointer elsewhere, or 0, stays) */
static void rebase(ob_file *f, const uint8_t *from, const uint8_t *to, uint32_t bytes)
{
    for (int i = 0; i < 2; i++) {
        uint32_t *w = f->vptr[i];
        if (w && *w >= (uint32_t)from && *w < (uint32_t)from + bytes) *w = (uint32_t)to + (*w - (uint32_t)from);
    }
}
/* the partition goes (kennel, audio thread): the holder's STATE leases back to their own copies */
static void of_gone(void *ctx, void *at)
{
    const of_hold *h = ctx;
    if (h->f && h->home && (h->f->vptr[0] || h->f->vptr[1])) rebase(h->f, at, h->home, h->vbytes);
    for (int i = 0; i < n_lz; i++) {
        const of_lease *l = &lz[i];
        if (l->f == h->f && l->kind == OF_STATE && l->place[h->part] != OF_NONE)
            copy(l->slow, (const uint8_t *)at + h->lease_at + l->place[h->part], l->bytes);
    }
}

/* the file's leases laid out first fit after `at` bytes, in the order taken (a lease too big is passed over); apply:
 * their places recorded. -> the bytes they use */
static uint32_t lay(ob_file *f, int part, uint32_t at, int apply)
{
    uint32_t pos = 0;
    for (int i = 0; i < n_lz; i++) {
        of_lease *l = &lz[i];
        if (l->f != f) continue;
        const int fits = at + pos + OF_AL(l->bytes) <= CAP[part];
        if (apply) l->place[part] = fits ? (uint16_t)pos : OF_NONE;
        if (fits) pos += OF_AL(l->bytes);
    }
    return pos;
}
/* first call with this front in this partition: the leases laid out. The front gives way when the leases alone would
 * use more of the partition (dx: its 8 KB sine table over its voices; measured 2026-11-17: the table in L1 beats the
 * voices there by 20..30 %); else the front, then what fits. */
static void __attribute__((noinline)) lay_out(ob_file *f, int part, uint32_t front)
{
    const uint32_t with = lay(f, part, OF_AL(front), 0), without = lay(f, part, 0, 0);
    f->front_off[part] = (uint8_t)(front && without > OF_AL(front) + with);
    f->lease_used[part] = lay(f, part, f->front_off[part] ? 0 : OF_AL(front), 1);
    f->laid[part] = OF_AL(front) + 1;
}
/* a fresh claim: where the holder's bytes are (for of_gone), its CONST / STATE leases copied in, its voice pointers
 * moved with its voices */
static void __attribute__((noinline)) took(ob_file *f, int part, uint8_t *p, uint32_t at, void *home, uint32_t state)
{
    of_hold *h = &hold[part];
    h->f = f; h->lease_at = at; h->part = part; h->home = state ? home : 0; h->vbytes = state;
    for (int i = 0; i < n_lz; i++) {
        const of_lease *l = &lz[i];
        if (l->f == f && l->kind != OF_SCRATCH && l->place[part] != OF_NONE) copy(p + at + l->place[part], l->slow, l->bytes);
    }
    if (state && (f->vptr[0] || f->vptr[1])) rebase(f, home, p, state);
}
static uint8_t *__attribute__((noinline)) enter_slow(of_slot *s, ob_file *f, int part, void *home, uint32_t front,
                                                     uint32_t state, uint32_t *t, uint32_t cb)
{
    of_ctx *c = cb ? &s->c : &thr;
    *t = cb ? 0 : kn_l1_thread_enter();
    c->f = f; c->base = 0; c->part = part;
    of_now[cb ? 0 : 1] = c;
    uint8_t *ret = 0;
    uint32_t key = 0;
    if ((unsigned)part < OP1_L1_PARTS && front <= CAP[part] && (front || f->lease_total)) {
        const uint32_t f0 = front;
        if (f->laid[part] != OF_AL(front) + 1) lay_out(f, part, front);
        if (f->front_off[part]) front = state = 0;
        const uint32_t at = OF_AL(front), want = at + f->lease_used[part];
        int fresh = 0;
        uint8_t *p = want ? kn_l1_claim_ex(part, s, state ? home : 0, state, want, &fresh, of_gone, &hold[part]) : 0;
        if (p) {
            OF_STAT(0);
            if (fresh) took(f, part, p, at, home, state);
            c->base = p + at;
            if (front) ret = p;
            key = f0 + 1u;
        } else if (want) OF_STAT(1);
    }
    if (cb) { s->ret = ret; s->key = key; s->tick = kn_l1_live.tick + 1u; }
    return ret ? ret : (uint8_t *)home;
}
/* Claim part for file f around one call: front bytes for the adapter at the start ([0, state) kept, home its own copy),
 * the file's leases after them; the slot is the claim's owner. In the callback the first call of a block claims (a
 * holder that claimed the same last block only renews: kn_l1_renew) and the later ones reuse it (kn_l1 keeps a holder
 * that claims every block). -> where the front lies now (L1, or home), and *t the kn_l1_thread_enter token for
 * of_leave (0 in the callback). */
uint8_t *of_enter(of_slot *s, ob_file *f, int part, void *home, uint32_t front, uint32_t state, uint32_t *t)
{
    if (!kn_l1_live.cb) return enter_slow(s, f, part, home, front, state, t, 0);
    kn_l1_live_t *L = &kn_l1_live;
    if (s->tick != L->tick + 1u) {                              /* the first call this block: kn_l1_renew, inline */
        if (s->key != front + 1u || s->c.part != part || !L->ok || !L->on || L->holder[part] != s)
            return enter_slow(s, f, part, home, front, state, t, 1);
        L->last[part] = L->tick;
        OF_STAT(0);
        s->tick = L->tick + 1u;
    }
    *t = 0;
    if (of_now[0] != &s->c) of_now[0] = &s->c;
    return s->ret ? s->ret : (uint8_t *)home;
}
void of_leave_thread(uint32_t t)
{
    of_now[1] = 0;
    thr.f = 0; thr.base = 0;
    kn_l1_thread_leave(t);
}

const ob_sym of_imports[] = {
    { "opus_fast", (uint32_t)s_fast },
    { "opus_fast_lease", (uint32_t)s_lease },
    { "opus_fast_use", (uint32_t)s_use },
};
const int of_n_imports = (int)(sizeof of_imports / sizeof of_imports[0]);
