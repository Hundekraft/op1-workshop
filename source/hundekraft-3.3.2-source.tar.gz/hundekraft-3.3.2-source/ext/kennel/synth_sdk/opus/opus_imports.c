/*
 * The names an .opmod file may import (Opus bridge, opus.h), and the services this core gives them (phase 2: the
 * basics and effects; D7: a file needing a name that is not here is refused with "needs <name>").
 *
 * fw_*: R246 functions by name, called directly. The addresses are the Opus kit's GPL sdk/op1fw.h, each checked against
 * our Ghidra project (an R246 function entry) and the other core's own table: the 64 names the 2026-11-11 study found
 * imported (OP1-Emulator run/opmod-compat-2026-11-11/out/fw_table.json; generator run/opus-bridge/tools/gen_fw.py).
 * Left out until kennel routes it (plan "fw_* routing"): fw_ui_dispatch (kennel's input path); a file importing it is
 * refused. fw_vc_note_on / fw_vc_note_off are opus_seq.c's (VoiceCtl key_down / key_up through kennel's note path).
 *
 * opus_*: shims over kennel services. The page primitives are opus_engine.c's (oe_imports), the art, page art,
 * keep / put and page_now opus_art.c's (oa_imports, phase 9); both tables are searched before this one.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../kennel/kn_setpage.h"
#include "../op1_synth.h"                                  /* SMC_* (the resource monitor's audio split) */

void *kn_alloc(uint32_t size);
void kn_log_line(const char *file, const char *msg);

/* ---- self, log, settings ---- */
static void s_log(opl_self *self, const char *text) { kn_log_line(self && self->id ? self->id : "opus", text ? text : ""); }
static int s_setting(opl_self *self, const char *name)
{
    ob_file *f = (ob_file *)self;
    if (!f || !name) return 0;
    for (int i = 0; i < f->n_set; i++)
        if (ob_eq(f->set[i].key, name)) {
            int32_t v;
            if (!kn_setcache_get(f->feat, name, &v)) v = kn_setting_db_get(f->feat, name, f->set[i].def);
            return (int)v;
        }
    return 0;
}
/* the plugin's own change of a setting (amp's controls): a name its manifest offers, kept inside its choices, written
 * at once (kennel's settings store; the kit writes it after 2 s quiet) and shown by the settings page; its handler is
 * not told. 1, or 0 for a name the manifest does not offer. Not from the audio thread (a store write). */
void op1_setting_set(const char *feature, const char *key, int32_t value);
static int s_set_setting(opl_self *self, const char *name, int value)
{
    ob_file *f = (ob_file *)self;
    if (!f || !name) return 0;
    for (int i = 0; i < f->n_set; i++)
        if (ob_eq(f->set[i].key, name)) {
            const int c = f->set[i].choices;
            if (c && value >= c) value = c - 1;
            if (value < 0) value = 0;
            op1_setting_set(f->feat, name, value);
            return 1;
        }
    return 0;
}
static void s_on_setting(opl_self *self, void (*fn)(const char *, int))
{
    ob_file *f = (ob_file *)self;
    if (f && (!fn || ob_inside(f, (const void *)fn))) f->on_setting = fn;   /* told by the settings page (opus_boot.c notify, kn_sl_notify) */
}

/* each OS main-loop pass (kennel's engine service, OP1_EV_SERVICE): only a file that adds an engine is called (the
 * service runs per engine type, the file's first); a library's or an effect's is kept but never called yet */
static void s_on_main_pass(opl_self *self, void (*fn)(void))
{
    ob_file *f = (ob_file *)self;
    if (f && f == ob_cur && (!fn || ob_inside(f, (const void *)fn))) f->main_pass = fn;
}
/* A folder (kit struct opus_folder: name, ext, max, take, changed): registered and made (/yaffs2/mod/NAME), so a plugin
 * that scans its own folder at opl_init (dx's banks) finds its files there. The disk exchange (copy out at disk mode's
 * start, take/changed at its end) is not built: R246 deletes the disk's non-tape files on leaving disk mode (kennel
 * ARCHITECTURE "dx banks"), so take and changed are never called; files come by the workshop push or are already
 * there. 1, or 0 for a bad struct or name, a name another file has, or more than six folders. */
#define OF_MAX 6
#ifdef OB_HOST_FS
int ob_mkdir(const char *, int);                                /* tier 2: the test's file system */
#define OF_MKDIR ob_mkdir
#else
#define OF_MKDIR ((int (*)(const char *, int))0x01A9A886u)      /* yaffs_mkdir (kn_boot.c Y_MKDIR) */
#endif
static char of_names[OF_MAX][9];
static int of_n;
static int s_on_folder(opl_self *self, const void *folder)
{
    ob_file *f = (ob_file *)self;
    const uint32_t *fd = folder;                                /* name, ext, max, take, changed */
    if (!f || f != ob_cur || !fd || !ob_inside(f, fd) || of_n >= OF_MAX) return 0;
    const char *nm = (const char *)fd[0];
    if (!nm || !ob_inside(f, nm) || (fd[1] && !ob_inside(f, (const void *)fd[1])) ||
        !ob_inside(f, (const void *)fd[3]) || !ob_inside(f, (const void *)fd[4])) return 0;
    int n = 0;
    for (; n < 9 && nm[n]; n++) {
        const char c = nm[n];
        if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-')) return 0;
    }
    if (n < 1 || n > 8) return 0;
    for (int i = 0; i < of_n; i++) if (ob_eq(of_names[i], nm)) return 0;
    for (int i = 0; i <= n; i++) of_names[of_n][i] = nm[i];
    of_n++;
    char path[24], *p = ob_cat(path, "/yaffs2/mod");
    OF_MKDIR(path, 0x1FF);                                      /* exists already: fine */
    p = ob_cat(ob_cat(p, "/"), nm);
    (void)p;
    const int r = OF_MKDIR(path, 0x1FF);
    kn_log_line(f->self.id, r == 0 ? "folder made" : "folder there (or not made)");   /* yaffs_mkdir: 0 made */
    return 1;
}

/* frames late of the last 8 (0-8): kennel's drawn frames that came more than ~52 ms after the one before (the Opus
 * core's 0x1413CD8 cycles; kennel/kn_gfx.c op1_frames_late: the pace or the governor slowed the drawing) */
int op1_frames_late(void) __attribute__((weak));
static int s_frames_late(void) { return op1_frames_late ? op1_frames_late() : 0; }

/* ---- memory: from opl_init (the boot stage's arena; cleared, 32-byte aligned) ---- */
static void *s_alloc(opl_self *self, unsigned bytes)
{
    (void)self;
    if (!ob_cur || !bytes) return 0;
    uint8_t *p = kn_alloc(bytes + 32);                          /* kn_alloc aligns to 4: round up to 32 */
    return p ? (void *)(((uint32_t)p + 31) & ~31u) : 0;
}
/* audio work a plugin reports itself (the Opus core charges it to the plugin's figure): into the resource monitor's
 * audio split (op1_synth.h sm_cy, screens/sysmon.c), where kennel's own plugins' calls are counted: a file with an
 * engine under synth, a drum engine under drum, any other (effects, LFO types) under FX. The bridge's calls into a
 * file are counted there already (the core times them); this is only what the file adds. */
extern volatile uint32_t sm_cy[] __attribute__((weak));
int oe_file_has(const ob_file *f);          /* opus_engine.c */
int od_file_has(const ob_file *f);          /* opus_drum.c */
static void s_cpu_charge(opl_self *self, unsigned cycles)
{
    if (!self || !sm_cy) return;
    const ob_file *f = (const ob_file *)self;   /* a plugin's self pointer is its record (opus.h) */
    sm_cy[oe_file_has(f) ? SMC_SYNTH : od_file_has(f) ? SMC_DRUM : SMC_FX] += cycles;
}

/* ---- colours: the stock encoder colours (kennel has no themes) ---- */
static unsigned s_accent_now(int i)
{
    static const unsigned stock[4] = { 0x6B8EFFu, 0x00EF94u, 0xFFFFFFu, 0xFF4139u };
    return stock[i & 3];
}
static void s_sincos(int turn, int *s, int *c)                  /* x 4096; a turn is 4096 */
{
    /* a quarter-wave table would cost 2 KB; the page names that use it are never drawn here: a coarse integer rotation */
    static const int16_t q[17] = { 0, 401, 799, 1189, 1567, 1931, 2276, 2598, 2896, 3166, 3406, 3612, 3784, 3920, 4017,
                                   4076, 4096 };
    int a = turn & 4095, quad = a >> 10, r = a & 1023, i = r >> 6, fr = r & 63;
    int sv = q[i] + (((q[i + 1] - q[i]) * fr) >> 6), cv = q[16 - i] + (((q[15 - i < 0 ? 0 : 15 - i] - q[16 - i]) * fr) >> 6);
    int so = quad == 0 ? sv : quad == 1 ? cv : quad == 2 ? -sv : -cv;
    int co = quad == 0 ? cv : quad == 1 ? -sv : quad == 2 ? -cv : sv;
    if (s) *s = so;
    if (c) *c = co;
}
void oa_sincos(int turn, int *s, int *c) { s_sincos(turn, s, c); }   /* opus_art.c (opus_art_turn) */

/* ---- the table: fw_* (generated) then opus_*, sorted by name (byte order) ---- */
static const ob_sym table[] = {
    { "fw_bend_down", 0x01A86074u },
    { "fw_bend_release_left", 0x01A85F98u },
    { "fw_bend_release_right", 0x01A86004u },
    { "fw_bend_stop", 0x01A85F58u },
    { "fw_bend_up", 0x01A86098u },
    { "fw_bg_save", 0x019410C8u },
    { "fw_bind", 0x01A3B5D0u },
    { "fw_clips_add", 0x0195CCECu },
    { "fw_clips_remove", 0x0195D5F8u },
    { "fw_db_exec", 0x0196F950u },
    { "fw_drum_slot_is_kit", 0x01995868u },
    { "fw_drum_slot_preset", 0x01A01DC8u },
    { "fw_json_assign", 0x019BDDC0u },
    { "fw_json_free", 0x019BDD18u },
    { "fw_json_get", 0x019BEB70u },
    { "fw_json_index", 0x019BFEB4u },
    { "fw_json_text", 0x019BDC4Cu },
    { "fw_loop_end", 0x01A53D88u },
    { "fw_loop_start", 0x01A53DA0u },
    { "fw_make_midinote", 0x01A85014u },
    { "fw_node_set_matrix", 0x019EAD58u },
    { "fw_note_down", 0x019AC0B0u },
    { "fw_note_up", 0x019AC2F8u },
    { "fw_read_iface", 0x01A28DA0u },
    { "fw_save_arm", 0x0193EF3Cu },
    { "fw_save_overlay_count", 0x01A3AAA0u },
    { "fw_save_overlay_full", 0x01A3AA68u },
    { "fw_save_overlay_off", 0x01A3AA58u },
    { "fw_save_overlay_ok", 0x01A3AA84u },
    { "fw_screen_draw", 0x01A3B4C8u },
    { "fw_screen_raster", 0x01A3B490u },
    { "fw_set_loop_end", 0x01A55100u },
    { "fw_set_loop_start", 0x01A550A8u },
    { "fw_set_text", 0x01A61AACu },
    { "fw_shift_held", 0x019D7C6Cu },
    { "fw_snprintf", 0x01A9CE04u },
    { "fw_svg_node_find", 0x019EB8ACu },
    { "fw_synth_adsr_json", 0x01A00C98u },
    { "fw_synth_knob_turn", 0x01A1DFECu },
    { "fw_synth_knobs_json", 0x01A00D14u },
    { "fw_synth_slot_preset", 0x01A02030u },
    { "fw_tape_db", 0x0196DD50u },
    { "fw_tape_invalidate", 0x01A540C0u },
    { "fw_tape_loop_changed", 0x01A59B10u },
    { "fw_tape_set_pos", 0x01A55024u },
    { "fw_text_draw", 0x01A6259Cu },
    { "fw_text_new", 0x01A61904u },
    { "fw_yaffs_access", 0x01A9A6B0u },
    { "fw_yaffs_close", 0x01A99908u },
    { "fw_yaffs_closedir", 0x01A9B74Cu },
    { "fw_yaffs_lseek", 0x01A9A0E4u },
    { "fw_yaffs_mkdir", 0x01A9A886u },
    { "fw_yaffs_open", 0x01A997F4u },
    { "fw_yaffs_opendir", 0x01A9B450u },
    { "fw_yaffs_pread", 0x01A99CA8u },
    { "fw_yaffs_pwrite", 0x01A99F9Cu },
    { "fw_yaffs_read", 0x01A99C90u },
    { "fw_yaffs_readdir", 0x01A9B648u },
    { "fw_yaffs_stat", 0x01A9A688u },
    { "fw_yaffs_unlink", 0x01A9A3FCu },
    { "fw_yaffs_write", 0x01A99F84u },
    { "opus_accent_now", (uint32_t)s_accent_now },
    { "opus_alloc", (uint32_t)s_alloc },
    { "opus_alloc_audio", (uint32_t)s_alloc },
    { "opus_cpu_charge", (uint32_t)s_cpu_charge },
    { "opus_effect_register", (uint32_t)opus_effect_register },
    { "opus_frames_late", (uint32_t)s_frames_late },
    { "opus_log", (uint32_t)s_log },
    { "opus_on_folder", (uint32_t)s_on_folder },
    { "opus_on_main_pass", (uint32_t)s_on_main_pass },
    { "opus_on_setting", (uint32_t)s_on_setting },
    { "opus_set_setting", (uint32_t)s_set_setting },
    { "opus_setting", (uint32_t)s_setting },
    { "opus_sincos", (uint32_t)s_sincos },
};
#define N_TABLE ((int)(sizeof table / sizeof table[0]))

uint32_t ob_import(const char *name)                            /* binary search: the table is sorted */
{
    for (int i = 0; i < oa_n_imports; i++) if (ob_eq(oa_imports[i].name, name)) return oa_imports[i].addr;
    for (int i = 0; i < oe_n_imports; i++) if (ob_eq(oe_imports[i].name, name)) return oe_imports[i].addr;
    for (int i = 0; i < od_n_imports; i++) if (ob_eq(od_imports[i].name, name)) return od_imports[i].addr;
    for (int i = 0; i < ol_n_imports; i++) if (ob_eq(ol_imports[i].name, name)) return ol_imports[i].addr;
    for (int i = 0; i < os_n_imports; i++) if (ob_eq(os_imports[i].name, name)) return os_imports[i].addr;
    for (int i = 0; i < of_n_imports; i++) if (ob_eq(of_imports[i].name, name)) return of_imports[i].addr;
    for (int i = 0; i < oi_n_imports; i++) if (ob_eq(oi_imports[i].name, name)) return oi_imports[i].addr;
    int lo = 0, hi = N_TABLE - 1;
    while (lo <= hi) {
        int m = (lo + hi) >> 1, c = ob_cmp(name, table[m].name);
        if (!c) return table[m].addr;
        if (c < 0) hi = m - 1; else lo = m + 1;
    }
    return 0;
}
int ob_table_sorted(void)                                        /* tests */
{
    for (int i = 1; i < N_TABLE; i++) if (ob_cmp(table[i - 1].name, table[i].name) >= 0) return 0;
    return N_TABLE;
}

/* ---- libraries: a loaded file's exports, for the files loaded after it (orbit3d's o3_* for chorus and plate) ---- */
#define LIBS 4
static struct { const char *id, *version; int n; ob_sym *exp; } libs[LIBS];
static int n_libs;
static const char *keep(const char *s, uint32_t n)
{
    char *d = kn_alloc(n + 1);
    if (d) { for (uint32_t i = 0; i < n; i++) d[i] = s[i]; d[n] = 0; }
    return d;
}
int ob_lib_add(const char *id, const char *version, const ol_file *f, uint32_t base)
{
    if (n_libs >= LIBS || !f->exp_n) return -1;
    ob_sym *e = kn_alloc(f->exp_n * sizeof *e);
    if (!e) return -1;
    for (uint32_t i = 0; i < f->exp_n; i++) {
        uint32_t off;
        const char *nm = ol_export(f, i, &off);
        e[i].name = keep(nm, (uint32_t)ob_len(nm));
        e[i].addr = base + off;
        if (!e[i].name) return -1;
    }
    libs[n_libs].id = keep(id, (uint32_t)ob_len(id)); libs[n_libs].version = keep(version, (uint32_t)ob_len(version));
    libs[n_libs].n = (int)f->exp_n; libs[n_libs].exp = e;
    n_libs++;
    return 0;
}
uint32_t ob_lib_import(const char *name)
{
    for (int l = 0; l < n_libs; l++)
        for (int i = 0; i < libs[l].n; i++) if (ob_eq(libs[l].exp[i].name, name)) return libs[l].exp[i].addr;
    return 0;
}
int ob_lib_has(const char *id, const char *min_version)
{
    for (int l = 0; l < n_libs; l++)
        if (ob_eq(libs[l].id, id))
            return ob_vercmp(libs[l].version, (uint32_t)ob_len(libs[l].version), min_version, (uint32_t)ob_len(min_version)) >= 0;
    return 0;
}
