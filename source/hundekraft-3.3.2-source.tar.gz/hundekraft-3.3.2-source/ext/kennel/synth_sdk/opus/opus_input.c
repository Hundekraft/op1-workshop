/*
 * Input and line-input services for .opmod files (Opus bridge, opus.h): opus_on_key, opus_on_key_after,
 * opus_on_knob_after (core 2.0 / 2026-10-21) and opus_on_line_input (core 2.58), over kennel's neutral seams in
 * kennel/kn_foreign.h: kn_foreign_input (kn_features_input, KeyHandler), kn_foreign_input_after (dispatcher.c,
 * after the event's whole handling) and kn_foreign_line_in (screens/sysmon_core.c, the audio callback's start).
 *
 * Order (the other core's rules, kit api.md "Keys and encoders"): every key event that reaches kennel's features'
 * input filter goes to each file's key handler in load order, before the engine's own page, the features and R246;
 * 1 takes it (no later handler, nothing after it sees it). FN (the help key, code 0x00) comes too; unlike the other
 * core, R246 still gets it when no handler takes it (its help overlay). An after handler hears every event the before
 * handlers saw, taken or not (a before and an after pair: an event a kennel page took earlier reaches neither), turns
 * with the delta R246 got. opus_on_knob (a handler that may change or take a turn) is not here: a file importing it
 * is refused ("needs opus_on_knob").
 *
 * Line input: fn(stereo, 64) with R246's RX buffer (64 frames x 2 int32, left then right, the sample in the top 24
 * bits) before R246's audio graph sums the two sides into its one input, only while the input source is the line
 * input (0xFF8010B4 == 1). What fn leaves there is what R246 takes. One handler a file (a second call replaces it).
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "opus.h"
#include "../op1_feature.h"                                     /* OP1_IN_KEY, OP1_IN_KNOB */
#include "../kennel/kn_foreign.h"
#include "../kn_mem.h"                                         /* kn_audio_text */

#define OI_MAX 8                                                /* handlers of each kind, all files */
typedef struct { ob_file *f; void *fn; } oi_rec;
static oi_rec on_key[OI_MAX], key_after[OI_MAX], knob_after[OI_MAX], line_in[OI_MAX];
static volatile int n_key, n_key_after, n_knob_after, n_line;
static uint8_t seen;                                            /* this event reached the before handlers */

static void add(oi_rec *t, volatile int *n, opl_self *self, void *fn, int one)
{
    ob_file *f = (ob_file *)self;
    if (!f || f != ob_cur || !fn || !ob_inside(f, fn)) return;  /* from opl_init only, code inside its image */
    if (one)
        for (int i = 0; i < *n; i++) if (t[i].f == f) { t[i].fn = fn; return; }
    if (*n >= OI_MAX) return;
    t[*n].f = f; t[*n].fn = fn;
    *n = *n + 1;                                                /* the record first, then the count (other threads) */
}
static void s_on_key(opl_self *s, int (*fn)(int, int)) { add(on_key, &n_key, s, (void *)fn, 0); }
static void s_on_key_after(opl_self *s, void (*fn)(int, int)) { add(key_after, &n_key_after, s, (void *)fn, 0); }
static void s_on_knob_after(opl_self *s, void (*fn)(int, short)) { add(knob_after, &n_knob_after, s, (void *)fn, 0); }
static void s_on_line_input(opl_self *s, void (*fn)(int *, unsigned)) { add(line_in, &n_line, s, (void *)fn, 1); }

int oi_count(void) { return n_key | n_key_after << 8 | n_knob_after << 16 | n_line << 24; }
void oi_rollback(int c)                                         /* back to oi_count()'s value (a refused file's) */
{
    if ((c & 0xFF) < n_key) n_key = c & 0xFF;
    if ((c >> 8 & 0xFF) < n_key_after) n_key_after = c >> 8 & 0xFF;
    if ((c >> 16 & 0xFF) < n_knob_after) n_knob_after = c >> 16 & 0xFF;
    if ((c >> 24 & 0xFF) < n_line) n_line = c >> 24 & 0xFF;
}

/* kn_features_input (KeyHandler): 1 takes the event */
int kn_foreign_input(int type, int code, int pressed, int delta)
{
    (void)delta;
    seen = 1;
    if (type != OP1_IN_KEY) return 0;
    for (int i = 0; i < n_key; i++)
        if (((int (*)(int, int))on_key[i].fn)(code, pressed ? 1 : 0)) return 1;
    return 0;
}
/* dispatcher.c, after the event's handling (KeyHandler): the after handlers of an event the before handlers saw */
void kn_foreign_input_after(int type, int code, int pressed, int delta)
{
    if (!seen) return;
    seen = 0;
    if (type == OP1_IN_KEY)
        for (int i = 0; i < n_key_after; i++) ((void (*)(int, int))key_after[i].fn)(code, pressed ? 1 : 0);
    else if (type == OP1_IN_KNOB)
        for (int i = 0; i < n_knob_after; i++) ((void (*)(int, short))knob_after[i].fn)(code, (short)delta);
}
/* the audio callback's start, while the input source is the line input: R246's RX block (64 frames, L then R) */
kn_audio_text void kn_foreign_line_in(int32_t *rx)
{
    for (int i = 0; i < n_line; i++) ((void (*)(int *, unsigned))line_in[i].fn)((int *)rx, 64u);
}

const ob_sym oi_imports[] = {                                   /* searched by ob_import */
    { "opus_on_key", (uint32_t)s_on_key },
    { "opus_on_key_after", (uint32_t)s_on_key_after },
    { "opus_on_knob_after", (uint32_t)s_on_knob_after },
    { "opus_on_line_input", (uint32_t)s_on_line_input },
};
const int oi_n_imports = (int)(sizeof oi_imports / sizeof oi_imports[0]);
