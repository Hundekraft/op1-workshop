/*
 * Accelerators for known files (Opus bridge, opus_quirk.c rows with an accel id): kennel's own Blackfin kernels for the
 * DSP of a plugin whose sound kennel also had as a port, called through a pointer the bridge owns (the engine's render
 * callback). The file's bytes are never changed, in the file or in RAM: the bridge calls this code instead of the
 * file's render for that one exact file (id, version, sha256), and the code works on the file's own voice state and
 * globals at offsets checked in that file's image. Sources and credits:
 *  - sim: HIM's voice and sample loops (plugins/him: him_voice.c, him_kern.S), the original drum engine's synthesis,
 *    ported with the author's permission (per the owner, 2026-11-09); here with sim's voice layout, the constants in a
 *    cache of their own and the original's |xs| (oa_sim.c, oa_sim_kern.S).
 *  - dx: DX's voice (plugins/dx: dx.c dx_render, dx_msfa.c msfa_note_compute, dx_kern.c / dx_kasm.S), ported 1:1 from
 *    the original with the author's permission (per the owner, 2026-11-14); the FM follows Google's Music Synthesizer
 *    for Android (MSFA, Copyright 2012 Google Inc., Apache License 2.0; the dx port's NOTICE) (oa_dx.c, oa_dx_kern.S).
 * OA_KERN_C (or a host build) builds the C loops instead of the assembly (the tests' reference).
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE); the
 * MSFA-derived parts stay under the Apache License 2.0 as well.
 */
#ifndef OPUS_ACCEL_H
#define OPUS_ACCEL_H

#if defined(__bfin__) && !defined(OA_KERN_C)
#define OA_KERN_ASM 1
#endif

#define OA_NONE 0
#define OA_SIM  1                           /* opus.sim 0.1.9 */
#define OA_DX   2                           /* opus.dx 0.4.1 */

#ifndef __ASSEMBLER__
#include <stdint.h>

extern int ob_accel_on;                     /* 1 (default): matched files use their accelerator; tests set 0 before boot */

typedef void (*oa_render_fn)(void *voice, short *out, const short *par, const unsigned *pitch);
/* the accelerator for a file the quirk row names (accel id), bound to that file's image and zero fill; 0 when the
 * file's render is not where the row says (then the file's own render runs) */
oa_render_fn oa_bind(int accel, uint8_t *image, uint8_t *zero, const void *file_render);

/* sim (oa_sim.c): the voice (76 bytes, the file's struct sim_voice) */
typedef struct {
    uint32_t ph[7];                         /* 0x00 body phase, six metal phases */
    uint32_t seed;                          /* 0x1c xorshift32 */
    int32_t lp, bp;                         /* 0x20 filter */
    uint32_t env, nenv, swp;                /* 0x28 */
    int32_t hold_n, hold_v;                 /* 0x34 crunch */
    int32_t choke;                          /* 0x3c */
    int32_t index;                          /* 0x40 */
    uint32_t ratio;                         /* 0x44 last pitch ratio */
    int32_t logp;                           /* 0x48 its log2, Q12 */
} oa_simv;
/* a voice's constants (worked out when the key's numbers, the pitch or choke change); the assembly reads the first
 * nine at these offsets */
typedef struct {
    int32_t fc, cmix, G, colhi, g, dgs, douts, hold, mask;      /* 0 .. 32 */
    uint32_t f1, f2, f3;
    int32_t u, samt, msc, b, q, crunch;
    int16_t par[8];
    int32_t logp, choke, ok, inc_ok;
    uint32_t inc_swp, inc;
} oa_simc;
/* a block's values for the sample loops */
typedef struct {
    uint32_t r[6];                          /*  0 metal increments */
    int32_t m0, mi;                         /* 24 */
    int32_t nz0, ni;                        /* 32 */
    int32_t inc0, dinc;                     /* 40 */
    int32_t b0, bi;                         /* 48 */
    int32_t flag;                           /* 56 */
    const oa_simc *c;                       /* 60 the voice's constants */
} oa_simkp;
void oa_sim_noise(oa_simv *v, int16_t *out, const oa_simkp *kp);
void oa_sim_body(oa_simv *v, int16_t *out, const oa_simkp *kp);
void oa_sim_drive(oa_simv *v, int16_t *out, const oa_simkp *kp);
void oa_sim_voice(oa_simv *v, oa_simc *c, int16_t *out, const int16_t *par, int32_t logp);   /* voice_render_block */
void oa_sim_render(void *voice, short *out, const short *par, const unsigned *pitch);         /* render_cb */
uint32_t oa_sim_calls(void);                /* tests and the log: blocks rendered by the accelerator */

/* dx (oa_dx.c) */
void oa_dx_render(void *voice, short *out, const short *par, const unsigned *pitch);          /* engine_render */
uint32_t oa_dx_calls(void);
#endif

#endif
