/*
 * Accelerators (oa.h): which render a quirk row's accel id gives, bound to the matched file's image and zero fill.
 * The bridge calls it through its own pointer (od_type / oe_type render) instead of the file's render; the file is
 * not changed. A file whose render is not at the offset the row was checked for keeps its own.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "oa.h"

int ob_accel_on = 1;

void oa_sim_bind(uint8_t *zero);
int oa_dx_bind(uint8_t *image, uint8_t *zero);

#define SIM_RENDER 0x1044u                  /* opus.sim 0.1.9: render_cb */
#define DX_RENDER  0x0110u                  /* opus.dx 0.4.1: engine_render */

oa_render_fn oa_bind(int accel, uint8_t *image, uint8_t *zero, const void *file_render)
{
    if (!ob_accel_on || !image || !zero) return 0;
    if (accel == OA_SIM && file_render == image + SIM_RENDER) { oa_sim_bind(zero); return oa_sim_render; }
    if (accel == OA_DX && file_render == image + DX_RENDER && oa_dx_bind(image, zero)) return oa_dx_render;
    return 0;
}
