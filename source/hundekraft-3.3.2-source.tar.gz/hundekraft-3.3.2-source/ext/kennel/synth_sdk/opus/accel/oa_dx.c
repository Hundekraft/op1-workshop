/*
 * The dx accelerator (oa.h): opus.dx 0.4.1's engine_render on DX's voice code (plugins/dx: dx.c dx_render, dx_msfa.c
 * msfa_note_compute and fm_op_compute_scaled, dx_kern.c / dx_kasm.S; ported 1:1 from the original with the author's
 * permission per the owner, 2026-11-14). The FM follows Google's Music Synthesizer for Android (MSFA, Copyright 2012
 * Google Inc., Apache License 2.0; NOTICE). It runs on the file's own voice (0x184 bytes) and globals, and calls the
 * file's own cold functions (voice_get_patch, msfa_lfo_reset, msfa_note_init, msfa_note_keyup, msfa_log2_lookup,
 * note_is_silent, msfa_env_advance, sin_table_use) and reads its tables, all at the offsets checked in the 0.4.1 image
 * (OP1-Emulator ext/opus-src plugins/dx names.json and image.S): the hot part, the operators and the output, is
 * kennel's (oa_dx_kern.S on the Blackfin, the C below elsewhere).
 *
 * Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and
 * NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well.
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "oa.h"

#define VOICE_VELOCITY(i) (*(volatile const short *)(0xFF801064 + 2 * (i)))     /* R246's voice i velocity, 8.8 */

struct env { int level, target, inc; unsigned char ix, rising, down, pad; unsigned char rates[4], levels[4]; int outlevel, rate_scaling; };
struct fmop { int phase, freq, gain_in, gain_out; };
struct voice {
    struct env env[6];                     /* 0x000 */
    struct fmop op[6];                     /* 0x0c0 */
    int pe_level, pe_target, pe_inc;       /* 0x120 */
    unsigned char pe_ix, pe_rising, pe_down, pe_pad;
    unsigned char pe_rates[4], pe_levels[4];
    int basepitch[6];                      /* 0x138 */
    int fb[2];                             /* 0x150 */
    unsigned char fixmode[6], ampmodsens[6];
    unsigned char algorithm, fb_shift, pitchmodsens, opmask;   /* 0x164 */
    int pitchmoddepth, ampmoddepth;        /* 0x168 */
    int last_out, amp_level, amp_gain;     /* 0x170 */
    short hold;                            /* 0x17c */
    unsigned char stage;
    volatile unsigned char first, releasing;
    unsigned char index;                   /* 0x181 */
};
_Static_assert(sizeof(struct voice) == 0x184, "dx's voice");
_Static_assert(__builtin_offsetof(struct voice, index) == 0x181, "dx's voice index");
struct fm_args { int *out; const int *in; int phase, freq, gain, dgain, shift; const short *sin; };
struct fm_fb_op { int phase, freq, gain, dgain, shift; };
struct fm_fb_args { int *out; int n, shift, pad, fb0, fb1; const short *sin; struct fm_fb_op op[3]; };
struct fm_fb1_args { int *out; int *fb; int phase, freq, gain, dgain, shift; const short *sin; int fs; };
struct sound { unsigned char kind, flags; char name[16]; unsigned char amp[8]; unsigned char patch[156]; };
_Static_assert(__builtin_offsetof(struct sound, amp) == 0x12 && __builtin_offsetof(struct sound, patch) == 0x1a, "dx's sound");

void oa_dx_op(const struct fm_args *a, int flags);
void oa_dx_fb(struct fm_fb_args *a);
void oa_dx_fb1(struct fm_fb1_args *a, int add);
int oa_dx_out(short *out, const int *in, int old, int step, int prev);
void *ob_fast_use(void *l);

/* the file: image offsets, then zero-fill offsets (0.4.1) */
#define I_GET_PATCH   0x007Cu
#define I_ENV_ADV     0x1620u
#define I_SIN_USE     0x1694u
#define I_LOG2        0x1718u
#define I_NOTE_INIT   0x17C0u
#define I_SILENT      0x1BA4u
#define I_KEYUP       0x1BD8u
#define I_LFO_RESET   0x22CCu
#define I_AMP_ENV     0x50C4u               /* default_amp_env[8] */
#define I_HOLD_TIME   0x5194u               /* amp_hold_time_table[100], u16 */
#define I_DECAY       0x525Cu               /* amp_decay_rate[100] */
#define I_ATTACK      0x53ECu               /* amp_attack_rate[100] */
#define I_AMS         0x5ABCu               /* ampmod_sens_table[4] */
#define I_ALGO        0x5ACCu               /* algorithm_flags[32][6] */
#define I_PE_LEVEL    0x5BC4u               /* pitchenv_level_table[100], s8 */
#define I_PE_RATE     0x5C28u               /* pitchenv_rate_table[100] */
#define I_EXP2        0x6320u               /* exp2_table[257] */
#define I_LV_INDEX    0x93DCu               /* loaded_voice_index */
#define I_LV_BANK     0x93E0u
#define I_LFO_SAMPLE  0x93E4u
#define I_LAST_NOTE   0x93E8u               /* last_note_index */
#define I_SIN_PTR     0x93ECu
#define Z_SOUND       0x00Cu
#define Z_LAST_VOICE  0x0C4u
#define Z_PATCH       0x184u                /* current_patch[156] */
#define Z_LFO_DELAY   0x220u
#define Z_LFO         0x224u
#define Z_FM_LEASE    0x23Cu
#define Z_SIN_LEASE   0x240u
#define Z_FM_SCRATCH  0x244u
#define Z_FM_BUFFER   0x248u

static struct {
    uint8_t *i, *z;
    void (*get_patch)(int, int, unsigned char *);
    void (*env_adv)(struct env *, int);
    void (*sin_use)(const short *);
    int (*log2)(int);
    void (*note_init)(struct voice *, const unsigned char *, int, int);
    int (*silent)(const struct voice *);
    void (*keyup)(struct voice *);
    void (*lfo_reset)(void *, const unsigned char *);
    const int *exp2;
} F;
static uint32_t calls;
uint32_t oa_dx_calls(void) { return calls; }
uint8_t *oa_dx_zero(void) { return F.z; }                  /* tests: the bound file's zero fill */

#define IW(o) (*(int *)(F.i + (o)))
#define ZW(o) (*(int *)(F.z + (o)))
#define ZP(o) (*(void **)(F.z + (o)))

int oa_dx_bind(uint8_t *image, uint8_t *zero)
{
    F.i = image; F.z = zero;
    F.get_patch = (void *)(image + I_GET_PATCH); F.env_adv = (void *)(image + I_ENV_ADV); F.sin_use = (void *)(image + I_SIN_USE);
    F.log2 = (void *)(image + I_LOG2); F.note_init = (void *)(image + I_NOTE_INIT); F.silent = (void *)(image + I_SILENT);
    F.keyup = (void *)(image + I_KEYUP); F.lfo_reset = (void *)(image + I_LFO_RESET); F.exp2 = (const int *)(image + I_EXP2);
    return 1;
}

static int exp2_lookup(int x)               /* msfa_exp2_lookup over the file's table */
{
    const int n = (x >> 24) - 6;
    if (n <= 0) {
        if (n >= -30) {
            const unsigned *p = (const unsigned *)((const char *)F.exp2 + ((unsigned char)(x >> 16) << 2));
            const unsigned d = (p[1] - p[0]) >> 7, r = ((d * (x & 0xffff)) >> 9) + p[0];
            return r >> -n;
        }
        return 0;
    }
    return 0x7fffffff;
}
static int freq_lookup(int x)               /* msfa_freq_lookup */
{
    const unsigned u = x + 0x10924e69;
    const int e = (int)u >> 24;
    if (u > 0x3dffffff) return 0;
    const int idx = (u >> 16) & 0xff;
    const unsigned y0 = F.exp2[idx], y1 = F.exp2[idx + 1], r = ((((y1 - y0) >> 7) * (u & 0xffff)) >> 9) + y0;
    return e <= 0x1d ? r >> (0x1e - e) : r << (e - 0x1e);
}

static void op_scaled(const short *sin, int *out, const int *in, int phase, int freq, int gain1, int gain2, int flags)
{
    struct fm_args a;
    const int mx = gain1 > gain2 ? gain1 : gain2, d = (gain2 - gain1 + 0x20) >> 6;
    int s, sh;
    if (mx <= 0x7fff) { sh = -0x19; s = 0x10; }
    else { const int c = __builtin_clz(mx); s = c - 1; sh = -8 - c; }
    a.out = out; a.in = in; a.phase = phase; a.freq = freq; a.gain = gain1 << s; a.dgain = d << s; a.shift = sh; a.sin = sin;
    oa_dx_op(&a, flags);
}

/* msfa_note_compute (DX's dx_msfa.c) */
static void note_compute(struct voice *v, int *buf, int base_pitch, int lfo_val, int lfo_delay, int *scratch, const short *sin)
{
    const signed char *pe_level_t = (const signed char *)(F.i + I_PE_LEVEL);
    const unsigned char *pe_rate_t = F.i + I_PE_RATE, (*algo)[6] = (const unsigned char (*)[6])(F.i + I_ALGO);
    const int *ams = (const int *)(F.i + I_AMS);
    int pe_level = v->pe_level, pitch_off, amd, i, fb_len, alg, has[3];
    if (v->pe_ix <= 2 || (v->pe_ix == 3 && !v->pe_down)) {
        const int ix = v->pe_ix;
        if (v->pe_rising) {
            pe_level += v->pe_inc;
            if (pe_level < v->pe_target) { v->pe_level = pe_level; goto pdone; }
        } else {
            pe_level -= v->pe_inc;
            if (pe_level > v->pe_target) { v->pe_level = pe_level; goto pdone; }
        }
        pe_level = v->pe_target;
        v->pe_level = pe_level;
        v->pe_ix = ix + 1;
        if (ix != 3) {
            v->pe_target = pe_level_t[v->pe_levels[ix + 1]] << 19;
            v->pe_rising = pe_level < v->pe_target;
            v->pe_inc = pe_rate_t[v->pe_rates[ix + 1]] * 1143;
        }
    }
pdone:
    pitch_off = (((v->pitchmodsens * (lfo_val - 0x800000)) >> 16) * (int)((unsigned)(v->pitchmoddepth * lfo_delay) >> 16) >> 7) + pe_level;
    amd = ((((v->ampmoddepth * 0x296) >> 8) * (lfo_delay >> 8) >> 16) * (lfo_val >> 8)) >> 16;
    struct fmop *op = v->op;
    struct env *e = v->env;
    const int *bp = v->basepitch;
    for (i = 0; i < 6; i++, op++, e++, bp++) {
        int level, gain, freq;
        op->gain_in = op->gain_out;
        level = e->level;
        if (e->ix <= 2 || (e->ix == 3 && !e->down)) {
            const int ix = e->ix;
            if (e->rising) {
                int slope;
                if (level <= 0x06b3ffff) { level = 0x06b40000; slope = 10; }
                else slope = ((17 << 24) - level) >> 24;
                level += slope * e->inc;
                if (level < e->target) { e->level = level; goto edone; }
            } else {
                level -= e->inc;
                if (level > e->target) { e->level = level; goto edone; }
            }
            level = e->target;
            e->level = level;
            e->ix = ix + 1;
            if (ix != 3) F.env_adv(e, ix + 1);
        }
    edone:
        if (v->ampmodsens[i]) level -= ams[v->ampmodsens[i]] * amd;
        gain = (v->opmask >> i) & 1 ? exp2_lookup(level - (7 << 25)) : 0;
        op->gain_out = gain;
        freq = *bp;
        if (v->fixmode[i] == 0) freq += base_pitch;
        op->freq = freq_lookup(freq + pitch_off);
    }
    alg = v->algorithm & 0x1f;
    has[0] = has[1] = has[2] = 0;
    fb_len = 0;
    if (alg == 3) { if (v->fb_shift <= 15) fb_len = 3; }
    else if (alg == 5) { if (v->fb_shift <= 15) fb_len = 2; }
    if (fb_len) {
        struct fm_fb_args a;
        a.out = buf; a.n = fb_len; a.shift = 17 - v->fb_shift; a.fb0 = v->fb[0]; a.fb1 = v->fb[1]; a.sin = sin;
        for (int k = 0; k < fb_len; k++) {
            const int g1 = v->op[k].gain_in, g2 = v->op[k].gain_out, d = (g2 - g1 + 0x20) >> 6, mx = g1 > g2 ? g1 : g2;
            int s, sh;
            if (mx <= 0x7fff) { sh = -0x19; s = 0x10; }
            else { const int c = __builtin_clz(mx); s = c - 1; sh = -8 - c; }
            a.op[k].phase = v->op[k].phase; a.op[k].freq = v->op[k].freq;
            a.op[k].gain = g1 << s; a.op[k].dgain = d << s; a.op[k].shift = sh;
        }
        oa_dx_fb(&a);
        v->fb[0] = a.fb0; v->fb[1] = a.fb1;
        if (v->op[fb_len - 1].gain_in > 0x45f || v->op[fb_len - 1].gain_out > 0x45f) has[0] = 1;
    }
    for (i = 0; i < 6; i++) {
        op = &v->op[i];
        const int ph = op->phase;
        if (i < fb_len) { op->phase = ph + (op->freq << 6); continue; }
        const int flags = algo[alg][i], outbus = flags & 3;
        int *outptr = outbus == 0 ? buf : scratch + (outbus - 1) * 0x40;
        const int g1 = op->gain_in, g2 = op->gain_out;
        if (g1 > 0x45f || g2 > 0x45f) {
            const int add = has[outbus] ? (flags & 4) != 0 : 0, inbus = (flags >> 4) & 3;
            if (inbus != 0 && has[inbus])
                op_scaled(sin, outptr, scratch + (inbus - 1) * 0x40, ph, op->freq, g1, g2, add + 2);
            else if ((flags & 0xc0) == 0xc0 && v->fb_shift <= 15) {
                struct fm_fb1_args f;
                const int d = (g2 - g1 + 0x20) >> 6, mx = g1 > g2 ? g1 : g2;
                int s, sh;
                if (mx <= 0x7fff) { sh = -0x19; s = 0x10; }
                else { const int c = __builtin_clz(mx); s = c - 1; sh = -8 - c; }
                f.out = outptr; f.fb = v->fb; f.phase = ph; f.freq = op->freq;
                f.gain = g1 << s; f.dgain = d << s; f.shift = sh; f.sin = sin; f.fs = 17 - v->fb_shift;
                oa_dx_fb1(&f, add);
            } else
                op_scaled(sin, outptr, 0, ph, op->freq, g1, g2, add);
            has[outbus] = 1;
        } else if (!(flags & 4))
            has[outbus] = 0;
        op->phase += op->freq << 6;
    }
    if (!has[0]) for (i = 0; i < 64; i++) buf[i] = 0;
}

/* engine_render (DX's dx_render) */
void oa_dx_render(void *voice, short *out, const short *par, const unsigned *pitch)
{
    struct voice *v = voice;
    struct sound *sd = (struct sound *)(F.z + Z_SOUND);
    unsigned char *cur = F.z + Z_PATCH;
    const unsigned char *patch, *amp;
    const int *attack = (const int *)(F.i + I_ATTACK), *decay = (const int *)(F.i + I_DECAY);
    int bank, vn, logf, old, gain, level, i;
    calls++;
    if (v->index == IW(I_LAST_NOTE)) ZP(Z_LAST_VOICE) = v;
    if (ZP(Z_SIN_LEASE)) F.sin_use(ob_fast_use(ZP(Z_SIN_LEASE)));
    if (ZP(Z_FM_LEASE)) {
        int *b = ob_fast_use(ZP(Z_FM_LEASE));
        ZP(Z_FM_BUFFER) = b;
        ZP(Z_FM_SCRATCH) = (char *)b + 0x100;
    }
    bank = par[5];
    vn = par[6];
    if (bank != IW(I_LV_BANK) || vn != IW(I_LV_INDEX)) {
        F.get_patch(bank, vn, cur);
        if (!(sd->flags & 1)) F.lfo_reset(F.z + Z_LFO, cur);
        IW(I_LV_BANK) = bank;
        IW(I_LV_INDEX) = vn;
    }
    patch = (sd->flags & 1) ? sd->patch : cur;
    amp = (sd->flags & 2) ? sd->amp : F.i + I_AMP_ENV;
    logf = F.log2(*pitch) + (int)0xF06DB197 + (patch[0x90] - 24) * 0x155555;
    if (v->first) {
        int midi;
        v->first = 0;
        if (logf > 0x02E80732) {
            midi = (logf - 0x02FD5C87) / 0x155555;
            if (midi > 127) midi = 127;
        } else
            midi = 0;
        F.note_init(v, patch, midi, VOICE_VELOCITY(v->index) >> 8);
        v->hold = ((const unsigned short *)(F.i + I_HOLD_TIME))[amp[5] % 100];
        if (amp[0] == 0) {
            v->stage = 1;
            v->amp_level = (amp[4] > 99 ? 0 : amp[4] - 99) * 0x295f3a;
            v->last_out = 0;
            v->amp_gain = exp2_lookup(v->amp_level);
        } else {
            v->stage = 0; v->amp_level = 0; v->last_out = 0; v->amp_gain = 0;
        }
    }
    if (v->releasing == 1) {
        v->releasing = 2;
        F.keyup(v);
    }
    old = v->amp_gain;
    if (v->releasing && v->stage <= 3) {
        level = v->amp_level;
        if (v->stage == 0) {
            level = level > 0 ? F.log2(level) - 0x18000000 : -0x10000000;
            v->amp_level = level;
        }
        v->stage = 4;
        goto release;
    }
    switch (v->stage) {
    case 0: {
        const int peak = exp2_lookup(((amp[4] > 99 ? 99 : amp[4]) - 99) * 0x295f3a);
        level = v->amp_level + (((attack[amp[0] % 100] >> 10) * (peak >> 8)) >> 6);
        v->amp_level = level;
        if (peak > level) gain = level;
        else { v->amp_level = ((amp[4] > 99 ? 99 : amp[4]) - 99) * 0x295f3a; v->stage = 1; gain = peak; }
        break;
    }
    case 1: {
        const short h = v->hold;
        v->hold = h - 1;
        if (h <= 0) v->stage = 2;
        gain = exp2_lookup(v->amp_level);
        break;
    }
    case 2: {
        const int sus = ((amp[2] > 99 ? 99 : amp[2]) - 99) * 0x295f3a;
        level = v->amp_level - decay[amp[1] % 100];
        if (sus < level) v->amp_level = level;
        else { v->stage = 3; v->amp_level = sus; level = sus; }
        gain = exp2_lookup(level);
        break;
    }
    case 3:
        level = ((amp[2] > 99 ? 99 : amp[2]) - 99) * 0x295f3a;
        v->amp_level = level;
        gain = exp2_lookup(level);
        break;
    case 4:
        level = v->amp_level;
    release:
        level -= decay[amp[3] % 100];
        v->amp_level = level;
        if (level < (int)0xF0000001) {
            v->stage = 5;
            v->amp_gain = 0;
            if (old == 0) goto silent;
            gain = 0;
            goto render;
        }
        gain = exp2_lookup(level);
        break;
    default:
        v->amp_gain = 0;
        if (old == 0) goto silent;
        gain = 0;
        goto render;
    }
    v->amp_gain = gain;
    if ((old | gain) == 0) {
    silent:
        for (i = 0; i < 128; i++) out[i] = 0;
        v->last_out = 0;
        return;
    }
render: {
        int *buf = ZP(Z_FM_BUFFER);
        note_compute(v, buf, logf, IW(I_LFO_SAMPLE), ZW(Z_LFO_DELAY), ZP(Z_FM_SCRATCH), *(const short **)(F.i + I_SIN_PTR));
        if (v->releasing && v->stage <= 4 && F.silent(v)) v->stage = 5;
        v->last_out = oa_dx_out(out, buf, old, (gain - old) >> 6, v->last_out);
    }
}

#ifndef OA_KERN_ASM                         /* DX's dx_kern.c: the host's and the tests' reference */
void oa_dx_op(const struct fm_args *a, int flags)
{
    int *out = a->out;
    const int *in = a->in;
    int phase = a->phase, gain = a->gain;
    for (int i = 0; i < 64; i++) {
        unsigned ph = phase;
        if (flags & 2) ph += (unsigned)*in++ << 18;
        gain += a->dgain;
        int y = (a->sin[ph >> 20] * (short)(gain >> 16)) >> -a->shift;
        if (flags & 1) y += out[i];
        out[i] = y;
        phase += a->freq;
    }
}
void oa_dx_fb(struct fm_fb_args *a)
{
    int fb0 = a->fb0, fb1 = a->fb1, y = 0;
    for (int i = 0; i < 64; i++) {
        unsigned ph = (unsigned)(fb0 + fb1) << a->shift;
        for (int k = 0; k < a->n; k++) {
            struct fm_fb_op *o = &a->op[k];
            const unsigned idx = (o->phase + ph) >> 20;
            o->phase += o->freq;
            o->gain += o->dgain;
            y = (a->sin[idx] * (short)(o->gain >> 16)) >> -o->shift;
            ph = y << 18;
        }
        fb0 = fb1; fb1 = y; a->out[i] = y;
    }
    a->fb0 = fb0; a->fb1 = fb1;
}
void oa_dx_fb1(struct fm_fb1_args *a, int add)
{
    int *p = a->out, fb0 = a->fb[0], fb1 = a->fb[1], g = a->gain;
    unsigned ph = a->phase;
    for (int k = 0; k < 64; k++) {
        const unsigned x = ((unsigned)(fb0 + fb1) << a->fs) + ph;
        g += a->dgain;
        const int y = (a->sin[x >> 20] * (short)(g >> 16)) >> -a->shift;
        fb0 = fb1; fb1 = y;
        *p = add ? *p + y : y;
        p++;
        ph += a->freq;
    }
    a->fb[0] = fb0; a->fb[1] = fb1;
}
int oa_dx_out(short *out, const int *s, int old, int step, int prev)
{
    for (int i = 0; i < 64; i++) {
        const int x = *s++;
        old += step;
        int y = (((x * 7) >> 5) * (old >> 9)) >> 15;
        if (y < -0x4000) y = -0x4000;
        if (y > 0x4000) y = 0x4000;
        out[2 * i] = (prev + y) >> 1;
        out[2 * i + 1] = y;
        prev = y;
    }
    return prev;
}
#endif
