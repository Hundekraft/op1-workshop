/*
 * The sim accelerator (oa.h): opus.sim 0.1.9's render_cb on kennel's kernels. The voice is HIM's (plugins/him/
 * him_voice.c, the original drum engine's synthesis ported with the author's permission per the owner, 2026-11-09),
 * here on sim's own 76-byte voice: the constants live in a cache of the accelerator's (one per voice index), and the
 * body's |xs| is the original's (32-bit: at xs = -0x8000 the body sample is 4, where HIM's build has 0). What render_cb
 * does around the voice is redone on the file's own globals (offsets checked in the 0.1.9 image, names.json of the
 * OP1-Emulator ext/opus-src rebuild): the voice's ratio and log at 0x44 / 0x48, zero+0x44 the last ratio, and the scope
 * tap (zero+0x5248 mark cycles, +0x524C block counter, +0x5250 32 sums, +0x5290 512 x {lo, hi, block}) the page draws.
 * Integers only; the block's divides only run when a key's numbers, the pitch or choke change.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "oa.h"

#define Z_RATIO   0x44u
#define Z_MARK    0x5248u
#define Z_COUNT   0x524Cu
#define Z_ACCUM   0x5250u
#define Z_RING    0x5290u

static uint8_t *zero_at;                    /* the bound file's zero fill */
static oa_simc cache[16];                   /* by the voice's index (init_cb's, 0..11) */
static oa_simkp kp_s;                       /* the block's values (audio thread only) */
static uint32_t calls;
uint32_t oa_sim_calls(void) { return calls; }
uint8_t *oa_sim_zero(void) { return zero_at; }             /* tests: the bound file's zero fill */
void oa_sim_bind(uint8_t *zero) { zero_at = zero; for (int i = 0; i < 16; i++) cache[i].ok = 0; }

static const uint16_t gain_tab[17] = { 962, 1002, 1019, 1013, 962, 853, 730, 604, 493, 420, 337, 274, 231, 201, 181, 165, 149 };
static const uint32_t exp_tab[17] = { 0x8000, 0x85ab, 0x8b96, 0x91c4, 0x9838, 0x9ef5, 0xa5ff, 0xad58, 0xb505, 0xbd09, 0xc567,
                                      0xce25, 0xd745, 0xe0cd, 0xeac1, 0xf525, 0x10000 };

static inline int32_t clampi(int32_t x, int32_t a, int32_t b) { return x < a ? a : x > b ? b : x; }
static inline int32_t s16(int32_t x) { return (int16_t)x; }

static uint32_t exp2q(int32_t x)            /* 65536 * 2^(x / 4096) */
{
    const int32_t o = x >> 12, i = (x >> 8) & 15, f = x & 0xff;
    const uint32_t v = (uint32_t)(((((int32_t)exp_tab[i + 1] - (int32_t)exp_tab[i]) * f) >> 8) + (int32_t)exp_tab[i]) * 2u;
    if (x >= 0) return o >= 15 ? 0xffffffffu : v << o;
    return o < -17 ? 0 : v >> -o;
}
static int32_t log2q(uint32_t r)            /* render_cb's: 4096 * log2(r / 65536) */
{
    uint32_t u = r;
    int32_t e = -1;
    if (r <= 0xffff) { while (u <= 0x7fff) { u <<= 1; e--; } }
    else { do { u >>= 1; e++; } while (u > 0xffff); }
    int32_t f = 0;
    for (uint32_t bit = 0x800; bit; bit >>= 1) {
        const uint32_t sq = u * u;
        u = sq >> 15;
        if (u > 0xffff) { u = sq >> 16; f |= bit; }
    }
    return e * 0x1000 + f;
}
static inline uint32_t step_inc(uint32_t sw, int32_t samt, int32_t u, int32_t logp)
{
    const int32_t x = clampi(((int32_t)(sw >> 1) * samt >> 15) + u + logp, 0, 0x9287);
    return ((exp2q(x & 0xfff) * 0x5338u) >> 9) << (x >> 12);
}

#define KP_AT(f, o) _Static_assert(__builtin_offsetof(oa_simkp, f) == (o), "oa_sim_kern.S reads oa_simkp." #f " at " #o)
KP_AT(r, 0); KP_AT(m0, 24); KP_AT(mi, 28); KP_AT(nz0, 32); KP_AT(ni, 36); KP_AT(inc0, 40); KP_AT(dinc, 44); KP_AT(b0, 48);
KP_AT(bi, 52); KP_AT(flag, 56); KP_AT(c, 60);
#define C_AT(f, o) _Static_assert(__builtin_offsetof(oa_simc, f) == (o), "oa_sim_kern.S reads oa_simc." #f " at " #o)
C_AT(fc, 0); C_AT(cmix, 4); C_AT(G, 8); C_AT(colhi, 12); C_AT(g, 16); C_AT(dgs, 20); C_AT(douts, 24); C_AT(hold, 28); C_AT(mask, 32);
#define V_AT(f, o) _Static_assert(__builtin_offsetof(oa_simv, f) == (o), "sim's voice: " #f " at " #o)
V_AT(ph, 0); V_AT(seed, 0x1c); V_AT(lp, 0x20); V_AT(bp, 0x24); V_AT(env, 0x28); V_AT(nenv, 0x2c); V_AT(swp, 0x30);
V_AT(hold_n, 0x34); V_AT(hold_v, 0x38); V_AT(choke, 0x3c); V_AT(index, 0x40); V_AT(ratio, 0x44); V_AT(logp, 0x48);

static void derive(const oa_simv *v, oa_simc *c, const int16_t *par, int32_t logp)
{
    for (int i = 0; i < 8; i++) c->par[i] = par[i];
    c->logp = logp; c->choke = v->choke; c->ok = 1; c->inc_ok = 0;
    const int32_t p0 = clampi(par[0], -0x5f00, 0x6100);
    const int32_t dec = par[1] > 0 ? par[1] : 0, swp = par[2] > 0 ? par[2] : 0, noi = par[3] > 0 ? par[3] : 0;
    const int32_t colraw = par[4], col = colraw > 0 ? colraw : 0, shpraw = par[5], shp = shpraw > 0 ? shpraw : 0;
    const int32_t drvraw = par[7], drv = drvraw > 0 ? drvraw : 0;
    const int32_t k = (int32_t)(((exp2q(0x60f2 - dec) >> 8) * 0x3b3du) >> 16);
    const int32_t nq = ((0x7fff - noi) * (0x7fff - noi)) >> 15;
    const int32_t rate = (int32_t)((uint32_t)(k << 15) / (uint32_t)(0x8000 - ((noi * 0x599a) >> 15)));   /* both >= 0 */
    const int32_t srate = rate * 4 > 0x1ee ? rate * 4 : 0x1ee;
    if (!v->choke) {
        c->f1 = exp2q(-rate);
        c->f2 = exp2q(-((((((nq * nq) >> 15) * 3) >> 3) + 0x1000) * k >> 12));
    } else c->f1 = c->f2 = 0x4000;
    c->f3 = exp2q(-srate);
    {                                       /* u = 2 x / 3, x = p0 + 0x5f00 in 0 .. 0xc000, without a divide */
        const uint32_t x = (uint32_t)(p0 + 0x5f00), q = (x * 43691u) >> 17;
        c->u = (int32_t)(2 * q + ((x - 3 * q) >> 1));
    }
    c->samt = swp * 5 >> 3;
    const int32_t one_n2 = 0x7fff - ((noi * noi) >> 15);
    int32_t gain, body;
    if (shpraw <= 0x3fff) {
        const int32_t t = ((shp * 2) * (shp * 2)) >> 15;
        gain = ((t * 15) >> 7) + 0x100; body = 0x7fff; c->msc = -1;
    } else {
        const int32_t m = (shp - 0x4000) * 2;
        body = 0x7fff - m; c->msc = m * one_n2 >> 15; gain = 0x1000;
    }
    const int32_t ai = col >> 11;
    c->G = (((((int32_t)gain_tab[ai + 1] - gain_tab[ai]) * (col & 0x7ff)) >> 11) + gain_tab[ai]) * 2;
    c->b = one_n2 * body >> 15;
    c->q = 0x7fff - nq;
    const uint32_t ff = exp2q((col * 71) >> 7) * 700u;
    c->fc = ff > 0x3e80ffffu ? 16000 : (int32_t)(ff >> 16);
    c->cmix = colraw > 0x3fff ? col - 0x4000 : col;
    c->colhi = colraw > 0x3fff;
    c->g = s16(gain);
    c->dgs = s16(((((drv * drv) >> 15) * 15) >> 7) + 0x100);
    c->douts = s16(0x3ccd - ((drv * 0xc29) >> 15));
    if (drvraw <= 0x4ccd) { c->hold = 1; c->mask = -1; }
    else {
        const int32_t t = (((drv - 0x4ccd) * 5) >> 1) * 5;
        c->mask = (int32_t)(0xffffffffu << (t >> 14)); c->hold = (t >> 15) + 1;
    }
    c->crunch = !(c->hold == 1 && c->mask == -1);
}

/* voice_render_block: 64 samples at 44.1 kHz, each twice into out[128] */
void oa_sim_voice(oa_simv *v, oa_simc *c, int16_t *out, const int16_t *par, int32_t logp)
{
    oa_simkp *kp = &kp_s;
    if (!c->ok || c->logp != logp || c->choke != v->choke || c->par[0] != par[0] || c->par[1] != par[1] ||
        c->par[2] != par[2] || c->par[3] != par[3] || c->par[4] != par[4] || c->par[5] != par[5] ||
        c->par[6] != par[6] || c->par[7] != par[7])
        derive(v, c, par, logp);
    kp->c = c;
    const uint32_t e0 = v->env >> 8, env1 = e0 * c->f1, n0 = v->nenv >> 8, nenv1 = n0 * c->f2, swp1 = v->swp * c->f3;
    const int hit = c->inc_ok && c->inc_swp == v->swp;
    const uint32_t inc0 = hit ? c->inc : step_inc(v->swp, c->samt, c->u, logp);
    const uint32_t inc1 = step_inc(swp1 >> 16, c->samt, c->u, logp);
    c->inc_swp = swp1 >> 16; c->inc = inc1; c->inc_ok = 1;
    const int32_t dinc = (int32_t)(inc1 - inc0) >> 6;
    int32_t m0 = 0, m1 = 0;
    if (c->msc >= 0) { m1 = (int32_t)(env1 >> 16) * c->msc >> 7; m0 = (int32_t)e0 * c->msc >> 7; }
    const int32_t b0 = (int32_t)e0 * c->b >> 7, b1 = (int32_t)(env1 >> 16) * c->b >> 7;
    const int32_t nz0 = (int32_t)n0 * c->q >> 7, nz1 = (int32_t)(nenv1 >> 16) * c->q >> 7;
    const int hasm = (m0 | m1) > 0x3ff;
    const int hasn = hasm || (nz0 | nz1) > 0x3ff;
    if (hasn) {
        if (hasm) {
            const uint32_t base = inc0 >> 12;
            kp->r[0] = base * 0x1000u; kp->r[1] = base * 0x17b9u; kp->r[2] = base * 0x1cceu; kp->r[3] = base * 0x28bdu;
            kp->r[4] = base * 0x2a16u; kp->r[5] = base * 0x3e59u;
            kp->m0 = m0; kp->mi = (m1 - m0) >> 6;
        }
        kp->nz0 = nz0; kp->ni = (nz1 - nz0) >> 6; kp->flag = hasm;
        oa_sim_noise(v, out, kp);
    }
    if ((b0 | b1) > 0x3ff) {
        kp->inc0 = (int32_t)inc0; kp->dinc = dinc; kp->b0 = b0; kp->bi = (b1 - b0) >> 6; kp->flag = hasn;
        oa_sim_body(v, out, kp);
        v->ph[0] = v->ph[0] + 64u * inc0 + 0x7e0u * (uint32_t)dinc;
    } else if (!hasn)
        for (int n = 64; n < 128; n++) out[n] = 0;
    kp->flag = c->crunch;
    oa_sim_drive(v, out, kp);
    v->env = env1 >> 8; v->nenv = nenv1 >> 8; v->swp = swp1 >> 16;
}

static inline uint32_t cycles(void)
{
#ifdef __bfin__
    uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c;
#else
    return 0;
#endif
}

uint32_t oa_sim_inc0(const oa_simv *v, const short *par, int32_t logp)    /* tests: the block's first body step */
{
    oa_simc c;
    c.ok = 0;
    derive(v, &c, par, logp);
    return step_inc(v->swp, c.samt, c.u, logp);
}

/* render_cb */
void oa_sim_render(void *voice, short *out, const short *par, const unsigned *pitch)
{
    oa_simv *v = voice;
    const uint32_t r = pitch && *pitch ? *pitch : 0x10000u;
    int32_t logp;
    if (r == v->ratio) logp = v->logp;
    else { logp = r == 0x10000u ? 0 : log2q(r); v->ratio = r; v->logp = logp; }
    uint8_t *z = zero_at;
    *(volatile uint32_t *)(z + Z_RATIO) = r;
    oa_sim_voice(v, &cache[v->index & 15], out, par, logp);
    calls++;
    uint32_t *mark = (uint32_t *)(z + Z_MARK), *count = (uint32_t *)(z + Z_COUNT);
    int16_t *acc = (int16_t *)(z + Z_ACCUM);
    const uint32_t now = cycles(), el = now - *mark;
    if (el > 290240u) {
        uint32_t n = (el + 290240u) / 580480u;
        if (!n) n = 1;
        *count += n;
        *mark = now;
        for (int i = 0; i < 32; i++) acc[i] = 0;
    }
    int32_t lo = 0x7fff, hi = -0x7fff;
    for (int i = 0; i < 32; i++) {
        const int32_t a = clampi(acc[i] + out[4 * i], -0x7fff, 0x7fff);
        acc[i] = (int16_t)a;
        lo = lo < a ? lo : a;
        hi = hi > a ? hi : a;
    }
    uint8_t *e = z + Z_RING + ((*count & 0x1ffu) << 3);
    ((int16_t *)e)[0] = (int16_t)lo; ((int16_t *)e)[1] = (int16_t)hi;
    ((uint32_t *)e)[1] = *count;
}

/* the C sample loops: on out[64..127] (the release's sample order); the assembly in oa_sim_kern.S */
#ifndef OA_KERN_ASM
void oa_sim_noise(oa_simv *v, int16_t *out, const oa_simkp *kp)
{
    const oa_simc *c = kp->c;
    int16_t *o = out + 64;
    if (kp->flag) {
        uint32_t a0 = v->ph[1], a1 = v->ph[2], a2 = v->ph[3], a3 = v->ph[4], a4 = v->ph[5], a5 = v->ph[6];
        const uint32_t r0 = kp->r[0], r1 = kp->r[1], r2 = kp->r[2], r3 = kp->r[3], r4 = kp->r[4], r5 = kp->r[5];
        const int32_t mi = kp->mi;
        int32_t me = kp->m0;
        for (int n = 0; n < 64; n++) {
            a0 += r0; a1 += r1; a2 += r2; a3 += r3; a4 += r4; a5 += r5;
            const int32_t neg = (int32_t)((a0 >> 31) + (a1 >> 31) + (a2 >> 31) + (a3 >> 31) + (a4 >> 31) + (a5 >> 31));
            me += mi;
            o[n] = (int16_t)(((3 - neg) * s16(me >> 8)) >> 4);
        }
        v->ph[1] = a0; v->ph[2] = a1; v->ph[3] = a2; v->ph[4] = a3; v->ph[5] = a4; v->ph[6] = a5;
    } else
        for (int n = 0; n < 64; n++) o[n] = 0;
    int32_t ne = kp->nz0, lp = v->lp, bp = v->bp;
    const int32_t ni = kp->ni, fc = c->fc, cmix = c->cmix, G = c->G;
    uint32_t x = v->seed;
    for (int n = 0; n < 64; n++) {
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        ne += ni;
        const int32_t nz = (s16((int32_t)(x >> 16)) * s16(ne >> 8)) >> 17;
        lp += (fc * s16(bp)) >> 14;
        const int32_t hp = clampi(o[n] + nz - lp - bp, -0x7fff, 0x7fff);
        bp += (fc * hp) >> 14;
        const int32_t y = c->colhi ? (s16(bp) * (0x4000 - cmix) + hp * cmix) >> 14 : (s16(lp) * (0x4000 - cmix) + s16(bp) * cmix) >> 14;
        o[n] = (int16_t)clampi((s16(y) * G) >> 8, -0x7fff, 0x7fff);
    }
    v->seed = x; v->lp = lp; v->bp = bp;
}

void oa_sim_body(oa_simv *v, int16_t *out, const oa_simkp *kp)
{
    int16_t *o = out + 64;
    uint32_t ph = v->ph[0], ii = (uint32_t)kp->inc0;
    int32_t be = kp->b0;
    const int32_t bi = kp->bi, g = kp->c->g, dinc = kp->dinc, add = kp->flag;
    for (int n = 0; n < 64; n++) {
        ph += ii; ii += (uint32_t)dinc;
        const int32_t xs = (int32_t)ph >> 16;                  /* -0x8000 .. 0x7fff: |xs| up to 0x8000, as the original's */
        int32_t y = (xs * s16(0x7fff - (xs < 0 ? -xs : xs))) >> 13;
        y = clampi((s16(y) * g) >> 8, -0x7fff, 0x7fff);
        be += bi;
        const int32_t w = (y * s16(be >> 8)) >> 16;
        o[n] = (int16_t)clampi((add ? o[n] : 0) + w, -0x7fff, 0x7fff);
    }
}

void oa_sim_drive(oa_simv *v, int16_t *out, const oa_simkp *kp)
{
    const oa_simc *c = kp->c;
    const int16_t *o = out + 64;
    const int32_t dgs = c->dgs, douts = c->douts, hold = c->hold, mask = c->mask, crunch = kp->flag;
    int32_t hn = v->hold_n, hv = v->hold_v;
    for (int n = 0; n < 64; n++) {
        const int32_t x = clampi((o[n] * dgs) >> 7, -0x7fff, 0x7fff);
        const int32_t cu = x * s16((x * x) >> 15);
        int32_t y;
        if (!crunch) y = clampi(x + (x >> 1) - (cu >> 16), -0x7fff, 0x7fff);
        else {
            if (--hn <= 0) { hv = clampi(x + (x >> 1) - (cu >> 16), -0x7fff, 0x7fff) & mask; hn = hold; }
            y = hv;
        }
        out[2 * n] = out[2 * n + 1] = (int16_t)((s16(y) * douts) >> 15);
    }
    if (crunch) { v->hold_n = hn; v->hold_v = hv; }
}
#endif
