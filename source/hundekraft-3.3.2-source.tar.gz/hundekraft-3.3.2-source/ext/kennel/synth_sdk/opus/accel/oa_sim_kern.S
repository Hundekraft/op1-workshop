/* The sim accelerator's sample loops (oa.h: oa_sim_noise, oa_sim_body, oa_sim_drive): HIM's him_kern.S (plugins/him,
 * the original drum engine's synthesis ported with the author's permission per the owner, 2026-11-09), bit for bit the C
 * in oa_sim.c, with three changes for sim's own 76-byte voice: the constants come from kp->c (oa_simc, not the voice),
 * and the body's |xs| is the original's: v = 0x7fff - |xs| wraps (|-0x8000| = 0x8000, v = -1, y = 4) instead of HIM's
 * saturating ABS (V). Exactness notes, register rules (only R, P, A, I0..I3, L0..L3 saved and zeroed, M2 / M3 saved;
 * every access 16-bit): him_kern.S's header.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "oa.h"
#ifdef OA_KERN_ASM

#define V_HOLD_N 52                     /* oa_simv */
#define V_HOLD_V 56
#define V_FC 0                          /* oa_simc (oa_sim.c checks the offsets) */
#define V_CMIX 4
#define V_G 8
#define V_COLHI 12
#define V_GB 16
#define V_DGS 20
#define V_DOUTS 24
#define V_HOLD 28
#define V_MASK 32
#define K_R 0                           /* him_kp */
#define K_M0 24
#define K_MI 28
#define K_NZ0 32
#define K_NI 36
#define K_INC0 40
#define K_DINC 44
#define K_B0 48
#define K_BI 52
#define K_FLAG 56
#define K_C 60

.macro LSAVE2
	R3 = L0; [--SP] = R3;
	R3 = L1; [--SP] = R3;
	R3 = 0; L0 = R3; L1 = R3;
.endm
.macro LREST2
	R3 = [SP++]; L1 = R3;
	R3 = [SP++]; L0 = R3;
.endm

/* ---- the drive, two samples a turn: R0 = o[2k] | o[2k+1] << 16 (I0 reads o), R5 = dgs | douts << 16.
 * x = sat16((o dgs) >> 7) (A1, A0: 32-bit products, shifted, saturated on extraction); t = x x >> 15 (T);
 * c >> 16 = ((x t) >> 15) >> 1 (T, |x t| < 2^30); y = (x - c16) + (x >> 1) saturated (x - c16 is exact: c16 has x's
 * sign and |c16| <= |x| / 2); out = y douts >> 15 (T). The C's lower clamps at -0x7fff are left out, both provably
 * without effect: x = -0x8000 (t saturates to 0x7fff) gives y = -0x8000 as x = -0x7fff does, and y = -0x8000 gives
 * the same out as -0x7fff (0 < douts < 0x8000, so both floor to -douts) and the same masked hv (a crunch mask clears
 * bit 0: crunch needs t >> 14 >= 1, as t >> 14 = 0 gives hold 1 and no mask).
 * Crunch: the pair masked (the mask's low half in both halves, from the stack: its high half is all ones, so the
 * 16-bit AND is the C's), then sample by sample: --hn <= 0 takes the masked y into hv (R1, its low half) and hn = hold
 * (P3 = hn, P4 = hold); out = hv douts >> 15 (R7.L, R7.H). I1 writes each result twice, a turn late. ---- */
.macro DPAIR ld, st, crunch, end=0
.if \st
	A1 = R0.H * R5.L, A0 = R0.L * R5.L (IS) || W[I1++] = R7.L;
.else
	A1 = R0.H * R5.L, A0 = R0.L * R5.L (IS);
.endif
.if \ld && \st
	A1 = A1 >>> 7 || R0.L = W[I0++] || W[I1++] = R7.L;
	A0 = A0 >>> 7 || R0.H = W[I0++] || W[I1++] = R7.H;
.elseif \st
	A1 = A1 >>> 7 || W[I1++] = R7.L;
	A0 = A0 >>> 7 || W[I1++] = R7.H;
.else
	A1 = A1 >>> 7 || R0.L = W[I0++];
	A0 = A0 >>> 7 || R0.H = W[I0++];
.endif
.if \st
	R6.H = A1, R6.L = A0 (IS) || W[I1++] = R7.H;
.else
	R6.H = A1, R6.L = A0 (IS);
.endif
	R7.H = R6.H * R6.H, R7.L = R6.L * R6.L (T);          /* t */
	R3.H = R6.H * R7.H, R3.L = R6.L * R7.L (T);
	R3 = R3 >>> 1 (V);                                   /* c >> 16 */
	R3 = R6 -|- R3;
	R2 = R6 >>> 1 (V);
	R3 = R3 +|+ R2 (S);
.if \crunch
	R2 = [SP];                                           /* the mask */
	R3 = R3 & R2;
	P3 += -1;
	CC = P3 <= 0;
	IF CC R1 = R3;
	IF CC P3 = P4;
	R7.L = R1.L * R5.H (T);
	P3 += -1;
	R2 = R3 >>> 16;
	CC = P3 <= 0;
	IF CC R1 = R2;
	IF CC P3 = P4;
.if \end
2:
.endif
	R7.H = R1.L * R5.H (T);
.else
.if \end
2:
.endif
	R7.H = R3.H * R5.H, R7.L = R3.L * R5.H (T);
.endif
.endm

.macro DRIVE crunch
	DPAIR 1, 0, \crunch
	P0 = 30;
	LSETUP (1f, 2f) LC0 = P0;
1:	DPAIR 1, 1, \crunch, 1
	DPAIR 0, 1, \crunch
	W[I1++] = R7.L;
	W[I1++] = R7.L;
	W[I1++] = R7.H;
	W[I1++] = R7.H;
.endm

	.text
	.align 4
	.global _oa_sim_drive
	.type _oa_sim_drive, STT_FUNC
_oa_sim_drive:
	[--SP] = (R7:4, P5:3);
	LSAVE2
	P2 = R0;
	P1 = R2;
	P5 = [P1 + K_C];                                     /* the constants */
	I1 = R1;
	R3 = 128;
	R1 = R1 + R3;
	I0 = R1;
	R5 = [P5 + V_DGS];
	R3 = [P5 + V_DOUTS];
	R5 = PACK (R3.L, R5.L);
	R0.L = W[I0++];
	R0.H = W[I0++];
	R2 = [P1 + K_FLAG];                                  /* crunch */
	CC = R2 == 0;
	IF CC JUMP .Ld_plain;
	P3 = [P2 + V_HOLD_N];
	P4 = [P5 + V_HOLD];
	R1 = [P2 + V_HOLD_V];
	R3 = [P5 + V_MASK];
	R3 = PACK (R3.L, R3.L);
	[--SP] = R3;
	DRIVE 1
	SP += 4;
	R1 = R1.L (X);
	[P2 + V_HOLD_N] = P3;
	[P2 + V_HOLD_V] = R1;
	JUMP .Ld_end;
.Ld_plain:
	DRIVE 0
.Ld_end:
	LREST2
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _oa_sim_drive, .-_oa_sim_drive

/* ---- the body, two samples a turn (s1, s2): R0 the phase, I3 the increment (+= M3 = dinc a sample), I2 the level
 * << 8 (+= M2 = bi << 8; its high half is s16(be >> 8)), R1 = 0x7fff in both halves. X = xs2 | xs1 (the phases' high
 * halves); v = 0x7fff - |xs| as the original computes it: |xs| = (xs ^ m) - m with m = xs >>> 15 per half, wrapping
 * (|-0x8000| = 0x8000), and v = 0x7fff - |xs| wrapping, so xs = -0x8000 gives v = -1 and y = 4 (HIM's saturating
 * ABS (V) gives 0 there); y = (xs v) >> 13, |y| <= 32767, so the (IS) extraction is exact;
 * y2 = sat16((y g) >> 8): the C's upper clamp, and its lower one (-0x7fff) is left out: y2 = -0x8000 gives the same
 * w as -0x7fff (b = s16(be >> 8) lies in -1 .. 0x7ffd, the envelope's range, and floor(-0x8000 b / 2^16) =
 * floor(-0x7fff b / 2^16) there); w = (y2 b) >> 16 = ((y2 b) >> 15) >> 1 (T, |y2 b| < 2^30).
 * Added: o + w saturated (the C's upper clamp; its lower one is left out as well: the drive follows, and its
 * dgs >= 0x100 turns -0x8000 and -0x7fff alike into x = -0x8000). I0 reads o, I1 writes it a turn late. ---- */
.macro BPAIR add, st, end=0
	R2 = I3;
.if \st
	R2 = R0 + R2 (NS) || I3 += M3 || W[I1++] = R6.L;     /* ph1 */
.else
	R2 = R0 + R2 (NS) || I3 += M3;
.endif
	R4 = I3;
.if \st
	R0 = R2 + R4 (NS) || I3 += M3 || W[I1++] = R6.H;     /* ph2 */
.else
	R0 = R2 + R4 (NS) || I3 += M3;
.endif
	R3 = PACK (R0.H, R2.H);                              /* X */
	R5 = R3 >>> 15 (V);                                  /* m: 0xffff in a negative half */
	R4 = R3 ^ R5;
	R4 = R4 -|- R5;                                      /* |xs|, wrapping: 0x8000 at -0x8000 */
	R5 = R1 -|- R4;                                      /* v, wrapping: -1 at -0x8000 */
	A1 = R3.H * R5.H, A0 = R3.L * R5.L (IS) || R2 = [P1];   /* g */
	A1 = A1 >>> 13 || I2 += M2;
	R4 = I2;                                             /* be1 << 8 */
	A0 = A0 >>> 13 || I2 += M2;
	R5 = I2;                                             /* be2 << 8 */
	R6.H = A1, R6.L = A0 (IS);                           /* y */
	A1 = R6.H * R2.L, A0 = R6.L * R2.L (IS);
	A1 = A1 >>> 8;
	A0 = A0 >>> 8;
	R6.H = A1, R6.L = A0 (IS);                           /* y2 */
	R7 = PACK (R5.H, R4.H);                              /* b2 | b1 */
.if \add
	R6.H = R6.H * R7.H, R6.L = R6.L * R7.L (T) || R5.L = W[I0++];
	R6 = R6 >>> 1 (V) || R5.H = W[I0++];                 /* w */
.if \end
2:
.endif
	R6 = R6 +|+ R5 (S);
.else
	R6.H = R6.H * R7.H, R6.L = R6.L * R7.L (T);
.if \end
2:
.endif
	R6 = R6 >>> 1 (V);                                   /* w */
.endif
.endm

.macro BODY add
	BPAIR \add, 0
	P0 = 31;
	LSETUP (1f, 2f) LC0 = P0;
1:	BPAIR \add, 1, 1
	W[I1++] = R6.L;
	W[I1++] = R6.H;
.endm

	.text
	.align 4
	.global _oa_sim_body
	.type _oa_sim_body, STT_FUNC
_oa_sim_body:
	[--SP] = (R7:4);
	R3 = L0; [--SP] = R3;
	R3 = L1; [--SP] = R3;
	R3 = L2; [--SP] = R3;
	R3 = L3; [--SP] = R3;
	R3 = M2; [--SP] = R3;
	R3 = M3; [--SP] = R3;
	R3 = 0; L0 = R3; L1 = R3; L2 = R3; L3 = R3;
	P2 = R0;
	R3 = 128;
	R1 = R1 + R3;
	I0 = R1;
	I1 = R1;
	P0 = R2;                                             /* kp */
	R0 = [P2];                                           /* ph[0] */
	R3 = [P0 + K_INC0]; I3 = R3;
	R3 = [P0 + K_DINC]; M3 = R3;
	R3 = [P0 + K_B0]; R3 <<= 8; I2 = R3;
	R3 = [P0 + K_BI]; R3 <<= 8; M2 = R3;
	R2 = [P0 + K_FLAG];                                  /* add */
	P1 = [P0 + K_C];                                     /* the constants: g */
	P1 += V_GB;
	R1 = 0x7fff (Z);
	R1 = PACK (R1.L, R1.L);
	CC = R2 == 0;
	IF CC JUMP .Lb_alone;
	BODY 1
	JUMP .Lb_end;
.Lb_alone:
	BODY 0
.Lb_end:
	R3 = [SP++]; M3 = R3;
	R3 = [SP++]; M2 = R3;
	R3 = [SP++]; L3 = R3;
	R3 = [SP++]; L2 = R3;
	R3 = [SP++]; L1 = R3;
	R3 = [SP++]; L0 = R3;
	(R7:4) = [SP++];
	RTS;
	.size _oa_sim_body, .-_oa_sim_body

/* ---- the metal (met only), in two passes over o[] that keep three phases each in registers (R0..R2, increments
 * R3..R5): pass A writes t = 3 + (a0 >>> 31) + (a1 >>> 31) + (a2 >>> 31), pass B adds a3..a5's and writes
 * (t me8) >> 4 with me8 = s16(me >> 8), the high half of I3 (me << 8, += M3 = mi << 8). Then the noise and the filter,
 * a sample a turn: R0 the xorshift state, R1 the noise level << 8 (its high half s16(ne >> 8)), R2 lp, R3 bp, R7 =
 * fc s16(bp) (worked out with the last sample's y, a dual MAC). The table at P1 (on the stack): ni << 8, 0x7fff,
 * -0x7fff, fc | cmix, fc | 0x4000 - cmix (the high half fc), G, 3. P0 reads o (sign-extended), I1 writes it a turn
 * late. All sums wrap (NS) as the C's 32-bit ones do; the clamps are MIN / MAX on 32 bits (the output's too: it is
 * stored as 16 bits, so a value under -0x8000 would wrap). ---- */
#define T_NI 0
#define T_MAX 4
#define T_MIN 8
#define T_FCM 12
#define T_FCN 16
#define T_G 20
#define T_3 24
#define T_CH 28

.macro MA st, end=0
.if \st
	R0 = R0 + R3 (NS) || R7 = [P1 + T_3] || W[I1++] = R7.L;
.else
	R0 = R0 + R3 (NS) || R7 = [P1 + T_3];
.endif
	R1 = R1 + R4 (NS);
	R2 = R2 + R5 (NS);
	R6 = R0 >>> 31;
	R7 = R7 + R6 (NS);
	R6 = R1 >>> 31;
	R7 = R7 + R6 (NS);
	R6 = R2 >>> 31;
.if \end
2:
.endif
	R7 = R7 + R6 (NS);
.endm

.macro MB st, end=0
.if \st
	R0 = R0 + R3 (NS) || R7 = W[P0++] (X) || W[I1++] = R6.L;
.else
	R0 = R0 + R3 (NS) || R7 = W[P0++] (X);
.endif
	R1 = R1 + R4 (NS) || I3 += M3;
	R2 = R2 + R5 (NS);
	R6 = R0 >>> 31;
	R7 = R7 + R6 (NS);
	R6 = R1 >>> 31;
	R7 = R7 + R6 (NS);
	R6 = R2 >>> 31;
	R7 = R7 + R6 (NS);
	R6 = I3;
	R6 = R7.L * R6.H (IS);
.if \end
2:
.endif
	R6 = R6 >>> 4;
.endm

.macro NS1 met, hi, st, end=0
.if \st
	R4 = R0 << 13 || W[I1++] = R6.L;
.else
	R4 = R0 << 13;
.endif
	R0 = R0 ^ R4;
	R4 = R0 >> 17 || R6 = [P1 + T_NI];
	R0 = R0 ^ R4;
	R4 = R0 << 5;
	R0 = R0 ^ R4;
	R1 = R1 + R6 (NS);                                   /* ne << 8 */
	R4 = R0.H * R1.H (IS);
.if \met
	R4 = R4 >>> 17 || R5 = W[P0++] (X);                  /* nz; the metal sample */
.else
	R4 = R4 >>> 17;                                      /* nz */
.endif
	R7 = R7 >>> 14;
	R2 = R2 + R7 (NS);                                   /* lp */
.if \met
	R4 = R4 + R5 (NS);
.endif
	R4 = R4 - R2 (NS) || R5 = [P1 + T_MAX];
	R4 = R4 - R3 (NS) || R6 = [P1 + T_MIN];
	R4 = MIN (R4, R5) || R5 = [P1 + T_FCM];
	R4 = MAX (R4, R6);                                   /* hp */
.if \hi
	R7 = (A1 = R4.L * R5.H), R6 = (A0 = R4.L * R5.L) (IS);   /* fc hp; cmix hp */
	R7 = R7 >>> 14 || R5 = [P1 + T_FCN];
	R3 = R3 + R7 (NS);                                   /* bp */
	R7 = (A1 = R3.L * R5.H), R6 = (A0 += R3.L * R5.L) (IS);  /* fc bp; + (0x4000 - cmix) bp */
.else
	R6 = R4.L * R5.H (IS);
	R6 = R6 >>> 14;
	R3 = R3 + R6 (NS);                                   /* bp */
	R7 = (A1 = R3.L * R5.H), R6 = (A0 = R3.L * R5.L) (IS) || R5 = [P1 + T_FCN];   /* fc bp; cmix bp */
	R6 = (A0 += R2.L * R5.L) (IS);                       /* + (0x4000 - cmix) lp */
.endif
	R6 = R6 >>> 14 || R5 = [P1 + T_G];                   /* y */
	R6 = R6.L * R5.L (IS) || R5 = [P1 + T_MAX];
	R6 = R6 >>> 8 || R4 = [P1 + T_MIN];
	R6 = MIN (R6, R5);
.if \end
2:
.endif
	R6 = MAX (R6, R4);                                   /* out */
.endm

.macro NOISE met, hi
	R7 = R3.L * R5.H (IS);                               /* fc bp */
	NS1 \met, \hi, 0
	P2 = 63;
	LSETUP (1f, 2f) LC0 = P2;
1:	NS1 \met, \hi, 1, 1
	W[I1++] = R6.L;
.endm

	.text
	.align 4
	.global _oa_sim_noise
	.type _oa_sim_noise, STT_FUNC
_oa_sim_noise:
	[--SP] = (R7:4, P5:3);
	R3 = L0; [--SP] = R3;
	R3 = L1; [--SP] = R3;
	R3 = L3; [--SP] = R3;
	R3 = M3; [--SP] = R3;
	R3 = 0; L0 = R3; L1 = R3; L3 = R3;
	SP += -32;
	P1 = SP;
	P5 = R0;                                             /* v */
	P3 = R2;                                             /* kp */
	R3 = 128;
	R1 = R1 + R3;
	P4 = R1;                                             /* o */
	R2 = [P3 + K_FLAG];                                  /* metal */
	[--SP] = R2;
	R0 = [P3 + K_NI]; R0 <<= 8; [P1 + T_NI] = R0;
	R0 = 0x7fff (Z); [P1 + T_MAX] = R0;
	R0 = -0x7fff (X); [P1 + T_MIN] = R0;
	P0 = [P3 + K_C];                                     /* the constants */
	R0 = [P0 + V_COLHI]; [P1 + T_CH] = R0;
	R0 = [P0 + V_FC];
	R1 = [P0 + V_CMIX];
	R2 = PACK (R0.L, R1.L); [P1 + T_FCM] = R2;
	R3 = 0x4000 (Z);
	R1 = R3 - R1;
	R2 = PACK (R0.L, R1.L); [P1 + T_FCN] = R2;
	R0 = [P0 + V_G]; [P1 + T_G] = R0;
	R0 = 3; [P1 + T_3] = R0;
	R2 = [SP++];
	CC = R2 == 0;
	IF CC JUMP .Ln_noise;
	/* the metal: pass A */
	R0 = [P5 + 4]; R1 = [P5 + 8]; R2 = [P5 + 12];
	R3 = [P3 + K_R]; R4 = [P3 + K_R + 4]; R5 = [P3 + K_R + 8];
	I1 = P4;
	MA 0
	P2 = 63;
	LSETUP (1f, 2f) LC0 = P2;
1:	MA 1, 1
	W[I1++] = R7.L;
	[P5 + 4] = R0; [P5 + 8] = R1; [P5 + 12] = R2;
	/* pass B */
	R0 = [P5 + 16]; R1 = [P5 + 20]; R2 = [P5 + 24];
	R3 = [P3 + K_R + 12]; R4 = [P3 + K_R + 16]; R5 = [P3 + K_R + 20];
	R6 = [P3 + K_M0]; R6 <<= 8; I3 = R6;                 /* m0 << 8 */
	R6 = [P3 + K_MI]; R6 <<= 8; M3 = R6;                 /* mi << 8 */
	I1 = P4;
	P0 = P4;
	MB 0
	P2 = 63;
	LSETUP (1f, 2f) LC0 = P2;
1:	MB 1, 1
	W[I1++] = R6.L;
	[P5 + 16] = R0; [P5 + 20] = R1; [P5 + 24] = R2;
	/* the noise and the filter */
	R0 = [P5 + 28]; R1 = [P3 + K_NZ0]; R1 <<= 8; R2 = [P5 + 32]; R3 = [P5 + 36]; R5 = [P1 + T_FCM];
	I1 = P4;
	P0 = P4;
	R6 = [P1 + T_CH];
	CC = R6 == 0;
	IF CC JUMP .Ln_m_lo;
	NOISE 1, 1
	JUMP .Ln_end;
.Ln_m_lo:
	NOISE 1, 0
	JUMP .Ln_end;
.Ln_noise:
	R0 = [P5 + 28]; R1 = [P3 + K_NZ0]; R1 <<= 8; R2 = [P5 + 32]; R3 = [P5 + 36]; R5 = [P1 + T_FCM];
	I1 = P4;
	R6 = [P1 + T_CH];
	CC = R6 == 0;
	IF CC JUMP .Ln_lo;
	NOISE 0, 1
	JUMP .Ln_end;
.Ln_lo:
	NOISE 0, 0
.Ln_end:
	[P5 + 28] = R0; [P5 + 32] = R2; [P5 + 36] = R3;
	SP += 32;
	R3 = [SP++]; M3 = R3;
	R3 = [SP++]; L3 = R3;
	R3 = [SP++]; L1 = R3;
	R3 = [SP++]; L0 = R3;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _oa_sim_noise, .-_oa_sim_noise

#endif
