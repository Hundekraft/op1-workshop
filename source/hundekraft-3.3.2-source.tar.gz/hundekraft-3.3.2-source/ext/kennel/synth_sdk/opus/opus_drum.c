/*
 * Opus drum engines as kennel drum-synth providers (Opus bridge phase 3, opus.h): an engine with OPUS_ENGINE_DRUM
 * (sim) plays a D-Box-family kit, R246's own 24 keys x 8 words, as HIM does (plugins/him/him_fw.c is the template: the
 * same R246 addresses, no new ones). opus_engine_add hands such an engine to od_add (inside its file's transaction:
 * od_rollback undoes it); after the stage, od_offer gives each committed type to the core (kn_ds_foreign_offer), which
 * activates it after the features' providers and adds its drum_types row (marked: removed once the file is gone).
 *
 * What the Opus core does (its engine glue, read in the full project ext/opus-src core/src/engineglue.c and enginehooks.c),
 * and so the adapter: a build (the factory) runs init(state, i) for the twelve voices; a key's note gets the key's
 * eight words (in R246's kit table), the key 0..23 and velocity 127: when group(words, key) > 0, every other active
 * voice of the engine on another key whose words give the same group is choked first; then note_key (or note_on).
 * A block: render(state, out, working words, &ratio) with ratio = R246's base pitch of that voice >> 10 (0x10000 =
 * no transposition), 128 samples at 88.2 kHz; then finished(state): nonzero ends the voice (status 0).
 * T1: R246's D-Box controls edit the kit (shift for words 4..7); the page is the engine's `page` on screen 0x11
 * (HIM's construction, an empty SVG), with opus_drum_key giving the shown key's words.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../op1_synth.h"
#include "../op1_feature_drum_synth.h"
#include "../kennel/kn_foreign.h"
#include "od_kits.h"

void *kn_alloc(uint32_t size);
void kn_log_line(const char *file, const char *msg);

#define OD_VOICES       12
#define CORE_SLOT       (*(volatile uint32_t *)0x01aaac10)          /* the slot whose voices exist */
#define SELECTED_SLOT   (*(volatile uint32_t *)0xff8016d8)          /* the drum slot shown */
#define LAST_PAD        (*(volatile uint32_t *)0xff801044)          /* the key last played / shown */
#define DRUM_MODE       (*(volatile uint32_t *)0x01de4c40)
#define BUILT_MODE      (*(volatile int32_t *)0xFF801038)
#define CURRENT_SCREEN  (*(volatile uint32_t *)0x018b65c8)
#define TABLE           ((void *volatile *)0x01df4e54)
#define SCREEN_ID       0x11u
#define PUBLICATION     ((void **)0x01aaad30)
#define VOICE_PITCH     ((const volatile uint32_t *)0xff801304)     /* a drum voice's base pitch: 2^26 = ratio 1 */
#define BASE(slot)      ((int16_t *)(0x01aaadb4u + (slot) * 384u))  /* a kit: 24 keys x 8 words */
#define STOCK_FACTORY(t, p, s) (((uint32_t (*)(uint32_t, void **, uint32_t))0x01a1b9c0)((t), (p), (s)))
#define JSON_GET(j, k)  (((const void *(*)(const void *, const char *))0x019BEB70)((j), (k)))

typedef struct { uint32_t alloc; union { char buf[16]; const char *ptr; } u; uint32_t size, cap; } name_string;

typedef struct {
    const opus_engine *e;
    ob_file *file;
    ob_render_fn render;                    /* e->render, or the file's accelerator (ob_render_for) */
    char saved[16];
    char row[64];                           /* its drum_types default_params: the engine's knobs */
    char kit[4][16];                        /* its factory kits' names (od_offer) */
    int mark;
    uint32_t vbytes;
    uint8_t *state;                         /* OD_VOICES x vbytes */
    uint8_t active[OD_VOICES];
    int8_t key[OD_VOICES];                  /* the key a voice plays, -1 none */
    uint8_t selected[8], bound, scanned;
    void *receiver[OD_VOICES];
    op1_drum_synth_t prov;
    uint32_t screen[32], vtable[10];
    void *original_screen;
    uint8_t screen_ready;
    uint32_t frames;
} od_type;
static od_type od[OD_TYPES];
static int n_drum;
int od_file_has(const ob_file *f) { for (int k = 0; k < n_drum; k++) if (od[k].file == f) return 1; return 0; }

int od_count(void) { return n_drum; }
void od_rollback(int n) { if (n >= 0 && n < n_drum) n_drum = n; }
const opus_engine *od_engine(int k) { return k >= 0 && k < n_drum ? od[k].e : 0; }
void *od_state(int k, int v) { return k >= 0 && k < n_drum && v >= 0 && v < OD_VOICES ? od[k].state + v * od[k].vbytes : 0; }
int od_mark(int k) { return k >= 0 && k < n_drum ? od[k].mark : 0; }
const void *od_provider(int k) { return k >= 0 && k < n_drum ? &od[k].prov : 0; }

static int has(const opus_engine *e, uint32_t end) { return e->size >= end; }
static int (*group_fn(const opus_engine *e))(const int16_t *, int) { return has(e, 112) ? e->group : 0; }
static void (*choke_fn(const opus_engine *e))(void *) { return has(e, 116) ? e->choke : 0; }

/* ---- the voices (also what tier 2 drives) ---- */
void od_build(int k)                                            /* a factory build: every voice's init */
{
    od_type *t = &od[k];
    for (int v = 0; v < OD_VOICES; v++) {
        t->active[v] = 0; t->key[v] = -1;
        if (t->e->init) t->e->init(t->state + v * t->vbytes, v);
    }
}
/* a hit on key (0..23) of a kit (24 x 8 words) on voice v, as the Opus core's voice note on */
void od_hit(int k, int v, const int16_t *kit, int key)
{
    od_type *t = &od[k];
    const opus_engine *e = t->e;
    const int16_t *w = kit + key * 8;
    int (*grp)(const int16_t *, int) = group_fn(e);
    void (*chk)(void *) = choke_fn(e);
    if (grp && chk) {
        const int g = grp(w, key);
        if (g > 0)
            for (int u = 0; u < OD_VOICES; u++) {
                if (u == v || !t->active[u] || t->key[u] < 0 || t->key[u] == key) continue;
                if (grp(kit + t->key[u] * 8, 0) != g) continue;
                chk(t->state + u * t->vbytes);
            }
    }
    t->key[v] = (int8_t)key;
    void *s = t->state + v * t->vbytes;
    if (has(e, 108) && e->note_key) e->note_key(s, w, key, 127);
    else if (e->note_on) e->note_on(s, w);
    t->active[v] = 1;
}
/* one block of voice v: 128 samples; returns whether it still sounds */
int od_block(int k, int v, int16_t *out, const int16_t *par, uint32_t ratio)
{
    od_type *t = &od[k];
    void *s = t->state + v * t->vbytes;
    unsigned r = ratio;
    t->render(s, out, par, &r);
    if (t->e->finished(s)) t->active[v] = 0;
    return t->active[v];
}

/* ---- the provider (op1_feature_drum_synth.h), HIM's R246 glue ---- */
static int is_mine(const od_type *t, const name_string *s)
{
    if (!s || s->size > 15) return 0;
    const char *p = s->cap > 15 ? s->u.ptr : s->u.buf;
    uint32_t i = 0;
    while (i < s->size && t->saved[i] && p[i] == t->saved[i]) i++;
    return i == s->size && !t->saved[i];
}
static int receiver_ok(uint32_t i, const void *p)
{
    return (uintptr_t)p == 0xffb00000u + 72u * i && *(volatile const uint32_t *)p == 0x0190f8a4u &&
           *(volatile const uint32_t *)((const unsigned char *)p + 20) == i && PUBLICATION[i] == p;
}
static int voice_of(const od_type *t, const void *p) { for (int i = 0; i < OD_VOICES; i++) if (t->receiver[i] == p) return i; return -1; }
static int ready(const od_type *t) { const uint32_t s = CORE_SLOT; return t->bound && s < 8 && t->selected[s]; }
static void scan(od_type *t)                                    /* slots loaded before the provider was there */
{
    for (unsigned slot = 0; slot < 8; slot++) {
        const void *v = JSON_GET((const void *)(0x01DDD9ACu + slot * 0x38), "type");
        if (v && ((const unsigned char *)v)[8] == 4) {
            const char *s = *(const char *const *)v;
            int i = 0;
            while (s && t->saved[i] && s[i] == t->saved[i]) i++;
            t->selected[slot] = s && !t->saved[i] && !s[i];
        }
    }
}

static uint32_t x_type(int k, const void *s, uint32_t caller, const void *patch)
{
    od_type *t = &od[k];
    const int mine = is_mine(t, s);
    if (caller == 0x01a006f4u && patch) {                       /* a slot's type is being set (Gin's rule) */
        const uint32_t slot = *(const uint32_t *)patch;
        if (slot < 8) t->selected[slot] = (uint8_t)mine;
    }
    return mine ? 9u : op1_drum_synth_stock_type(s);
}
static uint32_t x_factory(int k, uint32_t type)
{
    od_type *t = &od[k];
    const uint32_t slot = CORE_SLOT, r = STOCK_FACTORY(type, PUBLICATION, slot);
    t->bound = 0;
    if (type != 9u || slot >= 8 || !t->selected[slot]) return r;
    for (uint32_t i = 0; i < OD_VOICES; i++) { if (!receiver_ok(i, PUBLICATION[i])) return r; t->receiver[i] = PUBLICATION[i]; }
    /* a new kit (every word 0, as R246 hands a new type-9 kit over, or every key at the engine's own row) starts as
     * the engine's own kit (keys), as on Opus */
    int16_t *base = BASE(slot);
    int fresh = 1, zero = 1;
    for (int key = 0; key < 24 && (fresh || zero); key++)
        for (int j = 0; j < 8; j++) {
            if (base[key * 8 + j] != t->e->knobs[j]) fresh = 0;
            if (base[key * 8 + j]) zero = 0;
        }
    if ((fresh || zero) && has(t->e, 104) && t->e->keys)
        for (int key = 0; key < 24; key++) for (int j = 0; j < 8; j++) base[key * 8 + j] = t->e->keys[key][j];
    od_build(k);
    t->bound = 1;
    return r;
}
static uint32_t x_route(int k, const void *p) { return ready(&od[k]) && voice_of(&od[k], p) >= 0; }
static uint32_t x_trigger(int k, void *p, const int16_t *canonical)
{
    od_type *t = &od[k];
    const int v = voice_of(t, p);
    const uint32_t slot = CORE_SLOT;
    if (v < 0 || !ready(t) || !canonical) return 1;
    const uintptr_t d = (uintptr_t)canonical - (uintptr_t)BASE(slot);
    if ((uintptr_t)canonical < (uintptr_t)BASE(slot) || d >= 384u || (d & 15u)) return 1;
    od_hit(k, v, BASE(slot), (int)(d >> 4));
    return 0;
}
static uint32_t x_render(int k, void *p, int16_t *out, const int16_t *working)
{
    od_type *t = &od[k];
    const int v = voice_of(t, p);
    if (v < 0 || !ready(t) || !working) { for (int i = 0; i < 128; i++) out[i] = 0; return 1; }
    od_block(k, v, out, working, VOICE_PITCH[v] >> 10);
    return 0;
}
static uint32_t x_status(int k, const void *p)
{
    od_type *t = &od[k];
    const int v = voice_of(t, p);
    return v >= 0 && ready(t) && t->active[v];
}
static uint32_t x_release(void *p, const int16_t *w) { (void)p; (void)w; return 0; }   /* drums: no note off */
static void x_reset(int k) { for (int v = 0; v < OD_VOICES; v++) od[k].active[v] = 0; }
static void x_service(int k)
{
    od_type *t = &od[k];
    if (t->scanned) return;
    t->scanned = 1;                                             /* once: bind receivers built before the provider */
    scan(t);
    const uint32_t c = CORE_SLOT;
    if (c < 8 && t->selected[c] && BUILT_MODE == 1) x_factory(k, 9u);
}

/* ---- the page: the engine's `page` on screen 0x11 (HIM's construction over an empty SVG) ---- */
void oe_page_run(void (*fn)(void));                            /* opus_engine.c: the page primitives' raster */
static void scr_init(void *scr) { (void)scr; }
static void (*const t_up[OD_TYPES])(void *, int);
static void scr_update(int k, void *scr, int dt)
{
    od_type *t = &od[k];
    op1_screen_draw(scr, dt);
    if (t->e->page) oe_page_run(t->e->page);
    op1_screen_hash(scr, ++t->frames);                          /* the page draws every frame: never skipped */
}
static void x_ctor(int k)
{
    od_type *t = &od[k];
    t->original_screen = TABLE[SCREEN_ID];
    ((void *(*)(void *, int, const char *))0x01a3bab0)(t->screen, SCREEN_ID, "usbout.svg");
    TABLE[SCREEN_ID] = t->original_screen;
    for (unsigned i = 0; i < 10; i++) t->vtable[i] = ((const uint32_t *)0x019103fc)[i];
    t->vtable[7] = (uint32_t)(uintptr_t)t_up[k]; t->vtable[9] = (uint32_t)(uintptr_t)scr_init;
    t->screen[3] = (uint32_t)(uintptr_t)t->vtable;
}
static void x_load(int k)
{
    od_type *t = &od[k];
    t->original_screen = TABLE[SCREEN_ID];
    if (!t->screen[3]) return;
    if (t->screen[2]) t->screen[0] = (uint32_t)(uintptr_t)((void *(*)(void *))0x01a503d8)((void *)(uintptr_t)t->screen[2]);
    if (t->screen[0]) t->screen_ready = 1;
}
static uint32_t x_select(int k)
{
    od_type *t = &od[k];
    const uint32_t slot = SELECTED_SLOT;
    if (t->original_screen) TABLE[SCREEN_ID] = t->screen_ready && slot < 8 && t->selected[slot] ? (void *)t->screen : t->original_screen;
    return SCREEN_ID;
}

/* opus_drum_key: the shown kit's key words (R246's table, 16 bytes a key); the key, 0 past 23 (the Opus core's) */
static int s_drum_key(int16_t *out)
{
    const uint32_t slot = SELECTED_SLOT & 7;
    uint32_t key = LAST_PAD;
    if (key > 23) key = 0;
    const int16_t *w = BASE(slot) + key * 8;
    for (int i = 0; i < 8; i++) out[i] = w[i];
    return (int)key;
}

/* opus_drum_select_key (core 2.57): R246's selected drum pad (0xFF801044, the word its drum key-down handlers and drum
 * note-on store and its drum knob handler and pages read; kennel branch fluke-set kennel/kn_drum_key.h has the same
 * store as op1_drum_select_key): the key the drum's T1 and opus_drum_key take, without playing it. 1, 0 past 23. */
static int s_drum_select_key(int key)
{
    if ((unsigned)key >= 24u) return 0;
    LAST_PAD = (uint32_t)key;
    return 1;
}

#define TR(k) \
    static uint32_t ty##k(const void *s, uint32_t c, const void *p) { return x_type(k, s, c, p); } \
    static uint32_t fa##k(uint32_t t) { return x_factory(k, t); } \
    static uint32_t ro##k(const void *p) { return x_route(k, p); } \
    static uint32_t tr##k(void *p, const int16_t *w) { return x_trigger(k, p, w); } \
    static uint32_t re##k(void *p, int16_t *o, const int16_t *w) { return x_render(k, p, o, w); } \
    static uint32_t st##k(const void *p) { return x_status(k, p); } \
    static void rs##k(void) { x_reset(k); } \
    static void sv##k(void) { x_service(k); } \
    static void ct##k(void) { x_ctor(k); } \
    static void ld##k(void *tb) { (void)tb; x_load(k); } \
    static uint32_t se##k(void) { return x_select(k); } \
    static void up##k(void *scr, int dt) { scr_update(k, scr, dt); }
TR(0) TR(1)
static const op1_drum_synth_t tmpl[OD_TYPES] = {
    { .type = ty0, .factory = fa0, .route = ro0, .trigger = tr0, .render = re0, .status = st0, .release = x_release,
      .screen_ctor = ct0, .screen_load = ld0, .screen_select = se0, .service = sv0, .reset = rs0 },
    { .type = ty1, .factory = fa1, .route = ro1, .trigger = tr1, .render = re1, .status = st1, .release = x_release,
      .screen_ctor = ct1, .screen_load = ld1, .screen_select = se1, .service = sv1, .reset = rs1 } };
static void (*const t_up[OD_TYPES])(void *, int) = { up0, up1 };

/* ---- registration (opus_engine_add, inside the file's transaction) ---- */
int od_add(ob_file *f, const opus_engine *e, const char *saved, int mark)
{
    char m[80];
    const char *why = 0;
    if (n_drum >= OD_TYPES) why = "too many drum engine types";
    else if (!has(e, 76) || !e->finished) why = "a drum engine needs finished";
    else if (e->voice > 4096) why = "a voice needs more memory than this core gives";
    else if (!(has(e, 108) && e->note_key) && !e->note_on) why = "a drum engine needs note_key";
    if (why) { ob_cat(ob_cat(ob_cat(m, e->name), ": "), why); kn_log_line(f->self.id, m); return -1; }
    od_type *t = &od[n_drum];
    const uint32_t vb = (e->voice + 31) & ~31u;
    uint8_t *a = kn_alloc(OD_VOICES * (vb ? vb : 32) + 32);
    if (!a) { kn_log_line(f->self.id, "plugin memory full"); return -2; }
    for (int i = 0; i < (int)sizeof *t; i++) ((uint8_t *)t)[i] = 0;
    t->state = (uint8_t *)(((uint32_t)a + 31) & ~31u);
    t->vbytes = vb ? vb : 32;
    t->e = e; t->file = f; t->mark = mark;
    t->render = ob_render_for(f, (ob_render_fn)e->render);
    ob_cat(t->saved, saved);
    {   /* "[k0,..,k7]": the engine's knobs (a fresh kit's every key; the factory replaces it with `keys`) */
        char *p = ob_cat(t->row, "[");
        for (int i = 0; i < 8; i++) {
            int v = e->knobs[i];
            if (v < 0) { *p++ = '-'; v = -v; }
            p = ob_num(p, (uint32_t)v);
            if (i < 7) *p++ = ',';
        }
        ob_cat(p, "]");
    }
    t->prov = tmpl[n_drum];
    t->prov.api = OP1_DRUM_SYNTH_API; t->prov.size = sizeof(op1_drum_synth_t);
    t->prov.name = t->saved; t->prov.state_key = "opus_drum_state";
    for (int v = 0; v < OD_VOICES; v++) t->key[v] = -1;
    n_drum++;
    char *p = ob_cat(ob_cat(m, "drum engine "), t->saved);
    p = ob_num(ob_cat(p, " voice "), e->voice);
    p = ob_num(ob_cat(p, " mark "), (uint32_t)mark);
    if (has(e, 112) && e->group && has(e, 116) && e->choke) p = ob_cat(p, " choke");
    kn_log_line(f->self.id, m);
    return mark;
}
/* A kit saved on Opus (opus_saved.c, before the parse): type "dbox" carrying the engine's mark and its plugin id (the
 * Opus core's drum_job_run_hook). -> the saved name of the drum engine with that mark (else, without a mark, the
 * file's first drum engine), or 0 */
const char *od_from_opus(int mark, const char *engine)
{
    for (int k = 0; k < n_drum; k++) if (mark > 0 && od[k].mark == mark) return od[k].saved;
    for (int k = 0; mark <= 0 && engine && k < n_drum; k++) if (ob_eq(od[k].file->self.id, engine)) return od[k].saved;
    return 0;
}
/* after the stage: the committed types to the core (activated after the features' drum synths) */
void od_offer(void)
{
    for (int k = 0; k < n_drum; k++) {
        od_type *t = &od[k];
        for (int v = 0; v < OD_VOICES; v++) if (t->e->init) t->e->init(t->state + v * t->vbytes, v);
        scan(t);
        if (kn_ds_foreign_offer(&t->prov, t->row)) { kn_log_line(t->file->self.id, "drum engine: no room"); continue; }
        /* factory kits (the kit browser, folder = the saved name): "<name> default", the engine's own kit (`keys`, what
         * a new kit starts as); for sim also the retired HIM port's three kits on its words (od_kits.h). The Opus core
         * lists no kits of its own for an engine: a new kit is its `keys` there. */
        int nk = 0;
        if (has(t->e, 104) && t->e->keys && ob_inside(t->file, t->e->keys)) {
            ob_cat(ob_cat(t->kit[nk], t->saved), " default");
            kn_ds_foreign_kit(&t->prov, t->kit[nk], &t->e->keys[0][0]);
            nk++;
        }
        if (ob_eq(t->file->self.id, "opus.sim"))
            for (unsigned i = 0; i < sizeof od_sim_kits / sizeof od_sim_kits[0] && nk < 4; i++, nk++) {
                if (ob_len(t->saved) + 1 + ob_len(od_sim_kits[i].name) > 15) break;
                ob_cat(ob_cat(ob_cat(t->kit[nk], t->saved), " "), od_sim_kits[i].name);
                kn_ds_foreign_kit(&t->prov, t->kit[nk], &od_sim_kits[i].w[0][0]);
            }
    }
}
const ob_sym od_imports[] = {                                   /* merged into the import table (sorted by name) */
    { "opus_drum_key", (uint32_t)s_drum_key },
    { "opus_drum_select_key", (uint32_t)s_drum_select_key },
};
const int od_n_imports = (int)(sizeof od_imports / sizeof od_imports[0]);
