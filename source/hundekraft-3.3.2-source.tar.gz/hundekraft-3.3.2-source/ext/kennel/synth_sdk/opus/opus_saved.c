/*
 * Sounds saved on Opus (kennel/kn_foreign.h kn_foreign_sound): kennel/kn_patch_safe.c hands every sound to this before
 * R246's parser reads it (all five parse_patch_json callers: slot loads at boot, preset tables, a preset or kit load),
 * and the parts the Opus core saved in its own form are rewritten into the form kennel saves, so the sound opens as
 * one saved here would. Saves stay kennel form (README "Saves are kennel form only"); a kennel-saved sound is never
 * changed (each test below fails for it).
 *
 * What the Opus core saves (OP1-Emulator ext/opus-src core/src): a drum engine's kit is type "dbox" with
 * {"opus": {"engine": <plugin id>, "mark": <the engine's mark>}} (enginemark.c drum_job_run_hook); a plugin LFO type is
 * a stock MIDI LFO at rest ("lfo_type": "midi") with {"opus": {"lfo_type": <name>, "lfo_active", "lfo_params": [n]}}
 * (lfotypes.c lfo_pick_hook, fxrecords.c fx_slot_set_or_clear, manager "lfo"); an effect is "fx_type": its own name
 * with its eight params in its own units (fxhost.c), and an older sound may name it by an alias ("opus1:10",
 * fx_type_id_by_name).
 *   kit:    type "dbox" + a mark or engine of a bridged drum engine (od_from_opus) -> type = its saved name ("sim");
 *           the member's mark and engine are removed.
 *   LFO:    "lfo_type" "midi" + the member's lfo_type a bridged LFO type (ol_from_opus) -> lfo_type = its saved name,
 *           lfo_params = its words, "lfo_rec" = the settings (as op1_lfo_record_store keeps them); the member's three
 *           lfo keys are removed (the synth keep step keeps the member: a later stock pick must stay stock).
 *   effect: fx_type an Opus effect's name or alias with words not carrying kennel's selector (ox_from_opus) ->
 *           fx_type = its saved name ("plate" -> "plate_o"), fx_params = kennel's words.
 * Every node is type-checked before it is read (jsoncpp asserts on a wrong type); a member that is not as expected
 * leaves the sound as it was.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../kennel/kn_foreign.h"

#define JV_KEY      ((void *(*)(void *, const char *))0x019BFEB4)        /* Value::operator[](const char *) */
#define JV_CGET     ((const void *(*)(const void *, const char *))0x019BEB70)   /* const operator[]: no member added */
#define JV_IDX      ((void *(*)(void *, unsigned))0x019BFAF8)            /* Value::operator[](ArrayIndex) */
#define JV_SIZE     ((unsigned (*)(const void *))0x019BE8D8)             /* Value::size */
#define JV_ASSIGN   ((void *(*)(void *, const void *))0x019BDDC0)        /* Value::operator= */
#define JV_FROM_INT ((void *(*)(void *, int))0x019BD890)                 /* Value(int) */
#define JV_FROM_STR ((void *(*)(void *, const char *))0x019BDC4C)        /* Value(const char *) */
#define JV_DTOR     ((void (*)(void *, int))0x019BDD18)
#define JV_REMOVE   ((void (*)(void *, void *, const char *))0x019BEE88) /* removeMember(key) -> out */
enum { JV_INT = 1, JV_UINT = 2, JV_STRING = 4, JV_ARRAY = 6, JV_OBJECT = 7 };

static uint8_t jt(const void *v) { return v ? ((const uint8_t *)v)[8] : 0; }
static const char *jstr(const void *v) { return jt(v) == JV_STRING ? *(const char *const *)v : 0; }
static int jint(const void *v, int32_t *out)
{
    const int32_t x = *(const int32_t *)v;
    if (jt(v) == JV_INT || (jt(v) == JV_UINT && x >= 0)) { *out = x; return 1; }
    return 0;
}
static void set_str(void *obj, const char *key, const char *s)
{
    uint32_t t[4];
    JV_FROM_STR(t, s); JV_ASSIGN(JV_KEY(obj, key), t); JV_DTOR(t, 2);
}
static void set_int(void *slot, int v)
{
    uint32_t t[4];
    JV_FROM_INT(t, v); JV_ASSIGN(slot, t); JV_DTOR(t, 2);
}
static void drop(void *obj, const char *key)
{
    if (jt(JV_CGET(obj, key)) == 0) return;
    uint32_t t[4];
    JV_REMOVE(obj, t, key); JV_DTOR(t, 2);
}
static void set_array(void *obj, const char *key, const int16_t *v, int n)   /* a fresh array of n ints */
{
    drop(obj, key);
    void *a = JV_KEY(obj, key);
    for (int i = 0; i < n; i++) set_int(JV_IDX(a, (unsigned)i), v[i]);
}
static int is(const char *s, const char *lit) { return s && ob_eq(s, lit); }

static void kit(void *json, void *op)
{
    if (!is(jstr(JV_CGET(json, "type")), "dbox")) return;
    int32_t mark = 0;
    if (!jint(JV_CGET(op, "mark"), &mark)) mark = 0;
    const char *saved = od_from_opus(mark, jstr(JV_CGET(op, "engine")));
    if (!saved) return;
    set_str(json, "type", saved);
    drop(op, "mark");
    drop(op, "engine");
}
static void lfo(void *json, void *op)
{
    const char *name = jstr(JV_CGET(op, "lfo_type"));
    if (!name || !is(jstr(JV_CGET(json, "lfo_type")), "midi")) return;
    static int16_t p[64], rec[64], w[8];                           /* (the KeyHandler and boot threads: never both) */
    int n = 0;
    const void *a = JV_CGET(op, "lfo_params");
    if (jt(a) == JV_ARRAY) {
        n = (int)JV_SIZE(a);
        if (n > 64) n = 64;
        for (int i = 0; i < n; i++) {
            int32_t v;
            p[i] = jint(JV_IDX((void *)a, (unsigned)i), &v) && v >= -32768 && v <= 32767 ? (int16_t)v : -32768;
        }
    }
    uint32_t id;
    const char *saved = ol_from_opus(name, p, n, w, rec, &id);
    if (!saved) return;
    set_str(json, "lfo_type", saved);
    set_array(json, "lfo_params", w, 8);
    drop(json, "lfo_rec");
    void *m = JV_KEY(json, "lfo_rec");
    set_int(JV_KEY(m, "id"), (int)id);
    set_array(m, "p", rec, 64);
    drop(op, "lfo_type");
    drop(op, "lfo_active");
    drop(op, "lfo_params");
}
static void effect(void *json)
{
    const char *name = jstr(JV_CGET(json, "fx_type"));
    const void *a = JV_CGET(json, "fx_params");
    if (!name || jt(a) != JV_ARRAY || JV_SIZE(a) != 8) return;
    int16_t w[8];
    for (int i = 0; i < 8; i++) {
        int32_t v;
        if (!jint(JV_IDX((void *)a, (unsigned)i), &v) || v < -32768 || v > 32767) return;
        w[i] = (int16_t)v;
    }
    const char *saved = ox_from_opus(name, w);
    if (!saved) return;
    if (!ob_eq(saved, name)) set_str(json, "fx_type", saved);
    void *pa = JV_KEY(json, "fx_params");
    for (int i = 0; i < 8; i++) set_int(JV_IDX(pa, (unsigned)i), w[i]);
}

void kn_foreign_sound(void *json)
{
    if (jt(json) != JV_OBJECT) return;
    if (jt(JV_CGET(json, "opus")) == JV_OBJECT) {
        void *op = JV_KEY(json, "opus");
        kit(json, op);
        lfo(json, op);
    }
    effect(json);
}
