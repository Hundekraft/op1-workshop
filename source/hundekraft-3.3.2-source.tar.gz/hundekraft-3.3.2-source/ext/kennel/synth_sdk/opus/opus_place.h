/*
 * A page placed inside the panel (opus_quirk.c OQ_PLACE): the page is laid out for the panel's rows - OQ_SHRINK and
 * placed OQ_INSET pixels in from the left, so its left edge clears the unit's glass and its right edge stays where
 * it was (owner 2026-11-18: dimension's own 2 px at the right looked right on the unit; 4 / 4 gave 4 / 6). Only the
 * horizontal direction is inset; the columns scale with the rows (rows / 2 of the smaller page) from the top, as the
 * page's own layout does.
 *
 * Every path a page draws by takes the same placement:
 *   - R246's raster (lines, paths, text, SVG art) through the screen matrix at 0x01DE5E68, swapped for the page's draw:
 *     unit (x, y) -> memory row (rows - OQ_INSET) - s' x, column s' y, s' = (rows - OQ_SHRINK) / 320 in Q10;
 *   - the page's own pixels (opus_page_pixels, opus_page_keep): rows - OQ_SHRINK rows, the frame OQ_ROW_OFF memory
 *     rows on, so its pixel x lands on memory row (rows - OQ_INSET - 1) - x: the same pixel the matrix gives unit x / s'.
 * Pure functions here (host test synth_sdk/harness/opus_place_test.c); the swap and the hooks are in opus_quirk.c.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef OPUS_PLACE_H
#define OPUS_PLACE_H
#include <stdint.h>

#define OQ_INSET  4                         /* pixels the page moves in from the left */
#define OQ_SHRINK 4                         /* rows the page is laid out short of the panel's (its right edge: + INSET) */
#define OQ_ROW_OFF (OQ_SHRINK - OQ_INSET)   /* memory rows its own pixels start on (pixel x -> rows - INSET - 1 - x) */

/* m: R246's screen matrix, rows: the panel's rows (op1_panel_rows). -> the page's rows (rows - OQ_SHRINK) and in out
 * the matrix that places it; 0 (out untouched) when m is not R246's form for those rows, or the rows are no panel's */
static inline int oq_place_m(const int32_t *m, int rows, int32_t *out)
{
    const int32_t s = m[3];
    if (rows != 400 && rows != 376 && rows != 320) return 0;
    if (m[0] || m[1] != -s || m[2] || m[4] || m[5] || m[6] || m[8] != 1024 || m[7] != 320 * s
        || ((m[7] + 1023) >> 10) != rows)
        return 0;
    const int pr = rows - OQ_SHRINK;
    const int32_t sp = (pr * 1024 + 160) / 320;                 /* the page's scale, rounded */
    for (int i = 0; i < 9; i++) out[i] = m[i];
    out[1] = -sp;
    out[3] = sp;
    out[7] = (rows - OQ_INSET) * 1024;                          /* unit x 0 -> the boundary OQ_INSET pixels in */
    return pr;
}

#endif
