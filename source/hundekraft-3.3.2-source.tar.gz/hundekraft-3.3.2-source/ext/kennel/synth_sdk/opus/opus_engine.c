/*
 * Opus engines as kennel synth engines (Opus bridge phase 3, opus.h). opus_engine_add makes one kennel engine entry per
 * Opus engine and registers it under its saved name (kn_foreign_add); the entry's callbacks are trampolines stamped per
 * type (kennel's engine callbacks carry only the voice object), so a type number picks the record.
 *
 * Voices: kennel's voice object (0xFFB00000 + 0x24 v, op1_voice_index) picks a state block of `voice` bytes from the
 * arena (6 a type; OPUS_ENGINE_OS_VOICES engines get the voice object itself). init(state, v) runs on a voice's first
 * note after registration and again when that voice's next note comes from another slot or another sound selector than
 * the one it was built for (kennel has no voice-rebuild callback: R246 rebuilds voices at instrument, slot and sound
 * changes, which this catches at the next note). release = note_off with the last knobs that voice heard.
 * render(state, out, par, OP1_PITCH_INC): par = kennel's eight words with knob 4 replaced by the engine's mark (the
 * Opus core's knob 4), pitch R246's per-sample phase step at 88.2 kHz (the same contract on both cores).
 *
 * Envelope (kit OPUS_ENGINE_OWN_ENVELOPE): the flag with `finished` -> KN_FLAG_OWN_ENV (finished asked once a block);
 * the flag without it (an older plugin) -> KN_FE_NEUTRAL_ENV (the stock envelope held neutral); no flag -> the
 * sound's T2 envelope as any engine. OPUS_ENGINE_OWN_LFO -> KN_FE_OWN_LFO. `block` -> KN_FLAG_SUM (the voices' sum,
 * 64 samples at 44.1 kHz, before the synth FX). OPUS_ENGINE_DRUM goes to the drum adapter (opus_drum.c); refused for
 * now (the file rolls back): OPUS_ENGINE_SAMPLE ("needs sample engines").
 *
 * Page: kennel's engine screen slot, an empty SVG (usbout.svg) whose update calls the engine's `page` with the
 * opus_page_* primitives below (texts in R246 text objects, lines through R246's raster). Art (opus_art_*) is not
 * loaded yet ("not ready": engines fall back to their plain page). T1's turns and keys go to turn/key (KN_FLAG_ENG_INPUT,
 * x_input); T2/T4 pages, page_turn/page_key and pushes are not routed yet.
 * Shift layer: shift_knobs[e] == 5 + e for blue and green -> op1_engine_shift (kennel words 5, 6; fine turn); white
 * and orange share kennel's word 7 as two 7-bit fields, so they are left out.
 *
 * Identity: D4 names ("plate" -> "plate_o" when kennel has the name); D5 claimed marks (0x4F01..0x4FFF,
 * 0x5301..0x53FF) map to the registered number when a sound of type "iter" loads (kn_foreign_mark, dispatcher.c
 * patch_type_hook); an unclaimed engine gets the mark the Opus core derives (derived_mark), mapped the same way.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "opus.h"
#include "../op1_synth.h"
#include "../kennel/kn_foreign.h"
#include "../kennel/kn_load.h"
#include "../op1_feature.h"                                 /* OP1_EV_SERVICE */
#include "../kn_mem.h"                                      /* kn_farbss */

void *kn_alloc(uint32_t size);
void kn_log_line(const char *file, const char *msg);

#define OE_VOICES 6

typedef struct {
    const opus_engine *e;
    ob_file *file;
    ob_render_fn render;                    /* e->render, or the file's accelerator (ob_render_for) */
    of_slot slot;                           /* its audio-thread claim this block (opus_fast.c), next to e and file */
    uint32_t moves;                         /* the six voices' bytes when they move into L1 (moves_of), else 0 */
    op1_engine_ext2_t entry;                /* op1_engine_t, finished, block (+ input): the layout the flags say */
    char saved[16];
    int16_t def[4];
    int16_t def2[3];                        /* words 5..7 of a new sound (the factory row's page-2 words, KN_FLAG_PAGE2) */
    int mark;
    uint32_t vbytes;
    uint8_t *state;                         /* OE_VOICES x vbytes */
    int16_t last[OE_VOICES][8];             /* the knobs each voice last heard (release) */
    int16_t built_sel[OE_VOICES];           /* the sound selector and slot a voice was built for; -1 never */
    int8_t built_slot[OE_VOICES];
    int32_t acc[4];                         /* each encoder's turn left under a detent (op1_eng_detents) */
} oe_type;
static oe_type oe[OE_TYPES];
static int n_eng;

int oe_count(void) { return n_eng; }
int oe_file_has(const ob_file *f) { for (int k = 0; k < n_eng; k++) if (oe[k].file == f) return 1; return 0; }
void oe_rollback(int n) { if (n >= 0 && n < n_eng) n_eng = n; }
const void *oe_entry(int k) { return k >= 0 && k < n_eng ? &oe[k].entry : 0; }
const opus_engine *oe_engine(int k) { return k >= 0 && k < n_eng ? oe[k].e : 0; }
void *oe_state(int k, int v) { return k >= 0 && k < n_eng && v >= 0 && v < OE_VOICES ? oe[k].state + v * oe[k].vbytes : 0; }
int oe_vptr_bad(int k)
{
    if (k < 0 || k >= n_eng) return 0;
    const oe_type *t = &oe[k];
    int bad = 0;
    for (int i = 0; i < 2; i++) {
        const uint32_t *w = t->file->vptr[i];
        if (!w || !*w) continue;
        const uint32_t home = (uint32_t)t->state, l1 = 0xFF901840u, n = OE_VOICES * t->vbytes, x = *w;
        const int in_home = x >= home && x < home + n && !((x - home) % t->vbytes);
        const int in_l1 = t->moves && x >= l1 && x < l1 + n && !((x - l1) % t->vbytes);
        bad += !in_home && !in_l1;
    }
    return bad;
}
int oe_mark(int k) { return k >= 0 && k < n_eng ? oe[k].mark : 0; }

#define PITCH ((const uint32_t *)OP1_PITCH_INC)

static inline int vindex(void *self)
{
    int v = op1_voice_index(self);
    return v >= 0 && v < OE_VOICES ? v : 0;
}
/* Fast memory around a voice call (opus_fast.c): the synth partition for the file's leases, and with
 * OPUS_ENGINE_STATE_MOVES the six voices' state too (kept: kennel copies it in and home); -> the voices' base */
#define OPUS_ENGINE_STATE_MOVES 512u
static uint32_t moves_of(const oe_type *t)                     /* at registration (the file's quirk is known then) */
{
    const uint32_t fl = t->e->size >= 68 ? t->e->flags : 0;
    if (fl & OPUS_ENGINE_OS_VOICES) return 0;
    return (fl & OPUS_ENGINE_STATE_MOVES) || (t->file->quirk && (t->file->quirk->flags & OQ_MOVES)) ? OE_VOICES * t->vbytes : 0;
}
static inline uint8_t *enter(oe_type *t, uint32_t *tk)
{
    return of_enter(&t->slot, t->file, OP1_L1_SYNTH, t->state, t->moves, t->moves, tk);
}
static inline void *vstate_at(oe_type *t, uint8_t *base, void *self, int v)
{
    return (t->e->flags & OPUS_ENGINE_OS_VOICES) ? self : base + v * t->vbytes;
}
static inline void knobs(const oe_type *t, const int16_t *params, int16_t *par)
{
    for (int i = 0; i < 8; i++) par[i] = params[i];
    par[4] = (int16_t)t->mark;
}

static void x_note_on(int k, void *self, const int16_t *params)
{
    oe_type *t = &oe[k];
    const int v = vindex(self);
    uint32_t tk;
    void *s = vstate_at(t, enter(t, &tk), self, v);
    const int slot = op1_current_slot() & 7;
    if (t->built_sel[v] != params[4] || t->built_slot[v] != slot) {
        if (t->e->init) t->e->init(s, v);
        t->built_sel[v] = params[4]; t->built_slot[v] = (int8_t)slot;
    }
    knobs(t, params, t->last[v]);
    t->e->note_on(s, t->last[v]);
    of_leave(tk);
}
/* the newest voice's words as it renders them (LFOs in): opus_engine_live (the Opus core's engine_live_words, stamped
 * with R246's block counter 0xFF8016E0; live while at most 3 blocks old). Written by the audio thread under a
 * sequence count (odd while writing), read by any. */
#define BLOCK_COUNT (*(volatile uint32_t *)0xFF8016E0)
static volatile int16_t live_w[8];
static volatile uint32_t live_seq, live_stamp;
static volatile int8_t live_slot = -1, live_type = -1;
static void x_render(int k, void *self, int16_t *out, const int16_t *params)
{
    oe_type *t = &oe[k];
    const int v = vindex(self);
    knobs(t, params, t->last[v]);
    live_seq++;
    for (int i = 0; i < 8; i++) live_w[i] = t->last[v][i];
    live_stamp = BLOCK_COUNT; live_slot = t->built_slot[v]; live_type = (int8_t)k;
    live_seq++;
    uint32_t tk;
    t->render(vstate_at(t, enter(t, &tk), self, v), out, t->last[v], (const unsigned *)PITCH);
    of_leave(tk);
}
static void x_note_off(int k, void *self)
{
    oe_type *t = &oe[k];
    const int v = vindex(self);
    if (!t->e->release) return;
    uint32_t tk;
    t->e->release(vstate_at(t, enter(t, &tk), self, v), t->last[v]);
    of_leave(tk);
}
static int x_finished(int k, void *self)
{
    oe_type *t = &oe[k];
    const int v = vindex(self);
    if (!t->e->finished) return 0;
    uint32_t tk;
    const int r = t->e->finished(vstate_at(t, enter(t, &tk), self, v));
    of_leave(tk);
    return r;
}
/* Turns, keys and pushes (KN_FLAG_ENG_INPUT, the KeyHandler) on T1 and on its own T2 / T4 pages (kennel's page numbers
 * 0, 1, 3 are the kit's): a turn in detents (0 when less than one, as the kit says), a push as the kit's key code
 * 0x3B + encoder. With page_turn / page_key (core 2.31; they come instead of turn / key): a struct opus_page with the
 * sound's eight words (knob 4 the mark) to edit in place; 1 keeps the changed words (never 4) through
 * op1_engine_word_set, as the Opus core keeps them. Else turn(encoder, detents, page) / key(code, pressed, page).
 * 1 takes it; 0 leaves it R246's. */
static const opus_engine *pe(const oe_type *t, int field)      /* page_key (0) / page_turn (1) when the struct has it */
{
    return t->e->size >= 124 && (field ? (const void *)t->e->page_turn : (const void *)t->e->page_key) ? t->e : 0;
}
static int page_call(int k, int page, int turn, int a, int b)
{
    oe_type *t = &oe[k];
    const int slot = op1_current_slot() & 7;
    int16_t *w = (int16_t *)op1_synth_knobs(slot);
    static int16_t par[8];
    static opus_page pg;
    pg.kind = 1; pg.t = (int16_t)(page == OP1_ENG_T2 ? 2 : page == OP1_ENG_T4 ? 4 : 1); pg.where = 0;
    pg.slot = (int16_t)slot; pg.on = 1; pg.n = 8; pg.key = -1; pg.inst = 0; pg.module = t->e;
    for (int i = 0; i < 8; i++) par[i] = pg.live[i] = w[i];
    par[4] = pg.live[4] = (int16_t)t->mark;
    pg.par = par;
    const int took = turn ? t->e->page_turn(&pg, a, b) : t->e->page_key(&pg, a, b);
    if (!took) return 0;
    for (int i = 0; i < 8; i++)
        if (i != 4 && par[i] != w[i]) op1_engine_word_set(&t->entry.ext.voice, i, par[i] < 0 ? 0 : par[i]);
    return 1;
}
static int x_input(int k, int page, int ev, int a, int b)
{
    oe_type *t = &oe[k];
    if (page != OP1_ENG_T1 && page != OP1_ENG_T2 && page != OP1_ENG_T4) return 0;
    if (ev == OP1_ENG_TURN) {
        if ((unsigned)a >= 4u) return 0;
        const int d = op1_eng_detents(&t->acc[a], b);
        if (pe(t, 1)) return page_call(k, page, 1, a, d);
        return t->e->turn && t->e->turn(a, d, page) ? 1 : 0;
    }
    if (ev == OP1_ENG_PUSH) {
        if ((unsigned)a >= 4u) return 0;
        a = 0x3B + a;                                           /* the kit's push codes, blue .. orange */
    } else if (ev != OP1_ENG_KEY) return 0;
    if (pe(t, 0)) return page_call(k, page, 0, a, b);
    return t->e->key && t->e->key(a, b, page) ? 1 : 0;
}
/* the main loop (KN_FLAG_ENG_SERVICE): the file's opus_on_main_pass, once a pass from its first engine type */
static volatile uint8_t in_pass;            /* a main pass runs: the services refuse to store (op1_plugin.h service) */
static void x_service(int k, int ev, int32_t arg)
{
    (void)arg;
    if (ev != OP1_EV_SERVICE || !oe[k].file->main_pass) return;
    for (int j = 0; j < k; j++) if (oe[j].file == oe[k].file) return;
    in_pass = 1;
    oe[k].file->main_pass();
    in_pass = 0;
}
static volatile uint8_t in_block;           /* a voice-sum block runs (opus_skip_dry_input is valid only there) */
static void x_block(int k, int16_t *bus, int fresh)
{
    (void)fresh;
    if (!oe[k].e->block) return;
    in_block = 1;
    uint32_t tk;
    (void)enter(&oe[k], &tk);
    oe[k].e->block(bus);
    of_leave(tk);
    in_block = 0;
}
/* opus_skip_dry_input: this block's dry input left out (amp plays the input itself): kennel's kn_skip_dry, read and
 * cleared by the core right after the block. Outside a block (another thread, a block a thread renders): nothing. */
static void skip_dry(void) { if (in_block) kn_skip_dry = 1; }

/* ---- the page: primitives over R246's text objects and raster ---- */
/* Text: as the Opus core (pagetext page_text_common, text.c text_render), one R246 text object per file and slot
 * (the file's self->slot, 32 slots a file: two files' slot 13 are two objects), made at its first use with that call's
 * place, size and alignment (fixed after it: a later call with another place only draws it where it was made, as the
 * Opus core's), the colour updated whenever it changes. Alignment is R246's own (the text ctor's last argument: 1
 * centre, 2 right). The Opus core's checks: slot 0..31, x 0..319, y >= 0, y + size <= 160, size 6..48. */
#define PT_SLOTS 32
#define PT_POOL 64                                  /* text objects for all files (dx 3, dimension 11, castle, amp 8 ...) */
typedef struct {
    uint8_t t[OP1_TEXT_SIZE] __attribute__((aligned(4)));
    int16_t owner;                                  /* the file's self->slot (-1: the bridge's own title), -2 free */
    uint8_t slot;
    int32_t col;
    char shown[48];                                 /* 47 characters (outatime's shift legend has 40) */
} pt_obj;
static pt_obj ptext[PT_POOL] kn_farbss;
/* pixels the bridge writes itself (dots, a kept still part put back) go into the frame hash as what they are, so a page
 * that does not change can still be skipped (op1_plugin.h "Frame skip"); a page that writes pixels the bridge cannot
 * see (opus_page_pixels, opus_page_put) moves the hash every frame (oa_touched) */
static uint32_t ph;
static uint8_t ph_on;
static void ph_add(uint32_t v) { ph = (ph ^ v) * 0x01000193u; ph_on = 1; }
#define ST_WORDS 0x8000                                         /* 64 KB of runs */
static uint16_t st_buf[ST_WORDS] kn_farbss;
static int32_t st_kept = -1;
static uint32_t st_hash_kept, st_hash;
static uint8_t st_same, st_which;

static int pt_used;
static void *praster;                       /* only inside a page's draw */
static void colour(int id, uint8_t *c)
{
    static const uint8_t pal[6][3] = { { 255, 255, 255 }, { 0, 0, 0 }, { 255, 65, 57 }, { 72, 72, 72 }, { 160, 160, 160 },
                                       { 255, 255, 255 } };
    const uint8_t *p = pal[0];
    uint32_t rgb = 0;
    int own = 0;
    if (id <= -10 && id >= -13) {
        static const uint32_t acc[4] = { 0x6B8EFFu, 0x00EF94u, 0xC8C8FFu, 0xFF4139u };
        rgb = acc[-10 - id]; own = 1;
    } else if (id & 0x01000000) { rgb = (uint32_t)id & 0xFFFFFFu; own = 1; }
    else if (id == 1) p = pal[1];
    else if (id == 2) p = pal[2];
    else if (id == 4) p = pal[3];
    else if (id == 12) p = pal[4];
    if (own) { c[0] = (uint8_t)(rgb >> 16); c[1] = (uint8_t)(rgb >> 8); c[2] = (uint8_t)rgb; }
    else { c[0] = p[0]; c[1] = p[1]; c[2] = p[2]; }
    c[3] = 255;
}
static pt_obj *pt_find(int owner, int slot)
{
    for (int i = 0; i < pt_used; i++) if (ptext[i].owner == owner && ptext[i].slot == slot) return &ptext[i];
    return 0;
}
static void p_text_at(int owner, int slot, int x, int y, int size, int col, const char *s, int align)
{
    static const int32_t identity[9] = { 1024, 0, 0, 0, 1024, 0, 0, 0, 1024 };
    if (!praster || slot < 0 || slot >= PT_SLOTS || !s || (unsigned)x > 319u || y < 0 || y + size > 160 ||
        (unsigned)(size - 6) > 42u) return;
    if ((unsigned)(col + 13) > 3u && (unsigned)col > 19u) col = 14;   /* the Opus core: an unknown id is white */
    pt_obj *o = pt_find(owner, slot);
    if (!o) {
        if (pt_used >= PT_POOL) return;                             /* no room: not drawn (the Opus core: no memory) */
        o = &ptext[pt_used++];
        uint8_t c[4];
        colour(col, c);
        int32_t xq = x << 10;
        oq_text_at(&xq, &y);                                    /* OQ_PLACE: R246's text scales by the panel, not the matrix */
        op1_text_ctor_a(o->t, xq, y, size, c, align);
        o->owner = (int16_t)owner; o->slot = (uint8_t)slot; o->col = col; o->shown[0] = 0;
        op1_text_set(o->t, o->shown);
    } else if (o->col != col) {                                     /* the colour in place (the Opus core: Text +0x6C) */
        colour(col, o->t + 0x6C);
        o->col = col;
        o->shown[0] = 1; o->shown[1] = 0;                           /* set again below: the glyphs take the new colour */
    }
    int i = 0;
    while (s[i] && i < 47 && o->shown[i] == s[i]) i++;
    if ((s[i] && i < 47) || o->shown[i]) {
        for (i = 0; i < 47 && s[i]; i++) o->shown[i] = s[i];
        o->shown[i] = 0;
        op1_text_set(o->t, o->shown);
    }
    op1_text_draw(o->t, praster, identity);
}
static int self_slot(const opl_self *self) { return self ? self->slot : -3; }
static void p_text(opl_self *self, int slot, int x, int y, int size, int col, const char *s) { p_text_at(self_slot(self), slot, x, y, size, col, s, 0); }
static void p_text_r(opl_self *self, int slot, int x, int y, int size, int col, const char *s) { p_text_at(self_slot(self), slot, x, y, size, col, s, 2); }
static void p_text_c(opl_self *self, int slot, int x, int y, int size, int col, const char *s) { p_text_at(self_slot(self), slot, x, y, size, col, s, 1); }
static void seg(int x0, int y0, int x1, int y1, int w_q10, int col)
{
    if (!praster) return;
    uint8_t c[4];
    colour(col, c);
    op1_pt a = { x0 << 10, y0 << 10 }, b = { x1 << 10, y1 << 10 };
    op1_raster_line(praster, &a, &b, w_q10, c);
}
static void p_line(int x0, int y0, int x1, int y1, int col) { seg(x0, y0, x1, y1, 1024, col); }
static void p_frame(int x0, int y0, int x1, int y1, int col)
{
    seg(x0, y0, x1, y0, 1024, col); seg(x1, y0, x1, y1, 1024, col);
    seg(x1, y1, x0, y1, 1024, col); seg(x0, y1, x0, y0, 1024, col);
}
static void p_fill(int x0, int y0, int x1, int y1, int col)
{
    if (y1 < y0) { int t = y0; y0 = y1; y1 = t; }
    for (int y = y0; y <= y1; y++) seg(x0, y, x1, y, 1024, col);
}
static void p_bar(int x0, int y0, int x1, int y1, unsigned value, unsigned max, int col)
{
    p_frame(x0, y0, x1, y1, 4);
    if (!max) return;
    if (value > max) value = max;
    int x = x0 + (int)(((uint32_t)(x1 - x0) * value) / max);
    if (x > x0) p_fill(x0, y0, x, y1, col);
}
/* a dot (the Opus core's page_disc, paths.c): a disc (filled) or a ring one unit wide (hollow) of radius r units,
 * centre and radius scaled to the panel in 1/16 pixels, each pixel covered by its distance from the centre (or from the
 * ring) and blended over what is there. The Opus core's checks: r 0..40, the dot inside x 1..318, y 1..158. */
static void p_dot(int x, int y, int r, int filled, int col)
{
    if (!praster || (unsigned)r > 40u || x <= r || x + r > 318 || y <= r || y + r > 158) return;
    int off;
    const int rows = oq_page_rows(praster, &off);               /* OQ_PLACE: the placed page's rows, moved in by off */
    uint16_t *fb = *(uint16_t **)praster;
    if (rows <= 0 || !fb) return;
    uint8_t c[4];
    colour(col, c);
    const uint32_t c16 = (uint32_t)(c[0] >> 3) << 11 | (uint32_t)(c[1] >> 2) << 5 | (uint32_t)(c[2] >> 3);
    const uint32_t col32 = ((c16 << 16) + c16) & 0x07e0f81fu;
    const int cxs = (x << 4) * rows / 320, cys = (y << 4) * rows / 320, rs = (r << 4) * rows / 320, ext = rs + 0x18;
    const int x0 = (cxs - ext) >> 4, x1 = (cxs + ext) >> 4, y0 = (cys - ext) >> 4, y1 = (cys + ext) >> 4;
    for (int px = x0; px <= x1; px++) {
        const int dx = (px << 4) + 8 - cxs;
        if (px < 0 || px >= rows) continue;
        for (int py = y0; py <= y1; py++) {
            if (py < 0 || py >= rows / 2) continue;
            const int dy = (py << 4) + 8 - cys;
            uint32_t d2 = (uint32_t)(dx * dx + dy * dy), bit = 1u << 30, root = 0;
            while (bit > d2) bit >>= 2;
            while (bit) {                                       /* integer square root */
                const uint32_t t = root + bit;
                root >>= 1;
                if (d2 >= t) { d2 -= t; root += bit; }
                bit >>= 2;
            }
            int cover;
            if (!filled) { int d = (int)root - rs; if (d < 0) d = -d; cover = (0x10 - d) << 1; }
            else cover = (rs + 8 - (int)root) << 1;
            if (cover <= 0) continue;
            if (cover > 0x20) cover = 0x20;
            uint16_t *p = &fb[((rows - 1 - px + off) << 8) + py];
            uint32_t acc = col32 * (uint32_t)cover;
            if (*p) acc += (uint32_t)(0x20 - cover) * ((((uint32_t)*p << 16) + *p) & 0x07e0f81fu);
            acc = (acc >> 5) & 0x07e0f81fu;
            *p = (uint16_t)(acc | acc >> 16);
        }
    }
    ph_add((uint32_t)x | (uint32_t)y << 9 | (uint32_t)r << 18 | (uint32_t)!!filled << 24);   /* the frame hash */
    ph_add((uint32_t)col);
}
static void p_stroke_line(int x0, int y0, int x1, int y1, int w, int col)   /* units x 256 */
{
    if (!praster) return;
    uint8_t c[4];
    colour(col, c);
    op1_pt a = { x0 << 2, y0 << 2 }, b = { x1 << 2, y1 << 2 };
    op1_raster_line(praster, &a, &b, w << 2, c);
}
/* a path (opus_page_path / move / line_to / stroke): lines only (curves are not imported by any file the bridge loads
 * yet: a curve_to goes straight to its end), stroked through R246's raster line with round joins of its width; alpha
 * is taken as opaque, caps and joins as round. Places in units x 256, as opus_page_stroke_line. */
#define PATH_N 256
static int32_t path_x[PATH_N], path_y[PATH_N];
static uint8_t path_mv[PATH_N];
static int path_n;
static void p_path(void) { path_n = 0; }
static void path_pt(int x, int y, int mv)
{
    if (path_n >= PATH_N) return;                               /* past the room: dropped, as the kit says */
    path_x[path_n] = x; path_y[path_n] = y; path_mv[path_n] = (uint8_t)mv; path_n++;
}
static void p_move(int x, int y) { path_pt(x, y, 1); }
static void p_line_to(int x, int y) { path_pt(x, y, path_n == 0); }
/* a cubic from the last point: 8 straight pieces (de Casteljau at t = i/8, integers) */
static void p_curve_to(int x1, int y1, int x2, int y2, int x, int y)
{
    if (!path_n) { path_pt(x, y, 1); return; }
    const int32_t x0 = path_x[path_n - 1], y0 = path_y[path_n - 1];
    for (int i = 1; i <= 8; i++) {
        const int32_t t = i, u = 8 - i;                           /* /512 = /8^3 */
        const int32_t a = u * u * u, b = 3 * u * u * t, c = 3 * u * t * t, d = t * t * t;
        path_pt((int)((a * x0 + b * x1 + c * x2 + d * x) / 512), (int)((a * y0 + b * y1 + c * y2 + d * y) / 512), 0);
    }
}
static void p_close(void)                                         /* a line back to the subpath's first point */
{
    int s = path_n - 1;
    while (s > 0 && !path_mv[s]) s--;
    if (path_n > 1 && s >= 0) path_pt(path_x[s], path_y[s], 0);
}
/* the path filled, each subpath closed, even-odd, row by row through R246's raster line (alpha taken as opaque) */
static void seg(int x0, int y0, int x1, int y1, int w_q10, int col);
static void p_fill_path(int col, int alpha)
{
    if (!praster || alpha <= 0 || path_n < 2) return;
    int32_t lo = path_y[0], hi = path_y[0];
    for (int i = 1; i < path_n; i++) { if (path_y[i] < lo) lo = path_y[i]; if (path_y[i] > hi) hi = path_y[i]; }
    for (int32_t row = lo >> 8; row <= hi >> 8; row++) {
        const int32_t y = (row << 8) + 128;
        int32_t xs[32];
        int n = 0;
        for (int i = 0, s = 0; i < path_n; i++) {
            const int end = i + 1 == path_n || path_mv[i + 1];   /* the subpath's last point: an edge back to its start */
            const int j = end ? s : i + 1;
            const int32_t ya = path_y[i], yb = path_y[j];
            if ((ya <= y && yb > y) || (yb <= y && ya > y)) {
                if (n < 32) xs[n++] = path_x[i] + (int32_t)(((int64_t)(y - ya) * (path_x[j] - path_x[i])) / (yb - ya));
            }
            if (end) s = i + 1;
        }
        for (int a = 1; a < n; a++) for (int b = a; b > 0 && xs[b - 1] > xs[b]; b--) { int32_t t = xs[b]; xs[b] = xs[b - 1]; xs[b - 1] = t; }
        for (int a = 0; a + 1 < n; a += 2) {
            const int xa = (xs[a] + 128) >> 8, xb = (xs[a + 1] + 128) >> 8;
            if (xb >= xa) seg(xa, row, xb, row, 1024, col);
        }
    }
}
static void p_stroke(int width, int col, int alpha, int cap, int join)
{
    (void)alpha; (void)cap; (void)join;
    if (!praster || alpha <= 0) return;
    uint8_t c[4];
    colour(col, c);
    for (int i = 1; i < path_n; i++) {
        if (path_mv[i]) continue;
        op1_pt a = { path_x[i - 1] << 2, path_y[i - 1] << 2 }, b = { path_x[i] << 2, path_y[i] << 2 };
        op1_raster_line(praster, &a, &b, width << 2, c);
    }
}

void *oe_page_raster(void) { return praster; }                  /* opus_art.c: keep / put */
static uint32_t page_frames;
/* a page's draw: its page art (opus_page_art) behind, then its page with what it shows (opus_page_now). When it wrote
 * pixels itself (opus_page_pixels, opus_page_put) the frame hash moves, so frame skip never keeps a stale picture. */
void oe_page_frame(void *scr, const ob_file *f, int which, void (*fn)(void))
{
    praster = op1_raster();
    oa_in_page = 1; oa_touched = 0;
    ph = 0x811c9dc5u; ph_on = 0; st_which = (uint8_t)which;
    oq_page_begin(f, praster);                                  /* OQ_PLACE files: placed in (opus_quirk.c) */
    if (f) oa_page_art_draw(f, which);
    fn();
    oq_page_end();
    oa_in_page = 0;
    praster = 0;
    oa_page_clear();
    if (oa_touched) op1_screen_hash(scr, ++page_frames);
    else if (ph_on) op1_screen_hash(scr, ph);
}
static void page_draw(int k, void *scr, int dt, int which)       /* which: 0 T1, 1 T2, 3 T4 */
{
    op1_screen_draw(scr, dt);
    if (k >= n_eng) return;
    const opus_engine *e = oe[k].e;
    void (*fn)(void) = which == 1 ? e->page_t2 : which == 3 ? (e->size >= 72 ? e->page_t4 : 0) : e->page;
    if (!fn) return;
    const int slot = OP1_SCREEN_SLOT & 7;
    oa_page_set(1, which + 1, 0, slot, op1_synth_knobs(slot), oe[k].mark, 0, e);
    oe_page_frame(scr, oe[k].file, which, fn);
}
static void page(int k, void *scr, int dt) { page_draw(k, scr, dt, 0); }
void oe_page_run(void (*fn)(void)) { praster = op1_raster(); st_which = 7; oa_in_page = 1; fn(); oa_in_page = 0; praster = 0; }
/* a line of text centred on the page (a sequencer's page without its own drawing) */
void oe_page_title(const char *s) { praster = op1_raster(); p_text_at(-1, 0, 160, 76, 12, 12, s, 1); praster = 0; }
/* the frame a page draws into (opus_page_pixels; inside a page's draw only): R246's raster is the kit's frame, pixel
 * (x, y) at [256 (rows - 1 - x) + y], RGB565, rows from the screen matrix (op1_panel_rows) */
static void *p_pixels(int *rows)
{
    if (!praster) { if (rows) *rows = 0; return 0; }
    oa_touched = 1;                                             /* it may write pixels itself */
    int off;                                                    /* OQ_PLACE: its rows, OQ_ROW_OFF memory rows on */
    const int n = oq_page_rows(praster, &off);
    if (rows) *rows = n;
    return (uint16_t *)*(void **)praster + (off << 8);
}
/* A page's still part (the Opus core's opus_page_still / _still_done, pages.c): the page asks with a key of what its
 * still part shows; the key with the page (file, T page) and the panel rows makes a hash. When two frames in a row had
 * the same hash, still_done keeps the whole picture drawn so far (the art and the still part) as runs of its lit pixels
 * (oa_keep: never in a frame-skip record frame, whose raster is not the picture, op1_raster_live); a later frame with
 * that hash gets them put back and the answer 1, and the page draws only its moving part. The put pixels go into the
 * frame hash as the hash itself, so a page that stays the same is skipped by the core's frame skip as any other. One
 * kept picture for all pages (the Opus core keeps one too); a page that never calls still_done keeps nothing. */
static int p_still(opl_self *self, unsigned key)
{
    if (!praster || !self) return 0;
    uint32_t h = (key ^ 0x811c9dc5u) * 0x01000193u;
    h = ((h ^ (uint32_t)self->slot) * 0x01000193u ^ st_which) * 0x01000193u;
    h = (h ^ (uint32_t)op1_panel_rows(praster)) * 0x01000193u;
    if (st_kept >= 0 && st_hash_kept == h) {
        oa_put(st_buf, st_kept);
        ph_add(h);
        st_hash = h;
        return 1;
    }
    st_same = st_hash == h;
    st_hash = h;
    return 0;
}
static void p_still_done(opl_self *self)
{
    if (!praster || !self || !st_same) return;
    st_same = 0;
    int off;
    const int rows = oq_page_rows(praster, &off);
    st_kept = oa_keep(st_buf, ST_WORDS, 0, rows - 1, 0, rows / 2 - 1);
    st_hash_kept = st_hash;
}
static void page_init(int k, void *scr)
{
    (void)scr;
    if (k >= n_eng || oe[k].e->size < 100) return;
    for (int i = 0; i < 2; i++)
        if (oe[k].e->shift_knobs[i] == 5 + i) op1_engine_shift(&oe[k].entry.ext.voice, i, 1);
}

/* ---- trampolines ---- */
#define TR(k) \
    static void on##k(void *s, const int16_t *p) { x_note_on(k, s, p); } \
    static void re##k(void *s, int16_t *o, const int16_t *p) { x_render(k, s, o, p); } \
    static void of##k(void *s) { x_note_off(k, s); } \
    static int fi##k(void *s) { return x_finished(k, s); } \
    static void bl##k(int16_t *b, int f) { x_block(k, b, f); } \
    static void pi##k(void *scr) { page_init(k, scr); } \
    static void up##k(void *scr, int dt) { page(k, scr, dt); } \
    static void u2##k(void *scr, int dt) { page_draw(k, scr, dt, 1); } \
    static void u4##k(void *scr, int dt) { page_draw(k, scr, dt, 3); } \
    static void ni##k(void *scr) { (void)scr; } \
    static int in##k(int pg, int ev, int a, int b) { return x_input(k, pg, ev, a, b); } \
    static void sv##k(int ev, int32_t arg) { x_service(k, ev, arg); }
TR(0) TR(1) TR(2) TR(3) TR(4) TR(5) TR(6) TR(7)
static void (*const t_on[OE_TYPES])(void *, const int16_t *) = { on0, on1, on2, on3, on4, on5, on6, on7 };
static void (*const t_re[OE_TYPES])(void *, int16_t *, const int16_t *) = { re0, re1, re2, re3, re4, re5, re6, re7 };
static void (*const t_of[OE_TYPES])(void *) = { of0, of1, of2, of3, of4, of5, of6, of7 };
static int (*const t_fi[OE_TYPES])(void *) = { fi0, fi1, fi2, fi3, fi4, fi5, fi6, fi7 };
static void (*const t_bl[OE_TYPES])(int16_t *, int) = { bl0, bl1, bl2, bl3, bl4, bl5, bl6, bl7 };
static int (*const t_in[OE_TYPES])(int, int, int, int) = { in0, in1, in2, in3, in4, in5, in6, in7 };
static void (*const t_sv[OE_TYPES])(int, int32_t) = { sv0, sv1, sv2, sv3, sv4, sv5, sv6, sv7 };
static const op1_screen_t t_screen[OE_TYPES] = { { pi0, up0 }, { pi1, up1 }, { pi2, up2 }, { pi3, up3 }, { pi4, up4 },
    { pi5, up5 }, { pi6, up6 }, { pi7, up7 } };
static const op1_screen_t t_screen2[OE_TYPES] = { { ni0, u20 }, { ni1, u21 }, { ni2, u22 }, { ni3, u23 }, { ni4, u24 },
    { ni5, u25 }, { ni6, u26 }, { ni7, u27 } };                 /* own T2 pages (page_t2) */
static const op1_screen_t t_screen4[OE_TYPES] = { { ni0, u40 }, { ni1, u41 }, { ni2, u42 }, { ni3, u43 }, { ni4, u44 },
    { ni5, u45 }, { ni6, u46 }, { ni7, u47 } };                 /* own T4 pages (page_t4) */

/* ---- names (D4) ---- */
static const char *const kennel_eng[] = {                       /* names kennel has (its engines, loaded or not, and */
    "amp", "outatime", "dx7", "sid", "strum", "supersaw", "wavetable", "vox", "taffy",
    "vapora", "windwood", "gin", "oxbow", "platter", "aether", "arc", "bloodmoon", "blot", "brassophone",
    "chimera", "dddd", "drift", "elg", "eva", "fmbell", "granular", "hollowsaint", "juni", "ludwig", "mbira", "mixtur",
    "moai", "monolit", "pew", "pinboard", "reactor", "snap",
    "cluster", "digital", "dna", "dsynth", "fm", "iter", "phase", "pulse", "sampler", "string", "voltage", "drwave",
    "dbox", 0 };                                                /* R246's own) */
static int name_ok(const char *s)
{
    int n = 0;
    for (; s[n]; n++) {
        const char c = s[n];
        if (n >= 13 || !((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == ' ' || c == '_' || c == '+' || c == '-'))
            return 0;
    }
    return n > 0;
}
const char *oe_saved_name(const char *name, char *out)
{
    if (!name_ok(name)) return 0;
    int clash = kn_plugin_order(0, name) != 0;
    for (int i = 0; kennel_eng[i] && !clash; i++) clash = ob_eq(kennel_eng[i], name);
    char *e = ob_cat(out, name);
    if (clash) ob_cat(e, "_o");
    return out;
}

/* ---- D5: a claimed mark -> the registered number, when a sound of type "iter" loads ---- */
static int claimed(int m) { return (m >= 0x4F01 && m <= 0x4FFF) || (m >= 0x5301 && m <= 0x53FF); }
int kn_foreign_mark(int mark)
{
    for (int k = 0; k < n_eng; k++)
        if (mark > 0 && oe[k].mark == mark) return kn_plugin_order(0, oe[k].saved);
    return 0;
}

/* ---- registration (from opl_init) ---- */
/* an Opus-saved sound's engine data (kn_foreign.h kn_foreign_data): "opus": {"engine_data": "<hex>"} (the Opus core
 * writes it so, up to 256 bytes), for a claimed mark or the selector of a bridge engine */
int kn_foreign_mark(int mark);
int kn_foreign_data(int mark, const char **member, const char **key)
{
    *member = "opus"; *key = "engine_data";                     /* (always: the member is kept) */
    int n = mark > 0 ? kn_foreign_mark(mark) : 0;                   /* (a mark), else a selector: */
    if (!n && mark > 0x5300 && mark <= 0x53FF)
        for (int k = 0; k < n_eng; k++) if (kn_plugin_order(0, oe[k].saved) == mark - 0x5300) n = mark - 0x5300;
    return n > 0 ? n : 0;
}
/* An unclaimed engine's mark as the Opus core derives it (D5; learned from its engine registry, our own code): FNV-1a
 * over the plugin's id, ':' and the engine's name; x = h ^ h >> 15; the low 15 bits, moved by 0x2100 when bits 8..14
 * are 0 or the high byte would be 0x4F or 0x53 (the claimed ranges). 0x0100..0x7FFF, never a claimed value. */
static int derived_mark(const char *id, const char *name)
{
    uint32_t h = 0x811C9DC5u;
    for (const char *p = id; p && *p; p++) h = (h ^ (uint8_t)*p) * 0x01000193u;
    h = (h ^ (uint8_t)':') * 0x01000193u;
    for (const char *p = name; *p; p++) h = (h ^ (uint8_t)*p) * 0x01000193u;
    const uint32_t x = h ^ (h >> 15);
    int m = (int)(x & 0x7FFF);
    if (!(x & 0x7F00) || (m >> 8) == 0x4F || (m >> 8) == 0x53) m ^= 0x2100;
    return m;
}
static int inside(const ob_file *f, const void *p) { return !p || ob_inside(f, p); }
int opus_engine_add(opl_self *self, const opus_engine *e)
{
    ob_file *f = ob_cur;
    if (!f || self != &f->self) return -4;
    const char *why = 0;
    char m[80];
    if (!e || !ob_inside(f, e) || e->size < 60) why = "a bad engine struct";
    else if (e->size >= 68 && (e->flags & OPUS_ENGINE_DRUM)) {  /* a drum engine (opus_drum.c): no note_on needed */
        if (!ob_inside(f, e->name) || !e->render || !inside(f, (const void *)e->init) || !inside(f, (const void *)e->render) ||
            !inside(f, (const void *)e->note_on) || !inside(f, (const void *)e->page) ||
            (e->size >= 76 && !inside(f, (const void *)e->finished)) ||
            (e->size >= 104 && e->keys && !ob_inside(f, e->keys)) ||
            (e->size >= 108 && !inside(f, (const void *)e->note_key)) ||
            (e->size >= 112 && !inside(f, (const void *)e->group)) || (e->size >= 116 && !inside(f, (const void *)e->choke))) {
            kn_log_line(f->self.id, "a callback outside its image");
            return -1;
        }
        char saved[16];
        if (!oe_saved_name(e->name, saved)) { kn_log_line(f->self.id, "a bad engine name"); return -1; }
        const int mk = e->size >= 84 ? e->mark : 0;
        return od_add(f, e, saved, claimed(mk) ? mk : derived_mark(f->self.id, e->name));
    }
    else if (n_eng >= OE_TYPES) why = "too many engine types";
    else if (!ob_inside(f, e->name) || !e->note_on || !e->render || !inside(f, (const void *)e->init) ||
             !inside(f, (const void *)e->note_on) || !inside(f, (const void *)e->release) ||
             !inside(f, (const void *)e->render) || !inside(f, (const void *)e->block) || !inside(f, (const void *)e->page) ||
             !inside(f, (const void *)e->turn) || !inside(f, (const void *)e->key))
        why = "a callback outside its image";
    else if (e->size >= 76 && !inside(f, (const void *)e->finished)) why = "a callback outside its image";
    else if (!inside(f, (const void *)e->page_t2) || (e->size >= 72 && !inside(f, (const void *)e->page_t4)) ||
             (e->size >= 124 && (!inside(f, (const void *)e->page_key) || !inside(f, (const void *)e->page_turn))))
        why = "a callback outside its image";
    if (why) { kn_log_line(f->self.id, why); return -1; }
    const uint32_t fl = e->size >= 68 ? e->flags : 0;
    m[0] = 0;
    if (fl & OPUS_ENGINE_SAMPLE) why = "needs sample engines";
    else if (e->voice > 4096) why = "a voice needs more memory than this core gives";
    if (why) { ob_cat(ob_cat(ob_cat(m, e->name), ": "), why); kn_log_line(f->self.id, m); return -1; }
    oe_type *t = &oe[n_eng];
    if (!oe_saved_name(e->name, t->saved)) { kn_log_line(f->self.id, "a bad engine name"); return -1; }
    t->vbytes = (fl & OPUS_ENGINE_OS_VOICES) ? 0 : (e->voice + 31) & ~31u;
    t->state = 0;
    if (t->vbytes) {
        uint8_t *a = kn_alloc(OE_VOICES * t->vbytes + 32);
        if (!a) { kn_log_line(f->self.id, "plugin memory full"); return -2; }
        t->state = (uint8_t *)(((uint32_t)a + 31) & ~31u);
    }
    t->e = e; t->file = f;
    t->render = ob_render_for(f, (ob_render_fn)e->render);
    t->slot.c.f = 0; t->slot.c.base = 0; t->slot.ret = 0; t->slot.tick = 0;
    t->moves = moves_of(t);
    const int mk = e->size >= 84 ? e->mark : 0;
    for (int v = 0; v < OE_VOICES; v++) { t->built_sel[v] = -1; t->built_slot[v] = -1; }
    for (int i = 0; i < 4; i++) t->def[i] = e->knobs[i] < 0 ? 0 : e->knobs[i];
    /* a new sound's words 5..7: the engine's knobs[5..7] (clamped at 0, as the Opus core builds a new sound), through the
     * factory row's page-2 words (KN_FLAG_PAGE2: for an engine only the row; 0 there is a real value, not "unset") */
    for (int i = 0; i < 3; i++) t->def2[i] = e->knobs[5 + i] < 0 ? 0 : e->knobs[5 + i];
    const int k = n_eng;
    const int own_env = (fl & OPUS_ENGINE_OWN_ENVELOPE) && e->size >= 76 && e->finished;
    t->entry.ext.voice.note_on = t_on[k];
    t->entry.ext.voice.render = t_re[k];
    t->entry.ext.voice.note_off = t_of[k];
    for (int i = 0; i < 4; i++) t->entry.ext.voice.press[i] = OP1_PRESS_NONE;
    t->entry.ext.finished = own_env ? t_fi[k] : 0;
    t->entry.ext.block = e->block ? t_bl[k] : 0;
    /* its own T2 page (page_t2: kennel's t2_page needs the own envelope; without it the stock T2 page stays) and T4
     * page (page_t4); turns, keys and pushes go to them (x_input) */
    const int t2 = own_env && e->page_t2, t4 = e->size >= 72 && e->page_t4;
    t->entry.ext.t2 = t2 ? &t_screen2[k] : 0;
    t->entry.t4 = t4 ? &t_screen4[k] : 0;
    t->entry.service = t_sv[k];                                 /* opus_on_main_pass (x_service) */
    const int input = e->turn || e->key || (e->size >= 124 && (e->page_key || e->page_turn));   /* (x_input) */
    t->entry.input = input ? t_in[k] : 0;
    for (int i = 0; i < 4; i++) t->acc[i] = 0;
    uint32_t kf = KN_FLAG_PAGE2 | (own_env ? KN_FLAG_OWN_ENV : 0u) | (t2 ? KN_FLAG_T2_PAGE : 0u) | (t4 ? KN_FLAG_T4_PAGE : 0u) | (e->block ? KN_FLAG_SUM : 0u) | (input ? KN_FLAG_ENG_INPUT : 0u) |
                  KN_FLAG_ENG_SERVICE;
    uint16_t extra = (uint16_t)(((fl & OPUS_ENGINE_OWN_ENVELOPE) && !own_env ? KN_FE_NEUTRAL_ENV : 0u) |
                                ((fl & OPUS_ENGINE_OWN_LFO) ? KN_FE_OWN_LFO : 0u));
    kn_foreign_desc d = { 0, 1, extra, kf, t->saved, &t->entry, &t_screen[k], "usbout.svg", t->def, t->def2 };
    const char *err = kn_foreign_add(&d);
    if (err) {
        ob_cat(ob_cat(ob_cat(m, t->saved), ": "), err);
        kn_log_line(f->self.id, m);
        return -3;
    }
    t->mark = claimed(mk) ? mk : derived_mark(f->self.id, e->name);   /* the mark the Opus core gives it (D5) */
    n_eng++;
    {
        char *p = ob_cat(ob_cat(m, "engine "), t->saved);
        p = ob_num(ob_cat(p, " voice "), e->voice);
        p = ob_num(ob_cat(p, " flags "), fl);
        p = ob_num(ob_cat(p, " mark "), (uint32_t)t->mark);
        if (own_env) p = ob_cat(p, " own-env");
        if (extra & KN_FE_NEUTRAL_ENV) p = ob_cat(p, " neutral-env");
        if (e->block) p = ob_cat(p, " block");
        if (t2) p = ob_cat(p, " t2");
        if (t4) p = ob_cat(p, " t4");
        if (e->size >= 124 && e->page_turn) p = ob_cat(p, " page_turn");
        if (e->size >= 124 && e->page_key) p = ob_cat(p, " page_key");
        (void)p;
    }
    kn_log_line(f->self.id, m);
    return t->mark;
}

/* ---- the engine services (opus_engine_*) ---- */
static int cur_type(void)                                       /* the current synth slot's engine type, or -1 */
{
    const int16_t *w = op1_synth_knobs(op1_current_slot());
    const int n = w[4] - OP1_ENGINE_MAGIC;
    if (n <= 0) return -1;
    for (int k = 0; k < n_eng; k++) if (kn_plugin_order(0, oe[k].saved) == n) return k;
    return -1;
}
/* opus_engine_live: the current slot's words as its newest voice renders them (an LFO's moves in) when that voice
 * rendered in the last 3 blocks and plays this slot's engine, else the stored words; 1 when live. opus_engine_knobs:
 * the same words, 1 when the slot's sound is a bridged engine (the Opus core's services.c). Knob 4 is the mark. */
static int e_live(int16_t *par)
{
    const int slot = op1_current_slot() & 7;
    const int16_t *w = op1_synth_knobs(slot);
    const int k = cur_type();
    for (int i = 0; i < 8; i++) par[i] = w[i];
    if (k >= 0) par[4] = (int16_t)oe[k].mark;
    if (k < 0) return 0;
    for (int tries = 0; tries < 8; tries++) {
        const uint32_t q = live_seq;
        if (q & 1) continue;
        int16_t c[8];
        for (int i = 0; i < 8; i++) c[i] = live_w[i];
        const int ok = live_type == k && live_slot == slot && BLOCK_COUNT - live_stamp <= 3u;
        if (live_seq != q) continue;
        if (!ok) return 0;
        for (int i = 0; i < 8; i++) par[i] = c[i];
        return 1;
    }
    return 0;
}
static int e_knobs(int16_t *par)
{
    e_live(par);
    return cur_type() >= 0;
}
static int e_knob_set(int k, int value)
{
    const int t = cur_type();
    if (t < 0 || k == 4 || in_pass) return 0;
    return op1_engine_word_set(&oe[t].entry.ext.voice, k, value);
}
static int e_data(void *buf, int max)
{
    const int t = cur_type();
    if (t < 0 || !buf || max <= 0) return 0;
    if (max > 256) max = 256;
    return op1_engine_data(op1_current_slot() & 7, op1_engine_rec_owner(oe[t].saved), buf, max);
}
static int e_data_set(const void *buf, int n)
{
    const int t = cur_type();
    if (t < 0 || n < 0 || n > 256 || in_pass) return 0;
    return kn_engine_data_store_n(op1_current_slot() & 7, oe[t].saved, buf, n, 256);
}
/* opus_engine_sound_name: the current slot's sound name (R246's slot patch, its "name" member: the preset's name as
 * loaded or saved), as the Opus core's (its patch row's name); "" when it has none. -> its length */
#define SLOT_PATCH(s) ((const uint8_t *)0x01DDD7E8 + ((s) & 7) * 0x38 + 4)   /* the synth slots' JSON objects */
#define JV_CGET ((const void *(*)(const void *, const char *))0x019BEB70)
static int e_sound_name(char *buf, int max)
{
    if (!buf || max <= 0) return 0;
    buf[0] = 0;
    if (cur_type() < 0) return 0;
    const uint8_t *v = JV_CGET(SLOT_PATCH(op1_current_slot()), "name");
    const char *n = v && v[8] == 4 ? *(const char *const *)v : 0;   /* a string value */
    int i = 0;
    for (; n && i < max - 1 && n[i]; i++) buf[i] = n[i];
    buf[i] = 0;
    return i;
}
static int fn_held(void) { return op1_fn_held(); }
/* struct opus_clock { short year; unsigned char month, day, hour, minute, second, weekday; }: R246's clock is not
 * routed yet: a fixed date (2026-01-01 00:00:00, a Thursday) */
static void e_clock(void *c)
{
    uint8_t *b = c;
    if (!b) return;
    *(int16_t *)b = 2026; b[2] = 1; b[3] = 1; b[4] = 0; b[5] = 0; b[6] = 0; b[7] = 4;
}

const ob_sym oe_imports[] = {                                   /* merged into the import table (sorted by name) */
    { "opus_clock", (uint32_t)e_clock },
    { "opus_engine_add", (uint32_t)opus_engine_add },
    { "opus_engine_data", (uint32_t)e_data },
    { "opus_engine_data_set", (uint32_t)e_data_set },
    { "opus_engine_knob_set", (uint32_t)e_knob_set },
    { "opus_engine_knobs", (uint32_t)e_knobs },
    { "opus_engine_live", (uint32_t)e_live },
    { "opus_engine_sound_name", (uint32_t)e_sound_name },
    { "opus_fn_held", (uint32_t)fn_held },
    { "opus_page_bar", (uint32_t)p_bar },
    { "opus_page_close", (uint32_t)p_close },
    { "opus_page_curve_to", (uint32_t)p_curve_to },
    { "opus_page_dot", (uint32_t)p_dot },
    { "opus_page_fill", (uint32_t)p_fill },
    { "opus_page_fill_path", (uint32_t)p_fill_path },
    { "opus_page_frame", (uint32_t)p_frame },
    { "opus_page_line", (uint32_t)p_line },
    { "opus_page_line_to", (uint32_t)p_line_to },
    { "opus_page_move", (uint32_t)p_move },
    { "opus_page_path", (uint32_t)p_path },
    { "opus_page_pixels", (uint32_t)p_pixels },
    { "opus_page_still", (uint32_t)p_still },
    { "opus_page_still_done", (uint32_t)p_still_done },
    { "opus_page_stroke", (uint32_t)p_stroke },
    { "opus_page_stroke_line", (uint32_t)p_stroke_line },
    { "opus_page_text", (uint32_t)p_text },
    { "opus_page_text_centre", (uint32_t)p_text_c },
    { "opus_page_text_right", (uint32_t)p_text_r },
    { "opus_skip_dry_input", (uint32_t)skip_dry },
};
const int oe_n_imports = (int)(sizeof oe_imports / sizeof oe_imports[0]);
