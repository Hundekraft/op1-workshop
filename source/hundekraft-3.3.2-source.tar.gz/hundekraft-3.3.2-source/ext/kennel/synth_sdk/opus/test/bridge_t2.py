#!/usr/bin/env python3
"""Tier 2 proof of the Opus bridge (phase 2): the bridge's loader, imports, effect adapter and boot stage on bcore.

    python3 synth_sdk/opus/test/bridge_t2.py [--pack DIR] [--kit DIR] [--src DIR] [--work DIR]

For each of bitcrush, chorus and plate: one guest (bridge_guest.c) boots the bridge over the 4.2 starter pack's
bitcrush, chorus, plate and orbit3d plus files that must be refused (a damaged bitcrush, zoom: an import this core
lacks, bend: places), then runs the loaded effect through the kennel FX entry the bridge registered beside the same
effect built from source, and compares every sample. References: bitcrush from the GPL plugin kit's example source;
chorus and plate from OP1-Emulator's private ext/opus-src rebuilds (no GPL source exists for them), compiled here
only. Inputs live outside this repository (never commit .opmod files or those sources): it prints SKIP when one is
missing. The .opmod files are data: nothing here runs them on the host.

Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import argparse
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SDK = HERE.parents[1]                                       # synth_sdk


def find_root():
    for p in HERE.parents:
        if (p / 'toolchain' / 'bfin-gcc').is_dir():
            return p
    return None


def sh(cmd):
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True)
    if r.returncode:
        sys.exit(f'failed: {" ".join(map(str, cmd))}\n{r.stderr[-3000:]}')
    return r.stdout


REFS = {   # effect: (source folder relative to its base, base key)
    'bitcrush': ('examples/' + 'op' + 'us.bitcrush', 'kit'),
    'chorus': ('chorus/src', 'src'),
    'plate': ('plate/src', 'src'),
    'dimension': ('dimension/src', 'src'),                  # engines (phase 3): through the kennel engine entry
    'outatime': ('examples/' + 'op' + 'us.outatime', 'kit'),  # GPL kit source (1.4.3: the beta 4 file, --pack)
    'dx': ('dx/src', 'src'),                                # ext/opus-src rebuild (phase 3 part 2)
    'sim': ('sim/src', 'src'),                              # a drum engine (opus_drum.c), ext/opus-src rebuild
    'matrix': ('matrix/src', 'src'),                        # an LFO type (opus_lfo.c), ext/opus-src rebuild (phase 4)
    'castle': ('-', 'src'),                                 # displayname808's castle 1.1: no source, the loaded struct
    'pulse': ('seqtest', 'here'),                           # sequencers (opus_seq.c): our own test file, built with the kit
}
ENGINES = {'dimension', 'outatime', 'dx', 'castle'}
DRUMS = {'sim'}
LFOS = {'matrix'}
SEQS = {'pulse'}
FILES = ['orbit3d', 'bitcrush', 'chorus', 'plate', 'zoom', 'bend', 'dimension', 'dx', 'outatime', 'amp', 'sim', 'matrix']


def version_of(text):
    for line in text.splitlines():
        if line.startswith('version'):
            return line.split()[1]
    return None


def manifest_version(path):
    return version_of(path.read_text()) if path.exists() else None


def version(opmod):
    d = opmod.read_bytes()                                   # data only: the manifest's offset and length
    off, n = int.from_bytes(d[0x10:0x14], 'little'), int.from_bytes(d[0x14:0x18], 'little')
    return version_of(d[off:off + n].decode('latin1'))


def main():
    root = find_root()
    ap = argparse.ArgumentParser()
    ap.add_argument('--pack', type=Path, default=root and root / 'run/op' 'us-bridge/starter/mods')
    ap.add_argument('--kit', type=Path, default=root and root / 'build/op' 'us-kit-4.2/plugin-kit')   # e265bca (core 2.58)
    ap.add_argument('--castle', type=Path, default=root and root / 'firmware/op' 'us/displayname808/castle.op' 'mod')
    ap.add_argument('--src', type=Path, default=root and root / 'ext/op' 'us-src/plugins')
    ap.add_argument('--work', type=Path, default=SDK / 'build' / 'bridge_t2')
    ap.add_argument('--only', default='')
    ap.add_argument('--pool', action='store_true', help="kennel's L1 pool linked in and on (the files' leases and moving state in L1)")
    ap.add_argument('--noaccel', action='store_true', help="the known files' own render (ob_accel_on = 0), not kennel's kernels")
    ap.add_argument('--kern-c', action='store_true', help="the accelerators' C loops instead of the assembly")
    ap.add_argument('--direct', action='store_true', help='reference = the loaded struct called directly (the adapter alone)')
    a = ap.parse_args()
    emu = root and root / 'ext/op1emu/ext/bcore/build/emu'
    ext = '.op' + 'mod'
    missing = [p for p in [root, emu, a.pack, a.kit, a.src] if not p or not Path(p).exists()]
    missing += [a.pack / (f + ext) for f in FILES if not (a.pack / (f + ext)).exists()]
    if missing:
        print(f'SKIP bridge_t2: missing {missing[0]}')
        return 0
    tc = root / 'toolchain'
    gcc, as_, ld, nm = (tc / 'bfin-gcc/bin/bfin-elf-gcc', tc / 'bfin/bin/bfin-elf-as', tc / 'bfin/bin/bfin-elf-ld',
                        tc / 'bfin/bin/bfin-elf-nm')
    w = a.work
    w.mkdir(parents=True, exist_ok=True)
    flags = ['-mcpu=bf524', '-O2', '-ffreestanding', '-fno-builtin', '-nostdlib', '-fno-common', '-Wall',
             '-fno-tree-loop-distribute-patterns', f'-I{SDK}']
    bridge = []
    for c in sorted((SDK / ('op' + 'us')).glob('*.c')) + sorted((SDK / ('op' + 'us') / 'accel').glob('*.[cS]')):
        o = w / f'b_{c.parent.name}_{c.stem}.o'
        sh([gcc, *flags, '-DOB_HOST_FS', *(['-DOA_KERN_C'] if a.kern_c else []), '-c', c, '-o', o])
        bridge.append(o)
    if a.pool:                                              # kennel's L1 pool, the core's own code
        sh([gcc, *flags, '-c', SDK / 'kennel/kn_l1.c', '-o', w / 'kn_l1.o'])
        bridge.append(w / 'kn_l1.o')
    # the test sequencers (seqtest/): built here with the kit's tool and our toolchain (a bin/ of both folders' tools)
    tcdir = w / 'bfintc' / 'bin'
    tcdir.mkdir(parents=True, exist_ok=True)
    for sub in ('bfin', 'bfin-gcc'):
        for t in (tc / sub / 'bin').iterdir():
            link = tcdir / t.name
            if link.is_symlink() or link.exists():
                link.unlink()
            link.symlink_to(t)
    pulse = w / ('pulse' + ext)
    r = subprocess.run([sys.executable, '-I', str(a.kit / 'plugin_tool.py'), 'build', str(HERE / 'seqtest'), '--out', str(pulse)],
                       capture_output=True, text=True, env={**os.environ, 'OP1_BFIN_TOOLCHAIN': str(w / 'bfintc')})
    if r.returncode or not pulse.exists():
        sys.exit(f'failed: the test sequencer build\n{r.stdout[-2000:]}{r.stderr[-2000:]}')
    for d in (0, 1):
        for e, mode in (('', []), ('e', ['-DT2_ENGINE']), ('c', ['-DT2_ENGINE', '-DT2_SOLO']), ('d', ['-DT2_DRUM']),
                        ('l', ['-DT2_LFO']), ('s', ['-DT2_SEQ'])):
            sh([gcc, *flags, *(['-DT2_DIRECT'] if d else []), *(['-DT2_POOL'] if a.pool else []), *(['-DT2_NOACCEL'] if a.noaccel else []), *mode, '-c', HERE / 'bridge_guest.c', '-o', w / f'guest{e}{d}.o'])
    sh([as_, '-mcpu=bf524', SDK / 'harness/tier2/crt.S', '-o', w / 'crt.o'])
    lines = ['.section .rodata', '.align 4']
    paths = [a.pack / (f + ext) for f in FILES] + [pulse] + ([a.castle] if a.castle and a.castle.exists() else [])
    for i, path in enumerate(paths):
        lines += [f'_f{i}: .incbin "{path}"', f'_f{i}_end:', '.align 4', f'_n{i}: .asciz "{path.name}"', '.align 4']
    lines += ['.global _t2_files', '_t2_files:']
    for i in range(len(paths)):
        lines += [f'.long _n{i}, _f{i}, _f{i}_end - _f{i}']
    lines += ['.global _t2_nfiles', f'_t2_nfiles: .long {len(paths)}']
    (w / 'files.S').write_text('\n'.join(lines) + '\n')
    sh([as_, '-mcpu=bf524', w / 'files.S', '-o', w / 'files.o'])
    (w / 'guest.ld').write_text('ENTRY(_start)\nSECTIONS {\n . = 0x01E00000;\n .text : { KEEP(*(.text.start)) *(.text*) }\n'
                                ' .rodata : { *(.rodata*) }\n .data : { *(.data*) }\n'
                                ' .bss 0x03000000 (NOLOAD) : { *(.bss*) *(COMMON) }\n}\n')
    libgcc = sh([gcc, '-mcpu=bf524', '-print-libgcc-file-name']).strip()
    ok = True
    for eff, (rel, base) in REFS.items():
        if a.only and eff != a.only:
            continue
        sdir = (a.kit if base == 'kit' else HERE if base == 'here' else a.src) / rel
        if eff == 'castle' and not (a.castle and a.castle.exists()):
            continue
        opmod = pulse if eff in SEQS else a.castle if eff == 'castle' else a.pack / (eff + ext)
        direct = a.direct or version(opmod) != manifest_version(sdir / 'manifest.txt')
        refname = 'its loaded struct called directly (the adapter alone)' if direct else f'source {sdir}'
        objs = []
        for s in sorted(list(sdir.glob('*.c')) + list(sdir.glob('*.S'))):
            o = w / f'r_{eff}_{s.stem}_{s.suffix[1:]}.o'
            sh([gcc, *flags, f'-I{a.kit / "sdk"}', f'-I{sdir}', '-Dop' 'us_effect_register=src_effect_register',
                '-Dop' 'us_engine_add=src_engine_add', '-Dop' 'us_engine_live=src_engine_live',
                '-Dopl_init=src_opl_init', '-Dop' 'us_alloc=src_alloc', '-Dop' 'us_setting=src_setting_unused',
                '-Dop' 'us_lfo_register=src_lfo_register', '-Dop' 'us_lfo_move=src_lfo_move', '-Dop' 'us_tempo=src_tempo',
                '-Dop' 'us_tempo_phase=src_tempo_phase', '-Dop' 'us_tempo_phase_step=src_tempo_phase_step',
                '-Dop' 'us_seq_register=src_seq_register', '-Dop' 'us_on_block=src_on_block',
                '-Dfw_vc_note_on=src_note_on', '-Dfw_vc_note_off=src_note_off', '-c', s, '-o', o])
            objs.append(o)
        (w / f'ref_{eff}.c').write_text(f'const char t2_ref_name[] = "{eff}";\n'
                                        'int op' 'us_setting(void *s, const char *n);\n'
                                        'int src_setting_unused(void *s, const char *n) { return op' 'us_setting(s, n); }\n')
        sh([gcc, *flags, '-c', w / f'ref_{eff}.c', '-o', w / f'ref_{eff}.o'])
        objs.append(w / f'ref_{eff}.o')
        # every other name the source calls (the page's, orbit3d's, fw_*): a stub that returns 0 (never on the audio path)
        defined, undefined = set(), set()
        kind = 'c' if eff == 'castle' else 'e' if eff in ENGINES else 'd' if eff in DRUMS else 'l' if eff in LFOS else 's' if eff in SEQS else ''
        guest = w / f'guest{kind}{int(direct)}.o'
        for o in objs + bridge + [guest, w / 'crt.o', w / 'files.o']:
            for line in sh([nm, o]).splitlines():
                parts = line.split()
                if len(parts) == 2 and parts[0] == 'U':
                    undefined.add(parts[1])
                elif len(parts) == 3 and parts[1] in 'TDBRCtdbr':
                    defined.add(parts[2])
        stubs = sorted(u for u in undefined - defined if not u.startswith('___'))
        data = {'_kn_l1_live': 'unsigned kn_l1_live[16];'}   # without the pool: zeroed words (not in the callback)
        (w / f'stubs_{eff}.c').write_text(''.join(data[s] + '\n' if s in data else f'int {s[1:]}(void) {{ return 0; }}\n'
                                                  for s in stubs))
        sh([gcc, *flags, '-w', '-c', w / f'stubs_{eff}.c', '-o', w / f'stubs_{eff}.o'])
        elf = w / f'guest_{eff}.elf'
        sh([ld, '--no-warn-rwx-segments', '-T', w / 'guest.ld', w / 'crt.o', guest, *bridge, w / 'files.o', *objs,
            w / f'stubs_{eff}.o', libgcc, '-o', elf])
        r = subprocess.run([str(emu), '--fastmem', str(elf)], capture_output=True, text=True, timeout=600)
        out = [l for l in r.stdout.splitlines() if l.startswith('T2')]
        (w / f'result_{eff}.txt').write_text('\n'.join(out) + '\n' + r.stderr[-2000:])
        run = [l for l in out if l.startswith('T2 run')]
        good = bool(run) and ' diff=0x00000000' in run[0] and any('done' in l for l in out)
        if eff == 'castle':                             # no source: the struct called directly shares the file's globals
            good = bool(run) and any('done' in l for l in out)   # (its noise, its block state), so it only has to run;
            good &= any(l.startswith('T2 input') and 'key=0x00000001 key_after=0x00000001 knob_after=0x00000001' in l
                        for l in out)                   # and its three input handlers registered
            good &= any(l.startswith('T2 sha') and 'ok=0x00000001' in l for l in out)   # the quirk table's hash
            good &= any('quirk: voices in L1' in l for l in out)   # its row matched (id, version, the file's sha256)
            refname = 'nothing (the file alone: its sum must be the same with --pool and without)'
        if eff in ('sim', 'dx'):                        # the accelerator (accel/oa.c): bound, used, and equal to the file's render
            line = next((l for l in out if l.startswith('T2 accel ')), '')
            if a.noaccel:
                good &= bool(run) and ' accel=0x00000000' in run[0] and not line
            else:
                good &= any("accel: render on kennel's kernels" in l for l in out) and bool(run) and ' accel=0x00000000' not in run[0]
                good &= ' diff=0x00000000' in line and ' sdiff=0x00000000' in line and (eff != 'sim' or (' edge=0x00000000' not in line and ' zdiff=0x00000000' in line))
            print(line or f'{eff}: accelerator off')
        if eff in ('bitcrush', 'chorus', 'plate'):     # the shift layer: as the source's shift_knob, kept in words 5..7
            sl = next((l for l in out if l.startswith('T2 shift')), '')
            good &= ' bad=0x00000000' in sl and (eff == 'bitcrush' or ' turns=0x00000000' not in sl) and (eff != 'bitcrush' or ' fine=0x00000000' not in sl)
            print(sl or 'T2 shift: missing')
            ls = next((l for l in out if l.startswith('T2 lfoshift')), '')   # an LFO move of params 4..7 (matrix)
            good &= ' bad=0x00000000' in ls and (eff == 'bitcrush' or ' moved=0x00000005' in ls)
            print(ls or 'T2 lfoshift: missing')
            fo = next((l for l in out if 'T2 fromopus saved=' in l), '')   # a sound saved on Opus (name, alias)
            good &= ' bad=0x00000000' in fo and (eff == 'bitcrush' or ' aliased=0x00000001' in fo)
            print(fo or 'T2 fromopus: missing')
        if eff == 'dx':                                 # the engine and page services (opus_engine.c), on dx's run
            sv = next((l for l in out if l.startswith('T2 services')), '')
            good &= all(f' {k}=0x00000001' in sv for k in ('live', 'stored', 'name', 'text', 'dot', 'still'))
            print(sv or 'T2 services: missing')
        if eff in ENGINES:                              # a new sound's words 5..7 are the file's knobs[5..7]
            good &= any(l.startswith('T2 reg-engine') and 'page2_ok=0x00000001' in l for l in out)
            if eff in ('dx', 'dimension'):              # D4: kennel's ports are retired, the plain names are free
                good &= any(f'engine {eff} voice' in l for l in out)
        print(f'{eff}: {("runs" if eff == "castle" else "bit-exact") if good else "FAIL"} against {refname}: {run[0] if run else (out[-3:] if out else r.stderr[-400:])}')
        if eff in LFOS:                                 # offered as plain matrix (the retired port's name is free), its words matched
            good &= any(l.startswith('T2 lfo ') and 'offered=0x00000001' in l and ' name=matrix row=' in l for l in out)
            good &= any(l.startswith('T2 lfo-words') and 'match_ok=0x00000001' in l for l in out)
            good &= any(l.startswith('T2 fromopus lfo saved=matrix') and ' bad=0x00000000' in l for l in out)
            good &= any(l.startswith('T2 moves') and ' n=0x00000000' not in l for l in out)
            print('\n'.join(l for l in out if l.startswith(('T2 lfo', 'T2 moves', 'T2 fromopus'))))
        if eff in SEQS:                                 # pulse and dots_o offered, notes on and off from the block hook
            print('\n'.join(l for l in out if l.startswith(('T2 seq', 'T2 notes'))))
        if eff in DRUMS:                                # offered to the core with its row, the provider complete
            good &= any(l.startswith('T2 drum') and 'offered=0x00000001' in l and 'prov_ok=0x00000001' in l for l in out)
            good &= any(l.startswith('T2 kits names=sim default,sim range,sim ghost,sim metal') and ' bad=0x00000000' in l for l in out)
            good &= any(l.startswith('T2 fromopus kit') and ' bad=0x00000000' in l for l in out)
            print('\n'.join(l for l in out if l.startswith(('T2 drum', 'T2 kits', 'T2 fromopus', 'T2 log'))))
        if eff in ENGINES:
            print('\n'.join(l for l in out if l.startswith(('T2 engine', 'T2 reg-engine', 'T2 pitch', 'T2 log'))))
        if eff == 'bitcrush':                          # amp loads (phase 3 part 3: art colours, paths, skip_dry_input)
            good &= any(l.startswith('T2 reg amp_o') for l in out)
            # the art services (phase 9): dimension's t1.svg parsed once inside a page only, drawn, an element hidden
            # (an unknown id refused), a turn that keeps its centre, three colour records found and set, a pointer
            # outside the document's records left alone
            art = next((l for l in out if l.startswith('T2 art')), '')
            good &= all(f' {k}=0x{v:08x}' in art for k, v in (('found', 1), ('pre', 0), ('ready', 2), ('loads', 1),
                        ('draws', 1), ('show', 2), ('vis', 1), ('turn', 1), ('slots', 3), ('set', 1), ('total', 12345)))
            print(art or 'T2 art: missing')
            good &= any(l.startswith('T2 inv') and 'newcore' in l and 'reason=needs core 2.59' in l for l in out)
            print('\n'.join(l for l in out if l.startswith(('T2 inv', 'T2 reg', 'T2 need', 'T2 arena', 'T2 table', 'T2 settings', 'T2 paths', 'T2 input'))))
        ok &= good
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
