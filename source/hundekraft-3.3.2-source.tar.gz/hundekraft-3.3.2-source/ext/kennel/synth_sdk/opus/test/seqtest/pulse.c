/* test.pulse: two small sequencers for the bridge's tests (synth_sdk/opus/test/bridge_t2.py and the native take), built
 * with the Opus plugin kit against its sdk (opus_plugin.h, op1fw.h). Each player counts the sequencer clock's ticks
 * (96 a beat) and plays its next note at each step (pulse: C4 E4 G4 C5, a quarter note each; dots: C4 G4, eighths);
 * the block handler (opus_on_block, the sequencer thread, once a tick) releases a note 120 calls after it started.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "op1fw.h"
#include "opus_plugin.h"

typedef struct { int note, velocity; unsigned char send_midi, pad[3]; int extra; } note_ev;
typedef struct { const unsigned *vt; unsigned pad[7]; } player_obj;
typedef struct { int ticks, step, held, age, mode, on; } seq_state;

static seq_state st[2];                                           /* 0 pulse, 1 dots */
static const int len[2] = { 96, 48 };
static const int notes[2][4] = { { 60, 64, 67, 72 }, { 60, 67, 60, 67 } };
unsigned pulse_blocks, pulse_ons, pulse_offs;                     /* counters for the tests */

static void release(seq_state *s)
{
    if (!s->on) return;
    note_ev ev = { s->held, 0, 1, { 0 }, 0 };
    fw_vc_note_off(&ev);
    s->on = 0;
    pulse_offs++;
}
static void play(int k)
{
    seq_state *s = &st[k];
    release(s);
    s->held = notes[k][s->step & 3];
    s->step++;
    note_ev ev = { s->held, 100, 1, { 0 }, 0 };
    fw_vc_note_on(&ev, 0);
    s->on = 1; s->age = 0;
    pulse_ons++;
}
static void tick_k(int k)
{
    seq_state *s = &st[k];
    if (s->ticks % len[k] == 0) play(k);
    s->ticks++;
}
static int nop(void *self) { (void)self; return 0; }
static int down(void *self, int key, int shift) { (void)self; (void)key; (void)shift; return 0; }   /* keys play */
static int up(void *self, int key) { (void)self; (void)key; return 0; }
static void reset0(void *self) { (void)self; release(&st[0]); st[0].ticks = 0; st[0].step = 0; }
static void reset1(void *self) { (void)self; release(&st[1]); st[1].ticks = 0; st[1].step = 0; }
static void tick0(void *self, int pos) { (void)self; (void)pos; tick_k(0); }
static void tick1(void *self, int pos) { (void)self; (void)pos; tick_k(1); }
static void stop0(void *self) { reset0(self); }
static void stop1(void *self) { reset1(self); }
static const unsigned vt0[16] = { 0, 0, 0, (unsigned)nop, 0, (unsigned)down, 0, (unsigned)up, 0, (unsigned)reset0, 0,
                                  (unsigned)tick0, 0, (unsigned)nop, 0, (unsigned)stop0 };
static const unsigned vt1[16] = { 0, 0, 0, (unsigned)nop, 0, (unsigned)down, 0, (unsigned)up, 0, (unsigned)reset1, 0,
                                  (unsigned)tick1, 0, (unsigned)nop, 0, (unsigned)stop1 };
static player_obj pl[2] = { { vt0, { 0 } }, { vt1, { 0 } } };
static void *player0(int mode) { st[0].mode = mode; return &pl[0]; }
static void *player1(int mode) { st[1].mode = mode; return &pl[1]; }
static void chosen0(int mode, int on) { (void)mode; if (!on) release(&st[0]); }
static void chosen1(int mode, int on) { (void)mode; if (!on) release(&st[1]); }
static void start0(int mode) { (void)mode; reset0(0); }
static void start1(int mode) { (void)mode; reset1(0); }

static void block(void)                                           /* the sequencer thread, once a tick */
{
    pulse_blocks++;
    for (int k = 0; k < 2; k++)
        if (st[k].on && ++st[k].age >= 120) release(&st[k]);
}

static const struct opus_sequencer pulse = {
    .size = sizeof(struct opus_sequencer), .name = "pulse", .player = player0, .midi_start = start0, .chosen = chosen0 };
static const struct opus_sequencer dots = {
    .size = sizeof(struct opus_sequencer), .name = "dots", .player = player1, .midi_start = start1, .chosen = chosen1 };

int opl_init(struct opl_self *self)
{
    if (opus_seq_register(self, &pulse) < 0) return -1;
    if (opus_seq_register(self, &dots) < 0) return -2;
    opus_on_block(self, block);
    return 0;
}
