/*
 * Tier 2 guest for the Opus bridge (synth_sdk/opus/test/bridge_t2.py): the bridge's real loader, imports, effect
 * adapter and boot stage on bcore, over a small file system of embedded .opmod files and stand-ins for the kennel core
 * services (kn_foreign_*, the arena, settings, inventory). One effect is also built from source (the reference, its
 * names renamed by the driver); it runs beside the loaded file through the kennel FX entry the bridge registered, and
 * every output sample is compared (mono at the synth position, stereo at the master). Prints "T2 ..." lines.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")
#include <stdint.h>
#include "../opus.h"
#include "../accel/oa.h"
uint32_t oa_sim_inc0(const oa_simv *v, const short *par, int32_t logp);
uint8_t *oa_sim_zero(void); uint8_t *oa_dx_zero(void);
static inline uint32_t t2_cycles(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
#include "../../op1_plugin.h"
#include "../../kennel/kn_foreign.h"
#include "../../kennel/kn_inv.h"
#include "../../op1_feature_drum_synth.h"
int kn_foreign_path_ok(const char *path);

void t2_write(const char *b, int n);
unsigned t2_r246_calls, t2_r246_first;
static void put_s(const char *s) { t2_write(s, ob_len(s)); }
static void put_kv(const char *k, uint32_t v)
{
    char b[12]; put_s(" "); put_s(k); put_s("=0x");
    for (int i = 0; i < 8; i++) { int d = (v >> (28 - 4 * i)) & 15; b[i] = (char)(d < 10 ? '0' + d : 'a' + d - 10); }
    b[8] = 0; put_s(b);
}

/* ---- the embedded files (bridge_files.S, made by the driver) ---- */
typedef struct { const char *name; const uint8_t *d; uint32_t size; } t2_file;
extern const t2_file t2_files[];
extern const int t2_nfiles;
#define MAXF 20
static uint8_t copy_bad[64 * 1024];                             /* a damaged copy (one image byte flipped) */
static uint8_t copy_core[64 * 1024];                            /* plate with a `core` line newer than the bridge's */
static uint32_t crc_skip(const uint8_t *d, uint32_t n)          /* the file's CRC-32 (bytes 12..15 as 0) */
{
    uint32_t c = 0xFFFFFFFFu;
    for (uint32_t i = 0; i < n; i++) {
        c ^= (i >= 12 && i < 16) ? 0 : d[i];
        for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & -(c & 1));
    }
    return ~c;
}
static t2_file fs[MAXF];
static int nfs;
static struct { int f; uint32_t pos; } fds[8];
int ob_open(const char *p, int flag, int mode)
{
    (void)mode;
    if (flag) return 7;                                         /* writes (the stage marker) go nowhere */
    const char *n = p; for (const char *q = p; *q; q++) if (*q == '/') n = q + 1;
    for (int i = 0; i < nfs; i++)
        if (ob_eq(fs[i].name, n)) for (int k = 0; k < 7; k++) if (fds[k].f == 0) { fds[k].f = i + 1; fds[k].pos = 0; return k; }
    return -1;
}
int ob_close(int fd) { if (fd >= 0 && fd < 7) fds[fd].f = 0; return 0; }
int ob_read(int fd, void *b, unsigned n)
{
    if (fd < 0 || fd >= 7 || !fds[fd].f) return -1;
    const t2_file *f = &fs[fds[fd].f - 1];
    uint32_t left = f->size - fds[fd].pos;
    if (n > left) n = left;
    for (unsigned i = 0; i < n; i++) ((uint8_t *)b)[i] = f->d[fds[fd].pos + i];
    fds[fd].pos += n;
    return (int)n;
}
int ob_write(int fd, const void *b, unsigned n) { (void)fd; (void)b; return (int)n; }
int ob_unlink(const char *p) { (void)p; return 0; }
int ob_mkdir(const char *p, int m) { (void)p; (void)m; return 0; }
static int dir_i;
static uint8_t dirent[11 + 40];
void *ob_opendir(const char *p) { (void)p; dir_i = 0; return (void *)1; }
const uint8_t *ob_readdir(void *d)
{
    (void)d;
    if (dir_i >= nfs) return 0;
    ob_cat((char *)dirent + 11, fs[dir_i++].name);
    return dirent;
}
int ob_closedir(void *d) { (void)d; return 0; }

/* ---- R246's SVG side for the art services (opus_art.c under OB_HOST_FS): a fake document per parse ---- */
typedef struct { uint8_t pad[0x50]; uint8_t visible; uint8_t pad2[3]; int32_t m[9]; } fake_node;
static struct { uint8_t w[0x80]; uint8_t fill[3][4]; uint8_t stroke[2][20]; fake_node node[4]; } fdoc[4];
static const char *const fnode_id[4] = { "grid", "dash", "axis", "k0" };
static int n_fdoc, svg_loads, art_draws;
static uint32_t te_fake = 4000000;
void *oa_host_svg_load(uint32_t *loader)
{
    if (loader[0]) return (void *)loader[0];
    if (n_fdoc >= 4) return 0;
    uint8_t *d = (uint8_t *)&fdoc[n_fdoc];
    static const uint32_t fc[3] = { 0x2C4362, 0x112233, 0x2C4362 }, sc[2] = { 0x2C4362, 0x445566 };
    for (int i = 0; i < 3; i++) { fdoc[n_fdoc].fill[i][0] = fc[i] >> 16; fdoc[n_fdoc].fill[i][1] = fc[i] >> 8; fdoc[n_fdoc].fill[i][2] = fc[i]; fdoc[n_fdoc].fill[i][3] = 255; }
    for (int i = 0; i < 2; i++) { fdoc[n_fdoc].stroke[i][0] = sc[i] >> 16; fdoc[n_fdoc].stroke[i][1] = sc[i] >> 8; fdoc[n_fdoc].stroke[i][2] = sc[i]; }
    for (int i = 0; i < 4; i++) fdoc[n_fdoc].node[i].visible = 1;
    *(uint8_t **)(d + 0x5C) = &fdoc[n_fdoc].fill[0][0]; *(uint8_t **)(d + 0x60) = &fdoc[n_fdoc].fill[3][0];
    *(uint8_t **)(d + 0x6C) = &fdoc[n_fdoc].stroke[0][0]; *(uint8_t **)(d + 0x70) = &fdoc[n_fdoc].stroke[2][0];
    n_fdoc++; svg_loads++; te_fake += 12345;
    loader[0] = (uint32_t)d;
    return d;
}
void oa_host_screen_draw(void *scr, int dt) { (void)dt; if (*(void **)scr) art_draws++; }
void *oa_host_find(void *doc, const char *id, int warn)
{
    (void)warn;
    for (int k = 0; k < n_fdoc; k++)
        if ((void *)&fdoc[k] == doc) for (int i = 0; i < 4; i++) if (ob_eq(fnode_id[i], id)) return &fdoc[k].node[i];
    return 0;
}
void oa_host_set_matrix(void *node, const int32_t *m) { for (int i = 0; i < 9; i++) ((fake_node *)node)->m[i] = m[i]; }
uint32_t oa_host_te_used(void) { return te_fake; }
static uint8_t oa_heap[4096];
void *oa_host_new(uint32_t n) { return n <= sizeof oa_heap ? oa_heap : 0; }
void oa_host_delete(void *p) { (void)p; }
static uint8_t stage[1u << 20] __attribute__((aligned(32)));
uint8_t *ob_stage = stage;

/* ---- kennel core stand-ins ---- */
static uint8_t arena[3u << 19] __attribute__((aligned(32)));
static uint32_t next, begin_at;
void *kn_alloc(uint32_t n)
{
    n = (n + 3) & ~3u;
    if (next + n > sizeof arena) return 0;
    uint8_t *p = arena + next; next += n;
    for (uint32_t i = 0; i < n; i++) p[i] = 0;
    return p;
}
uint32_t kn_foreign_alloc(uint32_t size, uint32_t align)
{
    next = (next + align - 1) & ~(align - 1);
    if (next + size > sizeof arena) return 0;
    uint32_t a = (uint32_t)(arena + next); next += size;
    for (uint32_t i = 0; i < size; i++) ((uint8_t *)a)[i] = 0xA5;   /* "not cleared": the loader must clear */
    return a;
}
void kn_log_line(const char *file, const char *msg) { put_s("T2 log "); put_s(file); put_s(": "); put_s(msg); put_s("\n"); }
static int reg_n, reg_open_n;
static const char *reg_name[16];
static kn_foreign_desc reg_d[16];
static const kn_foreign_desc *reg_desc[16];
void kn_foreign_begin(void) { begin_at = next; reg_open_n = reg_n; }
void kn_foreign_sync(uint32_t lo, uint32_t hi) { (void)lo; (void)hi; }
int kn_foreign_image(const kn_img_rec *r) { (void)r; return 0; }
const char *kn_foreign_add(const kn_foreign_desc *d)
{
    for (int i = 0; i < reg_n; i++) if (ob_eq(reg_name[i], d->saved)) return "name taken";
    reg_d[reg_n] = *d; reg_name[reg_n] = d->saved; reg_desc[reg_n] = &reg_d[reg_n]; reg_n++;
    return 0;
}
void kn_foreign_commit(void) { }
void kn_foreign_rollback(void) { next = begin_at; reg_n = reg_open_n; }
int kn_plugin_order(int fx, const char *saved)           /* a registered engine: 40 + its index (the run's order); */
{                                                       /* an FX: 200 + its index */
    for (int i = 0; i < reg_n; i++) if (reg_d[i].fx == !!fx && ob_eq(reg_name[i], saved)) return (fx ? 200 : 40) + i;
    return 0;
}
const void *op1_sound_fx(int order)                     /* the FX a selector names (dispatcher.c): kn_plugin_order's */
{
    const int i = order - 200;
    return i >= 0 && i < reg_n && reg_d[i].fx ? reg_d[i].entry : 0;
}
int kn_setcache_get(const char *f, const char *k, int32_t *o) { (void)f; (void)k; (void)o; return 0; }
#define SEEN 32
static const char *seen_key[SEEN]; static int32_t seen_def[SEEN]; static int n_seen;   /* what the loaded files asked */
int32_t kn_setting_db_get(const char *f, const char *k, int32_t def)
{
    (void)f;
    if (n_seen < SEEN) { seen_key[n_seen] = k; seen_def[n_seen++] = def; }
    else { put_s("T2 settings-overflow "); put_s(k); put_s("\n"); }
    return def;
}
static int settings_rows;
int kn_settings_add(const char *name, const uint8_t *t, uint32_t len)
{
    (void)len;
    put_s("T2 settings "); put_s(name); put_kv("rows", t[1]); put_s("\n");
    settings_rows += t[1];
    return 0;
}
static kn_inv_rec inv[MAXF];
static int ninv;
kn_inv_rec *kn_inv_add(int source, const char *path)
{
    if (ninv >= MAXF) return 0;
    kn_inv_rec *r = &inv[ninv++];
    static char paths[MAXF][64];
    r->source = (uint8_t)source; r->path = ob_cat(paths[ninv - 1], path) - ob_len(path);
    return r;
}
static uint8_t big[3][300 * 1024] __attribute__((aligned(32)));
void *op1_fx_big(int pos, uint32_t *size) { if (size) *size = sizeof big[0]; return big[pos]; }

/* ---- the reference: the effect built from source (its opus_effect_register renamed) ---- */
static const opus_effect *ref;
int src_effect_register(void *self, const opus_effect *e) { (void)self; ref = e; return 8; }
int src_opl_init(void *self);
int opus_setting(void *self, const char *name)                  /* the source build's */
{
    (void)self;                                                 /* the same answer the loaded file got */
    for (int i = 0; i < n_seen; i++) if (ob_eq(seen_key[i], name)) {
        put_s("T2 ref-setting "); put_s(name); put_kv("v", (uint32_t)seen_def[i]); put_s("\n");
        return seen_def[i];
    }
    put_s("T2 ref-setting "); put_s(name); put_s(" missing\n");
    return 0;
}
extern const char t2_ref_name[];
static const opus_engine *eref;
static int eref_mark;
int src_engine_add(void *self, const opus_engine *e) { (void)self; eref = e; return 0x4F01; }
/* the reference's opus_alloc (its self is not a loaded file): a cleared 32-byte-aligned pool */
static uint8_t src_pool[96 * 1024] __attribute__((aligned(32)));
static uint32_t src_used;
void *src_alloc(void *self, unsigned n)
{
    (void)self;
    n = (n + 31) & ~31u;
    if (!n || src_used + n > sizeof src_pool) return 0;
    void *p = src_pool + src_used;
    src_used += n;
    return p;
}
int src_engine_live(int16_t *par)                               /* the source build's opus_engine_live: the same words */
{
    const int16_t *w = op1_synth_knobs(0);
    for (int i = 0; i < 8; i++) par[i] = w[i];
    par[4] = (int16_t)eref_mark;
    return 1;
}

/* the core's foreign drum offer (kennel/kn_drum_synth.c kn_ds_foreign_offer): recorded */
static int n_offer; static const char *offer_name, *offer_row;
int kn_ds_foreign_offer(const struct op1_drum_synth *d, const char *row)
{
    n_offer++; offer_name = ((const op1_drum_synth_t *)d)->name; offer_row = row;
    return 0;
}
static int n_kit; static const char *kit_nm[4]; static const int16_t *kit_w[4];   /* its factory kits (kn_ds_foreign_kit) */
int kn_ds_foreign_kit(const struct op1_drum_synth *d, const char *name, const int16_t *words)
{
    (void)d;
    if (n_kit >= 4) return -1;
    kit_nm[n_kit] = name; kit_w[n_kit++] = words;
    return 0;
}
/* ---- phase 4: LFO types and sequencers (opus_lfo.c, opus_seq.c) ---- */
#include "../../op1_feature_lfo.h"
#include "../../op1_feature_seq.h"
const char *const kn_own_seq[] = { "dots", "euclid", "oracle", "peal", 0 };   /* the build's sequencer names */
volatile int kn_src_force;
static int n_lfo_offer, n_seq_offer;
static const op1_lfo_type *lfo_offer[4]; static const char *lfo_offer_row[4];
static const op1_seq_type_t *seq_offer[4];
int kn_lfo_foreign_offer(const struct op1_lfo_type *t, void (*tick)(const op1_beat_t *), const char *row)
{
    (void)tick;
    if (n_lfo_offer < 4) { lfo_offer[n_lfo_offer] = t; lfo_offer_row[n_lfo_offer++] = row; }
    return 0;
}
int kn_seq_foreign_offer(const struct op1_seq_type *t) { if (n_seq_offer < 4) seq_offer[n_seq_offer++] = (const op1_seq_type_t *)t; return 0; }
static const void *active_seq[2];
const struct op1_seq_type *kn_seq_active_type(int mode) { return active_seq[mode & 1]; }
static int16_t t2_record[64];
volatile int t2_shold_square = 1;
static uint32_t t2_record_id;
const int16_t *op1_lfo_record(int pos, int slot, uint32_t id) { (void)pos; (void)slot; return id && id == t2_record_id ? t2_record : 0; }
/* the moves: the bridge's (as opus_lfo_move was asked, before it acts) and the reference's (its renamed opus_lfo_move) */
typedef struct { uint32_t n, sum, per[6][5]; } t2_mlog;
static t2_mlog mlog[2];
static uint32_t mrec[2][16384]; static int32_t mdel[2][16384];
static void mlog_add(int side, int pass, int voice, int g, int p, int d)
{
    t2_mlog *m = &mlog[side];
    const uint32_t v = (uint32_t)pass << 28 ^ (uint32_t)voice << 20 ^ (uint32_t)g << 16 ^ (uint32_t)p << 12 ^ (uint32_t)(uint16_t)d;
    if (m->n < 16384) mrec[side][m->n] = v, mdel[side][m->n] = d;
    m->sum = m->sum * 31u + v; m->n++;
    if (pass < 6 && g < 5) m->per[pass][g]++;
}
static void mfirst(void)
{
    const uint32_t n = mlog[0].n < mlog[1].n ? mlog[0].n : mlog[1].n;
    for (uint32_t i = 0; i < n && i < 16384; i++)
        if (mrec[0][i] != mrec[1][i]) {
            put_s("T2 mfirst"); put_kv("i", i); put_kv("a", mrec[0][i]); put_kv("b", mrec[1][i]); put_kv("da", (uint32_t)mdel[0][i]);
            put_kv("db", (uint32_t)mdel[1][i]); put_s("\n");
            return;
        }
}
void t2_lfo_move_log(const opus_lfo *l, int group, int param, int delta) { mlog_add(0, l->pass, l->voice, group, param, delta); }
/* the bridge's answer to a move (opus_lfo.c s_move, the shift layers' steps 0 here) */
static int move_rule(int pass, int g, int p)
{
    switch (g) {
    case 0: return p <= 3 && (pass == 0 || pass == 3);
    case 1: return p <= 3 && (pass == 1 || pass == 4);
    case 2: return (pass == 2 || pass == 5) && p < 4;
    case 4: return (p == 0 || p == 1) ? pass == 0 : (p == 2 || p == 3) ? (pass == 2 || pass == 5) : 0;
    }
    return 0;
}
static const opus_lfo_type *lref;
int src_lfo_register(void *self, const opus_lfo_type *t) { (void)self; lref = t; return 1; }
int src_lfo_move(const opus_lfo *l, int g, int p, int d)
{
    if (p < 0) return 0;
    mlog_add(1, l->pass, l->voice, g, p, d);
    return move_rule(l->pass, g, p);
}
void src_tempo(void *t) { ((void (*)(void *))ob_import("op" "us_tempo"))(t); }
unsigned src_tempo_phase(unsigned n) { return ((unsigned (*)(unsigned))ob_import("op" "us_tempo_phase"))(n); }
unsigned src_tempo_phase_step(unsigned n) { return ((unsigned (*)(unsigned))ob_import("op" "us_tempo_phase_step"))(n); }
/* sequencers: the notes both sides play (VoiceCtl key_down / key_up of the bridge, the reference's renamed calls) */
typedef struct { uint32_t on, off, sum; } t2_nlog;
static t2_nlog nlog[2];
static int nlog_side;
static void nlog_add(int side, int on, const int32_t *ev, int param)
{
    t2_nlog *n = &nlog[side];
    if (on) n->on++; else n->off++;
    n->sum = n->sum * 31u + ((uint32_t)on << 24 ^ (uint32_t)ev[0] << 16 ^ (uint32_t)ev[1] << 8 ^ (uint32_t)param);
}
static void vc_down(const int32_t *ev, int param) { nlog_add(nlog_side, 1, ev, param); }
static int in_block; static uint32_t block_offs;
static void vc_up(const int32_t *ev) { nlog_add(nlog_side, 0, ev, 0); block_offs += in_block; }
static const opus_sequencer *sref[4]; static int n_sref;
int src_seq_register(void *self, const opus_sequencer *d) { (void)self; if (n_sref < 4) sref[n_sref] = d; return n_sref++; }
static void (*src_block)(void);
void src_on_block(void *self, void (*fn)(void)) { (void)self; src_block = fn; }
void src_note_on(void *ev, int param) { nlog_add(1, 1, ev, param); }
void src_note_off(void *ev) { nlog_add(1, 0, ev, 0); }
void kn_seq_block(void);

static uint32_t rng = 12345;
static int16_t noise(int i) { rng = rng * 1103515245u + 12345u; return (int16_t)(((int)(rng >> 16) & 0x7FFF) - 16384 + ((i & 63) - 32) * 300); }
static int16_t a[64], b[64], al[64], ar[64], bl[64], br[64];
static uint8_t rstate[2][4096] __attribute__((aligned(32)));
static uint8_t rbulk[300 * 1024] __attribute__((aligned(32)));

static void jump_l(uint32_t at, uint32_t to)
{
    uint32_t d = ((to - at) >> 1) & 0xFFFFFF;
    volatile uint16_t *p = (volatile uint16_t *)at;
    p[0] = (uint16_t)(0xE200 | d >> 16);
    p[1] = (uint16_t)d;
}
static int ret0(void) { return 0; }
static int retm1(void) { return -1; }
/* ---- the page and engine services (opus_engine.c) over fakes of R246's raster, text and JSON ---- */
static uint16_t fake_pix[400 * 256];
static uint32_t fake_raster[4] = { (uint32_t)fake_pix, 198, 512, 400 };
static int svc_on;                                             /* the fakes answer only inside the services test */
static void *fake_raster_get(void) { return svc_on ? fake_raster : 0; }
static struct { void *obj; int32_t x, y, size, align; } ctor_rec[8];
static int n_ctor;
static void *fake_text_ctor(void *o, int32_t x, int32_t y, int32_t size, const uint8_t *c, int32_t align)
{
    (void)c;
    if (n_ctor < 8) { ctor_rec[n_ctor].obj = o; ctor_rec[n_ctor].x = x; ctor_rec[n_ctor].y = y; ctor_rec[n_ctor].size = size; ctor_rec[n_ctor].align = align; }
    n_ctor++;
    return o;
}
static struct { const char *s; uint32_t pad; uint8_t type; } fake_name = { "my voice", 0, 4 };
static const void *fake_json_get(const void *j, const char *k) { (void)j; return svc_on && k[0] == 'n' ? (const void *)&fake_name : 0; }
static opl_self self_a = { 16, "a", "/a", 3 }, self_b = { 16, "b", "/b", 5 };
static uint32_t lit(void) { uint32_t n = 0; for (unsigned i = 0; i < sizeof fake_pix / 2; i++) n += fake_pix[i] != 0; return n; }
static void clear_pix(void) { for (unsigned i = 0; i < sizeof fake_pix / 2; i++) fake_pix[i] = 0; }
static int svc_still[4];
static uint32_t svc_dot[3];
static void svc_page(void)
{
    void (*text)(opl_self *, int, int, int, int, int, const char *) = (void (*)(opl_self *, int, int, int, int, int, const char *))ob_import("op" "us_page_text");
    void (*text_r)(opl_self *, int, int, int, int, int, const char *) = (void (*)(opl_self *, int, int, int, int, int, const char *))ob_import("op" "us_page_text_right");
    void (*dot)(int, int, int, int, int) = (void (*)(int, int, int, int, int))ob_import("op" "us_page_dot");
    text(&self_a, 13, 160, 76, 24, 14, "11");                  /* dx's value slot */
    text(&self_b, 13, 96, 30, 6, 14, "eng");                   /* another file's slot 13: its own object */
    text(&self_a, 13, 10, 10, 9, 14, "12");                    /* the same object again, its first place kept */
    text_r(&self_b, 14, 308, 13, 6, 10, "x");                  /* right aligned: R246's align 2 */
    clear_pix(); dot(100, 50, 3, 1, 14); svc_dot[0] = lit();
    clear_pix(); dot(100, 50, 3, 0, 14); svc_dot[1] = lit();
    svc_dot[2] = fake_pix[((400 - 1 - 125) << 8) + 62] != 0;   /* the centre (100, 50) x 400 / 320: lit only when filled */
}
static int svc_round;
static void svc_still_page(void)
{
    int (*still)(opl_self *, unsigned) = (int (*)(opl_self *, unsigned))ob_import("op" "us_page_still");
    void (*done)(opl_self *) = (void (*)(opl_self *))ob_import("op" "us_page_still_done");
    if (!still(&self_a, 77)) { fake_pix[818] = 0x1234; done(&self_a); svc_still[svc_round] = 0; }
    else svc_still[svc_round] = fake_pix[818] == 0x1234 ? 1 : 2;
}

#ifdef T2_POOL
/* kennel's L1 pool (kennel/kn_l1.c linked in): R246's stock Lander table at 0xFF906908 (40 buffers back to back), so
 * kn_l1_init takes the range; one audio callback open for the whole run (no takeover: the loaded file holds its
 * partitions, its voices and leases in L1, the reference in SDRAM) */
void kn_l1_init(void); void kn_l1_begin(void); uint32_t kn_l1_ready(void);
extern uint32_t of_stat[2];
#define T2_L1_CLAIMS of_stat[0]
static void pool_setup(void)
{
    volatile uint32_t *ptr = (volatile uint32_t *)0xFF906908u, *size = (volatile uint32_t *)0xFF9069A8u;
    uint32_t at = 0xFF90081Cu;
    for (int i = 0; i < 40; i++) { uint32_t n = i < 39 ? 620 : 632; ptr[i] = at; size[i] = n; at += n; }
    kn_l1_init(); kn_l1_begin();
    put_s("T2 pool"); put_kv("ready", kn_l1_ready()); put_s("\n");
}
#else
#define T2_L1_CLAIMS 0
#endif
static int sha_ok(void)                                         /* opus_quirk.c's sha256: FIPS 180-2's two vectors */
{
    static const uint8_t a[32] = { 0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea, 0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
                                   0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c, 0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad };
    static const uint8_t b[32] = { 0x24, 0x8d, 0x6a, 0x61, 0xd2, 0x06, 0x38, 0xb8, 0xe5, 0xc0, 0x26, 0x93, 0x0c, 0x3e, 0x60, 0x39,
                                   0xa3, 0x3c, 0xe4, 0x59, 0x64, 0xff, 0x21, 0x67, 0xf6, 0xec, 0xed, 0xd4, 0x19, 0xdb, 0x06, 0xc1 };
    static const char m2[] = "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq";
    uint8_t o[32];
    int ok = 1;
    ob_sha256((const uint8_t *)"abc", 3, o);
    for (int i = 0; i < 32; i++) ok &= o[i] == a[i];
    ob_sha256((const uint8_t *)m2, 56, o);
    for (int i = 0; i < 32; i++) ok &= o[i] == b[i];
    return ok;
}
#ifdef T2_DRUM
/* (its own function at -O1: at -O2 GCC 13.3 stops with "unable to find a register to spill in class ODD_AREGS") */
static __attribute__((noinline, optimize("O1"))) void accel_sim(const opus_engine *le, const int16_t *kit)
{
    static int16_t oa[128], ob_[128];
    {   /* the accelerator against the file's own render_cb on copies of one voice: random states,
                                 * numbers and pitches, four blocks each (the constants' cache hit), and the body's
                                 * xs = -0x8000 sample (the first phase at 0x80000000) the original computes as 4 */
            static uint32_t va[24], vb[24];
            static int16_t p8[8];
            static uint32_t zsave[1043], zfile[1043];
            uint8_t *zs = oa_sim_zero();
            uint32_t xd = 0, sd = 0, cases = 0, edge = 0, zd = 0, rolls = 0;
            for (int n = 0; n < 4000; n++) {
                oa_simv *A = (oa_simv *)va;
                for (int i = 0; i < 19; i++) va[i] = (uint32_t)noise(i) << 16 ^ (uint32_t)noise(i + 7);
                for (int i = 0; i < 8; i++) p8[i] = noise(i + n) * 2 + (n & 1);
                if (n % 5 == 0) for (int i = 0; i < 8; i++) p8[i] = kit[((n / 5) % 24) * 8 + i];
                A->env = va[10] % 0x7FFF00u; A->nenv = va[11] % 0x7FFF00u; A->swp = va[12] % 0x10001u;
                A->lp = (int16_t)A->lp; A->bp = (int16_t)A->bp; A->hold_n = va[13] % 9u; A->hold_v = (int16_t)A->hold_v;
                A->choke = n % 7 == 0; A->index = n % 12; A->ratio = n % 3 ? 0x10000u : 0x9000u + n * 13u; A->logp = 0;
                if (!A->seed) A->seed = 1;
                const uint32_t pr = n % 4 == 0 ? 0 : n % 4 == 1 ? 0x10000u : 0x6000u + (uint32_t)n * 97u;
                if (n % 3 == 2) {                                       /* the edge: at ratio 1 (logp 0) */
                    A->ratio = 0x10000u; A->env = 0x7FFE00u; p8[5] = (int16_t)(n & 0x3FFF);
                    A->ph[0] = 0x80000000u - oa_sim_inc0(A, p8, 0); edge++;
                }
                for (int i = 0; i < 19; i++) vb[i] = va[i];
                for (int b = 0; b < 4; b++) {
                    /* the scope tap too: its words in the file's zero fill (+0x44, +0x5248 mark .. the ring's end) from
                     * the same start, the mark at "now" (no new block) or, every 7th, far back (the counter moves; the
                     * mark word itself then differs by the cycles between the two calls and is left out) */
                    const int roll = (n + b) % 7 == 0;
                    uint32_t *zw = (uint32_t *)(zs + 0x5248);
                    if (roll) zw[0] = t2_cycles() - 900000u; else zw[0] = t2_cycles();
                    for (uint32_t i = 0; i < 4168 / 4; i++) zsave[i] = zw[i];
                    zsave[1042] = *(uint32_t *)(zs + 0x44);
                    unsigned r = n % 3 == 2 ? 0x10000u : pr;
                    le->render(va, oa, p8, &r);
                    for (uint32_t i = 0; i < 4168 / 4; i++) { zfile[i] = zw[i]; zw[i] = zsave[i]; }
                    zfile[1042] = *(uint32_t *)(zs + 0x44); *(uint32_t *)(zs + 0x44) = zsave[1042];
                    if (roll) zw[0] = t2_cycles() - 900000u; else zw[0] = t2_cycles();
                    r = n % 3 == 2 ? 0x10000u : pr;
                    oa_sim_render(vb, ob_, p8, &r);
                    for (uint32_t i = roll ? 1 : 0; i < 4168 / 4; i++) zd += zfile[i] != zw[i];
                    zd += zfile[1042] != *(uint32_t *)(zs + 0x44);
                    rolls += roll && zw[1] != zsave[1];
                    for (int i = 0; i < 128; i++) xd += oa[i] != ob_[i];
                    for (int i = 0; i < 19; i++) sd += va[i] != vb[i];
                    cases++;
                }
            }
            put_s("T2 accel sim"); put_kv("blocks", cases); put_kv("edge", edge); put_kv("rolls", rolls); put_kv("zdiff", zd); put_kv("diff", xd); put_kv("sdiff", sd); put_s("\n");
        }
}
#endif
int main(void)
{
#ifdef T2_NOACCEL
    ob_accel_on = 0;
#endif
#ifdef T2_POOL
    pool_setup();
#endif
    put_s("T2 sha"); put_kv("ok", sha_ok()); put_s("\n");
    jump_l(0x019BEB70u, (uint32_t)fake_json_get);              /* the services test's fakes (svc_on): JSON get, */
    jump_l(0x01A3B490u, (uint32_t)fake_raster_get);            /* the raster, the text object */
    jump_l(0x01A61904u, (uint32_t)fake_text_ctor);
    jump_l(0x01A61AACu, (uint32_t)ret0); jump_l(0x01A6259Cu, (uint32_t)ret0);
    jump_l(0x01A9CE04u, (uint32_t)ret0);                       /* fw_snprintf, fw_shift_held, fw_screen_draw */
    jump_l(0x019D7C6Cu, (uint32_t)ret0);
    jump_l(0x01A3B4C8u, (uint32_t)ret0);
    jump_l(0x01A9B450u, (uint32_t)ret0);                       /* fw_yaffs_opendir: no folder (dx's bank scan) */
    jump_l(0x01A997F4u, (uint32_t)retm1);                      /* fw_yaffs_open: no file */
    put_s("T2 table"); put_kv("sorted", (uint32_t)ob_table_sorted()); put_s("\n");
    for (int i = 0; i < t2_nfiles && nfs < MAXF; i++) fs[nfs++] = t2_files[i];
    for (int i = 0; i < t2_nfiles; i++)                         /* a damaged copy of bitcrush */
        if (ob_eq(t2_files[i].name, "bitcrush.opmod") && t2_files[i].size <= sizeof copy_bad) {
            for (uint32_t k = 0; k < t2_files[i].size; k++) copy_bad[k] = t2_files[i].d[k];
            copy_bad[t2_files[i].size / 2] ^= 0x40;
            fs[nfs].name = "damaged.opmod"; fs[nfs].d = copy_bad; fs[nfs].size = t2_files[i].size; nfs++;
        }
    for (int i = 0; i < t2_nfiles; i++)                         /* plate declaring core 2.59: refused, "needs core 2.59" */
        if (ob_eq(t2_files[i].name, "plate.op" "mod") && t2_files[i].size <= sizeof copy_core) {
            const uint32_t n = t2_files[i].size;
            for (uint32_t k = 0; k < n; k++) copy_core[k] = t2_files[i].d[k];
            int hit = 0;
            for (uint32_t k = 0; k + 14 < n && !hit; k++)
                if (copy_core[k] == '\n' && copy_core[k + 1] == 'c' && copy_core[k + 2] == 'o' && copy_core[k + 3] == 'r' &&
                    copy_core[k + 4] == 'e') {
                    uint32_t v = k + 5;
                    while (copy_core[v] == ' ') v++;
                    if (copy_core[v] == '2' && copy_core[v + 1] == '.') { copy_core[v + 2] = '5'; copy_core[v + 3] = '9'; hit = 1; }
                }
            const uint32_t c = crc_skip(copy_core, n);
            for (int b = 0; b < 4; b++) copy_core[12 + b] = (uint8_t)(c >> (8 * b));
            if (hit) { fs[nfs].name = "newcore.op" "mod"; fs[nfs].d = copy_core; fs[nfs].size = n; nfs++; }
        }
    {                                                           /* the push's allow-list (kn_foreign_path_ok) */
        static const char *const good[] = { "op" "us/plate.op" "mod", "op" "us/a_b-1.op" "mod", 0 };
        static const char *const bad[] = { "op" "us/.x.op" "mod", "op" "us/a/b.op" "mod", "op" "us/Plate.op" "mod", "plugins/a.op" "mod",
                                           "op" "us/a.knl", "op" "us/.op" "mod", 0 };
        int ok = 1;
        for (int i = 0; good[i]; i++) ok &= kn_foreign_path_ok(good[i]) == 1;
        for (int i = 0; bad[i]; i++) ok &= kn_foreign_path_ok(bad[i]) == 0;
        put_s("T2 paths"); put_kv("ok", (uint32_t)ok); put_s("\n");
        if (!ok) return 1;
    }
    uint32_t images = 0, need = kn_foreign_need(&images);
    put_s("T2 need"); put_kv("bytes", need); put_kv("images", images); put_s("\n");
    kn_foreign_boot(0);
    for (int i = 0; i < ninv; i++) {
        put_s("T2 inv "); put_s(inv[i].path); put_kv("state", inv[i].state);
        put_s(" reason="); put_s(inv[i].reason ? inv[i].reason : "-");
        if (inv[i].claims) { put_s(" "); put_s(inv[i].claims); }
        put_s("\n");
    }
    for (int i = 0; i < reg_n; i++) {
        put_s("T2 reg "); put_s(reg_name[i]); put_kv("stereo", reg_desc[i]->flags & 4);
        put_kv("def0", (uint16_t)reg_desc[i]->defaults[0]); put_s("\n");
    }
    put_s("T2 arena"); put_kv("used", next); put_kv("need", need); put_s("\n");
    {   /* the input services (opus_input.c): castle 1.1 registers on_key, on_key_after, on_knob_after; a key and a turn
         * reach them through the core's seams (kn_features_input, then the after hook) */
        const int c = oi_count();
        const int took = kn_foreign_input(1, 0x00, 1, 0);
        kn_foreign_input_after(1, 0x00, 1, 0);
        kn_foreign_input(2, 0, 0, 4096);
        kn_foreign_input_after(2, 0, 0, 4096);
        put_s("T2 input"); put_kv("key", c & 0xFF); put_kv("key_after", c >> 8 & 0xFF); put_kv("knob_after", c >> 16 & 0xFF);
        put_kv("line", (uint32_t)c >> 24); put_kv("took", (uint32_t)took); put_s("\n");
    }

    {   /* the art services (opus_art.c, phase 9): dimension's t1.svg as its opl_init wrote it, parsed on the fake parser */
        int n = -1;
        for (int i = 0; i < oa_count(); i++) {
            const char *r = oa_rel(i);
            if (r && ob_eq(r, "../../mod/op" "us.dimension/t1.svg")) n = i;
        }
        int (*ready)(int) = (int (*)(int))ob_import("op" "us_art_ready");
        void (*draw)(int) = (void (*)(int))ob_import("op" "us_art_draw");
        int (*show)(int, const char *, int) = (int (*)(int, const char *, int))ob_import("op" "us_art_show");
        int (*turn)(int, const char *, int, int, int) = (int (*)(int, const char *, int, int, int))ob_import("op" "us_art_turn");
        int (*slots)(int, unsigned, unsigned char **, int) = (int (*)(int, unsigned, unsigned char **, int))ob_import("op" "us_art_colour_slots");
        void (*setc)(unsigned char **, int, unsigned) = (void (*)(unsigned char **, int, unsigned))ob_import("op" "us_art_set_colour");
        const int pre = n >= 0 ? ready(n) : -1;                 /* outside a page: not parsed */
        oa_in_page = 1;
        const int r1 = n >= 0 ? ready(n) : -1, r2 = n >= 0 ? ready(n) : -1;   /* parsed once */
        draw(n);
        oa_in_page = 0;
        fake_node *nd = n_fdoc ? fdoc[n_fdoc - 1].node : 0;
        const int sh = show(n, "grid", 0), shx = show(n, "nope", 1);
        const int vis = nd ? nd[0].visible == 0 && nd[1].visible == 1 : 0;
        const int tu = turn(n, "k0", 1024, 100 << 8, 40 << 8);  /* a quarter turn about (100, 40): it stays put */
        const int32_t *m = nd ? nd[3].m : 0;
        const int fixed = m && (100 << 10) * m[0] / 1024 + (40 << 10) * m[3] / 1024 + m[6] == 100 << 10 &&
                          (100 << 10) * m[1] / 1024 + (40 << 10) * m[4] / 1024 + m[7] == 40 << 10 && m[1] == 1024 && m[3] == -1024;
        unsigned char *sl[8];
        const int ns = slots(n, 0x2C4362, sl, 8);
        uint8_t bogus[4] = { 0x2C, 0x43, 0x62, 0 };
        sl[ns] = bogus;
        setc(sl, ns + 1, 0x010203);
        const int set_ok = nd && fdoc[n_fdoc - 1].fill[0][2] == 3 && fdoc[n_fdoc - 1].fill[2][0] == 1 && fdoc[n_fdoc - 1].stroke[0][1] == 2 &&
                           fdoc[n_fdoc - 1].fill[1][0] == 0x11 && bogus[0] == 0x2C;
        put_s("T2 art"); put_kv("found", n >= 0); put_kv("pre", (uint32_t)pre); put_kv("ready", (uint32_t)(r1 + r2)); put_kv("loads", (uint32_t)svg_loads);
        put_kv("draws", (uint32_t)art_draws); put_kv("show", (uint32_t)(sh * 2 + shx)); put_kv("vis", (uint32_t)vis); put_kv("turn", (uint32_t)(tu && fixed));
        put_kv("slots", (uint32_t)ns); put_kv("set", (uint32_t)set_ok); put_kv("total", oa_total()); put_s("\n");
    }

#ifdef T2_LFO
    {   /* an LFO type (opus_lfo.c): the kennel LfoMidi entries beside the source build driven as the Opus core drives it
         * (status.c lfo_place_dispatch: tick right before the apply of pass 2 / 4; services.c opus_lfo_move) */
        src_opl_init((void *)1);
        if (!lref) { put_s("T2 noref\n"); return 1; }
        int k = -1;
        for (int i = 0; i < ol_count(); i++) if (ob_eq(ol_lfo(i)->name, t2_ref_name)) k = i;
        if (k < 0) { put_s("T2 notloaded\n"); return 1; }
        const opus_lfo_type *lt = ol_lfo(k);
#ifdef T2_DIRECT
        lref = lt;
#endif
        const op1_lfo_type *kt = ol_kennel(k);
        put_s("T2 lfo "); put_s(lt->name); put_kv("size", lt->size); put_kv("nparams", lt->nparams); put_kv("state", lt->state_size);
        put_kv("offered", n_lfo_offer); put_s(" name="); put_s(n_lfo_offer ? lfo_offer[0]->name : "-");
        put_s(" row="); put_s(n_lfo_offer ? lfo_offer_row[0] : "-"); put_kv("marker", kt->marker); put_s("\n");
        /* R246's state: slot 0 of both instruments, the LFO on, six synth and twelve drum LFO objects */
        *(volatile int *)0xFF8016D4 = 0; *(volatile int *)0xFF8016D8 = 0; *(volatile int *)0x01AAAC10 = 0;
        ((volatile uint8_t *)0x01AAAC28)[0] = 1; ((volatile uint8_t *)0x01AAAC38)[0] = 1;
        void **so = (void **)0x01AAAD6C, **dob = (void **)0x01AAAD84;
        for (int i = 0; i < 6; i++) so[i] = (void *)(0x01A00000u + 16u * i);
        for (int i = 0; i < 12; i++) dob[i] = (void *)(0x01A10000u + 16u * i);
        void *fxo = (void *)0x01A20000u;
        int16_t *ws = (int16_t *)0xFF8014C4, *wd = (int16_t *)0xFF801644;
        for (int i = 0; i < 8; i++) ws[i] = wd[i] = 0;
        {   /* the row's words: "[0,0,h,0,0,0,0,-15104]" */
            const char *r = lfo_offer_row[0]; int c = 0, v = 0, neg = 0, idx = 0;
            for (; r && *r; r++) {
                if (*r == '-') neg = 1; else if (*r >= '0' && *r <= '9') { v = v * 10 + (*r - '0'); c = 1; }
                else if ((*r == ',' || *r == ']') && c) { ws[idx] = wd[idx] = (int16_t)(neg ? -v : v); idx++; v = 0; c = 0; neg = 0; }
            }
        }
        const int match_ok = kt->match(ws) && !kt->match((const int16_t[8]){ 0, 0, (int16_t)(ws[2] + 1), 0, 0, 0, 0, ws[7] });
        put_s("T2 lfo-words"); for (int i = 0; i < 8; i++) put_kv("w", (uint16_t)ws[i]); put_kv("match_ok", match_ok); put_s("\n");
        {   /* an LFO record saved on Opus (ol_from_opus): its words match the type, the settings kept (-32768: default) */
            static int16_t p[3] = { 0x0081, -32768, 42 }, w[8], rec[64], w2[8], rec2[64];
            uint32_t id = 0, id2 = 0, bad = 0;
            const char *sv = ol_from_opus(lt->name, p, 3, w, rec, &id);
            bad |= (uint32_t)!(sv && ob_eq(sv, lfo_offer[0]->name));
            bad |= (uint32_t)!(kt->match(w) && id && (uint16_t)w[0] == (id & 0xFFFF) && (uint16_t)w[1] == id >> 16) << 1;
            bad |= (uint32_t)(rec[0] != 0x0081 || rec[1] != lt->defaults[1] || rec[2] != 42) << 2;
            for (int i = 3; i < 64; i++) bad |= (uint32_t)(rec[i] != (i < lt->nparams ? lt->defaults[i] : 0)) << 3;
            ol_from_opus(lt->name, p, 3, w2, rec2, &id2);
            bad |= (uint32_t)(id2 != id) << 4;                           /* the same sound: the same record */
            bad |= (uint32_t)(ol_from_opus("nosuchlfo", p, 3, w2, rec2, &id2) != 0) << 5;
            put_s("T2 fromopus lfo saved="); put_s(sv ? sv : "-"); put_kv("id", id); put_kv("bad", bad); put_s("\n");
        }
        /* a record touching every destination group: rows of all six shapes and an envelope, synced and free rows */
        static const int16_t rows[8][8] = {
            { 0x0080 | 0x10 | 0, 0, 60, 4, 0, 0, 0, 0 }, { 0x0080 | 0x100 | 1, 8, 40, 250, 0, 0, 0, 0 },
            { 0x0080 | 6, 12, 80, 0, 10, 30, 50, 20 }, { 0x0080 | 0x20 | 2, 20, 30, 7, 0, 0, 0, 0 },
            { 0x0080 | 0x40 | 3, 21, 25, 9, 0, 0, 0, 0 }, { 0x0080 | 5, 22, 50, 12, 0, 0, 0, 0 },
            { 0x0080 | 4, 25, 70, 3, 0, 0, 0, 0 }, { 0x0080 | 0x10 | 0x20 | 1, 1, -50, 6, 0, 0, 0, 0 } };
        for (int r = 0; r < 8; r++) for (int j = 0; j < 8; j++) t2_record[r * 8 + j] = rows[r][j];
#ifndef T2_DIRECT
        /* row 5's sample and hold: the source rebuild's instrument-pass value differs from the release's (the first ring
         * move of pass 2: -8073 against -8474; ext/opus-src docs/c-matching.md: matrix's C is not matching; not run
         * down), so against the source it runs as a square; --direct (the loaded struct) runs it as written */
        if (t2_shold_square) t2_record[5 * 8] = 0x0080 | 4;
#endif
        static uint8_t rst[2][4096] __attribute__((aligned(32)));
        static opus_lfo rl;
        uint32_t sdiff = 0, blocks = 0;
        for (int phase = 0; phase < 2; phase++) {             /* 0: a fresh pick (id 0, the defaults); 1: the record */
            t2_record_id = phase ? 77 : 0;
            ws[0] = wd[0] = (int16_t)t2_record_id;
            for (int p = 0; p < 2; p++) for (int i = 0; i < 4096; i++) rst[p][i] = 0;
            const int16_t *par = phase ? t2_record : 0;
            static int16_t defs[64];
            for (int i = 0; i < 64; i++) defs[i] = i < lref->nparams ? lref->defaults[i] : 0;
            if (!par) par = defs;
            for (int blk = 0; blk < 300; blk++, blocks++) {
                op1_beat_t b = { 22050 << 14, 0, 0x100000, 0, 0 };
                ol_clock(&b);
                if (blk % 37 == 0) {                            /* notes: a synth voice and a drum voice start */
                    const int v = (blk / 37) % 6, dv = (blk / 37) % 12;
                    kt->trig_synth(so[v], ws);
                    rl = (opus_lfo){ 0, 0, (uint8_t)v, 0, (int16_t *)par, rst[0] }; lref->trigger(&rl);
                    kt->trig_drum(dob[dv], wd);
                    rl = (opus_lfo){ 1, 0, (uint8_t)dv, 0, (int16_t *)par, rst[1] }; lref->trigger(&rl);
                }
                for (int v = 0; v < 3; v++) for (int pass = 1; pass >= 0; pass--) {   /* synth: 1 then 0 a voice, then 2 */
                    kt->apply_synth(so[v], ws, pass);
                    rl = (opus_lfo){ 0, 0, (uint8_t)v, (uint8_t)pass, (int16_t *)par, rst[0] }; lref->apply(&rl);
                }
                kt->apply_fx(fxo, ws, 2);
                rl = (opus_lfo){ 0, 0, 255, 2, (int16_t *)par, rst[0] }; lref->tick(&rl); lref->apply(&rl);
                for (int v = 0; v < 4; v++) {                   /* drum: 3 a voice, then 4, then 5 */
                    kt->apply_drum(dob[v], wd, 3);
                    rl = (opus_lfo){ 1, 0, (uint8_t)v, 3, (int16_t *)par, rst[1] }; lref->apply(&rl);
                }
                kt->apply_fx(fxo, wd, 4);
                rl = (opus_lfo){ 1, 0, 255, 4, (int16_t *)par, rst[1] }; lref->tick(&rl); lref->apply(&rl);
                kt->apply_fx(fxo, wd, 5);
                rl = (opus_lfo){ 1, 0, 255, 5, (int16_t *)par, rst[1] }; lref->apply(&rl);
                for (int p = 0; p < 2; p++) {
                    const uint8_t *a = ol_state(k, p, 0), *r = rst[p];
                    for (int i = 0; i < lref->state_size; i++) {
                        if (a[i] != r[i] && !sdiff) { put_s("T2 first"); put_kv("phase", phase); put_kv("blk", blk); put_kv("pos", p);
                            put_kv("byte", i); put_kv("a", a[i]); put_kv("b", r[i]); put_s("\n"); }
                        sdiff += a[i] != r[i];
                    }
                }
            }
        }
#ifdef T2_DIRECT                                                /* the reference's moves go to the bridge (refused) */
        const uint32_t mdiff = 0;
#else
        const uint32_t mdiff = (mlog[0].n != mlog[1].n) + (mlog[0].sum != mlog[1].sum);
#endif
        if (mdiff) mfirst();
        put_s("T2 moves"); put_kv("n", mlog[0].n); put_kv("ref_n", mlog[1].n);
        for (int pass = 0; pass < 6; pass++) for (int g = 0; g < 5; g++) if (mlog[0].per[pass][g]) {
            put_s(" p"); char c[2] = { (char)('0' + pass), 0 }; put_s(c); put_s("g"); c[0] = (char)('0' + g); put_s(c);
            put_kv("", mlog[0].per[pass][g]); }
        put_s("\n");
        put_s("T2 run"); put_kv("l1", T2_L1_CLAIMS); put_kv("blocks", blocks); put_kv("diff", sdiff + mdiff + !match_ok); put_kv("sdiff", sdiff);
        put_kv("mdiff", mdiff); put_kv("sum", mlog[0].sum); put_s("\n");
        put_s("T2 done=0x1\n");
        return 0;
    }
#elif defined(T2_SEQ)
    {   /* sequencers (opus_seq.c): the kennel types' players and the block hook beside the source build */
        src_opl_init((void *)1);
        if (n_sref < 2 || !src_block) { put_s("T2 noref\n"); return 1; }
        jump_l(0x01A85750u, (uint32_t)vc_down);
        jump_l(0x01A85840u, (uint32_t)vc_up);
        *(volatile int *)0x01DE4C40 = 0;                        /* synth mode */
        put_s("T2 seq"); put_kv("loaded", os_count()); put_kv("offered", n_seq_offer);
        for (int i = 0; i < n_seq_offer; i++) { put_s(" name="); put_s(seq_offer[i]->name); }
        put_s("\n");
        if (n_seq_offer < 2) return 1;
        const opus_sequencer *ls0 = os_seq(0), *ls1 = os_seq(1);
#ifdef T2_DIRECT
        sref[0] = ls0; sref[1] = ls1;
#endif
        (void)ls0; (void)ls1;
        active_seq[0] = seq_offer[0];
        void *pa[2], *pb[2];
        for (int i = 0; i < 2; i++) { nlog_side = 0; pa[i] = seq_offer[i]->player(); pb[i] = sref[i]->player(0); }
        uint32_t ticks = 0;
        for (int t = 0; t < 3000; t++, ticks++) {
            for (int i = 0; i < 2; i++) {
                const uint32_t *va = *(const uint32_t *const *)pa[i], *vb = *(const uint32_t *const *)pb[i];
                nlog_side = 0; ((void (*)(void *, int))va[11])(pa[i], t % 48);
                ((void (*)(void *, int))vb[11])(pb[i], t % 48);
            }
            for (int b = 0; b < 3; b++) {                        /* about 3.6 blocks a tick at 120 BPM */
                nlog_side = 0; in_block = 1; kn_seq_block(); in_block = 0;
                src_block();
            }
        }
        for (int i = 0; i < 2; i++) {                           /* stop */
            const uint32_t *va = *(const uint32_t *const *)pa[i], *vb = *(const uint32_t *const *)pb[i];
            nlog_side = 0; ((void (*)(void *))va[15])(pa[i]);
            ((void (*)(void *))vb[15])(pb[i]);
        }
        const int names_ok = ob_eq(seq_offer[0]->name, "pulse") && ob_eq(seq_offer[1]->name, "dots_o");
        const uint32_t d = (nlog[0].on != nlog[1].on) + (nlog[0].off != nlog[1].off) + (nlog[0].sum != nlog[1].sum) + !names_ok
                           + !nlog[0].on + !block_offs;
        put_s("T2 notes"); put_kv("on", nlog[0].on); put_kv("off", nlog[0].off); put_kv("ref_on", nlog[1].on);
        put_kv("ref_off", nlog[1].off); put_kv("block_offs", block_offs); put_kv("names_ok", names_ok); put_s("\n");
        put_s("T2 run"); put_kv("l1", T2_L1_CLAIMS); put_kv("ticks", ticks); put_kv("diff", d); put_kv("sum", nlog[0].sum); put_s("\n");
        put_s("T2 done=0x1\n");
        return 0;
    }
#elif defined(T2_DRUM)
    {   /* a drum engine (opus_drum.c): the adapter's voices beside the source build driven as the Opus core's engine glue
         * drives it (engineglue.c voice_note_on / voice_render_block: group + choke, note_key velocity 127, render with
         * &ratio, finished) */
        src_opl_init((void *)1);
        if (!eref) { put_s("T2 noref\n"); return 1; }
        int k = -1;
        for (int i = 0; i < od_count(); i++) if (ob_eq(od_engine(i)->name, t2_ref_name)) k = i;
        if (k < 0) { put_s("T2 notloaded\n"); return 1; }
        const opus_engine *le = od_engine(k);
#ifdef T2_DIRECT
        eref = le;
#endif
        const op1_drum_synth_t *pv = od_provider(k);
        put_s("T2 drum "); put_s(le->name); put_kv("size", le->size); put_kv("voice", le->voice); put_kv("flags", le->flags);
        put_kv("offered", n_offer); put_s(" name="); put_s(n_offer ? offer_name : "-"); put_s(" row="); put_s(n_offer ? offer_row : "-");
        put_kv("prov_ok", pv && pv->name && ob_eq(pv->name, offer_name) && pv->type && pv->factory && pv->trigger && pv->render &&
               pv->status && pv->screen_ctor);
        put_s("\n");
        {   /* its factory kits (od_offer -> kn_ds_foreign_kit): "sim default" = the engine's own keys, then HIM's three */
            uint32_t kbad = n_kit != 4;
            for (int i = 0; i < n_kit; i++) { put_s(i ? "," : "T2 kits names="); put_s(kit_nm[i]); }
            for (int key = 0; n_kit && key < 24; key++) for (int j = 0; j < 8; j++) kbad |= (uint32_t)(kit_w[0][key * 8 + j] != le->keys[key][j]) << 1;
            if (n_kit == 4) kbad |= (uint32_t)(kit_w[1][0] != -24320 || kit_w[3][191] != 24823) << 2;   /* range's first, metal's last word */
            put_kv("n", (uint32_t)n_kit); put_kv("bad", kbad); put_s("\n");
        }
        {   /* a kit saved on Opus (od_from_opus): its mark, or the plugin id without one */
            const int m = od_mark(k);
            const char *a1 = od_from_opus(m, "x"), *a2 = od_from_opus(0, "op" "us.sim"), *a3 = od_from_opus(m + 1, "op" "us.sim");
            put_s("T2 fromopus kit"); put_kv("mark", (uint32_t)m);
            put_kv("bad", (uint32_t)!(a1 && ob_eq(a1, offer_name)) | (uint32_t)!(a2 && ob_eq(a2, offer_name)) << 1 | (uint32_t)(a3 != 0) << 2);
            put_s("\n");
        }
        static int16_t kit[24 * 8], oa[128], ob_[128];
        static uint8_t rv[12][256] __attribute__((aligned(32)));
        static uint8_t ract[12]; static int8_t rkey[12];
        for (int key = 0; key < 24; key++) for (int j = 0; j < 8; j++) kit[key * 8 + j] = eref->keys[key][j];
        for (int key = 0; key < 4; key++) kit[key * 8 + 6] = 8192;            /* choke group 1: keys 0..3 */
        for (int key = 4; key < 8; key++) kit[key * 8 + 6] = 16384;           /* group 2: keys 4..7 */
        for (int key = 12; key < 24; key += 3) { kit[key * 8 + 0] = (int16_t)(-20000 + key * 1700); kit[key * 8 + 7] = (int16_t)(key * 1300); }
        od_build(k);
        for (int v = 0; v < 12; v++) { eref->init(rv[v], v); ract[v] = 0; rkey[v] = -1; }
        uint32_t diff = 0, adiff = 0, sum = 0, blocks = 0, ends = 0, chokes = 0;
        for (int step = 0; step < 48; step++) {
            const int v = (step * 5) % 12, key = step < 8 ? step : (step * 7 + step / 5) % 24;
            od_hit(k, v, kit, key);
            {   /* the reference: engineglue.c voice_note_on */
                const int g = eref->group(kit + key * 8, key);
                if (g > 0) for (int u = 0; u < 12; u++) {
                    if (u == v || !ract[u] || rkey[u] < 0 || rkey[u] == key) continue;
                    if (eref->group(kit + rkey[u] * 8, 0) != g) continue;
                    eref->choke(rv[u]); chokes++;
                }
                rkey[v] = (int8_t)key;
                eref->note_key(rv[v], kit + key * 8, key, 127);
                ract[v] = 1;
            }
            const uint32_t ratio = step % 4 == 0 ? 0x10000u : step % 4 == 1 ? 0x18000u : step % 4 == 2 ? 0xC000u : 0x10000u + step * 997u;
            for (int blk = 0; blk < 6; blk++)
                for (int u = 0; u < 12; u++) {
                    if (rkey[u] < 0) continue;
                    const int16_t *par = kit + rkey[u] * 8;
                    const int was = ract[u];
                    const int a = od_block(k, u, oa, par, ratio);
                    unsigned r = ratio;
                    eref->render(rv[u], ob_, par, &r);
                    if (eref->finished(rv[u])) ract[u] = 0;
                    adiff += a != ract[u];
                    ends += was && !ract[u];
                    for (int i = 0; i < 128; i++) { diff += oa[i] != ob_[i]; sum = sum * 31 + (uint16_t)oa[i]; }
                    blocks++;
                }
        }
        put_s("T2 run"); put_kv("l1", T2_L1_CLAIMS); put_kv("blocks", blocks); put_kv("diff", diff + adiff); put_kv("vdiff", diff); put_kv("adiff", adiff);
        put_kv("ends", ends); put_kv("chokes", chokes); put_kv("sum", sum); put_kv("accel", oa_sim_calls()); put_s("\n");
        if (oa_sim_calls()) accel_sim(le, kit);
        put_s("T2 done=0x1\n");
        return 0;
    }
#elif defined(T2_ENGINE)
    {   /* the engine reference: built from source (its opus_engine_add renamed), run beside the kennel entry */
        src_opl_init((void *)1);
#ifndef T2_DIRECT
        if (!eref) { put_s("T2 noref\n"); return 1; }
#endif
        int k = -1;
        for (int i = 0; i < oe_count(); i++) {
            const char *n = oe_engine(i)->name; int j = 0;
            while (t2_ref_name[j] && n[j] == t2_ref_name[j]) j++;
            if (!t2_ref_name[j] && !n[j]) k = i;
        }
        if (k < 0) { put_s("T2 notloaded\n"); return 1; }
        const op1_engine_sum_t *en = oe_entry(k);
        const opus_engine *le = oe_engine(k);
#ifdef T2_DIRECT
        eref = le;
#endif
        put_s("T2 engine "); put_s(le->name); put_kv("size", le->size); put_kv("voice", le->voice);
        put_kv("flags", le->size >= 68 ? le->flags : 0); put_kv("mark", (uint32_t)oe_mark(k));
        put_kv("block", !!le->block); put_kv("finished", le->size >= 76 && le->finished); put_kv("page", !!le->page);
        put_kv("page_t2", !!le->page_t2); put_kv("page_t4", le->size >= 72 && le->page_t4);
        put_kv("svg", le->size >= 88 && le->svg); put_kv("shift", le->size >= 100 ? *(const uint32_t *)le->shift_knobs : 0xFFFFFFFFu);
        put_kv("entry_finished", !!en->finished); put_kv("entry_block", !!en->block); put_s("\n");
        int order = 0;
        for (int i = 0; i < reg_n; i++) if (reg_desc[i]->entry == en) { order = 40 + i; put_s("T2 reg-engine "); put_s(reg_name[i]);
            put_kv("extra", reg_desc[i]->extra); put_kv("flags", reg_desc[i]->flags);
            int p2ok = reg_desc[i]->page2 != 0;                 /* a new sound's words 5..7: the file's knobs[5..7] */
            for (int j = 0; p2ok && j < 3; j++) p2ok = reg_desc[i]->page2[j] == (le->knobs[5 + j] < 0 ? 0 : le->knobs[5 + j]);
            put_kv("page2_ok", p2ok); put_kv("p5", reg_desc[i]->page2 ? reg_desc[i]->page2[0] : -1);
            put_kv("p6", reg_desc[i]->page2 ? reg_desc[i]->page2[1] : -1); put_kv("p7", reg_desc[i]->page2 ? reg_desc[i]->page2[2] : -1);
            put_s("\n"); }
        volatile int32_t *pitch = (volatile int32_t *)OP1_PITCH_INC;
        volatile int16_t *knobs = (volatile int16_t *)op1_synth_knobs(0);
        void *self = OP1_VOICE(0);
        static const int16_t W[6][8] = {
            { 0x4ccd, 0x4000, 0x5dc0, 0x0fa0 }, { 0, 0, 32767, 16384 }, { 32767, 32767, 12000, 32767 },
            { 9000, 4000, 20000, 8000 }, { 31000, 2047, 32767, 0 }, { 5000, 30000, 1, 32766 } };
        static int16_t oa[128], ob_[128], ba[64], bb[64], words[8], rpar[8];
        static uint8_t rv[4096] __attribute__((aligned(32)));
        uint32_t diff = 0, bdiff = 0, sum = 0, blocks = 0, cross = 0, samples = 0;
        int prev = 0;
        eref_mark = oe_mark(k);
#ifdef T2_SOLO                                                  /* no reference: the loaded file alone (castle) */
#define REF(x) ((void)0)
#else
#define REF(x) x
#endif
        if (eref && eref->init) REF(eref->init(rv, 0));
        for (int p = 0; p < 6; p++) {
            const int32_t step = 21426316 + p * 3000000;        /* 440 Hz at 88.2 kHz, then higher */
            for (int i = 0; i < 128; i++) pitch[i] = step;
            for (int i = 0; i < 8; i++) { words[i] = W[p][i]; knobs[i] = W[p][i]; rpar[i] = W[p][i]; }
            words[4] = (int16_t)(0x5300 + order); knobs[4] = words[4]; rpar[4] = (int16_t)oe_mark(k);
            en->voice.note_on(self, words);
            REF(eref->note_on(rv, rpar));
            for (int blk = 0; blk < 40; blk++, blocks++) {
                en->voice.render(self, oa, words);
                REF(eref->render(rv, ob_, rpar, (const unsigned *)OP1_PITCH_INC));
                for (int i = 0; i < 128; i++) {
                    diff += oa[i] != ob_[i]; sum = sum * 31 + (uint16_t)oa[i];
                    if (p == 0) { int sg = oa[i] >= 0; if (samples && sg && !prev) cross++; prev = sg; samples++; }
                }
#ifndef T2_DIRECT                                               /* direct: one plugin, one global block state */
                if (le->block) {
                    for (int i = 0; i < 64; i++) ba[i] = bb[i] = (int16_t)((oa[2 * i] >> 1) + (oa[2 * i + 1] >> 1));
                    en->block(ba, 0); REF(eref->block(bb));
                    for (int i = 0; i < 64; i++) bdiff += ba[i] != bb[i];
                }
#endif
            }
            if (en->voice.note_off) en->voice.note_off(self);
            if (eref->release) REF(eref->release(rv, rpar));
            for (int blk = 0; blk < 10; blk++, blocks++) {
                en->voice.render(self, oa, words);
                REF(eref->render(rv, ob_, rpar, (const unsigned *)OP1_PITCH_INC));
                for (int i = 0; i < 128; i++) { diff += oa[i] != ob_[i]; sum = sum * 31 + (uint16_t)oa[i]; }
            }
        }
        /* rising crossings over the first set's 40 blocks at 440 Hz: freq = cross x 88200 / samples */
        put_s("T2 pitch"); put_kv("cross", cross); put_kv("samples", samples); put_kv("hz_x10", cross * 882000u / samples); put_s("\n");
#ifdef T2_SOLO
        /* castle's stress (its quirk moves its voices and the two words that point at them, opus_quirk.c): six voices,
         * a strike every 12 blocks, every other one at the last note's pitch (castle's takeover copies that voice), a
         * note-off 6 blocks later; with the pool, blocks end and begin (kn_l1_tick: the claim renews each block), every
         * third strike lands between blocks (the key thread's path) and page 7's switch goes off and on (state home,
         * the words rebased, fresh again). Its sum must be the same with --pool and without; `bad` counts the words
         * pointing anywhere but at one voice in the copy in use (home, or the synth partition). */
        uint32_t ssum = 0, bad = 0;
        {
            static const int32_t steps[6] = { 21426316, 21426316, 32000000, 32000000, 26000000, 26000000 };
            int on[6] = { 0 };
            for (int i = 0; i < 8; i++) { words[i] = W[2][i]; knobs[i] = W[2][i]; }
            words[4] = (int16_t)(0x5300 + order); knobs[4] = words[4];
            for (int b = 0; b < 360; b++) {
                const int v = (b / 12) % 6, strike = b % 12 == 0;
                int done = 0;
#ifdef T2_POOL
                void kn_l1_tick(void); void kn_l1_enable(int on);
                kn_l1_tick();
                if (strike && (b / 12) % 3 == 2) {               /* between blocks: the key thread's note_on */
                    for (int i = 0; i < 128; i++) pitch[i] = steps[(b / 12) % 6];
                    en->voice.note_on(OP1_VOICE(v), words); on[v] = 1; done = 1;
                }
                kn_l1_begin();
                if (b % 60 == 30) kn_l1_enable(0);
                if (b % 60 == 45) kn_l1_enable(1);
#endif
                if (strike && !done) {
                    for (int i = 0; i < 128; i++) pitch[i] = steps[(b / 12) % 6];
                    en->voice.note_on(OP1_VOICE(v), words); on[v] = 1;
                }
                if (b % 12 == 6 && en->voice.note_off) en->voice.note_off(OP1_VOICE((v + 4) % 6));
                for (int u = 0; u < 6; u++) {
                    if (!on[u]) continue;
                    for (int i = 0; i < 128; i++) pitch[i] = steps[u];
                    en->voice.render(OP1_VOICE(u), oa, words);
                    for (int i = 0; i < 128; i++) ssum = ssum * 31 + (uint16_t)oa[i];
                }
                if (le->block) {
                    for (int i = 0; i < 64; i++) ba[i] = (int16_t)(oa[2 * i] >> 1);
                    en->block(ba, 0);
                    for (int i = 0; i < 64; i++) ssum = ssum * 31 + (uint16_t)ba[i];
                }
                bad += oe_vptr_bad(k);
            }
        }
        put_s("T2 stress"); put_kv("ssum", ssum); put_kv("bad", bad); put_s("\n");
        diff += bad;
#endif
        put_s("T2 run"); put_kv("l1", T2_L1_CLAIMS); put_kv("blocks", blocks); put_kv("diff", diff + bdiff); put_kv("vdiff", diff); put_kv("bdiff", bdiff);
        put_kv("sum", sum); put_kv("accel", oa_dx_calls()); put_s("\n");
#ifndef T2_SOLO
        {   /* the engine services: live words (the newest voice's as it renders them, 3 blocks), the sound name (the slot's
             * "name"), text objects per file and slot, filled and hollow dots, a still part kept and put back */
            int (*live)(int16_t *) = (int (*)(int16_t *))ob_import("op" "us_engine_live");
            int (*kn)(int16_t *) = (int (*)(int16_t *))ob_import("op" "us_engine_knobs");
            int (*sname)(char *, int) = (int (*)(char *, int))ob_import("op" "us_engine_sound_name");
            volatile uint32_t *blk = (volatile uint32_t *)0xFF8016E0;
            for (int i = 0; i < 8; i++) { words[i] = W[3][i]; knobs[i] = W[3][i]; }
            words[4] = knobs[4] = (int16_t)(0x5300 + order);
            words[0] = 1234;                                    /* the voice hears 1234 (an LFO), the sound keeps W[3][0] */
            *blk = 100;
            en->voice.note_on(self, words); en->voice.render(self, oa, words);
            int16_t lw[8], kw[8];
            const int l1 = live(lw), k1 = kn(kw);
            const int live_ok = l1 == 1 && lw[0] == 1234 && lw[1] == W[3][1] && lw[4] == (int16_t)oe_mark(k) && k1 == 1 && kw[0] == 1234;
            *blk = 104;                                         /* 4 blocks later: the stored words */
            const int l2 = live(lw);
            const int stored_ok = l2 == 0 && lw[0] == W[3][0] && lw[4] == (int16_t)oe_mark(k);
            svc_on = 1;
            char nb[24];
            const int nl = sname(nb, sizeof nb);
            const int name_ok = nl == 8 && nb[0] == 'm' && nb[7] == 'e' && !nb[8];
            *(volatile uint32_t *)0x01D08520 = (uint32_t)fake_pix;   /* the raster is the picture (op1_raster_live) */
            void oe_page_frame(void *scr, const ob_file *f, int which, void (*fn)(void));
            static uint32_t scr[8];
            oe_page_frame(scr, 0, 0, svc_page);
            const int text_ok = n_ctor == 3 && ctor_rec[0].obj != ctor_rec[1].obj && ctor_rec[0].size == 24 && ctor_rec[1].size == 6
                && ctor_rec[0].x == 160 << 10 && ctor_rec[2].align == 2 && ctor_rec[0].align == 0;
            const int dot_ok = svc_dot[0] > svc_dot[1] && svc_dot[1] > 0 && svc_dot[2] == 0;
            for (svc_round = 0; svc_round < 4; svc_round++) { clear_pix(); oe_page_frame(scr, 0, 0, svc_still_page); }
            const int still_ok = svc_still[0] == 0 && svc_still[1] == 0 && svc_still[2] == 1 && svc_still[3] == 1;
            put_s("T2 services"); put_kv("live", live_ok); put_kv("stored", stored_ok); put_kv("name", name_ok); put_kv("text", text_ok);
            put_kv("dot", dot_ok); put_kv("filled", svc_dot[0]); put_kv("hollow", svc_dot[1]); put_kv("still", still_ok);
            put_kv("s0", (uint32_t)svc_still[0]); put_kv("s2", (uint32_t)svc_still[2]); put_kv("ctors", (uint32_t)n_ctor); put_kv("nl", (uint32_t)nl); put_kv("n0", (uint32_t)(uint8_t)nb[0]); put_s("\n");
            svc_on = 0;
            if (en->voice.note_off) en->voice.note_off(self);
        }
#endif
        if (oa_dx_calls()) {    /* the accelerator against the file's own engine_render on copies of one voice: the eight
                                 * factory voices, three pitches, held then released (the amplitude stages, the silent end) */
            static uint32_t va[0x184 / 4 + 4], vb[0x184 / 4 + 4];
            static int16_t p8[8];
            uint32_t xd = 0, sd = 0, cases = 0, nz = 0, algs = 0;
            for (int n = 0; n < 24; n++) {
                for (int i = 0; i < 8; i++) p8[i] = W[n % 6][i];
                p8[4] = (int16_t)oe_mark(k); p8[5] = 0; p8[6] = (int16_t)(n % 8);
                const int32_t st = 12000000 + n * 1700000;
                for (int i = 0; i < 128; i++) pitch[i] = st;
                {   /* the kept sound (sound_data, zero +0xC: flags, amp[8] at +0x12, patch[156] at +0x1A): half the cases
                     * with their own amplitude envelope (attack, decay, sustain, release, peak, hold), every fourth with
                     * a kept patch (the current one, its algorithm moved) */
                    uint8_t *sd = oa_dx_zero() + 0xC;
                    sd[1] = 0;
                    if (n % 2) {
                        static const uint8_t am[8] = { 0, 30, 70, 50, 90, 20, 0, 0 };
                        sd[1] |= 2;
                        for (int i = 0; i < 8; i++) sd[0x12 + i] = am[i];
                        sd[0x12] = (uint8_t)(n % 6 == 1 ? 0 : 10 + (n * 7) % 60);
                    }
                    if (n % 4 == 3) {
                        sd[1] |= 1;
                        for (int i = 0; i < 156; i++) sd[0x1A + i] = oa_dx_zero()[0x184 + i];
                        sd[0x1A + 0x86] = (uint8_t)(n % 32);
                    }
                }
                le->init(va, n % 6);
                le->note_on(va, p8);
                for (int i = 0; i < 0x184 / 4; i++) vb[i] = va[i];
                for (int b = 0; b < 160; b++) {
                    if (b == 1 && n >= 8) {                         /* other algorithms on the same voice, both copies:
                                                                     * the feedback loops (3: three operators, 5: two) too */
                        const uint8_t al = (uint8_t)(n >= 16 ? (n & 1 ? 3 : 5) : (n * 5) & 31);
                        ((uint8_t *)va)[0x164] = al; ((uint8_t *)vb)[0x164] = al;
                    }
                    if (b == 1) algs |= 1u << (((const uint8_t *)va)[0x164] & 31);
                    if (b == 50 && le->release) { le->release(va, p8); le->release(vb, p8); }
                    if (le->block) le->block(ba);                   /* the LFO's sample and delay move */
                    le->render(va, oa, p8, (const unsigned *)OP1_PITCH_INC);
                    oa_dx_render(vb, ob_, p8, (const unsigned *)OP1_PITCH_INC);
                    for (int i = 0; i < 128; i++) { xd += oa[i] != ob_[i]; nz += oa[i] != 0; }
                    for (int i = 0; i < 0x184 / 4; i++) sd += va[i] != vb[i];
                    cases++;
                }
            }
            put_s("T2 accel dx"); put_kv("blocks", cases); put_kv("nonzero", nz); put_kv("algorithms", algs); put_kv("diff", xd); put_kv("sdiff", sd); put_s("\n");
        }
        put_s("T2 done=0x1\n");
        return 0;
    }
#else
    /* the reference */
    src_opl_init((void *)1);
    if (!ref) { put_s("T2 noref\n"); return 1; }
    const opus_effect *src_ref = ref;
    int k = -1;
    for (int i = 0; i < reg_n; i++) {
        const char *n = reg_name[i];
        int j = 0; while (t2_ref_name[j] && n[j] == t2_ref_name[j]) j++;
        if (!t2_ref_name[j] && (!n[j] || n[j] == '_')) k = i;
    }
    if (k < 0) { put_s("T2 notloaded\n"); return 1; }
    const op1_fx_stereo_t *fx = ox_entry(k);
#ifdef T2_DIRECT
    ref = ox_effect(k);                                         /* the loaded struct called directly: the adapter alone */
    (void)src_ref;
#else
    (void)src_ref;
#endif
    opus_need n0 = { 0 }, n1 = { 0 };
    ref->need(0, &n0);
    if (ref->stereo) ref->need(1, &n1);
    put_s("T2 type "); put_s(reg_name[k]); put_kv("state", n0.state); put_kv("bulk", n0.bulk); put_kv("fast", n0.fast);
    put_kv("sbulk", n1.bulk); put_s("\n");
    for (int i = 0; i < 4; i++) { put_s("T2 limits"); put_kv("i", i); put_kv("lo", (uint16_t)ref->limits[i][0]);
        put_kv("hi", (uint16_t)ref->limits[i][1]); put_kv("st", (uint16_t)ref->limits[i][2]); put_kv("press", fx->mono.press[i]); put_s("\n"); }
    static const int16_t W[6][8] = {
        { 19968, 15360, 0, 32767 }, { 0, 0, 32767, 16384 }, { 32767, 32767, 12000, 32767 },
        { 9000, 4000, 20000, 8000 }, { 31000, 2047, 32767, 0 }, { 5000, 30000, 1, 32766 } };
    uint32_t diff = 0, sum = 0, blocks = 0, settle = 0;
    for (int pass = 0; pass < 2; pass++) {                      /* 0 mono (synth position 0), 1 stereo (master, 2) */
        const int pos = pass ? 2 : 0;
        if (pass && !fx->render_stereo) break;
        fx->mono.init(pos);
        for (int i = 0; i < 64; i++) a[i] = al[i] = ar[i] = 0;
        const uint32_t settle0 = settle;
        while (!ox_ready(k, pos) && settle < 400) {             /* the bulk clear: dry blocks; the last one renders */
            if (pass) fx->render_stereo(pos, al, ar, W[0]); else fx->mono.render(pos, a, W[0]);
            settle++;
        }
        opus_need *nd = pass ? &n1 : &n0;
        opus_fx rf = { rstate[pass], 0, 0, pass };
        for (uint32_t i = 0; i < sizeof rstate[0]; i++) rstate[pass][i] = 0;
        for (uint32_t i = 0; i < sizeof rbulk; i++) rbulk[i] = 0;
        rf.bulk = nd->bulk ? rbulk : 0;
        rf.fast = nd->fast ? rbulk + ((nd->bulk + 31) & ~31u) : 0;
        ref->init(&rf);
        if (settle != settle0) {                                /* the block that finished the clear also rendered */
            for (int i = 0; i < 64; i++) b[i] = bl[i] = br[i] = 0;
            if (pass) ref->stereo(&rf, bl, br, ox_params(k, pos)); else ref->mono(&rf, b, ox_params(k, pos));
        }
        for (int p = 0; p < 6; p++)
            for (int blk = 0; blk < 40; blk++, blocks++) {
                for (int i = 0; i < 64; i++) { a[i] = b[i] = al[i] = bl[i] = noise(i); ar[i] = br[i] = noise(i + 7); }
                if (!pass) { fx->mono.render(pos, a, W[p]); ref->mono(&rf, b, ox_params(k, pos)); }
                else { fx->render_stereo(pos, al, ar, W[p]); ref->stereo(&rf, bl, br, ox_params(k, pos)); }
                uint32_t d0 = diff;
                for (int i = 0; i < 64; i++) {
                    if (!pass) { diff += a[i] != b[i]; sum = sum * 31 + (uint16_t)a[i]; }
                    else { diff += (al[i] != bl[i]) + (ar[i] != br[i]); sum = sum * 31 + (uint16_t)al[i] + (uint16_t)ar[i]; }
                }
                if (diff != d0 && !d0) { put_s("T2 first"); put_kv("pass", pass); put_kv("p", p); put_kv("blk", blk);
                    for (int i = 0; i < 4; i++) { put_kv("a", (uint16_t)(pass ? al[i] : a[i])); put_kv("b", (uint16_t)(pass ? bl[i] : b[i])); } put_s("\n"); }
            }
    }
    const int16_t *pp = ox_params(k, 0);
    {   /* the shift layer (kn_foreign_fx_shift): Shift + turns against the loaded struct's own shift_knob called on a
         * plain copy of its defaults (the file's: plate 2.x tops decay at 0.9, the rebuilt source at 1.0) */
        const opus_effect *lr = ox_effect(k);
        uint32_t bad = 0, turns = 0, layer = lr->shift_knob != 0;
        int16_t w[8], e[8], c[8];
        for (int i = 0; i < 8; i++) { w[i] = i < 4 ? W[0][i] : 0; e[i] = lr->defaults[i]; }
        static const op1_fx_t other;
        bad |= kn_foreign_fx_shift(&other, w, 0, 4096) != 0;           /* not a bridged FX: not taken */
        fx->mono.render(0, a, w);                                       /* words 5..7 = 0: the defaults */
        for (int i = 4; i < 8; i++) bad |= (uint32_t)(ox_params(k, 0)[i] != lr->defaults[i]) << 1;
        static const struct { int8_t knob; int16_t delta; int8_t steps; } ev[] = {
            { 0, 4096, 1 }, { 1, 4096, 1 }, { 0, 2048, 0 }, { 0, 2048, 1 }, { 1, -4096, -1 }, { 1, -4096, -1 },
            { 0, 28672, 7 }, { 0, 28672, 7 }, { 0, 28672, 7 }, { 0, 28672, 7 }, { 0, 28672, 7 },   /* past the top */
            { 1, -32768, -8 }, { 1, -32768, -8 }, { 1, 8192, 2 }, { 2, 4096, 1 }, { 3, -4096, -1 } };
        uint32_t fine = 0;
        for (unsigned j = 0; j < sizeof ev / sizeof ev[0]; j++) {
            int16_t before[8];
            fx->mono.render(0, a, w);
            int32_t cur = ox_params(k, 0)[ev[j].knob & 3];
            for (int i = 0; i < 8; i++) { before[i] = w[i]; c[i] = e[i]; }
            const int r = kn_foreign_fx_shift(&fx->mono, w, ev[j].knob, ev[j].delta);
            const int want = layer ? lr->shift_knob(c, ev[j].knob, ev[j].steps) : 0;
            if (want) for (int i = 4; i < 8; i++) e[i] = c[i];
            bad |= (uint32_t)(r == 0) << 2;                             /* every Shift + turn is the bridge's */
            if (!want) {                                                /* the Opus core's stock move: 1/16 a turn */
                const int kn = ev[j].knob;
                const int32_t lo = lr->limits[kn][0], hi = lr->limits[kn][1], x = lr->limits[kn][2] * (ev[j].delta >> 4);
                int32_t q = x >> 15; if ((x & 0x7fff) > 0x4000 || ((x & 0x7fff) == 0x4000 && (q & 1))) q++;
                int32_t want_p = cur + q; want_p = want_p < lo ? lo : want_p > hi ? hi : want_p;
                fx->mono.render(0, a, w);
                const int32_t d = ox_params(k, 0)[kn] - want_p;
                bad |= (uint32_t)(d > 4 || d < -4) << 3;
                for (int i = 0; i < 8; i++) bad |= (uint32_t)(i != kn && w[i] != before[i]) << 10;   /* that word only */
                fine++;
                continue;
            }
            for (int i = 0; i < 5; i++) bad |= (uint32_t)(w[i] != before[i]) << 4;   /* words 0..4 never */
            turns++;
            bad |= (uint32_t)(w[5] != e[4] || w[6] != e[5]) << 5;       /* exact */
            for (int i = 5; i < 8; i++) bad |= (uint32_t)(w[i] < 0) << 6;   /* R246's range */
            for (int i = 6; i < 8; i++) { const int d = (int)((w[7] >> (i == 6 ? 0 : 8)) & 127) * 32767 / 127 - e[i];
                bad |= (uint32_t)(d > 130 || d < -130) << 7; }          /* 7 bits */
        }
        fx->mono.render(0, a, w);                                       /* what the effect hears */
        for (int i = 4; i < 8; i++) bad |= (uint32_t)(i < 6 ? layer && ox_params(k, 0)[i] != e[i] : !layer && ox_params(k, 0)[i] != lr->defaults[i]) << 8;
        int16_t sv[8], q[8];
        for (int i = 0; i < 8; i++) { sv[i] = w[i]; q[i] = ox_params(k, 0)[i]; }   /* saved, then loaded: the same */
        fx->mono.render(0, a, sv);
        for (int i = 0; i < 8; i++) bad |= (uint32_t)(ox_params(k, 0)[i] != q[i]) << 9;
        put_s("T2 shift"); put_kv("layer", layer); put_kv("turns", turns); put_kv("fine", fine); put_kv("bad", bad);
        for (int i = 4; i < 8; i++) put_kv("p", (uint16_t)ox_params(k, 0)[i]);
        for (int i = 5; i < 8; i++) put_kv("w", (uint16_t)w[i]);
        put_s("\n");
    }
    {   /* an LFO type's move of the shift layer (opus_lfo.c s_move group 2, params 4..7 -> ox_lfo_shift) on a stage copy:
         * own units, clamped; the other params kept (defaults while bit 7 is clear); not a bridged FX: -1 */
        const opus_effect *lr = ox_effect(k);
        const int layer = lr->shift_knob != 0;
        uint32_t bad = 0, moved = 0;
        int16_t w[8];
        for (int i = 0; i < 8; i++) w[i] = i < 4 ? W[0][i] : 0;
        w[4] = (int16_t)(OP1_ENGINE_MAGIC + kn_plugin_order(1, reg_name[k]));
        int16_t st[8];
        for (int i = 0; i < 8; i++) st[i] = w[i];
        st[4] = (int16_t)(OP1_ENGINE_MAGIC + 3);                         /* not a bridged FX */
        bad |= (uint32_t)(ox_lfo_shift(st, 4, 1000) != -1);
        bad |= (uint32_t)(st[5] || st[6] || st[7]) << 1;
        static const struct { int8_t p; int32_t d; } mv[] = { { 4, 1000 }, { 5, -2000 }, { 6, 9000 }, { 7, -100000 }, { 4, 100000 } };
        int32_t e[8];
        for (int i = 0; i < 8; i++) e[i] = lr->defaults[i];
        for (unsigned j = 0; j < sizeof mv / sizeof mv[0]; j++) {
            int16_t before[8];
            for (int i = 0; i < 8; i++) before[i] = w[i];
            const int r = ox_lfo_shift(w, mv[j].p, mv[j].d);
            bad |= (uint32_t)(r != layer) << 2;
            if (!layer) { for (int i = 0; i < 8; i++) bad |= (uint32_t)(w[i] != before[i]) << 3; continue; }
            moved++;
            const int p = mv[j].p;
            int32_t v = e[p] + (mv[j].d > 32767 ? 32767 : mv[j].d < -32768 ? -32768 : mv[j].d);
            e[p] = v < lr->limits[p][0] ? lr->limits[p][0] : v > lr->limits[p][1] ? lr->limits[p][1] : v;
            for (int i = 0; i < 5; i++) bad |= (uint32_t)(w[i] != before[i]) << 4;   /* the knobs and selector never */
            bad |= (uint32_t)!(w[7] & 0x80) << 5;
            fx->mono.render(0, a, w);
            for (int i = 4; i < 8; i++) {
                const int32_t d = ox_params(k, 0)[i] - (i < 6 ? e[i] : (e[i] * 127 + 16383) / 32767 * 32767 / 127);
                bad |= (uint32_t)(d > 1 || d < -1) << 6;
                e[i] = ox_params(k, 0)[i];                              /* (7-bit fields: what the next move starts from) */
            }
        }
        put_s("T2 lfoshift"); put_kv("layer", (uint32_t)layer); put_kv("moved", moved); put_kv("bad", bad);
        for (int i = 4; i < 8; i++) put_kv("p", (uint16_t)ox_params(k, 0)[i]);
        put_s("\n");
    }
    {   /* a sound saved on Opus (ox_from_opus): its name with Opus words opens here with the same params; its alias too;
         * kennel's sound (a selector in word 4) is left alone */
        const opus_effect *lr = ox_effect(k);
        const int layer = lr->shift_knob != 0;
        uint32_t bad = 0;
        static const int16_t frac[8] = { 10923, 22937, 3277, 29491, 9000, 21000, 5000, 30000 };
        int16_t P[8], w[8];
        for (int i = 0; i < 8; i++) { const int32_t lo = lr->limits[i][0], hi = lr->limits[i][1];
            P[i] = hi > lo ? (int16_t)(lo + (int32_t)(((int64_t)frac[i] * (hi - lo)) >> 15)) : lr->defaults[i]; w[i] = P[i]; }
        const char *sv = ox_from_opus(lr->name, w);
        bad |= (uint32_t)!(sv && ob_eq(sv, reg_name[k]));
        bad |= (uint32_t)(w[4] != (int16_t)(OP1_ENGINE_MAGIC + kn_plugin_order(1, reg_name[k]))) << 1;
        fx->mono.render(0, a, w);
        for (int i = 0; i < 8; i++) {
            const int32_t lo = lr->limits[i][0], hi = lr->limits[i][1], st = lr->limits[i][2];
            int32_t want = P[i], tol = (hi - lo) / 16384 + 1;
            if (i < 4 && (st <= 0 || hi <= lo)) want = lr->defaults[i];
            if (i >= 4 && !layer) want = lr->defaults[i];
            if (i >= 6 && layer) tol = (hi - lo) / 127 + 1;
            const int32_t d = ox_params(k, 0)[i] - want;
            bad |= (uint32_t)(d > tol || d < -tol) << (2 + i);
        }
        int16_t ks[8];                                                   /* kennel's own sound of that name */
        for (int i = 0; i < 8; i++) ks[i] = (int16_t)(1000 + i);
        ks[4] = (int16_t)(OP1_ENGINE_MAGIC + 7);
        bad |= (uint32_t)(ox_from_opus(lr->name, ks) != 0 || ks[0] != 1000 || ks[4] != (int16_t)(OP1_ENGINE_MAGIC + 7)) << 10;
        bad |= (uint32_t)(ox_from_opus("nosuchfx", ks) != 0) << 11;
        const char *al = lr->size >= 0x78 ? *(const char *const *)((const uint8_t *)lr + 0x74) : 0;
        uint32_t aliased = 0;
        if (al && *al) {                                                 /* its first alias */
            char an[24]; int n = 0;
            while (al[n] && al[n] != ' ' && n < 23) { an[n] = al[n]; n++; }
            an[n] = 0;
            for (int i = 0; i < 8; i++) w[i] = P[i];
            const char *as = ox_from_opus(an, w);
            aliased = as && ob_eq(as, reg_name[k]);
            bad |= (uint32_t)!aliased << 12;
            put_s("T2 alias "); put_s(an); put_s("\n");
        }
        put_s("T2 fromopus"); put_s(" saved="); put_s(sv ? sv : "-"); put_kv("aliased", aliased); put_kv("bad", bad);
        for (int i = 0; i < 8; i++) put_kv("w", (uint16_t)w[i]);
        put_s("\n");
    }
    put_s("T2 params"); for (int i = 0; i < 8; i++) put_kv("p", (uint16_t)pp[i]); put_s("\n");
    put_s("T2 run"); put_kv("l1", T2_L1_CLAIMS); put_kv("blocks", blocks); put_kv("settle", settle); put_kv("diff", diff); put_kv("sum", sum);
    put_kv("r246", t2_r246_calls); put_s("\n");
    put_s("T2 done=0x1\n");
    return 0;
#endif
}
