/* test.input: the bridge's native check of opus_on_line_input and opus_drum_select_key (core 2.58 / 2.57), built with
 * the Opus plugin kit against its sdk (opus_plugin.h), our own source.
 * - Line input: the handler measures each block's two sides (peak, top 16 bits) and counts the blocks; its mode
 *   decides what R246 gets back: 0 both sides as they came, 1 the right side zeroed (R246 sums the sides, so the
 *   monitored input drops 6 dB when both carry the same signal), 2 both zeroed (the input gone).
 * - The sequencer key (0x15) is taken: alone it steps the line mode 0 -> 1 -> 2 -> 0; with shift held it makes the
 *   drum's next key (current + 1, mod 24) the current one through opus_drum_select_key.
 * - Every key press, after its handling, logs "key K drum D line M blocks B peak L R" (D from opus_drum_key; the
 *   peaks are the largest since the last line), so a native run reads the services' effect from the boot log.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "op1fw.h"
#include "opus_plugin.h"

#define KEY_SEQ   0x15
#define KEY_SHIFT 0x26

static struct opl_self *me;
static volatile int line_mode;                 /* 0 pass, 1 right side zeroed, 2 both zeroed */
static volatile unsigned line_blocks;
static volatile int peak_l, peak_r;            /* since the last log line (16-bit scale) */
static int shift_down;
unsigned input_test_blocks;                    /* for a debugger: the same count */

static void line_in(int *stereo, unsigned frames)            /* the audio interrupt: integers, no calls */
{
    int pl = peak_l, pr = peak_r;
    for (unsigned i = 0; i < frames; i++) {
        int l = stereo[2 * i] >> 16, r = stereo[2 * i + 1] >> 16;
        if (l < 0) l = -l;
        if (r < 0) r = -r;
        if (l > pl) pl = l;
        if (r > pr) pr = r;
    }
    peak_l = pl; peak_r = pr;
    if (line_mode >= 1)
        for (unsigned i = 0; i < frames; i++) stereo[2 * i + 1] = 0;
    if (line_mode == 2)
        for (unsigned i = 0; i < frames; i++) stereo[2 * i] = 0;
    line_blocks++;
    input_test_blocks = line_blocks;
}

static char *put_num(char *p, int v)
{
    char t[12];
    int n = 0;
    unsigned u = v < 0 ? (unsigned)-v : (unsigned)v;
    if (v < 0) *p++ = '-';
    do { t[n++] = (char)('0' + u % 10u); u /= 10u; } while (u);
    while (n) *p++ = t[--n];
    return p;
}
static char *put_text(char *p, const char *s) { while (*s) *p++ = *s++; return p; }

static int on_key(int key, int pressed)                      /* before R246: the sequencer key is ours */
{
    if (key == KEY_SHIFT) { shift_down = pressed; return 0; }
    if (key != KEY_SEQ) return 0;
    if (!pressed) return 1;
    if (shift_down) {
        short par[8];
        int k = opus_drum_key(par);
        opus_drum_select_key((k + 1) % 24);
    } else {
        line_mode = (line_mode + 1) % 3;
    }
    return 1;
}

static void after_key(int key, int pressed)                  /* the KeyHandler thread, after the handling */
{
    char line[96], *p = line;
    short par[8];
    if (!pressed) return;
    int d = opus_drum_key(par);
    int pl = peak_l, pr = peak_r;
    peak_l = 0; peak_r = 0;
    p = put_text(p, "key "); p = put_num(p, key);
    p = put_text(p, " drum "); p = put_num(p, d);
    p = put_text(p, " w0 "); p = put_num(p, par[0]);
    p = put_text(p, " line "); p = put_num(p, line_mode);
    p = put_text(p, " blocks "); p = put_num(p, (int)line_blocks);
    p = put_text(p, " peak "); p = put_num(p, pl);
    p = put_text(p, " "); p = put_num(p, pr);
    *p = 0;
    opus_log(me, line);
}

int opl_init(struct opl_self *self)
{
    me = self;
    opus_on_line_input(self, line_in);
    opus_on_key(self, on_key);
    opus_on_key_after(self, after_key);
    opus_log(self, "input test ready");
    return 0;
}
