/*
 * The Opus plugin bridge (phase 2: loader, effects): kennel runs Opus 2 `.opmod` plugin files unmodified. Core code,
 * compiled into the firmware like kennel/ (make_firmware.py lists this folder); nothing here is exported to .knl files.
 * Only this folder may name Opus, its file format and its services (names_check ALLOW_DIRS). The core side it uses is
 * kennel/kn_foreign.h (the boot stage, transactions, registration under a saved name). ARCHITECTURE.md "Opus bridge".
 *
 * Structures mirror the Opus plugin kit's documented layouts (its GPL sdk/opus_plugin.h: offsets and meanings only,
 * our own declarations). A newer Opus may make a struct longer: every struct starts with its size, and the bridge reads
 * only the fields it knows.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef OPUS_BRIDGE_H
#define OPUS_BRIDGE_H
#include <stdint.h>
#include "../op1_plugin.h"                /* op1_beat_t */

/* ---- the file (.opmod format 1): a 0x60-byte header, the manifest text, one image, tables, strings ---- */
#define OPMOD_MAGIC     0x444D504Fu        /* "OPMD" */
#define OPMOD_HDR       0x60u
#define OPMOD_MAX_IMAGE (1u << 20)          /* image and zero fill, each */
#define OPMOD_F_CODE    1u
#define OPMOD_F_APART   8u                  /* zero-fill relocations carry REL_ZERO: the zero fill may lie apart */
#define OPMOD_MAX_IMPORTS 96
#define OPMOD_MAX_FILE  (512u * 1024u)       /* the bridge reads a whole file into one buffer */

typedef struct {                            /* a checked file: offsets into its bytes */
    const uint8_t *d;
    uint32_t size, crc;
    uint32_t man_off, man_len, img_off, img_len, zero, entry, imp_off, imp_n, rel_off, rel_n, str_off, str_len;
    uint32_t flags, exp_off, exp_n, pl_n;
} ol_file;

/* header, tables, names and every relocation checked; nothing written. 0, or the reason ("damaged: crc") */
const char *ol_check(const uint8_t *d, uint32_t size, ol_file *f);
/* import i's name (inside the strings: ol_check made sure) */
const char *ol_import_name(const ol_file *f, uint32_t i);
const char *ol_export(const ol_file *f, uint32_t i, uint32_t *offset);
/* the image copied to base, its zero fill cleared at zero_at (base + img_len when the file has no OPMOD_F_APART),
 * relocated against addr[] (one address per import); returns the entry's address */
uint32_t ol_place(const ol_file *f, const uint32_t *addr, uint8_t *base, uint8_t *zero_at);
/* a manifest line's value: the first line starting with key and white space; *len its length (to the line's end, white
 * space trimmed); n: which one (0 the first). 0 when there is none */
const char *ol_manifest(const ol_file *f, const char *key, int n, uint32_t *len);

/* ---- the services' structs (sdk/opus_plugin.h's layouts) ---- */
typedef struct opl_self {
    uint32_t size;                          /* sizeof (struct opl_self) as this core knows it: 16 */
    const char *id;                         /* the manifest's id ("opus.bitcrush") */
    const char *folder;                     /* /yaffs2/mod/<id> */
    int slot;                               /* the file's place in the bridge's list */
} opl_self;

typedef struct { uint32_t state, bulk, fast, fast_moves; } opus_need;
typedef struct { void *state, *bulk, *fast; int stereo; } opus_fx;
typedef struct {
    const char *label[4], *value[4];
    const int16_t *wave[3];
    int waves;
    const char *caption;
} opus_fx_view;
#define OPUS_FX_WAVE 128

typedef struct opus_effect {
    uint32_t size;
    const char *name;
    int16_t defaults[8];
    int16_t limits[8][3];                   /* {min, max, step}; step 0: no knob moves it */
    void (*need)(int stereo, opus_need *n);
    void (*init)(opus_fx *fx);
    void (*mono)(opus_fx *fx, int16_t *buf, const int16_t *par);
    void (*stereo)(opus_fx *fx, int16_t *l, int16_t *r, const int16_t *par);
    void (*view)(const int16_t *par, opus_fx_view *v);
    int (*shift_knob)(int16_t *par, int encoder, int detents);
    /* version 2 ends here (0x60); core 2.31+: svg, screen_init, screen_draw, page_key, page_turn, aliases, page */
} opus_effect;
#define OPUS_EFFECT_V2 0x60u

/* ---- the bridge's per-file record (opus_boot.c) ---- */
#define OB_SETTINGS 8
typedef struct ob_file {
    opl_self self;                          /* first: a plugin's self pointer is its record */
    uint32_t img_lo, img_hi;                /* its code: registered callbacks must lie inside */
    char name[16];                          /* the file's name without ".opmod" */
    char feat[24];                          /* its settings' owner name ("opus_chorus": the id, '.' as '_') */
    uint8_t n_set;
    struct { const char *key; int32_t def; uint8_t choices; } set[OB_SETTINGS];
    void (*on_setting)(const char *name, int value);
    void (*main_pass)(void);                /* opus_on_main_pass: its first engine type's service calls it */
    uint32_t lease_total;                   /* its fast leases' bytes, each 32-byte aligned (opus_fast.c) */
    uint32_t laid[4], lease_used[4];        /* per L1 partition: the front its leases were laid out after (+1), their bytes */
    uint8_t front_off[4];                   /* 1: the adapter's front stays home there (its leases use the room) */
    const struct ob_quirk *quirk;           /* a known file's own handling (opus_quirk.c), 0 for the generic path */
    uint32_t *vptr[2];                      /* the quirk's voice-pointer words, resolved in the image / zero fill */
    uint8_t *img, *zero_at;                 /* where its image and zero fill were placed (an accelerator binds to them) */
    uint32_t zero_len;                      /* its zero fill's bytes */
} ob_file;
extern ob_file *ob_cur;                     /* the file whose opl_init runs, 0 outside */
int ob_inside(const ob_file *f, const void *fn);   /* a callback in the file's image (Blackfin code: even) */
int ob_owns(const ob_file *f, const void *p);      /* data in the file's image or zero fill (its strings, its buffers) */

/* ---- per-file quirks (opus_quirk.c): plugin-specific handling for CPU, matched by the manifest's id and version and
 * the whole file's sha256, so an unknown or changed file keeps the generic path ---- */
#define OQ_MOVES     1u                     /* an engine's voices move into L1 although the file lacks the flag */
#define OQ_VPTR      2u                     /* ... and vptr[] are words holding a pointer to one voice's state: rebased */
#define OQ_PLACE     4u                     /* its pages placed OQ_INSET px in (opus_place.h); place_at: its rows checks */
typedef struct ob_quirk {
    const char *id, *version;
    uint8_t sha[32];                        /* the whole .opmod file */
    uint32_t flags;
    uint32_t vptr[2];                       /* OQ_VPTR: offsets from the image's start (img_len and up: the zero fill) */
    const char *what;                       /* the log line's reason */
    uint8_t accel;                          /* accel/oa.h: OA_SIM, OA_DX (kennel's kernels render it), 0 none */
    uint16_t place_at[3];                   /* OQ_PLACE: image offsets of its 320 / 376 / 400 rows immediates */
    uint16_t text_new_at;                   /* OQ_PLACE: its fw_text_new stub (P1.L = ..; P1.H = ..; JUMP (P1)) */
} ob_quirk;
/* the render an engine or drum type of file f calls: the file's own, or its quirk's accelerator (accel/oa.c, logged) */
typedef void (*ob_render_fn)(void *voice, short *out, const short *par, const unsigned *pitch);
ob_render_fn ob_render_for(ob_file *f, ob_render_fn own);
/* the quirk for a checked file (id, version, then the hash only when they match a row), or 0 */
const ob_quirk *ob_quirk_find(const ol_file *of, const char *id, uint32_t idn, const char *ver, uint32_t vn);
void ob_sha256(const uint8_t *d, uint32_t n, uint8_t out[32]);
/* OQ_PLACE (opus_quirk.c, opus_place.h): at load the file's rows checks take the placed page's rows (oq_load, before
 * the cache sync); a page's draw of that file runs between oq_page_begin and oq_page_end (the screen matrix swapped),
 * and the page's own pixels ask oq_page_rows for its rows and the memory rows it starts at (0 when not placed) */
void oq_load(ob_file *f);
void oq_page_begin(const ob_file *f, void *raster);
void oq_page_end(void);
int oq_page_rows(const void *raster, int *off);
void oq_text_at(int32_t *x_q10, int *y);   /* a text's place in the placed page (R246 text takes only the translation) */

/* ---- import table (opus_imports.c): sorted by name ---- */
typedef struct { const char *name; uint32_t addr; } ob_sym;
uint32_t ob_import(const char *name);       /* 0: this core does not have it */
int ob_table_sorted(void);                  /* tests: the table's size when sorted, else 0 */
/* libraries' exports (orbit3d's o3_*): recorded as each library loads, before the files that need it */
int ob_lib_add(const char *id, const char *version, const ol_file *f, uint32_t base);   /* 0 ok, -1 no room */
uint32_t ob_lib_import(const char *name);   /* 0: no loaded library exports it */
int ob_lib_has(const char *id, const char *min_version);   /* 1 loaded at that version or later */

/* ---- effects (opus_fx.c) ---- */
#define OX_TYPES 8                          /* effect types for all files (Opus's own limit is 8) */
int opus_effect_register(opl_self *self, const opus_effect *e);
const char *ox_saved_name(const char *name, char *out);    /* D4: "plate" -> "plate_o" when kennel has the name */
int ox_count(void);
void ox_rollback(int n);                    /* back to n types (a refused file's) */
/* tests (tier 2): the kennel entry of type k (an op1_fx_stereo_t), whether position pos runs (its bulk cleared and
 * the type's init done), the Opus params the last render used */
const void *ox_entry(int k);
int ox_ready(int k, int pos);
const int16_t *ox_params(int k, int pos);
const opus_effect *ox_effect(int k);       /* tests: the registered struct */
/* an LFO move (opus_lfo_move group 2, param p 4..7) on the FX stage words w of the pass: when w[4] selects a bridged
 * type with a shift layer, its param p moves by delta in its own units (clamped to its limits) in w[5..7] (bit 7 set);
 * 1 moved, 0 not (a bridged type without the layer), -1 not a bridged FX (kennel's own shift path) */
int ox_lfo_shift(int16_t *w, int p, int32_t delta);
/* sounds saved on Opus (opus_saved.c rewrites them before the parse; tier 2 tests these): an effect by its Opus name or
 * alias with the Opus core's words (made kennel's in w); an LFO record of an Opus type; a "dbox" kit's mark / engine id.
 * Each -> the saved name it opens as, or 0 (not the bridge's, or saved by kennel: unchanged) */
const char *ox_from_opus(const char *name, int16_t *w);
const char *ol_from_opus(const char *name, const int16_t *p, int n, int16_t *w, int16_t *rec, uint32_t *id);
const char *od_from_opus(int mark, const char *engine);
int od_mark(int k);                         /* tests: drum type k's mark */

/* ---- a module's page (the kit's struct opus_page, core 2.31): what page_key / page_turn are told ---- */
typedef struct opus_page {
    int16_t kind;                           /* 0 effect, 1 engine (T1, T2 or T4), 2 drum, 3 LFO, 4 sequencer */
    int16_t t;                              /* the T key: 1, 2 or 4 */
    int16_t where;                          /* 0 synth, 1 drum, 2 master */
    int16_t slot;                           /* the sound slot 0-7 */
    int16_t on;                             /* 1 for an engine */
    int16_t n;                              /* values in par (8) */
    int16_t key;                            /* a drum engine's key, else -1 */
    int16_t live[8];                        /* par as the sound hears it now (here: as stored) */
    volatile int16_t *par;                  /* what the page edits (an engine's knobs: knob 4's change is not kept) */
    void *inst;                             /* 0 for an engine */
    const void *module;                     /* the registered struct */
} opus_page;

/* ---- engines (opus_engine.c): struct opus_engine as the kit lays it out (124 bytes in core 2.31+; a shorter one ends
 * earlier: the adapter reads a field only when `size` covers it) ---- */
typedef struct opus_engine {
    uint32_t size;
    const char *name;
    int16_t knobs[8];
    uint32_t voice;                         /* +24 state bytes a voice */
    void (*init)(void *voice, int index);
    void (*note_on)(void *voice, const int16_t *knobs);
    void (*release)(void *voice, const int16_t *knobs);
    void (*render)(void *voice, int16_t *out, const int16_t *par, const unsigned *pitch);
    void (*block)(int16_t *buf);            /* +44 */
    void (*page)(void);
    void (*page_t2)(void);
    int (*turn)(int encoder, int detents, int page);
    int (*key)(int key, int pressed, int page);
    uint32_t flags;                         /* +64 */
    void (*page_t4)(void);
    int (*finished)(void *voice);           /* +72 */
    const char *type;
    int mark;                               /* +80 */
    const char *svg;
    void (*screen_init)(void *scr);
    void (*screen_draw)(void *scr, int dt);
    int8_t shift_knobs[4];                  /* +96 */
    const int16_t (*keys)[8];
    void (*note_key)(void *voice, const int16_t *knobs, int key, int velocity);
    int (*group)(const int16_t *knobs, int key);
    void (*choke)(void *voice);
    int (*page_key)(opus_page *pg, int key, int pressed);
    int (*page_turn)(opus_page *pg, int encoder, int detents);   /* +120 */
} opus_engine;
#define OPUS_ENGINE_OWN_ENVELOPE 1u
#define OPUS_ENGINE_OWN_LFO      2u
#define OPUS_ENGINE_OS_VOICES    4u
#define OPUS_ENGINE_SAMPLE       8u
#define OPUS_ENGINE_DRUM         16u
#define OE_TYPES 8                          /* engine types for all files */
int opus_engine_add(opl_self *self, const opus_engine *e);
int oe_count(void);
void oe_rollback(int n);
const char *oe_saved_name(const char *name, char *out);   /* D4 */
extern const ob_sym oa_imports[];           /* art, page_art, keep / put, page_now (opus_art.c), searched first */
extern const int oa_n_imports;
int oa_count(void);
void oa_rollback(int n);
void oa_page_art_draw(const ob_file *f, int which);
void oa_page_set(int kind, int t, int where, int slot, const int16_t *par8, int mark4, void *inst, const void *module);
void oa_page_clear(void);
extern int oa_in_page, oa_touched;
/* opus_art.c: a box of the page's lit pixels kept as runs (-1: no room, or not the picture in a frame-skip record frame)
 * and runs written back (the caller feeds the frame hash) */
int oa_keep(unsigned short *out, unsigned cap, int x0, int x1, int y0, int y1);
void oa_put(const unsigned short *runs, int used);
int oa_state(int n);                        /* tests: 0 not loaded, 1 loaded, 2 refused */
void *oa_doc(int n);
const char *oa_rel(int n);
uint32_t oa_total(void);
extern const ob_sym oe_imports[];           /* the engine and page services (opus_engine.c), searched first */
extern const int oe_n_imports;
/* ---- drum engines (opus_drum.c): OPUS_ENGINE_DRUM as a kennel drum-synth provider ---- */
#define OD_TYPES 2                          /* drum engine types for all files */
int od_add(ob_file *f, const opus_engine *e, const char *saved, int mark);   /* from opus_engine_add: the mark, or < 0 */
int od_count(void);
void od_rollback(int n);
void od_offer(void);                        /* after the stage: committed types to the core (kn_ds_foreign_offer) */
extern const ob_sym od_imports[];           /* opus_drum_key */
extern const int od_n_imports;
void oe_page_run(void (*fn)(void));         /* opus_engine.c: a page drawn with the primitives over R246's raster */
/* tests (tier 2) */
const opus_engine *od_engine(int k);
void *od_state(int k, int v);
const void *od_provider(int k);
void od_build(int k);
void od_hit(int k, int v, const int16_t *kit, int key);
int od_block(int k, int v, int16_t *out, const int16_t *par, uint32_t ratio);
/* tests (tier 2) */
const void *oe_entry(int k);                /* the kennel entry (op1_engine_sum_t layout) */
const opus_engine *oe_engine(int k);
void *oe_state(int k, int v);
int oe_vptr_bad(int k);                     /* tests: quirk voice-pointer words pointing at no voice (home or L1) */
int oe_mark(int k);

/* ---- LFO types (opus_lfo.c): the kit's struct opus_lfo / opus_lfo_type (core 2.21; page members core 2.31) ---- */
typedef struct opus_lfo {
    uint8_t instrument, slot, voice, pass;  /* 0 synth, 1 drum; 0-7; the voice or 255; the pass 0-5 */
    int16_t *params;
    void *state;
} opus_lfo;
typedef struct opus_lfo_type {
    uint32_t size;
    const char *name;
    uint16_t nparams, state_size;
    const int16_t *defaults;
    void (*tick)(opus_lfo *l);              /* +0x10 */
    int (*apply)(opus_lfo *l);
    void (*trigger)(opus_lfo *l);
    void (*page)(void);                     /* +0x1C */
    int (*turn)(int encoder, int detents);
    int (*key)(int key, int pressed);
    const char *svg;                        /* +0x28 */
    void (*screen_init)(void *scr);
    void (*screen_draw)(void *scr, int dt);
    int (*page_key)(opus_page *pg, int key, int pressed);   /* +0x34 */
    int (*page_turn)(opus_page *pg, int encoder, int detents);
} opus_lfo_type;
typedef struct opus_tempo {
    uint32_t size, mbpm, ticks, frac, step;
    uint8_t external, playing;
} opus_tempo;
#define OL_TYPES 2                          /* LFO types for all files */
int opus_lfo_register(opl_self *self, const opus_lfo_type *t);
int ol_count(void);
void ol_rollback(int n);
void ol_offer(void);                        /* after the stage: committed types to the core (kn_lfo_foreign_offer) */
void ol_clock(const op1_beat_t *b);         /* the per-block clock (opus_tempo) */
extern const ob_sym ol_imports[];
extern const int ol_n_imports;
const opus_lfo_type *ol_lfo(int k);         /* tests */
const void *ol_kennel(int k);
void *ol_state(int k, int pos, int slot);

/* ---- sequencers (opus_seq.c): the kit's struct opus_sequencer (core 2.8; page members core 2.31) ---- */
typedef struct opus_sequencer {
    uint32_t size;
    const char *name;
    void *(*player)(int mode);              /* +8 */
    int (*key)(int mode, int code, int pressed);
    int (*turn)(int mode, int encoder, int delta);
    void (*midi_start)(int mode);           /* +0x14 */
    void (*chosen)(int mode, int on);
    const char *svg;                        /* +0x1C */
    void (*screen_init)(void *scr);
    void (*screen_draw)(void *scr, int dt);
    const char *alias;                      /* +0x28 */
    int (*page_key)(opus_page *pg, int key, int pressed);
    int (*page_turn)(opus_page *pg, int encoder, int detents);   /* +0x30 */
} opus_sequencer;
#define OS_TYPES 2                          /* sequencers for all files */
int os_count(void);
void os_rollback(int n);
void os_offer(void);                        /* after the stage: committed types to the core (kn_seq_foreign_offer) */
int ob_block_count(void);                   /* opus_on_block handlers (run by kn_seq_block) */
void ob_block_rollback(int n);
extern const ob_sym os_imports[];
extern const int os_n_imports;
const opus_sequencer *os_seq(int k);        /* tests */
const void *os_kennel(int k);

/* ---- input and line input (opus_input.c): opus_on_key, _key_after, _knob_after, opus_on_line_input ---- */
int oi_count(void);                         /* the registries' sizes, packed (for a rollback) */
void oi_rollback(int c);
extern const ob_sym oi_imports[];
extern const int oi_n_imports;

/* ---- fast memory (opus_fast.c): opus_fast_lease / opus_fast_use over kennel's L1 pool ---- */
int of_count(void);
void of_rollback(int n);
/* One claimant (an engine type, an effect's position, a drum type): its audio-thread claim this block, so later calls
 * in the block reuse it (no claim, no bracket: a few words read) */
typedef struct of_ctx { ob_file *f; uint8_t *base; int part; } of_ctx;   /* base: the leases' area in L1, or 0 */
typedef struct of_slot {
    of_ctx c;                               /* the audio thread's context while it calls in */
    uint8_t *ret;                           /* the front in L1 this block, 0 home */
    uint32_t tick;                          /* kn_l1_live.tick + 1 of that claim, 0 none */
    uint32_t key;                           /* front + 1 of the last claim that held (renewed as it was), 0 none */
} of_slot;
extern of_ctx *of_now[2];                   /* [0] the callback's (read only while kn_l1_live.cb), [1] a thread's */
/* claim part (OP1_L1_*) for file f around one call: front bytes for the adapter first ([0, state) kept with home as its
 * own copy), the file's leases after them; -> where the front lies (L1 or home); of_leave(*t) after the call */
uint8_t *of_enter(of_slot *s, ob_file *f, int part, void *home, uint32_t front, uint32_t state, uint32_t *t);
void of_leave_thread(uint32_t t);
static inline void of_leave(uint32_t t) { if (t) of_leave_thread(t); }
extern const ob_sym of_imports[];
extern const int of_n_imports;

/* ---- the services' version (the kit's core line): a file whose `core` line is newer is refused ---- */
#define OB_CORE_MAJOR 2
#define OB_CORE_MINOR 58                    /* the plugin kit of e265bca (beta 4.2) */

/* ---- small text helpers (opus_load.c): no libc ---- */
int ob_len(const char *s);
int ob_eq(const char *a, const char *b);
int ob_cmp(const char *a, const char *b);
char *ob_cat(char *d, const char *s);       /* appends, returns the end */
char *ob_num(char *d, uint32_t v);          /* decimal, returns the end */
int ob_vercmp(const char *a, uint32_t alen, const char *b, uint32_t blen);   /* dotted numbers: <0, 0, >0 */
#endif
