# The Opus plugin bridge (core code)

Kennel loads Opus 2 `.opmod` plugin files unmodified (owner, 2026-11-17; plan in OP1-Emulator
`docs/ports/opmod-bridge-plan-2026-11-17.md`). This folder is the only place in kennel that may name Opus, its file
format and its services (`harness/names_check.py` `ALLOW_DIRS`). The core side it builds on is neutral:
`kennel/kn_foreign.h` (ARCHITECTURE.md "Foreign plugin bridge"). `make_firmware.py` compiles every `*.c` here into the
core. Nothing here is exported to `.knl` files.

## Files

| File | What |
|---|---|
| `opus.h` | Internal header: the file format's constants, the services' struct layouts (from the kit's GPL `sdk/opus_plugin.h`, our own declarations), the bridge's records and functions |
| `opus_load.c` | Loader: header, CRC, every table and relocation checked before a byte is written; copy, zero fill (apart with flag 8), word/lo/hi relocation; manifest lines; small text helpers |
| `opus_imports.c` | The import table, sorted by name: 61 `fw_*` (the kit's `op1fw.h`, checked against our Ghidra project; generator OP1-Emulator `run/opus-bridge/tools/gen_fw.py`) and the `opus_*` shims of phase 2; libraries' exports (orbit3d's `o3_*`) |
| `opus_fx.c` | Effect adapter: `opus_effect_register` -> one kennel `op1_fx_stereo_t` per type (stamped trampolines), instances per position, per-block parameter map, the shift layer (`kn_foreign_fx_shift`, params 4..7 in words 5..7), D4 names, the generic page from `view` |
| `opus_art.c` | A file's own SVG art (phase 9): `opus_art_text/open/ready/draw/show/turn/colour_slots/set_colour/colours`, `opus_page_art`, `opus_page_keep/put`, `opus_page_now`, through R246's SVG loader and renderer; the TE heap gate |
| `opus_engine.c` | Engine adapter (phase 3): `opus_engine_add` -> one kennel engine per type (stamped trampolines), per-voice state blocks, the envelope and LFO flags, the voice-sum `block`, D4 engine names, the D5 mark lookup (`kn_foreign_mark`), the page primitives over R246 text and raster, the engine services (`opus_engine_live/knobs/knob_set/data/data_set/sound_name`, `opus_fn_held`, `opus_clock`) |
| `opus_drum.c` | Drum engine adapter (phase 3 part 4): `OPUS_ENGINE_DRUM` -> one kennel drum-synth provider per type (a provider following HIM's R246 glue, now archived; offered to the core with `kn_ds_foreign_offer`), twelve voice state blocks, the Opus core's voice rules, the page on screen 0x11, `opus_drum_key`, the factory kits (`od_kits.h`: sim's beyond its own, HIM's three kits) |
| `opus_saved.c` | Sounds saved on Opus (`kn_foreign_sound`, before every parse): a kit's type, an LFO type's record, an effect's name or alias and words rewritten into kennel's form |
| `opus_lfo.c` | LFO type adapter (phase 4): `opus_lfo_register` -> one kennel `op1_lfo_type` per type (MIDI LFO class, shared reserved marker, name hash in word 2), settings in the sound's `lfo_rec` record, per-slot state, `opus_lfo_move` over kennel's matrix destination map, `opus_lfo_page` / `opus_lfo_changed`, the T4 page, `opus_tempo*` |
| `opus_seq.c` | Sequencer adapter (phase 4): `opus_seq_register` -> one kennel `op1_seq_type_t` per sequencer, `opus_seq_mode`, the sequencer-thread `opus_on_block` handlers (`kn_seq_block`), `fw_vc_note_on` / `fw_vc_note_off` through VoiceCtl key_down / key_up |
| `opus_input.c` | Input and line input (phase 6): `opus_on_key`, `opus_on_key_after`, `opus_on_knob_after` over the core's `kn_foreign_input` / `kn_foreign_input_after`, `opus_on_line_input` over `kn_foreign_line_in`; registries rolled back with a refused file |
| `opus_fast.c` | Fast memory (phase 6): `opus_fast_lease` / `opus_fast_use` and the adapters' moving state over kennel's L1 pool (`kn_l1_claim_ex`); one claim a block per claimant (phase 7) |
| `opus_quirk.c` | Per-file quirks (phase 7): known files by id, version and the file's sha256 (`ob_sha256`); castle 1.1's voices in L1; dimension 1.0.4's page placed 4 px in (`OQ_PLACE`) |
| `opus_place.h` | `OQ_PLACE`'s mapping: the page's rows (panel - 8) and the screen matrix that places it 4 px in (host test `harness/opus_place_test.c`) |
| `opus_settab.h` | a manifest's `setting` lines -> kennel's settings table (tag 7 layout) for `kn_settings_add_list`; shared with `harness/settings_list_test.c` |
| `opus_boot.c` | `kn_foreign_need` / `kn_foreign_boot`: `/yaffs2/opus/*.opmod` and the bundled `/yaffs2/content/*.opmod`, libraries first, `needs`, imports, the crash stage marker, settings rows (`opus_settab.h` packs them onto the settings page's OPUS PLUGINS list; a change calls the file's `on_setting`), inventory; the push allow-list `kn_foreign_path_ok`, `kn_foreign_bundle_ok`; `kn_foreign_has` (opus/ or content/ `<name>.opmod` exists: the core refuses a retired port beside its replacement) |
| `accel/oa.h`, `accel/oa.c` | Accelerators (phase 8): the binding of a quirk row's `accel` to a matched file (render offset checked), `ob_accel_on` |
| `accel/oa_sim.c`, `accel/oa_sim_kern.S` | sim 0.1.9's render_cb on HIM's voice (`derive`, the block's values) and sample loops, sim's 76-byte voice, the original's \|xs\|, the scope tap into its zero fill |
| `accel/oa_dx.c`, `accel/oa_dx_kern.S` | dx 0.4.1's engine_render on DX's `dx_render` / `msfa_note_compute` and FM kernels, over the file's globals, tables and cold functions |
| `test/bridge_guest.c`, `test/bridge_t2.py` | Tier 2 proof on bcore (below) |
| `test/inputtest/` | A small test file (our own source, built with the kit by hand for the native check): a line-input meter that can drop a side, a drum key selector on shift + sequencer, a log line per key |
| `test/seqtest/` | A small test file (our own source, built with the kit by the tier 2 driver): two sequencers, pulse and dots (-> dots_o), notes released from its block handler |

## Behaviour (phase 2)

- **Where files live:** `/yaffs2/opus/<name>.opmod` (the push's) and `/yaffs2/content/<name>.opmod` (files the
  workshop bundles into a firmware, phase 5); a file in `opus/` wins over a `content/` file of the same name. The
  workshop push may write and delete `opus/<file>.opmod` (devupd `du_path_ok` / `du_plugin_path` through the weak
  `kn_foreign_path_ok`) and delete a bundled `content/<file>.opmod` (`kn_foreign_bundle_ok`); HELLO bit 128 says the
  bridge is linked. A plugin's own folder (its `self->folder`) is `/yaffs2/mod/<id>`.
- **Boot:** `kn_foreign_need` reads only headers (image + zero fill + 6 KB a file for records, settings, inventory, log
  and effect state). `kn_foreign_boot`: files with exports first (libraries), then the rest. Each file: read whole into
  `KN_STAGE` (the pool, cleared after the stage); `ol_check`; refused when it has places (D3), when a `needs` library is
  missing or older, when an import is unknown ("needs <name>"), or when it crashed its start last time; then
  `kn_foreign_begin`, image and zero fill in the arena, relocate, `kn_foreign_sync`, crash-map record, the stage marker
  `/yaffs2/opus/.stage`, `opl_init`, marker removed; commit, or rollback on a negative return ("failed to start (-n)").
  Settings rows are added after the commit (none for a refused file). The inventory record (source `foreign`, path
  `opus/<file>`, id, version, author, a `cpu N` claim line per D8) is made before the transaction.
- **Crash stage:** when kennel's marker makes a boot skip every plugin file, and `.stage` names a file, that boot
  writes `<file> <crc>` to `/yaffs2/opus/.crashed`; the next boot refuses that file until it changes, loads the others,
  and removes `.crashed` once that file loads again.
- **Effects:** state per position from the arena; bulk and fast from `op1_fx_big(pos)` (cleared 8 KB a block from
  render, dry until done, then the type's `init`; plate: 17 blocks a position). Params 0..3 from the four knobs:
  `lo + q15 * (hi - lo) / 32767` per block (a range of at most 32 values: an `OP1_FX_STEPS` selector). Params 4..7
  (the shift layer, 2026-11-18): Shift + turn on the page goes to the type's `shift_knob` (dispatcher.c ->
  `kn_foreign_fx_shift`, steps as the Opus core: delta >> 10 gathered, a step every four; 0 drops the rest); without `shift_knob`
  (bitcrush), or for an encoder it refuses, the Opus core's stock move: params 0..3 at 1/16 of a plain turn's step
  (step x (delta >> 4) >> 15, half to even), into the knob word as a plain turn's; kept in the FX words 5..7 and saved with the sound: word 5 = par 4, word 6 = par 5,
  word 7 bits 0..6 / 8..14 = par 6 / 7 at 7 bits, bit 7 set (clear: the type's defaults). Name: the effect's own, or `<name>_o` when kennel has that name (its FX plugins, loaded or not,
  and R246's eight). An LFO type's move of params 4..7 (matrix's FX Shift targets) goes to `ox_lfo_shift` on the
  pass's stage words: add and clamp in the type's units, kept in words 5..7 as above (the stored words untouched).
  A sound saved on Opus names the effect by its own name ("plate") or an alias (`aliases`, "opus1:10") with its
  params in its own units; `opus_saved.c` -> `ox_from_opus` makes it the saved name (plate -> plate_o) and kennel's
  words (knob words mapped back, the shift layer in 5..7). A word 4 in the selector band (0x53xx) marks kennel's own
  sound: "plate" with a selector stays kennel's PLATE. The page: kennel's FX screen slot (`usbout.svg`, an empty screen) drawn from `view`.
- **Not done in phase 2:** the effect's own page (`page`, `svg`, `screen_draw`: the page and art imports only answer
  "nothing to draw"), key/knob services (zoom, playpause,
  endlesslatch are refused: "needs opus_on_knob" etc.), `fw_ui_dispatch` (left out until routed through kennel's
  input path; `fw_vc_note_on/off` came with phase 4), the disk folder intake, a held key
  that skips every file.

## Engines (phase 3)

- **Registration:** `opus_engine_add` checks the struct (reading a field only when `size` covers it), hands
  `OPUS_ENGINE_DRUM` to the drum adapter (below), refuses `OPUS_ENGINE_SAMPLE` ("needs sample engines"), takes 6 x `voice`
  bytes (32-aligned) from the arena, and registers a kennel `op1_engine_ext2_t` (40 bytes) under the saved name: the engine's name,
  or `<name>_o` when kennel has it (its engines, loaded or not, and R246's; the retired ports' names are free: `dx`, `dimension`). The log says `engine <saved> voice N flags F
  mark M` (+ own-env / neutral-env / block). Returns the mark.
- **Voices:** kennel's voice object picks the state block (`op1_voice_index`); `OPUS_ENGINE_OS_VOICES` engines get the
  voice object. `init(state, v)` runs at a voice's first note and again when its next note comes from another slot or
  sound selector (kennel has no rebuild callback). `note_on` / `render` get the eight words with knob 4 = the mark;
  `render`'s pitch is `OP1_PITCH_INC` (per-sample 88.2 kHz phase steps). `release` gets the knobs the voice last heard.
- **Envelope:** `OPUS_ENGINE_OWN_ENVELOPE` with `finished` -> `KN_FLAG_OWN_ENV`; the flag without `finished` -> the
  stock envelope held neutral (`KN_FE_NEUTRAL_ENV`); no flag -> the sound's T2 envelope. `OPUS_ENGINE_OWN_LFO` ->
  `KN_FE_OWN_LFO`. `block` -> `KN_FLAG_SUM` (64 samples at 44.1 kHz before the synth FX).
- **Page:** kennel's engine screen slot (`usbout.svg`, empty) calls the engine's `page` every frame with the primitives:
  `opus_page_text` (+ `_right`, `_centre`), `_line`, `_frame`, `_fill` (rows of lines), `_bar`, `_dot`, `_stroke_line`;
  colours by id (the stock encoder colours). Phase 9: art, keep and put are real (below, "Art (phase 9)"): dimension,
  amp and outatime draw their own pages. `opus_page_pixels` (inside a page's draw) gives R246's raster, which is the kit's
  frame (pixel (x, y) at [256 (rows - 1 - x) + y], rows from `op1_panel_rows`): castle's scene draws natively. Paths
  (`opus_page_path` / `_move` / `_line_to` / `_stroke`; `_curve_to` goes straight to its end): up to 256 points, stroked
  through R246's raster line (alpha opaque, caps and joins round).
- **Text** (2026-11-18, branch `opus-gaps-a`; the Opus core's `page_text_common` / `text_render`): one R246 text object
  per file and slot (the file's `self->slot`; 64 objects for all files, in `.farbss`), made at its first call with that
  call's place, size and alignment (R246's text ctor: 0 left, 1 centre, 2 right) and kept there, as the Opus core keeps
  them; the colour is written in place (Text +0x6C) and the text set again when it changes. The Opus core's checks: slot
  0..31, x 0..319, y >= 0, y + size <= 160, size 6..48, an unknown colour id white. Before, the 32 slots were shared by
  every file: a page that drew first fixed the place for all (the owner's unit: after matrix's T4 page, dx's value
  "5" sat at matrix's slot-13 place, 6 units high, between "OPUS" and "EP" in the title, and the value box was empty).
- **Dots** (`opus_page_dot`): the Opus core's `page_disc`, ported: a disc (filled) or a ring one unit wide (hollow),
  centre and radius in 1/16 pixels, each pixel covered by its distance and blended over what is there; r 0..40 inside
  x 1..318, y 1..158. The pixels go into the frame hash as the dot's numbers (the frame skip still skips an unchanged page).
- **Still part** (`opus_page_still` / `_still_done`, the Opus core's): the page's key, the file, the T page and the panel
  rows make a hash; when two frames in a row have the same one, `still_done` keeps the picture drawn so far (art and still
  part) as runs of its lit pixels (`oa_keep`, 32 K words in `.farbss`; never in a frame-skip record frame, where the
  raster is not the picture); a later frame with that hash gets them put back and 1, and the page draws only its moving
  part. The put pixels feed the frame hash as the hash itself, so the core's frame skip skips a page that stays the same.
  One kept picture for all pages, as on Opus. A picture over 32 K words is not kept (the page draws as before).
- **Engine services:** `opus_engine_live` gives the current slot's words as its newest voice renders them (the render's
  words: an LFO's moves in) when that voice rendered in the last 3 blocks (R246's block counter 0xFF8016E0) and plays the
  slot's engine, else the stored words, with knob 4 the mark (the Opus core's `engine_live_words`); `opus_engine_knobs`
  the same words (1 when the slot's sound is a bridged engine). So dimension's ensemble follows an LFO on green and dx's
  page follows LFOs. `opus_engine_sound_name`: the slot's sound name, R246's slot patch `"name"` member (the preset's
  name as loaded or saved; the Opus core's patch row name): dx shows a user preset's name and says "edited" only when
  its stored name matches.
- **Display and monitor services:** `opus_frames_late` = how many of the last 8 drawn frames came more than 36 audio
  blocks (~52 ms, the Opus core's 0x1413CD8 cycles) after the drawn frame before (`kennel/kn_gfx.c` `op1_frames_late`:
  kennel's pace or frame governor slowed the drawing). `opus_cpu_charge(self, cycles)` adds to the resource monitor's
  audio split (`sm_cy`): engine files under synth, drum engines under drum, others under FX (the bridge's own calls into
  a file are timed there already; no file in the pack calls it).
- **T2 / T4 pages:** `page_t2` with the own envelope -> kennel's `t2_page` (without the own envelope the stock T2 page
  stays), `page_t4` -> `t4_page`; both draw with the same primitives. Natively dx's own envelope and LFO pages show and
  a blue turn on each changes its data ("EDITED").
- **Turns, keys and pushes:** `KN_FLAG_ENG_INPUT` when the engine has `turn`, `key`, `page_turn` or `page_key` (each
  bounds-checked inside its image), on T1 and its own T2 / T4 pages (kennel's page numbers 0, 1, 3 are the kit's): a
  turn in detents (`op1_eng_detents`, 0 when less than one), a push as key 0x3B + encoder, a T1..T4 key as its code.
  With `page_turn` / `page_key` (core 2.31) they get a `struct opus_page` (kind 1, t, slot, the eight words with knob 4
  the mark, `par` a copy to edit); on 1 the changed words (never 4) are kept through `op1_engine_word_set`. Else
  `turn(encoder, detents, page)` / `key(code, pressed, page)`. 1 takes it. Natively: outatime's shift + orange stores
  its overdrive byte; castle's orange push (0x3E) stores its drone mode; castle 1.0 has `page_turn` (shift + blue there
  set its word 5, plain blue word 0).
- **Main pass:** every engine type has `KN_FLAG_ENG_SERVICE`; on `OP1_EV_SERVICE` the file's `opus_on_main_pass`
  handler runs once a pass (from its first engine type). A file without an engine is never called (kept only).
- **Folders:** `opus_on_folder` checks the struct and name (1-8 of a-z 0-9 _ -, six at most, no duplicate) and makes
  `/yaffs2/mod/NAME` (log "folder made" / "folder there"); a plugin that scans its folder at `opl_init` (dx's banks) finds files put there by the push (the workshop's DX banks: wire path `user/dx/<name>.syx`, written by the apply to `/yaffs2/mod/dx/`, `du_fw.c` `dest()`). The
  disk exchange (take / changed) is not built: R246 deletes the disk's non-tape files on leaving disk mode.
  `opus_page_art` is real since phase 9 (below); `opus_frames_late` above ("Display and monitor services").
- **Shift layer:** an engine with `turn` gets shift turns first (outatime turns its own knobs 5..7 there); otherwise
  `shift_knobs[e] == 5 + e` for blue and green -> `op1_engine_shift` (words 5, 6). White and orange share kennel's word
  7 (two 7-bit fields): an engine without `turn` whose shift layer is white or orange is not served.
- **A new sound** has words 5..7 = the engine's `knobs[5..7]` (clamped at 0, as the Opus core builds one): the factory
  row's page-2 words (`KN_FLAG_PAGE2`). Natively outatime_o's new sound is 13239, 9929, 16549 and its arms beat again.
- **Identity (D5):** a claimed mark (0x4F01..0x4FFF, 0x5301..0x53FF) maps to the registered number when a sound of
  type "iter" loads (`kn_foreign_mark`). An unclaimed engine's mark is the one the Opus core derives (`derived_mark`:
  FNV-1a over the plugin id, ':' and the engine name; x ^ x >> 15; 15 bits; moved by 0x2100 off 0x4Fxx / 0x53xx and
  bits 8..14 = 0): the engine sees it in knob 4 as on Opus, and Opus-saved sounds carrying it open in the engine
  (outatime 10708, dx 15117, castle 282).
- **Opus-saved data:** a sound without kennel's `eng_data` but with `"opus": {"engine_data": "<hex>"}` (how the Opus
  core keeps `opus_engine_data_set`, up to 256 bytes) gets those bytes in the slot's cache (`kn_foreign_data`, the
  keep step). Every parse keeps the `"opus"` member (R246's parser drops unknown members: without it a preset reached
  its slot without the data), so the slot's save writes it back. An "iter" sound a foreign mark opened gets the
  engine's name as its type in the parsed patch (the live sound).
- **Sounds saved on Opus** (`opus_saved.c`, 2026-11-18): `kn_foreign_sound(json)` from `kn_patch_safe.c` before
  every parse rewrites the kit type, the LFO record and the effect (each section below); a kennel-saved sound is never
  changed. Tier 2 checks the three decisions (`T2 fromopus`); the JSON glue runs natively only.
- **Saves are kennel form only** (owner, 2026-11-17): a slot save writes the live patch as R246 does: type = the
  saved name (e.g. `plate_o`), knob 4 the selector, the `"opus"` member kept as data (its `engine_data` as it came; a data
  change made here is in kennel's `eng_data`). Such a sound reopens here by name; Opus does not open it (it does not
  know the `_o` name or the selector). The Opus-form save edit (141f0209) was removed.
- **Main pass:** while a file's main-pass handler runs, `opus_engine_data_set` and `opus_engine_knob_set` refuse (a
  service must not store; dx's pass only reads).
- **amp:** loads as amp_o: `opus_skip_dry_input` sets kennel's `kn_skip_dry` inside the voice-sum block (outside it
  nothing): the core drops that block's dry input right after it. `opus_set_setting` writes kennel's settings store at
  once (the kit waits 2 s), kept inside the manifest's choices. amp plays only while R246's input mode word
  0xFF8010B0 is 0 (input on) and the source is not the mic, or headphones are in (0x018B621D): R246's own condition for
  monitoring the input dry. The word is 2 (input off) from boot (`input_settings_init`) on the unit too; the mic key
  turns the input on (0) and off (2). So a user plugs into the line in and presses the mic key; nothing to shim.
  Natively (phase 9, OP1-Emulator `run/opus-bridge/p9/amp/`, run1): with the mic key pressed and the line source (the
  jack's results set by hand: the emulator cannot plug the line jack, see the native check below), amp_o plays
  the line input and its dry copy is gone (an 11 kHz part of the input, which amp's chain removes: 0.0117 with
  wavetable dry-monitored, 0.000185 with amp_o, -36 dB; amp's 3rd harmonic 0.008 at 990 Hz).
- **Drum engines** (sim; part 4): `OPUS_ENGINE_DRUM` goes to `opus_drum.c` (no `note_on` needed; `finished` and
  `note_key` or `note_on` required; `keys`, `note_key`, `group`, `choke` read when `size` covers them). Two types at
  most. Each is a drum-synth provider under its saved name (D4: "sim"), offered after the stage and activated by the
  core after the features' (gin, HIM) with a marked `drum_types` row whose default_params are the engine's knobs. The
  kit is R246's own (24 keys x 8 words, D-Box controls on T1, shift for words 4..7); a fresh kit (all 0, or every key
  at the row) becomes the engine's `keys`. Voices as the Opus core's engine glue (`engineglue.c`, `enginehooks.c`):
  each factory build runs `init(state, i)` for the twelve voices; a hit runs `group(words, key)` and, when > 0, chokes
  every other active voice on another key whose words give the same group, then `note_key(state, words, key, 127)`;
  a block is `render(state, out, working words, &ratio)` with ratio = R246's base pitch of the voice >> 10 (0x10000 at
  the drum octave), then `finished` (nonzero: the voice's status goes to 0). No velocity scaling (the Opus core passes
  127). T1 is the engine's `page` on screen 0x11 over the empty SVG (HIM's construction), drawn every frame;
  `opus_drum_key` gives the shown key's words. A kit saved here is type "sim" (kennel form); an Opus-saved kit (type
  "dbox" with an `"opus": {"engine", "mark"}` member, the Opus core's drum job) opens in sim: `opus_saved.c` (below)
  sets its type to the saved name before the parse (`od_from_opus`: the mark, else the plugin id) and drops the two
  keys, so it saves as a kennel kit.
- **Factory kits** (2026-11-18): the Opus core lists no kits for an engine (a new kit is its `keys`). Kennel lists
  `<name> default` (the engine's `keys`) and, for sim, HIM's three kits on the same eight words as `sim range`,
  `sim ghost`, `sim metal` (`od_kits.h`, from `archive/him/him_presets.h`; 3.3.1 dropped HIM's own four and nothing
  replaced them). `od_offer` -> `kn_ds_foreign_kit`; the core inserts `drum_presets` rows (folder and type = the saved
  name, marked) and removes them once the engine is gone (`kn_core_rows.h` `kn_cr_drum_kit`, `kn_cr_drum_kits_cleanup`).
- **Not done:** sample engines, the folder's disk exchange (owner: skipped), recolour / palette lines (no themes here). SVG art and `opus_page_now` came in phase 9 ("Art (phase 9)"). Saving in the Opus form
  is not wanted (owner, 2026-11-17).

## LFO types (phase 4)

- **Registration:** `opus_lfo_register` (from `opl_init`, inside the file's transaction): size > 0x1b, name in the image
  (1-15 of a-z 0-9 space _ + -), 1..64 settings, `defaults` and `apply` (`tick`, `trigger` if set) inside the image,
  state up to 8 KB a slot. Two types at most. D4: a name R246 or kennel has (tremolo, value, random, element, midi, bend,
  crank, quad, pond, or a loaded kennel file's LFO type) gets `_o`, kennel's keeps the
  plain name. State: 16 slots (8 synth, 8 drum) x `state_size` from the arena (`kn_foreign_need` adds 20 KB for a file
  whose manifest `adds` an LFO). After the stage each committed type is offered to the core (`kn_lfo_foreign_offer`) with
  its `lfo_types` row `[0,0,hash,0,0,0,0,-15104]` and the bridge's per-block clock as its tick.
- **Words** (saved with the sound, kennel form only): w0/w1 the record id (0: a fresh pick, the type's defaults), w2 the
  saved name's 16-bit hash, w7 = 0xC500 (the shared reserved marker). The settings are the sound's `"lfo_rec"` record
  (`op1_lfo_record` / `op1_lfo_record_store`), as kennel's matrix keeps its rows. An Opus-saved sound (lfo_type
  "midi" with `"opus": {"lfo_type", "lfo_params"}`) opens in the bridged type: `opus_saved.c` writes the saved name,
  the words and an `lfo_rec` from the settings (`ol_from_opus`: -32768 = the default, the id from the settings) and
  drops the member's lfo keys (the member is kept, so a later stock pick stays stock).
- **Audio** (the Opus core's rules, read in OP1-Emulator `ext/opus-src` `lfotypes.c`, `status.c` lfo_place_dispatch,
  `services.c` opus_lfo_move): while the slot is current and its LFO on, `apply(l)` at every pass R246's MIDI LFO class
  runs (synth 1 and 0 a voice, then 2; drum 3 a voice, then 4, then 5); `tick(l)` right before the apply of pass 2 and
  of pass 4 (once a block an instrument); `trigger(l)` at a note (its voice; 255 from the FX object, for the instrument the page shows). `l` = {instrument,
  slot, voice (255 the instrument's), pass, settings, state}; the state is zeroed when another record arrives (a load, a
  pick), not for the page's own edits. `opus_lfo_move(l, group, param, delta)` acts only for the `l` being applied:
  engine knobs (pass 0 / 3, R246's own knob turn), envelope (1 / 4), the effect (2 / 5; params 4..7 kennel's FX shift
  layer), the engine's shift layer (kennel's `op1_engine_shift` words), the sound (volume and pitch on pass 0, ring and
  duck on 2 / 5): kennel's matrix destination map (`plugins/matrix/matrix.c` `mx_dest_move`), so a foreign LFO moves
  what kennel's matrix moves.
- **Page:** kennel's LFO page slot (0x1C) with an empty SVG, drawn by the type's `page` with the page primitives (paths
  close, cubic curves as 8 lines, `opus_page_fill_path` even-odd scanlines since phase 4). Turns (detents, 1024 units) go
  to `turn(encoder, detents)` or `page_turn`; encoder pushes to `key(0x3B + encoder, 1)` or `page_key`; Shift + push
  arrives as a turn of 0 (nothing) and then a push. `opus_lfo_page()` is the shown slot's edit copy;
  `opus_lfo_changed` stores it as a new record and puts its id into the words, which the core saves with the patch.
- **Tempo:** `opus_tempo` (mbpm, ticks, frac, step 16.16, external 0, playing 2 while the tape plays), `opus_tempo_phase`,
  `opus_tempo_phase_step`: kennel's beat clock (`op1_beat_clock`) counted a block at a time, or the tape position while
  the clock follows the tape (kennel's matrix design); written by the audio thread only, read from any.

## Sequencers (phase 4)

- **Registration:** `opus_seq_register` (inside the transaction): name 1-15 of a-z 0-9 - (the Opus core also takes a
  space; kennel's `seq_types` rows do not, so such a name is refused with a reason), `player` in the image;
  D4: a stock name (pattern, endless, tombola, finger, sketch, arpeggio), a name the core was built with (`kn_own_seq`)
  or a loaded kennel file's gets `_o` (`dots` -> `dots_o`); an alias is kept when free. Two at most; offered after the
  stage (`kn_seq_foreign_offer`), its `seq_types` row kept as a `.knl` type's.
- **Running** (the Opus core's `seq.c`): `player(mode)` for the mode being made goes to kennel's create_player hook as
  is (R246's player layout on both cores); a 0 answer gives finger's. On its page (slot 0x2D, an empty SVG with the
  sequencer's name: its own SVG screen is not drawn yet) keys go to `page_key` or `key(mode, code, pressed)` (the octave
  keys never: kennel moves the octave), pushes as codes 0x3B..0x3E; turns to `page_turn` (raw delta >> 10, a step every
  four, as the Opus core) or `turn(mode, encoder, raw delta)`. `midi_start(mode)` for each mode it is chosen for;
  `chosen(mode, on)` when that changes (asked once a sequencer tick). `opus_seq_mode`: the page's instrument.
- **Block handlers:** `opus_on_block(self, fn)` (8 at most): the sequencer thread once a PlayerManager tick
  (`kn_seq_block`, before the MIDI receive parser; the Opus core runs them before player_midi). `ob_block_calls` counts
  the calls (a probe).
- **Notes:** `fw_vc_note_on(ev, param)` / `fw_vc_note_off(ev)` are R246's VoiceCtl key_down / key_up (kennel's hooked
  entries: the note input observers and the note pipeline), with the note source set to a player (as kennel's
  `op1_seq_note_on`) and a note outside 0..127 dropped (R246 asserts). The note numbers are the plugin's own (on Opus
  too: no synth octave added).

## The 4.2 kit, input and fast memory (phase 6)

- **Version:** the bridge gives the services of core 2.58 (the kit of e265bca, beta 4.2). A file whose `core` line is
  newer is refused before anything else is checked ("needs core 2.59"); no `core` line: "its manifest"; a malformed one:
  "its core line". 4.2's additions: `opus_drum_select_key` (R246's selected pad word 0xFF801044, as kennel branch
  fluke-set's `op1_drum_select_key`), `opus_on_line_input` (below), a setting's ` if OTHER=VALUE` (parsed and dropped:
  kennel's settings page has no hidden rows, so the row always shows, as on a core before 2.36), `recolour` lines (not
  read: no themes here; phase 9 checked that no starter-pack file has `theme` or `recolour` lines, so art colours are
  the files' own and `opus_art_colours` stays 0), orbit3d 0.2.7's `o3_traces_spans` (the library's own export). `op1fw.h` did not change.
- **Keys:** `opus_on_key(fn)` handlers run in load order for every key event that reaches kennel's features' input
  filter (after its text entry, before an engine's own page, the features and R246); 1 takes it. The help key (0x00)
  comes too, and R246 still gets it when no handler takes it. `opus_on_key_after` / `opus_on_knob_after` hear every key
  and turn the before handlers saw, once its handling is over, taken or not (turns with the delta R246 got).
  `opus_on_knob` (a handler that changes or takes a turn) is not built: such a file is refused. castle 1.1 natively:
  C4 at 261.63 Hz, a help tap on T1 opens its kingdom statistics, a second tap closes them, a held help does nothing
  (OP1-Emulator `run/opus-bridge/p6/castle-a/`).
- **Line input:** `opus_on_line_input(fn)`: fn(stereo, 64) with R246's RX block (L, R per frame, the sample in the top
  24 bits) at the audio callback's start, before R246 sums the sides, only while the input source is the line input
  (0xFF8010B4 == 1). One handler a file. No file in the pack uses it; `test/inputtest/` runs it natively (phase 9, below).
- **Native check (phase 9):** `test/inputtest/` (test.input, core 2.58, our source built with the kit): its line handler
  measures both sides, and the sequencer key steps it through pass / right side zeroed / both zeroed; shift +
  sequencer calls `opus_drum_select_key(current + 1)`; every key press logs `key K drum D w0 W line M blocks B peak L
  R`. Natively (OP1-Emulator `run/opus-bridge/p9/amp/`, line source, input on): the dry-monitored input 0.0511 rms,
  0.0240 with the right side zeroed (R246 sums the sides), silent with both, 0.0499 back; the drum's current key 11
  (E, a note key) -> 12 -> 13, a blue turn then edits key 13's word 0 (0 -> 3104), key 11 unchanged. The emulator
  cannot plug the line jack (op1emu models the jack-detect expander 0x27 as an MCP23017, R246 reads it as an MCP23008's
  GPIO register 9 and gets 0), so that run sets the jack's two results by hand (line jack byte 0x018B621C = 1, source
  0xFF8010B4 = 1); the input mode word comes from the mic key.
- **Fast memory:** `opus_fast_lease(self, bytes, kind, slow)` from `opl_init` (log `fast lease N kind K`), and
  `opus_fast_use(l)`: the lease's copy in kennel's L1 pool while the file holds the partition of the position it plays
  at (synth engine 8,192 B, synth / drum FX 8,320 B, master FX 4,160 B, drum 512 B), else `slow`. The bridge claims the
  partition around each audio call into the file (once a block in the audio callback; later calls reuse it) (render, note_on, release, finished, the voice-sum block, an effect's
  init and render): first the adapter's moving state (an engine's six voices with `OPUS_ENGINE_STATE_MOVES`, kept: kennel
  copies them in and home; an effect's `fast` part with `fast_moves`), then the leases, first fit in the order taken.
  CONST and STATE leases are copied in on a fresh claim; STATE leases go back to `slow` when the partition goes (kennel's
  `kn_l1_claim_ex` copy-back). No priority between files: the one that plays holds it (kennel's rule). Engines without
  the moves flag keep their voices in SDRAM (they may keep pointers). `opus_fast` still answers 0. Leases in the pack:
  castle 4,096 const + 1,540 scratch (both fit; its voices move too through its quirk, phase 7), dx 8,192 const + 772 scratch
  (the sine table takes the whole partition: when the leases alone would use more of it than the front and the leases
  that fit after it, the front stays home), outatime 4,864 const after its voices. sim's twelve voices do not fit the 512-byte drum partition.

## Quirks and the claim path (phase 7)

- **Quirks** (`opus_quirk.c`): rows of known files by the manifest's `id` and `version` and the whole file's sha256
  (`ob_sha256`, hashed at boot only when id and version match a row, after the image is placed, before its start). A changed or
  unknown file keeps the generic path. Flags: `OQ_MOVES` (an engine's six voices move into the synth partition
  although the file lacks the state-moves flag), `OQ_VPTR` (two words in the image or zero fill, as offsets from the
  image's start, that hold a pointer to one voice: rebased with the voices on a fresh claim and in `gone`). The log
  says `quirk: voices in L1`. One row: castle 1.1 (displayname808), checked in its relocated code: its 196-byte
  voice is all scalars (KASTLE's 1:1 struct), the last and the previous note's voice pointers at +0x2A0F8 / +0x2A0F4
  (zero fill) are used only in voice init, note_on and render's takeover. Its partition: six 224-byte voices, then
  its 4,096 B sine and 1,540 B scratch leases (7,008 of 8,192 B).
- **One claim a block**: each claimant has an `of_slot`; the callback's first call in a block claims (a holder with
  the same front only renews, inline on `kn_l1_live`), later calls reuse the result (a refusal too). Key-thread calls
  claim each time inside `kn_l1_thread_enter` / `_leave`. `of_now[0]` (the callback's context) is read only while
  `kn_l1_live.cb` and only when its slot claimed this block (a call into the file outside `of_enter` gets `slow`);
  `of_now[1]` is a thread's for its call. The firmware renews inline in `of_enter`; `kn_l1_renew` is the same rule
  as a function (tested by `l1pool_test`).
- **Tried, not kept**: dx with its voices and scratch first and the sine table home (20..30 % dearer); sim's twelve
  voices (packed 76 B apart, 912 B) in the scratchpad's tail as a fifth partition: the claim cost about what the
  voices saved (`OP1-Emulator run/opus-cpu-2026-11-17/COMPARE-quirks.md`).
- **Tier 2**: castle's stress (restrikes on the last pitch so its takeover runs, every third strike on the key
  thread, page 7's switch off and on) gives the same sum with `--pool` and without; with the rebase disabled it
  does not (a negative control run once by hand). `T2 sha` checks two FIPS vectors.

## Accelerators (phase 8)

- **Why:** HIM and DX (kennel's ports of sim and dx) retire; their assembly now speeds up the bridged files. The kernels
  live here, in `accel/`, with their credits (HIM's voice: the original drum engine's synthesis, ported with the author's
  permission per the owner, 2026-11-09; DX: ported 1:1 with the author's permission, 2026-11-14, the FM after MSFA,
  Apache-2.0). The ports are archived since 2026-11-17 (`../archive/`, not built); these kernels are the only copies that build.
- **Licence and route:** the kit's licence (GPL-3.0 with two section 7 terms, c and e: a modified version is marked as
  different and does not use the original plugin's name; the kit README "Licence", `opus_plugin.h`) and the released
  files' terms ("free to use and share", source unpublished) leave an in-memory patch of the file open to being read
  as a modified version under the original's name. So the bridge never writes the file's code: it calls the
  accelerator through its own pointer (`od_type` / `oe_type` `render`, from `ob_render_for` at registration) instead of
  the file's render. Nothing else is redirected.
- **Binding:** a quirk row with `accel` (sim 0.1.9 `OA_SIM`, dx 0.4.1 `OA_DX`; id, version and the whole file's sha256,
  the starter pack's and `firmware/` files). `oa_bind` takes it only when the file's render is at the row's offset
  (sim +0x1044, dx +0x110), else the file's own runs ("accel: render not bound"). Log: `quirk: render on kennel's
  kernels`, then `accel: render on kennel's kernels`. `ob_accel_on = 0` (tier 2 `--noaccel`) keeps every file's own.
- **sim:** render_cb redone: ratio and log2 in the voice (+0x44 / +0x48), the last ratio at zero +0x44, HIM's voice on
  sim's voice (its first 64 bytes are HIM's layout; the constants are cached per voice index in the accelerator and
  reach the loops through `kp->c`), the scope tap (zero +0x5248 mark, +0x524C counter, +0x5250 sums, +0x5290 ring).
  The body's |xs| is sim's: 32-bit, so xs = -0x8000 gives 4; HIM keeps its saturating ABS (0 there: its README).
- **dx:** engine_render redone with DX's code: its operators and output on kennel's kernels, the sine table the file's
  (its lease's L1 copy through the bridge's `opus_fast_use`), the FM buffer the file's; voice_get_patch, msfa_lfo_reset,
  msfa_note_init, msfa_note_keyup, msfa_log2_lookup, note_is_silent, msfa_env_advance and sin_table_use are the file's,
  called by address; its tables (exp2, pitch envelope, amp-mod, algorithms, amplitude rates, hold times) read in its image.
- **Proof:** tier 2 (below) with and without `--noaccel`, `--pool`, and `--kern-c` (the C loops); `T2 accel sim` /
  `T2 accel dx` compare the accelerator with the file's own render on copies of one voice (outputs and voice bytes;
  sim also its scope words in the zero fill, with and without a new scope block; dx also with a kept sound's own
  envelope and patch, and the LFO moving through `block`).
- **CPU** (cold-noalloc, unit % = cycles / 5,805; OP1-Emulator `run/opus-cpu-2026-11-17/COMPARE-accel.md`): see there.

## Tests

`python3 synth_sdk/opus/test/bridge_t2.py [--pack DIR] [--kit DIR] [--castle FILE] [--pool] [--direct] [--only NAME]`
(the kit: the 4.2 checkout, OP1-Emulator `build/opus-kit-4.2/plugin-kit` at e265bca; `--pool` links kennel's L1 pool and
turns it on, so the files' leases and moving voices run from L1; castle 1.1 only runs, there being no source, and its
input handlers must register; a copy of plate declaring core 2.59 must be refused): LFO types (phase 4): matrix (vs
`ext/opus-src` 0.5.1) through the kennel LfoMidi entries (fresh pick and a record with rows of every destination group,
300 blocks each: 3 synth voices on passes 1/0, pass 2, 4 drum voices on pass 3, passes 4/5, triggers), the reference
driven as the Opus core does; every opus_lfo_move (pass, voice, group, param, delta) and the state bytes compared, plus
the offer as matrix, its row and words (groups 0, 1, 2 and 4 are moved; 3, the shift layer, is not in the record).
The source rebuild's sample-and-hold value on the instrument's pass differs from the release (its C is not matching; not
run down): against the source that row runs as a square; `--direct` runs it as written.
Sequencers: `test/seqtest/` built with the kit (`plugin_tool.py build`, our toolchain), pulse and dots_o through the
kennel types' players (3,000 ticks, three block calls a tick) beside the source build: every note on / off compared,
notes released from the block hook. Drum engines: sim (vs `ext/opus-src` 0.1.9) through `od_build` / `od_hit` / `od_block`, 48 hits on 12 voices with choke groups and four pitch ratios, every block's samples and finished state (3,060 blocks), and the provider offered to the core with its row; engines too (phase 3): dimension (vs `ext/opus-src` 1.0.4), dx (vs `ext/opus-src` 0.4.1; the reference gets its own `opus_alloc` pool) and outatime (vs the kit's GPL example 1.4.3, with `--pack` the beta 4 files) through the kennel engine entry, 6 knob sets x 40 blocks + 10 release blocks, the `block` sum compared too (not in `--direct`: one plugin's global block state), and a crossing-count pitch line. Effects: the bridge's real code on bcore over embedded
files (the 4.2 starter pack's orbit3d, bitcrush, chorus, plate, plus zoom and bend, and a damaged bitcrush), with the
kennel services stood in. It checks the refusals and the registrations (`plate_o`), then runs each effect through the
kennel FX entry beside a source build of it, mono at the synth position and stereo at the master, 6 x 40 blocks each.
References: bitcrush from the kit's GPL example; chorus and plate from OP1-Emulator's private `ext/opus-src` rebuilds
(compiled into the test only). `--direct` compares with the loaded struct called directly (the adapter alone). Prints
SKIP when an input is missing (none of them is in this repository).

## Retired ports (phase 9)

KASTLE, DX, HIM, DIMENSION, MATRIX and KHORUS are archived in `../archive/` (owner, 2026-11-17); the bridged files castle,
dx, sim, dimension, matrix and chorus replace them. D4 follows: the engines are `dx` and `dimension` (no `_o`), plate and
amp stay `plate_o` / `amp_o`, the LFO is `matrix` (owner, 2026-11-17: the name is free; an old sound's matrix words, marker 0xB3 with the record id in words 0 and 1, open in it and read its record in the Opus layout), the
sequencer `dots_o`. Nothing in this folder includes a file from `archive/`; facet3d is core code in `../f3/`.

## Art (phase 9)

`opus_art.c`. The files' own SVG art, drawn by R246 as kennel's own screens are:
- **Files:** `opus_art_text(self, name, svg, len)` (from opl_init) checks the text (an `<svg` root; R246's parser stops:
  kennel's `kn_svg_err` rules, plus a point with no decimal and an exponent, the kit's svgcheck) and writes it to
  `/yaffs2/mod/<id>/<name>` only when the file there differs; `opus_art_open(path)` names a file under `/yaffs2/mod/`.
  Up to 16 arts for all files. A refused file's arts go with its rollback.
- **Parse:** the first `opus_art_ready` inside a page's draw (the Gfx thread) parses the file with R246's `svg_load`
  (0x01A503D8) on a loader record of our own (`{ document, "../../mod/<id>/<name>" }`); outside a page it answers 0.
  The document is kept for good (the file keeps pointers into its colour records): one per file and name, never freed
  or evicted, outside kennel's lazy screen cap. Gate before a parse: TE heap used + 4 x the file + 64 KB (the parser's
  buffer) + 1.5 MB reserve within the 0x840000 pool, and all art documents within 512 KB; else "art refused (no room)"
  in the log and `ready` 0 (the plain page). Each parse logs its cost (`art parsed: <file> N bytes, TE heap used U`);
  `oa_stats` (documents, bytes, refused, draws, keeps that fit, keeps refused) for the debugger.
- **Draw:** R246's base screen draw (0x01A3B4C8) on `{ document }`: the drawing's units scaled to the panel by R246's
  screen matrix, as stock screens (no art is moved here). `show`: R246's lookup by id (0x019EB8AC, no panic), visible
  flag +0x50. `turn`: the transform setter (0x019EAD58), a rotation by t/4096 of a turn about (cx, cy) (units x 256),
  replacing the element's last transform. `colour_slots`: pointers to the fill records (4 bytes, +0x5C..+0x60) and
  stroke records (20 bytes, RGBA first, +0x6C..+0x70) holding the colour; `set_colour` writes only through pointers at
  a record's start inside a loaded document.
- **opus_page_art(page, path):** the art behind page 0 / 1 / 3 of the file's engine, drawn before its page each frame
  (path 0: none). The file is read and checked at its first show (in R246's heap, freed again). dx asks for
  `/yaffs2/mod/dx/t1.svg` etc. only when such files are in its folder; the starter pack carries none, so stock dx
  shows its plain pages.
- **Keep / put:** `opus_page_keep` copies the lit pixels of a box as runs (`row, y | (len - 1) << 8, pixels`), -1 when
  they do not fit or in a frame-skip record frame (`op1_raster_live` 0: not the picture); `opus_page_put` writes them
  back, bounds-checked. A page that wrote pixels itself (`opus_page_pixels`, `put`) moves the frame hash
  (`op1_screen_hash`), so frame skip never keeps a stale picture.
- **Effects' own page (core 2.34 `page`, +0x78):** chorus and plate draw it instead of the generic `view` page, with
  `opus_page_now` (kind 0, params mapped from the knobs, the position's instance, the registered struct; `par` is a
  copy). Their `svg` (blank.svg) and `screen_draw` are not used: kennel's slot is an empty screen too. A plain turn on
  the page also goes to the effect's `page_turn` (+0x70; dispatcher.c -> `kn_foreign_fx_turn`, 2026-11-18): what the
  page shows (kind 0, T 3, the params, a copy), detents as the Opus core counts them (rest += delta >> 10, one every
  four, 0 too); its answer and the copy are dropped and the turn goes on to kennel's knob handling (owner: page feedback
  only, the knob values unchanged). chorus flashes the turned knob's digits. `page_key` on the FX page is not routed (no
  file in the pack has one).
- **opus_page_now** for engine pages too (kind 1, T 1/2/4, the slot's words with knob 4 the mark).
- **Not done:** a changed `opus_page_art` file is read again only after a restart; recolour / themes (none here).
  `opus_page_art` has not run yet (no tier 2 case; the starter pack has no t1.svg for dx).
- **Placement:** the bridge places every page as the Opus core does (rows from the screen matrix, pixel x on memory row
  rows - 1 - x, no inset; checked in the Opus core's `opus_page_pixels` / `rect_fill_pixels` / `scale_coord`), with one
  exception: dimension 1.0.4 (`OQ_PLACE`, owner 2026-11-18). Its T1 page ran to x 0 and to 2 px from the right, which
  the unit's glass hides (our port had the same, fixed in 6c2c91e3). It is laid out for rows - 4 and placed 4 px in (owner: the right edge stays)
  on every panel: for its draw (`oe_page_frame`: `oq_page_begin` / `oq_page_end`) the screen matrix becomes
  `opus_place.h`'s (art, lines, paths); `opus_page_pixels` / `opus_page_keep` give rows - 4 (no memory-row offset)
  (its scope trace and kept page); its rows check (320 / 376 / 400 immediates) is patched at load to the placed rows;
  its own Text objects (the `fw_text_new` import) and `opus_page_text` get their place scaled (R246's Text takes the
  matrix's translation but scales by the panel). Emulator (OP1-Emulator `run/opus-panel-2026-11-18/dim/`): left /
  right free px 0 / 2 -> 4 / 2 on panel b and on the default panel (v1, rows - 8: 4 / 6; the owner kept the right
  edge as it was); labels and art within 1 px of 4 + x 368 / 376 in v1; the trace on the same mapping as its grid (host: 0 px). Other pages measured on panel b and
  unchanged: dx 6 / 6, sim 9 / 9, matrix 8 / 6, castle 8 / 8 (water to the bottom, as kastle), chorus 0 / 0 (full
  width, as khorus), plate 15 / 33 (top 1), bitcrush 15 / 40. Open: an OLED look on the unit; orbit3d-drawn pages
  other than castle not measured.
- **Vertical placement:** nothing is moved. Natively (panel b) the pages' ink reaches y 142..146 units (dimension 142, amp and
  outatime 145, chorus 146, plate 144), over kennel's 138 target and inside the kit's window (y 2..146); stock tape
  reaches 146 too. An OLED check for the owner (docs/screen-art.md: no universal crop is measured).
- **Native (panel b, OP1-Emulator `run/opus-bridge/p9/art/`):** parse costs dimension 22,480 B, amp 78,056, outatime
  42,000, chorus 39,920 (182,376 together); none refused; kennel and stock pages draw after them.
- Tier 2 (`bridge_t2.py`, the bitcrush run): dimension's `t1.svg` on a fake parser: not parsed outside a page, parsed
  once inside, drawn, an element hidden (an unknown id refused), a quarter turn that keeps its centre, three colour
  records found and set, a pointer outside the records left alone.
