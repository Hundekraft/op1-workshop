#!/usr/bin/env python3
"""Snap static SVG art to a panel's pixel grid (docs/screen-art.md "Pixel grid", 2026-11-17).

    python3 synth_sdk/display/snap_svg.py ART.svg [OUT.svg] [--panel b]
    python3 synth_sdk/display/snap_svg.py --variants SRC.svg OUT.svg      # OUT.svg (b), OUT.a.svg, OUT.d.svg

R246 draws unit (x, y) at device pixel (x s + off, y s) (s: 1.25 default, 1203/1024 on the 376 x 188 panels b and C2 with
off = 1/16 px on x, 1.0 on panel a). A straight edge lights whole pixels only when it lies on pixel edges: a stroke n px
wide has its centre on a pixel centre (n odd) or a pixel edge (n even), a fill edge lies on a pixel edge. The art is
snapped for ONE panel per file (default: b, the owner's unit). The other panels' grids differ (a file holds one set of
coordinates), so write_variants() / `--variants` writes one file per panel model: X.svg (b and C2), X.a.svg (panel a) and
X.d.svg (default), each snapped from the same unsnapped source; a variant equal to X.svg is not written. A plugin ships
them all and R246 parses the one for its panel (docs/screen-art.md "Pixel grid", "Per-panel art"). Oxbow does its own.

What is moved (everything else is kept as written):
  - <line>, <polyline>, <path> (M L Z only) and <rect> with a stroke: the width is made a whole number of pixels
    (at least 1; strokes under MIN_W units are left alone: faint hairlines), and every vertex that ends an axis-aligned
    segment is snapped across that segment (centre by the width's parity), so the segment lies on whole pixels.
    Diagonals only follow their end points (under half a pixel).
  - filled paths (no stroke): every vertex that ends an axis-aligned segment snaps to the nearest pixel edge (pixel
    art such as Warble's: each cell edge goes to the nearest pixel edge, cells come out one or two pixels wide).
  - an element whose snapped points would turn back on themselves (svg_check's rule, which R246 draws as a spike and
    pack.py refuses) stays as written;
  - elements with an id, curves (arcs, circles) and text are left as written; transforms are not looked at (the art
    that uses them moves at run time anyway).
Idempotent: a second pass changes nothing. snap_file(path) is what the generators call after writing their SVG.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import argparse
import math
import os
import re
import sys
from pathlib import Path

PANELS = {'b': (1203 / 1024, 1 / 16), 'c2': (1203 / 1024, 1 / 16), 'default': (1.25, 0.0), 'a': (1.0, 0.0)}
TOL = 0.0006                                          # units: "equal" coordinates (the art is written with 1 to 2 decimals)
MIN_SEG = 0.6                                         # units: shorter aligned pieces (rounded corners) don't count
MIN_W = 0.4                                           # units: thinner strokes are faint hairlines, left alone

ATTR = re.compile(r'([\w:-]+)="([^"]*)"')
TAG = re.compile(r'<(line|polyline|path|rect)\b([^>]*?)(/?)>')
NUM = re.compile(r'-?\d+(?:\.\d+)?(?:e-?\d+)?')


def fmt(v):
    t = f'{v:.4f}'.rstrip('0').rstrip('.')
    return '0' if t in ('', '-0') else t


class Grid:
    def __init__(self, panel):
        self.s, self.off = PANELS[panel]

    def edge(self, v, xa):
        o = self.off if xa else 0.0
        return (math.floor(v * self.s + o + 0.5 + 1e-9) - o) / self.s

    def centre(self, v, xa):
        o = self.off if xa else 0.0
        return (math.floor(v * self.s + o + 1e-9) + 0.5 - o) / self.s

    def snap(self, v, xa, odd):
        return self.centre(v, xa) if odd else self.edge(v, xa)


def snap_poly(pts, closed, g, odd):
    """pts: [(x, y)]; every vertex ending an axis-aligned segment snaps across it (odd: pixel centre, else edge)"""
    n = len(pts)
    segs = [(i, (i + 1) % n) for i in range(n if closed else n - 1)]
    sx, sy = set(), set()                             # vertices to snap in x (vertical segments) / in y (horizontal)
    rect = True                                       # every real segment axis-aligned (pixel art): all vertices, both axes
    for a, b in segs:
        (ax, ay), (bx, by) = pts[a], pts[b]
        dx, dy = abs(ax - bx), abs(ay - by)
        if dx < TOL and dy < TOL:
            continue
        if dy < TOL:
            sy.update((a, b))
        elif dx < TOL:
            sx.update((a, b))
        else:
            rect = False
    if rect:
        sx = sy = set(range(n))
    else:                                             # a short piece must not make its vertices count as aligned
        sx = {i for i in sx if _long(pts, segs, i, 0)}
        sy = {i for i in sy if _long(pts, segs, i, 1)}
    out = [[g.snap(x, True, odd) if i in sx else x, g.snap(y, False, odd) if i in sy else y] for i, (x, y) in enumerate(pts)]
    if not rect:                                      # a short aligned piece stays aligned: its loose end takes the snapped value
        for _ in range(3):
            for a, b in segs:
                (ax, ay), (bx, by) = pts[a], pts[b]
                for ax_i, sset in ((1, sy), (0, sx)):
                    al = abs(pts[a][ax_i] - pts[b][ax_i]) < TOL and abs(pts[a][1 - ax_i] - pts[b][1 - ax_i]) >= TOL
                    if al and (a in sset) != (b in sset):
                        src, dst = (a, b) if a in sset else (b, a)
                        out[dst][ax_i] = out[src][ax_i]
                        sset.add(dst)
    return [tuple(v) for v in out]


def _long(pts, segs, i, axis):
    """vertex i ends an aligned segment on `axis` (0: vertical, so x is shared; 1: horizontal) of at least MIN_SEG"""
    for a, b in segs:
        if i in (a, b):
            (ax, ay), (bx, by) = pts[a], pts[b]
            along, across = (abs(ay - by), abs(ax - bx)) if axis == 0 else (abs(ax - bx), abs(ay - by))
            if across < TOL and along >= MIN_SEG:
                return True
    return False


def parse_d(d):
    toks = re.findall(r'[A-Za-z]|-?\d+(?:\.\d+)?(?:e-?\d+)?', d)
    subs, cur, closed, i = [], None, [], 0
    while i < len(toks):
        t = toks[i]
        if t in 'ML':
            cur = [] if t == 'M' else cur
            if t == 'M':
                subs.append(cur); closed.append(False)
            if cur is None:
                return None
            cur.append((float(toks[i + 1]), float(toks[i + 2]))); i += 3
            while i < len(toks) and toks[i] not in 'MLZ' and not toks[i].isalpha():   # implicit L
                cur.append((float(toks[i]), float(toks[i + 1]))); i += 2
        elif t in 'Zz':
            closed[-1] = True; i += 1
        else:
            return None                               # curves, relative moves: not touched
    return subs, closed


def width_px(w, g):
    return max(1, int(round(w * g.s)))


def snap_tag(name, attrs, g):
    """-> {attribute: new value} for one element, or {}"""
    a = dict(ATTR.findall(attrs))
    if 'id' in a:
        return {}
    stroke = a.get('stroke', 'none') != 'none'
    out = {}
    odd = False
    if stroke:
        w = float(a.get('stroke-width', '1'))
        if w < MIN_W:
            return {}
        n = width_px(w, g)
        odd = bool(n & 1)
        out['stroke-width'] = fmt(n / g.s)
    if name == 'line':
        p = snap_poly([(float(a['x1']), float(a['y1'])), (float(a['x2']), float(a['y2']))], False, g, odd)
        out.update(x1=fmt(p[0][0]), y1=fmt(p[0][1]), x2=fmt(p[1][0]), y2=fmt(p[1][1]))
    elif name == 'polyline':
        v = [float(t) for t in NUM.findall(a['points'])]
        p = snap_poly(list(zip(v[0::2], v[1::2])), False, g, odd)
        out['points'] = ' '.join(f'{fmt(x)},{fmt(y)}' for x, y in p)
    elif name == 'rect':
        x, y, w, h = (float(a.get(k, '0')) for k in ('x', 'y', 'width', 'height'))
        p = snap_poly([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], True, g, odd)
        out.update(x=fmt(p[0][0]), y=fmt(p[0][1]), width=fmt(p[1][0] - p[0][0]), height=fmt(p[3][1] - p[0][1]))
    else:
        r = parse_d(a.get('d', ''))
        if r is None:
            return {}
        subs, closed = r
        sep = ',' if re.search(r'\d,\d', a['d']) else ' '
        parts = []
        for pts, cl in zip(subs, closed):
            q = snap_poly(pts, cl, g, odd)
            parts.append('M' + f'{fmt(q[0][0])}{sep}{fmt(q[0][1])}' + ''.join(f' L{fmt(x)}{sep}{fmt(y)}' if sep == ',' else f' L{fmt(x)} {fmt(y)}' for x, y in q[1:]) + (' Z' if cl else ''))
        out['d'] = ' '.join(parts)
        if sep == ' ':
            out['d'] = out['d'].replace(' L', ' L').replace('M', 'M')
    return out


def _turns(tag):
    """svg_check's turn-back rule on one element (R246 draws a spike there; pack.py refuses the file)"""
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'harness'))
    try:
        import svg_check
    finally:
        sys.path.pop(0)
    return svg_check.turn_backs_in(('<svg>' + tag + '</svg>').encode())


def snap_svg(text, panel='b'):
    g = Grid(panel)

    def one(m):
        name, attrs, slash = m.group(1), m.group(2), m.group(3)
        new = snap_tag(name, attrs, g)
        if not new:
            return m.group(0)
        for k, v in new.items():
            if re.search(rf'(?<![\w-]){k}="[^"]*"', attrs):
                attrs = re.sub(rf'(?<![\w-]){k}="[^"]*"', lambda _m, k=k, v=v: f'{k}="{v}"', attrs, count=1)
        out = f'<{name}{attrs}{slash}>'
        if name != 'rect' and _turns(out) and not _turns(m.group(0)):   # a hook of a few tenths collapsed to a turn-back:
            return m.group(0)                                          # that element stays as written (soft, but valid)
        return out
    return TAG.sub(one, text)


def snap_file(path, out=None, panel='b'):
    path = Path(path)
    t = path.read_text()
    n = snap_svg(t, panel)
    Path(out or path).write_text(n)
    return n != t


VARIANTS = {'b': '', 'a': '.a', 'default': '.d'}      # file suffix per panel model (C2 shares b's)
SCALE_PANEL = {0x4B3: 'b', 0x400: 'a', 0x500: 'default'}  # op1_dev_scale() -> panel model


def variant_paths(svg):
    """{panel: Path} of the files that may exist for a screen SVG (b = the file itself); same order as VARIANTS"""
    svg = Path(svg)
    return {p: svg.with_name(svg.stem + s + svg.suffix) for p, s in VARIANTS.items()}


def write_variants(src, out=None):
    """snap the unsnapped art `src` for every panel model: `out` (default: src, in place) holds panel b's, X.a.svg and
    X.d.svg the others, written only when they differ from b's (stale ones are removed). -> the panels written"""
    src = Path(src)
    out = Path(out or src)
    t = src.read_text()
    main = snap_svg(t, 'b')
    paths = variant_paths(out)
    done = ['b']
    for panel, path in paths.items():
        if panel == 'b':
            continue
        v = snap_svg(t, panel)
        if v != main:
            path.write_text(v)
            done.append(panel)
        elif path.exists():
            path.unlink()
    out.write_text(main)
    return done


def variant_for(svg, panel):
    """the SVG file a panel ('b', 'c2', 'a', 'default') uses: its own variant when the screen ships one, else svg itself"""
    p = variant_paths(svg).get('b' if panel == 'c2' else panel)
    return p if p and p.exists() else Path(svg)


def host_panel():
    """the panel host builds draw for (OP1_HOST_PANEL, read as op1_plugin.h's op1_dev_scale reads it)"""
    v = os.environ.get('OP1_HOST_PANEL', '')
    return 'b' if v[:1] in ('b', 'c') else 'a' if v[:1] == 'a' else 'default'


def main():
    ap = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    ap.add_argument('svg'); ap.add_argument('out', nargs='?')
    ap.add_argument('--panel', default='b', choices=sorted(PANELS))
    ap.add_argument('--variants', action='store_true', help='write OUT (b), OUT.a.svg and OUT.d.svg from the unsnapped SVG')
    a = ap.parse_args()
    if a.variants:
        print('wrote panels: ' + ', '.join(write_variants(a.svg, a.out)))
        return 0
    print('changed' if snap_file(a.svg, a.out, a.panel) else 'unchanged')


if __name__ == '__main__':
    sys.exit(main())
