# Writing op1r plugins (synth engines and effects)

A plugin is one folder with a `plugin.json` and C code. It becomes a new synth engine or FX in the OP-1's lists.
You can write and test it on a PC; the op1r maintainers build it into a release. License: like all of op1r,
GPL-3.0-or-later with the OP-1 firmware permission (see `LICENSE` and `NOTICE` in the repository root).

## Quick start

```sh
cp -r template/synth plugins/mysynth          # or template/fx
# rename mysynth.c, the symbol (ENGINE_mysynth / FX_myfx) and "name" in plugin.json
python3 harness/audio.py mysynth              # -> harness/out/audio_mysynth.wav: listen to it
python3 harness/audio.py mysynth --knobs 0,32767,8000,20000
```

You need a C compiler and Python 3 (with numpy only for some of the other tests). `audio.py` builds your plugin
with address and undefined-behaviour sanitizers: out-of-bounds writes and integer overflows are reported there,
before they can crash an OP-1.

- **Synths** play a short phrase (velocities 127 and 64 alternating). Engines that use the slot's sampler
  recording get a 2 s synthetic recording.
- **FX** process plucked saw notes followed by 1.5 s of silence, so you can hear tails and feedback.

## plugin.json

```json
{ "name": "mysynth", "kind": "synth", "order": 99, "symbol": "ENGINE_mysynth",
  "sources": ["mysynth.c"], "defaults": [4000, 12000, 6000, 24000] }
```

- `name`: shown on the OP-1; lowercase, at most 15 characters, not a stock type name.
- `kind`: `synth` or `fx`.
- `order`: the plugin's number. It is stored in every saved preset, so it must never change once released. Use 99
  in your submission; the maintainers assign the final number.
- `symbol`: your `op1_engine_t` / `op1_fx_t` object; `sources`: C files, the first one defines `symbol`.
- `defaults`: initial positions of the 4 knobs (blue, green, white, red), 0..32767.
- Optional: `page2_defaults` (second-page knobs 5..7 of a fresh FX or synth sound), `uses_sample` (synth reads the slot's sampler recording),
  `coarse` (synth knobs turned in 8 steps), `stereo` (FX with a stereo master render),
  `screen` (own screen, see below). All fields are documented in `plugins.py`.

## The API (op1_plugin.h)

Include only `op1_plugin.h`.

**Synth engine** (`op1_engine_t`): `note_on(self, params)`, `render(self, out[128], params)`, `note_off(self)`.
- 6 voices; `self` is the voice object: the first word belongs to the firmware, the next 32 bytes are yours.
- `OP1_PITCH_INC[n]`: phase increment per sample of this note (2^32 = one cycle).
  `op1_voice_vel_gain(self)`: note velocity as a Q15 gain.
- `params[0..3]`: the 4 knobs, 0..32767. The firmware's envelope and level are applied after `render`.

**Effect** (`op1_fx_t`): `init(pos)`, `render(pos, buf[64], params)` (in place).
- `pos`: 0 synth FX, 1 drum FX, 2 master FX (mono sum, mixed back as the wet part). Keep all state per position
  (e.g. `static state_t st[3]`): the same FX can run in several positions at once.
- Optional true stereo master: declare an `op1_fx_stereo_t` (unchanged mono prefix plus
  `render_stereo(pos, left[64], right[64], params)`) and set `"stereo": true` in `plugin.json`.
  The mono render still handles synth/drum. Existing mono files keep the mono-sum master. op1r 42 `.op1p` FX
  with their own stereo flag (`OP1P_F_STEREO`, the same 16-byte entry) get stereo master routing too.
- Knobs: convert with `op1_fx_param_q15(params, i)` (raw words -> 0..32767).
- Memory: `op1_fx_scratch(pos)`, 176 KB per position (shared with the stock FX: it starts with foreign data, clear
  or track what you use). Kennel cores from 2026-10-21 add `op1_fx_big(pos, &size)`: a 1 MiB lease per position in
  kennel's pool, same rules (only the active FX there uses it, undefined after an FX switch), cleared once at boot
  and never in `init` (no time for 1 MiB of stores in the audio path): keep a valid length. Read `size`; 0 = no lease
  (fall back to the scratch). For state that has to survive FX switching, declare a buffer: `OP1_BIGBUF(name, min,
  max)` in C and `"bigbuf": "name"` in plugin.json (at most 512 KiB, granted in load order, `name.ptr` / `name.size`
  set before any callback; docs/plugin-format.md "Declared pool buffer"). Older cores refuse such files cleanly.
  Plugin files may be up to 1 MiB.

**Coarse knobs** (synth engines): `"coarse": [0]` in plugin.json turns knob 0 (both pages) in 8 steps over its
range, one per encoder detent, instead of the stock ~50 (a selector, a mode): positions 0, 4681, .. 32767. Knobs
0..3; not for FX. Same field as op1r 44 (docs/plugin-format.md "Coarse knobs").

**Stepped page 2** (synth engines): `press[k] = OP1_PRESS_PAGE_STEPS(n)` pages knob k like `OP1_PRESS_PAGE` and turns its
page-2 word in n steps, one per detent (Amp's voice); page 1 stays fine. Code only, no plugin.json field
(docs/plugin-format.md "Stepped page 2").

**Debugging**: `op1_dbg("text", a, b)` (op1r 42's call): host builds print `dbg: text a b` to stderr; on the
OP-1 it is an empty call, fine in any thread but not per sample; an emulator can log it by the core's `_op1_dbg`
address (`build/synth.sym`).

**Helpers**: `OP1_SINE_TABLE` (8192 x int16), `op1_sat16`, `op1_mul16` (Q15). Second knob pages and latching
presses: the `press` field (see the comments in `op1_plugin.h`). A synth engine with `uses_sample` can set a press
to `OP1_PRESS_BROWSE`: the core's sample browser (the sampler presets) loads one into the slot's sample buffer and
the slot keeps the engine and its patch (Granular's white press).

## Rules (the code runs in the audio interrupt)

A crash, a very long block or an endless loop locks the OP-1 until it is switched off.

- **Integers only.** There is no FPU; float is emulated and far too slow. Use Q15 fixed point.
- **No division or modulo per sample**, no 64-bit arithmetic per sample (both are slow library calls). Per block
  (once per `render`) is fine. Multiply by a precomputed reciprocal instead.
- **No libc**: no malloc, printf, memcpy, memset. Write the loops.
- Keep the per-sample work small: the OP-1 has one DSP core shared by the instrument, FX, tape and UI.
  The resource monitor (clock screen + T1 on the OP-1) shows the load.
- Saturate before storing 16-bit values (`op1_sat16`).

## Own screen (optional)

Without `screen`, synths use the stock iter graphics and FX a generic page with the 4 knobs. For an own screen:
- an SVG (320 x 160, OP-1 line style; the file name must not clash with the OP-1's own `content/display` files),
- `op1_screen_t` with `init(scr)` (look up SVG nodes by id) and `update(scr, dt)` (every frame: move nodes, draw
  lines),
- `"screen": { "svg": "mysynth.svg", "symbol": "SCREEN_mysynth" }` in `plugin.json`.

Screen placement: follow [Placement and OLED bottom margin](../docs/screen-art.md#placement-and-oled-bottom-margin).
Keep essential glyphs, strokes and animation travel away from the lower edge. Existing
SID/C64arp/Plate/Warble/Crush/Father screens have a four-logical-pixel upward correction;
preserve it exactly once in both generated art and live drawing/text. A host preview
inside 320 × 160 is not physical OLED acceptance.

Preview: `python3 harness/render.py mysynth out.png`. Look at `plugins/supersaw` (synth) or `plugins/tape` (FX).
Colours: blue #4D9EFF, green #00ED95, white #FFFFFF, red #FF3A5D, grey #6F7173. Line ends are flat and zero-length
lines are not drawn (draw a dot as two short crossing lines).

## Submitting

Open a pull request with your `plugins/<name>/` folder: sources, `plugin.json`, a WAV made with `audio.py` and,
with a screen, a preview PNG. Keep your copyright line in the sources; by submitting you license your plugin under the same terms as op1r
(GPL-3.0-or-later with the OP-1 firmware permission). The maintainers test it on hardware, assign
its number and include it in a release; users can still hide any plugin when they patch their firmware.
