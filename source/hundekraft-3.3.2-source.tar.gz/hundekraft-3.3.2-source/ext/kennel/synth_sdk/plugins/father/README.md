# Father

Father is a stereo ambience effect for the original OP-1 running the current kennel 3.0 core. Its sound is an original feedback delay network, inspired by the spacious role of OP-1 Field Mother. Its screen follows the owner's supplied video of **Father**, whose original controls were distance, mod, color and mix; green now controls a wet gate. These are separate references; Father does not reproduce or contain Teenage Engineering's DSP.

| Encoder | Control | Behavior |
|---|---|---|
| Blue | distance | More predelay and a longer decay. Predelay spans 0–30 ms; the ideal unfiltered network's decay target spans 0.35–8 seconds. Damping makes the audible decay shorter. |
| Green | gate | Zero disables gating; turn up to shorten the tail hold from about 1.8 s to 80 ms, followed by a rounded fade. Enabling waits for a new input attack before shaping the existing tail. Stereo-linked; predelay is included. |
| White | color | Dark, heavily damped reflections through to a brighter tail. Push: CLASSIC (below). |
| Orange | mix | Linear dry/wet blend. Zero is exactly dry when settled. |

Metadata defaults correspond to about distance 50, gate off, color 54 and mix 20 on a normalized 0–99 scale. Native filter-range conversion can round the initial distance to 49; these are not a claim that selecting an existing effect resets its saved controls. Pushing white turns CLASSIC on or off (saved with the sound in word 7, two steps; a sound saved before CLASSIC existed has 0 there and loads with it off; owner 2026-11-08: a push, no page to turn). While CLASSIC is on, page 1 shows a small "classic" right above "color", right-aligned with it, in a smaller size (the owner's pick, 2026-11-08). The ordinary OP-1 FX switch enables or bypasses the effect. Synth and drum effects use the mono callback; the master uses independent stereo input/output through the current stereo FX API.

## DSP

Eight unequal delay lines use interleaved normalized four-way Hadamard scattering. Since the 2026-10-29 redesign the lines run at 11,025 Hz, half the FX rate (see "Redesign" below). Each line spreads into four destinations per pass and all eight after two passes; the feedback paths have no dominant 3/4 self-return. Shorter, more widely spread delays increase the early tail density. Every line starts at a different modulation phase and moves slowly by about 2–3 tank samples (4–6 at the FX rate) at an independent rate. Two input allpasses per channel feed the tank; the existing short, crossfed early-reflection path bridges into the late tail. Color filters the early reflections and damps the tank, with a softer bright endpoint.

Gate is off by default. Green controls hold duration (about 1.8 s near zero, 80 ms at maximum), with a smooth closing fade (roughly 160–40 ms to −60 dB) and fast rounded opening. A shared stereo dry-input detector runs once per block at fixed low thresholds (32 to activate, 16 to release, about −60/−66 dBFS), with a clear rise retriggering it. Dry activity refreshes the hold. Enabling Gate leaves the current tail open until a new input attack arms it; disabling opens smoothly. Both early and late wet output share the gate, while the dry path and tank continue unaffected.

Predelay still spans 0–30 ms. The shortest late path now starts around 44 ms at default Distance, overlapping the early-reflection cluster rather than arriving separately. The late-return gain is +3.5 dB relative to the original voicing, trimmed from the previous +6 dB for more output headroom with the denser tail. Early/late output limiting, the linear mix law and callback mix ramp remain.

R246 calls an FX with 64 samples at 44,100 Hz (689 calls a second). Father decimates its input 2:1 and runs the design at 22,050 Hz inside (32 samples per call: the predelay and the early reflections), the tank at 11,025 Hz (16 per call), and interpolates the wet back to 44,100 Hz; the dry path stays at 44,100 Hz.

CLASSIC (2026-11-08, owner, after a user found 3.2's Father muddy and asked for the old one): hundekraft 3.1.4's Father, sample for sample. That is the design running twice as fast as intended, as it did on the unit before the rate fix below: predelay 0–15 ms, decay 0.18–4 s, the tank at 22,050 Hz with its tail up to 11 kHz, Color an octave higher, modulation twice as fast, Gate's hold and fade halved. Same rings and tables; per call the tank takes 32 samples instead of 16, the predelay ring gets the 64 input samples undecimated, the early reflections and the late sum come out at 44,100 Hz with no extra interpolation, the gate detector and predelay slew run every call, and the gate's per-sample steps are the design's (`>> 5`, closing rate 64..256). The kernels take their loop counts from their argument structs. Turning CLASSIC on or off clears the state the way selecting the FX does (6 calls of dry input), since the two modes leave different things in it. Checks: `classic_check.py` builds `classic_run.h`'s run against kennel `bd899531`'s `father_dsp.c` (3.1.4) and against this one in CLASSIC and compares the hashes (equal; `father_test.c` asserts that hash), `father_test.c` / `kern_check.py` hold the C and the Blackfin kernels to `father_reference.c` in both modes, and `rate_father_test.c` measures CLASSIC at half the design times (18.4 ms, RT60 0.97 s). With CLASSIC off the output is unchanged (`exact_check.py` against main with CLASSIC forced off: 49 regimes bit-exact). Cost (bcore, `budget_check.py`, mono at position 0): about 9.3k packets a call off, 12.1k in CLASSIC; the master call 11.6k / 14.5k. The state grew to 23,076 bytes (the rows and tank input sized for 32 samples). Not heard on the unit.

Rate note (2026-11-03): Father was written for a 22,050 Hz callback (the old reading of `0xFFA02B34`), so on the unit every time ran at half its design: predelay 0–15 ms, decay 0.18–4 s, tank modulation twice as fast, Color's cutoffs an octave up, Gate's hold and fade halved. Now the input goes through one more 2:1 half-band (`fa_decim`) before the predelay ring and the wet through one more x2 interpolator, so every table and constant keeps its design value; the gate detector and the predelay slew run once per two calls (the design's 2.9 ms callback), and the gate gain's per-sample steps are halved (opening `>> 6`, closing rate 32..128) for the same times at 44,100 Hz. The cost went down (bcore, mono at position 0: 10.6k -> 8.2k packets a call) and the state by 252 bytes (22,756). `harness/rate_father_test.c` checks the first wet sample at full Distance (36.8 ms) and the decay at half Distance (RT60 about 1.9 s with Color bright; 0.97 s before). Not yet heard on the unit. State fits in the existing 176,460-byte scratch area at each of the three FX positions. No heap allocation, floating point or division runs in the audio loop. All delay, filter, interpolation and modulation state belongs to its instance.

`gen_tables.py` generates the ring geometry (`father_lines.h`) and the feedback coefficients (`father_tables.h`) analytically from line lengths and the target decay. The network topology and implementation are original. State occupies about 23 KB per FX position (was 93 KB), including 1 KB of per-callback rows, in the existing per-instance scratch (no new ISR stack arrays). The textbook reference is Julius O. Smith's [FDN Reverberation](https://dsprelated.com/freebooks/pasp/FDN_Reverberation.html), particularly lossless feedback matrices and damping. No source code was copied from that reference. A public [Father demonstration by xylograph](https://www.reddit.com/r/OP1users/comments/1x422ip/father_a_stereo_algorithmic_reverb_running_on_the/) describes a separately developed OG-1 reverb; no code or DSP from that project is included here.

Teenage Engineering's [OP-1 Field guide v1.7](https://assets.teenage.engineering/_img/69f248938d433104c4dd1846_original.pdf), page 24, lists Mother's controls as distance, gate, color and mix; it does not disclose the DSP algorithm or parameter ranges. The owner requested replacing **mod** with **gate** to approach Mother's documented controls. The exact TE detector/timing are unpublished. Our gate approximation is the duration-based design described above; it is not a reproduction of an unpublished TE algorithm. Zero disables gating, and the tank is never cleared when the wet envelope closes.

[Media Integration's Mother demonstration](https://www.minet.jp/contents/article/op-1-field-feat-yumi-iwaki-vol5/) describes gated tails, especially with short envelopes/drums. This informs the behavior, not an exact recreation of Mother's DSP. No matched listening or tests were run for the gate change.

## Redesign (2026-10-29)

On the unit Father cost about 19 % of an audio block, most of it SDRAM traffic rather than instructions: the OP-1's data cache does not fetch a line on a write miss, and the old design wrote its eight 8 KB tank lines and two 8 KB predelay rings mostly before reading them, about 1,240 single SDRAM writes per call. The owner picked candidate A of `docs/father-redesign.md` (source-only A/B: root `run/father-redesign-2026-10-29/index.html`). It is the same network with three changes:

- The tank runs at 11,025 Hz. A half-band decimator feeds it and a 4-tap interpolator brings the late sum back to 22,050 Hz (and since 2026-11-03 a second pair takes the input from and the wet back to R246's 44,100 Hz, see the rate note above). Delay times and decay per second are unchanged; the damping pole is squared so Color keeps its cutoffs. Nothing above 5.5 kHz reaches the late tail. The predelay and the early reflections stay at 22,050 Hz, so the reverb's attack keeps its top end up to 11 kHz.
- Every tank line and allpass is a ring exactly as long as its longest read. A callback reads the samples it then overwrites, so the writes land in cache lines the reads already fetched. The predelay ring and the per-callback rows are touched (one load per 32-byte line) before they are written. `father.c` puts the state on a 32-byte boundary.
- Each line's modulated delay is held for a callback. It moves less than 1/100 sample per callback, so this is inaudible, and the read becomes one fixed-fraction loop.

After a select the state is cleared 1,024 words per callback (`MW_CLEAR_WORDS`, `fx_spread.h`) with the input passed through dry meanwhile: 6 callbacks, about 9 ms. The old design cleared 93 KB inside one callback.

`father_reference.c` is now the plain C reference of this design (every ring index wrapped per sample). `father_dsp.c` must match it bit for bit, output and persistent state: on the host with its C pieces (`check.py`, under ASan/UBSan), on the Blackfin with `father_kern.S` (`kern_check.py`). The kernels:

| Kernel | Work |
|---|---|
| `fa_decim` | a 2:1 half-band (saturating extraction), 6 packets per output: the input to 22,050 Hz and the predelay tap to 11,025 Hz |
| `fa_ap2` | both input allpasses of a channel, two samples per pass, read and written in place |
| `fa_line_read` | one tank line: interpolation and damping as MAC sums, 10 packets per sample |
| `fa_early` | one channel's early filter (as before, on the new ring) |
| `fa_late` | one channel's late sum, interpolated and added to the early row |
| `fa_tank_write` | one Hadamard group's write-back to four circles (as before, rows as int16 pairs) |
| `fa_out` | gate, dry/wet and peak, from the old `fa_mix` |

Cost per call, bcore packets plus a cache model of bcore traces (root `run/father-redesign-2026-10-29/meas/final.md`): mono 13.2k -> 10.7k packets and 205 / 1,238 / 32 -> 122 / 67 / 82 line fills / single SDRAM writes / write-backs, about 14.9 % -> 8.4 % of a block with a cold cache (7.2 % -> 2.3 % with Father alone in a warm cache). The stereo master call: 15.2 % -> 9.8 %. `cost_check.py`: mono 14.5k -> 12.2k packets. These are models; the unit's page 5 and 7 readings decide.

## Historical checks and remaining acceptance

The evidence below predates the Gate control; it does not validate the new wet gate.

Run `python3 ext/kennel/synth_sdk/plugins/father/check.py run/father-host` from the containing OP1-Emulator checkout. The focused host checks exercise full-scale endpoint combinations under ASan/UBSan, exact dry output, silent input, separate instance state, stereo decorrelation, distance-dependent decay and an audible modulation change. The output folder contains a stereo wet impulse WAV and numeric evidence. These checks do not establish native screen rendering, Blackfin CPU headroom or real OP-1 sound.

Targeted emulator evidence in the containing OP1-Emulator checkout:

- `run/father-native/result.json`: 17/17 functional checks pass, 128.022 seconds, normal exit zero. It checks selected identity and exact relocated code, synth/drum/master callbacks and audio, bypass, four controls and mix maximum. This tested the earlier `7ac0cd60…` art pack.
- `run/father-visual-final/result.json`: 10/10 final-motion checks pass, 77.261 seconds, normal exit zero, pack `a2e7c5a1…`. Actual default/near/far frames show head movement, an unchanged declared room strip and idle bypass. The subsequent footer-only cleanup removes our duplicate FX-off lettering in favor of the stock overlay.
- `run/father-clean-native/result.json`: 6/6 footer-cleanup checks pass, 48.352 seconds, normal exit zero. Final pack SHA-256 is `13929fcbe42c2d87d516a2b74ee28d859a3c4491a38cbfad119084c322242046` (`build/father-clean/father.knl`). Actual normal and idle-off frames have contained artwork and labels, with only the stock FX-off overlay. This supplements the earlier motion checks; it does not repeat audio or cost checks. `build/father-clean/cost-audio-equivalence.json` records equal allocated audio-object sections and normalized relocations against the measured budget pack.
- The first visual run retains its failure in `run/father-visual-native`: the test compared a raw distance word with a normalized Q15 endpoint. The corrected runner reads the SDK-documented native filter table and reaches its exact endpoints, raw 64 and 14528, through real encoder input. No FX change was needed.
- `run/father-budget-opt/cost.json`: six separate mono/master default/min/max cases measure 62,748.9–63,055.2 packets per 64-sample callback, after settling. The focused optimization preserves every output sample and persistent state byte against `father_reference.c` for 6,000 changing-control stereo blocks. Father is heavier than Plate's roughly 35k packets. Packets omit cache and SDRAM stalls; physical sysmon measurements remain necessary, and heavy synth/FX combinations are not accepted by this result.

The inherited native audio fixture is quiet: synth peak 0.001117, drum 0.055015 and cascaded master 0.000210. Wet correlation 0.44388 versus the dry repeat's 0.64546 establishes the bounded comparison, not representative musical gain. The separate host dry/mix/wet chord WAVs and full-scale endpoint checks cover the DSP itself. No all-plugin or hardware-performance claim is made.

## Audio budget follow-up (2026-10-17)

The owner's `FATHER MUTED - TOO SLOW` report is the core's existing 64-consecutive-call,
193,000-CCLK FX guard. That guard and fallback are unchanged. The earlier packet
fixture does not model the unit's cache/SDRAM stalls and did not establish hardware
headroom.

Tank reads and writes now run line by line across a callback, keeping recurrence state
in registers and accessing nearby samples together. The shortest nominal tank delay remains
1,493 samples (at least 1,481 with modulation), longer than the 64-sample callback, so every current read precedes any
write it could observe. Diffusers use the same block scheduling. Audio, damping,
feedback and phase advancement still run at the full sample rate. The slow fractional
delay modulation is evaluated every eight samples and linearly interpolated between
exact endpoints. This is an approximation, with a conservative delay error bound of
5/256 sample; every modulation word swept around both triangle cusps observes at most
2/256 sample. Controls, line count, feedback coefficients and delay lengths are unchanged.

`run/father-budget-fix/settled/cost.json` in the parent checkout measures six independent
mono/master default/min/max cases at 50,374–51,015.8 packets per callback, versus the
previous settled 62,748.9–63,055.2. The 35,040-packet development target remains unmet;
this reduction and improved locality require physical-unit validation before calling
the hardware mute fixed. No watchdog relaxation is part of this change.

The focused sanitizer check compares 6,000 changing-control full-scale blocks,
alternating mono/stereo, with the retained full-rate reference: worst difference
59 LSB and RMS difference 0.0001072 of full scale. The deterministic chord comparison
has an exact dry endpoint, at most 1 LSB at mix 30 and 3 LSB at full wet; respective
RMS differences are 0.00000808 and 0.00001546 of full scale. It also checks exact phase,
predelay/diffuser state, silence, per-instance isolation, all control endpoints, tail,
stereo separation and color response. These are signal/error bounds, not a listening
claim or hardware CPU acceptance.

The exact rc-3.0x all-50 fixture passes the same bounded native journey before
(20/20, 102.295 s) and after (20/20, 108.570 s): original core image unchanged,
exact relocated Father text, sustained notes beyond 64 callbacks, enabled/bypassed
post-release tail, zero mute flags (and zero recorded strikes after). Afterward wet
RMS is 0.000172 versus bypass 0.000008. Actual native pixels retain the room, person,
cassette, bust, grid and labels. Tested file: SHA-256
`c1749f60834aa650271c573a22566f8117348b456e333f791dd3f4947447ba7b`,
`run/father-budget-fix/packages/father.knl` in the parent checkout. The emulator also
passes before the change, so these gates do not reproduce or close the owner's
physical watchdog failure. The private installer changes only `content/father.knl`;
no published package, pin or site changes.


## Screen reference and measured motion

The owner supplied `m2-res_1080p.mp4`, a filmed demonstration of Father. The matching
public demonstration is credited to xylograph (link above). The vector scene here
is an original reconstruction from that video, not imported Maiko or TE artwork.
The Maiko permission used by other plugins is not the provenance for Father.
The raw video and extracted frames stay private and are not distributed.

`gen_svg.py` maps the measured filmed display bounds, approximately x620–1255 and
y66–370, to 320×160. Perspective, illumination and video compression limit accuracy;
this is not an exact digital-screen trace. Frames at 2, 3 and 4 seconds show distance
49, 99 and 80. The central cap/glasses head and shoulders retain a fixed vanishing
anchor near (156,94), with measured footprint ratios about 1, .40 and .63. The live
screen interpolates those ratios. Values below the observed range extrapolate the
projection and clip intentionally to the viewport; they are not measured video states.

The fixed ceiling/floor/back-wall grid and cassette remain at their
reference locations; the small person is green and follows Gate. The grid is visible through the face and bust; only glasses
lenses occlude it. The cap curve, hem, pupil strokes and cassette button strip, lower
holes and loose tape follow identifying details visible in the lossless source frames.
Owner screen polish (2026-10-17) raises the complete scene and native readouts twelve
logical pixels, matching the other three FX scene lifts. Green now shifts the small green person with shorter gate duration. Green door bars
close around it as the audio gate closes. The bust follows Distance. White changes the
bust from dark cyan to pale bright cyan, reflecting dark damping through bright tails;
the original cyan is retained at the default color value. This is new control feedback,
not motion measured from the reference video. MIX drives the right bar;
all four sound controls remain active even where the source does not isolate a visual
change. DISTANCE and labels use runtime native fonts, cached until text changes;
no firmware font is copied. The existing native FX overlay owns bypass dimming and its central FX OFF label;
the illustration adds no duplicate indicator or silence-based inference.

The generated SVG uses the established `svgart.shape`/`rounded` helpers, separate
filled contours, `#010101` lens cutouts and at most two decimal places. The C geometry
contains only original measured points. `screen_check.py` checks 18 observed-distance,
endpoint, mix and enabled/bypass states under sanitizers and an unclipped native-font
layout model. This is host evidence; installed rendering is a separate gate.

### Phase audition pair

Run `python3 synth_sdk/plugins/father/presets.py OUT` from the kennel repository root to generate `father-ab.zip` and two original Phase presets. Both use the same voice, envelope and Father controls; only their names and saved effect on/off setting differ. The files contain no stock audio. Copy `father_ab` into the OP-1's `synth/` folder, eject and sync. In the synth browser, select FATHER_AB and FATHER-OFF or FATHER-ON, then press 1. T3 opens the effect page; pressing it again toggles the effect. Keep the global master effect off for comparison.

`run/father-presets-audition/result.json` passed 26/26 checks in 117.289 seconds, with normal exit 0 and the source NAND unchanged. Actual browser loads selected Phase (runtime type 7), byte-matched the final Father plugin, retained identical voice/envelope controls, restored the two saved effect states, and passed T3 off/on checks. Native mono note RMS was 0.032471 off and 0.023430 on; released-tail RMS was 0.000008 off and 0.000178 on. A read-only database check after normal quit confirmed that only the names and effect on/off settings differed.

The USB transfer and indexing occurred in an earlier setup phase. The accepted audition resumed clones of that imported NAND; it is not a seamless import/restart pass. Retained failed setup attempts exposed boot-readiness/sync waits, a missing prerequisite after the safety fallback, a whitespace dump filename, and a database-ID versus runtime-type oracle error. No Father DSP or acceptance thresholds changed. Physical hardware performance remains unverified.

## Earlier reverb voicing update (2026-10-17, superseded)

Gate now defaults to zero, allowing the natural tail to decay. Existing loaded
slot controls remain their current values: turn green to zero to hear the
ungated reverb. The generated Phase audition pair also uses Gate off.

Predelay spans 0–30 ms instead of 0–80 ms. Four early-reflection taps per output
use offsets149/263/421/631 samples on the left and173/307/487/733 on the right,
plus the current predelay, at22,050 Hz. At default Distance the first return
is about22 ms and the last early tap about48 ms; the shortest late-tank path
starts about83 ms. The tap gains are1/4,1/8,-1/16,1/16, with crossfeed on the
second and fourth taps; Color filters their sum. Absolute gains total1/2 per
output before that lowpass.

Late output gain rises by6 dB without raising feedback injection or changing
the decay table, tank delays, damping law or feedback stability. Linear mix
scaling and its callback ramp stay unchanged. Output remains limited to the
16-bit range after the early/late sum. Two color-filter states add8 bytes per
instance; the early taps reuse existing rings and allocate no new delay buffer.
When Gate is off, its peak detector, hold and gain calculations are skipped.

Rebuilt and updated in the local webapp without tests. All earlier audio/error
and budget results above describe older voicings; they do not validate this
wet gain, early path or hardware load. Sound, peak behavior and hardware
headroom remain for owner acceptance.

## Lusher tail and duration Gate (2026-10-17)

The owner reported metallic ringing and an immediate tail cut when Gate was
enabled. The current design above supersedes the threshold-controlled gate
and previous tail matrix. Tank lengths are641/887/1153/1429/1867/2131/2683/3163
samples; `gen_tables.py` regenerates the same0.35–8 s nominal decay curve for
those lengths. The interleaved four-way scattering uses additions and halves,
with no new feedback multiplier or extra delay line. Two independent groups
cross through their permuted destinations. Color's damping coefficient now
spans1800..21800 rather than1800..29300. Independent slow phase offsets and
4–6 sample delay motion replace the old shared-phase two-sample motion.

The block-rate detector stays aware of input while Gate is off. On enable,
the wet envelope stays open until a fresh threshold crossing or clear attack;
thereafter dry activity refreshes the selected hold. Enabling during silence
therefore preserves a tail instead of closing it. Trigger thresholds do not
rise with green. Closing rates and hold times vary smoothly with green;
reopening is rounded. Gate defaults remain off.

The old mean workspace is removed; three gate flags add four aligned bytes,
for a net252-byte scratch reduction per instance. No new allocation, sample
rate, voice limit or combination budget policy is introduced. Existing
Oxbow+Father crackling remains an open hardware report; these changes do not
establish CPU headroom or guarantee crackle-free playback.

Only builds/package and served-file comparisons were performed, as requested.
No tests, audio rendering/listening or hardware measurements. The intent is
a denser, softer stereo reverb, with no claimed sound match to Field Mother.

## Exact-sound performance update (2026-10-19)

The current eight-line voicing is unchanged. Contiguous delay-read spans, a separate feedback pass, padded tank heads and per-position normalization caching reduce default Blackfin instruction work from60,073 to51,302 packets per64-sample render with real filter ranges (~14.6%). Changed controls normalize immediately, including LFO and master edits. Padding adds256 bytes within the existing scratch. No half-rate processing, shorter tail, reduced voice count or changed watchdog is used.

`father_reference.c` now freezes the immediately preceding current voicing. `check.py` runs exact-output differential and cached-wrapper edit/re-init checks as well as signal/sanitizer coverage. The retained integer network has a roughly one-LSB tail floor; the decay check bounds it explicitly. See parent `docs/archive/father-mbira-performance-2026-10-19.md`. Hardware rapid-note/combination acceptance remains open.

## Blackfin kernels (2026-10-27, superseded by the 2026-10-29 redesign)

Father now runs almost all of its per-sample work in `father_kern.S`, hand-scheduled Blackfin code. The output is the same, sample for sample, as the C in `father_dsp.c`. The C loops are still there: host builds (`check.py`, the screen and golden harnesses) use them, and the `.S` assembles to nothing outside the Blackfin build.

| Kernel | Replaces | Packets per sample, before -> after |
|---|---|---|
| `fa_input` | predelay writes and the input peak | ~27 -> 2 |
| `fa_front` | predelay read and both input allpasses, per channel | ~38 -> 19.5 (two samples per pass) |
| `fa_tank_read` | the eight modulated tank reads with damping | ~18 -> 4.5 (two lines per dual MAC), plus a group setup shared by both lines |
| `fa_early` | the early filter, per channel | ~21 -> 10 |
| `fa_mix` | late sum, early return, gate and dry/wet mix | ~90 -> 22 (gated: estimated ~30, not measured on its own) |
| `fa_tank_write` | the Hadamard write-back, per group | ~97 -> 26 |

On the Blackfin the tank-read output (`block`) is stored as pair words, line 2k + 1 in the high half and line 2k in the low half, so the mix and the write-back load two lines with one load.

Per 64-sample call on bcore (`cost_check.py`): mono 42.8k -> 14.5k packets, stereo master 44.2k -> 15.6k. In the burst regimes (`cost_check.py --bursts`) the average block went from 41.7k to 13.4k and the slowest later block from 44.3k to 14.2k. With the unit model (10.1 % + 0.478 % per 1,000 packets per block), Father alone now costs about 6.4 % of a block instead of about 20 %. The first block after a select is still about 37k, because that is `mw_init` (24.8k) plus a render; `FX_SPREAD_INIT` (off by default) spreads that clear.

Four tricks keep the kernels exact:

- `fa_front` writes both allpass rings and `fa_input` both predelay rings two samples per 32-bit store (half the SDRAM writes of 16-bit stores); `fa_input` falls back to its 16-bit loop when a ring, l, r or the head is not word-aligned.
- The rings are read through circular I registers (B/L), so the C's ring-edge and wrap fallbacks are not needed on the Blackfin. Any head works, not just multiples of 64. `fa_front` still requires a block start on a multiple of 64 and falls back to C otherwise.
- `mul()` rounds toward zero. The kernels add 32767 to negative products as a separate multiply term (the sign times -32767), then take a truncating 16-bit extraction of the fractional sum. That gives exactly `(v + bias) >> 15`.
- `sat(half(x))` in the write-back is `(x - (x >>> 31)) << 15` with a saturating shift, and the result is read from the high half. The diffusers use 16-bit saturating add and subtract, which is exact because both operands are int16.
- Products whose factors are wider than 16 bits (`damp - v`, `w - a`, `x - e`, the interpolation's `p1 - p0`) are split into 16-bit products, so every multiply is a 16x16 MAC.

Checks: `exact_check.py father` (49 regimes, bit-exact against the C build) and `kern_check.py`. The second builds `kern_guest.c` with `father_dsp.c`, `father_kern.S` and `father_reference.c`, and runs it on bcore. It compares `mw_process` with the plain-C reference at every control endpoint with full-scale input, on noise with changing controls, mono and stereo, at heads that wrap inside a block, and with the gate closing and reopening. It also runs `fa_tank_read` and `fa_tank_write` alone on full-range random data. The regimes never reach the saturating paths in the write-back; the direct test does. Several of the saturating and rounding steps were broken on purpose to confirm that a check catches each one.

One gap: both checks verify against bcore's model of the fractional MAC, the truncating extraction and the saturating shift, not against the unit. R246's own code uses the same instruction forms, so the model is probably right, but this is where a hardware difference would show up as a sound change. Listening on the unit and sysmon readings are still open.
