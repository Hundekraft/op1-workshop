# C64 arp

A musical-clock arpeggiator inspired by C64 player pitch tables. This plugin sends
ordinary OP-1 notes to the selected instrument. It does not emulate SID oscillators,
register waveforms or 50 Hz pitch-register writes.

Primary references: Lasse Öörni's [GoatTracker v2.72 manual, section 3.4.1](https://github.com/leafo/goattracker2/blob/master/readme.txt)
describes relative/negative/absolute pitch entries, frame delays and looping table
rows. Linus Walleij's authored [SID-player pseudocode](https://codebase64.net/doku.php?id=base:a_sid_player_routine)
explains MIDI-root-relative arpeggio macros. These inform the table concept; the
kennel implementation is original C, not copied player source.

Choose `c64arp` in the sequencer browser, use the standard SEQ button to enable it,
and hold a root key. Orange right turns HOLD on (stock arpeggio behaviour), left
turns it off. PLAY is not required. Releasing the last held key silences it unless
HOLD is on. With HOLD on, released notes stay in the set; the first press after a
full release starts a new set. Turning HOLD off drops released notes and keeps the
physically held ones.
A new root takes priority; on release the highest remaining physical key becomes
root. STOP and player reset release the output and clear held/latch roots.
A fresh root is needed after STOP. Playback follows the stock player's delivery
of keys/ticks; there is no second Run control.

Default encoder page:

| Encoder | Control |
|---|---|
| Blue | OFF, custom (only while an edited table is playing), then the tables major, minor, major 7, minor 7, fifth, sus4, major up/down, minor up/down, octave, sus2, dom 7, dim 7, aug, add9, min 9, Alberti, then RANDOM |
| Green | 1/2, 1/4, 1/8, 1/8 triplet, 1/16, 1/16 triplet, 1/32, 1/32 triplet, 1/64 (left to right; 1/2 added 2026-11-10 as stored rate 8, the older rates keep stored 0..7, so saved rows read as before; a row with rate 8 is refused by builds older than this) |
| White | One to four octave cycles |
| Orange | HOLD on (right) / off (left); Shift+orange sets Gate, 10–100% |

Press any encoder to switch the whole screen between play and edit pages. On the
edit page, blue selects a row, green edits its relative semitone offset (−24 to +24),
white edits dwell (1–8 base steps), and orange edits note gate (10–100%). Shift
plus blue changes length (1–16 rows); Shift plus orange edits gate on both pages.

TABLE OFF (`cfg.table=0`, 2026-10-20 owner request) plays only the held (or HOLD-kept)
notes in ascending pitch order (ties by key), one base step each; rate, octaves
and gate still apply and the note's own key owns the voice. The rows are kept:
blue right restores the previous preset or custom table, and any row/length edit
switches the table back on.
Table/length/dwell edits mark the preset `custom`; selecting a preset replaces its
rows. Shortening a table past its current playback position releases immediately
and restarts its position at row 1. Notes outside MIDI 0–127 are silent steps.

RANDOM (`cfg.table=2`, 2026-11-06, user request): turn blue one more detent left from OFF. It plays the same
held (or HOLD-kept) notes as TABLE OFF, but each step picks a note and an octave (within OCTAVES) at random,
never the same note in the same octave twice in a row (2026-11-11, user report: one held note with OCTAVES 3 climbed
like an up-arp, since the octave still stepped in order). One held note at OCTAVES 1 just repeats. Rate and gate
apply as in TABLE OFF; blue right
goes back to OFF and then to the table, and any table edit switches the table on. The screen shows RANDOM where
TABLE OFF shows OFF (text only; the artwork and static-art cache are unchanged).

Each mode (synth/drum) keeps its own settings and table in versioned SQLite rows
`c64arpseq` (version 3 allows the table flag 2 = RANDOM; version-2 rows from 3.1.x keep flag 0/1; version-1 rows
from 3.0.2 load with the table on). Loading validates every range. Playback, note IDs, held keys and a
latched root are never saved. A normal synth save/restart journey verifies the
settings and table return with playback stopped and no held or latched root.
Drum settings are independent; drum restart persistence has not been exercised.

The unchanged owner-requested image `c64arp-art.png` was generated on 2026-10-16
with OpenAI image generation; original reference and prompt are in OP1-Emulator
`docs/design/c64/`. Its entire 1774×887 canvas maps uniformly to 320×160, followed by the owner-requested four-pixel upward translation
(2026-10-17 hardware review). The right readouts and footer move by the same amount. The SVG starts with measured flat colors and half-strength source boundaries,
then applies the owner-requested line weight and screen translation; raster
antialiasing differs.
The live controls occupy the reserved right region; a footer shows the current row.
The illustration is static. No TE fonts, screens or firmware bytes are included.

Current validation: focused sanitizer timing/release tests, 36 stroke-text
endpoint states and the source/contour raster comparison (undoing the four-pixel translation; four colors, both directions,
95th-percentile distance below one logical pixel after the requested width growth and at least 99% within 1 pixel). The Blackfin .knl packs
without unresolved libc imports. The real-input emulator journey verifies the
selected plugin's code and embedded SVG path, major-table notes/audio, release and
latch behavior, mode-change and STOP cleanup, maximum row editing, and a normal
synth save/restart with exact settings and replay. Native play/edit/restart screens
are reviewed separately. The write session and matched-NAND restart are separate
recorded phases; an earlier harness screenshot after normal exit failed before
launching its restart. No MIDI delivery or hardware load claim is made.

The 2026-10-17 hardware polish is checked against actual default, long-footer and
edit-page frames (row 16, offset −24, dwell 8, gate 100). The default framebuffer
is exactly the earlier frame shifted up five framebuffer pixels (four screen
units), including the footer. That translation is retained. The owner's follow-up
matches both artworks' thin ink to the synth's bottom leads (about 1.6 logical px
from native-frame coverage). `display/lineweight.py` preserves broad fills,
black channels and topology instead of uniformly inflating already-bold leads.
The palette and original 445 path count remain; vertices decrease. Native fonts
and readouts are unchanged. Fresh default native captures check this refinement;
the owner's hardware OLED review remains open.


## SVG text compaction (2026-10-17)

`gen_svg.py` finishes with the shared `display/compact_svg.py` serializer. It keeps
all coordinates, colours, contours, IDs and the four-pixel raise. It removes unused
stroke parameters from unstroked fills and whitespace around explicit M/L/Z commands.
The SVG text drops from 137,207 to 101,613 bytes; the plugin file is 110,616 bytes.
No tests or rendered comparisons were run for this owner-requested text-only change.

2026-10-18 control change: Run removed at owner request. Earlier runtime evidence above predates this change; no tests or native captures were run for it.

2026-10-20 control change: HOLD moved to plain orange on the main page (Gate to
Shift+orange there), and TABLE OFF added. Host logic/geometry tests (`check.py`) and
a Blackfin pack pass; the emulator journey was updated for the new mapping but not
run, and native screens/manual captures still show the earlier GATE label.


## Screen cleanup (2026-11-14)

The art's pale light-blue lines sit between the white and blue palette directions, so the per-pixel trace split them
into white and blue specks, which the 1.6 px line weight grew into dashed debris along the board edges (plus 190
specks and about 100 pinholes, each a path). `gen_svg.py` now gives each line one colour (the colour of most of its
pixels; small or thin pieces touching other ink take that ink's colour), drops isolated flecks, fills trace pinholes,
cuts any outline over 256 vertices into two overlapping halves, and no longer bridges contours (svg_lite step 0, so no
walked-back steps). 261 -> 126 paths, 6,171 -> 2,652 vertices, 85,836 -> 37 KB. `art_check.py` now sets its bar on
the ink of all colours together (per-colour numbers are still printed): placement p95 0.65 -> 0.57, missing p95
0.72 -> 0.65. Native screen memory and the OLED look are not measured yet.

v2, same day (owner on v1: "all lines should be contiguous and same color"): white and blue are drawn as centre-line
strokes instead of traced outlines. The two colours form one ink mask, so the art's pale lines aren't split; centre
lines are split at junctions, spurs dropped, each piece takes the colour most of its pixels have, and straight
continuations of one colour are joined, so each line is one stroke of one colour. Width is 1.6 where there's room and
narrower where another line runs closer (0.6 units of black stay open: key-top double rings, chip legs); circular
loops are `<circle>`s. Green and red stay filled outlines. 152 elements (129 strokes, 23 fills), 1,074 vertices,
27,679 B (release 261 / 6,171 / 85,836). `art_check.py` (all colours): p95 0.54 both ways, 99.8-100 % within 1 px.
Most lines are now thinner than 1.6 (36 at the 0.8 floor), closer to the art; the native frame and OLED are unchecked.
