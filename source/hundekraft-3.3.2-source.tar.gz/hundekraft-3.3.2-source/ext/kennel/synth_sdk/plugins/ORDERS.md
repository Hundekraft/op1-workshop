# Plugin numbers

Each synth and FX plugin has an `order` in its `plugin.json`. Saved sounds store it (`knobs[4] = 0x5300 + order`),
so a number means the same plugin forever: never renumber or reuse one after a release. Gaps are fine; a sound
whose number has no plugin in a build plays the stock iter (synth) or filter (FX). Orders run 1..31 per kind
(`OP1_MAX_ORDER`). Claim a number here before you ship. The table shows saved names; ids and the naming rule:
`docs/plugin-format.md` "Names" (`in a room` is the folder `in_a_room`).

| order | synth | FX |
|---|---|---|
| 1 | supersaw (op1r) | tape (op1r) |
| 2 | fmbell (op1r) | clouds (op1r) |
| 3 | granular (op1r) | reverb (op1r) |
| 4 | wavetable (hundekraft) | washer (hundekraft) |
| 5 | taffy (hundekraft) | snowglobe (hundekraft) |
| 6 | pew (hundekraft) | palme (Musica Obscura, #1) |
| 7 | elg (hundekraft) | in a room (Musica Obscura, #1) |
| 8 | mixtur (Musica Obscura, #1) | ente (op1r 52, pcppcp) |
| 9 | arc (Musica Obscura, #1) | |

| 10 | aether (op1r 33–40; native kennel file) | |
| 11 | reactor (hundekraft) | |

Amp is a loadable input engine without a fixed order (allocated by saved name); it does not reserve or renumber any released order. Its `input_engine` flag requires the new input-host core.

Hollow Saint (`hollowsaint`, SammiBabe666, 2026-10-29) is loadable without an order, like Brassophone, Nostromo and
OUTATIME: its sounds find it by saved name ("hollowsaint", knobs[4] = 0x5300). It claims no number here.
BLOODMOON (`bloodmoon`, SammiBabe666, 2026-10-29) is loadable without an order, like Hollow Saint, Brassophone and
Nostromo: its sounds find it by saved name ("bloodmoon", knobs[4] = 0). It claims no number here.
blot (`blot`, pcppcp, op1r 48, 2026-10-31) is loadable without an order, like Hollow Saint and BLOODMOON: its sounds find it by saved name ("blot", knobs[4] = 0x5300). It claims no number here.
VAPORA (`vapora`, AiAAAA, op1r 47, 2026-10-31) is loadable without an order, like Hollow Saint, BLOODMOON, Brassophone and
Nostromo: its sounds find it by saved name ("vapora", knobs[4] = 0x5300). It claims no number here.
Moai (`moai`, fungiboletus, op-moai 71c58d5, 2026-11-03) is loadable without an order, like Hollow Saint, BLOODMOON and VAPORA: its sounds find it by saved name ("moai"; Moai leaves knobs[4] to the core). It claims no number here.
strum (`strum`, hundekraft, 2026-11-03) is loadable without an order, like Hollow Saint, BLOODMOON and VAPORA: its sounds find it by saved name ("strum", knobs[4] = 0x5300). It claims no number here.
vox (`vox`, hundekraft, 2026-11-04) and snap (`snap`, hundekraft, 2026-11-04) are loadable input engines without an order, like Amp: their sounds find them by saved name ("vox" / "snap", knobs[4] = 0x5300). They claim no number here.
DIMENSION (`dimension`, hundekraft, DSP clean-room from a specification of another creator's engine, 2026-11-09) is loadable without an order, like strum and VAPORA: its sounds find it by saved name ("dimension", knobs[4] = 0x5300; not the original's 0x4F01 mark). It claims no number here.
KASTLE (`kastle`, modelled on displayname808's castle, 2026-11-10) is loadable without an order, like DIMENSION: its sounds find it by saved name
("kastle", knobs[4] = 0x5300). It claims no number here.
KHORUS (`khorus`, ported from another creator's chorus with the author's permission, 2026-11-11) is a loadable FX without an order, like DIMENSION and KASTLE: its sounds find it by saved name
("khorus", knobs[4] = 0x5300). It claims no number here.
HIM (`him`, ported from another creator's drum engine with the author's permission, 2026-11-09) is a native drum synth: drum kits find it by their saved type name
("him", the drum_types row and the kit folder "him"). It claims no number here.
chimera (`chimera`, hundekraft, 2026-11-12, branch `vocal-lite`) is loadable without an order, like Moai and strum: its sounds find it by saved name ("chimera", knobs[4] = 0x5300). It claims no number here.
PINBOARD (`pinboard`, hundekraft, 2026-11-13, branch `pinboard`) is loadable without an order, like chimera: its sounds find it by saved name ("pinboard", knobs[4] = 0x5300). It claims no number here.
PLOC (`ploc`, Nicolas Franck Pauly, PLOC 0.6.2, 2026-11-17, branch `ploc`) is loadable without an order (his plugin.json had `"order": 0`; it is dropped here, as kennel reads any `order` as a number), like Hollow Saint and VAPORA: its sounds find it by saved name ("ploc", knobs[4] = 0x5300 plus PLOC's own token). It claims no number here. Its controller `plocctrl` is a feature (no order).

Retired 2026-11-17 (owner): KASTLE, DX, HIM, DIMENSION, MATRIX and KHORUS are archived (`synth_sdk/archive/`, not built) in
favour of the bridged files castle, dx, sim, dimension, matrix and chorus. None of them held an order number (they load
by saved name, HIM by its drum_types row and kit folder, MATRIX as an LFO type), so no number is freed or reused. Their
saved names `kastle`, `khorus`, `him` and `matrix` stay retired: a sound saved with one finds nothing and plays the
stock engine, effect or kit. `dx` and `dimension` are now the saved names of the bridged engines (they were the ports').
