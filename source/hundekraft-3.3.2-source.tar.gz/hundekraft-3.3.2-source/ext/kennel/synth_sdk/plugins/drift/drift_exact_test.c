/* drift's engine against the reference: renders a fixed note sequence (six voices, first free else the oldest, a
 * knob track with ramps and jumps, every 7th block without the L1 lease so the voices hold) through the engine files
 * in DIR, the way the reference harness (render4.c) drives them, and prints an FNV-1a hash of the mix, which must be
 * LT_EXACT_HASH below. Until 2026-11-14 it was the reference's (OP1-Emulator run/neural-osc-2026-11-13, nosc2_core.h +
 * env4); since the owner's envelope-timing change (each voice's load live every block, the tick's wait bounded, two
 * voices taking a commit a block) only the blocks the envelope commits land on differ from the reference.
 *
 *   cc -O2 -Wno-unused-function -I DIR plugins/drift/drift_exact_test.c -lm   (DIR: this folder or the reference)
 * (from synth_sdk; make -C harness build/drift_exact_test runs it on this folder).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <nosc2_weights.h>                       /* <>: from -I DIR, not this folder */

#define LT_EXACT_HASH 1547208275u                 /* live load, owner 2026-11-14 (the reference's was 3218913511: the
                                                    * envelope commits now land at other blocks, nothing else differs) */

static struct nosc2_l1 l1_mem;
static struct nosc2_envnet env;
static struct nosc2_voice vs[6];
static int16_t mix[BLK], out[BLK];

static uint32_t rng = 12345;
static uint32_t rnd(uint32_t n) { rng = rng * 1664525u + 1013904223u; return (rng >> 8) % n; }

int main(void)
{
    enum { NBLK = 6000 };
    l1_mem = nosc2_l1_init;
    int32_t until[6] = {0}; int used[6] = {0};
    int16_t z[4], z0[4], z1[4]; int32_t k0 = 0, kd = 1;
    for (int j = 0; j < 4; j++) z[j] = z0[j] = z1[j] = 0;
    nosc2_env_fill(&nosc2_far_init, &env, z);
    uint32_t h = 2166136261u; int32_t next_note = 0, next_knob = 0;
    for (int32_t b = 0; b < NBLK; b++) {
        while (next_note <= b) {                                    /* a note: 1..5 at once */
            int n = 1 + (int)rnd(5) / 2;
            for (int c = 0; c < n; c++) {
                int v = 0; for (int i = 0; i < 6; i++) if (until[i] <= b) { v = i; break; } else if (until[i] < until[v]) v = i;
                int m = 24 + (int)rnd(72);
                uint32_t inc = (uint32_t)llround(440.0 * pow(2.0, (m - 69) / 12.0) / 88200.0 * 4294967296.0);
                nosc2_note_on(&vs[v], inc, (int16_t)lround((m - 36) / 60.0 * 4096), (int16_t)(1024 + rnd(3073)));
                used[v] = 1; until[v] = b + 40 + (int32_t)rnd(900);
            }
            next_note = b + 10 + (int32_t)rnd(300);
        }
        if (next_knob <= b) {                                       /* the knobs: a ramp, sometimes a jump (a fill) */
            for (int j = 0; j < 4; j++) { z0[j] = z[j]; z1[j] = (int16_t)((int32_t)rnd(16825) - 8412); }
            k0 = b; kd = 1 + (int32_t)rnd(800); next_knob = b + kd + (int32_t)rnd(200);
            if (!rnd(4)) { for (int j = 0; j < 4; j++) z0[j] = z1[j]; nosc2_env_fill(&nosc2_far_init, &env, z1); }
        }
        { int32_t x = b - k0 < kd ? b - k0 : kd; for (int j = 0; j < 4; j++) z[j] = (int16_t)(z0[j] + (z1[j] - z0[j]) * x / kd); }
        struct nosc2_voice *pv[6]; int np = 0;
        for (int v = 0; v < 6; v++) if (used[v] && until[v] > b) pv[np++] = &vs[v];
        nosc2_env_step(&nosc2_far_init, &env, z, pv, np);
        for (int i = 0; i < BLK; i++) mix[i] = 0;
        for (int v = 0; v < 6; v++) {
            if (!used[v] || until[v] <= b) continue;
            for (int j = 0; j < 4; j++) vs[v].in[3 + j] = z[j];
            nosc2_render(b % 7 == 6 && vs[v].age ? 0 : &l1_mem, &env, &vs[v], out);
            for (int i = 0; i < BLK; i++) mix[i] = n2_sat16(mix[i] + (out[i] >> 1));
        }
        for (int i = 0; i < BLK; i++) h = (h ^ (uint16_t)mix[i]) * 16777619u;
    }
    printf("DRIFT hash=%u\n", h);
    int bad = 0;
    if (LT_EXACT_HASH && h != LT_EXACT_HASH) { printf("DRIFT FAIL: hash differs from the reference's %u\n", LT_EXACT_HASH); bad = 1; }
    return bad;
}
