# DRIFT: the knob law, the Terrain screen and its interface to the engine

## The knob law (2026-11-14)

Each knob's word k (0..32767) maps to the net's latent z through its own table, `lt_zk[j]` in `drift_tables.h`: 65
points (k = 512 i), Q12, interpolated over the low 9 bits, the top word 32767 giving the last point; once a block, so
no CPU to speak of. `knob_law.py` measures and writes the law into `knob_law.json`; `gen_tables.py` (engine),
`gen_screen_tables.py` (the screen's `ds_z_of_knob`, the patches' knob positions) and `presets.py` read it. Before, all
four knobs used z = Phi^-1(0.005 + 0.99 k): the middle of each knob was the dense centre of the prior, where the
synth sounds sit, and the instrument-like patches were squeezed into the last few percent (clav at knob 0).

- Metric: a note (velocity 0.8, C3 and C5, the engine's C path through `knob_law_render.c`) is its log spectrum in 21
  bands (1/3 octave, at least 2 FFT bins, 60 Hz .. 20 kHz) in three windows (12, 145, 435 ms: attack, body, held),
  each band in dB floored 60 dB under the window's loudest band and taken relative to the window's mean (the spectral
  envelope: brightness, formants, noise between the partials), plus the window's level at half weight. The distance
  between neighbouring z is the RMS dB difference, averaged over the other three knobs held at each of
  {-1.6, -0.5, 0.5, 1.6}^3 and both notes. It hears what the net and the DSP voice do together, which the net's table
  alone does not. Checks: at twice the z resolution (193 points instead of 97) the arc lengths grow by 20 %, and the
  law (the tail shares below) moves by under 1.5 points; without the 60 dB floor (at 97 points) within 4 points.
- Result: timbre changes about evenly in z (0.4 dB a step at 193 points over -/+2.576, centre and tails alike; knob 3's
  tails up to 1.6x its centre), so the old law spent its travel badly: 0.2 .. 0.3 dB per 1 % of knob in the middle and
  7 .. 13 dB per 1 % at the ends.
- Law: k(z) = 0.75 k_arc(z) + 0.25 k_old(z), k_arc the measured arc length over its total, k_old the old
  (Phi(z) - 0.005) / 0.99. Pure arc length (blend 0) is even by construction (0.7 .. 0.8 dB per 1 %); the quarter of
  the old law keeps the centre a little finer (0.45 .. 0.55 dB per 1 %) at a worst of about 1.05 dB per 1 % in the
  tails (averaged over the held settings, not a worst case), against 7 .. 13 before, and puts 35 .. 44 % of the
  travel in the tails instead of 43 / 45 / 55 / 44 % at blend 0. Ends
  unchanged: z = -/+2.576 (now reached exactly at word 0 and 32767), so nothing reachable before is out of reach.

Travel per knob, the share of the knob's range by |z| (centre < 0.75, mid 0.75 .. 1.5, tails > 1.5):

| knob | before: centre / mid / tails | after: centre / mid / tails | dB per 1 % of knob, before -> after |
|---|---|---|---|
| 1 | 55 / 32 / 12 % | 36 / 29 / 35 % | 0.32 .. 7.4 -> 0.55 .. 1.05 |
| 2 | 55 / 32 / 12 % | 34 / 29 / 36 % | 0.26 .. 7.2 -> 0.49 .. 0.97 |
| 3 | 55 / 32 / 12 % | 29 / 27 / 44 % | 0.19 .. 13.3 -> 0.44 .. 1.07 |
| 4 | 55 / 32 / 12 % | 35 / 29 / 36 % | 0.28 .. 9.9 -> 0.51 .. 0.97 |

The presets keep their z: `presets.py` picks per knob the word whose new z is nearest to the z the preset had under
the old law (its `OLD_*`, for that only); `drift_test` reads the 27 files and checks each knob within one word's z
step of the old value (all 0 LSB off; metal's knob 1 sits at the end, 10551 now against the old table's 10544).
Re-measure: `python3 knob_law.py WORKDIR` (about 99,000 notes, under a minute), then `gen_tables.py`,
`gen_screen_tables.py anchors.json` and `presets.py`.


The screen and the engine (the neural oscillator, `drift.c` and the `nosc2_*` files) meet in one header,
`drift_view.h`; the engine's side of it is `drift_view.c`. The screen reads nothing else from the engine.

## Files

| File | What |
|---|---|
| `knob_law.py`, `knob_law_render.c`, `knob_law.json` | the knob law (above): the measurement, its note renderer (host only), the law |
| `drift_screen.c` | `SCREEN_drift`: the Terrain screen (GUI thread, integers only, static state of about 11 KB in plugin memory) |
| `drift_view.h` | the interface: the `drift_view` struct, `drift_view_sync()` and `drift_view_table()`, which the engine provides |
| `drift_view.c` | the engine's side: `drift_view`, its writes at note start / note_off / block start, `drift_view_sync`, `drift_view_table` |
| `drift_screen_tables.h` | the screen's lookup tables; `gen_screen_tables.py ANCHORS.json` writes it from the model's anchors file |
| `drift.svg` | the screen's SVG: only the sun (group `sun`, moved by the code) |
| `drift_view_stub.c`, `.h` | a stand-in engine side for host tests: scripted notes and knobs, made-up tables (doubles, host only) |

The test is `harness/drift_screen_test.c` (tier 1, in `make check`). It also writes the golden frames
`drift_*` that `golden.py` compares.

## What the engine fills, and when

`drift_view` is one instance, defined in the engine (`drift_view.c`). The screen only reads it. No locks are needed:
a torn read shows one odd frame at worst.

- note start (audio thread, voice v): add 1 to `drift_view.serial`, then set voice v's `serial` to it; `vel_q12`,
  `age = 0`, `released = 0`, `active = 1`.
- note_off (voice v): `released = 1`. A note pressed and released inside one block shows as held until the voice ends.
- once per block (audio thread): `knobs[]` = the four knob values the block rendered with (Q15).
- `drift_view_sync()` (GUI thread; the screen calls it once a frame before it reads): for each voice played, `tick`
  and `age` = the voice's own block count since note on, `pitch_q12` and `vel_q12` (the net's `in[0]` and `in[1]`),
  `note` (from the pitch), `prm[]` = the voice's DSP settings exactly as `nosc2_voice.prm` holds them (Q12, the
  engine's own order; the square-law levels stay squared). It reads the voices and changes nothing of the engine.
  `level` stays 0 (not drawn).
- `active` is not cleared. R246 stops calling render when its envelope ends, so the screen counts a voice as gone
  once its `tick` stops moving (90 ms).

`drift_view_table(pitch_q12, vel_q12, age, knobs, out, n)` returns the net's table for one note: `n` samples (64)
of one period at phases `i / n`, Q15, from the knobs in Q15 (the engine converts them to z as render does) and the
age in blocks (the engine maps it to its time input and caps it). It runs on the GUI thread, so it never touches
the L1 lease, a voice, or the audio thread's scratch. The const weights are fine wherever they live. The screen
calls it at most 9 times a frame, usually 0 to 4. Return 0 if it can't decode; the screen then keeps its old table.

The knobs the screen draws come from `op1_synth_knobs_live(OP1_SCREEN_SLOT & 7)`, the same values the stock
screens show, LFO included, so the ticks also move in silence. `drift_view.knobs` is only there to check that the
land and the sound agree.

## Joined with the engine (2026-11-14)

- `plugin.json` has `"screen": { "svg": "drift.svg", "symbol": "SCREEN_drift" }` and the sources in this order:
  `drift.c`, `drift_asm.S`, `drift_view.c`, `drift_screen.c`. Never `drift_view_stub.c`: it is for host tests, and it
  refuses to build without `OP1_HOST`.
- The engine side is `drift_view.c`: `drift_view`, `drift_view_sync`, `drift_view_table` and note_off. It is its
  own file, after `drift.c`, so that `drift.c`'s data keeps the cache layout the CPU pass measured (an engine data
  shift of about 0x300 bytes moved the worst block by up to 5 points at one load address). The stub defines the same
  symbols; the test (`drift_screen_test`) keeps using it.
- The audio thread writes the view only at a note's start, at note_off and once a block (the knobs). A per-voice,
  per-block publish cost up to 0.8 points in the cold model, so the screen calls `drift_view_sync()` once a frame
  and the engine copies tick, age, pitch, settings and note from its voices on the GUI thread. tick is the voice's
  block count: it moves while R246 renders the voice and stops when the voice ends.
- `drift_view_table` runs the net from `nosc2_l1_init` (the const weights in SDRAM) into its own static scratch with
  the voices' kernels; `drift_test` checks it gives the voice's own table, every second sample.
- `golden.py` renders the screen through `screen_harness.c` with the real engine: golden `engine_drift` (one note at
  the defaults, 166 lines; 166 to 174 at the knob corners, against the stub test's 210 median with a chord).
- In the emulator (2026-11-14): captures on both panels, the panel `b` edge check (3-5 px free at the sides and top)
  and 592 B of drawing heap. That build cut the setting sun flat at the ridge's highest point (a black gap of 1-2 px
  above the sloping ridge, faint grey seams of the black strips below it) and let gliders fly over the disc.
- Since then (2026-11-14): 16 strips, each from the topmost ridge at its centre down and overlapping its neighbours by
  1.3 px, so the cut follows the ridge and the ridge's stroke covers the join; gliders (and their plumb lines) and the knob
  wake's dots skip the part of a line over the visible disc (`ln_behind_sun`), so they pass behind the sun
  (`drift_screen_test` checks it). Still open: OLED acceptance on
  the unit, the decode cost per call on bcore.
