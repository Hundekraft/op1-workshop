/* drift host test (the glue in drift.c), in R246 units (128 samples at 88.2 kHz a call, OP1_PITCH_INC in 88.2 kHz
 * steps):
 *  - lt_pitch: (MIDI - 36) / 60 in Q12 from the phase increment, within 1 LSB for MIDI 0..127;
 *  - lt_zof: per knob, the ends at -/+2.576 (Q12 -/+10551, as the old Phi^-1(0.005 + 0.99 k) law), monotone; and
 *    each of the 27 presets (presets/NAME.aif, read from this folder) keeps the z the old law gave it, within one
 *    knob step of the new law (2026-11-14: knob_law.py's steps of equal timbre change replaced Phi^-1);
 *  - a note at A2, A3, A4 sounds at 110, 220, 440 Hz (autocorrelation over the held part, 1 %);
 *  - six voices struck together at the knobs' corners and the defaults, the knobs then swept: no voice silent, none
 *    at full scale for long, the mix stays finite; a note restarted on a sounding voice starts again (age 0);
 *  - the screen's view (drift_view.h, after drift_view_sync): note, age, pitch, settings, knobs, serial order, released
 *    after note_off; and
 *    drift_view_table gives the voice's own table (every second sample) for its pitch, velocity, age and knobs;
 *  - the preset trim (word 7): the same block from the same state at 1x, ~2x and 4x (capped) is the untrimmed one
 *    scaled by the trim, saturated on the rails, never wrapped.
 *   make -C synth_sdk/harness build/drift_test && synth_sdk/harness/build/drift_test
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "drift.c"
#include "drift_view.h"
#include "harness/r246_rate.h"
#include <string.h>

int16_t host_sine[8192]; int32_t host_pitch_inc[128]; uint8_t host_voice_mem[6 * 0x24]; int16_t host_voice_vel[6];
int16_t host_voice_env[128];
int16_t host_knobs[8][8]; int host_slot; const uint8_t *host_sample_buffer[8];
int16_t host_fx_knobs[3][8]; int16_t host_fx_meter[3]; void *host_fx_scratch[3];
volatile uint8_t op1_fx_page[3][4]; volatile uint8_t op1_eng_page[4]; uint8_t host_shift;
void *host_raster(void) { return 0; }
void host_raster_line(void *r, const void *a, const void *b, int32_t w, const uint8_t *c) { (void)r; (void)a; (void)b; (void)w; (void)c; }
void host_screen_draw(void *s, int dt) { (void)s; (void)dt; }
void *host_find_node(void *scr, const char *id) { (void)scr; (void)id; return 0; }
void host_node_set_transform(void *n, const int32_t *m) { (void)n; (void)m; }
void host_node_set_visible(void *n, int on) { (void)n; (void)on; }
void *read_fx_param_safe(int slot, int pos) { (void)slot; (void)pos; return 0; }

static int checks, fails;
#define CHECK(c, ...) do { checks++; if (!(c)) { fails++; printf("drift_test.c:%d: FAIL: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

/* the presets' z (Q12) under the old law (Phi^-1(0.005 + 0.99 k), 257-point table) at their old words, rc10 */
static const struct { const char *name; int16_t z[4]; } old_z[27] = {
    { "pluck saw", { -4881, 2838, 1791, -591 } },
    { "ep tine", { 3454, -5481, 4337, -3019 } },
    { "organ", { -4900, -6732, 880, -8867 } },
    { "clav", { -10551, 4012, 555, 227 } },
    { "harp", { 3750, -6478, -1597, -2657 } },
    { "marimba", { 4917, -3300, 2771, 1173 } },
    { "swell pad", { -6279, -614, -1255, -2315 } },
    { "pwm strings", { -6649, 382, -2237, -8113 } },
    { "glass pad", { 9659, -351, -5652, -2379 } },
    { "choir", { -5856, -9726, -4464, 2004 } },
    { "sync lead", { -4010, 6286, 6838, 430 } },
    { "square lead", { 3358, 9040, -8436, 459 } },
    { "acid", { -5450, 2495, 4295, -2283 } },
    { "brass", { -4988, 450, -4312, 905 } },
    { "fm growl", { 2918, -2816, 8813, -3713 } },
    { "reso bass", { -3843, 4021, -902, 2066 } },
    { "sub bass", { 5562, 1368, 8366, 1610 } },
    { "fm bass", { 8743, 1643, 4833, 3699 } },
    { "pluck bass", { -5542, 2025, -2313, -790 } },
    { "tom drop", { 6178, -5830, -3363, 3963 } },
    { "tubular bell", { 9757, -1675, 2108, 1587 } },
    { "metal", { 10544, 2884, -2363, -4683 } },
    { "kalimba", { 6807, -2063, 988, 4665 } },
    { "violin", { -4717, -6850, -5265, -983 } },
    { "flute", { -54, -6000, -6062, -131 } },
    { "clarinet", { -2688, 2340, -4106, 6692 } },
    { "trumpet", { -6937, -5671, 4673, 3242 } },
};
/* a preset's four knob words from its file's JSON ("knobs":[...]); 0 if the file is missing or has none */
static int preset_knobs(const char *name, int32_t *k)
{
    char path[1024], buf[4096];
#ifdef DRIFT_PRESETS                                              /* the Makefile: the absolute folder */
    snprintf(path, sizeof path, "%s%s.aif", DRIFT_PRESETS, name);
#else
    const char *f = __FILE__, *sl = strrchr(f, '/');                /* relative to where it was compiled from */
    snprintf(path, sizeof path, "%.*spresets/%s.aif", sl ? (int)(sl - f + 1) : 0, f, name);
#endif
    FILE *fp = fopen(path, "rb"); if (!fp) return 0;
    size_t n = fread(buf, 1, sizeof buf - 1, fp); fclose(fp); buf[n] = 0;
    for (size_t i = 0; i + 9 < n; i++)
        if (!memcmp(buf + i, "\"knobs\":[", 9))
            return sscanf(buf + i + 9, "%d,%d,%d,%d", &k[0], &k[1], &k[2], &k[3]) == 4;
    return 0;
}
/* one voice's render: the voice's pitch in OP1_PITCH_INC */
static void play(int vi, double hz, const int16_t *k, int16_t *out)
{
    r246_set_pitch(hz);
    ENGINE_drift.render(OP1_VOICE(vi), out, k);
}
static double ac_hz(const int16_t *x, long n)                      /* the strongest period by autocorrelation */
{
    double best = 0; long bl = 0; static double c[2000];
    for (long l = 30; l < 2000 && l < n / 2; l++) {
        double s = 0, e0 = 0, e1 = 0;
        for (long i = 0; i + l < n; i++) { s += (double)x[i] * x[i + l]; e0 += (double)x[i] * x[i]; e1 += (double)x[i + l] * x[i + l]; }
        c[l] = e0 > 0 && e1 > 0 ? s / sqrt(e0 * e1) : 0;
        if (c[l] > best) best = c[l];
    }
    for (long l = 31; l < 1999 && l < n / 2 - 1; l++)                /* the first peak near the best */
        if (c[l] >= 0.97 * best && c[l] >= c[l - 1] && c[l] >= c[l + 1]) { bl = l; break; }
    if (!bl) return 0;
    double a = c[bl - 1], b = c[bl], d = c[bl + 1], den = a - 2 * b + d;
    return R246_VOICE_HZ / (bl + (den != 0 ? 0.5 * (a - d) / den : 0));
}

int main(void)
{
    for (int i = 0; i < 8192; i++) host_sine[i] = (int16_t)lrint(32767.0 * sin(2 * M_PI * i / 8192.0));
    {   int worst = 0;
        for (int m = 0; m < 128; m++) {
            int d = abs(lt_pitch(r246_inc(r246_midi_hz(m))) - (int)lround((m - 36) / 60.0 * 4096)); if (d > worst) worst = d;
        }
        CHECK(worst <= 1, "lt_pitch off by %d LSB", worst);
        /* the asm layer kernel (n2k_layer_s) loads weights and inputs 32 bits at a time: misaligned is a fault on the
         * Blackfin (rc11: nosc2_far_init at 2 mod 4 behind lt_zk's 520 bytes, tier 2's CEC double fault) */
        CHECK(((uintptr_t)&nosc2_far_init & 3) == 0 && ((uintptr_t)&nosc2_l1_init & 3) == 0 && _Alignof(struct nosc2_far) >= 4,
              "weights not 4-aligned: far %p l1 %p", (const void *)&nosc2_far_init, (const void *)&nosc2_l1_init);
        int mono = 1;
        for (int j = 0; j < 4; j++) {
            CHECK(lt_zof(j, 0) == -10551 && lt_zof(j, 32767) == 10551 && lt_zof(j, -5) == -10551 && lt_zof(j, 40000) == 10551,
                  "knob %d: ends %d %d", j, lt_zof(j, 0), lt_zof(j, 32767));
            for (int32_t k = 0; k < 32767; k++) mono &= lt_zof(j, k + 1) >= lt_zof(j, k) && (k + 512 > 32767 || lt_zof(j, k + 512) > lt_zof(j, k));
        }
        CHECK(mono, "lt_zof not monotone");
        int wp = 0, np_ = 0;                                     /* the presets keep their z */
        for (int p = 0; p < 27; p++) {
            int32_t kw[4];
            if (!preset_knobs(old_z[p].name, kw)) { CHECK(0, "preset %s: no knobs read", old_z[p].name); continue; }
            np_++;
            for (int j = 0; j < 4; j++) {
                const int z = lt_zof(j, kw[j]), d = abs(z - old_z[p].z[j]);
                int step = 1;                                    /* one knob word's z step here, either side */
                if (kw[j] > 0) step = abs(z - lt_zof(j, kw[j] - 1)) > step ? abs(z - lt_zof(j, kw[j] - 1)) : step;
                if (kw[j] < 32767) step = abs(lt_zof(j, kw[j] + 1) - z) > step ? abs(lt_zof(j, kw[j] + 1) - z) : step;
                const int end = (kw[j] == 0 || kw[j] == 32767) && d <= 64;   /* a knob's end: the old table stopped
                                                                  * up to 52 LSB short of -/+2.576 (metal: 10544) */
                CHECK(d <= step || end, "preset %s knob %d: z %d, was %d (word %d, step %d)", old_z[p].name, j, z,
                      old_z[p].z[j], (int)kw[j], step);
                if (!end && d > wp) wp = d;
            }
        }
        printf("lt_pitch worst %d LSB; lt_zof ends and monotone; %d presets keep their z (worst %d LSB off the ends)\n",
               worst, np_, wp);
    }
    static int16_t buf[690 * OP1_BLOCK];                        /* 1 s */
    const int16_t organ[8] = { 3272, 1030, 19288, 0, 0x5300, 0, 0, 0 };
    for (int o = 0; o < 3; o++) {                                    /* pitch: A2, A3, A4 */
        const double hz = 110.0 * (1 << o);
        for (int i = 0; i < 6; i++) host_voice_vel[i] = 100 << 8;
        ENGINE_drift.note_on(OP1_VOICE(0), organ);
        long n = 0;
        for (long b = 0; b < R246_CALLS(0.6); b++, n += OP1_BLOCK) play(0, hz, organ, buf + n);
        const long held = R246_CALLS(0.3) * OP1_BLOCK;
        double f = ac_hz(buf + held, n - held > 8192 ? 8192 : n - held);
        CHECK(fabs(f / hz - 1) < 0.01, "A%d sounds %.2f Hz, not %.0f", 2 + o, f, hz);
        printf("A%d: %.2f Hz\n", 2 + o, f);
    }
    const int16_t sets[6][4] = { {16384, 16384, 16384, 16384}, {0, 0, 0, 0}, {32767, 32767, 32767, 32767},
                                 {0, 32767, 0, 32767}, {32767, 0, 32767, 0}, {8000, 24000, 30000, 2000} };
    for (int s = 0; s < 6; s++) {
        int16_t k[8] = { sets[s][0], sets[s][1], sets[s][2], sets[s][3], 0x5300, 0, 0, 0 };
        for (int v = 0; v < 6; v++) { host_voice_vel[v] = (int16_t)((40 + 17 * v) << 8); ENGINE_drift.note_on(OP1_VOICE(v), k); }
        int32_t peak[6] = {0}; long rail[6] = {0}; double e[6] = {0};
        static int16_t out[OP1_BLOCK];
        const long nb = R246_CALLS(1.5);
        for (long b = 0; b < nb; b++) {
            if (b >= nb / 2) for (int j = 0; j < 4; j++) k[j] = (int16_t)((sets[s][j] + (b - nb / 2) * 97 * (j + 1)) & 32767);   /* sweep */
            if (b == nb * 3 / 4) ENGINE_drift.note_on(OP1_VOICE(2), k);    /* a restrike on a sounding voice */
            for (int v = 0; v < 6; v++) {
                play(v, r246_midi_hz(36 + 7 * v), k, out);
                if (b == nb * 3 / 4 && v == 2) CHECK(lt_v[2].age == 1, "set %d: the restrike did not restart (age %u)", s, (unsigned)lt_v[2].age);
                if (b == nb / 3 || b == nb - 1) {                         /* the screen's view and its table decode */
                    drift_view_sync();
                    const volatile drift_view_voice_t *d = &drift_view.v[v];
                    int pe = 0; for (int j = 0; j < NP; j++) pe |= d->prm[j] != lt_v[v].prm[j];
                    CHECK(d->note == 36 + 7 * v && d->age == lt_v[v].age && d->pitch_q12 == lt_v[v].in[0] && !pe && d->active
                          && !d->released, "set %d voice %d: view note %d age %u", s, v, d->note, (unsigned)d->age);
                    CHECK(drift_view.knobs[0] == k[0] && drift_view.knobs[3] == k[3], "set %d: view knobs", s);
                    int16_t dec[64]; int wd = 0;
                    CHECK(drift_view_table(d->pitch_q12, d->vel_q12, d->age - 1, k, dec, 64), "set %d: no decode", s);
                    for (int i = 0; i < 64; i++) { int e_ = abs(dec[i] - lt_v[v].tab[2 * i]); if (e_ > wd) wd = e_; }
                    CHECK(wd == 0, "set %d voice %d: the decoded table differs from the voice's by %d", s, v, wd);
                }
                for (int i = 0; i < OP1_BLOCK; i++) {
                    int a = abs(out[i]); if (a > peak[v]) peak[v] = a; rail[v] += a >= 32700; e[v] += (double)out[i] * out[i];
                }
            }
        }
        {   /* serials: the later note on is newer; note_off marks the voice released */
            CHECK(drift_view.v[2].serial > drift_view.v[5].serial && drift_view.v[5].serial > drift_view.v[0].serial,
                  "set %d: view serials %u %u %u", s, (unsigned)drift_view.v[0].serial, (unsigned)drift_view.v[5].serial,
                  (unsigned)drift_view.v[2].serial);
            ENGINE_drift.note_off(OP1_VOICE(1)); play(1, r246_midi_hz(43), k, out);
            CHECK(drift_view.v[1].released && !drift_view.v[0].released, "set %d: note_off not in the view", s);
        }
        for (int v = 0; v < 6; v++) {
            double rms = sqrt(e[v] / (nb * OP1_BLOCK));
            CHECK(rms > 30, "set %d voice %d silent (rms %.1f)", s, v, rms);
            CHECK(rail[v] < nb * OP1_BLOCK / 100, "set %d voice %d at full scale %ld samples", s, v, rail[v]);
        }
        printf("set %d: peaks %d %d %d %d %d %d\n", s, peak[0], peak[1], peak[2], peak[3], peak[4], peak[5]);
    }
    {   /* the preset trim (word 7): the same block rendered from the same engine state with word 7 = 0 and with a trim.
         * At full velocity (in[1] = 4095) h = 16381, so the untrimmed sample is y0 = 2 ((x h) >> 15) for the pre-gain x;
         * the trimmed one must be sat16(2 ((x h') >> 15)) for an x that gives y0, h' = (h trim) >> 13 capped at 32767:
         * scaled by the trim and saturated on the rails (never wrapped). */
        static struct nosc2_voice sv[OP1_VOICES]; static struct nosc2_envnet se; static struct nosc2_l1 sh;
        uint8_t son[OP1_VOICES], sseen[OP1_VOICES], sreq[OP1_VOICES]; uint32_t sblk, svblk[OP1_VOICES]; int8_t slast; int16_t sz[4];
        int16_t k[8] = { 0, 32767, 0, 32767, 0x5300, 0, 0, 0 };   /* set 3: the loudest above */
        for (int v = 0; v < 6; v++) host_voice_vel[v] = 127 << 8;
        ENGINE_drift.note_on(OP1_VOICE(0), k);
        static int16_t y0[OP1_BLOCK], yt[OP1_BLOCK], ob[OP1_BLOCK], pre[OP1_BLOCK];   /* one output buffer, same contents before each take */
        const int16_t trims[3] = { 8192, 16345, 32767 };
        long bad[3] = {0}, rails[3] = {0}, n = 0; int32_t pk = 0;
        for (long b = 0; b < R246_CALLS(0.5); b++) {
            if (b < 8) { k[7] = 0; play(0, r246_midi_hz(71), k, ob); continue; }
            memcpy(pre, ob, sizeof pre);
            memcpy(sv, lt_v, sizeof sv); se = lt_env; sh = lt_home; memcpy(son, lt_on, sizeof son); memcpy(sseen, lt_seen, sizeof sseen);
            for (int i = 0; i < OP1_VOICES; i++) sreq[i] = lt_req[i];
            sblk = lt_blk; memcpy(svblk, lt_vblk, sizeof svblk); slast = lt_last; memcpy(sz, lt_z, sizeof sz);
            for (int t = -1; t < 3; t++) {
                if (t >= 0) {                                    /* back to the state before the untrimmed block */
                    memcpy(lt_v, sv, sizeof sv); lt_env = se; lt_home = sh; memcpy(lt_on, son, sizeof son); memcpy(lt_seen, sseen, sizeof sseen);
                    for (int i = 0; i < OP1_VOICES; i++) lt_req[i] = sreq[i];
                    lt_blk = sblk; memcpy(lt_vblk, svblk, sizeof svblk); lt_last = slast; memcpy(lt_z, sz, sizeof sz);
                }
                k[7] = t < 0 ? 0 : trims[t];
                memcpy(ob, pre, sizeof ob);
                play(0, r246_midi_hz(71), k, ob);
                memcpy(t < 0 ? y0 : yt, ob, sizeof ob);
                if (t < 0) continue;
                const int32_t h0 = 4096 + lt_v[0].in[1] * 3;
                int32_t h = (h0 * trims[t]) >> 13; if (h > 32767) h = 32767;
                for (int i = 0; i < OP1_BLOCK; i++) {
                    int ok = 0, rail = 0;
                    for (int32_t x = y0[i] - 12; x <= y0[i] + 12; x++) {   /* the x that gives y0: within 6 of it */
                        if (x < -32768 || x > 32767 || ((x * h0) >> 15) * 2 != y0[i]) continue;
                        int32_t e = ((x * h) >> 15) * 2; rail |= e > 32767 || e < -32768;
                        e = e > 32767 ? 32767 : e < -32768 ? -32768 : e;
                        ok |= yt[i] == e;
                    }
                    bad[t] += !ok; rails[t] += rail;
                    if (t == 0) { n++; if (abs(y0[i]) > pk) pk = abs(y0[i]); }
                }
            }
        }
        for (int t = 0; t < 3; t++)
            CHECK(bad[t] == 0, "trim %d: %ld of %ld samples not the untrimmed ones scaled by the trim", trims[t], bad[t], n);
        CHECK(rails[1] > 0 && rails[2] > rails[1], "the trims did not reach the rails (%ld, %ld; peak %d)", rails[1], rails[2], pk);
        printf("trim: peak %d at 1x; %ld samples, %ld / %ld on the rails at %d / %d, all scaled and saturated\n", pk, n,
               rails[1], rails[2], trims[1], trims[2]);
    }
    printf("drift_test: %d checks, %d failed\n", checks, fails);
    return fails != 0;
}
