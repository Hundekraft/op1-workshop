/* Host render of Amp's input strip (amp_dsp.h, source only: not R246's input path, cadence or decimator).
 *   amp_render RATE VOL COMP TONE DRIVE VOICEWORD < in.raw > out.raw     (int16 mono, 64-sample blocks)
 * stderr: "gate_closes=N gate_opens=M" (the gate's open flag changes over the run). -DAMP_HG_1X: the cascade voices'
 * stages at 1x (the alias check's reference; 44,100 only).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdio.h>
#include <stdlib.h>
#include "../amp_dsp.h"
int main(int argc, char **argv)
{
    if (argc != 7) { fprintf(stderr, "usage: amp_render RATE VOL COMP TONE DRIVE VOICEWORD\n"); return 2; }
    uint32_t rate = (uint32_t)atoi(argv[1]);
    int16_t p[8] = { (int16_t)atoi(argv[2]), (int16_t)atoi(argv[3]), (int16_t)atoi(argv[4]), (int16_t)atoi(argv[5]), 0,
                     (int16_t)atoi(argv[6]), 0, 0 };
    static amp_dsp s;
    amp_dsp_reset(&s, rate);
    int16_t in[64], out[64];
    int opens = 0, closes = 0, was = s.open;
    for (;;) {
        size_t n = fread(in, 2, 64, stdin);
        if (!n) break;
        for (size_t i = n; i < 64; i++) in[i] = 0;
        amp_dsp_process(&s, in, out, p);
        if (s.open != was) { if (s.open) opens++; else closes++; was = s.open; }
        fwrite(out, 2, n, stdout);
    }
    fprintf(stderr, "gate_closes=%d gate_opens=%d\n", closes, opens);
    return 0;
}
