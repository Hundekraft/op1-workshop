#!/usr/bin/env python3
"""Amp's CPU per block on the real Blackfin code (cost_guest.c): every voice at full Drive (and CRUNCH at Drive 0),
at both input rates, on bcore emu --cycles with --memmodel (default cold-noalloc: both caches flushed after every
block, the calibrated variant, tier2.py). Prints the average and slowest block in cycles and Amp's own share of the
unit block, cycles / 5,805 % (tier2.py stall_pct without the base; the synth slot is 35 %).

    python3 synth_sdk/plugins/amp/test/amp_cost.py [--variant cold-noalloc] [--renders N] [--json OUT]

Needs the Blackfin toolchain and a bcore emu with --memmodel (BCORE_EMU_CYCLES or OP1-Emulator
build/bcore-cycles-bin/emu). The input is a stand-in (cost_guest.c), not R246's input path.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import argparse
import json
import re
import struct
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
HARNESS = HERE.parents[2] / 'harness'
sys.path.insert(0, str(HARNESS))
import tier2 as T                                     # noqa: E402

VOICES = ['CLEAN', 'CRUNCH', 'LEAD', 'BASS', 'FUZZ', 'HIGH GAIN', 'METAL', 'CRUNCH drive 0']


def run(emu, elf, args, voice, rate, renders):
    off, _ = T.elf_section(elf, '.t2cfg')
    d = bytearray(elf.read_bytes())
    struct.pack_into('<IIIII', d, off, 3, renders, 0, voice, rate)
    p = elf.with_name(f'amp_{voice}_{rate}.elf')
    p.write_bytes(d)
    r = subprocess.run([emu, '--fastmem', '--count-packets', '--cycles', *args, str(p)], capture_output=True, timeout=1800)
    line = next((s for s in r.stdout.decode(errors='replace').splitlines() if s.startswith('T2')), '')
    v = {k: int(x, 16) for k, x in re.findall(r' (\w+)=0x([0-9a-f]+)', line)}
    if 'hash' not in v or not v.get('bn'):
        return {'error': (line or r.stderr.decode(errors='replace')[-300:]).strip()}
    return {'avg': v['bsum'] / v['bn'], 'max': v['bmax'], 'at': v['bat'], 'b0': v['b0'], 'hash': f'{v["hash"]:08x}'}


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('--variant', default=T.MEMMODEL_CALIBRATED)
    ap.add_argument('--renders', type=int, default=400)
    ap.add_argument('--json', type=Path)
    a = ap.parse_args(argv)
    found = T.setup_env()
    if 'toolchain' not in found or 'emu_memmodel' not in found:
        print('amp_cost: SKIP (needs the Blackfin toolchain and a bcore emu with --memmodel)')
        return 0
    sys.path.insert(0, str(T.KENNEL / 'tools/kennel'))
    import pack
    T.OUT = HARNESS / 'build' / 'amp_cost'
    T.OUT.mkdir(parents=True, exist_ok=True)
    knl = T.OUT / 'amp.knl'
    pack.pack_dir(HERE.parent, knl, keep=T.OUT / 'keep')
    t = T.tools(found['toolchain'])
    elf, _ = T.build_guest(t, 'amp_cost', knl, HERE / 'cost_guest.c')
    args = T.memmodel_args(elf, t['nm'], a.variant)
    tasks = [(v, r) for r in (0, 1) for v in range(len(VOICES))]
    with ThreadPoolExecutor(max_workers=2) as ex:
        rows = list(ex.map(lambda k: (k, run(found['emu_memmodel'], elf, args, *k, a.renders)), tasks))
    res = {}
    print(f'amp_cost: {a.variant}, {a.renders} blocks; Amp\'s own share = cycles / 5,805 % (synth slot 35 %)')
    print(f'{"voice":16s} {"rate":>6s} {"avg cyc":>9s} {"max cyc":>9s} {"avg %":>6s} {"max %":>6s}')
    for (v, r), x in rows:
        key = f'{VOICES[v]} {44100 if r == 0 else 22050}'
        res[key] = x
        if 'error' in x:
            print(f'{key}: ERROR {x["error"]}'); continue
        print(f'{VOICES[v]:16s} {44100 if r == 0 else 22050:6d} {x["avg"]:9,.0f} {x["max"]:9,} '
              f'{T.stall_pct(x["avg"], False):6.1f} {T.stall_pct(x["max"], False):6.1f}')
    if a.json:
        a.json.write_text(json.dumps(res, indent=1) + '\n')
    return 1 if any('error' in x for x in res.values()) else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
