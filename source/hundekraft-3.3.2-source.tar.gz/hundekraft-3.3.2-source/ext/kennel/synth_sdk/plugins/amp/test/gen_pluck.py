#!/usr/bin/env python3
"""A synthetic plucked-string test signal for Amp (Karplus-Strong strings with pick position, pickup roll-off, a 50 Hz
hum and a noise floor; after the root project's run/amp-native-2026-10-27/gen_guitar.py). Not a recorded DI.

    python3 gen_pluck.py OUT.wav [RATE]      (16-bit mono; default 44100, the emulator's SPORT rate)

make(fs): 16 s, peak -10 dBFS: low E, a scale run, an E chord, a palm-muted riff, a high lead line, 0.8 s of hum and
noise only (parts['hum']: start, end s), an A chord. decays(fs): four single notes ringing out over 3 s each (gate check).
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import sys
import wave

import numpy as np


def _pluck(out, fs, rng, t0, midi, dur, damp=0.996, amp=1.0, pick=0.18):
    f = 440 * 2 ** ((midi - 69) / 12)
    n = int(fs / f)
    L = int(dur * fs)
    exc = np.convolve(rng.uniform(-1, 1, n), [0.5, 0.5], 'same')
    exc = exc - np.roll(exc, max(1, int(pick * n)))
    # Karplus-Strong a period at a time: y[i] = damp * (y[i - n] + y[i - n + 1]) / 2
    y = np.empty(L + n + 1)
    y[:n] = exc
    y[n] = exc[0]
    i = n
    while i < L + n:
        k = min(n - 1, L + n - i)
        prev = y[i - n:i - n + k + 1]
        y[i:i + k] = damp * 0.5 * (prev[:-1] + prev[1:])
        i += k
    y = y[:L]
    env = np.ones(L)
    r = int(0.01 * fs)
    env[-r:] = np.linspace(1, 0, r)
    a = int(t0 * fs)
    seg = out[a:a + L]
    seg += amp * (y * env)[:len(seg)]


def _finish(out, fs, rng):
    a = np.exp(-2 * np.pi * 5000 / fs)
    for _ in range(2):                                      # pickup: one-pole low-pass at 5 kHz, twice
        from scipy.signal import lfilter
        out = lfilter([1 - a], [1, -a], out)
    out *= 10 ** (-10 / 20) / np.max(np.abs(out))
    t = np.arange(len(out)) / fs
    return out + 10 ** (-70 / 20) * np.sin(2 * np.pi * 50 * t) + 10 ** (-78 / 20) * rng.standard_normal(len(out))


def make(fs=44100):
    rng = np.random.default_rng(7)
    out = np.zeros(int(16.0 * fs))
    E2, A2, D3, G3, B2, B3, E3, Gs3, E4, G4, A4, B4, D5, E5 = 40, 45, 50, 55, 47, 59, 52, 56, 64, 67, 69, 71, 74, 76
    _pluck(out, fs, rng, 0.0, E2, 2.0)
    for i, m in enumerate((A2, D3, G3, B3, E4)):
        _pluck(out, fs, rng, 2.0 + 0.6 * i, m, 0.6)
    for i, m in enumerate((E2, B2, E3, Gs3, B3, E4)):
        _pluck(out, fs, rng, 5.0 + 0.012 * i, m, 3.5, amp=0.7)
    for i in range(8):
        for m in (E2, B2):
            _pluck(out, fs, rng, 8.5 + i * 60 / 140 / 2, m, 0.2, damp=0.95, amp=0.9)
    for i, m in enumerate((E4, G4, A4, B4, D5, E5)):
        _pluck(out, fs, rng, 10.5 + 0.35 * i, m, 0.35 + (0.6 if i == 5 else 0), amp=0.8)
    for i, m in enumerate((45, 52, 57, 61, 64)):
        _pluck(out, fs, rng, 14.0 + 0.012 * i, m, 2.0, amp=0.7)
    return _finish(out, fs, rng), {'hum': (13.5, 13.98)}


def decays(fs=44100):
    rng = np.random.default_rng(11)
    out = np.zeros(int(12.5 * fs))
    for i, m in enumerate((40, 52, 59, 64)):
        _pluck(out, fs, rng, 0.2 + 3.0 * i, m, 2.9, damp=0.9985)
    return _finish(out, fs, rng), {'notes': 4}


if __name__ == '__main__':
    fs = int(sys.argv[2]) if len(sys.argv) > 2 else 44100
    x, _ = make(fs)
    with wave.open(sys.argv[1], 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(fs)
        w.writeframes(np.round(x * 32767).astype('<i2').tobytes())
