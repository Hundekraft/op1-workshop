/* Amp's per-block cost on the real Blackfin code (amp_cost.py; bcore emu --cycles, with --memmodel the modelled cache
 * and SDRAM stalls): reset, then process() on 64 samples a block, each call timed with CYCLES. The input: a plucked-
 * string stand-in (a saw from 82 to 330 Hz, decaying over 64 blocks, 8 silent blocks, peak about -6 dBFS). t2_cfg.mode
 * = the voice (0..6; 7: CRUNCH at Drive 0), t2_cfg.knobs = the rate (0: 44,100, 1: 22,050). Knobs: Volume 50, Comp
 * full, Tone centre, Drive full. Result: "T2 ... b0= bmax= bat= bsum= bn= hash=".
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#define main t2_guest_main_unused
#include "../../../harness/tier2/guest.c"
#undef main
#include "../amp_voices.h"

static inline uint32_t cyc(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
static uint32_t blk, b0, bmax, bat, bsum, bn;
#define TIMED(x) do { uint32_t t_ = cyc(); x; blk += cyc() - t_; } while (0)
void __attribute__((noinline)) blk_end(uint32_t r)
{
    if (r == 0) b0 = blk; else if (blk > bmax) { bmax = blk; bat = r; }
    bsum += blk; bn++; blk = 0;
    __asm__ volatile ("" ::: "memory");
}
static uint32_t hash = 2166136261u;

int main(void)
{
    put("T2");
    setup();
    kn_info in;
    const char *err = 0;
    if (kn_parse(t2_file, t2_file_size, OP1_PLUGIN_API, &in, &err) ||
        kn_relocate(t2_file, &in, (uint8_t *)ARENA_LO, ARENA_LO, KN_ARENA_TOP - ARENA_LO, t2_exports, t2_export_count, &err)) {
        put_str("error", err); goto done;
    }
    if (!(in.flags & KN_FLAG_INPUT)) { put_str("error", "not an input engine"); goto done; }
    const op1_input_engine_t *e = (void *)(ARENA_LO + in.entry_offset);
    const uint32_t voice = t2_cfg.mode, rate = t2_cfg.knobs ? 22050 : 44100;
    int16_t p[8] = { 16384, 32767, 16384, 32767, 0, 0, 0, 0 };
    p[4] = (int16_t)(OP1_ENGINE_MAGIC + in.legacy_order);
    if (voice >= AMP_VOICES) { p[3] = 0; p[5] = 9830; }
    else p[5] = (int16_t)(((2 * (int)voice + 1) * 32768) / 16);
    static int16_t inb[64];
    uint32_t ph = 0;
    TIMED(e->reset(0, rate));
    for (uint32_t r = 0; r < t2_cfg.renders; r++) {
        uint32_t q = r % 72, note = r / 72;
        uint32_t inc = (82u + (note * 37u) % 248u) * (rate == 44100 ? 97391u : 194783u);   /* Hz * 2^32 / rate */
        int32_t amp = q >= 64 ? 0 : 16000 - (int32_t)q * 240;
        for (int i = 0; i < 64; i++) { ph += inc; inb[i] = (int16_t)((((int32_t)(ph >> 16) - 32768) * amp) >> 15); }
        TIMED(e->process(inb, out, p, rate));
        for (int i = 0; i < 64; i++) hash = (hash ^ (uint16_t)out[i]) * 16777619u;
        blk_end(r);
    }
    put_hex("hash", hash);
    put_hex("b0", b0); put_hex("bmax", bmax); put_hex("bat", bat); put_hex("bsum", bsum); put_hex("bn", bn);
done:
    put("\n");
    t2_write(line, n_line);
    return err ? 1 : 0;
}
