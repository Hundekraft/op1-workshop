#!/usr/bin/env python3
"""Amp's cascade voices (HIGH GAIN, METAL) on the host: SOURCE ONLY (amp_dsp.h built for the host, fed 64-sample
blocks at the input rate; not R246's input path, cadence or codec). Needs numpy and a C compiler.

    python3 synth_sdk/plugins/amp/test/hg_check.py [--out DIR] [--wav]

- input: a synthetic plucked-string signal (Karplus-Strong, gen_pluck.py; not a recorded DI), peak -10 dBFS, with a
  hum/noise-only stretch and slow single-note decays;
- levels: every voice at Drive 30 / 70 / 100 (Volume 50, Comp 0, Tone centre): rms of the playing part and the
  loudest 400 ms window, so the new voices can be matched to the old ones;
- gate: on the decays and the hum stretch, the gate's open/close count (no chatter: one close per decay at most) and
  the output level on the hum stretch;
- aliasing: a -12 dBFS sine at 1, 2.5 and 4 kHz into each cascade voice at full Drive, 44,100 Hz: the power outside
  the harmonics of the input (below 20 kHz), stages at 2x (the build) against the same stages at 1x (-DAMP_HG_1X);
- 22,050 (the other input cadence): LEAD, FUZZ and the cascade voices' levels, the cascade voices' gate on the decays;
- checks (exit 1): every voice sounds and no take clips for long; the 2x stage beats 1x by at least 5 dB of alias at
  every test frequency; at most one gate close per decaying note and the hum stretch gated to silence.
--wav writes every take as DIR/<voice>-d<drive>.wav (44.1 kHz).
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import argparse
import json
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import gen_pluck  # noqa: E402

VOICES = ['CLEAN', 'CRUNCH', 'LEAD', 'BASS', 'FUZZ', 'HIGH GAIN', 'METAL']
OLD_WORDS = [3276, 9830, 16384, 22937, 29491]          # 3.1..3.4 sounds' 5-step centres


def word(i):
    return OLD_WORDS[i] if i < 5 else ((2 * i + 1) * 32768) // 16


def build(out, extra=()):
    exe = out / ('amp_render' + ('_1x' if extra else ''))
    subprocess.run(['cc', '-O2', '-Wall', '-Wextra', '-Wno-unused-function', *extra, str(HERE / 'amp_render.c'), '-o',
                    str(exe)], check=True)
    return exe


def render(exe, x, rate, drive, w, vol=16384, comp=0, tone=16384):
    r = subprocess.run([str(exe), str(rate), str(vol), str(comp), str(tone), str(drive), str(w)],
                       input=x.astype('<i2').tobytes(), capture_output=True, check=True)
    gate = dict(kv.split('=') for kv in r.stderr.decode().split())
    return np.frombuffer(r.stdout, '<i2').astype(float) / 32768, {k: int(v) for k, v in gate.items()}


def db(v):
    return 20 * np.log10(max(v, 1e-9))


def levels(y, fs, mask):
    win = int(0.4 * fs)
    w = [np.sqrt(np.mean(y[i:i + win] ** 2)) for i in range(0, len(y) - win, win // 4)]
    return {'rms_db': round(db(np.sqrt(np.mean(y[mask] ** 2))), 2), 'max400_db': round(db(max(w)), 2),
            'peak_db': round(db(np.max(np.abs(y))), 2), 'crest_db': round(db(np.max(np.abs(y))) - db(max(w)), 2), 'clip_pct': round(100 * np.mean(np.abs(y) > 0.999), 3)}


def alias_db(y, fs, f0):
    y = y[len(y) // 4:]
    n = len(y)
    s = np.abs(np.fft.rfft(y * np.blackman(n))) ** 2
    fr = np.fft.rfftfreq(n, 1 / fs)
    harm = np.zeros(len(s), bool)
    for k in range(1, int(fs / 2 / f0) + 1):
        harm |= np.abs(fr - k * f0) < 12
    band = (fr > 30) & (fr < 20000)
    return round(10 * np.log10(s[band & ~harm].sum() / s[band & harm].sum()), 2)


def save(path, y, fs):
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(fs)
        w.writeframes((np.clip(y, -1, 1) * 32767).astype('<i2').tobytes())


def main():
    ap = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    ap.add_argument('--out', type=Path, default=HERE.parents[2] / 'harness' / 'build' / 'amp_hg')
    ap.add_argument('--wav', action='store_true')
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    exe, exe1 = build(a.out), build(a.out, ['-DAMP_HG_1X'])
    fs = 44100
    x, parts = gen_pluck.make(fs)
    xi = np.round(x * 32767).astype(np.int16)
    playing = np.zeros(len(x), bool)
    playing[:int(parts['hum'][0] * fs)] = True
    res, bad = {'levels': {}, 'gate': {}, 'alias': {}}, []
    for vi, name in enumerate(VOICES):
        for d in (0, 30, 70, 100):
            if d == 0 and vi:
                continue
            y, gate = render(exe, xi, fs, round(d * 32767 / 100), word(vi))
            key = 'DRY d0' if d == 0 else f'{name} d{d}'
            lv = levels(y, fs, playing)
            res['levels'][key] = lv
            if lv['rms_db'] < -60 or lv['clip_pct'] > 1:
                bad.append(f'{key}: level {lv}')
            if a.wav:
                save(a.out / f'{name.lower().replace(" ", "")}-d{d}.wav', y, fs)
            if vi >= 5 and d:
                h0, h1 = (int(t * fs) for t in parts['hum'])
                res['gate'][key] = dict(gate, hum_rms_db=round(db(np.sqrt(np.mean(y[h0:h1] ** 2))), 1))
    # decays alone: each note rings out from -10 dBFS; the gate may close once per note
    xd, dparts = gen_pluck.decays(fs)
    for vi in (5, 6):
        for d in (30, 70, 100):
            _, gate = render(exe, np.round(xd * 32767).astype(np.int16), fs, round(d * 32767 / 100), word(vi))
            key = f'{VOICES[vi]} d{d}'
            res['gate'][key]['decays'] = gate
            if gate['gate_closes'] > dparts['notes']:
                bad.append(f'{key}: gate closed {gate["gate_closes"]} times on {dparts["notes"]} decays (chatter)')
        if res['gate'][f'{VOICES[vi]} d100']['hum_rms_db'] > -70:
            bad.append(f'{VOICES[vi]}: hum stretch not gated ({res["gate"][f"{VOICES[vi]} d100"]})')
    # the 22,050 cadence: levels against LEAD / FUZZ and the gate on the decays
    res['rate22050'] = {}
    x2, parts2 = gen_pluck.make(22050)
    xd2, _ = gen_pluck.decays(22050)
    m2 = np.zeros(len(x2), bool); m2[:int(parts2['hum'][0] * 22050)] = True
    for vi in (2, 4, 5, 6):
        for d in (30, 70, 100):
            key = f'{VOICES[vi]} d{d}'
            y, _ = render(exe, np.round(x2 * 32767).astype(np.int16), 22050, round(d * 32767 / 100), word(vi))
            lv = levels(y, 22050, m2)
            if vi >= 5:
                _, gate = render(exe, np.round(xd2 * 32767).astype(np.int16), 22050, round(d * 32767 / 100), word(vi))
                lv['decays'] = gate
                if gate['gate_closes'] > dparts['notes']:
                    bad.append(f'22050 {key}: gate closed {gate["gate_closes"]} times on {dparts["notes"]} decays')
            if lv['rms_db'] < -60 or lv['clip_pct'] > 1:
                bad.append(f'22050 {key}: level {lv}')
            res['rate22050'][key] = lv
    t = np.arange(int(1.5 * fs)) / fs
    for vi in (5, 6):
        for f0 in (1000, 2500, 4000):
            s = np.round(10 ** (-12 / 20) * 32767 * np.sin(2 * np.pi * f0 * t)).astype(np.int16)
            a2 = alias_db(render(exe, s, fs, 32767, word(vi))[0], fs, f0)
            a1 = alias_db(render(exe1, s, fs, 32767, word(vi))[0], fs, f0)
            res['alias'][f'{VOICES[vi]} {f0} Hz'] = {'2x_db': a2, '1x_db': a1}
            if a1 - a2 < 5:
                bad.append(f'{VOICES[vi]} {f0} Hz: 2x alias {a2} dB vs 1x {a1} dB (less than 5 dB better)')
    print('SOURCE ONLY (host amp_dsp.h, synthetic plucked string; not native)')
    print(f'{"take":16s} {"rms dB":>8s} {"max400":>8s} {"peak":>7s} {"crest":>6s} {"clip%":>6s}')
    for k, v in res['levels'].items():
        print(f'{k:16s} {v["rms_db"]:8.2f} {v["max400_db"]:8.2f} {v["peak_db"]:7.2f} {v["crest_db"]:6.2f} {v["clip_pct"]:6.3f}')
    for k, v in res['gate'].items():
        print(f'gate {k:14s} {v}')
    for k, v in res['rate22050'].items():
        print(f'22050 {k:16s} rms {v["rms_db"]:7.2f} max400 {v["max400_db"]:7.2f} peak {v["peak_db"]:6.2f}' + (f' gate {v["decays"]}' if 'decays' in v else ''))
    for k, v in res['alias'].items():
        print(f'alias {k:18s} 2x {v["2x_db"]:7.2f} dB   1x {v["1x_db"]:7.2f} dB')
    (a.out / 'hg_check.json').write_text(json.dumps(res, indent=1) + '\n')
    for b in bad:
        print('FAIL', b)
    print(f'hg_check: {"ok" if not bad else f"{len(bad)} failed"}')
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
