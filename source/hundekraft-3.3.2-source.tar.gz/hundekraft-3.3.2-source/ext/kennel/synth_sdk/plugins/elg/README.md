# ELG

### v2: the layered moose, and CLASSIC (2026-11-12, branch elg-v3)

ELG has a new sound under the same name and slot (owner, 2026-11-12, from OP1-Emulator
`docs/elg-v2-sound-2026-11-12.md`). Every note is now an animal call. A growling voice opens its throat from "oo"
towards a vowel on each call, and its pitch scoops up and sags. Behind it sit a chest, some breath and a sine sub;
orange adds a slow aurora pad, three saws through two drifting band-passes. Each voice calls again on its own every
few seconds, so a held chord keeps calling.

| Knob | Name | What it moves |
|---|---|---|
| blue | CALL | the vowel a call opens to (oo, oh, aa, eh), how far the pitch scoops (+0.5 then -0.35 semitone), how often a voice calls (every 8 s down to 2.5 s) |
| green | BREATH | breath noise (louder while the glottis is open), the puff at each call, pitch jitter, the aurora saws' spread (3 to 13 cents) |
| white | BODY | drive and growl (every other glottal period louder), sub level, chest resonance, the output low-pass (1.2 to 11 kHz). Push: CLASSIC |
| orange | AURORA | the mix from the bare animal to the sky, how fast the two bands drift (0.03 to 0.28 Hz) and how sharp they are |
| Shift blue | THROAT | formant and chest size, bull (0.45) to calf (1.0) |
| Shift green | CALL TIME | how long a call takes to open and sag, 0.4 to 2.5 s |
| Shift white | SUB | off, one octave down, two octaves down, both |
| Shift orange | DRIFT | the aurora's band set: low, wide, high, or following the key (its 3rd and 6th harmonics) |

Push white for CLASSIC: ELG as it was on branch elg-v2, sample for sample. A small "classic" sits at the lower left
while it is on. A sound saved before v2 has words 5 and 6 at 0 (no ELG wrote them before), so it loads in CLASSIC with
its preset trim in word 7 and keeps its sound; a fresh pick gets the v2 words from the type row (`page2_defaults`) and
starts in v2. On the v2 layout CLASSIC is word 7 bit 7, next to SUB and DRIFT in its 7-bit fields. A push on a legacy
sound writes the v2 defaults to words 5..7, so its old preset trim is gone (v2 has its own level); the push after
that just toggles bit 7. Details: `elg_mode.h`.

DSP: the oscillators run at 88.2 kHz and are averaged in pairs; everything else runs at 44.1 kHz (64 samples a call)
and is interpolated back to 128. Seven Chamberlin band-passes (three formants, two chest modes, two aurora bands), a
one-pole high band for the breath, two one-pole low-passes. Integers only, no division, no libc. On the Blackfin
`elg2_dsp.S` runs the passes, bit for bit with `elg2_dsp.h`'s C (`kern_check.py`). Levels stay within about 3.5 dB
over every knob at C3 and in -27 .. -7 dBFS RMS at every corner of the knobs from C1 to C7 (`harness/elg2_test.c`); a
formant or aurora band never gets narrower than 0.6 of the key, so a high note on a narrow formant doesn't boom.

Cost: 16,609 packets a voice (CLASSIC 9,047). Modelled cold cycles for six voices (`cost_check --bursts --stalls`,
v2 forced): 129K held, 146K with six notes struck in one block, 21.8 / 24.7 % of the unit on the 2026-11-11 fit. Not
yet heard or measured on the unit.

Checks: `classic_check.py` (CLASSIC hashes the same as 6e084ceb's elg.c), `harness/elg2_test.c` (the hash, the
saved words, the push, Shift turns, a mode switch while a note sounds, the macros in R246 units, the corners),
`kern_check.py`, `exact_check.py elg` with every sound forced to CLASSIC against elg-v2's hashes. Evidence:
OP1-Emulator `run/elg-v3-2026-11-12/`.

### Blue in band steps, and a crossfade (2026-11-12, branch elg-v2)

The glide below did not cure it: on beta 4 blue "still steps harshly". R246 moves blue 328 words a tick, so a turn
crossed the 512-word bands unevenly and every change was a quick pitch slide, with a two-octave dive every fifth band.
Now a detent moves exactly one band (the next interval in order: unison, fifth, octave, octave + fifth, two octaves,
round again) and the third saw fades out, changes interval silent and fades back in (31 ms each way, the level made
up meanwhile). Saved sounds keep their interval; held settings render as before. Check: `harness/elg_sweep_test.c`;
evidence: OP1-Emulator `run/elg-v2-2026-11-12/`.

Screen: each knob part springs to its place and keeps a slow idle motion. Blue's antlers sway and dim while the third
saw crossfades; green's breath breathes and puffs on each new note; white now moves the moon over the whole knob (a
shadow eats the ring from the right below the default, the glow arcs above it); red's aurora ripples a little at 0
too; the stars twinkle at rest. Goldens updated; preview `run/elg-v2-2026-11-12/elg-knob-sweep.gif`.

### Interval glide (2026-11-11, branch elg-fix)

Blue turned in jumps on the unit (3.3 beta 2). The interval bands are narrow (512 units) and repeat, so a slow turn
stepped the third saw through unison, fifth, octave, octave + fifth and two octaves and then dropped back two octaves,
each step at once, and the level trim jumped with it (up to 9 dB at low timbre). Now the step glides (about 45 ms) and
the trim follows it; held settings sound exactly as before. Check: `harness/elg_sweep_test.c`. Details: kennel
ARCHITECTURE.md "ELG interval glide".

### Screen v2 (2026-11-06, branch elg-screen)

The folk-art moose crown: concept B "fine" (OP1-Emulator `docs/design/elg-v2/`), generated with an image model for the
owner's brief and picked and approved by the owner on 2026-11-06. `elg-art.png` is that PNG unchanged; `gen_svg.py`
traces it (`display/art_trace.py`, the knotwork corners traced on their own so the lavender keeps its own width) and
writes `elg.svg` and `elg_geom.h` together. Its header lists every forced change: stock palette instead of the
image's drifted colours, one 7 px lift for the OLED's bottom margin with the beard's tip trimmed at y 137.5, specks
under 1.6 px dropped and lines simplified within 0.35 px, the pines as filled silhouettes, the stars and berries
measured and redrawn.

What is SVG and what is code: the drawing heap holds a parsed SVG (about 200 bytes an element and 29 a vertex), so
the whole trace as SVG would have cost about 215 KB (the old screen 42 KB). `elg.svg` keeps the still parts that are
not repeated hatching (landscape and pines, knotwork and berries, moon ring and clouds, the fur and shading under the
breath, which the clouds must cover) and the two breath clouds (`breathL`, `breathR`, scaled by `svg_scale`).
`screen.c` draws the rest each frame with raster lines from `elg_geom.h` (no heap): the aurora (ribbons and fringe,
animated), the antlers with their inner tine lines (they spread with the interval), the fur and face shading (the
engraving's repeated short strokes), the moon's glow arcs and the star sparkles. About 490 SVG segments and 1,080
code segments a frame (Pew's static SVG draws about 1,650).

Knobs: blue Interval spreads the antlers (93 .. 107 % wide, 96.5 .. 103.5 % tall; the concept's size at the octave,
the default; glides, ignores the slot LFO); green Detune scales each breath cloud about its nostril (87.5 .. 137.5 %,
plus up to 6 % with the level); white Timbre lights up to three glow arcs outside the moon ring above its default (none at or below it, as in the concept; since elg-v2 a shadow over the ring below it); red Movement sends a
wave along the aurora (the ribbons sink up to 3 px, the fringe stretches up to 45 %), its depth swinging with Elg's
LFO while notes play; the stars twinkle while notes play. The sound is unchanged (`exact_check.py elg`: 41 regimes
bit-exact against main). Goldens: `engine_elg`, `engine_elg_low`, `engine_elg_high`, `engine_elg_play`.

### Rate (2026-11-03)

A voice call is 128 samples at 88.2 kHz, 689 calls a second, not 344. The movement LFO (0.03 .. 2 Hz) ran at twice
that, the low-pass sat an octave up (the coefficient `2 sin(pi fc / fs)` was built for 44.1 kHz: 80 Hz .. 11.6 kHz
instead of 40 Hz .. 6 kHz) and the pitch drift wandered twice as fast. Now the LFO step is 187000 per call, the
cutoff base 93.5 (clamp 60 .. 13500), and the drift steps every other call. Pitch, detune and the asm kernels are
unchanged. Check: `harness/rate_elg_test.c`.

### Output polish (2026-10-17)

Bounded base-timbre/interval gain compensation preserves the internal moving cutoff, swell and quieter drones. Current kennel only; historical2.x engine sources and preset controls remain unchanged. Method, calibration and native emulator evidence: parent `docs/archive/engine-level-polish-2026-10-17.md`. Physical CPU/listening acceptance remains separate.

### Blackfin kernels (2026-10-27)

On the Blackfin the sample loop runs in `elg_dsp.S`: five hand-scheduled passes (increments, saws and sum / 3, drive
and soft clip, low-pass and gain, level), the same samples bit for bit as `elg.c`'s C loop, which the host builds keep.
About 58 packets per sample instead of about 190: 24.7k -> 9.1k per voice call, a 6-voice block 141k -> 49k.
Details and the exactness checks: kennel ARCHITECTURE.md "ELG Blackfin kernels".

### Antlers (2026-10-28)

Replaced by the screen v2 above (the old screen's antlers scaled 90 .. 100 % with the interval).
