/*
 * Four tapes (docs/tapes.md): switch R246's tape between tape 1 (TE's: /yaffs2/user/tape_c.raw, tape.db) and tapes
 * 2..4 (/yaffs2/user/tape<N>/...), each with its own tracks, clips, loop, tempo and album. Requested from any thread
 * (op1_tape_switch), done on the main loop (kn_tapes_service, from ci_service), which owns the tape file and cache.
 * A new tape is a sparse image: only its FAT16 metadata and AIFC headers are written (kn_tape_image_meta), the audio
 * stays a YAFFS hole that reads as silence. Boot always opens tape 1 (stock's start-up and marker recovery only ever see
 * tape 1); the last tape used comes back by one ordinary switch after OP1_EV_BOOT_DONE (kn_tapes_boot_done below). R246 addresses: docs/tapes.md.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_feature_tape.h"
#include "../op1_synth.h"                                     /* op1_db_write */
#include "../kn_mem.h"                                        /* kn_farbss */

void kn_event(int id, int32_t arg);
void *kn_alloc(uint32_t size);
int32_t op1_setting_get(const char *feature, const char *key, int32_t def);
void op1_setting_set(const char *feature, const char *key, int32_t value);

/* ---- image layout (R246's, OP1-Emulator docs/firmware/tape.md) ---- */
#define IMG_SIZE      0x18000000
#define FAT1          0x1000
#define FAT2          0x19000
#define FAT_BYTES     0x18000                     /* 192 sectors */
#define ROOT          0x31000
#define DATA          0x35000
#define CLUSTER       0x2000
#define CL_OFF(c)     (DATA + ((int32_t)(c) - 2) * CLUSTER)
#define TRACK_FRAMES  0xF28000
#define SIDE_FRAMES   0xF23FA0
#define TRACK_BYTES   (0x70 + TRACK_FRAMES * 2)  /* 31,785,072 */
#define SIDE_BYTES    (0x70 + SIDE_FRAMES * 4)   /* 63,504,112 */
#define CL_COUNT(b)   (((b) + CLUSTER - 1) / CLUSTER)
#define TAPE_DIR      2
#define TRACK1        3
#define ALBUM_DIR     (TRACK1 + 4 * CL_COUNT(TRACK_BYTES))      /* 15527 */
#define SIDE_A        (ALBUM_DIR + 1)
#define LAST_CL       (SIDE_A + 2 * CL_COUNT(SIDE_BYTES) - 1)   /* 31031 */
#define DOS_TIME      0x0000
#define DOS_DATE      ((46 << 9) | (1 << 5) | 1)               /* 2026-01-01 (R246 writes the clock; nobody reads it) */

/* FAT16 entry of cluster c: contiguous chains, 0xFFFF at each end, entries 0 and 1 zero as R246 leaves them */
static uint16_t fat_entry(int32_t c)
{
    if (c < 2 || c > LAST_CL) return 0;
    if (c == TAPE_DIR || c == ALBUM_DIR) return 0xFFFF;
    int32_t first, n;
    if (c < ALBUM_DIR) { n = CL_COUNT(TRACK_BYTES); first = TRACK1 + (c - TRACK1) / n * n; }
    else { n = CL_COUNT(SIDE_BYTES); first = SIDE_A + (c - SIDE_A) / n * n; }
    return c == first + n - 1 ? 0xFFFF : (uint16_t)(c + 1);
}
static void put16(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t *p, uint32_t v) { put16(p, v); put16(p + 2, v >> 16); }
static void be32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v; }
static void zero(uint8_t *p, int n) { while (n--) *p++ = 0; }
static void cpy(uint8_t *d, const char *s, int n) { while (n--) *d++ = (uint8_t)*s++; }

static void dirent(uint8_t *e, const char *name11, int dir, int32_t cluster, uint32_t size)
{
    zero(e, 32);
    cpy(e, name11, 11);
    e[11] = dir ? 0x10 : 0x20;
    e[12] = name11[0] == '.' ? 0 : dir ? 0x08 : 0x18;          /* NT case: lowercase name (and extension) */
    put16(e + 14, DOS_TIME); put16(e + 16, DOS_DATE); put16(e + 18, DOS_DATE);
    put16(e + 22, DOS_TIME); put16(e + 24, DOS_DATE);
    put16(e + 26, (uint32_t)cluster); put32(e + 28, size);
}

/* the AIFC header (0x70 bytes): little-endian PCM ('sowt'), 44.1 kHz, 16 bit */
static void aifc(uint8_t *h, int channels, uint32_t frames)
{
    static const char desc[] = "Signed integer (little-endian) linear PCM";
    uint32_t data = frames * (uint32_t)channels * 2;
    zero(h, 0x70);
    cpy(h, "FORM", 4); be32(h + 4, 0x70 + data - 8); cpy(h + 8, "AIFCFVER", 8); be32(h + 0x10, 4);
    be32(h + 0x14, 0xA2805140);                                 /* AIFC version 1 */
    cpy(h + 0x18, "COMM", 4); be32(h + 0x1C, 0x40);
    h[0x20] = 0; h[0x21] = (uint8_t)channels; be32(h + 0x22, frames); h[0x26] = 0; h[0x27] = 16;
    h[0x28] = 0x40; h[0x29] = 0x0E; h[0x2A] = 0xAC; h[0x2B] = 0x44;   /* 44100 as an 80-bit float */
    cpy(h + 0x32, "sowt", 4); h[0x36] = sizeof desc - 1; cpy(h + 0x37, desc, sizeof desc - 1);
    cpy(h + 0x60, "SSND", 4); be32(h + 0x64, data + 8);
}

/* Writes every non-zero byte of a fresh image except the boot sector (R246's fat_image_write_boot_template writes
 * it): both FATs, the root directory, the TAPE and ALBUM directories, the six AIFC headers. wr(off, buf, len); buf
 * is scratch of 8 KiB. 0 or the first nonzero wr result. */
int kn_tape_image_meta(int (*wr)(void *ctx, int32_t off, const uint8_t *buf, int32_t len), void *ctx, uint8_t *buf)
{
    int r;
    int32_t fat_used = (LAST_CL + 1) * 2, fat_len = (fat_used + 511) & ~511;
    for (int copy = 0; copy < 2; copy++)
        for (int32_t at = 0; at < fat_len; at += CLUSTER) {
            int32_t n = fat_len - at < CLUSTER ? fat_len - at : CLUSTER;
            for (int32_t i = 0; i < n; i += 2) put16(buf + i, fat_entry((at + i) / 2));
            if ((r = wr(ctx, (copy ? FAT2 : FAT1) + at, buf, n))) return r;
        }
    zero(buf, 512);                                            /* root: TAPE, ALBUM */
    dirent(buf, "TAPE       ", 1, TAPE_DIR, 0);
    dirent(buf + 32, "ALBUM      ", 1, ALBUM_DIR, 0);
    if ((r = wr(ctx, ROOT, buf, 512))) return r;
    zero(buf, 512);                                            /* TAPE: ., .., four tracks */
    dirent(buf, ".          ", 1, TAPE_DIR, 0);
    dirent(buf + 32, "..         ", 1, 0, 0);
    static const char tn[] = "TRACK_1 AIF";
    char name[12];
    for (int t = 0; t < 4; t++) {
        for (int i = 0; i < 12; i++) name[i] = tn[i];
        name[6] = (char)('1' + t);
        dirent(buf + 64 + 32 * t, name, 0, TRACK1 + t * CL_COUNT(TRACK_BYTES), TRACK_BYTES);
    }
    if ((r = wr(ctx, CL_OFF(TAPE_DIR), buf, 512))) return r;
    zero(buf, 512);                                            /* ALBUM: ., .., two sides */
    dirent(buf, ".          ", 1, ALBUM_DIR, 0);
    dirent(buf + 32, "..         ", 1, 0, 0);
    dirent(buf + 64, "SIDE_A  AIF", 0, SIDE_A, SIDE_BYTES);
    dirent(buf + 96, "SIDE_B  AIF", 0, SIDE_A + CL_COUNT(SIDE_BYTES), SIDE_BYTES);
    if ((r = wr(ctx, CL_OFF(ALBUM_DIR), buf, 512))) return r;
    for (int t = 0; t < 4; t++) {
        aifc(buf, 1, TRACK_FRAMES);
        if ((r = wr(ctx, CL_OFF(TRACK1 + t * CL_COUNT(TRACK_BYTES)), buf, 0x70))) return r;
    }
    for (int s = 0; s < 2; s++) {
        aifc(buf, 2, SIDE_FRAMES);
        if ((r = wr(ctx, CL_OFF(SIDE_A + s * CL_COUNT(SIDE_BYTES)), buf, 0x70))) return r;
    }
    return 0;
}

#ifndef KN_TAPES_META_ONLY                         /* harness/tapes_image_test.c builds the writer alone */
/* ---- R246 ---- */
#ifdef OP1_HOST                                    /* harness/tapes_test.c */
#include "../harness/tapes_host.h"
#else
#define Y_OPEN        ((int (*)(const char *, int, int))0x01A997F4)
#define Y_CLOSE       ((int (*)(int))0x01A99908)
#define Y_READ        ((int (*)(int, void *, int))0x01A99C90)
#define Y_WRITE       ((int (*)(int, const void *, int))0x01A99F84)
#define Y_LSEEK       ((int32_t (*)(int, int32_t, int))0x01A9A0E4)
#define Y_UNLINK      ((int (*)(const char *))0x01A9A3FC)
#define Y_MKDIR       ((int (*)(const char *, int))0x01A9A886)
#define Y_ACCESS      ((int (*)(const char *, int))0x01A9A6B0)
#define Y_FREE()      ((uint32_t)((int (*)(const char *))0x01A9B1C0)("/yaffs2"))
#define DELAY_MS      ((void (*)(int))0x0193E5C0)
#define IMG_PATH      ((char *)0x01AABCE4)                             /* tape_c.raw path (0x200) */
#define MARKER_PATH   ((char *)0x01AAC934)                             /* marker.txt path (0x200) */
#define IMG_FD        (*(volatile int32_t *)0x018C180C)               /* tape_image_fat_handle */
#define SET_FILE      ((void (*)(int))0x01A5404C)                     /* tape_set_file_handle */
#define PRESIZE       ((int (*)(int))0x01A99FB4)                      /* tape_image_presize: 0x18000000 bytes */
#define BOOT_SECTOR   ((void (*)(int))0x019988C8)                     /* fat_image_write_boot_template */
#define DISK_BIND     ((void (*)(int))0x019761D8)                     /* fat_disk_bind_tape_image */
#define FAT_MOUNT     ((int (*)(int, void *))0x01998E74)              /* f_mount(volume, fs); fs 0 unmounts */
#define FAT_FS        ((uint8_t *)0x01AABEE4)                      /* FatFs volume: +1 drive, +3 FATs, +4 window dirty,
                                                                       * +0x18 FAT size, +0x20 FAT start, +0x2C window
                                                                       * sector, +0x30 window (move_window 0x0199A800) */
#define DISK_WRITE    ((int (*)(int, const void *, uint32_t, int))0x01976288)   /* (drive, buf, sector, count): kn_disk_write */
#define DISK_FD       (*(volatile int32_t *)0x01CC0FEC)               /* FatFs drive 0's descriptor (fat_disk_bind_tape_image) */
#define FAT_SYNC      ((int (*)(void))0x01996530)                     /* fat_sync_after_reboot */
#define SYNC_WAITING  ((int (*)(void))0x01995764)                     /* op1.db fatsync.was_mounted != 0 */
#define SYNC_CLEAR    ((void (*)(int))0x01995728)                     /* was_mounted = 0 */
#define MOUNT_INDEX   ((void (*)(void))0x01996F38)                    /* tape_image_mount_and_index */
#define INVALIDATE_ALL ((void (*)(void))0x01A54078)                   /* tape_cache_invalidate_clean */
#define DB_BOX        (*(void **volatile *)0x01BAB72C)                /* tape.db: the box db2 calls take */
#define DB_LOCK       (*(void *volatile *)0x01BAB718)                 /* db2 statement lock */
#define SEM_PEND      ((void (*)(void *, int))0xFFA0B6E8)
#define SEM_POST      ((void (*)(void *))0xFFA0B96C)
#define SQL_CLOSE     ((int (*)(void *))0x019D6134)
#define SQL_OPEN      ((int (*)(const char *, void **, int, const char *))0x019D73C8)   /* open_v2: VFS 0 */
#define DB_GET        ((void (*)(void *, void *, const char *))0x0196FBD0)
#define BG_HEAD       (*(volatile int32_t *)0x01BA33E4)
#define BG_TAIL       (*(volatile int32_t *)0x01BA33E8)
#define BG_JOB        (*(void *volatile *)0x01BA29D8)
#define CLIPS_INST    ((void *(*)(void))0x0195BBB4)
#define CLIPS_HAS     ((uint8_t *)0x01AAA570)
#define CLIPS_FREE    (*(volatile int32_t *)0x01AAA770)
#define CLIPS_LOADED  (*(volatile uint8_t *)0x01AA7368)
#define CLIPS_LOAD    ((void (*)(void *))0x0195CE88)
#define CLIPS_REMOVE  ((void (*)(void *, int))0x0195D688)             /* tape_clips_remove_channel(pool, track) */
#define TRACK_REMADE  ((volatile uint8_t *)0xFF906EFC)                /* set by the mount check per recreated track */
#define TAPE_RESET    ((void (*)(void *))0x01A56CD8)                  /* loop off, track 0, position 0, saved */
#define CTRL          ((void *(*)(void))0x01A56D94)                   /* tape_controller_instance */
#define TAPE_SAVE     ((void (*)(void))0x01A569BC)                    /* tape_db_save */
#define LOOP_ON       (*(volatile uint8_t *)0xFF8029C5)
#define LOOP_EFF      (*(volatile uint8_t *)0xFF8029C6)
#define SET_LOOP_IN   ((void (*)(int32_t))0x01A550A8)
#define SET_LOOP_OUT  ((void (*)(int32_t))0x01A55100)
#define CUR_TRACK     (*(volatile int32_t *)0xFF802964)
#define LOCATE        ((void (*)(int32_t))0x01A55024)
#define TAPE_STATE    (*(volatile int32_t *)0x018C17D4)
#define TAPE_RUN      (*(volatile int32_t *)0xFF802960)               /* 1 recording */
#define ALBUM_STATE   (*(volatile int32_t *)0xFF9002B4)               /* 6 / 7 recording */
#define ALBUM_REQ     ((void (*)(int))0x01915590)                     /* 0 stops */
#define DISK_ACTIVE   (*(volatile uint8_t *)0xFF906EF9)
#define CLIP_CONS     (*(volatile int32_t *)0x01AA7330)
#define CLIP_PROD     (*(volatile int32_t *)0x01AA7334)
#define DISPATCH_KEY  ((void (*)(int, int))0x019B6C74)                /* KeyHandler::dispatch_key */
#define TEMPO_CTRL    ((void *(*)(void))0x01A5ED44)                   /* tempo_controller_get */
#define KNOB_BPM10    ((volatile int32_t *)0x01B60E18)                /* tempobpmdecimal: value +0x10 = v * scale +0xC */
#define KNOB_BPM      ((void *)0x01B60D98)
#define KNOB_SET      ((void (*)(void *, int32_t))0x019696E8)
#define SET_BPM       ((void (*)(float))0x01A5E9A4)
#endif

#define NEW_TAPE_FREE (64u << 20)                  /* a new tape needs 64 MB free */
static const char USER[] = "/yaffs2/user/";

typedef struct { uint32_t alloc; union { char buf[16]; char *ptr; } u; uint32_t size, cap; uint32_t pad; } dstr;   /* db2_get's string */

static volatile int8_t req = -1;                  /* tape asked for, -1 none */
static int8_t cur;                                /* 0..3 */
static int8_t img_tape;                           /* the tape whose image is bound (FatFs, disk mode): its write rules */
static int8_t stop_wait;                          /* passes left waiting for STOP */
static uint8_t *scratch;
static const char NOW[] = "/yaffs2/user/kn_tape"; /* the tape in use while it is 2..4 ('2'..'4'); gone on tape 1 */
static void note_tape(int tape);
static int8_t rs_state;                           /* last tape restore: 0 off, 1 waiting for a quiet moment, 2 switch asked */
static int8_t rs_tape;                            /* ... the tape to go back to (1..3) */
static int16_t rs_wait;                           /* ... service passes since BOOT_DONE */
#define RS_SETTLE     30                          /* passes to let boot's last loads and the boot toast start first */
#define RS_GIVEUP     3000                        /* passes of waiting for idle before it is left (key kept) */

int op1_tape_current(void) { return cur; }

/* "/yaffs2/user/" + "tape<N>/" (tapes 2..4) + name */
static void tape_path(char *o, int tape, const char *name)
{
    const char *s = USER;
    while (*s) *o++ = *s++;
    if (tape) { const char *d = "tape"; while (*d) *o++ = *d++; *o++ = (char)('1' + tape); *o++ = '/'; }
    while (*name) *o++ = *name++;
    *o = 0;
}
static int exists(int tape, const char *name) { char p[64]; tape_path(p, tape, name); return Y_ACCESS(p, 0) == 0; }

static int write_file(const char *path, const void *data, int len)
{
    int fd = Y_OPEN(path, 0x242, 0x180);
    if (fd < 0) return -1;
    int ok = Y_WRITE(fd, data, len) == len;
    return Y_CLOSE(fd) == 0 && ok ? 0 : -1;
}

static int wr_image(void *ctx, int32_t off, const uint8_t *buf, int32_t len)
{
    int fd = (int)(long)ctx;
    return Y_LSEEK(fd, off, 0) == off && Y_WRITE(fd, buf, len) == len ? 0 : -1;
}

/* a new tape (1..3): sparse image, the factory tape.db, marker "0", then `ready` */
static int make_tape(int tape)
{
    char p[64], q[64];
    tape_path(p, tape, "");
    p[sizeof USER - 1 + 5] = 0;                                     /* "/yaffs2/user/tape<N>" */
    Y_MKDIR(p, 0);
    tape_path(p, tape, "ready"); Y_UNLINK(p);
    tape_path(p, tape, "tape_c.raw");
    int fd = Y_OPEN(p, 0x242, 0x180);
    if (fd < 0) return -1;
    int ok = PRESIZE(fd) >= 0 && Y_LSEEK(fd, 0, 2) == IMG_SIZE;
    if (ok) { BOOT_SECTOR(fd); ok = kn_tape_image_meta(wr_image, (void *)(long)fd, scratch) == 0; }
    if (Y_CLOSE(fd) != 0) ok = 0;
    if (!ok) return -1;
    int in = Y_OPEN("/yaffs2/content/tape.db", 0, 0);              /* the factory copy (4 KiB) */
    if (in < 0) return -1;
    int n = Y_READ(in, scratch, 0x2000);
    Y_CLOSE(in);
    tape_path(q, tape, "tape.db");
    if (n <= 0 || n >= 0x2000 || write_file(q, scratch, n)) return -1;
    tape_path(q, tape, "marker.txt");
    if (write_file(q, "0", 1)) return -1;
    tape_path(q, tape, "ready");
    return write_file(q, "1", 1);
}

/* a tape whose marker is above '0' (a power cut during its defragmentation) is made again */
static int marker_dirty(int tape)
{
    char p[64]; uint8_t c = '0';
    tape_path(p, tape, "marker.txt");
    int fd = Y_OPEN(p, 0, 0);
    if (fd < 0) return 0;
    Y_READ(fd, &c, 1);
    Y_CLOSE(fd);
    return c > '0';
}

/* ---- tape.db: the tape row and the tempo ---- */
static int32_t db_int(const char *sql, int32_t def)
{
    dstr s; zero((uint8_t *)&s, sizeof s);
    DB_GET(&s, DB_BOX, sql);
    if (!s.size) return def;
    const char *p = s.cap > 15 ? s.u.ptr : s.u.buf;
    int32_t v = 0, neg = 0, any = 0;
    if (*p == '-') { neg = 1; p++; }
    for (uint32_t i = 0; i < s.size && *p >= '0' && *p <= '9'; i++, p++) { v = v * 10 + (*p - '0'); any = 1; }
    return any ? (neg ? -v : v) : def;
}
static const char KN_TABLE[] = "CREATE TABLE IF NOT EXISTS kn_tape (id INTEGER PRIMARY KEY, bpm10 INTEGER)";
static int32_t bpm10_now(void)
{
    TEMPO_CTRL();
    return KNOB_BPM10[4] / (KNOB_BPM10[3] ? KNOB_BPM10[3] : 1);     /* value / scale */
}
/* The tempo of the tape in use (2026-11-24, users on 3.3.1: "Tape 4 loaded, 125 BPM" after a power cycle on tape 4
 * at 90, and tape 1 then at 90). R246 keeps one tempo, the knob in op1.db's `knobs` (ctl_knob_set marks it for the
 * BgFile save), and boot brings that back whatever tape it belonged to. Each tape's own tempo is its kn_tape row:
 *   - saved when it changes (bpm_watch: the tempo unchanged for BPM_QUIET, once the tape is stopped and nothing is
 *     recording or busy; not with a switch pending), before a switch and at power-off (kn_tapes_shutdown), so the row never misses the last tempo set;
 *   - at boot the live tempo is R246's last one, not tape 1's: bpm_unset keeps it out of tape 1's row (no save on the
 *     restore switch, none from bpm_watch) until tape 1's row is applied (the restore gave up or none was armed, after
 *     RS_SETTLE passes) or another tape's row is loaded by the restore switch.
 * tapes_used: a tape 2..4 exists (or was switched to): with only TE's tape nothing here writes or applies a tempo. */
static int32_t bpm_saved = -1;                    /* the tempo in the current tape's row (or just applied), -1 unknown */
static int32_t bpm_seen;                          /* bpm_watch: the tempo last seen and since when */
static uint32_t bpm_since;
static int8_t bpm_unset;                          /* 1: the live tempo is not the current tape's (boot, until applied) */
static int8_t tapes_used;
static int16_t bpm_wait;                          /* boot: passes before tape 1's row is applied */
#ifndef TP_NOW
#define TP_NOW()      op1_cycles()
#endif
#define BPM_QUIET     600000000u                  /* cycles: 1.5 s at 400 MHz, as bgsave.c's patch saves */
static void save_bpm(void)
{
    char sql[64], *o = sql;
    const char *h = "INSERT OR REPLACE INTO kn_tape VALUES (0,";
    while (*h) *o++ = *h++;
    int32_t v = bpm10_now(), saved = v; char d[8]; int k = 0;
    do { d[k++] = (char)('0' + v % 10); v /= 10; } while (v && k < 7);
    while (k) *o++ = d[--k];
    *o++ = ')'; *o = 0;
    op1_db_write(DB_BOX, KN_TABLE);
    op1_db_write(DB_BOX, sql);
    bpm_saved = bpm_seen = saved;
}
int32_t op1_tape_bpm10(void) { return bpm10_now(); }

static void apply_bpm(int32_t bpm10)
{
    if (bpm10 < 400 || bpm10 > 2200) return;
    TEMPO_CTRL();
    KNOB_SET((void *)KNOB_BPM10, bpm10);                            /* as the tempo screen's fine knob does */
    KNOB_SET(KNOB_BPM, bpm10 / 10);
    SET_BPM((float)bpm10 / 10.0f);
}

/* the current tape's row applied (its tempo is the tape's from now on); a tape without a row stores the tempo it has */
static void adopt_bpm(void)
{
    int32_t v = db_int("SELECT bpm10 FROM kn_tape WHERE id=0", 0);
    bpm_unset = 0;
    if (v < 400 || v > 2200) { save_bpm(); return; }
    apply_bpm(v);
    bpm_saved = bpm_seen = bpm10_now();
}

/* ---- the switch ---- */
static int busy_reason(void)
{
    if (TAPE_RUN == 1 || ALBUM_STATE == 6 || ALBUM_STATE == 7) return OP1_TAPE_SW_RECORDING;
    if (DISK_ACTIVE) return OP1_TAPE_SW_DISK;
    if (CLIP_CONS != CLIP_PROD) return OP1_TAPE_SW_BUSY;
    return 0;
}

int op1_tape_switch(int tape)
{
    if (tape < 0 || tape > 3) return OP1_TAPE_SW_BAD;
    if (tape == cur) return OP1_TAPE_SW_SAME;
    rs_state = 0;                                   /* a switch asked for by someone else: the restore is off */
    int r = busy_reason();
    if (r) return r;
    if (!exists(tape, "ready") && tape && Y_FREE() < NEW_TAPE_FREE) return OP1_TAPE_SW_FULL;
    req = (int8_t)tape;
    stop_wait = 100;
    return 0;
}

static int bg_idle(void) { return BG_HEAD == BG_TAIL && !BG_JOB; }

static void set_paths(int tape)
{
    tape_path(IMG_PATH, tape, "tape_c.raw");
    tape_path(MARKER_PATH, tape, "marker.txt");
}

/* open tape `tape`'s image, bind and mount it without the mount check (as tape_image_open_at_boot leaves tape 1) */
static int bind_tape(int tape)
{
    set_paths(tape);
    int fd = Y_OPEN(IMG_PATH, 2, 0x180);
    if (fd < 0) return -1;
    img_tape = (int8_t)tape;                        /* before the mount check: its writes follow this tape's rules */
    IMG_FD = fd;
    SET_FILE(fd);
    DISK_BIND(fd);
    *(uint32_t *)(FAT_FS + 0x2C) = 0xFFFFFFFF;
    FAT_FS[4] = 0;
    FAT_MOUNT(0, FAT_FS);
    return 0;
}

/* open tape `tape`'s image and mount it as R246's start-up does; 0 ok */
static int mount_tape(int tape)
{
    if (bind_tape(tape)) return -1;
    MOUNT_INDEX();                                  /* checks the six files, data offsets */
    return 0;
}
/* FatFs keeps one sector window per volume (move_window): a dirty one belongs to the image still bound, and its
 * sector number survives a remount (the mount reads the new boot sector into the window without updating it), so a
 * later read of that sector would get the old bytes. Write a dirty window back now; forget its sector before the next
 * mount. */
static void fat_window_flush(void)
{
    uint8_t *fs = FAT_FS;
    if (!fs[4]) return;
    uint32_t s = *(uint32_t *)(fs + 0x2C), fsize = *(uint32_t *)(fs + 0x18), fat = *(uint32_t *)(fs + 0x20);
    DISK_WRITE(fs[1], fs + 0x30, s, 1);
    if (s < fat + fsize)                            /* a FAT sector: the other copies too */
        for (int n = fs[3]; n > 1; n--) { s += fsize; DISK_WRITE(fs[1], fs + 0x30, s, 1); }
    fs[4] = 0;
}
static void unmount_tape(void)
{
    INVALIDATE_ALL();                               /* every node is clean after the flush: all dropped */
    fat_window_flush();                             /* into the old image, while it is still bound */
    FAT_MOUNT(0, 0);
    if (IMG_FD >= 0) Y_CLOSE(IMG_FD);
    IMG_FD = -1;
}

/* tape.db of `tape` into the box db2 uses, under the statement lock; 0 ok (on failure the old one is open again) */
static int swap_db(int from, int to)
{
    char p[64];
    void *lock = DB_LOCK, **box = DB_BOX;
    if (lock) SEM_PEND(lock, 0);
    int r = SQL_CLOSE(*box);
    if (r == 0) {
        tape_path(p, to, "tape.db");
        r = SQL_OPEN(p, box, 2, 0);
        if (r) { tape_path(p, from, "tape.db"); SQL_OPEN(p, box, 2, 0); }
    }
    if (lock) SEM_POST(lock);
    return r;
}

static void *load_clips(void)
{
    void *pool = CLIPS_INST();
    for (int i = 0; i < 512; i++) CLIPS_HAS[i] = 0;
    CLIPS_FREE = 512;
    CLIPS_LOADED = 0;
    CLIPS_LOAD(pool);
    return pool;
}

static void load_tape_state(int fresh)
{
    void *pool = load_clips();
    int remade = 0;
    for (int t = 0; t < 4; t++)
        if (TRACK_REMADE[t]) { CLIPS_REMOVE(pool, t); TRACK_REMADE[t] = 0; remade = 1; }
    LOOP_ON = LOOP_EFF = (uint8_t)(db_int("SELECT loop FROM tape", 0) != 0);
    SET_LOOP_IN(db_int("SELECT loop_in FROM tape", 0));
    SET_LOOP_OUT(db_int("SELECT loop_out FROM tape", 0));
    int32_t tr = db_int("SELECT track FROM tape", 0);
    CUR_TRACK = tr >= 0 && tr < 4 ? tr : 0;
    LOCATE(db_int("SELECT pos FROM tape", 0));
    if (remade) TAPE_RESET(CTRL());
    op1_db_write(DB_BOX, KN_TABLE);
    bpm_unset = 0;
    if (fresh) save_bpm();                          /* a new tape starts at the tempo of this moment */
    else adopt_bpm();
}

static void do_switch(int to)
{
    int from = cur, fresh = 0;
    TAPE_SAVE();                                    /* loop, loop points, track, position of the old tape */
    op1_db_write(DB_BOX, KN_TABLE);
    tapes_used = 1;
    if (!bpm_unset) save_bpm();                     /* (at boot before tape 1's row is applied: R246's tempo, not its) */
    for (int i = 0; i < 200 && !bg_idle(); i++) DELAY_MS(10);
    if (!bg_idle()) { op1_toast("tape busy, try again"); return; }
    if (op1_tape_flush() < 0) { op1_toast("tape still writing"); return; }
    if (to && (!exists(to, "ready") || marker_dirty(to))) {
        if (!scratch) scratch = kn_alloc(0x2000);
        if (!scratch || make_tape(to)) { op1_toast("could not make the tape"); return; }
        fresh = 1;
    }
    kn_event(OP1_EV_TAPE_SWITCH, from | to << 8 | 1 << 16);
    if (swap_db(from, to)) { op1_toast("could not open the tape"); kn_event(OP1_EV_TAPE_SWITCH, from | from << 8); return; }
#ifndef OP1_HOST
    {                                               /* STEFAN: the old tape's chunks and loops go (tape/tm.c) */
        extern void tm_tape_switch(void);
        tm_tape_switch();
    }
#endif
    unmount_tape();
    if (mount_tape(to)) {                           /* the image is there (checked or just made): not expected */
        swap_db(to, from);
        mount_tape(from);
        load_tape_state(0);
        op1_toast("could not open the tape");
        kn_event(OP1_EV_TAPE_SWITCH, from | from << 8);
        return;
    }
    cur = (int8_t)to;
    load_tape_state(fresh);
    note_tape(to);
    kn_event(OP1_EV_TAPE_SWITCH, from | to << 8);
    if (op1_setting_get("tapes", "last", 0) != to + 1) op1_setting_set("tapes", "last", to + 1);   /* main loop, once a switch is done */
}

/* ---- the last tape comes back after boot (docs/tapes.md "Boot into the last tape") ----
 * "tapes.last" (1..4) is written by do_switch above. Boot still opens tape 1 only; kn_core_service calls
 * kn_tapes_boot_done right after OP1_EV_BOOT_DONE, which arms a one-shot step in kn_tapes_service. When the machine is
 * quiet (no recording, clip queue, album or disk mode; tape stopped; BgFile idle; no disk mode sync left over) it asks
 * for the ordinary switch to that tape. The boot sync after disk mode (kn_boot_fat_sync) has already run in the boot
 * hook, long before this, against the tape disk mode was on; that tape is also tapes.last, so the switch then goes back
 * to it. A sync that was left for the next boot (SYNC_WAITING still set) skips the restore this boot. A missing or
 * unfinished tape, or a switch that did not happen, stays on tape 1 and clears the key; a restore that never found a
 * quiet moment or was overtaken by the user's own switch keeps it. */
void kn_tapes_boot_done(void)
{
    int v = (int)op1_setting_get("tapes", "last", 0);
    if (v >= 2 && v <= 4 && cur == 0) { rs_tape = (int8_t)(v - 1); rs_wait = 0; rs_state = 1; }
    if (!tapes_used) tapes_used = (int8_t)(exists(1, "ready") || exists(2, "ready") || exists(3, "ready"));
    if (tapes_used && cur == 0) { bpm_unset = 1; bpm_wait = 0; }   /* tape 1's row, once the restore is settled */
}

/* stopped (or REC held), nothing recording, no disk mode or clip work, BgFile idle: the db writes (synchronous, on the
 * main loop) and boot's tempo change wait for this, as the restore does */
static int quiet(void) { return !busy_reason() && bg_idle() && (TAPE_STATE == 0 || TAPE_STATE == 3); }
/* main loop: a changed tempo into the current tape's row once it has stayed for BPM_QUIET (and the boot's step) */
static void bpm_watch(void)
{
    if (!tapes_used) return;
    if (bpm_unset) {                                /* boot: the restore switches (and loads its tape's row) or not */
        if (rs_state || req >= 0) return;
        if (bpm_wait < RS_SETTLE) { bpm_wait++; return; }
        if (cur == 0 && quiet()) adopt_bpm();
        return;
    }
    if (req >= 0) return;
    int32_t v = bpm10_now();
    if (bpm_saved < 0) { bpm_saved = bpm_seen = v; return; }       /* first pass: what the row was saved with */
    if (v == bpm_saved) { bpm_seen = v; return; }
    if (v != bpm_seen) { bpm_seen = v; bpm_since = TP_NOW(); return; }
    if (TP_NOW() - bpm_since < BPM_QUIET || !quiet()) return;
    save_bpm();
}

/* power-off / restart (bgsave.c kn_bgs_stop, before BgFileWorker stops): the last tempo into the tape's row */
void kn_tapes_shutdown(void)
{
    if (!tapes_used || bpm_unset || DISK_ACTIVE || req >= 0) return;
    if (bpm_saved < 0 || bpm10_now() != bpm_saved) save_bpm();
}
#ifdef OP1_HOST
void kn_tapes_host_reboot(void)                    /* harness/tapes_test.c: a power cycle (the core's RAM state) */
{
    req = -1; cur = 0; img_tape = 0; stop_wait = 0; rs_state = 0; rs_tape = 0; rs_wait = 0;
    bpm_saved = -1; bpm_seen = 0; bpm_since = 0; bpm_unset = 0; tapes_used = 0; bpm_wait = 0;
}
#endif

static void restore_step(void)
{
    if (rs_state == 2) {                            /* the switch was asked for: done, dropped or failed by now */
        if (req >= 0) return;
        if (cur != rs_tape) op1_setting_set("tapes", "last", 0);
        rs_state = 0;
        return;
    }
    if (cur != 0 || req >= 0) { rs_state = 0; return; }
    if (rs_wait < RS_GIVEUP) rs_wait++;
    if (rs_wait < RS_SETTLE) return;
    if (SYNC_WAITING() || rs_wait >= RS_GIVEUP) { rs_state = 0; return; }   /* a sync is still owed: boot again first */
    if (busy_reason() || !bg_idle() || (TAPE_STATE != 0 && TAPE_STATE != 3) || (ALBUM_STATE >= 2 && ALBUM_STATE <= 4)) return;
    if (!exists(rs_tape, "ready") || marker_dirty(rs_tape)) {   /* gone, or unfinished (a switch would make it again) */
        op1_setting_set("tapes", "last", 0); rs_state = 0; return;
    }
    int t = rs_tape, r = op1_tape_switch(t);        /* (clears rs_state) */
    if (r == 0) { rs_tape = (int8_t)t; rs_state = 2; return; }
    if (r == OP1_TAPE_SW_BUSY) { rs_tape = (int8_t)t; rs_state = 1; return; }   /* clip queue: try again */
    op1_setting_set("tapes", "last", 0);            /* full flash, bad tape: stay on tape 1 */
}

/* ---- the sync after a disk mode restart on tapes 2..4 (docs/tapes.md "Disk mode writes") ----
 * Leaving disk mode with changed files restarts the OP-1, and the next boot runs fat_sync_after_reboot (0x01996530,
 * called at 0x019F034E) against presync_files in op1.db, filled when disk mode began. Boot mounts tape 1, so after
 * disk mode on tape 2..4 the sync compared tape 1's files with tape N's list (tape 1's clips dropped, tape N's new
 * files not imported). NOW names the tape in use whenever it is 2..4; a switch is refused in disk mode, and the
 * restart after it is immediate, so at boot it names the tape disk mode was on. Then the boot hook itself (where
 * stock runs its sync: tape 1's db open and clips loaded, its image open and mounted, the mount check not yet run,
 * the UI not started, so the sync's log goes to the boot console as stock's does) binds tape N's db and image, loads
 * its clips, runs R246's sync on it, drains the BgFile queue (the clip rows into tape N's db), and binds tape 1 again
 * as boot left it; boot then goes on with tape 1's mount check. NOW goes only once that is done, so a power cut
 * retries. (Round 2 ran this from the first main loop pass: the sync's log then stayed on the screen.) */
static void note_tape(int tape)
{
    if (tape) { char d = (char)('1' + tape); write_file(NOW, &d, 1); }
    else Y_UNLINK(NOW);
}

static int bg_drain(int ms) { for (int i = 0; i < ms / 10 && !bg_idle(); i++) DELAY_MS(10); return bg_idle(); }

static int boot_sync(int t)
{
    if (!exists(t, "ready") || marker_dirty(t)) {  /* nothing to sync with (a raised marker: the tape is made again) */
        SYNC_CLEAR(0); Y_UNLINK(NOW); return 0;
    }
    if (!bg_drain(2000) || swap_db(0, t)) return 0;                             /* left for the next boot */
    unmount_tape();
    int r = 0, ok = !bind_tape(t);
    if (ok) {
        load_clips();                               /* as at boot: clips loaded, then the sync */
        r = FAT_SYNC();
        bg_drain(30000);                            /* the clip rows into tape N's tape.db before it is closed */
        unmount_tape();
    }
    swap_db(t, 0);
    if (bind_tape(0)) IMG_FD = -1;                  /* boot opened it a moment ago; R246 checks it next */
    load_clips();                                   /* tape 1's again */
    if (ok) Y_UNLINK(NOW);
    return r;
}

int kn_boot_fat_sync(void)                         /* CALL @0x019F034E fat_sync_after_reboot */
{
    uint8_t c = 0;
    int fd = Y_OPEN(NOW, 0, 0);
    if (fd < 0) return FAT_SYNC();                 /* tape 1: R246's own */
    Y_READ(fd, &c, 1);
    Y_CLOSE(fd);
    if (c >= '2' && c <= '4' && SYNC_WAITING()) return boot_sync(c - '1');
    Y_UNLINK(NOW);
    return FAT_SYNC();
}

/* main loop (ci_service) */
void kn_tapes_service(void)
{
    if (rs_state) restore_step();
    bpm_watch();
    int to = req;
    if (to < 0) return;
    if (busy_reason()) { req = -1; return; }        /* recording / disk mode started meanwhile: dropped */
    if (TAPE_STATE != 0 && TAPE_STATE != 3) {       /* playing or armed: STOP first, then a later pass */
        if (stop_wait == 100) { DISPATCH_KEY(0x23, 1); DISPATCH_KEY(0x23, 0); }
        if (--stop_wait <= 0) req = -1;
        return;
    }
    if (ALBUM_STATE >= 2 && ALBUM_STATE <= 4) { ALBUM_REQ(0); return; }   /* album playing: stop, next pass */
    req = -1;
    do_switch(to);
}

/* flash left (bytes); REC's flash check */
uint32_t op1_flash_free(void) { return Y_FREE(); }

/* ---- disk mode writes (docs/tapes.md "Disk mode writes") ----
 * R246's usb_ms_write_sectors (0x01A715DC, entry jumped here: .hook_mswrite) seeks to sector x 512 in the bound image
 * and writes; a short write is an assert (usb_ms_yaffs.cpp:55, a crash). A backup written back covers every sector
 * of the six files, mostly zeros, and each write takes new flash, so on a sparse tape (2..4) the flash ran out at
 * about 171 MB and the OP-1 crashed. Here: a sector of zeros whose image sector already reads zero (a hole reads
 * zero and costs nothing) is not written, so the image stays sparse; any other failure (seek, short write, or less
 * than MS_MARGIN free on tapes 2..4 before a write) returns non-zero, which R246's SCSI WRITE handler (0x01A6F404)
 * turns into CHECK CONDITION, sense key 3 (medium error): the host sees a failed write and the OP-1 keeps running.
 * Tape 1 has no margin: R246 fills its files when it makes the tape, so a write there only overwrites. Runs on the
 * USB thread, so the compare buffer is static. (buf, sector, count) -> 0 ok. */
#ifndef MS_WCOUNT
#define MS_WCOUNT     (*(volatile int32_t *)0x018C1F34)              /* sectors written (R246's counter) */
#endif
#define MS_MARGIN     (8u << 20)                   /* tapes 2..4: no write below 8 MB free (the take rule's margin) */
#define MS_RECHECK    (1u << 20)                   /* free space read again after this much written */
static uint8_t ms_cmp[4096] kn_farbss;
static uint32_t ms_free, ms_since;                  /* free space at the last read, bytes written since */

static int ms_zero(const uint8_t *p, int n) { while (n--) if (*p++) return 0; return 1; }

static int ms_put(int fd, int32_t sector, const uint8_t *src, int32_t n, int margin)
{
    uint32_t len = (uint32_t)n * 512;
    if (margin) {                                   /* read again every MB, and whenever the estimate gets close */
        if (ms_since >= MS_RECHECK || ms_free < MS_MARGIN + ms_since + len) { ms_free = Y_FREE(); ms_since = 0; }
        if (ms_free < MS_MARGIN + len) return -1;
    }
    int32_t off = sector * 512;
    if (Y_LSEEK(fd, off, 0) != off || Y_WRITE(fd, src, (int)len) != (int)len) { ms_since = MS_RECHECK; return -1; }
    if (margin) ms_since += len;
    return 0;
}

/* count sectors from buf at sector; a zero sector over one that reads zero is skipped (cmp: 4 KiB scratch) */
static int sparse_write(int fd, const uint8_t *buf, int32_t sector, int32_t count, uint8_t *cmp, int margin)
{
    int32_t run = -1;                               /* first sector of the pending write, -1 none */
    for (int32_t s = 0; s < count;) {
        if (!ms_zero(buf + s * 512, 512)) { if (run < 0) run = s; s++; continue; }
        int32_t z = s + 1, max = s + 4096 / 512;    /* zero sectors in a row, one read */
        while (z < count && z < max && ms_zero(buf + z * 512, 512)) z++;
        int32_t off = (sector + s) * 512, len = (z - s) * 512;
        int got = Y_LSEEK(fd, off, 0) == off ? Y_READ(fd, cmp, len) : -1;
        for (int32_t k = s; k < z; k++) {
            int same = got == len && ms_zero(cmp + (k - s) * 512, 512);
            if (!same) { if (run < 0) run = k; continue; }
            if (run >= 0) { if (ms_put(fd, sector + run, buf + run * 512, k - run, margin)) return -1; run = -1; }
        }
        s = z;
    }
    if (run >= 0 && ms_put(fd, sector + run, buf + run * 512, count - run, margin)) return -1;
    return 0;
}

int kn_ms_write(const uint8_t *buf, int32_t sector, int32_t count)
{
    MS_WCOUNT += count;
    return sparse_write(IMG_FD, buf, sector, count, ms_cmp, img_tape != 0);
}

/* FatFs disk_write (0x01976288, entry jumped here: .hook_diskwr), R246's own writes into the bound image: the mount
 * check's file re-creation (aifc_create_zero_file: a whole track or side of zeros), the boot sync's track copies, the
 * FAT window. On tape 1 exactly as R246 (seek, write, 1 on a short write); on tapes 2..4 zero sectors over zeros are
 * skipped as for the host's writes, so the image stays sparse (no free space margin: R246 panics on some of these
 * errors). Drives 1 and 2 answer as R246's do. */
static uint8_t dw_cmp[4096] kn_farbss;
int kn_disk_write(int drive, const uint8_t *buf, uint32_t sector, int count)
{
    if (drive) return drive == 1 || drive == 2 ? 0 : 4;
    int32_t n = (int16_t)count, off = (int32_t)sector * 512;
    int fd = DISK_FD;
    if (!img_tape) return Y_LSEEK(fd, off, 0) != off ? 1 : Y_WRITE(fd, buf, n * 512) != n * 512;
    return sparse_write(fd, buf, (int32_t)sector, n, dw_cmp, 0) ? 1 : 0;
}

/* R246's defragmenter writes clusters to the image itself (0x01974C58, entry jumped here: .hook_defragwr; (object:
 * fd, block size; buf, block, count), 0 or -1), not through FatFs. The mount check runs it when a file of the image is
 * fragmented, which a host's copy can leave (a Mac's ._ files between the tracks): on tapes 2..4 its zero sectors over
 * zeros are skipped too. Tape 1 as R246. */
#ifndef DEFRAG_WCOUNT
#define DEFRAG_WCOUNT (*(volatile int32_t *)0x0100145C)              /* blocks written (R246's counter) */
#endif
int kn_defrag_write(const int32_t *obj, const uint8_t *buf, int32_t block, int32_t count)
{
    DEFRAG_WCOUNT += count;
    int fd = obj[0];
    int32_t bs = obj[1], off = bs * block, len = bs * count;
    if (!img_tape || (bs & 511)) {
        if (Y_LSEEK(fd, off, 0) < 0) return -1;
        return Y_WRITE(fd, buf, len) == len ? 0 : -1;
    }
    return sparse_write(fd, buf, off / 512, len / 512, dw_cmp, 0);
}
#endif
