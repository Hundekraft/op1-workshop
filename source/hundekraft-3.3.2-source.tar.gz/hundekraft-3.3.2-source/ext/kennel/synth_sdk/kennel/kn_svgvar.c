/*
 * Per-panel screen art (docs/screen-art.md "Per-panel art", 2026-11-17). A screen SVG can be on one panel's pixel grid
 * only (display/snap_svg.py), and R246 draws unit (x, y) at pixel x * s + off with s = 1.25 (400 x 200), 1203/1024 (376
 * x 188) or 1.0 (320 x 156). tools/kennel/pack.py therefore appends the art snapped for the other panels to the plugin
 * file's SVG prefix, after the NUL that ends the screen SVG (panel b's):
 *     'K' 'V' code 0 | u32 size (this chunk: 8 + text + NUL) | text | NUL          code 'a' (320), 'd' (default 400)
 * R246's svg_parse_file (0x019FB458) reads the whole file, skips a BOM and parses from the text pointer at [FP + 8] up to
 * the first NUL. hook_svgstart (0x019FB57C, hook.S: the 4-byte `R0.L = 0xA5C` after the BOM skip) calls kn_svg_start
 * with the frame pointer, and the pointer moves to the chunk of the running panel. Panel b (the screen SVG itself),
 * a panel without a chunk, and every stock SVG (nothing follows their NUL) parse as before. The panel is read on every
 * parse (a lazily parsed page, an evicted one parsed again), from the screen matrix word op1_dev_scale() reads.
 * Cost: panel b nothing; the others scan the SVG for its NUL (a few microseconds per KB, once per parse).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>
#include "op1_plugin.h"

#define KV_MAX_CHUNKS 4

const uint8_t *kn_svgvar_pick(const uint8_t *p, int32_t scale)
{
    uint8_t want = scale == 0x4B3 ? 0 : scale == 0x400 ? 'a' : 'd';
    if (!want) return p;                                       /* panel b / C2: the screen SVG itself */
    const uint8_t *q = p;
    while (*q) q++;
    q++;                                                       /* the first chunk, or whatever follows the file's SVG */
    for (int n = 0; n < KV_MAX_CHUNKS && q[0] == 'K' && q[1] == 'V' && q[3] == 0; n++) {
        if (q[2] == want) return q + 8;
        uint32_t size = (uint32_t)q[4] | (uint32_t)q[5] << 8 | (uint32_t)q[6] << 16 | (uint32_t)q[7] << 24;
        if (size < 10 || size > (1u << 20)) break;
        q += size;
    }
    return p;
}

#ifndef OP1_HOST
/* hook.S _svg_start_stub: fp = the frame pointer of svg_parse_file, whose word [FP + 8] is the text pointer */
void kn_svg_start(uint32_t *fp)
{
    const uint8_t *p = (const uint8_t *)(uintptr_t)fp[2];
    if (!p) return;
    fp[2] = (uint32_t)(uintptr_t)kn_svgvar_pick(p, op1_dev_scale());
}
#endif
