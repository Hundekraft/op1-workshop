/*
 * kennel plugin loader: checks and relocation of one plugin file (docs/plugin-format.md), the same steps and order
 * as the reference loader tools/kennel/reloc.py. No firmware calls here: kn_boot.c reads the files and registers
 * the result; the host test (harness/kennel_load_host.c) runs this file on the PC against reloc.py.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_LOAD_H
#define KN_LOAD_H
#include <stdint.h>

#define KN_FORMAT_VERSION 1
#define KN_HEADER_SIZE    144
#define KN_NONE           0xFFFFFFFFu
#define KN_KIND_SYNTH     1
#define KN_KIND_FX        2
#define KN_KIND_FEATURE   3
#define KN_FLAG_USES_SAMPLE 1u
#define KN_FLAG_PAGE2       2u
#define KN_FLAG_STEREO      4u
#define KN_FLAG_INPUT       8u
#define KN_FLAG_OWN_ENV     0x20u        /* synth: the entry is an op1_engine_env_t (own envelope, op1_plugin.h); cores
                                            before 2026-11-10 refuse the bit ("unknown flags") */
#define KN_FLAG_SUM         0x40u        /* synth: the entry is an op1_engine_sum_t, 24 bytes (a block callback on the voices'
                                            sum at +20, op1_plugin.h); cores before 2026-11-11 refuse the bit ("unknown flags") */
#define KN_FLAG_T2_PAGE     0x80u        /* synth with KN_FLAG_OWN_ENV: the entry is an op1_engine_ext_t, 28 bytes (its own T2
                                            page at +24, op1_plugin.h; +20 is the sum block with KN_FLAG_SUM, else 0); cores
                                            before 2026-11-11 refuse the bit ("unknown flags") */
#define KN_FLAG_T2_SWALLOW  0x100u       /* with KN_FLAG_T2_PAGE: kennel takes the encoders and pushes on that page (nothing reaches
                                            R246's T2 words or the edit mark); the entry is unchanged. Cores before 2026-11-11
                                            (second change) refuse the bit ("unknown flags") */
#define KN_FLAG_ENG_INPUT   0x200u       /* synth: the entry is an op1_engine_ext2_t, 40 bytes: input(page, ev, a, b) at +28 takes
                                            T1 / T2 / T4 encoders and keys (op1_plugin.h); cores before 2026-11-14 refuse it */
#define KN_FLAG_T4_PAGE     0x400u       /* synth, op1_engine_ext2_t: its own T4 page at +32 and the stock LFO held off for its
                                            sounds; cores before 2026-11-14 refuse it */
#define KN_FLAG_ENG_SERVICE 0x800u       /* synth, op1_engine_ext2_t: service(ev, arg) at +36 on the main loop; cores before
                                            2026-11-14 refuse it */
#define KN_FLAG_EXT2        (KN_FLAG_ENG_INPUT | KN_FLAG_T4_PAGE | KN_FLAG_ENG_SERVICE)
#define KN_FLAG_COLD        0x1000u      /* feature only: the file has no audio-thread code and loads into the cold tier, the
                                            fixed range KN_COLD_LO..KN_COLD_HI (kn_mem.h), not heap 0's arena. The loader
                                            checks the claim (kn_cold_err) and refuses a file that breaks it. Cores before
                                            3.4 (2026-11-16) refuse the bit ("unknown plugin flags") */
#define KN_FLAG_BIGBUF      0x10u        /* the file declares a pool buffer: extension KN_EXT_BIGBUF -> op1_bigbuf_t
                                            (op1_plugin.h). Cores before 2026-10-21 refuse the bit ("unknown flags") */
#define KN_EXT_BIGBUF       4            /* extension tag: u32 image offset of the op1_bigbuf_t descriptor */
#define KN_EXT_COST         5            /* extension tag: u32 x 2, the declared worst-block cost in bcore packets (synth:
                                            per voice, voice start; FX: per call, init). Information for tools only: the
                                            core does not act on it. Any other length is ignored, never refused */
/* 6: reserved (the randomiser's word layouts, branch rnd-scope) */
#define KN_EXT_SETTINGS     7            /* extension tag: plugin.json "settings", the settings page's rows (docs/plugin-format.md
                                            "Settings table"). kn_parse only records where it is: kn_settings_add checks it,
                                            and a malformed table drops only the plugin's settings. Older cores skip it */
#define KN_BIGBUF_MAGIC     0x42424E4Bu  /* "KNBB" */
#define KN_BIGBUF_VERSION   1
#define KN_BIGBUF_SIZE      24           /* magic, version, min, max, ptr, size */
#define KN_BIGBUF_MAX       0x80000u     /* = kn_mem.h KN_DECL_MAX: a larger min is refused (kn_load.c, reloc.py) */
#define KN_FLAG_COARSE_MASK 0xF0000u     /* synth: bit 16 + k = knob k turns in 8 steps (plugin.json "coarse", op1r 44) */
#define KN_COARSE(flags)    (((flags) >> 16) & 15)

typedef struct { const char *name; uint32_t addr; } kn_export;

/* What a checked file says (pointers point into the file buffer). */
typedef struct {
    uint8_t  kind, legacy_order;
    char     type_name[16];          /* NUL-terminated copy */
    uint32_t flags;
    int16_t  defaults[4], page2[4];
    uint32_t image_size, load_size, image_align, text_size;
    uint32_t entry_offset, screen_offset;
    uint32_t hdr_off;                /* 0, or where the header starts after the SVG prefix */
    const uint8_t *svg;              /* 0 if none; else the file itself starts with the screen SVG */
    uint32_t svg_size;
    uint32_t crc;                    /* the header's crc32 */
    const char *claims, *author, *version;   /* extension table entries (NUL-terminated; claims: a NUL-separated
                                                list ending in an empty string), 0 if absent */
    uint32_t bigbuf_offset;          /* KN_FLAG_BIGBUF: image offset of the op1_bigbuf_t, else KN_NONE */
    uint32_t bigbuf_min, bigbuf_max; /* its declared sizes (bytes) */
    uint32_t cost[2];                /* KN_EXT_COST, {0, 0} if absent or malformed */
    const uint8_t *settings;         /* KN_EXT_SETTINGS (into the file), 0 if absent; unchecked */
    uint32_t settings_len;
    uint32_t n_imports;              /* entries of the import table */
} kn_info;

/* Check `file` (size bytes) and fill `info`. 0 = ok, else *err says why (a static string). */
int kn_parse(const uint8_t *file, uint32_t size, uint16_t api_version, kn_info *info, const char **err);

/* Copy the image to `dst` (which will run at address `base`, `cap` bytes available), zero .bss and apply the
 * relocations; imports are looked up in `exports` (n entries). 0 = ok, else *err. Call kn_parse first. */
/* 1 if the checked file (kn_parse) imports `name` (with Blackfin's underscore, as kn_exports.c lists it), else 0. */
int kn_imports(const uint8_t *file, const kn_info *info, const char *name);

int kn_relocate(const uint8_t *file, const kn_info *info, uint8_t *dst, uint32_t base, uint32_t cap,
                const kn_export *exports, int n, const char **err);

/* Call stubs (docs/plugin-format.md "Call stubs"): kn_relocate with one difference. A CALL / JUMP.L into the core
 * (PCREL24, +-16 MiB) that cannot reach its target from `base` goes to a stub after the image instead, which jumps
 * there absolutely: P1.L = target; P1.H = target; JUMP (P1); NOP (12 bytes, P1 is call-clobbered in the Blackfin
 * ABI). One stub per distinct target, in the order the relocations first need one, from the first 4-byte boundary at or
 * after load_size. *used: the bytes taken (load_size when no stub was needed); at most load_size + kn_stub_room().
 * The plugin arena in heap 0 (kn_boot.c) is more than 16 MiB below the core, so every core call there takes one. */
#define KN_STUB_SIZE 12u
static inline uint32_t kn_stub_room(const kn_info *in) { return 3u + KN_STUB_SIZE * in->n_imports; }
int kn_relocate_far(const uint8_t *file, const kn_info *info, uint8_t *dst, uint32_t base, uint32_t cap,
                    const kn_export *exports, int n, const char **err, uint32_t *used);

/* A look at a file's header before anything is loaded (kn_boot.c sizes the arena from it): no CRC, none of the block
 * checks. `file` holds the file's first `avail` bytes (the reader adds more while the answer is 1: an SVG prefix
 * runs to its NUL, then the header). need: the most the loader takes for this file at a bump pointer on any 4-byte
 * boundary: load_size + kn_stub_room + image_align - 1 (kn_boot.c alloc's pad). str_off / str_size: the string table
 * (the import names). 0 = ok; 1 = more bytes; -1 = kn_parse would refuse it (magic, version, header size, API,
 * kind, alignment, sizes): counts nothing. Whatever kn_parse accepts, kn_peek accepts with the same sizes. */
typedef struct { uint32_t need, load_size, str_off, str_size, flags; } kn_peek_t;   /* flags: the header's (KN_FLAG_COLD) */
int kn_peek(const uint8_t *file, uint32_t avail, uint16_t api_version, kn_peek_t *p);

/* A cold file (KN_FLAG_COLD) must have no audio-thread code. Imports that put plugin code on the audio thread or
 * timer context, or that only make sense there, are refused (kn_cold_imports, checked before memory is taken); so is
 * a relocated op1_feature_t (entry: its words) with any of tick, seq, lfo, drum, tape, note_on, note_off, note_in,
 * midi_in, midi_raw or drum_synth set. entry 0: the imports only. 0 = fine, else why the file is refused. The same
 * rules: tools/kennel/reloc.py cold_problem, pack.py at build time. */
extern const char *const kn_cold_imports[];          /* 0-terminated, with Blackfin's underscore */
#define KN_COLD_WORDS 22u                             /* op1_feature_t's size in words (kn_boot.c asserts it) */
const char *kn_cold_err(const uint8_t *file, const kn_info *info, const uint32_t *entry);

#endif
