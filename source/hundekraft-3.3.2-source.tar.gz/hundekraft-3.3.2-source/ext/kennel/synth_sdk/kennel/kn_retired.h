/* Retired ports (2026-11-17, synth_sdk/archive/README.md): KASTLE, DX, HIM, DIMENSION, MATRIX and KHORUS were kennel
 * files until the bridged files castle, dx, sim, dimension, matrix and chorus replaced them.
 *
 * The clash rule (owner 2026-11-18): a retired port's .knl / .op1p is refused only when its replacement is on the
 * device, pushed or bundled (the bridge answers: kn_foreign.h kn_foreign_has). With no replacement there the port
 * loads as any file, so the public archive's .knl files stay usable. The bridge's files load after every .knl / .op1p
 * (kn_foreign_boot), so "on the device" is also "will be loaded": no replacement is registered yet when a port's file
 * is read. A core without the bridge never refuses a port.
 * kn_boot.c decides once per listed file (list_files, before arena_need) and uses that answer in arena_need (no arena
 * for a refused file) and load_file (the log line and inventory record). The bridge's own files never pass through
 * here. Host test: harness/retired_test.c.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_RETIRED_H
#define KN_RETIRED_H

typedef struct {
    const char *id;                         /* the port's plugin id (its file name without .knl / .op1p) */
    const char *by;                         /* the replacement's name (the bridge's file name without its extension) */
    const char *refused;                    /* load_file's reason (kn_log line, inventory record) when it is there */
    const char *loaded;                     /* the log line's text when it is not and the port loaded */
} kn_retired_t;

#define KN_RETIRED_ROW(id, r) { id, r, "retired port, refused: the bundled " r " replaces it", \
                                "loaded (retired port, no bundled " r " here)" }
static const kn_retired_t kn_retired_ports[] = {
    KN_RETIRED_ROW("kastle", "castle"), KN_RETIRED_ROW("dx", "dx"), KN_RETIRED_ROW("him", "sim"),
    KN_RETIRED_ROW("dimension", "dimension"), KN_RETIRED_ROW("matrix", "matrix"), KN_RETIRED_ROW("khorus", "chorus"),
};
#undef KN_RETIRED_ROW

/* the retired port plugin file `file` ("dx.knl", "kastle.op1p", or a bare id) is, or 0 */
static inline const kn_retired_t *kn_retired_port(const char *file)
{
    for (unsigned i = 0; i < sizeof kn_retired_ports / sizeof *kn_retired_ports; i++) {
        const char *a = kn_retired_ports[i].id, *f = file;
        while (*a && *a == *f) { a++; f++; }
        if (*a) continue;
        if (!*f) return &kn_retired_ports[i];                      /* the bare id */
        const char *e = f[0] == '.' && f[1] == 'k' ? ".knl" : ".op1p";
        while (*e && *e == *f) { e++; f++; }
        if (!*e && !*f) return &kn_retired_ports[i];               /* id + .knl or .op1p, nothing after */
    }
    return 0;
}

/* Slots left on a retired type (3.3.1, owner 2026-11-18): what a stored slot's top-level "type" becomes, once, at boot
 * (kn_boot.c -> kn_presets.c kn_presets_retired_slots), while no provider of `from` registered. Only names that break a
 * slot load are here, and only to a type R246 always has:
 *   drum "him" -> "dbox": no drum type, so the drum slot load failed with error 13 and asserted patch.cpp:221 at every
 *     boot; the D-Box family shares dbox's words (kn_patch_safe.c's parse fallback, now the safety net).
 * Already safe, left alone: a synth slot on "kastle" (or "dx" / "dimension" with no bridge) loads as stock iter, the
 * name kept (dispatcher.c patch_type_hook: selector 0); not mapped to the bridged "castle" (sounds of retired ports
 * are let go, no compatibility code; kastle's words were never checked against castle's). An FX "khorus" loads as the stock filter (fx_name_eq, fx_patch_type_hook), name kept.
 * An LFO "matrix" is taken by the bridged matrix (old words read), or without it reset to tremolo, off
 * (kn_patch_safe.c known_lfo). dx, dimension and matrix keep their names through the bridge. */
typedef struct { const char *tbl, *from, *to; } kn_retired_slot_t;
static const kn_retired_slot_t kn_retired_slots[] = { { "drum_slots", "him", "dbox" } };

/* 1: refuse `file` (a retired port whose replacement is on the device); 0: load it as any file. has(name) is 1 when the
 * bridge's file `name` is on the device; 0 for has (a core without the bridge): never refused. */
static inline int kn_retired_refuse(const char *file, int (*has)(const char *name))
{
    const kn_retired_t *p = kn_retired_port(file);
    return p && has && has(p->by);
}

#endif
