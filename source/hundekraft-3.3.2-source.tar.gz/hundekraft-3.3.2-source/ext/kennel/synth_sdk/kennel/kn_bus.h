/* core side of op1_bus.h (kennel/kn_bus.c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_BUS_H
#define KN_BUS_H
#include <stdint.h>
void kn_bus_run(int pos, int16_t *bus);                   /* kn_input_bus: after the high-pass, pos 0 synth, 1 drum */
void kn_bus_post_site(int pos, int16_t *bus);             /* kn_input_bus: after the gap declick (post, FX not due) */
void kn_bus_after_fx(int16_t *bus);                       /* kn_dc_mono: after a mono FX render and its declick */
void kn_bus_master_pre(int16_t *l, int16_t *r);           /* kn_mfx_site: after the master EQ, before the gap declick */
void kn_bus_master_post_site(int16_t *l, int16_t *r);     /* kn_mfx_site: after the gap declick */
void kn_bus_master_after_fx(int16_t *l, int16_t *r);      /* fr_route: after the master FX and its declick */
void ml_bus_tick(void);                                   /* screens/mlfo.c: the master LFO's strip targets, once a block */
#endif
