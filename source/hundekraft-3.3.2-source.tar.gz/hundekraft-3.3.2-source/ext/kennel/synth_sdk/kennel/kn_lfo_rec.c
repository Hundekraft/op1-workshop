/*
 * A sound's records: values kept in the sound's JSON beside the eight words, for settings that have no room in them.
 * Two kinds share this store (the same keep step, cache, JSON writer):
 *   "lfo_rec": {"id": <id>, "p": [64 ints]}       an LFO type's record (op1_feature_lforec.h; matrix): the id is in the
 *                                                  type's words, so a cache that missed a copy is detected
 *   "eng_rec": {"e": "<engine>", "p": [16 ints]}  an engine's record (op1_plugin.h op1_engine_record; outatime's drive
 *                                                  shape): the owner is the engine's name, so another engine on the
 *                                                  slot never reads it
 *   "eng_data": {"e": "<engine>", "p": [104 ints]} an engine's data (op1_plugin.h op1_engine_data, 2026-11-14; dx's edited
 *                                                  voice): up to OP1_ENGINE_DATA_MAX bytes, p[0] the byte count, p[1..]
 *                                                  the bytes as a little-endian bit stream 15 bits a value, so every
 *                                                  value is 0..32767 (no sign through R246's jsoncpp writer and reader);
 *                                                  synth slots only (no drum cache)
 * Both are kept through parse_patch_json by dp_keep_op1r (kennel/kn_drum.c, every patch the parser builds: presets in
 * the table, slots at boot, a preset load, the synth controller's patch) and cached per slot here, so the audio thread
 * reads plain int16 and never JSON. Every JSON node is type-checked before it is indexed: jsoncpp asserts on a wrong
 * type, and a hand-edited member ("eng_rec": 5) must never stop a sound from loading. A slot whose patch has no valid
 * member has no record (the type's / engine's defaults); nothing else in the patch depends on the member. Stock and
 * older parsers drop both members (the sound plays with the defaults there).
 *
 * The cache: two buffers a slot; a new record is written into the one not in use, then made current, then its id set,
 * so the audio thread (which preempts every writer) never reads a half-written record.
 *
 * Writing the JSON (the KeyHandler thread, a turn): R246's BgFileWorker serializes a live slot patch in its jobs (the
 * slot save, the preset and type jobs; kn_drum_synth.c), and a structural change of that JSON while the writer walks
 * it crashes R246 (json_value.cpp:1029). So a record whose member already has its shape is written in place, value by
 * value (an int Value owns no memory, as patch::set_knobs writes the knobs); a member that is missing or malformed is
 * rebuilt only while no such job runs (op1_drum_synth_patch_busy). An engine record that can't be written then is
 * pending: the cache has it (the sound plays it), the main loop (kn_eng_rec_service) writes it once the job is done.
 * After the JSON write the patch is marked changed (vt+0x34, as patch::set_knobs), so the stock save path saves it.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_feature_lforec.h"
#include "../op1_plugin.h"
#ifndef KN_LFO_REC_HOST
#include "../kn_mem.h"                                    /* kn_farbss */
#else
#define kn_farbss
#endif

#ifndef KN_LFO_REC_HOST
#define JV_KEY      ((void *(*)(void *, const char *))0x019BFEB4)        /* Value::operator[](const char *) */
#define JV_CGET     ((const void *(*)(const void *, const char *))0x019BEB70)   /* const operator[]: no member added */
#define JV_IDX      ((void *(*)(void *, unsigned))0x019BFAF8)            /* Value::operator[](ArrayIndex) */
#define JV_SIZE     ((unsigned (*)(const void *))0x019BE8D8)             /* Value::size */
#define JV_ASSIGN   ((void *(*)(void *, const void *))0x019BDDC0)        /* Value::operator= */
#define JV_FROM_INT ((void *(*)(void *, int))0x019BD890)                 /* Value(int) */
#define JV_FROM_STR ((void *(*)(void *, const char *))0x019BDC4C)        /* Value(const char *) */
#define JV_DTOR     ((void (*)(void *, int))0x019BDD18)
#define JV_REMOVE   ((void (*)(void *, void *, const char *))0x019BEE88) /* removeMember(key) -> out */
#define LR_PATCH(pos, slot) ((uint8_t *)(((pos) ? 0x01DDD9A8u : 0x01DDD7E8u) + (uint32_t)(slot) * 0x38u))
#define LR_PATCH_JSON(pos, slot) ((void *)(LR_PATCH(pos, slot) + 4))
static inline uint32_t lr_cycles(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
static void lr_changed(int pos, int slot)               /* mark the patch changed, as patch::set_knobs (kennel/kn_seq.c) */
{
    uint8_t *patch = LR_PATCH(pos, slot);
    const uint32_t *vt = *(const uint32_t **)(patch + 0x34);
    ((void (*)(void *))vt[0x34 / 4])(patch + (int16_t)vt[0x30 / 4]);
}
uint32_t op1_drum_synth_patch_busy(void);               /* kennel/kn_drum_synth.c: a stock patch job runs */
#define LR_BUSY() op1_drum_synth_patch_busy()
#else                                                     /* host test (harness/rec_store_test.c) supplies these */
void *JV_KEY(void *v, const char *k);
const void *JV_CGET(const void *v, const char *k);
void *JV_IDX(void *v, unsigned i);
unsigned JV_SIZE(const void *v);
void *JV_ASSIGN(void *d, const void *s);
void *JV_FROM_INT(void *v, int i);
void *JV_FROM_STR(void *v, const char *s);
void JV_DTOR(void *v, int how);
void JV_REMOVE(void *v, void *out, const char *k);
void *LR_PATCH_JSON(int pos, int slot);
uint32_t lr_cycles(void);
void lr_changed(int pos, int slot);
uint32_t LR_BUSY(void);
#endif
enum { LR_NULL = 0, LR_INT = 1, LR_UINT = 2, LR_STRING = 4, LR_ARRAY = 6, LR_OBJECT = 7 };
static uint8_t lr_type(const void *v) { return ((const uint8_t *)v)[8]; }
static const char *lr_str(const void *v) { return lr_type(v) == LR_STRING ? *(const char *const *)v : 0; }

/* ---- the kinds ---- */
typedef struct {
    const char *key;                                      /* the sound JSON's member */
    const char *owner;                                    /* "id": a positive int; "e": a name (its hash is the id) */
    int n;                                                /* values a record */
    int npos;                                             /* positions cached: 2 (synth, drum) or 1 (synth only) */
    int16_t *rec;                                         /* [2 pos][8 slots][2 buffers][n] */
    volatile uint8_t *cur;                                /* [2][8] the current buffer */
    volatile uint32_t *id;                                /* [2][8] 0: no record */
} lr_kind;

static int16_t lr_rec[2][8][2][OP1_LFO_REC_N];            /* (names as matrix-lfo's: native scripts read them) */
static volatile uint8_t lr_cur[2][8];
static volatile uint32_t lr_id[2][8];
static int16_t er_rec[2][8][2][OP1_ENGINE_REC_N];
static volatile uint8_t er_cur[2][8];
static volatile uint32_t er_id[2][8];                     /* the engine's op1_engine_rec_owner, 0: none */
/* The cache holds up to KN_ENGINE_DATA_CAP bytes (256: a foreign engine's data, kennel/kn_foreign.h, through
 * kn_engine_data_store_n); plugin files store up to OP1_ENGINE_DATA_MAX (192). A record of at most 192 bytes is written
 * as before, 1 + OP1_ENGINE_DATA_WORDS values (dat_len), so dx's saved JSON and older cores reading it are unchanged; a
 * longer one is 1 + KN_ENGINE_DATA_CAP_WORDS values, of which an older core reads the first 104 (its byte count is
 * then over its limit: no data, never a crash). */
#define KN_ENGINE_DATA_CAP       256
#define KN_ENGINE_DATA_CAP_WORDS 137                      /* ceil(256 * 8 / 15) */
#define ED_N (1 + KN_ENGINE_DATA_CAP_WORDS)               /* the byte count, then the packed bytes */
static int16_t ed_rec[1][8][2][ED_N] kn_farbss;           /* synth slots only: 4.4 KB */
static volatile uint8_t ed_cur[1][8];
static volatile uint32_t ed_id[1][8];
static const lr_kind LFO = { "lfo_rec", "id", OP1_LFO_REC_N, 2, &lr_rec[0][0][0][0], &lr_cur[0][0], &lr_id[0][0] };
static const lr_kind ENG = { "eng_rec", "e", OP1_ENGINE_REC_N, 2, &er_rec[0][0][0][0], &er_cur[0][0], &er_id[0][0] };
static const lr_kind DAT = { "eng_data", "e", ED_N, 1, &ed_rec[0][0][0][0], &ed_cur[0][0], &ed_id[0][0] };
#define AT(k, pos, slot) ((pos) * 8 + (slot))
static int16_t *buf(const lr_kind *k, int pos, int slot, int b) { return k->rec + ((AT(k, pos, slot) * 2 + b) * k->n); }
/* the values a record is written with: every kind its n, the engine data its short form while it fits */
static int rec_len(const lr_kind *k, const int16_t *p)
{
    return k == &DAT && p[0] <= OP1_ENGINE_DATA_MAX ? 1 + OP1_ENGINE_DATA_WORDS : k->n;
}

/* an int member that fits an int16 (records) or a positive int (ids); 0 when not one */
static int lr_int(const void *v, int32_t *out)
{
    const int32_t w = *(const int32_t *)v;
    if (lr_type(v) == LR_INT || (lr_type(v) == LR_UINT && w >= 0)) { *out = w; return 1; }
    return 0;
}

/* the member's owner as the cache's id: "id" a positive int, "e" an engine name of 1..31 characters; 0 when invalid */
static uint32_t owner_of(const lr_kind *k, const void *member)
{
    const void *o = JV_CGET(member, k->owner);            /* (const lookups: a malformed member gains no node) */
    if (k != &LFO) {
        const char *s = lr_str(o);
        int l = 0;
        if (!s) return 0;
        while (l < 32 && s[l]) l++;
        return l >= 1 && l < 32 ? op1_engine_rec_owner(s) : 0;
    }
    int32_t id;
    return lr_int(o, &id) && id > 0 ? (uint32_t)id : 0;
}

/* the cache: n values (missing ones 0) into the buffer not in use, made current, then the id */
static void cache_put(const lr_kind *k, int pos, int slot, uint32_t id, const int16_t *p, int n)
{
    const int at = AT(k, pos, slot), b = !k->cur[at];
    int16_t *d = buf(k, pos, slot, b);
    for (int i = 0; i < k->n; i++) d[i] = i < n ? p[i] : 0;
    k->cur[at] = (uint8_t)b;                              /* the old id still finds the old record until here */
    k->id[at] = id;
}

/* the slot's patch was parsed (keep step): its member (0: none) into the cache */
static void rec_loaded(const lr_kind *k, int pos, int slot, void *member)
{
    if ((unsigned)pos >= (unsigned)k->npos || (unsigned)slot > 7) return;
    const int at = AT(k, pos, slot);
    uint32_t id;
    void *p;
    if (!member || lr_type(member) != LR_OBJECT || !(id = owner_of(k, member))
        || lr_type(p = (void *)JV_CGET(member, "p")) != LR_ARRAY) { k->id[at] = 0; return; }
    const int b = !k->cur[at];
    int16_t *d = buf(k, pos, slot, b);
    const unsigned n = JV_SIZE(p);
    for (unsigned i = 0; i < (unsigned)k->n; i++) {
        int32_t v = 0;
        if (i < n && !lr_int(JV_IDX(p, i), &v)) { k->id[at] = 0; return; }   /* not an int: no record */
        if (v < -32768 || v > 32767) { k->id[at] = 0; return; }
        d[i] = (int16_t)v;
    }
    k->id[at] = 0;
    k->cur[at] = (uint8_t)b;
    k->id[at] = id;
}

static void *rec_keep(const lr_kind *k, void *patch, void *fresh)
{
    void *old = JV_KEY(patch, k->key);                    /* (adds a null member if absent: patch is overwritten next) */
    if (lr_type(old) != LR_OBJECT) return 0;
    JV_ASSIGN(JV_KEY(fresh, k->key), old);
    return JV_KEY(fresh, k->key);
}

/* the member written in place when it has the record's shape (owner of the right type, "p" an array of exactly n ints):
 * no node added or freed. -> 1 when written */
static int json_in_place(const lr_kind *k, void *json, const char *name, uint32_t id, const int16_t *p)
{
    const void *m = JV_CGET(json, k->key);
    if (!m || lr_type(m) != LR_OBJECT) return 0;
    const void *o = JV_CGET(m, k->owner), *a = JV_CGET(m, "p");
    const int len = rec_len(k, p);
    if (!o || !a || lr_type(a) != LR_ARRAY || JV_SIZE(a) != (unsigned)len) return 0;
    if (k != &LFO) {                                      /* the same engine's name: unchanged */
        const char *s = lr_str(o);
        int i = 0;
        if (!s) return 0;
        for (; name[i] && s[i] == name[i]; i++) {}
        if (name[i] || s[i]) return 0;
    } else if (lr_type(o) != LR_INT && lr_type(o) != LR_UINT) return 0;
    void *mm = JV_KEY(json, k->key), *aa = JV_KEY(mm, "p");
    for (int i = 0; i < len; i++) {
        int32_t v;
        if (!lr_int(JV_IDX(aa, (unsigned)i), &v)) return 0;   /* (checked before any write: all or nothing) */
    }
    uint32_t tmp[4];
    if (k == &LFO) { JV_FROM_INT(tmp, (int)id); JV_ASSIGN(JV_KEY(mm, k->owner), tmp); JV_DTOR(tmp, 2); }
    for (int i = 0; i < len; i++) { JV_FROM_INT(tmp, p[i]); JV_ASSIGN(JV_IDX(aa, (unsigned)i), tmp); JV_DTOR(tmp, 2); }
    return 1;
}

/* the member rebuilt: whatever was there (any type) removed, a fresh object (structural: no stock patch job may run) */
static void json_rebuild(const lr_kind *k, void *json, const char *name, uint32_t id, const int16_t *p)
{
    uint32_t tmp[4];
    JV_REMOVE(json, tmp, k->key); JV_DTOR(tmp, 2);
    void *m = JV_KEY(json, k->key);
    if (k != &LFO) JV_FROM_STR(tmp, name); else JV_FROM_INT(tmp, (int)id);
    JV_ASSIGN(JV_KEY(m, k->owner), tmp); JV_DTOR(tmp, 2);
    void *a = JV_KEY(m, "p");
    const int len = rec_len(k, p);
    for (int i = 0; i < len; i++) { JV_FROM_INT(tmp, p[i]); JV_ASSIGN(JV_IDX(a, (unsigned)i), tmp); JV_DTOR(tmp, 2); }
}

/* ---- parse_patch_json's keep step (dp_keep_op1r): both members onto the fresh patch, for every patch the parser
 * builds; a slot's (synth_slot / drum_slot >= 0) into the caches ---- */
void kn_lfo_rec_loaded(int pos, int slot, void *member) { rec_loaded(&LFO, pos, slot, member); }
#ifndef KN_LFO_REC_HOST
#include "kn_foreign.h"
extern const char *op1_engine_names[];
static int hexv(char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1; }
/* another format's engine data (kn_foreign.h kn_foreign_data): its member is kept (copied into the parsed patch, as
 * rec_keep: a preset in the table and the slot it loads into keep it, and the slot's save writes it back); then, for a
 * synth slot with no eng_data (slot >= 0), its hex string into the cache. Every node type-checked; a bad string (odd
 * length, a non-hex character, over 256 bytes) gives no data */
static void foreign_data(void *patch, void *fresh, int slot)
{
    if (!kn_foreign_data) return;
    const void *k = JV_CGET(patch, "knobs");
    if (!k || lr_type(k) != LR_ARRAY || JV_SIZE(k) <= 4) return;
    int32_t mark;
    if (!lr_int(JV_IDX((void *)k, 4), &mark) || mark < 0 || mark > 32767) return;   /* (size checked: no resize) */
    const char *mk = 0, *kk = 0;
    const int n = kn_foreign_data(mark, &mk, &kk);        /* (names given whatever the mark: kept before a load) */
    if (!mk || !kk) return;
    const char *name = n > 0 ? op1_engine_names[n - 1] : 0;
    if (name && name[0]) {
        /* an "iter" sound the other format's mark opened (with its member or without): saved by the engine's name from
         * here on, as kennel's own (the type name is the identity; the selector alone would move when the build's
         * engine numbers change) */
        const char *t = lr_str(JV_CGET(fresh, "type"));
        if (t && t[0] == 'i' && t[1] == 't' && t[2] == 'e' && t[3] == 'r' && !t[4]) {
            uint32_t tmp[4];
            JV_FROM_STR(tmp, name); JV_ASSIGN(JV_KEY(fresh, "type"), tmp); JV_DTOR(tmp, 2);
        }
    }
    const void *m = JV_CGET(patch, mk);
    if (!m || lr_type(m) != LR_OBJECT) return;
    JV_ASSIGN(JV_KEY(fresh, mk), m);                      /* kept (fresh is the patch from here on) */
    if (!name || !name[0] || slot < 0) return;
    const char *s = lr_str(JV_CGET(m, kk));
    if (!s) return;
    int len = 0;
    while (len <= 2 * KN_ENGINE_DATA_CAP && s[len]) len++;
    if (!len || (len & 1) || len > 2 * KN_ENGINE_DATA_CAP) return;
    int16_t v[ED_N];
    for (int i = 0; i < ED_N; i++) v[i] = 0;
    v[0] = (int16_t)(len / 2);
    for (int i = 0; i < len / 2; i++) {
        const int hi = hexv(s[2 * i]), lo = hexv(s[2 * i + 1]);
        if (hi < 0 || lo < 0) return;
        const int d = hi << 4 | lo, b = 8 * i, wi = b / 15, sh = b % 15;
        v[1 + wi] = (int16_t)((v[1 + wi] | d << sh) & 0x7FFF);
        if (sh > 7) v[2 + wi] = (int16_t)(d >> (15 - sh));
    }
    cache_put(&DAT, 0, slot, op1_engine_rec_owner(name), v, ED_N);
}
#endif
/* [0] the engine record (eng_rec), [1] the engine data (eng_data); synth slots (stores are synth only) */
static volatile uint8_t er_pending[2][8];                 /* in the cache, not yet in the JSON */
static const char *er_name[2][8];                         /* its engine's name (op1_engine_names: static strings) */
void kn_lfo_rec_keep(void *patch, void *fresh, int synth_slot, int drum_slot)
{
    for (int i = 0; i < 3; i++) {
        const lr_kind *k = i == 2 ? &DAT : i ? &ENG : &LFO;
        void *m = rec_keep(k, patch, fresh);
        if (synth_slot >= 0) rec_loaded(k, 0, synth_slot, m);
        if (drum_slot >= 0) rec_loaded(k, 1, drum_slot, m);
    }
    if (synth_slot >= 0 && synth_slot < 8) er_pending[0][synth_slot] = er_pending[1][synth_slot] = 0;   /* the loaded
                                                                 sound's own record and data win */
#ifndef KN_LFO_REC_HOST
    foreign_data(patch, fresh, synth_slot >= 0 && synth_slot < 8 && !ed_id[0][synth_slot] ? synth_slot : -1);
#endif
}

/* ---- an LFO type's record (op1_feature_lforec.h) ---- */
const int16_t *op1_lfo_record(int pos, int slot, uint32_t id)
{
    if ((unsigned)pos > 1 || (unsigned)slot > 7 || !id || lr_id[pos][slot] != id) return 0;
    return lr_rec[pos][slot][lr_cur[pos][slot]];
}

uint32_t op1_lfo_record_store(int pos, int slot, const int16_t *p, int n)
{
    static uint32_t seed = 0x2545F491u;
    if ((unsigned)pos > 1 || (unsigned)slot > 7 || !p || n < 1 || n > OP1_LFO_REC_N) return 0;
    const uint32_t old = lr_id[pos][slot];
    uint32_t id;
    do {
        seed = seed * 1664525u + 1013904223u + lr_cycles();
        id = (seed >> 1) & 0x7FFFFFFFu;
    } while (!id || id == old);
    int16_t v[OP1_LFO_REC_N];
    for (int i = 0; i < OP1_LFO_REC_N; i++) v[i] = i < n ? p[i] : 0;
    void *json = LR_PATCH_JSON(pos, slot);
    if (!json_in_place(&LFO, json, 0, id, v)) json_rebuild(&LFO, json, 0, id, v);   /* (the caller saves the words) */
    cache_put(&LFO, pos, slot, id, v, OP1_LFO_REC_N);     /* the words take the new id after this returns */
    return id;
}

/* ---- an engine's record (op1_plugin.h) ---- */
const int16_t *op1_engine_record(int slot, uint32_t owner)
{
    if ((unsigned)slot > 7 || !owner || er_id[0][slot] != owner) return 0;
    return er_rec[0][slot][er_cur[0][slot]];
}

static volatile uint8_t er_writing;                       /* a JSON write in progress (the main loop's, preempted) */
/* the cache's record (which 0) or data (which 1) of synth slot `slot` into the patch JSON: in place, or rebuilt while no
 * stock patch job runs. -> 1 written (and the patch marked changed), 0 left pending */
static int er_flush(int which, int slot)
{
    if (er_writing) return 0;
    er_writing = 1;
    const lr_kind *k = which ? &DAT : &ENG;
    int done = 0;
    const char *name = er_name[which][slot];
    const uint32_t id = k->id[AT(k, 0, slot)];
    if (!id || !name) { er_pending[which][slot] = 0; er_writing = 0; return 1; }   /* dropped meanwhile: nothing to write */
    er_pending[which][slot] = 0;                          /* first: a store while writing pends again */
    static int16_t v[ED_N > OP1_ENGINE_REC_N ? ED_N : OP1_ENGINE_REC_N];   /* (er_writing: one writer) */
    const int16_t *c = buf(k, 0, slot, k->cur[AT(k, 0, slot)]);
    for (int i = 0; i < k->n; i++) v[i] = c[i];
    void *json = LR_PATCH_JSON(0, slot);
    if (json_in_place(k, json, name, id, v)) done = 1;
    else if (!LR_BUSY()) { json_rebuild(k, json, name, id, v); done = 1; }
    if (done) lr_changed(0, slot);
    else er_pending[which][slot] = 1;
    er_writing = 0;
    return done;
}

static int name_ok(const char *name)
{
    int l = 0;
    if (!name || !name[0]) return 0;
    while (l < 32 && name[l]) l++;
    return l < 32;
}

int op1_engine_record_store(int slot, const char *name, const int16_t *p, int n)
{
    if ((unsigned)slot > 7 || !name_ok(name) || !p || n < 1 || n > OP1_ENGINE_REC_N) return 0;
    er_name[0][slot] = name;
    cache_put(&ENG, 0, slot, op1_engine_rec_owner(name), p, n);   /* the sound plays it from here */
    er_pending[0][slot] = 1;
    er_flush(0, slot);
    return 1;
}

/* ---- an engine's data (op1_plugin.h op1_engine_data): bytes packed 15 bits a value ---- */
int op1_engine_data(int slot, uint32_t owner, void *out, int max)
{
    if ((unsigned)slot > 7 || !owner || ed_id[0][slot] != owner || !out || max <= 0) return 0;
    const int16_t *w = ed_rec[0][slot][ed_cur[0][slot]];
    int n = w[0];
    if (n <= 0 || n > KN_ENGINE_DATA_CAP) return 0;
    if (n > max) n = max;
    uint8_t *o = out;
    for (int i = 0; i < n; i++) {                         /* byte i = bits 8i .. 8i+7 of the stream */
        const int b = 8 * i, wi = b / 15, sh = b % 15;
        uint32_t x = (uint32_t)(uint16_t)w[1 + wi] >> sh;
        if (sh > 7) x |= (uint32_t)(uint16_t)w[2 + wi] << (15 - sh);
        o[i] = (uint8_t)x;
    }
    return n;
}

int kn_engine_data_store_n(int slot, const char *name, const void *data, int n, int cap);
int op1_engine_data_store(int slot, const char *name, const void *data, int n)
{
    return kn_engine_data_store_n(slot, name, data, n, OP1_ENGINE_DATA_MAX);
}
/* the store with a cap: OP1_ENGINE_DATA_MAX for plugin files, up to KN_ENGINE_DATA_CAP for the core (kn_foreign.h) */
int kn_engine_data_store_n(int slot, const char *name, const void *data, int n, int cap)
{
    if (cap > KN_ENGINE_DATA_CAP) cap = KN_ENGINE_DATA_CAP;
    if ((unsigned)slot > 7 || !name_ok(name) || n < 0 || n > cap || (n && !data)) return 0;
    int16_t v[ED_N];
    for (int i = 0; i < ED_N; i++) v[i] = 0;
    v[0] = (int16_t)n;
    const uint8_t *d = data;
    for (int i = 0; i < n; i++) {
        const int b = 8 * i, wi = b / 15, sh = b % 15;
        v[1 + wi] = (int16_t)((v[1 + wi] | d[i] << sh) & 0x7FFF);
        if (sh > 7) v[2 + wi] = (int16_t)(d[i] >> (15 - sh));
    }
    er_name[1][slot] = name;
    cache_put(&DAT, 0, slot, op1_engine_rec_owner(name), v, ED_N);
    er_pending[1][slot] = 1;
    er_flush(1, slot);
    return 1;
}

/* the main loop (kennel/kn_core.c kn_core_service): pending records into their JSON once no stock patch job runs */
void kn_eng_rec_service(void)
{
    for (int s = 0; s < 8; s++) {
        if (er_pending[0][s]) er_flush(0, s);
        if (er_pending[1][s]) er_flush(1, s);
    }
}

/* the synth type job picked an engine for the slot (samplerplus/sp_core.c sp_type_job, on the worker inside its patch
 * job count): a fresh pick has the engine's defaults, as its words, so the record goes. The job copies the slot's JSON
 * without the parser (0x0193FFAC, 0x019FF5F0: no keep step), so it is dropped here, before the copy. */
void kn_eng_rec_drop(int slot)
{
    if ((unsigned)slot > 7) return;
    er_pending[0][slot] = er_pending[1][slot] = 0;
    er_id[0][slot] = 0;
    ed_id[0][slot] = 0;
    void *json = LR_PATCH_JSON(0, slot);
    for (int i = 0; i < 2; i++) {
        const char *key = i ? DAT.key : ENG.key;
        const void *m = JV_CGET(json, key);
        if (m && lr_type(m) != LR_NULL) { uint32_t tmp[4]; JV_REMOVE(json, tmp, key); JV_DTOR(tmp, 2); }
    }
}

/* a synth slot's sound "lfo_active" (kennel/kn_eng_hooks.c: the held-off LFO given back): 1 / 0, -1 when not a bool.
 * Const lookups only (no node added), so a stock patch job's writer is never disturbed. */
int kn_patch_lfo_active(int slot)
{
    if ((unsigned)slot > 7) return -1;
    const void *v = JV_CGET(LR_PATCH_JSON(0, slot), "lfo_active");
    return v && lr_type(v) == 5 ? ((const uint8_t *)v)[0] != 0 : -1;
}
