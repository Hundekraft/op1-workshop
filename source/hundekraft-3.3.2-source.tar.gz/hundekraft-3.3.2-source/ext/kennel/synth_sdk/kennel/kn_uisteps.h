/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 *
 * Two small UI helpers, pure C so harness/uisteps_test.c runs the same code as the core:
 *
 * 1. PICKER STEP (settings row, key 'pickstep'): R246's mode-8 lists (engine, FX, LFO, sequencer pickers, preset browsers) move one
 *    row per 4 encoder ticks (CtlKnob scale 4 at 0x01DE5154, built by 0x01A17804). One tick = 1024 knob delta = 2 quadrature
 *    edges (512 each, docs/firmware/input.md); a tick is taken as one detent (how many edges a mechanical detent makes is
 *    open item G18, and the settings page counts ticks the same way). kn_pick_delta scales the delta before stock
 *    sees it (dispatcher.c knob_event_hook): index 0 = 1 detent a row (x4), 1 = 2 (x2), 2 = 4 (x1, stock).
 * 2. Shift + < / > repeat on the tape screen: kn_rep_step is polled from kn_core_service while the arrow is held.
 *    The first repeat is due 400 ms after the press, the next ones every 130 ms from the last one sent. Cycles at 400 MHz.
 */
#ifndef KN_UISTEPS_H
#define KN_UISTEPS_H
#include <stdint.h>

#define KN_PICK_STOCK 2                                   /* index of 4 detents a row = R246 as is */
static inline int16_t kn_pick_delta(int16_t d, int idx)
{
    const int32_t m = idx == 0 ? 4 : idx == 1 ? 2 : 1;
    const int32_t v = (int32_t)d * m;
    return (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v);
}

/* R246's mode 8 is every list picker (preset_browser_open 0x01A174DC). Its list object pointer, 0x01DE511C, is the synth
 * (0x01DDD688) or drum (0x01DDD698) preset-browser root (kn_preset_tools.c) or a type list's own (engine, FX, LFO,
 * sequencer, ...). Every list scales, the preset browsers too (owner 2026-11-18; until then they kept stock pace). (The word at
 * 0x01DE5140 is 4 x the rows of the folder knob, 212 / 120 / 36 / 48 in the engine / FX / LFO / preset lists: no folder
 * count.) Called with the mode-8 knob delta. */
#define KN_PICK_ROOT_SYNTH 0x01DDD688u
#define KN_PICK_ROOT_DRUM  0x01DDD698u
static inline int16_t kn_pick_scale(int16_t d, int idx, uint32_t root)
{
    (void)root;                                           /* (kept: the preset roots are no longer an exception) */
    if (idx >= KN_PICK_STOCK) return d;
    return kn_pick_delta(d, idx);
}

#define KN_REP_FIRST (160u * 1000 * 1000)                 /* 400 ms */
#define KN_REP_NEXT  (52u * 1000 * 1000)                  /* 130 ms */
typedef struct { uint64_t since, next; int code; } kn_rep_t;   /* code -1: idle */
/* active: the arrow is held, with Shift (down at the press too), on the tape screen. since: the press time.
 * Returns 1 when one more press is due. A new press (code or since changed) restarts the first delay. */
static inline int kn_rep_step(kn_rep_t *s, int active, int code, uint64_t since, uint64_t now)
{
    if (!active) { s->code = -1; return 0; }
    if (s->code != code || s->since != since) { s->code = code; s->since = since; s->next = since + KN_REP_FIRST; }
    if (now < s->next) return 0;
    s->next = now + KN_REP_NEXT;
    return 1;
}
#endif
