/* The instrument-bus insert and its modulation (op1_bus.h). kn_bus_run is called from kn_input_bus (kennel/kn_input.c)
 * after R246's high-pass, once a block, for the synth (pos 0) or the drum (pos 1) caller of core_bus_highpass; it
 * steps the master LFO's strip targets (screens/mlfo.c ml_bus_tick), sums the fresh modulation and calls the insert.
 * No insert registered, or its gate says the bus is idle (op1_bus_gate), and no tap (kn_tap_add): a few loads and branches. The insert's time is charged to the FX class of the resource monitor.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../op1_synth.h"
#include "../op1_bus.h"
#include "../kn_mem.h"
#include "kn_bus.h"
#include "kn_foreign.h"                                   /* the audio taps (kn_tap_add) */

#ifndef OP1_HOST
#define BLOCKS() (*(volatile uint16_t *)0x01AB8BAC)          /* R246's block count, a 16-bit word (core_block_process) */
#else
uint16_t kn_bus_host_blocks;
#define BLOCKS() (kn_bus_host_blocks)
#endif

/* the words every site tests, in one cache line (a cold block fetches it once for all five sites) */
static struct {
    op1_bus_insert_fn insert;
    const volatile uint8_t *gate_ui, *gate_au;            /* op1_bus_gate: the insert's wake flags, or 0 */
    volatile uint32_t tap_n;                              /* kn_foreign.h's pre-FX taps: the only word read while none is registered */
    uint8_t post[3], armed;                               /* post FX per bus; armed: pos + 1 while R246's FX is due */
    uint8_t marmed;                                       /* the master's: armed while its FX is due */
} h kn_hot __attribute__((aligned(32)));
static kn_tap_fn taps[KN_TAP_MAX] kn_hot;                 /* the taps (kn_tap_add, below) */
static int16_t mods[OP1_BUS_NSRC][3][OP1_BUS_NMOD] kn_hot;
static uint16_t stamp[OP1_BUS_NSRC][3] kn_hot;
static uint8_t seen[OP1_BUS_NSRC][3] kn_hot;
volatile uint32_t kn_bus_calls, kn_bus_cy_max;            /* emulator checks: blocks with the insert, its slowest */
static uint16_t ran_at[3] kn_hot;                         /* per bus: the block the insert ran last (+1: 0 = never) */
volatile uint32_t kn_bus_where[4];                        /* emulator checks: runs pre, after the FX, post without FX, misses */
volatile uint32_t kn_bus_mwhere[4];                       /* the same for the master */
uint32_t kn_bus_mfx_cy;                                   /* a post master insert's cycles inside fx_render_stereo's timing */

#ifndef OP1_HOST
#define MASTER_FX_PTR (*(void *volatile *)0x01AAAD68)        /* the master (stereo) FX object */
#define MASTER_FX_ON  (*(volatile uint8_t *)0x01AAAC40)
#define FX_PTR(pos)  (((void *volatile *)0x01AAAD60)[pos])  /* the mono FX object (synth, drum) */
#define FX_SLOT(pos) (((volatile int32_t *)0x01AAAC0C)[pos]) /* the slot Core has built for */
#define FX_ON(pos, s) (((volatile uint8_t *)0x01AAAC20)[(pos) * 16 + (s)])   /* synth 0x01AAAC20, drum 0x01AAAC30 */
#else
void *kn_bus_host_fx[2]; int32_t kn_bus_host_slot[2]; uint8_t kn_bus_host_on[2][8];
void *kn_bus_host_mfx; uint8_t kn_bus_host_mon;
#define MASTER_FX_PTR (kn_bus_host_mfx)
#define MASTER_FX_ON  (kn_bus_host_mon)
#define FX_PTR(pos)  (kn_bus_host_fx[pos])
#define FX_SLOT(pos) (kn_bus_host_slot[pos])
#define FX_ON(pos, s) (kn_bus_host_on[pos][s])
#endif
/* whether core_block_process renders the mono FX after the high-pass this block: the object pointer and the slot's
 * FX-on byte (synth 0xFFA02A3C..0xFFA02A52, drum 0xFFA02618..0xFFA0262E) */
static inline int fx_due(int pos)
{
    const int32_t s = FX_SLOT(pos);
    return FX_PTR(pos) && (uint32_t)s < 8u && FX_ON(pos, s);
}
void op1_bus_post(int pos, int post_on) { if ((unsigned)pos < 3) h.post[pos] = (uint8_t)(post_on != 0); }

int op1_bus_insert(op1_bus_insert_fn fn)
{
    if (fn && h.insert && h.insert != fn) return -1;
    h.insert = fn;
    return 0;
}
int op1_bus_insert_on(void) { return h.insert != 0; }
void op1_bus_gate(const volatile uint8_t *ui, const volatile uint8_t *au) { h.gate_au = au; h.gate_ui = ui; }
/* whether the insert wants pos this block (no gate: always) */
static inline int awake(int pos) { const volatile uint8_t *u = h.gate_ui; return !u || u[pos] | h.gate_au[pos]; }

kn_audio_text void op1_bus_mod_set(int src, int pos, const int16_t *mod)
{
    if ((unsigned)src >= OP1_BUS_NSRC || (unsigned)pos > OP1_BUS_ALL) return;
    for (int p = 0; p < 3; p++) {
        if (pos != OP1_BUS_ALL && p != pos) continue;
        for (int k = 0; k < OP1_BUS_NMOD; k++) mods[src][p][k] = mod[k];
        stamp[src][p] = BLOCKS(); seen[src][p] = 1;
    }
    if (src == OP1_BUS_SRC_MASTER) {                       /* the tape strips that follow it (screens/usbtrack.c) */
        extern int16_t kn_tape_mod[OP1_BUS_NMOD]; extern volatile uint8_t kn_tape_mod_fresh;
        for (int k = 0; k < OP1_BUS_NMOD; k++) kn_tape_mod[k] = mod[k];
        kn_tape_mod_fresh = 3;
    }
}

/* kn_foreign.h's pre-FX taps: after a PRE insert (never a POST one), before R246's FX. tap_n is the only word read when
 * none is registered */
volatile uint32_t kn_tap_calls;                            /* emulator checks: blocks the taps ran */
int kn_tap_add(int point, kn_tap_fn fn)
{
    if (point != KN_TAP_PRE_FX || !fn || h.tap_n >= KN_TAP_MAX) return -1;
    taps[h.tap_n] = fn;
    h.tap_n = h.tap_n + 1;                                     /* after the pointer: the audio thread never sees a 0 */
    return 0;
}
static __attribute__((noinline)) kn_audio_text void tap_run(int pos, int16_t *bus)
{
    const uint32_t t = op1_cycles(), n = h.tap_n;
    for (uint32_t i = 0; i < n; i++) taps[i](pos, bus);
    sm_cy[SMC_FX] += op1_cycles() - t;
    kn_tap_calls++;
}
static kn_audio_text void run(int pos, int16_t *bus, int16_t *r, int where)
{
    const op1_bus_insert_fn fn = h.insert;
    const uint16_t blk = (uint16_t)(BLOCKS() + 1);
    if (ran_at[pos] == blk) return;                        /* once a block: an insert that moved post runs there next block */
    ran_at[pos] = blk;
    ml_bus_tick();                                         /* the master LFO's strip targets (screens/mlfo.c) */
    int32_t sum[OP1_BUS_NMOD];
    for (int k = 0; k < OP1_BUS_NMOD; k++) sum[k] = 0;
    const uint16_t now = BLOCKS();
    for (int s = 0; s < OP1_BUS_NSRC; s++) {
        if (!seen[s][pos] || (uint16_t)(now - stamp[s][pos]) > 2) continue;   /* stale: the source stopped */
        for (int k = 0; k < OP1_BUS_NMOD; k++) sum[k] += mods[s][pos][k];
    }
    int16_t m[OP1_BUS_NMOD];
    for (int k = 0; k < OP1_BUS_NMOD; k++) m[k] = (int16_t)(sum[k] > 32767 ? 32767 : sum[k] < -32767 ? -32767 : sum[k]);
    const uint32_t t = op1_cycles();
    fn(pos, bus, r, m);
    const uint32_t d = op1_cycles() - t;
    sm_cy[SMC_FX] += d;
    if (pos == OP1_BUS_MASTER && where == 1) kn_bus_mfx_cy = d;   /* fx_render_stereo takes it off its own (dispatcher.c) */
    kn_bus_calls++;
    (pos == OP1_BUS_MASTER ? kn_bus_mwhere : kn_bus_where)[where]++;
    if (d > kn_bus_cy_max) kn_bus_cy_max = d;
}
/* a PRE insert's block, then the taps (out of line: kn_bus_run stays frameless) */
static __attribute__((noinline)) kn_audio_text void pre_run(int pos, int16_t *bus)
{
    run(pos, bus, 0, 0);
    if (h.tap_n) tap_run(pos, bus);
}
/* before the FX (kn_input_bus, after the high-pass): a PRE insert, then kn_foreign.h's pre-FX taps, so the taps see the
 * bus after a PRE strip. A POST strip runs after R246's FX (kn_bus_post_site / kn_bus_after_fx): the taps see the bus
 * without it. Idle (no insert, a POST one or the gate asleep) and no tap: a few loads and branches, no frame (both
 * calls are tail calls). */
kn_audio_text void kn_bus_run(int pos, int16_t *bus)
{
    if (h.insert && !h.post[pos] && awake(pos)) { pre_run(pos, bus); return; }
    if (h.tap_n) tap_run(pos, bus);
}
/* after the gap declick at the end of the input bus hook: a post insert runs here when R246 will not render the FX,
 * else it is armed for the FX's render (kn_bus_after_fx). An arm left from the block before means the FX did not
 * render after all (switched off between the test and the render): counted, the block went unprocessed. */
kn_audio_text void kn_bus_post_site(int pos, int16_t *bus)
{
    if (h.armed) { h.armed = 0; kn_bus_where[3]++; }
    if (!h.insert || !h.post[pos] || !awake(pos)) return;
    if (fx_due(pos)) h.armed = (uint8_t)(pos + 1);
    else run(pos, bus, 0, 2);
}
/* the end of every mono FX render (kennel/kn_declick.c kn_dc_mono, after the declick) */
kn_audio_text void kn_bus_after_fx(int16_t *bus)
{
    const int a = h.armed;
    if (!a) return;
#ifndef OP1_HOST
    if (bus != (int16_t *)0xFF800BB4) return;              /* only R246's instrument bus (mix_bus), never another buffer */
#endif
    h.armed = 0;
    if (h.insert && h.post[a - 1]) run(a - 1, bus, 0, 1);
}
/* the master (L, R: out_l16 / out_r16): from the output stage after the master EQ, where R246 tests the master FX
 * pointer (kennel/kn_declick.c kn_mfx_site, the L1 entry 0xFFA01202): pre FX runs before the gap declick; post runs
 * after it when R246 will not render the master FX (off, or no object), else it is armed for the render's end
 * (screens/fxroute.c fr_route, after the declick, before the metronome's click) */
kn_audio_text void kn_bus_master_pre(int16_t *l, int16_t *r)
{
    if (h.marmed) { h.marmed = 0; kn_bus_mwhere[3]++; }
    if (h.insert && !h.post[OP1_BUS_MASTER] && awake(OP1_BUS_MASTER)) run(OP1_BUS_MASTER, l, r, 0);
}
kn_audio_text void kn_bus_master_post_site(int16_t *l, int16_t *r)
{
    if (!h.insert || !h.post[OP1_BUS_MASTER] || !awake(OP1_BUS_MASTER)) return;
    if (MASTER_FX_ON && MASTER_FX_PTR) h.marmed = 1;
    else run(OP1_BUS_MASTER, l, r, 2);
}
kn_audio_text void kn_bus_master_after_fx(int16_t *l, int16_t *r)
{
    if (!h.marmed) return;
    h.marmed = 0;
    if (h.insert && h.post[OP1_BUS_MASTER]) run(OP1_BUS_MASTER, l, r, 1);
}
