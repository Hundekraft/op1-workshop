/* USB MIDI out after Scale and Chord (owner 2026-11-17): a synth key played on the keyboard sends what the synth plays
 * from it, the notes at the end of the note pipeline, instead of the raw key.
 *
 * R246 (VoiceCtl key_down 0x01A85750, synth bank): the pipeline call 0x01A85828 (note_pipe_on) first, then the shared
 * tail tests send_midi and CALLs midi_note_on_out 0x019E2E64 (note, velocity) at 0x01A857B0 with the raw note; key_up
 * 0x01A85840 the same with midi_note_off_out 0x019E2DC0 at 0x01A85880. Both CALLs come here (hook.S hook_mostockon /
 * hook_mostockoff), drum and the other banks included.
 *
 * Which path a key takes is decided once, at its note on in note_pipe_on: the pipeline path when the note comes from
 * the keyboard (op1_note_source() KEYS), has send_midi set and Scale or Chord is on (op1_harmony_context); otherwise
 * the stock path, byte for byte as before. The note off follows the note on's path (routed[] per key), so switching
 * Scale or Chord while a key is held can't strand a note.
 *
 * Pipeline path: note_pipe_on marks its copy of the record (pad[0..2], KN_MO_MARK0..2; every other note gets them
 * zeroed, since R246 leaves them uninitialised); Scale and Chord copy whole records,
 * so every note they emit from that key carries the mark, strummed notes from chord's tick too. The sink (past the last
 * stage, kn_features.c) clears the mark, hands VoiceCtl send_midi 0 (R246's held list then leaves these notes' MIDI to
 * us: its octave step and voice resets skip them) and sends the note with R246's own midi_note_on_out / _off_out, so
 * the bytes, the channel, the USB gate and the per-note flags 0x01AAFD60 (all-notes-off 0x019E2F84) stay R246's.
 * out_n[] counts the routed notes holding each out note: two keys on one note send one note on and the last off ends
 * it. The stock on drops a note whose flag is set and the stock off a note whose flag is clear, so an all-notes-off in
 * between leaves nothing hanging. Guards: a voice reset (kn_notes_reset) and the release of the last routed key end
 * every out note still counted.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../op1_feature.h"
#include "../op1_feature_midi.h"
#include "kn_midiout.h"

#ifdef OP1_HOST
extern void host_midi_note_on_out(int note, int velocity);   /* the test's R246 midi_note_on_out / _off_out */
extern void host_midi_note_off_out(int note);
extern int host_mo_harmony;                                  /* Scale or Chord on */
#define STOCK_ON  host_midi_note_on_out
#define STOCK_OFF host_midi_note_off_out
#define XFORM()   host_mo_harmony
#define IRQ_OFF() 0u
#define IRQ_ON(m) ((void)(m))
#else
#define STOCK_ON  ((void (*)(int, int))0x019E2E64)            /* midi_note_on_out(note, velocity) */
#define STOCK_OFF ((void (*)(int))0x019E2DC0)                 /* midi_note_off_out(note) */
static int xform(void) { int32_t h[4]; op1_harmony_context(h); return h[2] || h[3]; }
#define XFORM()   xform()
static inline uint32_t irq_off(void) { uint32_t m; __asm__ volatile ("cli %0;" : "=d"(m) : : "memory"); return m; }
static inline void irq_on(uint32_t m) { __asm__ volatile ("sti %0;" : : "d"(m) : "memory"); }
#define IRQ_OFF() irq_off()
#define IRQ_ON(m) irq_on(m)
#endif

static uint8_t routed[128];      /* per key (the raw note): note ons taken down the pipeline path, not yet off */
static uint8_t skip_on[128];     /* per key: the stock tail's raw note on to drop (set after the pipeline ran) */
static uint8_t skip_off[128];
static uint8_t out_n[128];       /* per out note: routed pipeline notes holding it */
static int n_routed;             /* keys with routed[] != 0 */

int kn_mo_route_on(const op1_note *n, op1_note *copy)
{
    int k = n->note;
    *copy = *n;
    copy->pad[0] = copy->pad[1] = copy->pad[2] = 0;
    if (k < 0 || k > 127 || !n->send_midi || OP1_SRC_KIND(op1_note_source()) != OP1_SRC_KEYS || !XFORM()) return 0;
    copy->pad[0] = KN_MO_MARK0; copy->pad[1] = KN_MO_MARK1; copy->pad[2] = KN_MO_MARK2;
    uint32_t m = IRQ_OFF();
    if (!routed[k]++) n_routed++;
    IRQ_ON(m);
    return 1;
}
void kn_mo_routed_on(int key) { if (key >= 0 && key < 128 && skip_on[key] < 255) skip_on[key]++; }

int kn_mo_route_off(const op1_note *n, op1_note *copy)
{
    int k = n->note;
    *copy = *n;
    copy->pad[0] = copy->pad[1] = copy->pad[2] = 0;
    if (k < 0 || k > 127 || !routed[k]) return 0;
    copy->pad[0] = KN_MO_MARK0; copy->pad[1] = KN_MO_MARK1; copy->pad[2] = KN_MO_MARK2;
    uint32_t m = IRQ_OFF();
    if (!--routed[k]) n_routed--;
    if (n->send_midi && skip_off[k] < 255) skip_off[k]++;   /* the stock tail only runs with send_midi set */
    IRQ_ON(m);
    return 1;
}

static void flush(void)          /* every counted out note off */
{
    for (int o = 0; o < 128; o++) {
        uint32_t m = IRQ_OFF();
        int was = out_n[o];
        out_n[o] = 0;
        if (was) STOCK_OFF(o);
        IRQ_ON(m);
    }
}
void kn_mo_routed_off(int key)   /* after the pipeline's note off: the last routed key gone, nothing may sound */
{
    (void)key;
    if (!n_routed) {
        int any = 0;
        for (int o = 0; o < 128; o++) any |= out_n[o];
        if (any) flush();
    }
}

/* the sink, both directions: n is the pipeline's note, VoiceCtl gets *vc */
int kn_mo_sink(const op1_note *n, op1_note *vc, int on)
{
    if (!KN_MO_MARKED(n)) return 0;
    *vc = *n;
    vc->pad[0] = vc->pad[1] = vc->pad[2] = 0;
    vc->send_midi = 0;
    int o = n->note;
    if (o < 0 || o > 127) return 1;
    uint32_t m = IRQ_OFF();
    if (on) {
        int v = n->velocity < 1 ? 1 : n->velocity > 127 ? 127 : n->velocity;
        if (out_n[o] < 255) out_n[o]++;
        STOCK_ON(o, v);                                      /* R246 drops it while the note's flag is set */
    } else if (out_n[o] && !--out_n[o]) STOCK_OFF(o);
    IRQ_ON(m);
    return 1;
}

/* hook.S: VoiceCtl key_down's / key_up's CALL midi_note_on_out / _off_out (every bank) */
void kn_mo_stock_on(int note, int velocity)
{
    if (note >= 0 && note < 128 && skip_on[note]) {
        uint32_t m = IRQ_OFF();
        int s = skip_on[note];
        if (s) skip_on[note] = (uint8_t)(s - 1);
        IRQ_ON(m);
        if (s) return;
    }
    STOCK_ON(note, velocity);
}
void kn_mo_stock_off(int note)
{
    if (note >= 0 && note < 128 && skip_off[note]) {
        uint32_t m = IRQ_OFF();
        int s = skip_off[note];
        if (s) skip_off[note] = (uint8_t)(s - 1);
        IRQ_ON(m);
        if (s) return;
    }
    STOCK_OFF(note);
}

void kn_mo_reset(void)           /* a stock voice reset (kn_notes_reset): forget the keys, end the out notes */
{
    uint32_t m = IRQ_OFF();
    for (int k = 0; k < 128; k++) routed[k] = skip_on[k] = skip_off[k] = 0;
    n_routed = 0;
    IRQ_ON(m);
    flush();
}

#ifndef OP1_HOST
/* hook.S hook_morelease: VoiceCtl's MIDI release of its held list (0x01A8624C: offs for its send_midi notes, list
 * cleared, no voice reset; drum key handling 0x01977EE8, line/mic record key up 0x019DEE74, 0x019AC44A after a voice
 * reset). Our notes are off its list (send_midi 0), so end them here too, then R246's. */
void kn_mo_release_stock(void);
void kn_mo_release(void) { kn_mo_reset(); kn_mo_release_stock(); }
#endif

int kn_mo_out_count(int note) { return note >= 0 && note < 128 ? out_n[note] : 0; }
