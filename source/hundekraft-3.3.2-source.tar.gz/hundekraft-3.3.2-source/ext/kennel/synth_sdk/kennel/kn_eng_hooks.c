/*
 * Engine hooks for an engine with its own pages (op1_plugin.h op1_engine_ext2_t, 2026-11-14; dx): its input on T1, its
 * own T2 page and its own T4 page, the T4 page itself (screen 0x1C) with the stock LFO held off, the main-loop service,
 * and op1_engine_word_set. The decisions are in kn_eng_hooks.h (harness/eng_hooks_test.c); this file is the R246 side.
 * Callers: kn_eng_input from kn_features_input (kennel/kn_core.c, KeyHandler: knob_event_hook / key_event_hook);
 * kn_eng_service and kn_eng_lfo_hold from kn_core_service and kn_tape.c (main loop); kn_t4_screen_for from R246's synth
 * T4 page choice (hook.S, CALL at 0x01A50560); kn_lfo_bypass from R246's LFO-off overlay (DATA_PATCHES 0x019106F8,
 * Gfx); kn_eng_t4_sync from kn_screens_update (Gfx: the T4 page follows the sound); kn_eng_t4_ctor / _load
 * from dispatcher.c's screen set-up next to kn_input_ctor / kn_input_load.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "kn_eng_hooks.h"
#include "../op1_feature_sound.h"
#include "kn_input.h"                                               /* kn_t2_page_visible */

const op1_engine_ext2_t *kn_eng_ext2[OP1_SLOTS];                    /* by order (kn_boot.c), 0 without the hooks */
uint8_t kn_eng_hook[OP1_SLOTS];                                     /* KN_EH_* */
uint8_t kn_eng_own_lfo[OP1_SLOTS];                                  /* a foreign engine's own LFO (kennel/kn_foreign.h KN_FE_OWN_LFO) */
static void (*svc[OP1_SLOTS])(int, int32_t);

#define PLAY_MODE   (*(volatile uint32_t *)0xFF801038)
#define SLOT        (*(volatile int *)0xFF8016D4 & 7)
#define TYPE(s)     (*(volatile uint32_t *)(0xFF8016E4 + 4 * (s)))
#define SCREEN      (*(volatile int *)0x018B65C8)
#define DRUM_PAGE   (*(volatile int *)0x01DE4C40 == 1)
#define TABLE       ((void **)0x01DF4E54)
#define ITER_SCREEN 0x14
#define MODE        (*(volatile int *)0xFF907D58)                    /* ModeSwitcher: active mode, synth 0 */
#define SYNTH_PAGE  (*(volatile int *)0x01B4EE88)                    /* the synth controller's page, T4 = 3 (ui.md) */
#define LFO_TYPE(s) (((volatile int *)0xFF801384)[s])               /* synth LFO type per slot */
#define REFRESH     (*(volatile uint8_t *)0x01DF4E40)                /* screens_update's refresh pending byte */
#define LFO_ON(s)   (((volatile uint8_t *)0x01AAAC28)[s])           /* synth LFO on, per slot (audio-graph.md) */
#define LFO_SET     ((void (*)(int, int))0x019672B8)                 /* core_set_synth_lfo_on(slot, on): the flag only */
#define FOR_LFO     ((int (*)(int))0x01A3C01C)                       /* ScreenId::for_lfo(type) */
#define PATCH(s)    ((void *)(0x01DDD7E8 + (s) * 0x38))
#define SET_KNOBS   ((void (*)(void *, const int16_t *))0x01A00D14)  /* patch::set_knobs: JSON written, patch changed */
int kn_patch_lfo_active(int slot);                                  /* kennel/kn_lfo_rec.c */

void kn_eng_hooks_set(int n, uint8_t hooks, const op1_engine_ext2_t *e)   /* kn_boot.c: a loaded synth's order */
{
    if (n <= 0 || n >= OP1_SLOTS) return;
    kn_eng_hook[n] = e ? hooks : 0;
    kn_eng_ext2[n] = hooks && e ? e : 0;
    svc[n] = (hooks & KN_EH_SERVICE) && e ? e->service : 0;
}

static int sound_of(int slot)                                       /* the engine order of a synth slot's sound, or 0 */
{
    if (TYPE(slot) != 14) return 0;
    const int n = op1_synth_knobs(slot)[4] - OP1_ENGINE_MAGIC;
    return n > 0 && n < OP1_SLOTS && op1_sound_engine(n) ? n : 0;
}
static int current(unsigned hook)                                   /* the current synth sound's engine with `hook` */
{
    if (PLAY_MODE != 0) return 0;
    const int n = sound_of(SLOT);
    return n && (kn_eng_hook[n] & hook) && kn_eng_ext2[n] ? n : 0;
}

/* ---- T4: the engine's page object, as kn_input.c builds the T2 pages ---- */
static uint32_t *t4obj[OP1_SLOTS];
static void *t4_prior;
void *kn_alloc(uint32_t);
static int t4_ours(const void *p)
{
    if (!p) return 0;
    for (int n = 1; n < OP1_SLOTS; n++) if (t4obj[n] && (const void *)t4obj[n] == p) return 1;
    return 0;
}
void kn_eng_t4_ctor(void)
{
    for (int n = 1; n < OP1_SLOTS; n++) if ((kn_eng_hook[n] & KN_EH_T4) && kn_eng_ext2[n] && kn_eng_ext2[n]->t4) {
        uint32_t *s = kn_alloc(128), *v = kn_alloc(40);
        if (!s || !v) continue;
        void *save = TABLE[KN_T4_SCREEN];                               /* the ctor registers itself: put the entry back */
        ((void *(*)(void *, int, const char *))0x01A3BAB0)(s, KN_T4_SCREEN, "usbout.svg");
        TABLE[KN_T4_SCREEN] = save;
        for (int i = 0; i < 10; i++) v[i] = ((const uint32_t *)0x019103FC)[i];   /* the iter screen's vtable */
        v[7] = (uint32_t)kn_eng_ext2[n]->t4->update; v[9] = (uint32_t)kn_eng_ext2[n]->t4->init; s[3] = (uint32_t)v;
        t4obj[n] = s;
    }
}
void kn_eng_t4_load(void)
{
    for (int n = 1; n < OP1_SLOTS; n++) if (t4obj[n]) {
        uint32_t *s = t4obj[n];
        s[0] = (uint32_t)((void *(*)(void *))0x01A503D8)((void *)s[2]);   /* the (empty) SVG */
        if (s[0]) kn_eng_ext2[n]->t4->init(s); else t4obj[n] = 0;
    }
}
static void *t4_want(void) { const int n = current(KN_EH_T4); return n ? t4obj[n] : 0; }
/* R246's synth T4 page choice (the CALL ScreenId::for_lfo at 0x01A50560, KeyHandler): the engine's page on 0x1C, else
 * as before (case 4 reaches lfo_screen_select, the quad LFO) */
int kn_t4_screen_for(int type)
{
    void *want = t4_want();
    kn_t4_swap(&TABLE[KN_T4_SCREEN], &t4_prior, want, t4_ours);
    return want ? KN_T4_SCREEN : FOR_LFO(type);
}
/* every frame (Gfx, kn_screens_update, before the frame copies the table and R246's screens_update pops its requests):
 * the synth T4 page follows the sound. A change to or from a T4-page engine redoes the T4 key's choice and switches the
 * screen id as screens_update does on a request (0x01A3BB58: the id, then refresh pending); a screen request from here
 * could meet KeyHandler's push (Queue.h "!pushing_" panics). One engine's page to another's: the 0x1C swap alone. */
void kn_eng_t4_sync(void)
{
    const int scr = SCREEN;
    const int t4 = MODE == 0 && SYNTH_PAGE == 3 && scr >= 0x18 && scr <= 0x1E;
    const int shown = scr == KN_T4_SCREEN && t4_ours(TABLE[KN_T4_SCREEN]);
    void *want = t4_want();
    if (kn_t4_follow(t4, shown, want != 0)) {
        const int id = kn_t4_screen_for(LFO_TYPE(SLOT));
        if (id != scr) { SCREEN = id; REFRESH = 1; }
    } else if (shown) kn_t4_swap(&TABLE[KN_T4_SCREEN], &t4_prior, want, t4_ours);
}
/* lfo_bypass's "is it up" (make_firmware DATA_PATCHES 0x019106F8, R0 = the overlay object, R1 = the screen id; Gfx):
 * no "LFO OFF" on an engine's own T4 page (kn_lfo_overlay_skip), else R246's check, 0x019C9780 */
int kn_lfo_bypass(void *self, int id)
{
    if (kn_lfo_overlay_skip(id, t4_ours(TABLE[KN_T4_SCREEN]))) return 0;
    return ((int (*)(void *, int))0x019C9780)(self, id);
}
static int t4_visible(void)
{
    const int n = current(KN_EH_T4);
    return n && SCREEN == KN_T4_SCREEN && t4obj[n] && TABLE[KN_T4_SCREEN] == (void *)t4obj[n] ? n : 0;
}

/* ---- input (KeyHandler) ---- */
static kn_eng_keys keys;
int kn_eng_input(int type, int code, int pressed, int delta)
{
    kn_eng_ev e;
    const int idx = kn_eng_key_idx(type, code);
    if (idx >= 0 && !pressed) {                                     /* an up goes where its down went */
        int pg = 0;
        const int m = kn_eng_up_owner(&keys, idx, &pg);
        if (!m) return 0;
        const op1_engine_ext2_t *x = kn_eng_ext2[m];
        if (x && (kn_eng_hook[m] & KN_EH_INPUT) && x->input && kn_eng_event(pg, type, code, 0, 0, &e))
            x->input(e.page, e.ev, e.a, e.b);
        return 1;
    }
    int n = t4_visible(), page = OP1_ENG_T4;
    if (!n) { n = kn_t2_page_visible(); page = OP1_ENG_T2; }
    if (!n && SCREEN == ITER_SCREEN && !DRUM_PAGE) { n = current(KN_EH_INPUT); page = OP1_ENG_T1; }
    if (!n || !kn_eng_event(page, type, code, pressed, delta, &e)) return 0;
    const op1_engine_ext2_t *x = kn_eng_ext2[n];
    const int took = (x && (kn_eng_hook[n] & KN_EH_INPUT) && x->input ? x->input(e.page, e.ev, e.a, e.b) : 0) || e.take;
    kn_eng_down(&keys, idx, n, page, took);
    return took;
}

/* ---- main loop ---- */
void kn_eng_service(int ev, int32_t arg) { kn_eng_service_all(svc, kn_eng_hook, OP1_SLOTS, ev, arg); }
void kn_eng_disk_done(void) { kn_eng_service(OP1_EV_DISK, 0); }   /* kn_tape.c: disk mode ended */
static uint8_t lfo_held[8];
void kn_eng_lfo_hold(void)                                          /* every pass: op1_plugin.h t4_page's LFO hold */
{
    for (int s = 0; s < 8; s++) {
        const int n = sound_of(s), owned = n && ((kn_eng_hook[n] & KN_EH_T4) || kn_eng_own_lfo[n]);
        if (!owned && !lfo_held[s]) continue;
        const int w = kn_lfo_hold_step(owned, LFO_ON(s) != 0, &lfo_held[s], owned ? -1 : kn_patch_lfo_active(s));
        if (w >= 0) LFO_SET(s, w);
    }
}

/* ---- op1_engine_word_set (op1_plugin.h; UI thread) ---- */
int op1_engine_word_set(const op1_engine_t *e, int k, int v)
{
    const int slot = SLOT, n = sound_of(slot);
    if (!e || !kn_eng_word_ok(k, v) || !n || op1_sound_engine(n) != e) return 0;
    int16_t *w = (int16_t *)op1_synth_knobs(slot);
    w[k] = (int16_t)v;
    SET_KNOBS(PATCH(slot), w);
    return 1;
}
