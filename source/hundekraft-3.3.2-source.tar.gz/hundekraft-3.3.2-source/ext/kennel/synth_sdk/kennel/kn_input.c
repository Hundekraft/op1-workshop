/* Selected-input producer at R246's post-decimator high-pass entry. No encrypted patch.
 * The assembly entry passes the caller's local has-input flag; only the verified
 * PmSynth call site runs input engines; the input observer (line clock) may clear the flag at all three verified
 * core_block_process call sites. Input source/mode and sampler taps stay intact.
 * GPL-3.0-or-later with OP-1 firmware permission. */
#include "kn_input.h"
#include "../kn_mem.h"                 /* kn_audio_text */
#include "../op1_synth.h"
#include "kn_src.h"                              /* page 7's named sources (test build) */
#include "../op1_feature.h"
#include "../op1_feature_sound.h"
#include "kn_input_gain.h"
#include "kn_input_ear.h"
#include "kn_bus.h"
#include "kn_foreign.h"                           /* kn_skip_dry */
const op1_input_engine_t *op1_input_engines[OP1_SLOTS];
static const op1_input_engine_t *active kn_hot;
static int active_slot=-1;
static uint32_t active_rate,active_source,active_mode;
static uint32_t rate=22050;
static uint32_t previous_clock kn_hot, clock_sum kn_hot, clock_count kn_hot;   /* every block (kn_mem.h kn_hot) */
static int block_touched kn_hot;
/* INPUT GAIN per source (0 mic .. 3 USB), dB; see kn_input_service */
static volatile int8_t gain_db[4];
static volatile uint8_t gain_dirty;
static uint8_t gain_loaded;
static int gain_acc;
#define PLAY_MODE (*(volatile uint32_t *)0xFF801038)
#define SLOT (*(volatile uint32_t *)0xFF8016D4&7)
#define TYPE (*(volatile uint32_t *)(0xFF8016E4+4*SLOT))
#define INPUT_MODE (*(volatile uint32_t *)0xFF8010B0)
#define INPUT_SOURCE (*(volatile uint32_t *)0xFF8010B4)
#define SCREEN (*(volatile int *)0x018B65C8)
#define TABLE ((void **)0x01DF4E54)
kn_audio_text static int current(void){
 if(PLAY_MODE!=0||TYPE!=14)return 0;
 int n=op1_synth_knobs(SLOT)[4]-OP1_ENGINE_MAGIC;
 return n>0&&n<OP1_SLOTS&&op1_input_engines[n]&&op1_sound_engine(n)?n:0;
}
kn_audio_text void kn_input_clock(uint32_t now){
 uint32_t d=now-previous_clock;previous_clock=now;block_touched=0;
 /* Derive the two supported rates from the actual 400MHz callback cadence,
  * ignoring startup pauses. Change only after 16 consistent valid periods. */
 if(d<400000u||d>1600000u){clock_sum=clock_count=0;return;}
 clock_sum+=d;
 if(++clock_count==16){rate=clock_sum>13931968u?22050:44100;clock_sum=clock_count=0;}
}
/* CPU cycles in one audio block at the measured cadence: 64 frames at 44.1 kHz on the unit (1.451 ms), twice that
 * at the emulator's old 22.05 kHz link (OP1EMU_SPORT_HZ=22050) (docs: OP1-Emulator docs/emu-audio-clock-2026-10-21.md). kennel/kn_shed.c */
kn_audio_text uint32_t kn_audio_block_cycles(void){return rate==44100?580499u:1160997u;}
extern void kn_input_highpass_stock(void);
extern void kn_engine_sum(uint32_t caller);   /* dispatcher.c: op1_engine_sum_t block on the synth bus */
/* Input observer (op1_input.h op1_input_observe, line clock). core_bus_highpass has three callers, all inside
 * core_block_process (0xFFA017EC), which moves SP only in its prologue and epilogue: synth (return 0xFFA02896), drum
 * (0xFFA02464) and game (0xFFA01EC2) pass the same has-input local at SP+0x34 (read at 0xFFA020C2 and 0xFFA0211A
 * for the dry monitor and the input added after the output stage). Any other caller is not observed. */
static volatile op1_input_observer_fn observer kn_hot;
volatile uint8_t kn_skip_dry kn_hot;   /* kn_foreign.h: the engine's sum block left this block's dry input out */
int op1_input_observe(op1_input_observer_fn fn){
 if(fn&&observer&&observer!=fn)return -1;
 observer=fn;return 0;
}
#define LINE_JACK (*(volatile uint8_t *)0x018B621C)
#define TAPE_STATE (*(volatile uint32_t *)0x018C17D4)
#define TAPE_RUN (*(volatile uint32_t *)0xFF802960)
#define TAPE_TRACK (*(volatile uint32_t *)0xFF802964)
int fr_ear_feed(int16_t *out,unsigned skip);
kn_audio_text static int observe(uint32_t *monitor,uint32_t caller){
 op1_input_observer_fn fn=observer;
 if(!fn||(caller!=0xFFA02896u&&caller!=0xFFA02464u&&caller!=0xFFA01EC2u))return 0;
 const int16_t *in=*monitor?(const int16_t *)0xFF800CB4:0;
 return fn(in,(int)INPUT_SOURCE,LINE_JACK!=0,rate);
}
/* The bus insert (op1_bus.h, kennel/kn_bus.c) runs last on each instrument's bus: after the high-pass and an input
 * engine, and after the engine's voice-sum block (kn_engine_sum first, then kn_bus_run), before R246's FX and the
 * FX switch declick (kn_input_bus). Synth (0xFFA02896) pos 0, drum (0xFFA02464) pos 1; never in game mode. */
#define BUS ((int16_t *)0xFF800BB4)
kn_audio_text static void input_bus(uint32_t *monitor,uint32_t caller){
 int mute=observe(monitor,caller);
 if(caller!=0xFFA02896u){kn_input_highpass_stock();if(mute)*monitor=0;if(caller==0xFFA02464u)kn_bus_run(1,BUS);return;}
 int n=current();
 /* synth bus, not an input engine: the high-pass, then the sound's voice-sum block if its engine has one (dispatcher.c) */
 if(!n){kn_input_highpass_stock();kn_engine_sum(caller);if(mute||kn_skip_dry)*monitor=0;kn_skip_dry=0;kn_bus_run(0,BUS);return;}
 const op1_input_engine_t *d=op1_input_engines[n];int slot=(int)SLOT;
 if(d!=active||slot!=active_slot||active_rate!=rate||active_source!=INPUT_SOURCE||active_mode!=INPUT_MODE){if(active)active->reset(-1,rate);active=d;active_slot=slot;active_rate=rate;active_source=INPUT_SOURCE;active_mode=INPUT_MODE;d->reset(slot,rate);}
 block_touched=1;
 int16_t words[8];for(int k=0;k<8;k++)words[k]=op1_synth_knobs(slot)[k];
 /* By R246's input mode (kn_input_ear.h): the input block, the tape's pre-fader mix in Ear (mode 1; R246's own Ear
  * signal only exists after the output stage, in mix_bus, and contains this engine), or silence. */
 static const int16_t silence[64];
 static int16_t ear[64];
 const int16_t *input=silence;
 const int feed=kn_input_feed(INPUT_MODE,*monitor!=0,mute);
 if(feed==KN_FEED_INPUT)input=(const int16_t *)0xFF800CB4;
 else if(feed==KN_FEED_TAPE){
  input=ear; /* the armed / recording track stays out (it would reach the engine again one tape pass later) */
  fr_ear_feed(ear,kn_ear_skip(TAPE_STATE,TAPE_RUN,TAPE_TRACK));
 }
 /* INPUT GAIN (T2, per source): 0 dB passes the input buffer itself, so the engine sees the same bytes */
 static int16_t gained[64];
 const int db=INPUT_SOURCE<4?gain_db[INPUT_SOURCE]:0; /* Ear (source 4): no trim, mic's isn't it */
 if(db&&input!=silence){kn_gain_apply(input,gained,64,db);input=gained;}
 uint32_t t=op1_cycles();
 d->process(input,(int16_t *)0xFF800BB4,words,rate);
 uint32_t elapsed=op1_cycles()-t;sm_cy[SMC_SYNTH]+=elapsed;kn_input_budget(n,elapsed);
 kd_src(KD_SRC(KD_K_SYN,n),elapsed); /* the input engine (test build: page 7) */
 *monitor=0; /* only the caller's two dry-monitor additions; input buffer unchanged */
 kn_bus_run(0,BUS);
}
void kn_dc_mono_gap(int pos,int16_t *bus); /* kennel/kn_declick.c: the FX switch declick when R246's swap skips the mono FX */
kn_audio_text void kn_input_bus(uint32_t *monitor,uint32_t caller){
 input_bus(monitor,caller);
 KD_T0(t0);
 kn_dc_mono_gap(caller==0xFFA02464u,(int16_t *)0xFF800BB4); /* drum position for the drum caller, else synth (synth, game) */
 KD_LEAF(KD_SRC_KN,t0);
 if(caller!=0xFFA01EC2u)kn_bus_post_site(caller==0xFFA02464u,BUS); /* a post-FX insert: here, or after the FX's render */
}
kn_audio_text void kn_input_end(void){if(!block_touched&&active){active->reset(-1,rate);active=0;active_slot=-1;active_rate=0;}}
/* INPUT GAIN: one trim per input source (mic, line, radio, USB), -12..+24 dB, settings "input.gain.mic" etc. (kennel
 * settings, not the sound: the gain matches the source). Read on the first main-loop pass, written there after a turn
 * (the KeyHandler thread only changes gain_db and marks it). The audio thread reads gain_db once a block. */
static const char *const gain_key[4]={"gain.mic","gain.line","gain.radio","gain.usb"};
int op1_input_gain_db(void){return INPUT_SOURCE<4?gain_db[INPUT_SOURCE]:0;}
void kn_input_service(void){
 if(!gain_loaded){gain_loaded=1;for(int i=0;i<4;i++)gain_db[i]=(int8_t)kn_gain_clamp((int)op1_setting_get("input",gain_key[i],0));}
 if(gain_dirty){uint8_t d=gain_dirty;gain_dirty&=(uint8_t)~d;for(int i=0;i<4;i++)if(d>>i&1)op1_setting_set("input",gain_key[i],gain_db[i]);}
 int n=current();if(n&&op1_input_engines[n]->service)op1_input_engines[n]->service();
}
/* An engine's own T2 page (kn_t2_page.h): an input engine's tuner or an own-envelope engine's page
 * (op1_engine_env_page_t), by order in kn_t2_pages (kn_boot.c). T2 objects are ordinary table entries, so the
 * shared-screen lifetime fix covers their drawing caches. Allocate only for installed providers, once at boot. */
const op1_screen_t *kn_t2_pages[OP1_SLOTS];
uint8_t kn_t2_swallow[OP1_SLOTS];
static uint32_t *objects[OP1_SLOTS];
static void *prior,*shown;
void *kn_alloc(uint32_t);
static int page_current(void){                   /* the current synth slot's engine, if it brings a T2 page */
 if(PLAY_MODE!=0||TYPE!=14)return 0;
 int n=op1_synth_knobs(SLOT)[4]-OP1_ENGINE_MAGIC;
 return n>0&&n<OP1_SLOTS&&kn_t2_pages[n]&&op1_sound_engine(n)?n:0;
}
void kn_input_ctor(void){
 for(int n=1;n<OP1_SLOTS;n++)if(kn_t2_pages[n]){
  uint32_t *s=kn_alloc(128),*v=kn_alloc(40);if(!s||!v)continue;
  void *save=TABLE[22];((void *(*)(void *,int,const char *))0x01A3BAB0)(s,22,"usbout.svg");TABLE[22]=save;
  for(int i=0;i<10;i++)v[i]=((const uint32_t *)0x019103FC)[i];
  v[7]=(uint32_t)kn_t2_pages[n]->update;v[9]=(uint32_t)kn_t2_pages[n]->init;s[3]=(uint32_t)v;
  objects[n]=s;
 }
}
void kn_input_load(void){for(int n=1;n<OP1_SLOTS;n++)if(objects[n]){
 uint32_t *s=objects[n];s[0]=(uint32_t)((void *(*)(void *))0x01A503D8)((void *)s[2]);
 if(s[0])kn_t2_pages[n]->init(s);else objects[n]=0;
}}
void kn_input_screen_sync(void){
 int n=page_current();
 kn_t2_sync(&TABLE[22],&shown,&prior,n?objects[n]:0);
}
static int page_visible(void){int n=page_current();return SCREEN==22&&n&&objects[n]&&TABLE[22]==objects[n]?n:0;}
int kn_t2_page_visible(void){return page_visible();}   /* kennel/kn_eng_hooks.c: the engine's T2 page is up -> its order */
int kn_input_tuner_visible(void){int n=page_visible();return n&&op1_input_engines[n];}
int kn_input_control(int type,int code,int down,int delta){
 (void)down;
 const int n=page_visible();
 const int input=n&&op1_input_engines[n];
 if(!kn_t2_takes(input,n&&kn_t2_swallow[n],type,code))return 0;   /* an own-envelope page without t2_swallow: R246's controller keeps them */
 if(input&&type==OP1_IN_KNOB&&code==KN_GAIN_KNOB&&gain_loaded&&INPUT_SOURCE<4){       /* blue turn: INPUT GAIN, 1 dB a detent (1024) */
  gain_acc+=delta;
  int steps=gain_acc/1024;                                       /* KeyHandler thread, not audio */
  if(steps){gain_acc-=steps*1024;const uint32_t so=INPUT_SOURCE&3;
   int g=kn_gain_clamp(gain_db[so]+steps);if(g!=gain_db[so]){gain_db[so]=(int8_t)g;gain_dirty|=(uint8_t)(1u<<so);}}
 }
 return 1;
}

int op1_input_tuner_active(void){return kn_input_tuner_visible();}
