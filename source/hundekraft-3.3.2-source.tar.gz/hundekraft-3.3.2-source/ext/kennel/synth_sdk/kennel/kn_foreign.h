/* Core services for an in-core loader of another plugin format (the bridge, ARCHITECTURE.md "Foreign plugin bridge:
 * core services"; phase 1 of the root project's bridge plan). Core-internal: none of this is in kn_exports.c, so no .knl
 * file can import it and nothing here is an ABI promise to plugin files.
 *
 * The boot stage (kennel/kn_boot.c): the bridge supplies the two weak hooks below. Without them (a core without the
 * bridge) nothing is counted, nothing runs, and the boot is the same as before.
 *   kn_foreign_need(&images)  from arena_need, every boot, before the heap-0 arena is taken: the arena bytes the
 *                             bridge's files will take (images, zero fills, its own tables, its inventory and log
 *                             lines: the core counts KN_ARENA_PER_FILE only for .knl / .op1p files), counted like a
 *                             .knl header's need (the bytes are ignored after a boot that did not reach the UI), and
 *                             how many image records (kn_images.h) it will add. images 0: the stage does not run.
 *   kn_foreign_boot(skipped)  after every .knl / .op1p file loaded and before the plugin-number map and the factory
 *                             rows are cleaned up and saved, so foreign registrations keep their numbers and rows.
 *                             skipped 1: the crash marker was found (every plugin file is skipped this boot): record
 *                             the files as skipped, load nothing. Runs on the boot thread (Clips::load's caller).
 * Inside kn_foreign_boot only:
 *   kn_foreign_begin()        starts one file's transaction (its memory and registrations). Arena memory taken
 *                             after it (kn_foreign_alloc, but also kn_alloc: inventory records and strings, settings
 *                             rows) goes back at rollback, so take what must outlive a refusal before begin.
 *   kn_foreign_alloc(n, al)   n bytes of the code arena (heap 0, or the fixed range), aligned to al (a power of two);
 *                             not cleared; 0 when the arena is full ("plugin memory full").
 *   kn_foreign_sync(lo, hi)   after writing code: D-cache flush, then I-cache invalidate over [lo, hi) (bcore does not
 *                             model the I-cache: only the unit shows this works).
 *   kn_foreign_add(d)         registers an engine or FX under its saved name now (op1_engines / op1_fxs, the number
 *                             map); 0 or why not. Its factory row is written at commit.
 *   kn_foreign_image(r)       the file's crash-map record (r->format KN_IMG_FOREIGN); -1 when the map is full.
 *   kn_foreign_commit()       the file is in: rows for its listed registrations.
 *   kn_foreign_rollback()     the file is out (opl_init failed, a bad struct): every registration since begin is
 *                             undone and its arena memory given back. Registrations of earlier files stay.
 *
 * Identity (owner D4, 2026-11-17): sounds find an engine or FX by the saved type name (patch_type_hook), so a saved
 * name never means two things. kn_foreign_add refuses a saved name that is already registered (kennel's own, a
 * built-in, another foreign file's): a foreign registration never replaces anything. A foreign engine whose name
 * kennel has is registered under another saved name (the bridge picks it). "One active per name" is the picker
 * list: kn_plugin_listed(fx, saved, 0) keeps a registered engine or FX out of the factory rows (the picker) while
 * sounds saved with it still open in it; kennel's own stays listed unless the bridge says otherwise.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_FOREIGN_H
#define KN_FOREIGN_H
#include <stdint.h>
#include "kn_images.h"
#include "../op1_plugin.h"                 /* op1_beat_t */

#define KN_IMG_FOREIGN 3                    /* kn_img_rec.format of a foreign file's image */

/* kn_foreign_desc.extra: what a foreign engine needs beyond the .knl flags */
#define KN_FE_NEUTRAL_ENV 1u                /* the stock envelope runs held neutral (fastest attack, full sustain, slowest
                                               release) for its voices, whatever the sound's T2 words say */
#define KN_FE_OWN_LFO     2u                /* the stock LFO is held off for its sounds (kn_eng_lfo_hold), as a T4-page
                                               engine's; the sound's "lfo_active" is never written */

typedef struct {
    uint8_t fx;                             /* 0 a synth engine, 1 an FX */
    uint8_t listed;                         /* 1: a factory row (the picker shows it); 0: loads saved sounds only */
    uint16_t extra;                         /* KN_FE_* (engines) */
    uint32_t flags;                         /* the .knl header flags the entry is laid out for (kn_load.h KN_FLAG_*):
                                               engines USES_SAMPLE, OWN_ENV, SUM, T2_PAGE, T2_SWALLOW, ENG_INPUT, T4_PAGE,
                                               ENG_SERVICE; FX STEREO; PAGE2 for page2. INPUT and COARSE are refused. */
    const char *saved;                      /* the saved type name: 1..15 of a-z 0-9 space _ + - */
    const void *entry;                      /* op1_engine_t (or the ext layouts the flags say) / op1_fx_t (stereo) */
    const void *screen;                     /* op1_screen_t for its T1 / FX page, or 0 */
    const char *svg;                        /* that screen's SVG, relative to content/display, or 0 */
    const int16_t *defaults;                /* 4 words 0..32767 (a new sound's) */
    const int16_t *page2;                   /* 3 words (words 5..7) with KN_FLAG_PAGE2, else 0 */
} kn_foreign_desc;

uint32_t kn_foreign_need(uint32_t *images) __attribute__((weak));
/* the push's allow-list (devupd du_path_ok, du_plugin_path): 1 for a path the bridge's files may be written to and
 * deleted at (its folder, one level). Weak: without a bridge no extra path is allowed. */
int kn_foreign_path_ok(const char *path) __attribute__((weak));
/* the bridge's files a firmware bundles beside the plugin files (content/<file>, one level): 1 for one the push may
 * delete (devupd du_plugin_path), so an unticked bundled file goes. Weak: without a bridge none. */
int kn_foreign_bundle_ok(const char *path) __attribute__((weak));
void kn_foreign_boot(int skipped) __attribute__((weak));
/* 1 when the bridge's file `name` (no extension) is on the device, pushed or bundled: the retired ports' clash rule
 * (kn_retired.h; kn_boot.c list_files, before anything loads). Weak: without a bridge no port is refused. */
int kn_foreign_has(const char *name) __attribute__((weak));
/* a sound of type "iter" loading (dispatcher.c patch_type_hook): knob 4 holds another format's engine mark; -> the
 * registered engine number that claims it, or 0 (the sound loads as before). Weak: without a bridge never called. */
int kn_foreign_mark(int mark) __attribute__((weak));
/* a synth slot's sound loading without "eng_data" (kn_lfo_rec.c keep step): knob 4 (the other format's mark, or the
 * 0x5300 selector patch_type_hook made of it) -> the registered engine number whose data another format keeps as a hex
 * string in sound[*member][*key] (up to 256 bytes), or 0. *member and *key are set whatever the mark: every patch the
 * parser builds keeps that member (a preset in the table, the slot it loads into, the slot's save). The data goes into
 * the slot's eng_data cache (not the JSON) under the engine's name. Weak: without a bridge never called (bfin only). */
int kn_foreign_data(int mark, const char **member, const char **key) __attribute__((weak));

/* every sound before R246's parser reads it (kennel/kn_patch_safe.c parse_safe: all five parse_patch_json callers), on
 * the boot or KeyHandler thread: the bridge rewrites the parts another format saved in its own form (a kit's type, an
 * LFO record, an effect's name and words) into kennel's, in place; a sound kennel saved is left as it is. Weak: without
 * a bridge never called (bfin only). */
void kn_foreign_sound(void *json) __attribute__((weak));
/* a foreign drum provider (op1_feature_drum_synth.h's descriptor, kennel/kn_drum_synth.c): offered at the boot stage after
 * its file committed (never inside a transaction), activated after the features' providers registered; row: its
 * drum_types default_params (the core adds the row, marked, and removes it once the provider is gone). 0, or -1 (an
 * incomplete descriptor, a name kennel's drum synths have, no room) */
struct op1_drum_synth;
int kn_ds_foreign_offer(const struct op1_drum_synth *d, const char *row);
/* a factory kit of an offered provider (after kn_ds_foreign_offer, up to 4): name (a-z 0-9 space _ + -, 1..15) and its 24
 * keys x 8 words, both kept by pointer (static or the file's image). Once the provider is active the core inserts a
 * drum_presets row in folder = its name (type = its name) when that folder has no kit of that name, and removes the
 * folder's kits once the provider is gone (kn_boot.c, kn_core_rows.h kn_cr_drum_kit); the kit browser lists them as
 * any factory kit. 0, or -1 (not offered, no room) */
int kn_ds_foreign_kit(const struct op1_drum_synth *d, const char *name, const int16_t *words);

/* a foreign LFO type (op1_feature_lfo.h's descriptor, kennel/kn_lfo.c): offered at the boot stage after its file committed,
 * taken after the features' types (a name a feature's type has stays the feature's). Its words carry the shared marker
 * KN_LFO_FOREIGN_MARK in word 7 (reserved by the core: such words never reach R246's LfoMidi or its range check, also
 * once the file is gone) and must be told apart by its match. tick: called once a 64-sample block on the audio thread
 * with the features' clock ticks (one call per distinct function), or 0. 0, or -1 (incomplete, another marker, no room).
 * row: its lfo_types default_params (8 words, JSON), inserted after the highest id and marked, and removed once it is
 * not registered (kn_boot.c). */
#define KN_LFO_FOREIGN_MARK 0xC5
struct op1_lfo_type;
int kn_lfo_foreign_offer(const struct op1_lfo_type *t, void (*tick)(const op1_beat_t *), const char *row);
/* a foreign sequencer type (op1_feature_seq.h's descriptor, kennel/kn_seq.c): offered at the boot stage, taken after the
 * features' types (a name a feature's type has stays the feature's); its seq_types row is kept as a .knl type's (marked,
 * removed once it is gone). 0, or -1 (incomplete, no room). */
struct op1_seq_type;
int kn_seq_foreign_offer(const struct op1_seq_type *t);
/* the mode's (0 synth, 1 drum) active sequencer type, 0 for a stock one (kennel/kn_seq.c) */
const struct op1_seq_type *kn_seq_active_type(int mode);
/* the sequencer thread, once a PlayerManager tick (devupd du_rx_poll, right before the MIDI receive parser): a weak
 * hook the bridge supplies (its files' block handlers). Without a bridge never called. */
void kn_seq_block(void) __attribute__((weak));
/* input (KeyHandler): kn_foreign_input runs in kn_features_input after the text entry and before an engine's own page,
 * the features and R246 (type OP1_IN_KEY / OP1_IN_KNOB as op1_input); 1 takes the event. kn_foreign_input_after runs once
 * the event's whole handling is over (dispatcher.c key_event_hook's delivery, knob_event_hook), taken or not, with the
 * delta R246 got; the bridge pairs it with the before call. Weak: without a bridge never called. */
int kn_foreign_input(int type, int code, int pressed, int delta) __attribute__((weak));
void kn_foreign_input_after(int type, int code, int pressed, int delta) __attribute__((weak));
/* Shift + turn of knob 0..3 on the FX page (dispatcher.c knob_event_hook, KeyHandler, before kennel's op1_fx_shift
 * path) of an FX the bridge registered: fx is the page's op1_fx_t, w its eight words, delta R246's. -> 0 not taken
 * (not a bridged FX, or it has no shift layer for that knob: the paths after run as before), 1 taken, 2 taken and words
 * 5..7 changed (the core saves them as a turn's). Weak: without a bridge never called. */
int kn_foreign_fx_shift(const void *fx, int16_t *w, int knob, int delta) __attribute__((weak));
/* a plain turn of knob 0..3 on the FX page (dispatcher.c knob_event_hook, before the shift paths) of an FX the bridge
 * registered: the bridge tells the FX's own page (its page feedback, e.g. a flash on the turned knob); the turn then goes
 * on as before (the knob words are not changed here). Weak: without a bridge never called. */
void kn_foreign_fx_turn(const void *fx, const int16_t *w, int knob, int delta) __attribute__((weak));
/* the audio callback's start (screens/sysmon_core.c), while the input source is the line input (0xFF8010B4 == 1):
 * R246's RX block, 64 frames x 2 int32 (left, right; the sample in the top 24 bits), before its graph sums the two sides;
 * what the hook leaves there is what R246 takes. Weak: without a bridge never called. */
void kn_foreign_line_in(int32_t *rx) __attribute__((weak));

void kn_foreign_begin(void);
uint32_t kn_foreign_alloc(uint32_t size, uint32_t align);
void kn_foreign_sync(uint32_t lo, uint32_t hi);
const char *kn_foreign_add(const kn_foreign_desc *d);
int kn_foreign_image(const kn_img_rec *r);
void kn_foreign_commit(void);
void kn_foreign_rollback(void);
int kn_plugin_listed(int fx, const char *saved, int listed);   /* boot stage: 0 ok, -1 no such registered name */
int kn_plugin_order(int fx, const char *saved);                /* the registered number of a saved name, 0 none */

/* ---- audio taps (kennel/kn_bus.c): plain functions on the audio thread, 64 samples at 44.1 kHz in place, integer
 * only. Registered at boot (the bridge's stage); no tap registered costs one load and a branch a block. ----
 *   KN_TAP_PRE_FX  the instrument's bus before its FX (pos 0 synth, 1 drum): after the high-pass, the engine's
 *                  voice-sum block and a PRE bus insert (the channel strip set to PRE), before R246 renders the slot's
 *                  FX, whether that FX is on or not. A POST strip runs after the FX, so the tap sees the bus without
 *                  it; an OFF strip asleep (op1_bus_gate) changes nothing, the taps still run every block. Never in
 *                  game mode. Charged to the FX class of the resource monitor.
 * Post-FX and post-master taps have no kennel-owned site that runs with the FX off (R246 renders the FX in L1,
 * core_block_process); they need a new L1 poke and are not built (ARCHITECTURE.md "Foreign plugin bridge: core services"). */
enum { KN_TAP_PRE_FX = 0, KN_TAP_N };
#define KN_TAP_MAX 4                        /* per point */
typedef void (*kn_tap_fn)(int pos, int16_t *bus);
int kn_tap_add(int point, kn_tap_fn fn);    /* boot: 0 ok, -1 full or a bad point */
/* this block's dry input left out (an engine that plays the input itself, from its voice-sum block: the input is heard
 * once): set on the audio thread inside op1_engine_sum_t.block, read and cleared right after it by kennel/kn_input.c
 * (the synth bus: the caller's has-input word to 0, so neither the dry monitor nor the input added after the output
 * stage takes the block). 0 every other time; a core without the bridge never sets it. */
extern volatile uint8_t kn_skip_dry;

/* ---- a sound's data for a foreign engine: up to 256 bytes (the other format's limit), kept in the sound's "eng_data" member as
 * op1_engine_data's (kennel/kn_lfo_rec.c; plugin files stay at OP1_ENGINE_DATA_MAX, 192). Read with op1_engine_data.
 * cap at most 256; KeyHandler, as op1_engine_data_store. 1 stored, 0 refused. ---- */
int kn_engine_data_store_n(int slot, const char *name, const void *data, int n, int cap);

/* the stock envelope's words for a KN_FE_NEUTRAL_ENV engine's voice (dispatcher.c kn_engine_adsr_words): the T2 ranges'
 * (0x01DE5710: 64..16320 for A, D, R, 0..32767 for S) fastest attack, full sustain, slowest release; words 4..7 (the
 * play mode and the rest) the sound's own */
static inline void kn_neutral_words(const int16_t *in, int16_t *out)
{
    for (int i = 4; i < 8; i++) out[i] = in[i];
    out[0] = 64; out[1] = 64; out[2] = 32767; out[3] = 16320;
}

/* ---- per-order engine extras the foreign registration sets (dispatcher.c, kennel/kn_eng_hooks.c) ---- */
extern uint8_t kn_engine_neutral_env[];     /* [OP1_SLOTS]: KN_FE_NEUTRAL_ENV */
#endif
