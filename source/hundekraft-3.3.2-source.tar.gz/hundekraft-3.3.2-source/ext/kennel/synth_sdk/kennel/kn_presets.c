/*
 * User presets sent over SysEx (devupd: presets/<synth|drum>/<folder>/<name>.aif and .del; docs/inventory.md
 * "Presets", ARCHITECTURE.md "Presets over SysEx").
 *
 * Two ways in, one importer:
 * - Live (HELLO bit 32, PRESET_APPLY): du.c writes DU_PRESET_QUEUE (a manifest of the staged files) and calls
 *   kn_presets_start; the main loop (du_service -> kn_presets_live) then takes one queue entry per pass, removals
 *   first, then adds, each in send order. While the queue runs, du.c answers BEGIN / DELETE / ABORT / COMMIT / RESTART /
 *   PRESET_APPLY with "state" (the stage files are the queue's data). At the end: each changed kind's table reloaded
 *   and an open browser rebuilt (preset tools' kn_pt_changed), a toast, the queue file removed. A cut in the middle:
 *   the boot hook finishes the queue (the entry in flight is lost at most; each stage file is removed before R246's
 *   insert, so none goes in twice).
 * - With a restart (bit 16, a mixed update: COMMIT): the apply phase copies the files to /yaffs2/presets/...; the boot
 *   hook imports that directory (removals first, then adds, names sorted).
 * Both run at the end of kennel's boot hook (databases open, before fat_sync_after_reboot 0x019F034E and
 * patch_table_loader 0x01A0567C), so presets are listed on that boot.
 *
 * R246 keeps a user preset as a row (id, patch JSON, folder) in op1.db synth_user / drum_user plus, for a sampler or
 * drum preset, the sample in /yaffs2/user/audio/preset_<kind>/<folder>/<name>.raw (16-bit mono, no header). Add: the
 * row goes in through R246's own insert (fat_interface 0x019955EC via 0x01995938 synth_user / 0x01995B80 drum_user:
 * JSON parse, parse_patch_json, INSERT; the disk sync and the hold-to-save use it too; it takes db2's lock itself),
 * the JSON's "name" set to the file's name; rows with the same folder and name (preset tools' lookup, kn_pt_rows) are
 * deleted after the insert worked, so a replace sticks. The sample is written before the row names it: a new one
 * straight to <name>.raw, a replaced one to <name>.raw.new, then the row, then copied over <name>.raw (YAFFS has no
 * rename; preset tools' order). Remove (.del): preset tools' delete path (kn_pt_delete: .deleted keeps the newest 16,
 * slot source records forgotten). Caps (one place, kn_preset_cap) are checked before the insert: R246's loader
 * asserts at boot on too many rows.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_synth.h"
#include "../devupd/du.h"
#include "../devupd/du_preset.h"

typedef int (*row_cb)(void *, int, char **, char **);
int kn_pt_rows(int kind, const char *folder, const char *name, int32_t *ids, int max);   /* kn_preset_tools.c */
int kn_pt_query(const char *q, row_cb cb, void *arg);
int kn_pt_json_str(const char *t, const char *key, char *out, int size);
int kn_pt_factory(int kind, const char *type);
const char *kn_pt_delete(int kind, const char *folder, const char *name);
void kn_pt_changed(int kind);
void op1_toast(const char *text);
void kn_log_line(const char *what, const char *msg);              /* kn_boot.c */

#ifdef OP1_HOST                                                   /* harness/presets_usb_test.c with fake_r246.c */
int host_y_open(const char *p, int flags, int mode), host_y_close(int fd), host_y_read(int fd, void *d, int n);
int host_y_write(int fd, const void *s, int n), host_y_unlink(const char *p), host_y_mkdir(const char *p, int mode);
int32_t host_y_lseek(int fd, int32_t off, int whence);
int host_access(const char *path);
void *host_opendir(const char *path);
void *host_readdir(void *dir);
void host_closedir(void *dir);
int host_insert(int kind, const char *json, const char *folder);  /* 1 inserted */
int host_bgs_drain(int ms);
#define Y_OPEN     host_y_open
#define Y_CLOSE    host_y_close
#define Y_READ     host_y_read
#define Y_WRITE    host_y_write
#define Y_LSEEK    host_y_lseek
#define Y_UNLINK   host_y_unlink
#define Y_MKDIR    host_y_mkdir
#define ACCESS(p)  host_access(p)
#define OPENDIR    host_opendir
#define READDIR(d) ((const uint8_t *)host_readdir(d))
#define CLOSEDIR   host_closedir
#define DRAIN(ms)  host_bgs_drain(ms)
#define FARBSS
uint16_t host_gate_synth[2] = { 0xE121, 300 }, host_gate_sampler[2] = { 0x6001 | 42 << 3, 0x6001 | 42 << 3 }, host_gate_drum[2] = { 0x6001 | 58 << 3, 0 };
#define GATE_SYNTH    ((const volatile uint16_t *)host_gate_synth)
#define LIMIT_SAMPLER ((const volatile uint16_t *)&host_gate_sampler[0])
#define GATE_SAMPLER  ((const volatile uint16_t *)&host_gate_sampler[1])
#define GATE_DRUM     ((const volatile uint16_t *)host_gate_drum)
#else
#include "../kn_mem.h"
#define FARBSS kn_farbss
#define Y_OPEN     ((int (*)(const char *, int, int))0x01A997F4)
#define Y_CLOSE    ((int (*)(int))0x01A99908)
#define Y_READ     ((int (*)(int, void *, unsigned))0x01A99C90)
#define Y_WRITE    ((int (*)(int, const void *, unsigned))0x01A99F84)
#define Y_LSEEK    ((int32_t (*)(int, int32_t, int))0x01A9A0E4)
#define Y_UNLINK   ((int (*)(const char *))0x01A9A3FC)
#define Y_MKDIR    ((int (*)(const char *, int))0x01A9A886)      /* yaffs_mkdir: P0 = R0 at 0x01A9A886, then LINK */
#define ACCESS(p)  (((int (*)(const char *, int))0x01A9A6B0)((p), 0))   /* 0 = exists */
#define OPENDIR    ((void *(*)(const char *))0x01A9B450)
#define READDIR    ((const uint8_t *(*)(void *))0x01A9B648)      /* dirent: +0x0B d_name */
#define CLOSEDIR   ((int (*)(void *))0x01A9B74C)
int bgs_drain(int ms);                                            /* bgsave.c */
#define DRAIN(ms)  bgs_drain(ms)
#define INSERT_SYNTH ((int (*)(void *))0x01995938)                /* {string patch, string folder} -> 1 inserted */
#define INSERT_DRUM  ((int (*)(void *))0x01995B80)
extern volatile uint32_t kn_insert_sql_refused;                    /* kn_patch_sql.c: a statement too big, not run */
extern const volatile uint16_t *kn_preset_gate_at;                /* kn_inv.c: 0x019FEF02, the save gate's R1 = imm16 */
#define GATE_SYNTH   kn_preset_gate_at
#define LIMIT_SAMPLER ((const volatile uint16_t *)0x01A05954)     /* R1 = imm7 (patch.cpp:629) */
#define GATE_SAMPLER ((const volatile uint16_t *)0x019FEF16)
#define GATE_DRUM    ((const volatile uint16_t *)0x019FEEEE)
typedef struct { uint32_t alloc; union { char buf[16]; char *ptr; } u; uint32_t size, cap; } r_str;   /* R246 std::string */
#endif
#define O_CREATE   0x241

#define ROOT   "/yaffs2/presets"
#define MAXF   64                                                 /* folders per kind looked at in one boot */
#define MAXN   160                                                /* files per folder */

/* result per sent file of the last apply (PRESET_LIST what 2); 0 = not done yet */
enum { R_ADDED = 1, R_REPLACED = 2, R_REMOVED = 3, R_ABSENT = 4,
       R_NOT_PATCH = 16, R_BAD_TEXT = 17, R_SAMPLE = 18, R_FULL_SYNTH = 19, R_FULL_SAMPLER = 20, R_FULL_DRUM = 21,
       R_CHECK = 22, R_WRITE = 23, R_NO_CAP = 24, R_NOT_DELETED = 25, R_BAD_NAME = 26 };

volatile int kn_preset_added, kn_preset_replaced, kn_preset_removed, kn_preset_absent, kn_preset_refused;   /* since boot */

static char sql[640];
static char json[DU_PJSON_MAX + 64] FARBSS, text[DU_PJSON_MAX + 64] FARBSS;
static uint8_t io[4096] FARBSS;
static char folders[MAXF][DU_PRESET_FOLDER + 1] FARBSS;
static char names[MAXN][DU_PRESET_NAME + 5] FARBSS;

static char *cat(char *d, const char *s) { while (*s) *d++ = *s++; *d = 0; return d; }
static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }
static int scmp(const char *a, const char *b) { while (*a && *a == *b) a++, b++; return (uint8_t)*a - (uint8_t)*b; }
static char *num(char *d, uint32_t v) { char t[12]; int n = 0; do t[n++] = (char)('0' + v % 10); while (v /= 10); while (n) *d++ = t[--n]; *d = 0; return d; }

/* ---------------- caps: the one place they are read (the builder and preset-storage change the gates) ---------------- */
static int gate_value(const volatile uint16_t *at)                /* R1 = imm16 (0xE121 imm) or R1 = imm7; -1 neither */
{
    uint16_t w = at[0];
    if (w == 0xE121) return at[1];
    if ((w & 0xFC07) == 0x6001 && !(w & 0x200)) return (w >> 3) & 0x3F;   /* (positive: bit 6 of imm7 clear) */
    return -1;
}
/* Kits with preset storage (branch preset-storage, kn_preset_store.c): its save gate 0x019FEEE4 is a jump to
 * kn_pl_drum_gate_fn, so R246's 58 at 0x019FEEEE is dead code there; the cap is the factory kits plus the room the
 * user load is limited to. kn_pl_scan.h exists only with preset storage, and kn_pl_drum_factory is weak (a host test
 * without kn_preset_store.c links), so this file builds with or without it. */
#if __has_include("kn_pl_scan.h")
#include "kn_pl_scan.h"
extern volatile int32_t kn_pl_drum_factory __attribute__((weak));
static int kit_cap(void) { if (!&kn_pl_drum_factory) return -2; int32_t f = kn_pl_drum_factory; return f + kn_pl_drum_room(f); }
#else
static int kit_cap(void) { return -2; }                           /* -2: no preset storage, read R246's gate */
#endif
/* which: 0 plain synth (user rows), 1 sampler (factory included), 2 drum kits (factory included); -1 unknown */
int kn_preset_cap(int which)
{
    if (which == 0) return GATE_SYNTH ? gate_value(GATE_SYNTH) : -1;
    if (which == 2) { int k = kit_cap(); return k != -2 ? k : gate_value(GATE_DRUM); }
    int a = gate_value(LIMIT_SAMPLER), b = gate_value(GATE_SAMPLER);
    return a < 0 || b < 0 ? -1 : a < b ? a : b;
}
static int count_cb(void *arg, int n, char **v, char **c) { (void)c; int x = 0; if (n > 0 && v[0]) for (const char *p = v[0]; *p >= '0' && *p <= '9'; p++) x = x * 10 + *p - '0'; *(int *)arg = x; return 0; }
static int user_count(const char *q) { int x = 0; return kn_pt_query(q, count_cb, &x) ? -1 : x; }
#define IS_SAMPLER "patch GLOB '*\"type\":\"sampler\"*'"
/* what the cap of `which` counts now (as R246's loader: user rows, plus factory entries for samplers and kits) */
int kn_preset_have(int which)
{
    if (which == 0) return user_count("SELECT COUNT(*) FROM synth_user WHERE NOT " IS_SAMPLER);
    if (which == 1) return kn_pt_factory(0, "sampler") + user_count("SELECT COUNT(*) FROM synth_user WHERE " IS_SAMPLER);
    return kn_pt_factory(1, 0) + user_count("SELECT COUNT(*) FROM drum_user");
}

/* ---------------- one preset ---------------- */
static int qfd = -1;
static int q_read(void *c, uint32_t off, uint8_t *dst, uint32_t n)
{
    (void)c;
    if (Y_LSEEK(qfd, (int32_t)off, 0) != (int32_t)off) return 1;
    while (n) { int k = Y_READ(qfd, dst, n); if (k <= 0) return 1; dst += k; n -= (uint32_t)k; }
    return 0;
}
static int copy_sample(const du_aif *a, const char *dst)          /* the sample as 16-bit little-endian; 0 ok */
{
    int out = Y_OPEN(dst, O_CREATE, 0x180);
    if (out < 0) return 1;
    int ok = 1;
    for (uint32_t at = 0; ok && at < a->snd_len;) {
        uint32_t k = a->snd_len - at > sizeof io ? sizeof io : a->snd_len - at;
        if (q_read(0, a->snd_off + at, io, k)) { ok = 0; break; }
        if (!a->little) for (uint32_t i = 0; i + 1 < k; i += 2) { uint8_t t = io[i]; io[i] = io[i + 1]; io[i + 1] = t; }
        if (Y_WRITE(out, io, k) != (int)k) ok = 0;
        at += k;
    }
    if (Y_CLOSE(out)) ok = 0;
    if (!ok) Y_UNLINK(dst);
    return !ok;
}
static int fcopy(const char *from, const char *to)                /* 0 ok */
{
    int in = Y_OPEN(from, 0, 0x100);
    if (in < 0) return 1;
    int out = Y_OPEN(to, O_CREATE, 0x180), ok = out >= 0;
    while (ok) {
        int k = Y_READ(in, io, sizeof io);
        if (k < 0) ok = 0;
        if (k <= 0) break;
        if (Y_WRITE(out, io, (unsigned)k) != k) ok = 0;
    }
    if (out >= 0 && Y_CLOSE(out)) ok = 0;
    Y_CLOSE(in);
    return !ok;
}
static void raw_path(char *o, int kind, const char *folder, const char *name, const char *ext)   /* kind 0 synth, 1 drum */
{
    o = cat(cat(o, "/yaffs2/user/audio/preset_"), kind ? "drum" : "synth");
    if (folder) { o = cat(cat(o, "/"), folder); if (name) cat(cat(cat(o, "/"), name), ext); }
}
static const char *why_text(int r)
{
    switch (r) {
    case R_ADDED: return "added"; case R_REPLACED: return "replaced"; case R_REMOVED: return "removed"; case R_ABSENT: return "not there";
    case R_NOT_PATCH: return "not an OP-1 patch file"; case R_BAD_TEXT: return "bad patch text";
    case R_SAMPLE: return "sample not 16-bit mono up to 6 / 12 s"; case R_FULL_SYNTH: return "no room (synth presets)";
    case R_FULL_SAMPLER: return "no room (sampler presets)"; case R_FULL_DRUM: return "no room (drum presets)";
    case R_CHECK: return "refused by the patch check"; case R_WRITE: return "not written"; case R_NO_CAP: return "cap unknown";
    case R_NOT_DELETED: return "not deleted"; case R_BAD_NAME: return "bad name";
    }
    return "?";
}
static void say(int kind, const char *folder, const char *name, int r)
{
    char m[120], *o = cat(cat(m, kind ? "drum/" : "synth/"), folder);
    cat(cat(cat(cat(o, "/"), name), ": "), why_text(r));
    kn_log_line("preset", m);
    if (r == R_ADDED) kn_preset_added++; else if (r == R_REPLACED) kn_preset_replaced++; else if (r == R_REMOVED) kn_preset_removed++;
    else if (r == R_ABSENT) kn_preset_absent++; else kn_preset_refused++;
}

static int remove_one(int kind, const char *folder, const char *name)
{
    const char *e = kn_pt_delete(kind, folder, name);
    return !e ? R_REMOVED : e[0] == 'n' && e[4] == 't' && e[5] == 'h' ? R_ABSENT : R_NOT_DELETED;   /* "not there" */
}

static int insert(int kind, int n, const char *folder)
{
#ifdef OP1_HOST
    (void)n;
    return host_insert(kind, json, folder);
#else
    r_str obj[2];                                                 /* R246: {std::string patch, std::string folder} */
    for (unsigned i = 0; i < sizeof obj / 4; i++) ((volatile uint32_t *)obj)[i] = 0;
    obj[0].u.ptr = json; obj[0].size = (uint32_t)n; obj[0].cap = (uint32_t)n < 16 ? 16 : (uint32_t)n;
    int fl = slen(folder);
    if (fl > 15) { obj[1].u.ptr = (char *)folder; obj[1].cap = (uint32_t)fl; }   /* (folder: at most 24 characters) */
    else { for (int i = 0; i <= fl; i++) obj[1].u.buf[i] = folder[i]; obj[1].cap = 15; }
    obj[1].size = (uint32_t)fl;
    uint32_t refused = kn_insert_sql_refused;                     /* R246 returns 1 even when kn_patch_sql.c refused */
    return (kind ? INSERT_DRUM : INSERT_SYNTH)(obj) && kn_insert_sql_refused == refused;
#endif
}

/* the add / replace of one preset from the queue file qp (opened as qfd here); the file is gone afterwards */
static int add_one(int kind, const char *folder, const char *name, const char *qp)
{
    int r = 0;
    du_aif a;
    int32_t size = Y_LSEEK(qfd, 0, 2);
    int sampler = 0, audio = 0, n = -1;
    if (size <= 0 || du_aif_scan(q_read, 0, (uint32_t)size, &a)) r = R_NOT_PATCH;
    else if (a.json_len > DU_PJSON_MAX || q_read(0, a.json_off, (uint8_t *)text, a.json_len)) r = R_BAD_TEXT;
    else if ((n = du_preset_json(text, (int)a.json_len, name, json, sizeof json)) < 0) r = R_BAD_TEXT;
    if (!r) {
        char type[16];                                            /* the type whose .raw is the preset's sample */
        if (kn_pt_json_str(json, "type", type, sizeof type)) type[0] = 0;
        sampler = kind == 0 && du_preset_sampler(json);
        audio = kind == 1 ? scmp(type, "drum") == 0 : sampler;    /* (dbox and plugin kits have none, as preset tools' SAMPLED) */
        if (audio && (a.channels != 1 || a.bits != 16 || !a.snd_len || (a.snd_len & 1) ||
                      a.snd_len > (kind == 0 ? DU_SYNTH_RAW_MAX : DU_DRUM_RAW_MAX))) r = R_SAMPLE;
    }
    static int32_t old[16];
    int nold = r ? 0 : kn_pt_rows(kind, folder, name, old, 16);   /* the rows it replaces (read before the insert) */
    if (nold < 0) r = R_WRITE;
    if (nold > 16) nold = 16;
    if (!r) {                                                     /* caps: R246's loader asserts past them at boot */
        int which = kind ? 2 : sampler ? 1 : 0, cap = kn_preset_cap(which), have = kn_preset_have(which);
        int same = 0;                                             /* a replace frees its own row (same cap class) */
        if (nold) {
            char q[400], *o = cat(q, "SELECT COUNT(*) FROM ");
            o = cat(cat(cat(o, kind ? "drum_user" : "synth_user"), " WHERE id IN ("), "");
            for (int i = 0; i < nold; i++) { if (i) o = cat(o, ","); o = num(o, (uint32_t)old[i]); }
            o = cat(o, ")");
            if (!kind) cat(o, sampler ? " AND " IS_SAMPLER : " AND NOT " IS_SAMPLER);
            same = user_count(q);
        }
        if (cap < 0 || have < 0) r = R_NO_CAP;
        else if (have - same + 1 > cap) r = which == 2 ? R_FULL_DRUM : which == 1 ? R_FULL_SAMPLER : R_FULL_SYNTH;
    }
    char raw[DU_MAX_PATH + 64], tmp[DU_MAX_PATH + 72];
    raw_path(raw, kind, folder, name, ".raw");
    raw_path(tmp, kind, folder, name, ".raw.new");
    int staged = 0;                                               /* 1: sample in <name>.raw.new, 2: straight in <name>.raw */
    if (!r && audio) {
        char d[DU_MAX_PATH + 48];
        raw_path(d, kind, 0, 0, 0); Y_MKDIR(d, 0x1FF);            /* (-1 when it exists) */
        raw_path(d, kind, folder, 0, 0); Y_MKDIR(d, 0x1FF);
        staged = ACCESS(raw) == 0 ? 1 : 2;
        if (copy_sample(&a, staged == 1 ? tmp : raw)) { r = R_WRITE; staged = 0; }
    }
    Y_CLOSE(qfd); qfd = -1;
    Y_UNLINK(qp);                                                 /* before R246's insert runs */
    if (!r && !insert(kind, n, folder)) r = R_CHECK;
    if (r) {
        if (staged) Y_UNLINK(staged == 1 ? tmp : raw);
        return r;
    }
    if (nold) {                                                   /* the replaced rows */
        char *o = cat(cat(cat(sql, "DELETE FROM "), kind ? "drum_user" : "synth_user"), " WHERE id IN (");
        for (int i = 0; i < nold; i++) { if (i) o = cat(o, ","); o = num(o, (uint32_t)old[i]); }
        cat(o, ")");
        kn_pt_query(sql, 0, 0);
    }
    if (staged == 1 && !fcopy(tmp, raw)) Y_UNLINK(tmp);           /* (a failed copy keeps <name>.raw.new) */
    if (!audio) Y_UNLINK(raw);                                    /* (a replaced sampler preset's sample) */
    return nold ? R_REPLACED : R_ADDED;
}

/* one queue file: kind 0 synth / 1 drum; del: a .del; path: the file (removed afterwards) */
static int import_one(int kind, const char *folder, const char *name, int del, const char *path)
{
    int r;
    if (del) { r = remove_one(kind, folder, name); Y_UNLINK(path); }
    else {
        qfd = Y_OPEN(path, 0, 0x100);
        if (qfd < 0) { r = R_WRITE; Y_UNLINK(path); }
        else r = add_one(kind, folder, name, path);
    }
    say(kind, folder, name, r);
    return r;
}
/* "presets/<synth|drum>/<folder>/<name>.<aif|del>" into its parts; kind 0 / 1, -1 bad */
static int parts(const char *rel, char *folder, char *name, int *del)
{
    int k = du_preset_path(rel, 1);
    if (!k) return -1;
    const char *f = rel + (k == 1 ? 14 : 13);
    int i = 0;
    while (f[i] != '/') { folder[i] = f[i]; i++; }
    folder[i] = 0;
    const char *nm = f + i + 1;
    int l = slen(nm);
    for (i = 0; i < l - 4; i++) name[i] = nm[i];
    name[l - 4] = 0;
    *del = nm[l - 1] == 'l';
    return k - 1;
}

/* ---------------- the live queue (DU_PRESET_QUEUE) ---------------- */
static du_file qf[DU_MAX_FILES] FARBSS;
static uint8_t result[DU_MAX_FILES];
static struct { uint8_t active, booting, drained, pass; uint8_t touched[2]; int n, at; uint32_t apply; int counts[4]; } live;

static int read_queue(void)                                      /* entries into qf; their count, -1 none / bad */
{
    static char t[DU_MAX_FILES * (DU_MAX_PATH + 32) + 64] FARBSS;
    int fd = Y_OPEN(DU_PRESET_QUEUE, 0, 0x100);
    if (fd < 0) return -1;
    int n = Y_READ(fd, t, sizeof t - 1);
    Y_CLOSE(fd);
    if (n <= 0) return -1;
    t[n] = 0;
    int k;
    return du_manifest_parse(t, qf, &k) ? -1 : k;
}
int kn_presets_start(void)                                        /* du_fs.preset_start: the apply's number, 0 none */
{
    if (live.active) return 0;
    int n = read_queue();
    if (n <= 0) return 0;
    live.n = n; live.at = 0; live.pass = 0; live.drained = 0; live.touched[0] = live.touched[1] = 0;
    for (int i = 0; i < 4; i++) live.counts[i] = 0;
    for (int i = 0; i < DU_MAX_FILES; i++) result[i] = 0;
    if (++live.apply == 0) live.apply = 1;
    live.active = 1;
    return (int)live.apply;
}
int kn_presets_busy(void) { return live.active; }
#ifdef OP1_HOST
void kn_presets_test_reboot(void) { live.active = 0; }           /* presets_usb_test: RAM state gone, files kept */
#endif

static void toast_result(void)                                    /* "presets: 4 in, 2 out" / "4 in, 2 out, 1 refused" */
{
    int in = live.counts[0] + live.counts[1], out = live.counts[2], bad = live.counts[3];
    char m[48], *o = bad ? m : cat(m, "presets: ");
    char *start = o;
    if (in) o = cat(num(o, (uint32_t)in), " in");
    if (out) { if (o != start) o = cat(o, ", "); o = cat(num(o, (uint32_t)out), " out"); }
    if (bad) { if (o != start) o = cat(o, ", "); o = cat(num(o, (uint32_t)bad), " refused"); }
    if (o == start) cat(m, "presets: no changes");
    op1_toast(m);
}
/* one step: the next entry of the pass (0 removals, 1 adds); 1 while there is more */
static int live_step(void)
{
    for (; live.pass < 2; live.pass++, live.at = 0)
        for (; live.at < live.n; live.at++) {
            const du_file *f = &qf[live.at];
            char folder[DU_PRESET_FOLDER + 1], name[DU_PRESET_NAME + 1], stage[40];
            int del, kind = parts(f->path, folder, name, &del);
            if (kind < 0) { if (live.pass == 0) result[live.at] = R_BAD_NAME; continue; }
            if (del != (live.pass == 0)) continue;
            du_stage_name(live.at, stage);
            int i = live.at++;
            if (ACCESS(stage) != 0) return 1;                     /* done before a cut (boot): result unknown */
            int r = import_one(kind, folder, name, del, stage);
            result[i] = (uint8_t)r;
            live.counts[r == R_ADDED ? 0 : r == R_REPLACED ? 1 : r == R_REMOVED ? 2 : r == R_ABSENT ? 2 : 3] += r != R_ABSENT;
            if (r == R_ADDED || r == R_REPLACED || r == R_REMOVED) live.touched[kind] = 1;
            return 1;
        }
    return 0;
}
static void live_finish(void)
{
    if (!live.booting) {
        for (int k = 0; k < 2; k++) if (live.touched[k]) kn_pt_changed(k);
        toast_result();
    }
    Y_UNLINK(DU_PRESET_QUEUE);
    live.active = 0;
}
void kn_presets_live(void)                                        /* du_service (main loop), every pass */
{
    if (!live.active) return;
    if (!live.drained) { live.drained = 1; DRAIN(3000); return; } /* queued slot saves and preset loads first */
    if (!live_step()) live_finish();
}

/* PRESET_LIST (du_fs.preset_list): what 0 / 1 = the user synth / drum rows after row id `from` as text records
 * "folder\tname\tT\n" (T: p plain synth, s sampler, k kit), whole records only: u32 last id given, u8 more, text.
 * A row that can't fit a 64-byte page alone goes out alone, cut: "folder\tname\tT\tc\n" (folder <= 24 bytes, the name
 * what fits; cut at a UTF-8 character boundary), so every page moves `last` on.
 * what 2 = the last apply's results from index `from`: u32 apply number, u8 running, u8 count, a byte per file.
 * what 3 = counts and caps: u16 have / cap for plain synth, sampler, kits (cap 0xFFFF: unknown). */
typedef struct { uint8_t *out; int cap, len, rows, full; uint32_t last; int kind; } list_t;
static int list_cb(void *arg, int n, char **v, char **c)
{
    (void)c;
    list_t *l = arg;
    l->rows++;
    if (l->full || n < 3 || !v[0] || !v[2]) { l->full = 1; return 0; }
    char nm[DU_PRESET_NAME * 2 + 1], ty[16];
    if (kn_pt_json_str(v[2], "name", nm, sizeof nm)) nm[0] = 0;
    if (kn_pt_json_str(v[2], "type", ty, sizeof ty)) ty[0] = 0;
    const char *fo = v[1] ? v[1] : "";
    int fl = slen(fo), nl = slen(nm), cut = 0, need = fl + nl + 4;
    if (l->len + need > l->cap) {
        /* a row longer than a whole page (disk-mode names): alone on its page, folder and name cut at a character
         * boundary and a fourth field "c" (cut) added, so the list moves on; a page with rows already ends here */
        if (l->len) { l->full = 1; return 0; }
        cut = 1;
        if (fl > DU_PRESET_FOLDER) fl = DU_PRESET_FOLDER;
        if (nl > l->cap - 6 - fl) nl = l->cap - 6 - fl;
        while (fl > 0 && ((uint8_t)fo[fl] & 0xC0) == 0x80) fl--;
        while (nl > 0 && ((uint8_t)nm[nl] & 0xC0) == 0x80) nl--;
        need = fl + nl + 6;
    }
    uint8_t *o = l->out + l->len;
    for (int i = 0; i < fl; i++) *o++ = (uint8_t)fo[i];
    *o++ = '\t';
    for (int i = 0; i < nl; i++) *o++ = (uint8_t)nm[i];
    *o++ = '\t';
    *o++ = l->kind ? 'k' : scmp(ty, "sampler") == 0 ? 's' : 'p';
    if (cut) { *o++ = '\t'; *o++ = 'c'; }
    *o++ = '\n';
    l->len += need;
    uint32_t id = 0;
    for (const char *p = v[0]; *p >= '0' && *p <= '9'; p++) id = id * 10 + (uint32_t)(*p - '0');
    l->last = id;
    return 0;
}
static void w32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }
int kn_presets_list(int what, uint32_t from, uint8_t *out, int cap)
{
    if (what == 0 || what == 1) {
        if (cap < 5 + 8) return -1;
        list_t l = { out + 5, cap - 5 > 64 ? 64 : cap - 5, 0, 0, 0, from, what };
        char *o = cat(cat(cat(sql, "SELECT id,folder,patch FROM "), what ? "drum_user" : "synth_user"), " WHERE id>");
        cat(cat(num(o, from), " ORDER BY id LIMIT "), "16");
        if (kn_pt_query(sql, list_cb, &l)) return -1;
        w32(out, l.last);
        out[4] = (uint8_t)(l.full || l.rows >= 16);
        return 5 + l.len;
    }
    if (what == 2) {
        if (cap < 6) return -1;
        w32(out, live.apply);
        out[4] = live.active;
        int n = live.n, k = 0;
        out[5] = (uint8_t)n;
        for (uint32_t i = from; (int)i < n && 6 + k < cap; i++, k++) out[6 + k] = result[i];
        return 6 + k;
    }
    if (what == 3) {
        if (cap < 12) return -1;
        for (int w = 0; w < 3; w++) {
            int have = kn_preset_have(w), c = kn_preset_cap(w);
            out[w * 4] = (uint8_t)have; out[w * 4 + 1] = (uint8_t)(have >> 8);
            out[w * 4 + 2] = (uint8_t)(c < 0 ? 0xFF : c); out[w * 4 + 3] = (uint8_t)(c < 0 ? 0xFF : c >> 8);
        }
        return 12;
    }
    return -1;
}

/* ---------------- the restart path: /yaffs2/presets/<kind>/<folder>/<name>.<aif|del> ---------------- */
static int list_dir(const char *dir, char *out, int max, int width)   /* names, sorted */
{
    void *d = OPENDIR(dir);
    if (!d) return 0;
    int n = 0;
    const uint8_t *e;
    while ((e = READDIR(d)) && n < max) {                         /* names first: no file I/O while it is open */
        const char *s = (const char *)e + 11;
        int l = slen(s);
        if (s[0] == '.' || l >= width) continue;
        for (int i = 0; i <= l; i++) out[n * width + i] = s[i];
        n++;
    }
    CLOSEDIR(d);
    for (int i = 1; i < n; i++)                                   /* insertion sort: YAFFS lists newest first */
        for (int j = i; j > 0 && scmp(out + (j - 1) * width, out + j * width) > 0; j--)
            for (int k = 0; k < width; k++) { char t = out[j * width + k]; out[j * width + k] = out[(j - 1) * width + k]; out[(j - 1) * width + k] = t; }
    return n;
}
static void one_kind(int kind)
{
    char dir[DU_MAX_PATH + 32], p[DU_MAX_PATH + 32], rel[DU_MAX_PATH + 16];
    cat(cat(dir, ROOT "/"), kind ? "drum" : "synth");
    int nf = list_dir(dir, (char *)folders, MAXF, DU_PRESET_FOLDER + 1);
    for (int f = 0; f < nf; f++) {
        const char *folder = folders[f];
        char fd[DU_MAX_PATH + 32]; cat(cat(cat(fd, dir), "/"), folder);
        int nn = list_dir(fd, (char *)names, MAXN, DU_PRESET_NAME + 5);
        for (int pass = 0; pass < 2; pass++)                      /* removals first: they make room */
            for (int i = 0; i < nn; i++) {
                cat(cat(cat(cat(cat(rel, "presets/"), kind ? "drum/" : "synth/"), folder), "/"), names[i]);
                cat(cat(cat(p, fd), "/"), names[i]);
                char fo[DU_PRESET_FOLDER + 1], nm[DU_PRESET_NAME + 1];
                int del, k = parts(rel, fo, nm, &del);
                if (k != kind) {                                  /* not ours: left alone, once logged */
                    if (pass == 0) { char m[80]; cat(cat(m, "bad name, left: "), names[i]); kn_log_line("preset", m); kn_preset_refused++; }
                    continue;
                }
                if (del == (pass == 0)) import_one(kind, fo, nm, del, p);
            }
    }
}

/* ---------------- a retired drum provider's user kits ---------------- */
/* HIM, retired in 3.3.1 (owner 2026-11-18: "sounds from retired ports are let go"): every drum_user row whose patch is
 * of `type` goes. A kit whose folder and name are its own goes through preset tools' delete (its JSON kept in
 * preset_drum/.deleted, the newest 16 kept there; the slot source records forgotten); one sharing its folder and name
 * with another kit, or with a name preset tools can't look up (disk mode), is deleted by id alone. kn_boot.c calls this
 * at boot, before the importer, when no provider of `type` registered. -> the kits removed (-1: the query failed). */
typedef struct { int32_t id; char folder[DU_PRESET_FOLDER + 1], name[DU_PRESET_NAME + 1]; } retired_row;
static int retired_cb(void *arg, int n, char **v, char **c)
{
    (void)c;
    retired_row *r = arg;
    if (n < 3 || !v[0]) return 0;
    r->id = 0;
    for (const char *p = v[0]; *p >= '0' && *p <= '9'; p++) r->id = r->id * 10 + *p - '0';
    int k = 0;
    for (const char *p = v[1] ? v[1] : ""; *p && k < DU_PRESET_FOLDER; p++) r->folder[k++] = *p;
    r->folder[k] = 0;
    if (!v[1] || v[1][k] || !v[2] || kn_pt_json_str(v[2], "name", r->name, sizeof r->name)) r->name[0] = 0;   /* (cut: by id) */
    return 0;
}
int kn_presets_retired(const char *type)
{
    int gone = 0;
    for (int guard = 0; guard < 1024; guard++) {
        retired_row r = { -1, "", "" };
        char *o = cat(cat(sql, "SELECT id,folder,patch FROM drum_user WHERE patch GLOB '*\"type\":\""), type);
        cat(o, "\"*' ORDER BY id LIMIT 1");
        if (kn_pt_query(sql, retired_cb, &r)) return gone ? gone : -1;
        if (r.id < 0) break;
        int32_t ids[2];
        if (!r.name[0] || kn_pt_rows(1, r.folder, r.name, ids, 2) != 1 || ids[0] != r.id || kn_pt_delete(1, r.folder, r.name)) {
            num(cat(sql, "DELETE FROM drum_user WHERE id="), (uint32_t)r.id);
            if (kn_pt_query(sql, 0, 0)) break;
        }
        gone++;
    }
    return gone;
}

/* ---------------- slots left on a retired type ---------------- */
/* A slot's working patch (op1.db `tbl` = drum_slots / synth_slots, ids 0..7: R246's slot loaders 0x01A05454 /
 * 0x01A04DC0 read "SELECT patch FROM ..._slots WHERE id=%i" for 0..7) whose top-level "type" is `from` gets `to`, once:
 * the stored row is changed, so the next boots find nothing. kn_boot.c calls this at boot, before OP_Main's slot loads
 * (0x019F0456 -> 0x01A059D0), only when no provider of `from` registered (kn_retired.h kn_retired_slots). One SELECT
 * when nothing matches (GLOB prefilter on "from"; the exact top-level check is kn_pl_scan.h's scanner). The edit runs
 * in SQL (substr at the type's character position, guarded by the same text in WHERE): no copy of the patch, nothing
 * to quote. Each matching slot gets one write attempt per boot and one log line; a failed write leaves the row as it
 * was (kn_patch_safe.c's parse fallback still loads it) and is logged. Reads and writes through kn_pt_query
 * (sqlite3_exec under db2's lock, the rc returned: never db2::exec, which asserts). -> slots changed, -1 query failed. */
#define SLOT_IDS 8
typedef struct { const char *from; int n; int32_t id[SLOT_IDS]; uint32_t at[SLOT_IDS]; } slot_hits;
#if __has_include("kn_pl_scan.h")
/* 1-based character position (SQLite substr on TEXT counts UTF-8 characters) of the top-level "type" value's opening
 * quote when that value is exactly `want`; 0 otherwise or on text the scanner does not take */
static uint32_t slot_type_at(const char *text, const char *want)
{
    const char *p = kn_pl_ws(text);
    if (*p++ != '{') return 0;
    for (p = kn_pl_ws(p); *p == '"';) {
        const char *k = p + 1, *e = kn_pl_skip_str(p);
        if (!e) return 0;
        p = kn_pl_ws(e);
        if (*p++ != ':') return 0;
        p = kn_pl_ws(p);
        if (kn_pl_key_is(k, (int)(e - 1 - k), "type")) {
            const char *v = p + 1, *w = want;
            if (*p != '"') return 0;
            while (*w && *v == *w) v++, w++;
            if (*w || *v != '"') return 0;
            uint32_t at = 1;
            for (const char *c = text; c < p; c++) at += ((uint8_t)*c & 0xC0) != 0x80;
            return at;
        }
        if (!(p = kn_pl_skip_val(p))) return 0;
        p = kn_pl_ws(p);
        if (*p != ',') return 0;
        p = kn_pl_ws(p + 1);
    }
    return 0;
}
#else
static uint32_t slot_type_at(const char *text, const char *want) { (void)text; (void)want; return 0; }
#endif
static int slot_cb(void *arg, int n, char **v, char **c)
{
    (void)c;
    slot_hits *h = arg;
    if (n < 2 || !v[0] || !v[1] || h->n >= SLOT_IDS) return 0;
    int32_t id = 0;
    for (const char *p = v[0]; *p >= '0' && *p <= '9'; p++) id = id * 10 + *p - '0';
    const uint32_t at = slot_type_at(v[1], h->from);
    if (at) { h->id[h->n] = id; h->at[h->n] = at; h->n++; }
    return 0;
}
static int slot_name(const char *s)                               /* [a-z0-9_+-], 1..15: safe inside '...' and GLOB */
{
    int n = 0;
    for (; s[n]; n++)
        if (n >= 15 || !((s[n] >= 'a' && s[n] <= 'z') || (s[n] >= '0' && s[n] <= '9') || s[n] == '_' || s[n] == '+' || s[n] == '-')) return 0;
    return n > 0;
}
/* sql = "... substr(patch,<at>,<len>)='\"<type>\"'" */
static char *slot_guard(char *o, uint32_t at, const char *type)
{
    o = num(cat(o, "substr(patch,"), at);
    o = num(cat(o, ","), (uint32_t)slen(type) + 2);
    return cat(cat(cat(o, ")='\""), type), "\"'");
}
__attribute__((noinline)) int kn_presets_retired_slots(const char *tbl, const char *from, const char *to)
{
    if (!slot_name(tbl) || !slot_name(from) || !slot_name(to)) return 0;
    slot_hits h;                                                  /* no aggregate init: GCC makes it a memset, which the core lacks */
    h.from = from; h.n = 0;                                       /* (id/at are written before they are read, below n) */
    char *o = cat(cat(cat(sql, "SELECT id,patch FROM "), tbl), " WHERE id BETWEEN 0 AND 7 AND patch GLOB '*\"");
    cat(cat(o, from), "\"*' ORDER BY id");
    if (kn_pt_query(sql, slot_cb, &h)) return -1;
    int changed = 0;
    for (int i = 0; i < h.n; i++) {
        /* UPDATE tbl SET patch=substr(patch,1,at-1)||'"to"'||substr(patch,at+len) WHERE id=N AND <guard from> */
        o = num(cat(cat(cat(sql, "UPDATE "), tbl), " SET patch=substr(patch,1,"), h.at[i] - 1);
        o = num(cat(cat(cat(o, ")||'\""), to), "\"'||substr(patch,"), h.at[i] + (uint32_t)slen(from) + 2);
        o = num(cat(o, ") WHERE id="), (uint32_t)h.id[i]);
        slot_guard(cat(o, " AND "), h.at[i], from);
        int ok = !kn_pt_query(sql, 0, 0), now = 0;
        if (ok) {                                                 /* the row really has `to` there now */
            o = num(cat(cat(cat(sql, "SELECT count(*) FROM "), tbl), " WHERE id="), (uint32_t)h.id[i]);
            slot_guard(cat(o, " AND "), h.at[i], to);
            ok = !kn_pt_query(sql, count_cb, &now) && now == 1;
        }
        char m[72];
        o = cat(num(cat(cat(m, tbl), " id "), (uint32_t)h.id[i]), ok ? ": retired type, now " : ": retired type, rewrite failed");
        if (ok) cat(o, to);
        kn_log_line(from, m);
        changed += ok;
    }
    return changed;
}

void kn_presets_import(void)                                     /* kn_boot_hook, at its end */
{
    if (read_queue() > 0 && kn_presets_start()) {                 /* a live apply cut short: finish it now */
        live.booting = 1; live.drained = 1;
        while (live_step()) ;
        live_finish();
        live.booting = 0;
    }
    void *d = OPENDIR(ROOT);
    if (!d) return;                                               /* (the usual boot: one failed open) */
    CLOSEDIR(d);
    one_kind(0);
    one_kind(1);
}
