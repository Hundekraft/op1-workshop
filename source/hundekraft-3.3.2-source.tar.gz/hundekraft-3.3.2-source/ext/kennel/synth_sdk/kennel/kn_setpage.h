/*
 * The settings page's rows (kennel/kn_setpage.c; the screen is screens/settings.c, clock T3). ARCHITECTURE.md
 * "Settings page".
 *
 * Pages: the core pages first (4 slots each, blue / green / white / red; slots 0..11), then one or two pages per
 * plugin that declares plugin.json "settings" (extension tag KN_EXT_SETTINGS, docs/plugin-format.md), sorted by
 * plugin name; a bridged Opus file's rows (kn_settings_add_list) go on the one OPUS PLUGINS list instead (kn_sl_*).
 * Core page 1 is fixed: 0 COUNT-IN, 1 the first op1_switch (MIDI SEQ), 2 STEFAN, 3 CLICK (push FX).
 * Core page 2 is USB AUDIO (blue, slot 4) and TRACKS FROM (green, slot 5) (settings.c). Further op1_switch rows take slots 6..11 in registration order.
 *
 * Values: a plugin row lives in op1rsettings under "<plugin>.<key>" (rows may share a key as bit fields, `mask`).
 * The core keeps every declared key's stored word in RAM (read at registration from the DB): op1_setting_get and
 * op1_setting_set go through it for declared keys, op1_setting_value reads it from any thread. A turn changes the RAM
 * word at once; the DB write follows at the next key event (kn_setpage_flush, from settings_flush), on/off rows are
 * saved at once. A core row (kn_setting_core) has its own get / set: its owner applies and saves it (and may refuse).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_SETPAGE_H
#define KN_SETPAGE_H
#include <stdint.h>

#define KN_SET_ONOFF   1
#define KN_SET_CHOICE  2
#define KN_SET_NUMBER  3

#define KN_SET_RESTART 0x01        /* table row flags: a change takes effect at the next boot (toast) */
#define KN_SET_DIAG    0x02        /* shown only in the test build (KN_DIAG) */
#define KN_SET_HIDDEN  0x04        /* a push target: no row of its own */

#define KN_SET_CORE_SLOTS 12       /* core pages 1..3 */
#define KN_SET_SLOT_USBOUT 4       /* core page 2, blue: USB AUDIO (screens/settings.c); op1_switch rows skip it */
#define KN_SET_SLOT_USBFROM 5      /* core page 2, green: TRACKS FROM (screens/settings.c); op1_switch rows skip it */
#define KN_SET_SLOT_PICK 6         /* core page 2, white: PICKER STEP (screens/settings.c); op1_switch rows skip it */
#define KN_SET_PAGES_MAX  24
#define KN_SET_ARENA      6144     /* plugin tables, copied (bytes) */
#define KN_SET_KEYS       48       /* declared storage keys */

typedef struct {
    const char *label;                       /* stroke-font charset, at most 12 characters */
    uint8_t type, n;                         /* KN_SET_*; n choices */
    const char *const *choices;              /* choice labels (values are the index); 0 for on/off and number */
    int32_t min, max, step, def;             /* number range; def: what a push resets a choice / number row to */
    int32_t (*get)(void);                    /* any thread */
    void (*set)(int32_t v);                  /* KeyHandler: the owner applies and saves, may refuse (STEFAN) */
    const char *push_tag;                    /* drawn after the value while push_get() is on ("FX"); 0 = none */
    int32_t (*push_get)(void);
    void (*push_set)(int32_t v);
    int (*inactive)(void);                   /* optional: nonzero draws the value dim (the row still turns) */
} kn_setting_core_t;

/* a core row at slot 0..11 of page "core" (0 ok; -1 bad page / slot or the slot is taken by another row) */
int kn_setting_core(const char *page, int slot, const kn_setting_core_t *row);

/* a plugin's packed table (tag 7, or a compiled-in feature's): copied into the arena. 0 ok; -1 malformed (logged,
 * nothing kept: the plugin still loads), -2 no room (logged), -3 already there */
int kn_settings_add(const char *name, const uint8_t *tab, uint32_t len);
/* the same for a bridged Opus file (opus/opus_boot.c): its rows go on the one OPUS PLUGINS list page instead of a page
 * of their own (same keys, defaults, saved values and OP1_EV_SETTING); labels up to KN_SL_LABEL, choices up to
 * KN_SL_CHOICE characters. ctx: the file, passed to kn_sl_notify. */
int kn_settings_add_list(const char *name, const uint8_t *tab, uint32_t len, void *ctx);
/* set by the bridge: called on the main loop (kn_setpage_service) for each list row the page changed, with the row's
 * key and new value (the file's on_setting) */
extern void (*kn_sl_notify)(void *ctx, const char *key, int32_t value);
#define KN_SL_LABEL  24
#define KN_SL_CHOICE 14

/* ---- the page (screens/settings.c) ---- */
typedef struct {
    const char *label;                       /* upper case */
    char value[24];                          /* the value as drawn, with a push tag ("WOOD FX") */
    uint8_t dim;                             /* 1: the row is inactive, draw the value dim */
    const char *owner;                       /* list rows: the plugin's name (upper case); 0 on a page row */
    uint8_t vmax;                            /* list rows: the longest value the row can show (characters) */
} kn_sp_view;
int kn_sp_pages(void);                       /* 1.. */
const char *kn_sp_title(int page);           /* "SETTINGS" or the plugin's title */
int kn_sp_row(int page, int slot, kn_sp_view *v);   /* 1 = a row there (v filled), 0 = empty */
void kn_sp_turn(int page, int slot, int dir);       /* one detent: dir > 0 right (KeyHandler) */
void kn_sp_push(int page, int slot);                /* on/off flips, a push tag flips, choice / number: default */
/* the OPUS PLUGINS list (kn_settings_add_list's rows): grouped by plugin, plugins by name (A..Z), rows in table order;
 * not one of kn_sp_pages() (screens/settings.c puts it after the DEMO page, when kn_sl_count() > 0) */
int kn_sl_count(void);                              /* rows in the list */
int kn_sl_row(int i, kn_sp_view *v);                /* 1 = row i (v filled, v->owner its plugin), 0 = none */
void kn_sl_turn(int i, int dir);                    /* one step (KeyHandler) */
void kn_sl_reset(int i);                            /* back to the file's default */

/* the op1_switch rows in registration order (exported before 3.3; the page no longer uses them) */
int kn_switch_count(void), kn_switch_get(int i);
const char *kn_switch_label(int i);
void kn_switch_set(int i, int on);
uint32_t kn_setpage_used(void);              /* arena bytes taken */

/* ---- core plumbing ---- */
void kn_setpage_flush(void);                 /* KeyHandler, next key event: the deferred DB writes */
void kn_setpage_service(void);               /* main loop: OP1_EV_SETTING to the features whose rows changed */
int kn_setcache_get(const char *feature, const char *key, int32_t *out);   /* 1 = a declared key (its RAM word) */
void kn_setcache_put(const char *feature, const char *key, int32_t v);     /* op1_setting_set of a declared key */
int32_t kn_setting_db_get(const char *feature, const char *key, int32_t def);   /* kn_settings.c: the DB, no cache */
#endif
