/*
 * Patch saves that fit (2026-11-12, OP1-Emulator run/gin-fxcrash-2026-11-12/).
 *
 * R246's patch jobs (BgFileWorker; the slot save 0x01940574, the kit / preset loads 0x0193F578 / 0x019407DC and the
 * type jobs 0x0193F86C / 0x0193FFAC) serialize the slot's patch and format
 *     snprintf(0x01BA340C, 5000, "UPDATE drum_slots SET patch='%s' WHERE id=%i", patch, slot)   (or synth_slots)
 * then run it with db2_exec (0x0196F950), which stops the OP-1 on any SQLite error (db2.cpp:129). A patch over
 * about 4,950 bytes is cut before its closing quote: "unrecognized token: "'{"dbox_data":..."". A Gin kit reloaded
 * after a reboot is 5,040 bytes (R246's normalize adds dbox_data, 24 x 8 nulls), so any stock save of that slot (an
 * FX change: on/off, type, a knob) crashed on 3.3 beta 4 and 3.2.x. The quote is not escaped either: a ' in a
 * patch string would end the literal early.
 *
 * Each of the seven snprintf calls (make_firmware.py HOOKS hook_psql*) comes here instead, same arguments. The
 * statement is built with every ' doubled. If it fits the stock buffer it goes there, as before. If not, it is built
 * in our own buffer and run here, the same db2_exec on the same handle the stock code is about to use, and the stock
 * buffer gets a statement that does nothing. Past our buffer too (no patch this side of KN_PATCH_SQL_CAP is known),
 * nothing is written and a toast says so: the sound stays as it is in memory, the OP-1 keeps running.
 * Only BgFileWorker runs these jobs (or bgs_flush_sync after it stopped), one at a time: one static buffer.
 * The same for R246's inserts with user text (2026-11-21, the 3.3 / 3.3.1 drum kit upload crash, db2.cpp:129
 * 'near "11": syntax error': a ' in a kit name or folder): the user preset INSERT (0x019956F4) and the slot rows
 * (0x01995AA6 / 0x01995CEE), 8,192-byte stock buffers, our own 16 KB one (they run on the boot / main thread).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>
#include "kn_patch_sql.h"
#include "../kn_mem.h"

#ifdef OP1_HOST
extern int kn_patch_sql_host_snprintf(char *, unsigned, const char *, const char *, int);
extern int kn_patch_sql_host_snprintf3(char *, unsigned, const char *, uintptr_t, uintptr_t, uintptr_t);
extern void *kn_patch_sql_host_db(void);
extern void kn_patch_sql_host_exec(void *, const char *);
#define STOCK_SNPRINTF  kn_patch_sql_host_snprintf
#define STOCK_SNPRINTF3 kn_patch_sql_host_snprintf3
#define DB_HANDLE       kn_patch_sql_host_db
#define DB2_EXEC        kn_patch_sql_host_exec
#else
#define STOCK_SNPRINTF  ((int (*)(char *, unsigned, const char *, ...))0x01A4CCD8)
#define STOCK_SNPRINTF3 STOCK_SNPRINTF
#define DB_HANDLE       ((void *(*)(void))0x0196DD44)                    /* the op1.db handle the jobs pass */
#define DB2_EXEC        ((void (*)(void *, const char *))0x0196F950)     /* db2_exec: panics on an SQLite error */
#endif
void op1_toast(const char *text);                                        /* kn_core.c */
void kn_log_line(const char *file, const char *msg);                     /* kn_boot.c */

static char big[KN_PATCH_SQL_CAP];                                       /* BgFileWorker's patch jobs */
static char big_insert[KN_INSERT_SQL_CAP] kn_farbss;                    /* the inserts (boot / main thread) */
volatile uint32_t kn_patch_sql_big, kn_patch_sql_refused;               /* counts (monitor, tests) */
volatile uint32_t kn_insert_sql_big, kn_insert_sql_refused;
static const char nothing[] = "SELECT 1 WHERE 0;";

/* the statement fmt makes from the arguments in order (%s a string, ' doubled; %i / %d an int), written to out when
 * out is not 0; its length, or -1 for a format this does not know (anything but %s, %i, %d, %%, or more than 3) */
static int build(char *out, const char *fmt, const uintptr_t *arg)
{
    int n = 0, k = 0;
    for (const char *f = fmt; *f; f++) {
        if (*f != '%') { if (out) out[n] = *f; n++; continue; }
        f++;
        if (*f == '%') { if (out) out[n] = '%'; n++; continue; }
        if ((*f != 's' && *f != 'i' && *f != 'd') || k == 3) return -1;
        uintptr_t a = arg[k++];
        if (*f == 's') {
            for (const char *p = a ? (const char *)a : ""; *p; p++) {
                if (out) out[n] = *p;
                n++;
                if (*p == '\'') { if (out) out[n] = '\''; n++; }
            }
        } else {
            int id = (int)a;
            char d[12]; int m = 0; uint32_t v = id < 0 ? 0u - (uint32_t)id : (uint32_t)id;
            do { d[m++] = (char)('0' + v % 10u); v /= 10u; } while (v);
            if (id < 0) { if (out) out[n] = '-'; n++; }
            while (m--) { if (out) out[n] = d[m]; n++; }
        }
    }
    if (out) out[n] = 0;
    return n;
}

static void copy(char *dst, const char *src) { while ((*dst++ = *src++)) ; }

/* the statement into buf when it fits; else built in own[] and run here (the stock code then runs the no-op); past
 * own[] nothing is written and a toast says so. -1: a format build() does not know (the caller uses the stock one). */
static int place(char *buf, unsigned cap, const char *fmt, const uintptr_t *arg, char *own, unsigned own_cap,
                 volatile uint32_t *bigs, volatile uint32_t *refused, const char *toast)
{
    int n = build(0, fmt, arg);
    if (n < 0) return -1;
    if ((unsigned)n < cap) { build(buf, fmt, arg); return n; }
    if (cap <= sizeof nothing) return -1;                                 /* no room even for the no-op */
    if ((unsigned)n < own_cap) {
        build(own, fmt, arg);
        DB2_EXEC(DB_HANDLE(), own);
        (*bigs)++;
    } else {
        (*refused)++;
        kn_log_line("sound", "patch too big to save, not saved");
        op1_toast(toast);
    }
    copy(buf, nothing);
    return n;
}

int kn_patch_sql(char *buf, unsigned cap, const char *fmt, const char *patch, int id)
{
    uintptr_t arg[3] = { (uintptr_t)patch, (uintptr_t)id, 0 };
    int n = place(buf, cap, fmt, arg, big, sizeof big, &kn_patch_sql_big, &kn_patch_sql_refused, "Sound too big to save");
    return n < 0 ? STOCK_SNPRINTF(buf, cap, fmt, patch, id) : n;          /* not one of ours: as before */
}

/* R246's inserts: the user preset (fat_interface 0x019955EC: table, patch, folder) and the slot rows (0x01995A40 /
 * 0x01995C88: id, patch). Only db2_exec's callers on the boot / main thread reach these (the disk sync, the
 * hold-to-save, kennel's preset import), never BgFileWorker: their own buffer, not big[]. */
static int insert3(char *buf, unsigned cap, const char *fmt, uintptr_t a, uintptr_t b, uintptr_t c)
{
    uintptr_t arg[3] = { a, b, c };
    int n = place(buf, cap, fmt, arg, big_insert, sizeof big_insert, &kn_insert_sql_big, &kn_insert_sql_refused,
                  "Sound too big to save");
    return n < 0 ? STOCK_SNPRINTF3(buf, cap, fmt, a, b, c) : n;
}

int kn_insert_sql(char *buf, unsigned cap, const char *fmt, const char *table, const char *patch, const char *folder)
{
    return insert3(buf, cap, fmt, (uintptr_t)table, (uintptr_t)patch, (uintptr_t)folder);
}

int kn_slot_insert_sql(char *buf, unsigned cap, const char *fmt, int id, const char *patch)
{
    return insert3(buf, cap, fmt, (uintptr_t)id, (uintptr_t)patch, 0);
}
