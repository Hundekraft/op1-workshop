/*
 * FX switch declick (2026-11-11, ARCHITECTURE.md "FX switch declick"; OP1-Emulator run/fxlist-click-2026-11-11/).
 *
 * Scrolling an FX list swaps the live effect at every row with no fade (R246's own behaviour: core_set_mono_fx
 * 0x019679CC builds the new object in place; the master's core_create_master_fx 0x01967A24 likewise), so the output
 * steps by up to ~90 % of the signal's peak in one sample. Every mono and master FX render now passes through
 * kennel, which removes that step with a decaying offset (kn_declick.h):
 *   mono   the seven stock mono FX vtables' render slot (make_firmware.py SLOTS kn_dc_mono_*: delay, grid, punch,
 *          phone, spring, nitro, cwo) and the filter type's fx_render (dispatcher.c: the stock filter and every
 *          plugin FX). One state: R246 has one mono FX object, for the synth or the drum position.
 *   master fr_route (screens/fxroute.c), which every master render already goes through (the filter's and the seven
 *          ml_st_* wrappers), after the FX2 routing has mixed the result back: what the listener hears.
 * Identity: the stock render's address, or for the filter type the plugin index and the init epoch (kn_fx_ident).
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>
#include "kn_declick.h"
#include "kn_mem.h"
#include "kn_src.h"                              /* page 7's named sources (test build): the declick is KN */

#define FRAME_COUNTER (*(volatile uint32_t *)0xFF8016E0)        /* one per audio block */
#define OP1_BLOCK 64

uint32_t kn_fx_ident(int master);                                /* dispatcher.c */

static kn_dc_t dc_mono kn_hot, dc_l kn_hot, dc_r kn_hot;
volatile uint32_t kn_dc_stats[4];   /* mono switches, master switches, largest mono step, largest master step (abs) */

volatile uint32_t kn_dc_log[16][4];  /* the last 16 switches: block, position (0 mono, 1 master), new identity (master: previous last sample << 16 | first output sample, left), step */
static uint32_t dc_log_n;
static void kn_dc_note(int i, int32_t off, uint32_t id)
{
    volatile uint32_t *e = kn_dc_log[dc_log_n++ & 15];
    e[0] = FRAME_COUNTER; e[1] = (uint32_t)i; e[2] = id; e[3] = (uint32_t)off;
    if (off < 0) off = -off;
    kn_dc_stats[i]++;
    if ((uint32_t)off > kn_dc_stats[i + 2]) kn_dc_stats[i + 2] = (uint32_t)off;
}

kn_audio_text void kn_dc_mono(uint32_t id, int16_t *buf, int16_t dry0)
{
    uint16_t n0 = dc_mono.switches;
    kn_dc_run(&dc_mono, id, buf, OP1_BLOCK, dry0, FRAME_COUNTER);
    if (dc_mono.switches != n0) kn_dc_note(0, dc_mono.step, id);
}

kn_audio_text void kn_dc_master(const void *fx, int16_t *l, int16_t *r, int16_t l0, int16_t r0)
{
    uint32_t id = ((uint32_t)fx ^ kn_fx_ident(1) << 1) | 1u;
    uint32_t blk = FRAME_COUNTER;
    uint16_t n0 = dc_l.switches;
    int16_t prev = dc_l.last;
    kn_dc_run(&dc_l, id, l, OP1_BLOCK, l0, blk);
    kn_dc_run(&dc_r, id, r, OP1_BLOCK, r0, blk);
    if (dc_l.switches != n0) kn_dc_note(1, (dc_l.step < 0 ? -dc_l.step : dc_l.step) > (dc_r.step < 0 ? -dc_r.step : dc_r.step) ? dc_l.step : dc_r.step, (uint32_t)(uint16_t)prev << 16 | (uint16_t)l[0]);
}

/* R246's swap has the FX pointer empty for a block: no render, the dry bus goes out (OP1-Emulator
 * run/fxlist-click-2026-11-11: about every second row in the emulator, mostly at the master). These run before the
 * render would: the mono one at the end of the input bus hook (kennel/kn_input.c, every block, all three modes), the
 * master one from an L1 trampoline in R246's output stage (make_firmware.py L1_PCCALLS 0xFFA01202, hook.S
 * _l1_tramp_mfx -> _kn_dc_mfx_entry), after the master EQ and right before R246 tests the master FX pointer, so the
 * dry block it shapes is in the same place in the chain as the master FX's output. */
#define MONO_FX_PTR(pos) (((void *volatile *)0x01AAAD60)[pos])   /* synth 0, drum 1 */
#define MASTER_FX_PTR    (*(void *volatile *)0x01AAAD68)
#define MASTER_FX_ON     (*(volatile uint8_t *)0x01AAAC40)
kn_audio_text void kn_dc_mono_gap(int pos, int16_t *bus)
{
    if (MONO_FX_PTR(pos)) return;
    uint16_t n0 = dc_mono.switches;
    if (kn_dc_gap(&dc_mono, bus, OP1_BLOCK, FRAME_COUNTER) && dc_mono.switches != n0) kn_dc_note(0, dc_mono.step, KN_DC_DRY);
}
void kn_bus_master_pre(int16_t *l, int16_t *r), kn_bus_master_post_site(int16_t *l, int16_t *r);   /* kennel/kn_bus.c */
kn_audio_text void kn_dc_master_gap(int16_t *l, int16_t *r);
/* the L1 entry's C side (hook.S _kn_dc_mfx_entry): a master bus insert before the master FX, the gap declick, then a
 * post-FX master insert when R246 will not render the master FX */
kn_audio_text void kn_mfx_site(int16_t *l, int16_t *r)
{
    kn_bus_master_pre(l, r);
    kn_dc_master_gap(l, r);
    kn_bus_master_post_site(l, r);
}
kn_audio_text void kn_dc_master_gap(int16_t *l, int16_t *r)
{
    if (!MASTER_FX_ON || MASTER_FX_PTR) return;
    KD_T0(t0);
    uint32_t blk = FRAME_COUNTER;
    uint16_t n0 = dc_l.switches;
    kn_dc_gap(&dc_l, l, OP1_BLOCK, blk);
    kn_dc_gap(&dc_r, r, OP1_BLOCK, blk);
    if (dc_l.switches != n0) kn_dc_note(1, dc_l.step, KN_DC_DRY);
    KD_LEAF(KD_SRC_KN, t0);
}

/* the seven stock mono FX renders other than the filter: render(this, int16_t bus[64], params[8]); then a post-FX bus
 * insert (kennel/kn_bus.c; the filter type's fx_render calls it after its own timing, dispatcher.c) */
void kn_bus_after_fx(int16_t *bus);
typedef void (*kn_dc_render_t)(void *, int16_t *, const int16_t *);
#define DC_WRAP(name, k, orig) \
    kn_audio_text void name(void *self, int16_t *buf, const int16_t *p) \
    { int16_t d0 = buf[0]; ((kn_dc_render_t)(orig))(self, buf, p); KD_T0(t0); kn_dc_mono(k, buf, d0); KD_LEAF(KD_SRC_KN, t0); kn_bus_after_fx(buf); }
DC_WRAP(kn_dc_mono_delay,  1, 0x0197D8C4)
DC_WRAP(kn_dc_mono_grid,   2, 0x019AF338)
DC_WRAP(kn_dc_mono_punch,  3, 0x019E6260)
DC_WRAP(kn_dc_mono_phone,  4, 0x01A1BB74)
DC_WRAP(kn_dc_mono_spring, 5, 0x01A326E8)
DC_WRAP(kn_dc_mono_nitro,  6, 0x019A62A4)
DC_WRAP(kn_dc_mono_cwo,    7, 0x0194480C)
