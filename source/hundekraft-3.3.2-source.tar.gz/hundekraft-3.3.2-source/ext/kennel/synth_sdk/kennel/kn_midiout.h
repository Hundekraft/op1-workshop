/* USB MIDI out after Scale and Chord (kennel/kn_midiout.c): the note pipeline's side.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_MIDIOUT_H
#define KN_MIDIOUT_H
#include "../op1_feature.h"
/* op1_note.pad[0..2] of a note from a key on the pipeline path, cleared at the sink. R246 leaves the pad bytes of its
 * records uninitialised (stack), so note_pipe_on/_off zero them on every note and the mark is three bytes. */
#define KN_MO_MARK0 0xA5
#define KN_MO_MARK1 0x4D
#define KN_MO_MARK2 0x4F
#define KN_MO_MARKED(n) ((n)->pad[0] == KN_MO_MARK0 && (n)->pad[1] == KN_MO_MARK1 && (n)->pad[2] == KN_MO_MARK2)
int kn_mo_route_on(const op1_note *n, op1_note *copy);    /* note_pipe_on: *copy = n with pad zeroed (marked: 1, the pipeline path) */
void kn_mo_routed_on(int key);                            /* ... after the pipeline ran: drop the stock tail's raw on */
int kn_mo_route_off(const op1_note *n, op1_note *copy);   /* note_pipe_off: the same; 1 = this key's on took the pipeline path */
void kn_mo_routed_off(int key);                           /* ... after the pipeline ran: the stuck-note guard */
int kn_mo_sink(const op1_note *n, op1_note *vc, int on);  /* past the last stage: 1 = marked, VoiceCtl gets *vc */
void kn_mo_stock_on(int note, int velocity);              /* hook.S: VoiceCtl's CALL midi_note_on_out */
void kn_mo_stock_off(int note);                           /* hook.S: VoiceCtl's CALL midi_note_off_out */
void kn_mo_reset(void);                                   /* kn_notes_reset */
int kn_mo_out_count(int note);                            /* tests: routed notes holding this out note */
#endif
