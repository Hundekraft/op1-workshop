/* Patch saves that fit (kn_patch_sql.c). Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE). */
#ifndef KN_PATCH_SQL_H
#define KN_PATCH_SQL_H
#include <stdint.h>
/* our statement buffer: the largest known patch is a Gin kit after a reboot, 5,040 bytes (gin_fw_snapshot.c puts its
 * upper bound near 6,100 with every ' doubled); 8 KB as Gin's own working save (SQL_CAP) */
#define KN_PATCH_SQL_CAP 8192u
/* R246's snprintf(buf, cap, "UPDATE ..._slots SET patch='%s' WHERE id=%i", patch, id) at the seven patch-job sites
 * (make_firmware.py HOOKS hook_psql*): same arguments, same place on the stack */
int kn_patch_sql(char *buf, unsigned cap, const char *fmt, const char *patch, int id);
extern volatile uint32_t kn_patch_sql_big, kn_patch_sql_refused;
/* R246's inserts format into 8,192 bytes (0x01CFEBC0, 0x01D00BC0, 0x01D02BC0); a longer statement runs from our own
 * buffer (.farbss), up to this */
#define KN_INSERT_SQL_CAP 16384u
/* snprintf(buf, 8192, "INSERT INTO %s (patch,folder) VALUES('%s','%s')", table, patch, folder): the user preset insert
 * (fat_interface 0x019955EC; the disk sync, hold-to-save, kennel's preset import; HOOKS hook_isql1) */
int kn_insert_sql(char *buf, unsigned cap, const char *fmt, const char *table, const char *patch, const char *folder);
/* snprintf(buf, 8192, "INSERT INTO synth_slots|drum_slots VALUES(%i,'%s')", id, patch): the slot rows (0x01995A40 /
 * 0x01995C88; HOOKS hook_isql2 / hook_isql3) */
int kn_slot_insert_sql(char *buf, unsigned cap, const char *fmt, int id, const char *patch);
extern volatile uint32_t kn_insert_sql_big, kn_insert_sql_refused;
#endif
