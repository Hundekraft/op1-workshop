/*
 * MIDI sequencer, as a kennel feature (op1r 35: op1r-src 5c90efb seqdev/ms_fw.c, pcppcp, rebuilt on kennel's
 * services; the core is ms_core.c, the view ms_draw.c, both unchanged from op1r).
 * 4 tracks of notes and CCs on the tape timeline, in one song file (user/op1r_seq.mseq, the same file and format as
 * op1r 35), played with the tape (PLAY / STOP stay the tape's).
 *   switch      settings page (clock, T3), green "midi seq": off = SEQ + TAPE stock, nothing allocated, no work;
 *               switching off closes the view, silences, saves what is pending, then idles. Saved, default off.
 *   view        hold SEQ and press TAPE (kennel's SEQ + TAPE view); TAPE alone or another mode key leaves it (the
 *               sequencer keeps playing with the tape). In the view: T1..T4 select the track (Shift: mute), REC held =
 *               record the selected track (Shift + REC: latched, STOP ends it), scissors marks the selection start /
 *               end, lift cuts it from the selected track (no selection: the 1.5 s page under the playhead), Shift +
 *               lift from all tracks, then the playhead jumps to the first lifted note; drop pastes with the first note
 *               at the playhead; white press switches between the track's input and output, white turn steps through
 *               i (instrument / keyboard), s (stock sequencer), m1..m16 (MIDI channel); red press and Shift + red
 *               turn are the tape markers, as on the tape screen.
 *   recording   input i: notes from the keyboard; s: notes the stock sequencers and kennel's sequencer types play
 *               (op1_note_source); m<ch>: notes and CCs received on that MIDI channel (midi_raw). Inputs i / s also
 *               take CCs on the OP-1's MIDI channel.
 *   playback    output i: notes to the instrument (op1_key_down / up), CCs 53-60 / 72-79 to the synth knobs
 *               (midicc.h), other CCs to the stock CC table (MIDI LFO); s: notes into the current stock sequencer
 *               (op1_stock_seq_key); m<ch>: USB MIDI out on that channel.
 * Threads: recording inputs are queued from any thread and inserted by the audio thread (tape hook `block`); the main
 * loop (tape hook `service`) loads, prefetches and saves; keys and encoders on the KeyHandler thread (`input`).
 * Copyright (C) 2026 Hundekraft, pcppcp. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef OP1_HOST
#pragma GCC optimize ("Os", "no-tree-loop-distribute-patterns")
#endif
#include "../op1_synth.h"
#include "../op1_feature_midi.h"
#include "../op1_feature_tape.h"
#include "../seq/seq_text.h"
#include "ms_core.h"
#include "ms_draw.h"
#include "midicc.h"

#define MS_FILE     "/yaffs2/user/op1r_seq.mseq"
#define MS_HEAD_SZ  4096

#ifdef OP1_HOST
/* host (harness/midiseq_test.c): the tape and the MIDI channel as plain data */
extern int32_t host_tape_pos, host_loop_in, host_loop_out, host_located;
extern int host_tape_state, host_loop_on, host_midi_ch;
extern uint32_t host_bpm_bits;
int32_t op1_tape_zoom_q10(void);                       /* op1_feature_tape.h's is firmware-only */
static uint32_t irq_off(void) { return 0; }
static void irq_on(uint32_t m) { (void)m; }
#define TAPE_STATE  host_tape_state
#define TAPE_POS_S  host_tape_pos
#define LOOP_IN     host_loop_in
#define LOOP_OUT    host_loop_out
#define LOOP_ON     host_loop_on
#define MIDI_CH     host_midi_ch
#define BPM_BITS    host_bpm_bits
#define LOCATE(p)   (host_located = (p))
#define VC_MIDI_MSG(v) ((void)(v))
void host_dispatch_key(int code, int pressed);
#define KEY_DISPATCH host_dispatch_key
#define SHIFT       host_shift
/* Print: R246's record node and set_mode's words as plain data (tests: midiseq_print_test.c) */
uint8_t pr_host_started, pr_host_recflag, pr_host_fwd = 1;
int16_t pr_host_target;
int32_t pr_host_run, pr_host_node, pr_host_ext[2];
int pr_host_clips_ok = 1;
void host_set_mode(void);
#define TAPE_RUN    pr_host_run
#define REC_STARTED pr_host_started
#define REC_NODE    pr_host_node
#define REC_TARGET  pr_host_target
#define REC_FLAG    pr_host_recflag
#define EXT_LO      pr_host_ext[0]
#define EXT_HI      pr_host_ext[1]
#define FWD()       pr_host_fwd
#define CLIPS_OK()  pr_host_clips_ok
#define SET_MODE()  host_set_mode()
#define PR_STEFAN() 0
#define PR_FLASH_LOW() 0
#else
static uint32_t irq_off(void) { uint32_t m; __asm__ volatile ("cli %0;" : "=d"(m)); return m; }
static void irq_on(uint32_t m) { __asm__ volatile ("sti %0;" : : "d"(m)); }
#define TAPE_STATE  (*(volatile int32_t *)0x018C17D4)
extern volatile int32_t tm_xoff;                                    /* STEFAN's transport keep-alive jumps (tape/tm.c) */
#define TAPE_POS_S  ((*(volatile int32_t *)0xFF802974 >> 6) + tm_xoff)    /* 1/64 samples -> samples; with STEFAN live the
                                                                     * transport is moved back 3 min past 5:00: tm_xoff
                                                                     * adds it back, so the sequence runs on (0 otherwise) */
#define LOOP_IN     (*(volatile int32_t *)0x01B4EF34)
#define LOOP_OUT    (*(volatile int32_t *)0x01B4EF38)
#define LOOP_ON     (*(volatile uint8_t *)0xFF8029C5)
#define MIDI_CH     (*(volatile int *)0x01AADB20 & 15)                 /* the OP-1's MIDI channel */
#define BPM_BITS    (*(volatile uint32_t *)0x018C1878)                 /* tempo, float 40..220 (read as bits) */
#define LOCATE(p)   (((void (*)(int32_t))0x01A55024)(p))               /* tape locate */
#define VC_MIDI_MSG ((void (*)(void *))0x01A84F8C)                     /* VoiceCtl::midi_message (CC table) */
#define KEY_DISPATCH ((void (*)(int, int))0x019B6C74)
#define SHIFT       (*(volatile uint8_t *)0x01DD7F78)
/* Print: R246's record node (L1 0xFFA06334, after the tape block hook in each callback) and set_mode's words; the
 * same use as the punch plugin's quantized punch (tape/punch.c, ARCHITECTURE.md "Quantized punch") */
#define TAPE_RUN    (*(volatile int32_t *)0xFF802960)     /* 1 recording, 2 playing: set_mode makes a clip only from 1 */
#define REC_STARTED (*(volatile uint8_t *)0x018C17D8)     /* the node's started flag: 0 + run 1 = its start path */
#define REC_NODE    (*(volatile int32_t *)0x018C17EC)     /* the node's cache entry (0: looked up again) */
#define REC_TARGET  (*(volatile int16_t *)0xFF8029E0)     /* the node's gain target */
#define REC_FLAG    (*(volatile uint8_t *)0xFF8029EC)     /* the extent grows only while 1 */
#define EXT_LO      (*(volatile int32_t *)0xFF8029E4)     /* the recorded extent: set_mode's clip */
#define EXT_HI      (*(volatile int32_t *)0xFF8029E8)
#define FWD()       (*(volatile uint8_t *)0x018C17D0 != 0) /* tape_direction_forward */
#define SET_MODE()  (((void (*)(void))0x01A581F4)())      /* TapeController::set_mode */
static int pr_clips_ok(void)                             /* the stock REC-press checks: clips left, clipboard idle */
{
    if (*(int32_t *)((uint8_t *)((void *(*)(void))0x0195BBB4)() + 0x1A00) < 1) return 0;
    return ((int (*)(void))0x0191C750)() != 0 && ((int (*)(void))0x0191554C)() == 0;
}
#define CLIPS_OK()  pr_clips_ok()
#define PR_STEFAN() op1_tape_stefan()
static int pr_flash_low(void)                            /* the tapes feature's REC rule on tapes 2..4: 32 MB free */
{
    op1_storage_t st;
    return op1_tape_current() != 0 && op1_storage(&st) && st.bytes[OP1_STORE_FREE] < (32u << 20);
}
#define PR_FLASH_LOW() pr_flash_low()
#endif

static ms_t *ms;                                       /* op1_alloc'd (about 60 KB) once switched on */
static volatile uint8_t on;                            /* op1_switch_on("midiseq"), followed on the main loop */
static volatile uint8_t rec_held, rec_latch, own_play;
static int32_t sel_a = -1, sel_b = -1;
static uint8_t sel_set, io_sel;                        /* io_sel: white edits 0 output, 1 input */
static int io_acc;
static volatile uint8_t rec_arm, arm_go, ci_latch, take_done, quant_dirty;
static int ms_quant, quant_acc;
static volatile uint8_t quant_req;
static int32_t quant_a, quant_b;
static int quant_track;
static int32_t bpm_q8(void);
/* Print (Shift + drop in the view): the state, read by e_play and the block hook */
enum { PR_IDLE, PR_REQ, PR_ARMED, PR_HOLD, PR_REC, PR_CLOSED, PR_ENDED };
static volatile uint8_t pr, pr_opened, pr_now, pr_prev_run, pr_was_muted, pr_stuck;
static volatile uint32_t pr_wait;                      /* blocks (64 samples) spent waiting for Shift / in the pre-roll */
#define PR_SHIFT_MAX  2756                             /* Shift still down after 4 s: the print is dropped */
#define PR_PREROLL_MAX 4134                            /* 6 s from PLAY and the pre-roll hasn't reached the first note */
static volatile int8_t pr_solo = -1;                   /* the track being printed: the only one that plays */
static volatile int32_t pr_in, pr_out, pr_last_on, pr_last, pr_lo, pr_hi;


/* ---- env ---- */
static int32_t e_pos(void) { return TAPE_POS_S; }
static int e_playing(void) { int st = TAPE_STATE; return st == 10 || st == 9 || st == 4 || st == 5; }
static int e_loop(int32_t *a, int32_t *b) { *a = LOOP_IN; *b = LOOP_OUT; return LOOP_ON; }
static void e_play(int t, int dest, int ch, int kind, int d1, int d2, int note_on)
{
    if (pr_solo >= 0) {                                           /* printing: one track, its notes in the span */
        if (t != pr_solo) return;
        int32_t ph = TAPE_POS_S;
        if (kind == MS_NOTE && note_on && (ph < pr_in - 64 || ph > pr_last_on + 64)) return;
    }
    if (dest == MS_DEST_MIDI) {                                   /* USB MIDI out, the track's channel */
        uint8_t m[3] = { (uint8_t)((kind == MS_CC ? 0xB0 : note_on ? 0x90 : 0x80) | (ch & 15)), (uint8_t)d1,
                         (uint8_t)(kind == MS_CC ? d2 : note_on ? d2 : 64) };
        op1_midi_send(m, 3);
        return;
    }
    if (kind == MS_CC) {
        if (midicc_set(d1, d2)) return;                           /* synth knobs (CC automation map) */
        static uint8_t msg[3];                                    /* else as a received CC: stock CC table, MIDI LFO */
        static struct { uint32_t a; uint8_t *b, *e; uint32_t c; } vec;
        msg[0] = (uint8_t)(0xB0 | (ch & 15)); msg[1] = (uint8_t)d1; msg[2] = (uint8_t)d2;
        vec.b = msg; vec.e = msg + 3;
        VC_MIDI_MSG(&vec);
        return;
    }
    if (dest == MS_DEST_SEQ) { op1_stock_seq_key(d1, note_on); return; }
    op1_note n = { d1, note_on ? d2 : 0, 0, { 0 }, 0 };
    own_play = 1;
    if (note_on) op1_key_down(&n, 0); else op1_key_up(&n);
    own_play = 0;
}
/* the song file through the core's file service (main loop only, as ms_core calls these) */
/* 0 ok; 1 the file ends before (none yet: opening creates it empty, so a failed open is a read error, also when all
 * 8 handles are taken); -1 read error (retried, nothing written) */
static int e_read(int off, void *p, int n)
{
    int fd = op1_file_open(MS_FILE, OP1_FILE_RDWR | OP1_FILE_CREATE), r = -1;
    if (fd < 0) return -1;
    if (op1_file_seek(fd, off, 0) == off) { int k = op1_file_read(fd, p, n); r = k == n ? 0 : k >= 0 ? 1 : -1; }
    op1_file_close(fd);
    return r;
}
static int e_write(int off, const void *p, int n)
{
    int fd = op1_file_open(MS_FILE, OP1_FILE_RDWR | OP1_FILE_CREATE), r = -1;
    if (fd < 0) return -1;
    if (op1_file_seek(fd, off, 0) == off && op1_file_write(fd, p, n) == n) r = 0;
    op1_file_close(fd);
    return r;
}
static int e_rs(int sl, ms_slot *o) { return e_read(MS_HEAD_SZ + sl * (int)sizeof(ms_slot), o, (int)sizeof *o); }
static int e_ws(int sl, const ms_slot *i) { return e_write(MS_HEAD_SZ + sl * (int)sizeof(ms_slot), i, (int)sizeof *i); }
static int e_rh(void *h, int n) { return e_read(0, h, n); }
static int e_wh(const void *h, int n) { return e_write(0, h, n); }
static const ms_env env = { e_pos, e_playing, e_loop, e_play, e_rs, e_ws, e_rh, e_wh, irq_off, irq_on };

/* ---- recording inputs: queued from any thread, inserted by the audio thread ---- */
#define QN 64
static struct { uint8_t cc, d1, d2, ch; } q[QN];
static volatile uint32_t qw, qr;
static void q_put(int cc, int d1, int d2, int ch)
{
    uint32_t m = irq_off();
    if (qw - qr < QN) { q[qw % QN].cc = (uint8_t)cc; q[qw % QN].d1 = (uint8_t)d1; q[qw % QN].d2 = (uint8_t)d2; q[qw % QN].ch = (uint8_t)ch; __asm__ volatile("" ::: "memory"); qw++; }
    irq_on(m);
}
static int recording(void) { return ms && on && op1_tape_view_open() && (rec_held || rec_latch || rec_arm); }
static int waiting(void) { return !e_playing() && (rec_arm || (rec_held && !ci_latch)); }
static void cancel_recording(void)
{
    if (ci_latch) op1_countin_cancel();
    uint32_t m=irq_off(); rec_held=rec_latch=rec_arm=arm_go=ci_latch=0; qr=qw; irq_on(m);
}
static int in_kind(void) { return ms->h.in[ms->sel & 3] & 15; }
static int src_kind(void)                               /* the note's source as a track input, -1: not recordable */
{
    int s = OP1_SRC_KIND(op1_note_source());
    return s == OP1_SRC_KEYS ? MS_DEST_INSTR : s == OP1_SRC_PLAYER ? MS_DEST_SEQ : -1;   /* MIDI: from midi_raw */
}
static void ni_down(const op1_note *n, int param)
{
    (void)param;
    if (own_play || ci_latch || !recording() || n->note < 0 || n->note > 127 || src_kind() != in_kind()) return;
    q_put(0, n->note, n->velocity < 1 ? 100 : n->velocity > 127 ? 127 : n->velocity, 1);
    if (waiting()) { rec_arm=1; arm_go=1; }
}
static void ni_up(const op1_note *n)
{
    if (own_play || ci_latch || !recording() || n->note < 0 || n->note > 127 || src_kind() != in_kind()) return;
    q_put(0, n->note, 0, 0);
}
static const op1_note_input note_in = { ni_down, ni_up };
/* every received MIDI message: input m<ch> takes notes and CCs on its channel; inputs i / s take CCs on the OP-1's
 * MIDI channel (what stock receives) */
static void raw_in(const uint8_t *m, int len)
{
    if (len < 3 || ci_latch || !recording()) return;
    int st = m[0] & 0xF0, ch = m[0] & 15;
    if (st != 0x80 && st != 0x90 && st != 0xB0) return;
    int in = ms->h.in[ms->sel & 3];
    int mine = (in & 15) == MS_DEST_MIDI ? ch == in >> 4 : st == 0xB0 && ch == MIDI_CH;
    if (!mine) return;
    if (st == 0xB0) q_put(1, m[1], m[2], ch);
    else q_put(0, m[1], st == 0x90 ? m[2] : 0, st == 0x90 && m[2]);
    if (st==0x90 && m[2] && waiting()) { rec_arm=1; arm_go=1; }   /* note on with velocity 0 = off */
}

/* ---- Print: the selected track (output I) played into a take on the tape's selected track ----
 * Main loop (pr_start): the span = the track's notes (in the selection if there is one), from the first note-on to the
 * last note-off plus a bar, its end up to the next beat; locate a beat before it, arm, PLAY: one take. The track plays
 * alone (e_play). Audio thread (pr_block, before R246's record node in the same callback): hold the node at gain 0 (it
 * adds to the track, so nothing changes) until the block before the first note, then let its own start path fade in
 * and reset the extent; at the end, run 2 (its stop path fades out). Main loop (pr_finish): the extent = the span,
 * run 1, STOP: set_mode makes the clip, REC before / after are R246's, so a print is one undo step. Then the MIDI track
 * is muted. STOP during a print, or leaving the view, ends it where it is (nothing kept before the first note). */
static void pr_block(void)
{
    if (pr == PR_REQ) { if (pr_wait < 0xFFFF) pr_wait++; return; }     /* waiting for Shift to be released */
    if (pr < PR_ARMED || pr == PR_ENDED) return;
    if (pr < PR_REC && !pr_now && pr_wait++ > PR_PREROLL_MAX) { pr_now = 1; pr_stuck = 1; }   /* the pre-roll is stuck */
    if (pr < PR_REC && !pr_now && !FWD()) { pr_now = 1; pr_stuck = 1; }   /* the tape turned round: end it */
    int run = TAPE_RUN, st = TAPE_STATE, prev = pr_prev_run, rec = st == 4 || st == 5 || st == 7;
    int32_t pos = TAPE_POS_S, blk = pos - pr_last;
    pr_prev_run = (uint8_t)run; pr_last = pos;
    if (blk <= 0 || blk > 64 * 16) blk = 64;
    if (pr == PR_ARMED) {
        if (pr_now) { if (run == 1 && rec) { pr_in = pos; pr_out = pos; pr_lo = EXT_LO; pr_hi = EXT_HI; TAPE_RUN = 2; pr = PR_CLOSED; } else pr = PR_ENDED; return; }
        if (run != 1 || !rec) return;                             /* PLAY not through yet */
        if (prev == 1 || REC_STARTED) { pr = PR_ENDED; return; }   /* not our take */
        if (pos <= pr_in && pos + 2 * blk > pr_in) { pr = PR_REC; pr_opened = 1; }   /* at the first note already */
        else { REC_STARTED = 1; REC_NODE = 0; REC_TARGET = 0; pr = PR_HOLD; pr_opened = 0; }   /* (also while the
                                                                  * locate to the pre-roll hasn't landed yet) */
    }
    if (pr == PR_CLOSED) { if (run == 1) TAPE_RUN = 2; return; }  /* a set_mode from elsewhere: stay closed */
    if (!rec || run != 1) { pr = PR_ENDED; return; }              /* stopped elsewhere */
    if (pr == PR_HOLD) {
        REC_TARGET = 0;
        if (!pr_now && !(pos <= pr_in && pos + 2 * blk > pr_in)) return;   /* only in the block before the note */
        if (!pr_now) { REC_STARTED = 0; pr = PR_REC; pr_opened = 1; return; }   /* the start path: fade in */
    }
    int32_t late = LOOP_ON && pr_out >= LOOP_OUT ? blk : 0;       /* the loop end: close in the block that reaches it */
    if (pr_now || pos + late >= pr_out) {
        if (pr_now) pr_out = pos;
        pr_lo = EXT_LO; pr_hi = EXT_HI;
        TAPE_RUN = 2;                                             /* the stop path: fade out, then nothing */
        pr = PR_CLOSED;
    }
}

static void pr_end(int printed)                                   /* main loop */
{
    int t = pr_solo;
    pr_solo = -1;
    if (ms) { uint32_t m = irq_off(); ms_all_off(ms); irq_on(m); }
    if (ms && t >= 0) { ms->h.mute[t] = printed ? 1 : pr_was_muted; ms->head_dirty = 1; }   /* played through a mute */
    if (printed && t >= 0) op1_toast("Printed. MIDI track muted");
    else if (pr_stuck) op1_toast("Print didn't start");
    else if (pr >= PR_ARMED) op1_toast("Print stopped");
    pr = PR_IDLE; pr_now = 0; pr_stuck = 0;
}
static void pr_finish(void)                                       /* main loop: the gate is closed */
{
    int st = TAPE_STATE, printed = pr_opened && !pr_now;
    uint32_t m = irq_off();
    REC_STARTED = 1; REC_TARGET = 0; REC_NODE = 0; REC_FLAG = 0;  /* run 1 without the start path, extent frozen */
    if (!pr_opened) { EXT_LO = 0x7FFFFFFF; EXT_HI = (int32_t)0x80000000; }   /* never opened: no clip */
    else { EXT_LO = pr_in; EXT_HI = pr_out > pr_in ? pr_out : pr_in + 1; }
    TAPE_RUN = 1; pr_prev_run = 1;
    irq_on(m);
    if (st == 4 || st == 5 || st == 7) { KEY_DISPATCH(0x23, 1); KEY_DISPATCH(0x23, 0); }   /* STOP: set_mode, the clip */
    else SET_MODE();                                              /* stopped meanwhile: set_mode makes the clip */
    pr_end(printed);
}
/* first note-on, last note-on and last note-off of track t in [a, b) (main loop: loads each page it reads) */
static int pr_span(int t, int32_t a, int32_t b, int32_t *first, int32_t *last_on, int32_t *last_off)
{
    static ms_ev ev[64]; static int32_t ps[64];
    int found = 0;
    for (int p = (int)(a >> MS_PAGE_BITS); p <= (int)((b - 1) >> MS_PAGE_BITS) && p < MS_PAGES; p++) {
        if (ms->h.first[t][p] == MS_NONE) continue;
        if (ms_load_range(ms, t, p, p)) return -1;
        int32_t x = (int32_t)p << MS_PAGE_BITS, e = x | 0xFFFF;
        if (x < a) x = a;
        if (e > b - 1) e = b - 1;
        while (x <= e) {
            int n = ms_events(ms, t, x, e, ev, ps, 64);
            for (int i = 0; i < n; i++) {
                if (ev[i].kind != MS_NOTE) continue;
                int32_t off = ps[i] + (int32_t)ev[i].len * 64;
                if (!found || ps[i] < *first) *first = ps[i];
                if (!found || ps[i] > *last_on) *last_on = ps[i];
                if (!found || off > *last_off) *last_off = off;
                found = 1;
            }
            if (n < 64) break;
            x = ps[63] + 1;
        }
    }
    return found;
}
static void pr_start(void)                                        /* main loop: Shift + drop asked for a print */
{
    pr = PR_IDLE;
    int t = ms->sel & 3, st = TAPE_STATE;
    const char *no = 0;
    if (!op1_tape_view_open()) return;                            /* the view closed before this pass */
    int32_t a = sel_b >= 0 ? sel_a : 0, b = sel_b >= 0 ? sel_b : MS_MAXPOS, first = 0, last_on = 0, last_off = 0;
    if (recording() || take_done || quant_req) no = "Finish recording first";
    else if (st != 0 && st != 1 && st != 2) no = "Stop the tape first";
    else if (PR_STEFAN()) no = "Print needs STEFAN off";
    else if (!FWD()) no = "Print plays forward only";
    else if (ms->h.dest[t] % 3 != MS_DEST_INSTR) no = "Print needs output I";
    else if (!CLIPS_OK()) no = "No free clips";
    else if (PR_FLASH_LOW()) no = "Flash full";
    else {
        int r = pr_span(t, a, b, &first, &last_on, &last_off);
        if (r < 0) no = "Can't read the song";
        else if (!r) no = "No notes to print";
    }
    uint32_t beat = 677376000u / (uint32_t)bpm_q8();              /* samples (Q8 bpm), as ms_grid_step */
    int32_t out = last_off + 4 * (int32_t)beat;                   /* one bar of release */
    out = (int32_t)(((uint32_t)out + beat - 1) / beat * beat);    /* up to the next beat */
    if (out > 0xF23FA0) out = 0xF23FA0;
    int32_t pre = first > (int32_t)beat ? first - (int32_t)beat : 0;
    if (!no && LOOP_ON && LOOP_OUT > LOOP_IN) {                   /* the tape wraps at the loop end */
        if (first < LOOP_IN || first >= LOOP_OUT) no = "The notes are outside the loop";
        if (pre < LOOP_IN) pre = LOOP_IN;
        if (out > LOOP_OUT) out = LOOP_OUT;
    }
    if (no) { op1_toast(no); return; }
    { uint32_t m = irq_off(); ms_all_off(ms); irq_on(m); }
    pr_in = first; pr_out = out; pr_last_on = last_on; pr_now = 0; pr_opened = 0; pr_stuck = 0; pr_wait = 0;
    ms_load_range(ms, t, (int)(first >> MS_PAGE_BITS), (int)((first >> MS_PAGE_BITS) + 1 < MS_PAGES ? (first >> MS_PAGE_BITS) + 1 : first >> MS_PAGE_BITS));
    pr_was_muted = ms->h.mute[t]; ms->h.mute[t] = 0;              /* a muted track prints too (the mute is put back) */
    pr_solo = (int8_t)t;
    LOCATE(pre);
    pr_last = pre; pr_prev_run = (uint8_t)TAPE_RUN;
    __asm__ volatile("" ::: "memory");
    pr = PR_ARMED;
    TAPE_STATE = 3;                                               /* armed, as REC from stop */
    KEY_DISPATCH(0x22, 1); KEY_DISPATCH(0x22, 0);                 /* PLAY: 3 -> 4, recording from the pre-roll */
}

/* ---- audio thread: tape hook `block`, once per 64-sample block ---- */
static void ms_tape_block(void)
{
    pr_block();
    if (!ms || !on) return;
    ms->sel = ms->sel & 3;
    if (e_playing()) {
        if (ci_latch || rec_arm) { ci_latch=rec_arm=arm_go=0; rec_latch=1; }
    } else if (ci_latch && !op1_countin_pending()) ci_latch=0;
    int was=ms->rec;
    ms->rec = recording();
    if (ms->rec && !was) ms_take_reset(ms);
    if (!ms->rec && was) take_done=1;
    ms_block(ms);
    if (waiting()) return; /* first note remains queued at the stopped playhead until PLAY */
    uint32_t end = qw; /* arrivals during this block wait for the next one */
    while (qr != end) {
        int i = qr % QN;
        if (q[i].cc) ms_cc_in(ms, q[i].d1, q[i].d2, q[i].ch);
        else ms_note_in(ms, q[i].d1, q[i].d2, 0, q[i].ch);    /* (notes: ch 1 = note-on, 0 = note-off) */
        qr++;
    }
    if (!e_playing()) rec_latch = 0;
}

/* ---- main loop: tape hook `service` ---- */
static void ms_tape_service(void)
{
    static uint8_t dead, was_on;
    if (dead) return;
    on = (uint8_t)op1_switch_on("midiseq");
    op1_tape_view_enable(on);
    if (!on) {                                            /* off (or switched off): close, silence, save, then idle */
        if (!ms) return;
        if (was_on) {
            was_on = 0; cancel_recording();
            uint32_t m = irq_off(); ms_all_off(ms); irq_on(m);
        }
        int dirty = ms->head_dirty;
        for (int b = 0; b < MS_RAM && !dirty; b++) dirty = ms->ram_slot[b] != MS_NONE && ms->ram_dirty[b];
        if (dirty) ms_service(ms, 4);
        return;
    }
    was_on = 1;
    if (!ms) {
        ms_t *s = (ms_t *)op1_alloc(sizeof(ms_t));
        if (!s) { dead = 1; op1_toast("midi seq: not enough memory"); return; }
        ms_init(s, &env);
        ms_load(s);
        ms = s;
        return;
    }
    if (!op1_tape_view_open() && (rec_arm || ci_latch || rec_held || rec_latch)) cancel_recording();
    if (pr == PR_REQ) {                                           /* PLAY waits for Shift: R246 reads Shift + PLAY as reverse */
        if (!SHIFT) pr_start();
        else if (pr_wait > PR_SHIFT_MAX) { pr = PR_IDLE; op1_toast("Release Shift to print"); }
    }
    if (pr >= PR_ARMED && !op1_tape_view_open()) pr_now = 1;      /* the view closed: the print ends here */
    if (pr == PR_ARMED && TAPE_STATE != 4) { if (TAPE_STATE == 3) TAPE_STATE = 0; pr_end(0); }   /* PLAY didn't start a take */
    if (pr == PR_CLOSED) pr_finish();
    else if (pr == PR_ENDED) pr_end(0);
    ms_service(ms, 4);
    if (quant_dirty) { quant_dirty=0; op1_setting_set("midiseq", "quant", ms_quant); }
    if (take_done && !ms->rec) { /* main-loop file/cache work, never in the audio callback */
        take_done=0;
        int32_t step=ms_grid_step(ms_quant,bpm_q8());
        if (step) ms_quantize_take(ms,step); else ms_take_reset(ms);
    }
    if (quant_req && !recording()) {
        int32_t a=quant_a,b=quant_b; int track=quant_track; quant_req=0;
        ms_quantize(ms,track,a,b,ms_grid_step(ms_quant,bpm_q8()));
    }
    if (arm_go) {
        arm_go=0;
        if (on && op1_tape_view_open() && waiting()) { KEY_DISPATCH(0x22,1); KEY_DISPATCH(0x22,0); }
    }
}
static const struct op1_tape_hooks tape = { .block = ms_tape_block, .service = ms_tape_service };

static void ms_event(int id, int32_t arg)
{
    (void)arg;
    if (id == OP1_EV_BOOT_DONE) { ms_quant=op1_setting_get("midiseq","quant",0); if ((unsigned)ms_quant>=MS_Q_N) ms_quant=0; op1_switch("midiseq", "midi seq"); on = (uint8_t)op1_switch_on("midiseq"); op1_tape_view_enable(on); }
}

/* ---- keys and encoders (KeyHandler thread, the features' input filter): only while the view is shown ---- */
static uint8_t swallow[0x40];
static int white_turn(int delta)        /* one step per detent through i, s, m1..m16 (wraps), input or output */
{
    if ((io_acc > 0 && delta < 0) || (io_acc < 0 && delta > 0)) io_acc = 0;
    io_acc += delta;
    int st = io_acc / 1024;
    if (!st) return 1;
    io_acc = 0;
    int t = ms->sel & 3, k, ch;
    if (io_sel) { k = ms->h.in[t] & 15; ch = ms->h.in[t] >> 4; } else { k = ms->h.dest[t] % 3; ch = ms->h.ch[t] & 15; }
    int i = k == MS_DEST_MIDI ? 2 + ch : k == MS_DEST_SEQ ? 1 : 0;   /* list index */
    i = ((i + st) % 18 + 18) % 18;
    k = i >= 2 ? MS_DEST_MIDI : i == 1 ? MS_DEST_SEQ : MS_DEST_INSTR; ch = i >= 2 ? i - 2 : ch;
    if (io_sel) ms->h.in[t] = (uint8_t)(k | ch << 4); else { ms->h.dest[t] = (uint8_t)k; ms->h.ch[t] = (uint8_t)ch; }
    ms->head_dirty = 1;
    return 1;
}
static int ms_input(const op1_input *in)
{
    if (in->type == OP1_IN_KNOB && pr != PR_IDLE && on && ms && op1_tape_view_open() && (in->code == 0 || in->code == 2)) return 1;
    if (in->type == OP1_IN_KNOB && on && ms && op1_tape_view_open() && in->code==0 && in->shift) {
        quant_acc+=in->delta; int n=quant_acc/1024; quant_acc-=n*1024;
        int q=ms_quant+n; ms_quant=q<0?0:q>=MS_Q_N?MS_Q_N-1:q; quant_dirty=1; return 1;
    }
    if (in->type == OP1_IN_KNOB) return on && ms && op1_tape_view_open() && in->code == 2 ? white_turn(in->delta) : 0;
    int code = in->code, pressed = in->pressed;
    if (code >= 0x40) return 0;
    if (!pressed && swallow[code]) { swallow[code] = 0; if (code == 0x21) rec_held = 0; return 1; }
    if (pr != PR_IDLE && on && ms && op1_tape_view_open()) {     /* printing: STOP ends it, the rest waits */
        if (!pressed) return 0;                                   /* releases go on (Shift, keys held before) */
        if (code == 0x23) pr_now = 1;
        swallow[code] = 1; return 1;
    }
    if (pressed && code==0x23) { cancel_recording(); return 0; }
    if (!on || !ms || !op1_tape_view_open() || !pressed) return 0;
    if (code==0x01 && rec_held) {
        if (op1_countin_pending()) { op1_countin_cancel(); ci_latch=0; }
        else if (!e_playing() && op1_countin_start()) { ci_latch=1; rec_arm=arm_go=0; }
        else op1_toast("Count-in unavailable");
        swallow[code]=1; return 1;
    }
    if (code==0x3B && in->shift) {
        if (!ms_quant) op1_toast("Choose quantize grid");
        else if (recording()) op1_toast("Finish recording first");
        else if (!quant_req) {
            quant_a=sel_b>=0?sel_a:TAPE_POS_S&~0xFFFF;
            quant_b=sel_b>=0?sel_b:(TAPE_POS_S|0xFFFF)+1;
            quant_track=ms->sel&3; __asm__ volatile("" ::: "memory"); quant_req=1;
        }
        swallow[code]=1; return 1;
    }
    int sh = in->shift;
    if (code >= 0x06 && code <= 0x09) {                   /* T1..T4: select, Shift: mute */
        int t = code - 0x06;
        if (sh) { ms->h.mute[t] ^= 1; ms->head_dirty = 1; if (ms->h.mute[t]) { uint32_t m = irq_off(); ms_all_off(ms); irq_on(m); } }
        else { cancel_recording(); ms->sel = t; }
        swallow[code] = 1; return 1;
    }
    if (code == 0x21) { if (take_done || quant_req) { op1_toast("Finishing take"); swallow[code]=1; return 1; } if (!sh) rec_held=1; else if (e_playing()) rec_latch^=1; else { rec_arm^=1; arm_go=0; } swallow[code] = 1; return 1; }
    int32_t ph = TAPE_POS_S;
    if (code == 0x0C) {                                   /* scissors: selection start, then end */
        if (!sel_set || sel_b >= 0) { sel_a = ph; sel_b = -1; sel_set = 1; }
        else { sel_b = ph; if (sel_b < sel_a) { int32_t x = sel_a; sel_a = sel_b; sel_b = x; } }
        swallow[code] = 1; return 1;
    }
    if (code == 0x0A) {                                   /* lift: the selected track, Shift: all tracks */
        int32_t a = sel_b >= 0 ? sel_a : ph & ~0xFFFF, b = sel_b >= 0 ? sel_b : (ph | 0xFFFF) + 1;
        if (!ms_cut(ms, a, b, sh ? 15 : 1 << (ms->sel & 3)) && ms->clip_first >= 0)
            LOCATE(ms->clip_first);                       /* DROP here puts them back in place */
        sel_set = 0; sel_a = sel_b = -1;
        swallow[code] = 1; return 1;
    }
    if (code == 0x0B && sh) { if (pr == PR_IDLE) { pr_wait = 0; pr = PR_REQ; } swallow[code] = 1; return 1; }   /* Shift + drop: print */
    if (code == 0x0B) { ms_paste(ms, ph); swallow[code] = 1; return 1; }
    if (code == 0x3D) { io_sel ^= 1; swallow[code] = 1; return 1; }   /* white press: input / output */
    return 0;
}

/* ---- the view's screen (Gfx thread, every frame) ---- */
static int32_t bpm_q8(void)                       /* float bits -> bpm in Q8, no soft-float; 120 if out of range */
{
    uint32_t b = BPM_BITS;
    int e = (int)((b >> 23) & 0xFF) - 127;
    if ((b >> 31) || e < 5 || e > 7) return 120 << 8;
    uint32_t m = (b & 0x7FFFFF) | 0x800000;
    return (int32_t)(m >> (15 - e));
}
static void ms_scr_init(void *scr) { (void)scr; }
static void ms_scr_update(void *scr, int dt)
{
    (void)scr; (void)dt;
    if (!ms) return;
    ms_view v;
    v.ph = TAPE_POS_S; v.zoom_q10 = op1_tape_zoom_q10(); v.bpm_q8 = bpm_q8();
    v.loop_on = LOOP_ON; v.loop_in = LOOP_IN; v.loop_out = LOOP_OUT;
    v.sel_a = sel_a; v.sel_b = sel_b; v.sel_track = ms->sel & 3; v.rec = recording(); v.punch = pu_mode; v.io = io_sel;
    v.shift = SHIFT; v.quant=ms_quant;
    v.tm_n = tm_n; v.tm = tm_pos;
    ms_draw(op1_raster(), &v, ms);
}
static const op1_screen_t ms_screen = { ms_scr_init, ms_scr_update };
static const op1_page_t ms_view_page = { 0, "usbout.svg", &ms_screen, 0, 0 };   /* empty SVG, drawn in code */
static const char *const ms_claims[] = { "view:seqtape", 0 };
const op1_feature_t FEATURE_midiseq = { .api = OP1_FEATURE_API, .priority = 1000, .name = "midiseq", .tape = &tape,
                                        .event = ms_event, .input = ms_input, .midi_raw = raw_in, .note_in = &note_in,
                                        .tape_view = &ms_view_page, .claims = ms_claims };

#ifdef OP1_HOST
ms_t *midiseq_host_state(void) { return ms; }
#endif
