/* 4-byte JUMP.L placed at 0x019B975C (instr_types name compare) -> instr_name_eq */
	.section .hook_namecmp,"ax"
	.global __hook_namecmp
__hook_namecmp:
	jump.l _instr_name_eq;

/* --dev only: CALL access("/yaffs2/te-boot.op1") at boot (0x019F01B8) -> du_boot_access (devupd/du_fw.c) */
	.section .hook_devrx,"ax"
	.global __hook_devrx
__hook_devrx:
	call _du_rx_poll;
	.section .hook_devboot,"ax"
	call _du_boot_access;

/* CALL at 0x01A01844 (patch::sample_path "sampler" check) -> sample_type_eq */
	.section .hook_samplecheck,"ax"
	.global __hook_samplecheck
__hook_samplecheck:
	call _sample_type_eq;

/* JUMP.L at 0x019AAD8E (fx_types name compare) -> fx_name_eq */
	.section .hook_fxnamecmp,"ax"
	.global __hook_fxnamecmp
__hook_fxnamecmp:
	jump.l _fx_name_eq;

/* ScreenId::for_fx jump-table case 5 target. Entered with the for_fx frame (LINK 0xc) still active,
 * like the original case code: compute R0, then  P0=[FP+4]; UNLINK; JUMP (P0). */
	.text
	.global _fx_screen_case5
	.align 2
_fx_screen_case5:
	call _fx_screen_select;
	P0 = [FP + 4];
	unlink;
	jump (P0);

	.section .hook_iterread,"ax"
	call _iter_read_hook;
	.section .hook_screenctor,"ax"
	call _screens_ctor_hook;
	.section .hook_screenload,"ax"
	call _screens_load_hook;

/* ScreenId::for_synth jump-table case 14 (iter) target, same frame convention as fx_screen_case5 */
	.text
	.global _synth_screen_case14
	.align 2
_synth_screen_case14:
	call _synth_screen_select;
	P0 = [FP + 4];
	unlink;
	jump (P0);

/* ---- optional OP-Z controller mode (make_firmware.py --opz), docs/12 ----
 * Flag 0x018B6016 = OP-Z host mode. Stock fw clears it on COM->CTRL entry (midi_send_identity_request)
 * and on every TE host-mode SysEx F0 00 20 76 00 01 <m> F7, but never sets or reads it.
 * midi_opz_mode_enabled (0x019E0CFC, stub "return 0") -> return the flag. */
	.section .hook_opzget,"ax"
	jump.l _opz_mode_enabled;
	.text
	.align 2
	.global _opz_mode_enabled
_opz_mode_enabled:
	P1.L = 0x6016;
	P1.H = 0x018B;
	R0 = B[P1] (Z);
	rts;

/* midi_rx_parse, host-mode SysEx branch for m != 1,2 (0x019E3540, was B[P4+9] = R5).
 * Entry: P4 = 0x018B600C (+8 ableton, +9 reason, +A opz), R0 = m. m == 3 -> OP-Z mode.
 * (stock code stores R5 here, assumed 0 - but a preceding 00 04 SysEx can leave R5 = 1) */
	.section .hook_opzset,"ax"
	jump.l _opz_hostmode_other;
	.text
	.align 2
_opz_hostmode_other:
	CC = R0 == 3;
	R0 = CC;
	B[P4 + 10] = R0;
	R0 = 0;
	B[P4 + 9] = R0;
	jump.l _midi_rx_parse_next;

/* every CALL read_fx_param (0x01A28DA0) in the firmware -> read_fx_param_safe (dispatcher.c):
 * clamps custom-FX knob words into the filter ranges first, so the range assert can never fire. */
	.section .hook_rfp019427b8,"ax"
	call _read_fx_param_safe;
	.section .hook_rfp01984f60,"ax"
	call _read_fx_param_safe;
	.section .hook_rfp019a74d4,"ax"
	call _read_fx_param_safe;
	.section .hook_rfp019b05f8,"ax"
	call _read_fx_param_safe;
	.section .hook_rfp019e6a48,"ax"
	call _read_fx_param_safe;
	.section .hook_rfp019e832c,"ax"
	call _read_fx_param_safe;
	.section .hook_rfp01a1cfd2,"ax"
	call _read_fx_param_safe;
	.section .hook_rfp01a33fb2,"ax"
	call _read_fx_param_safe;

/* KeyHandler::process_queue dispatch -> encoder press / turn handling for custom FX pages (dispatcher.c) */
	.section .hook_keyev,"ax"
	call _key_event_hook;
	.section .hook_knobev,"ax"
	call _knob_event_hook;
/* VoiceCtl key_down / key_up: CALL voicectl_synth_note_on / _note_off -> the features' note pipeline (kennel/kn_features.c) */
	.section .hook_chordon,"ax"
	call _note_pipe_on;
	.section .hook_chordoff,"ax"
	call _note_pipe_off;
/* VoiceCtl key_down / key_up tail: CALL midi_note_on_out / _off_out (every bank) -> kennel/kn_midiout.c: a key whose
 * notes went out from the end of the pipeline drops its raw note; everything else calls R246's as before */
	.section .hook_mostockon,"ax"
	call _kn_mo_stock_on;
	.section .hook_mostockoff,"ax"
	call _kn_mo_stock_off;
/* midi_rx_parse FA (MIDI START) branch: CALL 0x01A5E7D0 (reset beat counters) -> midi_start_hook (dispatcher.c) */
	.section .hook_midistart,"ax"
	call _midi_start_hook;
/* VoiceCtl::on_midi_rx 0xB0 branch: CALL midi_message (0x01A84F8C) -> midi_cc_hook (dispatcher.c) */
	.section .hook_midicc,"ax"
	call _midi_cc_hook;

/* ---- quad LFO (lfo/quadlfo.c) ---- */
/* lfo_types name compares (from_name 0x019C9C3A, is_valid 0x019C9BE2): "midi" also matches "quad" */
	.section .hook_lfoname1,"ax"
	call _lfo_name_eq;
	.section .hook_lfoname2,"ax"
	call _lfo_name_eq;
/* every CALL read_lfo_param (0x01A293BC) -> read_lfo_param_safe (quad words would trip the range assert) */
	.section .hook_rlp0193de2a,"ax"
	call _read_lfo_param_safe;
	.section .hook_rlp01968c34,"ax"
	call _read_lfo_param_safe;
	.section .hook_rlp01981eda,"ax"
	call _read_lfo_param_safe;
	.section .hook_rlp019e4a18,"ax"
	call _read_lfo_param_safe;
	.section .hook_rlp01a2d388,"ax"
	call _read_lfo_param_safe;
	.section .hook_rlp01a30c3c,"ax"
	call _read_lfo_param_safe;
	.section .hook_rlp01a48fe8,"ax"
	call _read_lfo_param_safe;
/* synth T4 page choice: CALL ScreenId::for_lfo (0x01A3C01C) at 0x01A50560 -> an engine's own T4 page, else the same call
 * (kennel/kn_eng_hooks.c kn_t4_screen_for; R0 = the slot's LFO type in, the screen id out) */
	.section .hook_t4scr,"ax"
	call _kn_t4_screen_for;

/* ScreenId::for_lfo case 4 (midi) target, same frame convention as fx_screen_case5 */
	.text
	.global _lfo_screen_case4
	.align 2
_lfo_screen_case4:
	call _lfo_screen_select;
	P0 = [FP + 4];
	unlink;
	jump (P0);

/* LfoMidi vtable apply entries (synth 0x01910840, drum 0x01910860, FX 0x01910880) -> here.
 * Entry R0 = this, R1 = LFO param words, R2 = pass. Words of a feature LFO type (quad; kennel/kn_lfo.c) -> its
 * code, anything else -> tail jump to the original LfoMidi method with registers and stack untouched. */
.macro QL_STUB name, orig, ours
	.global \name
	.align 2
\name:
	[--SP] = RETS;
	[--SP] = R0;
	[--SP] = R1;
	[--SP] = R2;
	SP += -12;
	R0 = R1;
	call _kn_lfo_claims;
	SP += 12;
	CC = R0 == 0;
	R2 = [SP++];
	R1 = [SP++];
	R0 = [SP++];
	RETS = [SP++];
	IF !CC JUMP 1f;
	jump.l \orig;
1:
	jump.l \ours;
.endm
	QL_STUB _ql_vt_synth, _midi_apply_synth, _kn_lfo_apply_synth
	QL_STUB _ql_vt_fx, _midi_apply_fx, _kn_lfo_apply_fx
	QL_STUB _ql_vt_drum, _midi_apply_drum, _kn_lfo_apply_drum
	.global _ql_apply_none
_ql_apply_none:
	R0 = 0;
	rts;

/* boot: CALL Clips::load (0x019F02EE) -> + kennel plugin loader; CALL MasterController::load (0x019F054A) -> + master
 * FX by name (kennel/kn_boot.c) */
	.section .hook_knboot,"ax"
	call _kn_boot_hook;
/* boot stage timers (kennel/kn_boottime.c, after op1r-src b220d08): db2::open (L1 pokes by DTEST first, kn_l1rt_boot,
 * as op1r 20581ac), fat_manager::init, the five sound loads */
	.section .hook_btopen,"ax"
	call _kn_bt_db_open;
	.section .hook_btfat,"ax"
	call _kn_bt_fat_init;
/* boot: CALL fat_sync_after_reboot -> kn_boot_fat_sync: after disk mode on tape 2..4 the sync waits for that tape (kn_tapes.c) */
	.section .hook_btsync,"ax"
	call _kn_boot_fat_sync;
	.section .hook_btsnd,"ax"
	call _kn_bt_sounds;
/* preset table fill by swap (kennel/kn_boottime.c, after op1r-src b220d08) */
	.section .hook_lpsyn1,"ax"
	call _kn_lp_set_synth;
	.section .hook_lpsyn2,"ax"
	call _kn_lp_set_synth_user;		/* user rows: light entries (kennel/kn_preset_store.c) */
	.section .hook_lpdrm1,"ax"
	call _kn_lp_set_drum;
	.section .hook_lpdrm2,"ax"
	call _kn_lp_set_drum_user;
/* preset storage (kennel/kn_preset_store.c): light user rows, fill on choose, a 448-entry drum table, one sort per
 * browser folder */
	.section .hook_plparse,"ax"		/* db2::load_presets: CALL Reader::parse */
	call _kn_pl_parse;
	.section .hook_plsynu,"ax"		/* load_synth_presets: CALL db2::load_presets(synth_user) */
	call _kn_pl_load_synth;
	.section .hook_pldrmu,"ax"		/* load_drum_presets: CALL db2::load_presets(drum_user) */
	call _kn_pl_load_drum;
	.section .hook_plrcs,"ax"		/* recount_presets: synth_user */
	call _kn_pl_load_synth;
	.section .hook_plrcd,"ax"		/* recount_presets: drum_user */
	call _kn_pl_load_drum;
	.section .hook_dt1,"ax"		/* drum table load 0x0193f58c */
	P2.L = _kn_drum_tab; P2.H = _kn_drum_tab;
	.section .hook_dt2,"ax"		/* drum table load 0x0193fbc6 */
	R2.L = _kn_drum_tab; R2.H = _kn_drum_tab;
	.section .hook_dt3,"ax"		/* drum table load 0x01a01e14 */
	R0.L = _kn_drum_tab + 4; R0.H = _kn_drum_tab + 4;
	.section .hook_dt4,"ax"		/* drum table load 0x01a0265a */
	R5.L = _kn_drum_tab + 4; R5.H = _kn_drum_tab + 4;
	.section .hook_dt5,"ax"		/* drum table load 0x01a0293a */
	R7.L = _kn_drum_tab + 4; R7.H = _kn_drum_tab + 4;
	.section .hook_dt6,"ax"		/* drum table load 0x01a04e54 */
	R6.L = _kn_drum_tab + 4; R6.H = _kn_drum_tab + 4;
	.section .hook_dt7,"ax"		/* drum table load 0x01a05004 */
	R5.L = _kn_drum_tab; R5.H = _kn_drum_tab;
	.section .hook_dt8,"ax"		/* drum table load 0x01a06018 */
	R0.L = _kn_drum_tab; R0.H = _kn_drum_tab;
	.section .hook_dt9,"ax"		/* drum table load 0x01a060d8 */
	R0.L = _kn_drum_tab; R0.H = _kn_drum_tab;
	.section .hook_dtctor,"ax"		/* drum table vector ctor: 448 entries */
	call _kn_dt_ctor_stub;
	.section .hook_dtdtor,"ax"
	call _kn_dt_dtor_stub;
	.section .hook_dtgate,"ax"		/* drum save gate (R246: count < 58) */
	jump.l _kn_pl_drum_gate_fn;
	.section .hook_dtassert,"ax"		/* drum loader, user rows: R4 = 58 -> 56 << 3 = 448 (R4 holds 0x38 here) */
	R4 <<= 0x3;
	.section .hook_brsort,"ax"		/* fw list child add: CALL std::sort */
	call _kn_br_sort_stub;
	.section .hook_brsyn,"ax"		/* CALL synth preset list builder */
	call _kn_pl_build_synth;
	.section .hook_brdrm,"ax"		/* CALL drum kit list builder */
	call _kn_pl_build_drum;
	.text
	.align 2
_kn_dt_ctor_stub:			/* static init: constants only */
	R1 = 448 (X);
	jump.l _vec_ctor;
_kn_dt_dtor_stub:
	R1 = 448 (X);
	jump.l _vec_dtor;
_kn_br_sort_stub:			/* P4 = the folder + 0x20 (its child vector at +0x24) */
	P0.L = _kn_br_p4; P0.H = _kn_br_p4;
	[P0] = P4;
	jump.l _kn_br_sort;
/* lazy stock screens (kennel/kn_lzscr.c): Screen::find_node 0x01A3B580 entry (LINK 0) -> kn_lz_guard(R0 = the
 * screen object) parses a deferred screen first; R0..R2 and RETS kept, then the original LINK 0 and on */
	.section .hook_lzfind,"ax"
	jump.l _lz_find_stub;
	.text
	.align 2
_lz_find_stub:
	[--SP] = RETS; [--SP] = R0; [--SP] = R1; [--SP] = R2;
	SP += -12;
	call _kn_lz_guard;
	SP += 12;
	R2 = [SP++]; R1 = [SP++]; R0 = [SP++]; RETS = [SP++];
	LINK 0;
	jump.l _find_node_body;
/* per-panel screen art (kennel/kn_svgvar.c): svg_parse_file 0x019FB458, after the BOM skip, `R0.L = 0xA5C` (0x019FB57C) ->
 * kn_svg_start(FP) moves the text pointer [FP + 8] to the running panel's chunk; the displaced instruction runs after */
	.section .hook_svgstart,"ax"
	call _svg_start_stub;
	.text
	.align 2
_svg_start_stub:
	[--SP] = RETS; [--SP] = R1; [--SP] = R2; [--SP] = R3; [--SP] = P1; [--SP] = P2;
	R0 = FP;
	SP += -12;
	call _kn_svg_start;
	SP += 12;
	P2 = [SP++]; P1 = [SP++]; R3 = [SP++]; R2 = [SP++]; R1 = [SP++]; RETS = [SP++];
	R0.L = 0x0a5c;
	rts;
	.section .hook_lpgrow,"ax"		/* db2::load_presets row vector: new capacity = cap + (cap << 5) (stock: cap >> 1) */
	R4 = R3 << 0x5;
	.section .hook_knmaster,"ax"
	call _kn_master_load;
/* master FX list: the picker's CALL db2::get_master_fx_type (0x019D97F0) -> the plugin's name for the opening row (kennel/kn_boot.c) */
	.section .hook_knmasterlist,"ax"
	call _kn_master_list_type;
/* power-off / restart: R246's shutdown write-back loop CALL tape_c::service(1) 0x01A54710 (0x019F0BE2) -> one bounded
 * flush of every modified tape chunk, held ones included, then R0 = 0 ends the loop (kennel/kn_tape.c kn_tape_final) */
	.section .hook_tapefinal,"ax"
	call _kn_tape_final;
/* power-off / restart: R246's shutdown CALL yaffs unmount 0x019964B4 (0x019F0BEA) -> + crash marker (kennel/kn_boot.c) */
	.section .hook_knunmount,"ax"
	call _kn_boot_unmount;
/* main loop: CALL yaffs background GC 0x01A9AC48 (0x019F0C46) -> at most once per 0.1 s, as op1r 49 (kennel/kn_boot.c) */
	.section .hook_gcrate,"ax"
	call _kn_gc_rate;
/* delayed patch saves (bgsave.c): the SaveSlotJob queue entry 0x019411B8 (LINK 0) -> bgs_queue_slot, which only notes
 * (kind, slot); bgs_queue_stock is the original (its LINK here, then on at 0x019411BC). Shutdown: CALL BgFileWorker
 * stop 0x019412D4 (0x019F0BDC) -> kn_bgs_stop (queue what is noted, wait for the ring, then stop). */
	.section .hook_bgsqueue,"ax"
	jump.l _bgs_queue_slot;
	.section .hook_bgsstop,"ax"
	call _kn_bgs_stop;
/* patch saves that fit (kennel/kn_patch_sql.c): the seven patch jobs' CALL snprintf(0x01BA340C, 5000, "UPDATE
 * ..._slots SET patch='%s' WHERE id=%i", patch, slot) (0x01A4CCD8) -> kn_patch_sql, same arguments */
	.section .hook_psql1,"ax"
	call _kn_patch_sql;
	.section .hook_psql2,"ax"
	call _kn_patch_sql;
	.section .hook_psql3,"ax"
	call _kn_patch_sql;
	.section .hook_psql4,"ax"
	call _kn_patch_sql;
	.section .hook_psql5,"ax"
	call _kn_patch_sql;
	.section .hook_psql6,"ax"
	call _kn_patch_sql;
	.section .hook_psql7,"ax"
	call _kn_patch_sql;
/* R246's inserts with user text (kennel/kn_patch_sql.c): CALL snprintf(buf, 8192, ...) (0x01A4CCD8), same arguments.
 * The user preset: "INSERT INTO %s (patch,folder) VALUES('%s','%s')" (table, patch, folder) -> kn_insert_sql */
	.section .hook_isql1,"ax"
	call _kn_insert_sql;
/* the slot rows: "INSERT INTO synth_slots / drum_slots VALUES(%i,'%s')" (id, patch) -> kn_slot_insert_sql */
	.section .hook_isql2,"ax"
	call _kn_slot_insert_sql;
	.section .hook_isql3,"ax"
	call _kn_slot_insert_sql;
	.text
	.global _bgs_queue_stock
	.align 2
_bgs_queue_stock:
	LINK 0;
	jump.l _bgs_queue_cont;
/* every frame: gfx_render_frame's CALL screens_update (0x019B2690) -> + toast (kennel/kn_core.c) */
	.section .hook_knscreens,"ax"
	call _kn_screens_update;
/* Gfx_thread::Run's CALL of the buffer flush (0x019AB8C8; R0 buffer, R1 end) -> kn_gfx_finish (kennel/kn_gfx.c:
 * flush + invalidate, present), then back to the disp_draw_busy clear at 0x019AB8D2. P3/P4/P5/R7 are callee-saved. */
	.section .hook_gfxfinish,"ax"
	jump.l _kn_gfx_finish_stub;
	.text
	.align 2
_kn_gfx_finish_stub:
	call _kn_gfx_finish;
	jump.l _kn_gfx_finish_ret;
/* screens_update's CALL raster_begin_frame (0x01A3BBE0; R0 the raster, P4 the frame table, R7 dt) -> kn_gfx_frame
 * (kennel/kn_gfx.c: the clear and R246's update loop, or a skipped frame), then on at 0x01A3BC02
 * (player_manager_advance(R7, [P3]), knob_touched_clear). R7 / P3 / P4 are callee-saved; screens_update returns
 * through [FP + 4], so RETS may change here. */
	.section .hook_gfxframe,"ax"
	jump.l _kn_gfx_frame_stub;
	.text
	.align 2
_kn_gfx_frame_stub:
	R1 = P4;
	R2 = R7;
	call _kn_gfx_frame;
	jump.l _kn_gfx_frame_ret;

/* Exact GUI frame skip (screens/guiskip.c, from op1r-src 59: 19108de, plus kennel's hook_gsdna; hooked unless
 * KN_GUISKIP=0). Entry stubs call the
 * C recorder with the original arguments; a non-zero result skips the body (RTS to the caller), else the replaced
 * first instruction(s) run and the body continues. op1r's frame hook (hook_gsframe, 0x01A3BBE0) is kennel's
 * hook_gfxframe above: kn_gfx_frame calls gs_frame. */
	.section .hook_gsmove,"ax"
	jump.l _gs_move_stub;
	.section .hook_gsline,"ax"
	jump.l _gs_line_stub;
	.section .hook_gstext,"ax"
	jump.l _gs_text_stub;
	.section .hook_gsdim,"ax"
	jump.l _gs_dim_stub;
	.section .hook_gsfade,"ax"
	jump.l _gs_fade_stub;
	.section .hook_gsdot,"ax"
	jump.l _gs_dot_stub;
	.section .hook_gssw1,"ax"
	P1.L = _gs_sweep_stub; P1.H = _gs_sweep_stub;
	.section .hook_gssw2,"ax"
	P1.L = _gs_sweep_stub; P1.H = _gs_sweep_stub;
	.section .hook_gssw3,"ax"
	P1.L = _gs_sweep_stub; P1.H = _gs_sweep_stub;
	.section .hook_gssw4,"ax"
	P1.L = _gs_sweep_stub; P1.H = _gs_sweep_stub;
	.section .hook_gssw5,"ax"
	P1.L = _gs_sweep_stub; P1.H = _gs_sweep_stub;
/* kennel: Text::draw's glyph sweep (0x01A62726: P1 = 0xFFA0894C; CALL (P1)) -> gs_glyph (screens/guiskip.c) with the
 * kernel's five arguments (R0..R2, two on the caller's stack), which draws it or lets the tape cache skip it */
	.section .hook_gsglyph,"ax"
	P1.L = _gs_glyph_stub; P1.H = _gs_glyph_stub;
	.text
	.align 2
/* kennel: agg_sweep_scanlines called from C (screens/tapecache.c): it stores its renderer at [FP + 0x14], in its
 * caller's frame, as R246's callers reserve 0x14 bytes of outgoing arguments; this frame does the same */
	.global _tc_sweep_call
_tc_sweep_call:
	LINK 0x14;
	P1.L = 0x55b4; P1.H = 0xffa0;
	CALL (P1);
	UNLINK;
	RTS;
_gs_glyph_stub:
	[--SP] = RETS;
	R3 = [SP + 16]; P0 = [SP + 20];
	SP += -20;
	[SP + 12] = R3; [SP + 16] = P0;
	call _gs_glyph;
	SP += 20;
	RETS = [SP++];
	RTS;
/* kennel: the DNA page's CALL of the raster getter 0x019B2614 (at 0x019B5A1E) -> gs_dna_raster (screens/guiskip.c):
 * the getter's result in R0 and the frame hash changed. The getter clobbers only P1 and R0: the stub keeps the rest. */
	.section .hook_gsdna,"ax"
	call _gs_dna_stub;
	.text
	.align 2
_gs_dna_stub:
	[--SP] = RETS; [--SP] = R1; [--SP] = R2; [--SP] = R3; [--SP] = P0; [--SP] = P2;
	SP += -12;
	call _gs_dna_raster;
	SP += 12;
	P2 = [SP++]; P0 = [SP++]; R3 = [SP++]; R2 = [SP++]; R1 = [SP++]; RETS = [SP++];
	RTS;
	.text
	.align 2
/* save R0..R2 / RETS, call C (args prepared by the macro user), CC = result != 0, restore */
.macro GS_CALL fn
	[--SP] = RETS; [--SP] = R0; [--SP] = R1; [--SP] = R2;
	SP += -12;
	call \fn;
	SP += 12;
	CC = R0 == 0;
	R2 = [SP++]; R1 = [SP++]; R0 = [SP++]; RETS = [SP++];
.endm
_gs_move_stub:
	[--SP] = P0; P0.L = _gs_caller; P0.H = _gs_caller; R3 = RETS; [P0] = R3; P0 = [SP++];
	GS_CALL _gs_point
	IF !CC JUMP 1f;
	LINK 0;
	jump.l _rs_move_body;
_gs_line_stub:
	[--SP] = P0; P0.L = _gs_caller; P0.H = _gs_caller; R3 = RETS; [P0] = R3; P0 = [SP++];
	GS_CALL _gs_point
	IF !CC JUMP 1f;
	LINK 0;
	jump.l _rs_line_body;
_gs_text_stub:
	GS_CALL _gs_text
	IF !CC JUMP 1f;
	LINK 0x24;
	jump.l _txt_draw_body;
_gs_dot_stub:
	[--SP] = R0; R0 = 2;
	GS_CALL _gs_misc_dot
	R0 = [SP++];
	IF !CC JUMP 1f;
	LINK 0x18;
	jump.l _dot_body;
_gs_dim_stub:
	GS_CALL _gs_misc_dim
	IF !CC JUMP 1f;
	P0 = R0;
	[--SP] = (R7:4, P5:5);
	jump.l _dim_body;
_gs_fade_stub:				/* Raster::fade(R0 raster, R1 amount), op1r-src 8dd28bb */
	GS_CALL _gs_misc_fade
	IF !CC JUMP 1f;
	P0 = R0;
	[--SP] = (R7:4, P5:5);
	jump.l _fade_body;
_gs_sweep_stub:
	[--SP] = RETS; [--SP] = R0; [--SP] = R1; [--SP] = R2;
	SP += -12;
	R3 = R1; R1 = R2; R2 = R3;
	call _gs_sweep;
	SP += 12;
	CC = R0 == 0;
	R2 = [SP++]; R1 = [SP++]; R0 = [SP++]; RETS = [SP++];
	IF !CC JUMP 1f;
	P1.L = 0x55b4; P1.H = 0xffa0;
	jump (P1);
1:	RTS;

/* parse_patch_json (0x01A037A8) type lookups -> engine / FX picked by the saved type name (dispatcher.c,
 * docs/preset-identity.md). The parser keeps its source JSON at [FP - 0x78]; the callee has not linked yet, so FP is
 * still the parser's. The stubs pass it as the second argument and jump on: the C function returns to the parser. */
	.section .hook_patchtype,"ax"
	call _patch_type_stub;
	.section .hook_fxpatchtype,"ax"
	call _fx_patch_type_stub;
	.text
	.global _patch_type_stub
_patch_type_stub:
	R1 = [FP - 120];
	jump.l _patch_type_hook;
	.global _fx_patch_type_stub
_fx_patch_type_stub:
	R1 = [FP - 120];
	jump.l _fx_patch_type_hook;

/* parse_patch_json LFO word range check (0x01A042A2) -> lfo_range_ok (accepts quad words, dispatcher.c) */
	.section .hook_lforange,"ax"
	call _lfo_range_ok;

/* PlayerManager::create_player case 3 (CALL 0x019ED460 finger singleton @0x01A0D150) -> finger, euclid or dots */
	.section .hook_euplayer,"ax"
	call _seq_player_get;

/* SeqIds::from_name CALLs -> eu_seq_from_name ("euclid" = type 3 + flag) */
	.section .hook_seqname1,"ax"
	call _eu_seq_from_name;
	.section .hook_seqname2,"ax"
	call _eu_seq_from_name;
	.section .hook_seqname3,"ax"
	call _eu_seq_from_name;
/* SeqIds::name(type) entry -> eu_seq_name (returns "euclid" for type 3 while euclid is active) */
	.section .hook_seqtoname,"ax"
	jump.l _eu_seq_name;

/* input key "sampler?" checks -> rec_type_ok (dispatcher.c). Each replaces "CC = Rx == R(6); IF !CC JUMP no"
 * (4 bytes) with a CALL; the stub keeps all registers, returns to the next instruction (yes) or to `no`. */
	.section .hook_recA,"ax"
	call _rec_check_a;
	.section .hook_recB,"ax"
	call _rec_check_b;
	.section .hook_recend,"ax"
	call _rec_end_patch;
	.text
	.align 2
_rec_check_a:                       /* on_key @0x019AC8B4: type in R0, no -> 0x019AC8CC */
	[--SP] = RETS;
	[--SP] = (R7:0, P5:0);
	SP += -12;
	call _rec_type_ok;
	SP += 12;
	CC = R0 == 0;
	(R7:0, P5:0) = [SP++];
	RETS = [SP++];
	if CC jump 1f;
	rts;
1:	[--SP] = P0;
	P0.L = 0xC8CC;
	P0.H = 0x019A;
	RETS = P0;
	P0 = [SP++];
	rts;
_rec_check_b:                       /* on_key_shift @0x019ACC7C: type in R1, no -> 0x019ACC8C */
	[--SP] = RETS;
	[--SP] = (R7:0, P5:0);
	SP += -12;
	R0 = R1;
	call _rec_type_ok;
	SP += 12;
	CC = R0 == 0;
	(R7:0, P5:0) = [SP++];
	RETS = [SP++];
	if CC jump 1f;
	rts;
1:	[--SP] = P0;
	P0.L = 0xCC8C;
	P0.H = 0x019A;
	RETS = P0;
	P0 = [SP++];
	rts;

/* L1 tape resampler 0xFFA06194 prologue call-out (make_firmware.py L1_CALLS): replaces P1 = 0xFF8029DC;
 * P2 = 0xFF802154. Entered after LINK 0 + push (R7:6, P5:3); R0 = position (1/64 samples), R1 = increment,
 * R2 = gain increment pointer: all kept. ASTAT kept: the tape code sets CC (lp_index < 0) before the call and tests it
 * after (0xFFA0724E / 0xFFA0725C, assert tape_c.cpp:1039); the stock resampler never touches CC. The resampler sets every other register it uses afterwards, so the C call
 * (track outs, seq/... usbtrack.c) may clobber the C caller-saved registers. Caller frame: [FP] = tape FP,
 * [FP + 0x40] = tape [SP + 0x38] = samples read per block. */
	.text
	.global _l1_rs_probe
	.align 2
_l1_rs_probe:
	[--SP] = ASTAT;                           /* CC is live across the resampler call (tape code tests it after) */
	P0.L = _tp_on; P0.H = _tp_on;             /* takeover (usbtrack.c tp_decide): our resampler + mix, then R246's
	                                           * epilogue (the stock body is skipped). P0 / R3: the stock body sets
	                                           * them before any use */
	R3 = B[P0] (Z);
	CC = R3 == 0;
	if !CC jump _tp_probe;
	P0.L = _tp_check; P0.H = _tp_check;       /* tp_mode 3: ours into a shadow, R246's return through tp_ret */
	R3 = B[P0] (Z);
	CC = R3 == 0;
	if !CC jump _tp_probe_check;
	P0.L = _tp_par; P0.H = _tp_par;           /* tp_mode 0: the track pass beside R246's mix */
	R3 = B[P0] (Z);
	CC = R3 == 0;
	if !CC jump _tp_probe_par;
	ASTAT = [SP++];                           /* no track work: R246's mix and resampler */
	P1.L = 0x29dc; P1.H = 0xff80;
	P2.L = 0x2154; P2.H = 0xff80;
	rts;
_tp_probe_par:
	[--SP] = RETS;
	[--SP] = R0;
	[--SP] = R1;
	[--SP] = R2;
	SP += -12;
	call _tr_resample;
	SP += 12;
	R2 = [SP++];
	R1 = [SP++];
	R0 = [SP++];
	RETS = [SP++];
	ASTAT = [SP++];
	P1.L = 0x29dc; P1.H = 0xff80;
	P2.L = 0x2154; P2.H = 0xff80;
	rts;
_tp_probe_check:                              /* as the stock path, plus tp_check_pre, and the resampler's saved RETS
	                                           * ([FP + 4], LINK 0) swapped for tp_ret (op1r-src df045d1, xoza) */
	[--SP] = RETS;
	[--SP] = R0;
	[--SP] = R1;
	[--SP] = R2;
	SP += -12;
	call _tp_check_pre;
	SP += 12;
	P0.L = _tp_ret_to; P0.H = _tp_ret_to;
	R3 = [FP + 4];
	[P0] = R3;
	R3.L = _tp_ret; R3.H = _tp_ret;
	[FP + 4] = R3;
	R2 = [SP++];
	R1 = [SP++];
	R0 = [SP++];
	RETS = [SP++];
	ASTAT = [SP++];
	P1.L = 0x29dc; P1.H = 0xff80;
	P2.L = 0x2154; P2.H = 0xff80;
	rts;
_tp_ret:                                      /* R246's resampler returns here (JUMP (P0) with P0 = this): compare,
	                                           * then on to tape_play_mix; every register kept (R0 result, CC live) */
	[--SP] = ASTAT; [--SP] = RETS;
	[--SP] = (R7:0, P5:0);
	[--SP] = I0; [--SP] = I1; [--SP] = I2; [--SP] = I3;
	[--SP] = LC0; [--SP] = LT0; [--SP] = LB0; [--SP] = LC1; [--SP] = LT1; [--SP] = LB1;
	[--SP] = A0.W; [--SP] = A0.X; [--SP] = A1.W; [--SP] = A1.X;
	SP += -12;
	call _tp_check_post;
	SP += 12;
	A1.X = [SP++]; A1.W = [SP++]; A0.X = [SP++]; A0.W = [SP++];
	LB1 = [SP++]; LT1 = [SP++]; LC1 = [SP++]; LB0 = [SP++]; LT0 = [SP++]; LC0 = [SP++];
	I3 = [SP++]; I2 = [SP++]; I1 = [SP++]; I0 = [SP++];
	(R7:0, P5:0) = [SP++];
	RETS = [SP++]; ASTAT = [SP++];
	P0.L = _tp_ret_to; P0.H = _tp_ret_to;     /* as R246's own return: P0 = the address, JUMP (P0) */
	P0 = [P0];
	JUMP (P0);
_tp_probe:                                    /* called from R246's resampler after LINK 0; [--SP] = (R7:6, P5:3);
	                                           * R0 pos, R1 inc, R2 gain increment pointer; ASTAT (pushed above) kept */
	SP += -12;
	call _tp_resample;                        /* R0 = pos + 64 inc, the resampler's result */
	SP += 12;
	ASTAT = [SP++];
	(R7:6, P5:3) = [SP++];                    /* R246's epilogue: back to tape_play_mix (UNLINK restores its RETS) */
	UNLINK;
	rts;

/* Tape mix loops (L1): the per-track peak-meter MAX instruction is replaced by CALL to an L1 trampoline, which calls
 * these. They do the MAX and log {src, dest, track, N} for the track outs. Must preserve every register but R0.
 * Stack on entry: trampoline pushed RETS + P1 (8 bytes) -> tape SP = SP + 8. */
	.global _mix_hook_fwd
	.align 2
_mix_hook_fwd:                                /* loop 1 @0xFFA0709C: src P4, dest P3, track R1 */
	R0 = MAX (R2, R0) (V);
	[--SP] = P0; [--SP] = P5; [--SP] = R7; [--SP] = R6;
	P0 = [SP + 16];                           /* the loop's P1: track gains (L, R at + 8) -> tm_g (usbtrack.c) */
	R6 = W[P0] (X); R7 = W[P0 + 8] (X);
	P0 = R1; P0 = P0 << 1;
	P5.L = _tm_g; P5.H = _tm_g; P5 = P5 + P0;
	W[P5] = R6; W[P5 + 8] = R7;
	R6 = P4; R7 = P3;
	[--SP] = R1;
	jump.s _mix_rec_common;
	.global _mix_hook_rev
	.align 2
_mix_hook_rev:                                /* loop 2 @0xFFA0712C: src P1 (+2), dest I1, track R3 */
	R0 = MAX (R0, R1) (V);
	[--SP] = P0; [--SP] = P5; [--SP] = R7; [--SP] = R6;   /* 16 bytes: the trampoline's saved P1 is now at SP + 16 */
	P0 = [SP + 12];                           /* the loop's P0: track gains (L, R at + 8) -> tm_g */
	R6 = W[P0] (X); R7 = W[P0 + 8] (X);
	P0 = R3; P0 = P0 << 1;
	P5.L = _tm_g; P5.H = _tm_g; P5 = P5 + P0;
	W[P5] = R6; W[P5 + 8] = R7;
	R6 = [SP + 16];                           /* the loop's P1: pushed by the trampoline (P1 = hook address here) */
	R6 += 2; R7 = I1;
	BITSET (R6, 0);                           /* src bit 0 = loop 2 (its gains pair the other way, usbtrack.c) */
	[--SP] = R3;
_mix_rec_common:                              /* stack: track, R6, R7, P5, P0 (20 bytes) + 8 -> tape SP = SP + 28 */
	[--SP] = ASTAT;                           /* CC is live in the mix loop (IF CC JUMP right after) */
	[--SP] = R5;
	[--SP] = R4;                              /* + 12 -> tape SP = SP + 40 */
	P5.L = _tr_rec; P5.H = _tr_rec;
	R5 = [P5];
	CC = R5 == 0;                             /* the block's first pass: the tape mix's cost probe starts
	                                           * (usbtrack.c tp_cyc; P0 is pushed, set again below) */
	if !CC jump 2f;
	R4 = CYCLES;
	P0.L = _tp_t0; P0.H = _tp_t0;
	[P0] = R4;
2:	R4 = 16;
	CC = R5 < R4;
	if !CC jump _mix_rec_full;
	P0 = R5;
	R5 += 1;
	[P5] = R5;
	P0 = P0 << 2;
	P0 = P0 << 2;
	P5 = P5 + P0;
	[P5 + 4] = R6;                            /* src */
	[P5 + 8] = R7;                            /* dest */
	R5 = [SP + 12];                           /* track */
	[P5 + 12] = R5;
	R5 = [SP + 0x60];                         /* tape [SP + 0x38] = N: SP + 40 + 0x38 */
	[P5 + 16] = R5;
_mix_rec_full:
	P5.L = _tp_on; P5.H = _tp_on;             /* takeover: CC = 1 in the saved ASTAT -> the loop's IF CC JUMP skips
	                                           * R246's MAC loop (usbtrack.c replays it from the log) */
	R5 = B[P5] (Z);
	CC = R5 == 0;
	if CC jump 1f;
	R5 = [SP + 8];
	BITSET (R5, 5);                           /* ASTAT bit 5 = CC */
	[SP + 8] = R5;
1:	R4 = [SP++]; R5 = [SP++]; ASTAT = [SP++];
	SP += 4;
	R6 = [SP++]; R7 = [SP++]; P5 = [SP++]; P0 = [SP++];
	rts;

/* L1 trampolines (plain LDR block at 0xFFA0BFB4, the free end of L1 instruction SRAM): pc-relative CALL range */
	.section .l1tramp,"ax"
	.global _l1_tramp_fwd
	.align 2
_l1_tramp_fwd:
	[--SP] = RETS; [--SP] = P1;
	P1.L = _mix_hook_fwd; P1.H = _mix_hook_fwd;
	call (P1);
	P1 = [SP++]; RETS = [SP++];
	rts;
	.global _l1_tramp_rev
	.align 2
_l1_tramp_rev:
	[--SP] = RETS; [--SP] = P1;
	P1.L = _mix_hook_rev; P1.H = _mix_hook_rev;
	call (P1);
	P1 = [SP++]; RETS = [SP++];
	rts;

	.global _l1_tramp_mfx
	.align 2
_l1_tramp_mfx:                                /* core_master_mix_stage 0xFFA01202, every block after the master EQ */
	[--SP] = RETS; [--SP] = P1;
	P1.L = _kn_dc_mfx_entry; P1.H = _kn_dc_mfx_entry;
	call (P1);
	P1 = [SP++]; RETS = [SP++];
	P1.L = 0xad68;                            /* the replaced instruction (P1.H = 0x01aa follows in R246) */
	rts;

/* FX switch declick (kennel/kn_declick.c kn_dc_master_gap): called from the L1 trampoline above in the middle of R246's
 * output stage, so every register is R246's: save all a C call may change (and clear L0..L3 for it). */
	.section .text.kn_audio,"ax"
	.global _kn_dc_mfx_entry
	.align 2
_kn_dc_mfx_entry:
	[--SP] = ASTAT;
	[--SP] = (R7:0, P5:0);
	[--SP] = RETS;
	[--SP] = A0.X; [--SP] = A0.W; [--SP] = A1.X; [--SP] = A1.W;
	[--SP] = LC0; [--SP] = LT0; [--SP] = LB0; [--SP] = LC1; [--SP] = LT1; [--SP] = LB1;
	[--SP] = I0; [--SP] = I1; [--SP] = I2; [--SP] = I3;
	[--SP] = M0; [--SP] = M1; [--SP] = M2; [--SP] = M3;
	[--SP] = B0; [--SP] = B1; [--SP] = B2; [--SP] = B3;
	[--SP] = L0; [--SP] = L1; [--SP] = L2; [--SP] = L3;
	R0 = 0; L0 = R0; L1 = R0; L2 = R0; L3 = R0;
	R0.L = 0x0d34; R0.H = 0xff80;             /* out_l16: the master FX's L */
	R1.L = 0x0db4; R1.H = 0xff80;             /* out_r16 */
	SP += -12;
	call _kn_mfx_site;                        /* kennel/kn_declick.c: master insert, gap declick */
	SP += 12;
	L3 = [SP++]; L2 = [SP++]; L1 = [SP++]; L0 = [SP++];
	B3 = [SP++]; B2 = [SP++]; B1 = [SP++]; B0 = [SP++];
	M3 = [SP++]; M2 = [SP++]; M1 = [SP++]; M0 = [SP++];
	I3 = [SP++]; I2 = [SP++]; I1 = [SP++]; I0 = [SP++];
	LB1 = [SP++]; LT1 = [SP++]; LC1 = [SP++]; LB0 = [SP++]; LT0 = [SP++]; LC0 = [SP++];
	A1.W = [SP++]; A1.X = [SP++]; A0.W = [SP++]; A0.X = [SP++];
	RETS = [SP++];
	(R7:0, P5:0) = [SP++];
	ASTAT = [SP++];
	rts;

/* USB 6 channels (screens/usbtrack.c) */
	.section .hook_usbdesc,"ax"
	.global __hook_usbdesc
__hook_usbdesc:
	call _usb6_desc_init;
	.section .hook_usbiso1,"ax"
	.global __hook_usbiso1
__hook_usbiso1:
	call _usb6_iso_in_silent;
	.section .hook_ciservice,"ax"
	.global __hook_ciservice
__hook_ciservice:
	call _ci_service;
	.section .hook_taperase,"ax"
	.global __hook_taperase
__hook_taperase:
	call _fast_tape_erase;
/* tape edit events (kennel/kn_tape.c): CALL sites in the clipboard service, its main-loop call, split and join */
	.section .hook_clipsvc,"ax"
	.global __hook_clipsvc
__hook_clipsvc:
	call _kn_clip_service;
	.section .hook_clipdrop,"ax"
	.global __hook_clipdrop
__hook_clipdrop:
	call _kn_clip_drop_add;
	.section .hook_clipdropall,"ax"
	.global __hook_clipdropall
__hook_clipdropall:
	call _kn_clip_dropall_add;
	.section .hook_cliplift,"ax"
	.global __hook_cliplift
__hook_cliplift:
	call _kn_clip_lift;
	.section .hook_cliplftall,"ax"
	.global __hook_cliplftall
__hook_cliplftall:
	call _kn_clip_lift_all;
	.section .hook_split1,"ax"
	.global __hook_split1
__hook_split1:
	call _kn_tape_split;
	.section .hook_split2,"ax"
	.global __hook_split2
__hook_split2:
	call _kn_tape_split;
	.section .hook_split3,"ax"
	.global __hook_split3
__hook_split3:
	call _kn_tape_split;
	.section .hook_join,"ax"
	.global __hook_join
__hook_join:
	call _kn_tape_join;
	.section .hook_recadd1,"ax"
	.global __hook_recadd1
__hook_recadd1:
	call _kn_rec_clip_add;
	.section .hook_recadd2,"ax"
	.global __hook_recadd2
__hook_recadd2:
	call _kn_rec_clip_add;
	.section .hook_recadd3,"ax"
	.global __hook_recadd3
__hook_recadd3:
	call _kn_rec_clip_add;
	.section .hook_recadd4,"ax"
	.global __hook_recadd4
__hook_recadd4:
	call _kn_rec_clip_add;
	.section .hook_recadd5,"ax"
	.global __hook_recadd5
__hook_recadd5:
	call _kn_rec_clip_add;
	.section .hook_recstart,"ax"
	.global __hook_recstart
__hook_recstart:
	call _kn_rec_start;
/* tape writeback and disk mode flush (kennel/kn_tape.c) */
	.section .hook_tapewrite,"ax"
	.global __hook_tapewrite
__hook_tapewrite:
	call _kn_tape_write;
/* tape cache load, R246's CALL yaffs_read in tape_c::service (one per track): STEFAN's mask (kennel/kn_tape.c) */
	.section .hook_taperead,"ax"
	.global __hook_taperead
__hook_taperead:
	call _kn_tape_read;
	.section .hook_disk1,"ax"
	.global __hook_disk1
__hook_disk1:
	call _kn_disk_toggle;
	.section .hook_disk2,"ax"
	.global __hook_disk2
__hook_disk2:
	call _kn_disk_toggle;
	.section .hook_disk3,"ax"
	.global __hook_disk3
__hook_disk3:
	call _kn_disk_toggle;
	.section .hook_disk4,"ax"
	.global __hook_disk4
__hook_disk4:
	call _kn_disk_toggle;
/* snapshot save hook (kennel/kn_save.c): the global controller's hold-to-save pass, and its two date-stamp
 * snprintf calls (synth / drum) -> _kn_stamp_stub: stock snprintf unless a feature's name is armed */
	.section .hook_savesvc,"ax"
	.global __hook_savesvc
__hook_savesvc:
	call _kn_save_service;
	.section .hook_stampsyn,"ax"
	.global __hook_stampsyn
__hook_stampsyn:
	call _kn_stamp_stub;
	.section .hook_stampdrm,"ax"
	.global __hook_stampdrm
__hook_stampdrm:
	call _kn_stamp_stub;
	.text
	.align 2
	.global _kn_stamp_stub
_kn_stamp_stub:
	P0.L = _kn_snap_armed; P0.H = _kn_snap_armed;
	P0 = [P0];
	CC = P0 == 0;
	IF !CC JUMP _kn_stamp_mine;
	P0.L = 0xce04; P0.H = 0x01a9;		/* snprintf: arguments untouched (5 on the stack) */
	JUMP (P0);
_kn_stamp_mine:
	JUMP.L _kn_snap_name;			/* (dst, size): the name */
/* tape hook point (kennel/kn_tape.c): note input observers at VoiceCtl key_down / key_up's entries (LINK 0x10 /
 * LINK 0x20), the tape draw's recording-state CALL, tape_c's chunk lookup entry (LINK 0, called from the L1 tape
 * tick). Each entry stub first reads its core pointer: 0 = the original first instruction, then on (stock but for
 * P0 and a few cycles; checked in R246: all three bodies write P0 before reading it, key_down takes R0 / R1 only,
 * key_up R0). Otherwise the C side runs with RETS, ASTAT, the arguments and both hardware loops kept (the callers are
 * VisualDSP code). */
	.section .hook_vcdown,"ax"
	jump.l _kn_vcdown_stub;
	.section .hook_vcup,"ax"
	jump.l _kn_vcup_stub;
	.section .hook_tapepre,"ax"
	call _kn_tape_pre;
	.section .hook_tlookup,"ax"
	jump.l _kn_lookup_stub;
	.text
	.align 2
_kn_vcdown_stub:
	[--SP] = ASTAT;
	P0.L = _kn_note_obs; P0.H = _kn_note_obs;
	P0 = [P0];
	CC = P0 == 0;
	IF CC JUMP _kn_vcdown_stock;
	[--SP] = RETS; [--SP] = R0; [--SP] = R1;
	[--SP] = LC0; [--SP] = LT0; [--SP] = LB0; [--SP] = LC1; [--SP] = LT1; [--SP] = LB1;
	R2 = RETS;			/* caller: the note's source (kn_midi.c) */
	SP += -12;
	call _kn_note_input_down;
	SP += 12;
	LB1 = [SP++]; LT1 = [SP++]; LC1 = [SP++]; LB0 = [SP++]; LT0 = [SP++]; LC0 = [SP++];
	R1 = [SP++]; R0 = [SP++]; RETS = [SP++];
_kn_vcdown_stock:
	ASTAT = [SP++];
	LINK 0x10;
	P0.L = 0x5754; P0.H = 0x01a8;
	JUMP (P0);
	.align 2
_kn_vcup_stub:
	[--SP] = ASTAT;
	P0.L = _kn_note_obs; P0.H = _kn_note_obs;
	P0 = [P0];
	CC = P0 == 0;
	IF CC JUMP _kn_vcup_stock;
	[--SP] = RETS; [--SP] = R0;
	[--SP] = LC0; [--SP] = LT0; [--SP] = LB0; [--SP] = LC1; [--SP] = LT1; [--SP] = LB1;
	R1 = RETS;			/* caller (key_up takes R0 only) */
	SP += -12;
	call _kn_note_input_up;
	SP += 12;
	LB1 = [SP++]; LT1 = [SP++]; LC1 = [SP++]; LB0 = [SP++]; LT0 = [SP++]; LC0 = [SP++];
	R0 = [SP++]; RETS = [SP++];
_kn_vcup_stock:
	ASTAT = [SP++];
	LINK 0x20;
	P0.L = 0x5844; P0.H = 0x01a8;
	JUMP (P0);
	.align 2
_kn_lookup_stub:
	[--SP] = ASTAT;
	P0.L = _kn_lookup_owner; P0.H = _kn_lookup_owner;
	P0 = [P0];
	CC = P0 == 0;
	IF CC JUMP _kn_lookup_stock;
	[--SP] = RETS;
	[--SP] = LC0; [--SP] = LT0; [--SP] = LB0; [--SP] = LC1; [--SP] = LT1; [--SP] = LB1;
	SP += -12;
	call _kn_tape_lookup;
	SP += 12;
	LB1 = [SP++]; LT1 = [SP++]; LC1 = [SP++]; LB0 = [SP++]; LT0 = [SP++]; LC0 = [SP++];
	RETS = [SP++];
	ASTAT = [SP++];
	rts;
_kn_lookup_stock:
	ASTAT = [SP++];
	.global _kn_lookup_orig
_kn_lookup_orig:                              /* the stock lookup, callable: its first instruction, then the rest */
	LINK 0;
	P0.L = 0x4d60; P0.H = 0x01a5;
	JUMP (P0);
/* USB-in buffer (idle-cpu, 2026-11-07): R246's audio callback calls 0x019E193C(0x01AB2E2C, ..) before every block. With
 * no USB audio input (byte 0x018B5FD8 == 0, or its state word 0x018B6034 <= 5) it zeroes the 512-byte buffer with 128
 * stores and then updates its ring position (0x019E1A2A..); else it fills the buffer from the USB ring. The buffer is in
 * SDRAM with no write-allocate, so every block's 128 stores of zero miss the cache (OP1-Emulator
 * docs/idle-cpu-analysis-2026-11-07.md). Nothing else writes it (its only writer is this function, its only reader
 * core_block_process with input source 3). Here: the same tests as 0x019E1950..0x019E195C; a fill clears
 * _kn_altin_zero; an idle call clears the buffer the stock way once and sets it, and later idle calls skip only the
 * stores (the buffer already holds the zeros they would write) and run the stock tail. Same frame, P1 = buffer, R3 = 0
 * as the stock code has at 0x019E1A2A. Bit-exact by construction. */
	.section .hook_altin,"ax"
	jump.l _kn_altin_stub;
	.section .bss.kn_hot,"aw",@nobits
	.align 4
	.global _kn_altin_zero
_kn_altin_zero:
	.space 4
	.section .text.kn_audio,"ax"                      /* every block (kn_mem.h kn_audio_text) */
	.align 2
_kn_altin_stub:
	LINK 0;                                   /* the stock prologue (0x019E193C..0x019E1942) */
	[--SP] = (R7:4, P5:5);
	SP += -16;
	P5.L = 0x5fd8; P5.H = 0x018b;
	P1 = R0;
	R3 = B[P5] (X);
	CC = R3 == 0;
	IF CC JUMP 1f;
	R3 = [P5 + 0x5c];
	CC = R3 <= 5 (IU);
	IF CC JUMP 1f;
	P0.L = _kn_altin_zero; P0.H = _kn_altin_zero;   /* USB input: the stock fill (0x019E1954) writes the buffer */
	R3 = 0;
	[P0] = R3;
	P0.L = 0x1954; P0.H = 0x019e;
	JUMP (P0);
1:	P0.L = _kn_altin_zero; P0.H = _kn_altin_zero;
	R3 = [P0];
	CC = R3 == 0;
	IF CC JUMP 2f;
	R3 = 0;                                   /* already zero: the stock tail after the clear loop */
	P0.L = 0x1a2a; P0.H = 0x019e;
	JUMP (P0);
2:	R3 = 1;
	[P0] = R3;
	P0.L = 0x1a1c; P0.H = 0x019e;             /* the stock clear (P0 = 0x40, R3 = 0, 128 stores), then the tail */
	JUMP (P0);
	.section .hook_dpkeep,"ax"
	.global __hook_dpkeep
__hook_dpkeep:
	call _dp_keep_op1r;
	.section .hook_dpbrowse,"ax"
	.global __hook_dpbrowse
__hook_dpbrowse:
	call _dp_browser_id;
	.section .hook_dpload,"ax"
	.global __hook_dpload
__hook_dpload:
	call _dp_load_parse;
/* FX2 routing (screens/fxroute.c, op1r 44): the LFO / seq tick 0x019C9D04 (P1 = 0x01DD591E; B[P1] = 0; RTS; its caller
 * is L1 core_block_process right after the tape playback) -> fr_snap, which also does the tick's stock body */
	.section .hook_frsnap,"ax"
	jump.l _fr_snap;
/* CALL parse_patch_json in the synth slot loader (0x01A051F8) -> synth_load_parse (kennel/kn_patch_safe.c) */
	.section .hook_synthload,"ax"
	.global __hook_synthload
__hook_synthload:
	call _synth_load_parse;
/* sampler preset guard (kennel/kn_sampler_guard.c): patch_table_loader's user-row branch for "sampler count over the
 * limit" (0x01A05984, R0.L = the patch.cpp:629 text; then CALL panic) -> count back to the limit, row skipped. R1 still
 * holds the limit (the compare's imm7); R0 / P0 are dead there (the stock branch calls panic). 0x01A0596A is the
 * loop's next row (it reloads R4 / R7), past the all-patches count, so the skipped entry is not kept. */
	.section .hook_smpover,"ax"
	.global __hook_smpover
__hook_smpover:
	jump.l _kn_sampler_over_stub;
	.text
	.align 2
	.global _kn_sampler_over_stub
_kn_sampler_over_stub:
	R0 = R1;
	call _kn_sampler_over;
	P0.L = 0x596a; P0.H = 0x01a0;
	jump (P0);
/* disk-mode export (0x0199DA6C), sampler row: CALL yaffs_open at 0x0199DD7A, whose handle R246 never closes ->
 * kn_export_probe_open: the same open, closed again (kennel/kn_sampler_guard.c) */
	.section .hook_diskprobe,"ax"
	.global __hook_diskprobe
__hook_diskprobe:
	call _kn_export_probe_open;
	.section .hook_sqlcache,"ax"
	.global __hook_sqlcache
__hook_sqlcache:
	call _sqlite_cache_hook;
	.section .hook_usbiso2,"ax"
	.global __hook_usbiso2
__hook_usbiso2:
	call _usb6_iso_in;
	.section .hook_usbiso3,"ax"
	.global __hook_usbiso3
__hook_usbiso3:
	call _usb6_iso_in_silent;
	.section .hook_usbbuf1,"ax"
	.global __hook_usbbuf1
__hook_usbbuf1:
	R2 = 0x33c (X);
	.section .hook_usbbuf2,"ax"
	.global __hook_usbbuf2
__hook_usbbuf2:
	R2 = 0x33c (X);

/* ---- L1 vector: fixed entry points for the calls patched into the encrypted L1 code ----
 * Placed first in .text (link.ld), so its addresses (CODE_BASE + 4 * i) never move: the encrypted L1 patches are
 * then constant and ship as precomputed bytes (l1_patches.json); plugins can change without regenerating them.
 * JUMP.L keeps all registers, RETS and ASTAT: the target returns straight to the L1 caller. Append only. */
	.section .l1vec, "ax"
	.global _l1v_metro, _l1v_push_lr, _l1v_push_interleaved, _l1v_rs_probe
_l1v_metro:            JUMP.L _ci_metro_render
_l1v_push_lr:          JUMP.L _usb6_push_lr
_l1v_push_interleaved: JUMP.L _usb6_push_interleaved
_l1v_rs_probe:         JUMP.L _l1_rs_probe

/* Instrument fade: original envelope fast path when idle. Adapted from op1r-src hook_spadsr. */
.section .hook_knfadeadsr,"ax"
jump.l _kn_sound_adsr_entry;
.section .text.kn_audio,"ax"                              /* per voice, every block (kn_mem.h kn_audio_text) */
.global _kn_sound_adsr_entry
.align 2
_kn_sound_adsr_entry:
 P1.L = _kn_fade_live; P1.H = _kn_fade_live;
 R3 = B[P1] (Z);
 CC = R3 == 0;
 IF !CC JUMP 1f;
 P1.L = _kn_sampler_adsr_live; P1.H = _kn_sampler_adsr_live;
 R3 = B[P1] (Z);
 CC = R3 == 0;
 IF !CC JUMP 1f;
 P1.L = _kn_engine_adsr_live; P1.H = _kn_engine_adsr_live;   /* an own-envelope engine is loaded (dispatcher.c) */
 R3 = B[P1] (Z);
 CC = R3 == 0;
 IF !CC JUMP 1f;
 [--SP] = (R7:4, P5:3);
 P5 = R2;
 jump.l _kn_sound_adsr_cont;
1: jump.l _kn_sound_adsr;
.global _kn_sound_adsr_stock
.align 2
_kn_sound_adsr_stock:
 [--SP] = (R7:4, P5:3);
 P5 = R2;
 jump.l _kn_sound_adsr_cont;

.section .hook_lander1,"ax"
call _lander_stub;
.section .hook_lander2,"ax"
call _lander_stub;
.section .hook_lander3,"ax"
call _lander_stub;

/* Physical-key note construction and octave release/replay. */
.section .hook_keydown,"ax"
call _kn_keys_down;
.section .hook_keyup,"ax"
call _kn_keys_up;
.section .hook_keyoct0,"ax"
call _kn_keys_octave;
.section .hook_keyoct1,"ax"
call _kn_keys_octave;
.section .hook_keyoct2,"ax"
call _kn_keys_octave;
.section .hook_keyoct3,"ax"
call _kn_keys_octave;
.section .hook_keyoct4,"ax"
call _kn_keys_octave;
.section .hook_keyoct5,"ax"
call _kn_keys_octave;

/* Queued synth octave / slot steps (CALL 0x01A0CEFC): skipped while a kennel sequencer type is the synth one. */
.section .hook_seqoct0,"ax"
call _kn_seq_octave_queue;
.section .hook_seqoct1,"ax"
call _kn_seq_octave_queue;

/* VoiceCtl reset: replay its original LINK 0 before resuming. */
.section .hook_notesreset,"ax"
jump.l _kn_notes_reset;
.text
.global _kn_notes_reset_stock
.align 2
_kn_notes_reset_stock:
 LINK 0;
 jump.l _kn_notes_reset_cont;

/* VoiceCtl's MIDI release of its held list (0x01A8624C): MIDI out of keys on the pipeline path first (kn_midiout.c),
 * then R246's, replaying its LINK 0. */
.section .hook_morelease,"ax"
jump.l _kn_mo_release;
.text
.global _kn_mo_release_stock
.align 2
_kn_mo_release_stock:
 LINK 0;
 jump.l _kn_mo_release_cont;

/* Stock slot selection transposes held voices just like the octave path. */
.section .hook_keyslot,"ax"
jump.l _kn_keys_slot;
.text
.global _kn_keys_slot_stock
.align 2
_kn_keys_slot_stock:
 LINK 0x10;
 jump.l _kn_keys_slot_cont;

/* All preset import paths share native sound repair before returning to the caller. */
.section .hook_pparse1,"ax"
call _patch_parse_safe;
.section .hook_pparse2,"ax"
call _patch_parse_safe;
.section .hook_pparse3,"ax"
call _patch_parse_safe;

/* coop-fw's stock DSP rewrites (dsp/coop/*_fast.S, coldsoldr; through op1r-src e6219e4; ARCHITECTURE.md "coop-fw stock
 * DSP"): the stock per-sample loops of DSynth, Phase, phone, nitro, cwo, grid, spring and delay jump into the
 * rewrites (punch: its stereo render slot, screens/mlfo.c ml_st_punch). make_firmware.py HOOKS checks the stock bytes. */
.section .hook_coop_dsynth,"ax"
jump.l _coop_dsynth_voice_loop;
.section .hook_coop_cwo,"ax"
jump.l _coop_cwo_loop_near;
.section .hook_coop_cwo_v0,"ax"
call _coop_cwo_vec_ctor;
.section .hook_coop_cwo_v1,"ax"
call _coop_cwo_vec_ctor;
.section .hook_coop_cwo_v2,"ax"
call _coop_cwo_vec_ctor;
.section .hook_coop_cwo_v3,"ax"
call _coop_cwo_vec_ctor;
.section .hook_coop_phone,"ax"
jump.l _coop_phone_loop_near;
.section .hook_coop_phonecap,"ax"
jump.l _coop_phone_capture_near;
.section .hook_coop_grid,"ax"
jump.l _coop_grid_loop_near;
.section .hook_coop_delay,"ax"
jump.l _coop_delay_loop_near;
.section .hook_coop_nitro,"ax"
jump.l _coop_nitro_loop_near;
.section .hook_coop_spring,"ax"
jump.l _coop_spring_loop_near;
.section .hook_coop_phase,"ax"
jump.l _coop_phase_loop_near;

/* Crash screen (kennel/kn_crash.c; op1r-src 8bf2f84, xoza): te_fatal_show_message 0x0191995C (R0 = message) entry
 * LINK 0x10 -> kn_crash_stub. Its frame rebuilt as the stock entry makes it (LINK 0x10, R7:4 / P5:3 pushed, P5 = the
 * text buffer 0x01BA138C, 16 bytes of locals), our text instead of its FP chain, then its own tail from 0x01919A1A
 * (the text drawn with the built-in bitmap font 0x019416EA, the frame sent to the panel 0x01A36AB6, its epilogue),
 * then a key restarts (kn_crash_wait, never returns). */
/* disk mode writes: usb_ms_write_sectors (0x01A715DC, LINK 0) -> kn_ms_write, same arguments and result (kennel/kn_tapes.c) */
.section .hook_mswrite,"ax"
jump.l _kn_ms_write;
/* FatFs disk_write (0x01976288, LINK 0) -> kn_disk_write: tapes 2..4 stay sparse under R246's own writes (kn_tapes.c) */
.section .hook_diskwr,"ax"
jump.l _kn_disk_write;
/* the defragmenter's cluster write (0x01974C58, LINK 0x20) -> kn_defrag_write: the same for its copies (kn_tapes.c) */
.section .hook_defragwr,"ax"
jump.l _kn_defrag_write;
.section .hook_crash,"ax"
jump.l _kn_crash_stub;
.text
.align 2
.global _kn_crash_stub
_kn_crash_stub:
 call _kn_crash_frame;
 call _kn_crash_wait;
_kn_crash_frame:
 LINK 0x10;
 [--SP] = (R7:4, P5:3);
 P5.L = 0x138c; P5.H = 0x01ba;
 SP += -0x10;
 call _kn_crash_print;
 P5.L = 0x138c; P5.H = 0x01ba;
 P0.L = 0x9a1a; P0.H = 0x0191;
 jump (P0);
