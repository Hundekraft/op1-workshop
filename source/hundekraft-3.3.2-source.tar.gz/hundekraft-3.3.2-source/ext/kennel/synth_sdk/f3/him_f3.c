/* HIM's facet3d port, part 1: the camera and maths, occlusion, the pixel plot, the anti-aliased wide-line
 * rasteriser, the segment flush (dark-gap pass, dashes), 2D polylines and segments, and the 3D polylines, spheres,
 * circles, ticks and glyphs. the original 3D renderer (0.2.5), ported with the author's permission (per the owner,
 * 2026-11-09), statement by statement from the original's code so the pixels are the same (test/f3_oracle.py).
 * GUI thread only. Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission. */
#include "him_f3_int.h"
#include "him_data.h"
#ifdef F3_CORE                                      /* the core build (make_firmware.py): the state lives in .farbss */
#include "../kn_mem.h"
#else
#define kn_farbss
#endif

f3_state f3s kn_farbss;                                     /* zero fill, as the renderer's (rows 376 until a frame says) */
uint16_t *(*f3_page_pixels)(int *rows);
static const int LINE_W[3] = { 512, 384, 256 }, GAP_W[3] = { 1024, 896, 0 };
static const int DASH_ON[4] = { 0, 1024, 768, 154 }, DASH_OFF[4] = { 0, 768, 768, 614 };
static const signed char GLYPH_SQUARE[8] = { -1, -1, 1, -1, 1, 1, -1, 1 }, GLYPH_DIAMOND[8] = { 0, -1, 1, 0, 0, 1, -1, 0 },
                         GLYPH_TRIANGLE[6] = { 0, -1, 1, 1, -1, 1 };


unsigned f3i_isqrt(unsigned n)
{
    unsigned bit = 0x40000000u, r = 0;
    if (n < 0x40000000u) { do bit >>= 2; while (n < bit); if (!bit) return 0; }
    do {
        const unsigned t = bit + r;
        r >>= 1;
        if (t <= n) { n -= t; r += bit; }
        bit >>= 2;
    } while (bit);
    return r;
}

void f3i_sincos(int a, int *s, int *c)
{
    const unsigned q = (unsigned)(a >> 10), i = (unsigned)a & 0x3ff;
    int sv = HIM_SIN[1024 - i], cv = HIM_SIN[i];
    if (!(q & 1)) { sv = HIM_SIN[i]; cv = HIM_SIN[1024 - i]; }
    if (q & 2) sv = -sv;
    *s = sv;
    if ((q & 3) - 1 < 2) cv = -cv;
    *c = cv;
}

void f3i_view(const int *p, int *out)
{
    const int *M = f3s.M, x = p[0], y = p[1], z = p[2];
    out[0] = ((M[0] * x + 0x800) >> 12) + ((M[1] * y + 0x800) >> 12) + ((M[2] * z + 0x800) >> 12);
    out[1] = ((y * M[4] + 0x800) >> 12) + ((M[3] * x + 0x800) >> 12) + ((M[5] * z + 0x800) >> 12);
    out[2] = ((M[7] * y + 0x800) >> 12) + ((x * M[6] + 0x800) >> 12) + ((z * M[8] + 0x800) >> 12);
}

void f3_mul(int out[9], const int a[9], const int b[9])
{
    int t[9];
    for (int r = 0; r < 3; r++)
        for (int k = 0; k < 3; k++)
            t[r * 3 + k] = ((b[3 + k] * a[r * 3 + 1] + 0x800) >> 12) + ((b[k] * a[r * 3] + 0x800) >> 12) +
                           ((b[6 + k] * a[r * 3 + 2] + 0x800) >> 12);
    for (int i = 0; i < 9; i++) out[i] = t[i];
}

void f3_rotation(int out[9], int a, int b, int c)
{
    int sa, ca, sb, cb, sc, cc, t[9];
    f3i_sincos(a, &sa, &ca); f3i_sincos(b, &sb, &cb); f3i_sincos(c, &sc, &cc);
    const int Ry[9] = { ca, 0, sa, 0, 0x1000, 0, -sa, 0, ca }, Rx[9] = { 0x1000, 0, 0, 0, cb, -sb, 0, sb, cb },
              Rz[9] = { cc, -sc, 0, sc, cc, 0, 0, 0, 0x1000 };
    f3_mul(t, Rx, Ry);
    f3_mul(out, Rz, t);
}

void f3_apply(int out[3], const int m[9], const int in[3], const int add[3])
{
    const int x = in[0], y = in[1], z = in[2];
    if (!m) { out[0] = x; out[1] = y; out[2] = z; }
    else {
        out[0] = ((m[1] * y + 0x800) >> 12) + ((m[0] * x + 0x800) >> 12) + ((m[2] * z + 0x800) >> 12);
        out[1] = ((m[4] * y + 0x800) >> 12) + ((m[3] * x + 0x800) >> 12) + ((m[5] * z + 0x800) >> 12);
        out[2] = ((m[6] * x + 0x800) >> 12) + ((m[7] * y + 0x800) >> 12) + ((m[8] * z + 0x800) >> 12);
    }
    if (add) { out[0] += add[0]; out[1] += add[1]; out[2] += add[2]; }
}

void f3_to_view(const int p[3], int out[3]) { f3i_view(p, out); }

void f3_to_page(const int v[3], int *x, int *y)
{
    *x = ((v[0] * f3s.scale) >> 12) + f3s.cx;
    *y = f3s.cy - ((f3s.scale * v[1]) >> 12);
}

void f3_begin(int yaw, int pitch, int scale, int cx, int cy, unsigned colour, int gap)
{
    f3_rotation(f3s.M, yaw, pitch, 0);
    f3s.cx = cx; f3s.cy = cy; f3s.colour = colour; f3s.gap = gap;
    f3s.mode = 0; f3s.alpha = 0x100; f3s.nsph = 0; f3s.hidden = 0; f3s.drawn = 0;
    f3s.scale = scale;
    int rows = 0;
    uint16_t *f = f3_page_pixels ? f3_page_pixels(&rows) : 0;
    if (rows > 0) f3s.rows = rows;
    else if (!f3s.rows) f3s.rows = 376;                       /* the renderer's default panel (rev 2) */
    f3s.frame = (colour >> 24) & 1 ? f : 0;
    const unsigned R = ((int)colour >> 19) & 0x1f, G = ((int)colour >> 10) & 0x3f, B = ((int)colour >> 3) & 0x1f;
    f3s.B = (int)B; f3s.G = (int)G; f3s.R = (int)R;
    f3s.ylo = f3s.rows / 160;
    f3s.yhi = f3s.rows * 0x92 / 0x140;
    f3s.S = (f3s.rows << 16) / 0x140;
    unsigned r = 0, g = 0, b = 0;
    for (int i = 0; i <= 32; i++) {
        f3s.ramp0[i] = (uint16_t)((uint16_t)(r >> 5) * 0x800 | (uint16_t)(g >> 5) * 0x20 | (uint16_t)(b >> 5));
        r += R; g += G; b += B;
    }
    if (!f3s.slen[0])
        for (int i = 0; i <= 256; i++) {
            const unsigned l = f3i_isqrt((unsigned)(i * i + 0x10000));
            f3s.slen[i] = (uint16_t)l;
            f3s.scos[i] = (uint16_t)(0x10000u / (l & 0xffff));
        }
}

void f3_end(void) { f3s.nsph = 0; }

int f3_drawn(int *hidden) { if (hidden) *hidden = f3s.hidden; return f3s.drawn; }

void f3_ink(unsigned colour, int flags)
{
    f3s.colour = colour;
    const unsigned R = (colour >> 19) & 0x1f, B = (colour >> 3) & 0x1f, G = (colour >> 10) & 0x3f;
    f3s.R = (int)R; f3s.G = (int)G; f3s.B = (int)B;
    const int a = (int)((unsigned)flags & 0xfffeffffu);
    const int c = a > 0x100 ? 0x100 : a;
    f3s.alpha = c < 0 ? 0 : c;
    f3s.ramp0[32] = (uint16_t)(R * 0x800 | G * 0x20 | B);
    if (!(((unsigned)flags >> 16) & 1)) { f3s.mode = 1; return; }
    f3s.mode = 2;
    const int step = f3s.alpha * 8;
    int v = 0;
    for (int i = 0; i <= 32; i++, v += step) {
        const int lv = v >> 8;
        f3s.ramp2[i] = v < 0x1800 ? 0 : (uint16_t)(((int)(R * lv) >> 8) << 11 | ((int)(G * lv) >> 8) << 5 | (int)(lv * B) >> 8);
    }
}

/* ---- occlusion (0x00C8) ---- */
int f3i_visible(const int *p, int near, int skip)
{
    for (int k = 0; k < f3s.nsph; k++) {
        if (skip == k) continue;
        const int *s = f3s.sph[k], r = s[3];
        int dx = p[0] - s[0];
        if (!(dx < r && -r < dx)) continue;
        const int dy = p[1] - s[1];
        if (!(dy < r && -r < dy)) continue;
        dx = dx * dx + dy * dy;
        if (dx < r * r) {
            const int dz = (p[2] - s[2]) + (near == k ? r >> 4 : r >> 7);
            if (dz < 0 || dz * dz + dx < r * r) return 0;
        }
    }
    return 1;
}

void f3i_outline(int i);
int f3_sphere(const int c[3], int r, int outline)
{
    const int k = f3s.nsph;
    if (k >= 8 || r <= 0) return -1;
    int v[3];
    f3i_view(c, v);
    f3s.sph[k][0] = v[0]; f3s.sph[k][1] = v[1]; f3s.sph[k][2] = v[2]; f3s.sph[k][3] = r;
    f3s.nsph = k + 1;
    if (outline) f3i_outline(k);
    return k;
}

int f3_project(const int p[3], int *x, int *y)
{
    int v[3];
    f3i_view(p, v);
    *x = ((v[0] * f3s.scale) >> 12) + f3s.cx;
    *y = f3s.cy - ((f3s.scale * v[1]) >> 12);
    return f3i_visible(v, -1, -1);
}

/* ---- the plot (0x015C) ---- */
void f3i_plot(unsigned x, int y, int cov, int erase)
{
    if (!(x < (unsigned)f3s.rows && f3s.ylo <= y && y <= f3s.yhi && cov > 0)) return;
    uint16_t *p = f3s.frame + ((f3s.rows - 1 - (int)x) * 0x100 + y);
    if (erase) { if (cov > 0x5f) *p = 0; return; }
    int i = cov >> 3;
    if (f3s.mode == 2) {
        uint16_t c;
        if (cov < 0x100) { c = f3s.ramp2[i]; if (!c) return; }
        else {
            if (!f3s.ramp2[32]) return;
            c = f3s.ramp2[32];
            if (f3s.alpha > 0xff) { *p = c; return; }
        }
        *p = f3i_max(*p, c);
    } else if (f3s.mode == 0) {
        if (cov > 0xff) i = 32;
        if ((*p & 0x7e0) < (f3s.ramp0[i] & 0x7e0)) *p = f3s.ramp0[i];
    } else {
        const int a = (f3s.alpha * (cov > 0x100 ? 0x100 : cov)) >> 8;
        if (a > 0) *p = a < 0x100 ? f3i_blend(*p, a) : f3s.ramp0[32];
    }
}

/* ---- the rasteriser (0x0938): page Q8 ends, width Q8 px; ends bit 0 / 1 extend the start / end by width / 2
 * (else 0.5 px). Without frame pixels the original draws through the host stroke-line call: here nothing. ---- */
void f3i_raster(int x0, int y0, int x1, int y1, int width, int erase, unsigned ends)
{
    if (!f3s.frame) return;
    const int S = f3s.S, rows = f3s.rows;
    const int Y0 = (y0 >> 4) * S >> 12, Y1 = (y1 >> 4) * S >> 12, X0 = (x0 >> 4) * S >> 12, X1 = (x1 >> 4) * S >> 12;
    const int dx = X1 - X0, dy = Y1 - Y0;
    const int ady = dy < 0 ? -dy : dy, adx = dx < 0 ? -dx : dx;
    const int ymaj = adx < ady;
    int A0, A1, B0, md, minor;
    if (ymaj) {
        if (dy >= 0) { A0 = Y0; A1 = Y1; B0 = X0; md = dy; minor = dx; }
        else { A0 = Y1; A1 = Y0; B0 = X1; md = -dy; minor = -dx; ends = ((ends * 2) & 2) | (unsigned)((int)ends >> 1); }
    } else {
        if (dx >= 0) { A0 = X0; A1 = X1; B0 = Y0; md = dx; minor = dy; }
        else { A0 = X1; A1 = X0; B0 = Y1; md = -dx; minor = -dy; ends = ((ends * 2) & 2) | (unsigned)((int)ends >> 1); }
    }
    int sl = 0, idx = 0;
    if (md) {
        sl = md < 0x40000 ? (minor * 4096) / md : (minor * 16) / (md >> 8);
        idx = (sl < 0 ? -sl : sl) >> 4;
    }
    const uint16_t full = f3s.ramp2[32];
    const unsigned cosk = f3s.scos[idx], w2 = (unsigned)width >> 1;
    const unsigned e0 = (ends & 1) ? w2 : 0x80, e1 = ((ends >> 1) & 1) ? w2 : 0x80;
    const int t0 = (int)(e0 * cosk) >> 8;
    const int As = A0 - t0, Ae = ((int)(e1 * cosk) >> 8) + A1;
    if (!(As < Ae)) return;
    int B = B0 - ((t0 * sl) >> 12);
    if (minor == 0 && width <= 0x100) B = (B >> 8) * 0x100 + 0x80;
    int m = As >> 8;
    const int hl = f3s.slen[idx] >> 1;
    int mlast = (Ae - 1) >> 8;
    int minlo = f3s.ylo, minhi = f3s.yhi, majlo, majhi;
    if (ymaj) { minlo = 0; minhi = rows - 1; majlo = f3s.ylo; majhi = f3s.yhi; }
    else { majlo = 0; majhi = rows - 1; }
    mlast = imin(majhi, mlast);
    m = imax(m, majlo);
    const int fast = f3s.mode == 2 ? (erase ^ 1) : 0;
    int mq = m * 0x100;
    int c = ((((mq + 0x80) - As) >> 4) * sl >> 4) + B * 0x10;
    if (m > mlast) return;
    const int step = ymaj ? -0x100 : 1;
    const int hw = (int)(f3s.slen[idx] * w2) >> 8;
    int rowoff = (rows - 1 - m) * 0x100;
    const int part_alpha = f3s.alpha < 0x100;
    for (;;) {
        const int me = mq + 0xff < Ae ? mq + 0x100 : Ae;
        const int lo = (c >> 4) - hw, hi = hw + (c >> 4);
        const int n0 = imax((((lo - hl) - 0x80) >> 8) + 1, minlo);
        const int n1 = imin((hl + hi - 0x81) >> 8, minhi);
        if (n0 <= n1) {
            const int part = me - imax(mq, As);
            const int pc = n0 * 0x100 + 0x80;
            if (!fast) {
                int q = hl + pc;
                for (int n = n0; n <= n1; n++, q += 0x100) {
                    int cov = (int)((unsigned)(imin(hi, q) - imax(lo, q - 2 * hl)) * cosk) >> 8;
                    if (part < 0x100) cov = cov * part >> 8;
                    if (cov > 0) { if (ymaj) f3i_plot((unsigned)n, m, cov, erase); else f3i_plot((unsigned)m, n, cov, erase); }
                }
            } else {
                uint16_t *p = f3s.frame + (ymaj ? (rows - 1 - n0) * 0x100 + m : n0 + rowoff);
                int q = pc - hl;
                int cnt = (int)((unsigned)((n1 * 0x100 - hl) - q + 0x80) >> 8) + 1;
                do {
                    int cov = (int)((unsigned)(imin(hi, q + 2 * hl) - imax(q, lo)) * cosk) >> 8;
                    if (part < 0x100) cov = cov * part >> 8;
                    if (cov < 0xf8) {
                        if (cov > 0) { const uint16_t cc = f3s.ramp2[cov >> 3]; if (cc) *p = f3i_max(*p, cc); }
                    } else if (part_alpha) { if (full) *p = f3i_max(*p, full); }
                    else *p = full;
                    p += step; q += 0x100;
                } while (--cnt > 0);
            }
        }
        m++; c += sl; rowoff -= 0x100;
        if (mlast < m) return;
        mq = m * 0x100;
    }
}

/* ---- the segment flush (0x0E5C): the line width and the dark gap's width (0: none) as the renderer passes them
 * (a style's LINE_W / GAP_W, or f3_seg_width's width, 0.2.6) ---- */
void f3i_flush(int width, int gapw, int on, int off)
{
    if (f3s.gap && gapw) {
        if (f3s.nseg < 1) { f3s.nseg = 0; f3s.open = 0; return; }
        for (int i = 0; i < f3s.nseg; i++)
            f3i_raster(f3s.seg[i][0], f3s.seg[i][1], f3s.seg[i][2], f3s.seg[i][3], gapw, 1, 3);
    }
    for (int i = 0; i < f3s.nseg; i++) {
        const int *s = f3s.seg[i];
        unsigned first = 0, last = 0;
        if (f3s.open) { first = i == 0; last = i == f3s.nseg - 1; }
        if (on <= 0 || off <= 0) {
            f3i_raster(s[0], s[1], s[2], s[3], width, 0, ((last ^ 1) << 1) | (first ^ 1));
            continue;
        }
        const int ddx = (s[2] - s[0]) >> 4, ddy = (s[3] - s[1]) >> 4;
        const unsigned len = f3i_isqrt((unsigned)(ddx * ddx + ddy * ddy));
        if (!len) continue;
        const unsigned lr = len * 0x10 * (unsigned)f3s.rows;
        if (lr <= 0x13f) continue;
        const unsigned L = (unsigned)(((uint64_t)lr * 0xCCCCCCCDu) >> 32) >> 8;
        const unsigned endbit = (last ^ 1) << 1, per = (unsigned)(on + off);
        unsigned u = 0;
        int ph = f3s.phase;
        for (;;) {
            const unsigned r = (u + (unsigned)ph) % per;
            if (r < (unsigned)on) {
                const unsigned end = u + (unsigned)on - r, e = L <= end ? L : end;
                const int f0 = (int)((u << 12) / L), f1 = (int)((e << 12) / L);
                unsigned eb = u == 0 ? (r != 0) : 0;
                if (L < end) eb |= endbit;
                f3i_raster(((s[2] - s[0]) * f0 >> 12) + s[0], ((s[3] - s[1]) * f0 >> 12) + s[1],
                           ((s[2] - s[0]) * f1 >> 12) + s[0], ((s[3] - s[1]) * f1 >> 12) + s[1], width, 0, eb);
                ph = f3s.phase;
                u = e;
                if (L <= u) break;
            } else {
                u = per + u - r;
                if (L <= u) break;
            }
        }
        f3s.phase = ph + (int)L;
    }
    f3s.nseg = 0; f3s.open = 0;
}
static void flush(int style, int on, int off) { f3i_flush(LINE_W[style], GAP_W[style], on, off); }

void f3_seg(const int (*xy)[2], int n, int closed, int style, int on, int off)
{
    if (n < 2) return;
    f3s.phase = 0; f3s.nseg = 0;
    int k = 0;
    for (int i = 0; i < n - (closed == 0); i++) {
        const int j = i + 1 < n ? i + 1 : 0;
        if (k < 320) { f3s.seg[k][0] = xy[i][0]; f3s.seg[k][1] = xy[i][1]; f3s.seg[k][2] = xy[j][0]; f3s.seg[k][3] = xy[j][1]; k++; }
    }
    f3s.nseg = k;
    f3s.open = closed == 0;
    const int g = f3s.gap;
    f3s.gap = 0;
    flush(style > 2 ? 2 : style < 0 ? 0 : style, on, off);
    f3s.gap = g;
}

void f3_lines(const int (*seg)[4], int n, int style)
{
    f3s.nseg = 0;
    int k = 0;
    for (int i = 0; i < n; i++)
        if (k < 320) { for (int j = 0; j < 4; j++) f3s.seg[k][j] = seg[i][j]; k++; }
    f3s.nseg = k;
    const int g = f3s.gap;
    f3s.gap = 0;
    flush(style > 2 ? 2 : style < 0 ? 0 : style, 0, 0);
    f3s.gap = g;
}

/* ---- 3D polylines (0x0358, 0x03E8, 0x0470, 0x1100, 0x1200) ---- */
static void bisect(const int *v, const int *h, int near, int skip, int *out)
{
    int vx = v[0], vy = v[1], vz = v[2], hx = h[0], hy = h[1], hz = h[2];
    for (int k = 5; k; k--) {
        const int m[3] = { (((hx - vx) + 1) * 0x800 >> 12) + vx, (((hy - vy) + 1) * 0x800 >> 12) + vy, (((hz - vz) + 1) * 0x800 >> 12) + vz };
        if (f3i_visible(m, near, skip) == 1) { vx = m[0]; vy = m[1]; vz = m[2]; }
        else { hx = m[0]; hy = m[1]; hz = m[2]; }
    }
    out[0] = vx; out[1] = vy; out[2] = vz;
}

static void append(const int *a, const int *b)
{
    if (f3s.nseg < 320) {
        int *s = f3s.seg[f3s.nseg];
        s[2] = ((b[0] * f3s.scale) >> 12) + f3s.cx;
        s[0] = ((a[0] * f3s.scale) >> 12) + f3s.cx;
        s[1] = f3s.cy - ((a[1] * f3s.scale) >> 12);
        s[3] = f3s.cy - ((b[1] * f3s.scale) >> 12);
        f3s.nseg++;
    }
    f3s.drawn++;
}

static void edge(const int *a, const int *b, int va, int vb, int near, int skip, int depth)
{
    int m[3];
    if (!va) {
        if (!vb) { f3s.hidden++; return; }
        bisect(b, a, near, skip, m);
        append(m, b);
        return;
    }
    if (!vb) { bisect(a, b, near, skip, m); append(a, m); return; }
    m[0] = (((b[0] - a[0]) + 1) * 0x800 >> 12) + a[0];
    m[1] = (((b[1] - a[1]) + 1) * 0x800 >> 12) + a[1];
    m[2] = (((b[2] - a[2]) + 1) * 0x800 >> 12) + a[2];
    if (depth == 2 || f3i_visible(m, near, skip)) { append(a, b); return; }
    edge(a, m, 1, 0, near, skip, depth + 1);
    edge(m, b, 0, 1, near, skip, depth + 1);
}

static void poly(const int (*p)[3], int n, int closed, int style, int dash, int near, int skip)
{
    if (n < 2) return;
    f3s.nseg = 0; f3s.phase = 0;
    int vp = f3i_visible(p[0], near, skip);
    f3s.open = closed == 0;
    const int count = (f3s.open ^ 1) + n - 1;
    for (int i = 0; i != count; i++) {
        const int j = (i + 1) % n;
        const int vj = f3i_visible(p[j], near, skip);
        edge(p[i], p[j], vp, vj, near, skip, 0);
        vp = vj;
    }
    const int d = dash > 3 ? 3 : dash < 0 ? 0 : dash, s = style > 2 ? 2 : style < 0 ? 0 : style;
    flush(s, DASH_ON[d], DASH_OFF[d]);
}

void f3i_outline(int i)
{
    const int r = f3s.sph[i][3];
    for (int k = 0; k < 96; k++) {
        int s, c;
        f3i_sincos((k * 0x1000) / 0x60, &s, &c);
        f3s.spts[k][0] = ((c * r + 0x800) >> 12) + f3s.sph[i][0];
        f3s.spts[k][1] = ((r * s + 0x800) >> 12) + f3s.sph[i][1];
        f3s.spts[k][2] = f3s.sph[i][2];
    }
    poly((const int (*)[3])f3s.spts, 0x60, 1, 0, 0, -1, i);
}

void f3_line(const int (*p)[3], int n, int closed, int style, int dash, int near)
{
    const int k = n > 0x100 ? 0x100 : n;
    for (int i = 0; i < k; i++) f3i_view(p[i], f3s.pts[i]);
    poly((const int (*)[3])f3s.pts, k, closed, style, dash, near, -1);
}

void f3_circle(const int m[9], const int c[3], int r, int n, int style, int dash, int near)
{
    if (n <= 2) return;
    const int k = n > 0x100 ? 0x100 : n;
    for (int i = 0; i < k; i++) {
        int s, co;
        f3i_sincos((i << 12) / k, &s, &co);
        const int loc[3] = { (co * r + 0x800) >> 12, 0, -((s * r + 0x800) >> 12) };
        f3_apply(f3s.cpts[i], m, loc, c);
    }
    for (int i = 0; i < k; i++) f3i_view(f3s.cpts[i], f3s.pts[i]);
    poly((const int (*)[3])f3s.pts, k, 1, style, dash, near, -1);
}

void f3_ring_ticks(const int m[9], const int c[3], int r, int n, int major_every, int len)
{
    for (int i = 0; i < n; i++) {
        int s, co;
        f3i_sincos((i * 0x1000) / n, &s, &co);
        int l = len;
        if (major_every >= 1 && i % major_every == 0) l = (len >> 1) + len;
        const int a[3] = { (s * r + 0x800) >> 12, 0, -((co * r + 0x800) >> 12) };
        const int b[3] = { (s * (l + r) + 0x800) >> 12, 0, -((co * (l + r) + 0x800) >> 12) };
        int pa[3], pb[3];
        f3_apply(pa, m, a, c);
        f3_apply(pb, m, b, c);
        f3i_view(pa, f3s.pts[0]);
        f3i_view(pb, f3s.pts[1]);
        poly((const int (*)[3])f3s.pts, 2, 0, l == len ? 2 : 1, 0, -1, -1);
    }
}

int f3_glyph(const int p[3], int kind)
{
    int v[3];
    f3i_view(p, v);
    if (!f3i_visible(v, -1, -1)) return 0;
    const int X = ((v[0] * f3s.scale) >> 12) + f3s.cx, Y = f3s.cy - ((f3s.scale * v[1]) >> 12);
    const signed char *t;
    int n;
    if (kind == 0) { t = GLYPH_SQUARE; n = 4; }
    else if (kind == 1) { t = GLYPH_TRIANGLE; n = 3; }
    else if (kind == 3) {
        for (int a = 0; a != 0x1000;) {
            int s0, c0, s1, c1;
            f3i_sincos(a, &s0, &c0);
            a += 0x200;
            f3i_sincos(a, &s1, &c1);
            f3i_raster(((c0 * 0x400 + 0x800) >> 12) + X, ((s0 * 0x400 + 0x800) >> 12) + Y, ((c1 * 0x400 + 0x800) >> 12) + X,
                       ((s1 * 0x400 + 0x800) >> 12) + Y, 0x180, 0, 3);
        }
        f3i_raster(X - 0x80, Y, X + 0x80, Y, 0x200, 0, 3);     /* the original passes its angle step (0x200) as the width */
        return 1;
    } else { t = GLYPH_DIAMOND; n = 4; }
    for (int i = 0; i < n; i++) {
        const int j = (i + 1) % n;
        f3i_raster(t[2 * i] * 0x300 + X, t[2 * i + 1] * 0x300 + Y, t[2 * j] * 0x300 + X, t[2 * j + 1] * 0x300 + Y, 0x180, 0, 3);
    }
    return n;
}
