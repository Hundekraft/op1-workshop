/* op1_bus.h: an insert on the instrument bus, and modulation for it from the LFOs (kennel cores from 2026-11-12; a file
 * that imports these is refused by older cores: an import is not exported by the core).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 *
 * Where it runs (kennel/kn_input.c, kn_bus.c): R246's core_block_process renders one instrument a block (play mode:
 * synth or drums, never both), decimates it to 64 samples at 44.1 kHz and calls core_bus_highpass, whose prologue
 * kennel owns. After the high-pass (and after an input engine) the core calls the insert on that bus, in place, for the
 * synth caller (pos 0) and the drum caller (pos 1); R246 then renders the instrument's FX (on or off) and the bus goes
 * on to the mixer and the tape. Not in game mode. One insert at a time: the channel strip (plugins/strip).
 *
 * Pre or post FX (op1_bus_post): post, the insert runs after R246's mono FX instead: from the FX switch declick at the
 * end of every mono FX render (kennel/kn_declick.c kn_dc_mono, after the declick), or, in a block where R246 will not
 * render the FX (its pointer empty or the slot's FX off: the same test core_block_process makes), at the end of the
 * input bus hook, after the gap declick. Either way once a block, on the bus that goes on to the mixer and the tape. The
 * insert changes position at the next block: to switch without a click it fades itself out first and calls
 * op1_bus_post from its own call, then fades in at the new place.
 *
 * Modulation: OP1_BUS_NMOD words, one per strip control (HPF, LPF, FREQ, GAIN, Q, DRIVE, LEVEL), Q15 offsets on the
 * control's 0..32767 word (32767 = the whole range). Sources publish once a block on the audio thread:
 *   OP1_BUS_SRC_SOUND   the sound's LFO (quad / pond: lfo/quadlfo.c, from the FX-position apply, every block while the
 *                       sound's LFO is on), for pos 0 or 1;
 *   OP1_BUS_SRC_MASTER  the master LFO (screens/mlfo.c), for every bus (OP1_BUS_ALL: synth, drum and master).
 * A source that did not publish in the last two blocks counts as 0 (an LFO switched off leaves nothing behind). The
 * insert gets the sum of the fresh sources, clamped, and adds it to its own words; it never writes the sum back into
 * what it saves. op1_bus_insert_on() tells an LFO page whether to offer the targets at all.
 */
#ifndef OP1_BUS_H
#define OP1_BUS_H
#include <stdint.h>

#define OP1_BUS_NMOD 7
enum { OP1_BUS_HPF, OP1_BUS_LPF, OP1_BUS_FREQ, OP1_BUS_GAIN, OP1_BUS_Q, OP1_BUS_DRIVE, OP1_BUS_LEVEL };
enum { OP1_BUS_SYNTH = 0, OP1_BUS_DRUM = 1, OP1_BUS_MASTER = 2, OP1_BUS_ALL = 3 };
enum { OP1_BUS_SRC_SOUND, OP1_BUS_SRC_MASTER, OP1_BUS_NSRC };

/* the insert: 64 samples in place on the audio thread (short, no division, no libc); mod: OP1_BUS_NMOD offsets.
 * pos 0 / 1: the instrument bus in bus, r = 0. pos 2 (OP1_BUS_MASTER): the master's L in bus and R in r, from R246's
 * output stage after the master EQ (pre) or after the master FX and the FX2 routing (post), before the metronome's
 * click and the master dynamics. */
typedef void (*op1_bus_insert_fn)(int pos, int16_t *bus, int16_t *r, const int16_t *mod);
int op1_bus_insert(op1_bus_insert_fn fn);                 /* 0 ok (also fn = 0: none), -1 another insert has it. Boot */
int op1_bus_insert_on(void);                              /* 1 while an insert is registered (any thread) */
void op1_bus_post(int pos, int post);                     /* pos 0..2: 1 = after the FX from the next block. Audio thread */
void op1_bus_mod_set(int src, int pos, const int16_t *mod);   /* audio thread: this block's offsets from src */
/* the idle gate (kennel cores from 2026-11-18): the core calls the insert for pos only while ui[pos] | au[pos] is set;
 * otherwise a bus site costs a load and a branch (no master LFO step, no modulation sum). ui: the plugin's UI thread
 * keeps it (a strip ON, its page open), au: its audio thread (still fading or moving). Both 3 bytes, the plugin's own,
 * for good. 0, 0: no gate (every block, as before). Boot */
void op1_bus_gate(const volatile uint8_t *ui, const volatile uint8_t *au);

/* ---- the tape-track insert (kennel cores from 2026-11-13: tape strips, screens/usbtrack.c) ----
 * Per-track processing of R246's four tape tracks, pre-fader: 64 samples at 44.1 kHz after R246's resampler (or
 * STEFAN's heads), before volume x level x mute fade x pan and the sum into tape L / R. What reads the track outs (USB
 * track channels PRE and POST, FX2 aux sends, sidechain / Ear TAPE sources) hears the processed tracks.
 * The core keeps the controls: per track seven words (OP1_BUS_HPF .. OP1_BUS_LEVEL, 0..32767) and word 7 (bits
 * OP1_TAPE_ON, OP1_TAPE_FOLLOW), op1_tape_words(); after changing them call op1_tape_changed() (any thread). A track is
 * wanted while ON and any word is off neutral (HPF 0, LPF 32767, GAIN / LEVEL 16384, DRIVE 0; FREQ and Q are neutral
 * with GAIN 0 dB), or ON with the follow bit while the master LFO publishes strip offsets (op1_bus_mod_set,
 * OP1_BUS_SRC_MASTER; b->mod then holds them, else 0): ON with every control flat and no LFO counts as inactive. While no track is wanted and the insert says none is still running, R246's
 * tape mix runs untouched (bit for bit). Otherwise the core plays the tape through its own mix (the takeover's fast
 * path: a few LSB from R246's rounding, all four tracks) or, while STEFAN plays, STEFAN's heads, and calls the insert
 * once a block with all four tracks; it processes the tracks in mask in place and returns the tracks that must run
 * next block although not wanted (a fade out, a glide back to flat).
 * Not called on cores without the takeover; op1_tape_insert_on() says whether the core has it. */
#define OP1_TAPE_NTRK 4
#define OP1_TAPE_ON 1                   /* word 7: the strip ON */
#define OP1_TAPE_FOLLOW 2               /* word 7: the track follows the master LFO's strip targets (wanted while it runs) */
typedef struct {
    int16_t (*tr)[64];                  /* the four tracks, in place */
    const volatile int16_t *g;          /* their gains this block: L 0..3, R 4..7 (Q15; 0 and 0 = muted or silent) */
    const volatile uint16_t (*kw)[8];   /* op1_tape_words() */
    const int16_t *mod;                 /* the master LFO's offsets (OP1_BUS_NMOD) for following tracks, or 0 */
    uint8_t mask;                       /* the tracks to process: wanted, or still running */
    uint8_t outs;                       /* a pre-fader reader wants the tracks (USB track outs, FX2 aux, sidechain) */
    uint8_t stefan;                     /* 1: STEFAN's heads, 0: R246's machine */
} op1_tape_blk;
typedef uint8_t (*op1_tape_insert_fn)(const op1_tape_blk *b);   /* audio thread; returns tracks still running */
int op1_tape_insert(op1_tape_insert_fn fn);             /* 0 ok (also fn = 0: none), -1 taken or no takeover. Boot */
int op1_tape_insert_on(void);                           /* 1 while a tape insert is registered */
volatile uint16_t (*op1_tape_words(void))[8];           /* the controls: [track][7 words + ON] */
void op1_tape_changed(void);                            /* any thread: the words changed (the wanted mask is redone) */
#endif
