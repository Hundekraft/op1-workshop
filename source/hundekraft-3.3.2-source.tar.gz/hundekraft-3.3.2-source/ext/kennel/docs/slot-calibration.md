# Slot calibration: reading the unit's worst block

`synth_sdk/harness/slot_budget.py` (in `make check`) is a packet gate. It counts bcore instructions against fixed
shares of the block, with a slope fitted in October to two sysmon averages. It does not say what the unit's page 7
will show. The owner's rule is about the page-7 worst block: REST 35, synth 35, each FX 12, headroom 6 (percent of the
580,525-cycle block). To compare the two, the harness needs a handful of readings from the unit. This page says how
to take them.

## What a reading is

One number per plugin and setting: **the worst INST (synth) or worst FX % on page 7**, with the settings that
produced it. The fit divides it by the plugin's modelled cold cycles (`cost_stalls` in plugin.json, as % of the
block) and gets a factor. Two spot checks so far gave 1.6 to 2.3 for small-state engines and about 4 to 5 for
big-state ones. Those are not a fit; four to six readings on current code are.

## Taking a reading

1. Use a **test build** (`KN_DIAG=1`). Release builds have no page 7 (ARCHITECTURE.md "Release and test builds").
   Build it from the kennel head you want measured and note its commit.
2. Load the plugin alone: no FX on the instrument and master unless the reading is for an FX. Nothing else that is
   heavy. Preset or settings exactly as listed below; write down anything you change.
3. Open the resource monitor and go to page 7 (`7/12` on the bottom line since 2026-11-11; `7/11` on older test
   builds). Entering page 7 starts a fresh worst block, and the counters run while page 7 or 8 shows, so play while it
   is open (or push once to restart).
4. Play for 20 to 30 s: six notes held (six voices), re-struck, turning the knobs. Let the worst block settle.
5. Read **INST** on the worst line for a synth, **FX** for an FX. Take a photo. If it keeps climbing, play on and
   read again at the end. One number.
   Builds with the named sources (branch `sysmon-names` and later): the three rows under the worst line say the same
   per plugin, `syn NAME n` for a synth (its renders, note_ons and sum block, without kennel's dispatch, which is in
   `kn`), `fx` / `dfx` / `mfx NAME n` for an FX at the synth, drum or master position. Write that number into the
   note too ("syn kastle 27"); the reading stays the worst-line INST or FX. For an LFO type or a drum synth there is
   no INST / FX number: read its row (`lfo matrix n`, `drm him n`) and say so in `settings`. The photo should show
   the rows; if a name is missing, its share is under 0.5 % or it is in `etc`.
6. Add it to `synth_sdk/harness/slot_calibration.json` under `readings`:

       {"plugin": "kastle", "settings": "6 voices, feedback and saturation full, noise and ring on, blue jumping",
        "worst_pct": 43, "date": "2026-11-12", "note": "core 1234abcd, IMG_2001"}

   `plugin` is the folder name in `synth_sdk/plugins`. `worst_pct` is the single page-7 number.

## What to read, in this order

1. **kastle**, six voices, feedback and saturation full, noise and ring on, blue jumping, INST worst. This is the
   reading that tells whether the other firmware's castle figure (24.9 %) is an emulator number or a unit number (about 28 % points
   to a unit reading; 43 % or more to an emulator one; see OP1-Emulator `docs/ports/cpu-budget-study.md` Q2). Kastle
   is on the `kastle` branch, not on main: build from there.
2. **dimension**, six voices, the heaviest page-1 settings, INST worst. Also not on main yet.
3. **khorus**, FX worst, heaviest settings (once on the instrument FX, once on the master if you can).
4. **outatime** (on main), six voices, chord then random knobs, INST worst. The 2026-10-29 reading was 28 % on older code.
5. **MBIRA** (on main), six voices re-struck, INST worst. Earlier 30 %.
6. **One big-state engine**: EVA or Oxbow, six voices, heaviest settings, INST worst. This one shows how far the
   factor spreads for engines with a lot of state.

A plugin needs `cost_stalls` to be used in the fit. `python3 synth_sdk/harness/plugin_cost.py --stalls --write NAME`
fills it (a bcore run, a few minutes); re-run it if the plugin's code changed since the reading.

## Fitting

    python3 synth_sdk/harness/slot_budget.py --fit            dry run: per-reading ratios, median, range
    python3 synth_sdk/harness/slot_budget.py --fit --write    store the result in slot_calibration.json

The fit needs four usable readings and skips any without `cost_stalls`. It stores the median and the lowest and
highest ratio. From then on `slot_budget.py` shows "unit estimate" as cold % times that range. Before a fit it uses
the spot checks' 1.6..2.3 and labels the column "uncalibrated". The packet gate itself (pass / fail, the allowlist)
does not change with the fit. Whether to move the gate onto the owner's slots is a separate decision once the
numbers are in.
