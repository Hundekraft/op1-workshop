# kennel plugin file format (version 1)

<!-- Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). -->

One file holds one synth engine or effect (later: one feature): its code and data linked from address 0, the
relocations that depend on where the loader puts it, the core symbols it calls, its screen SVG and its defaults.
`tools/kennel/pack.py` writes it from a plugin folder; `tools/kennel/reloc.py` is the reference loader (the
checks and the relocation the C loader must do, in the same order). `tools/kennel/test_plugin_format.py` packs
every plugin in `synth_sdk/plugins`, relocates it to two addresses and compares the bytes with a plain
`bfin-elf-ld` link at those addresses.

File name: `<id>.knl` (see "Names"). The loader reads `/yaffs2/plugins` and `/yaffs2/content` (`synth_sdk/kennel/kn_boot.c`;
it also reads op1r 34's `.op1p` files). The C loader is `synth_sdk/kennel/kn_load.c`, tested against
`reloc.py` by `tools/kennel/test_loader.py`.

## Names

One rule for every plugin; nothing else identifies one, and nothing matches a second name.

1. **The id**: `[a-z0-9_-]`, 1..15 characters. It is the plugin's folder (`synth_sdk/plugins/<id>`), its file
   (`<id>.knl`), the `plugin.json` `"name"`, the entry in `kennel.off`, the name in the inventory and the name a
   feature registers (`op1_feature_t.name`).
2. **The saved name**: the header's `type_name`, what the OP-1 shows and what saved sounds and kits store. It is the id
   with `_` turned into a space (`in_a_room` -> "in a room"). The packer derives it; it is never written by hand.
3. **Frozen exceptions**: names already in users' saved files that rule 2 cannot give. Only `drumplus` -> "drum+"
   (drum patch JSON `"engine": "drum+"`, the `drum_types` row). `plugin.json` may carry `"saved_name"` only for an id
   on this list (`pack.SAVED_NAMES`; `test_plugin_format.py` `test_names` holds the list fixed).

`pack.py` (`check_id`, also called by `plugins.py` for `make_firmware`) refuses an id or folder that breaks rule 1, a
folder that differs from its id, a file not named `<id>.knl` and a `"saved_name"` outside the list. The loader
matches `kennel.off` by the file's id (its name without `.knl` / `.op1p`), also for a file it cannot read, and lists
every file under its id. Engines and effects are numbered and picked by their saved name (`docs/preset-identity.md`).

## Rules
- Little-endian. Every block starts on a 4-byte boundary in the file; the file size is a multiple of 4.
- No PIC. The code is linked for address 0 and relocated at load. Absolute firmware addresses in the code
  (`0x01DF6F78`, `0xFF801950`, ...) are plain immediates and have no relocation.
- The loader skips a file that fails any check below, prints why, and boots on. A broken file never halts.

## SVG in front
A plugin with a screen starts with its SVG text, a NUL and zero padding to a 4-byte boundary; the header starts
there (`header_offset`). The stock SVG parser stops at the NUL, so the loader registers the plugin file itself as the
screen's SVG. Every other file offset in the header counts from the start of the file; the CRC is taken over the
whole file with the 4 CRC bytes (header + 12) as zero. Without a screen the header is at 0.

Per-panel art (2026-11-17): after the screen SVG's NUL there may be chunks `'K' 'V' code 0 | u32 size | text | NUL`
(size counts the whole chunk; code `a` = the 8-bit 320 x 156 panel, `d` = the default 400 x 200 panel; the screen SVG
itself is for the 376 x 188 panels b and C2). The header starts after the last chunk (4-byte boundary) and `svg_size`
still covers the screen SVG alone. R246's parser starts at the running panel's chunk (`kennel/kn_svgvar.c`); every
chunk follows the SVG rules (`pack.py`, `kn_boot.c` `svg_err_all`). docs/screen-art.md "Per-panel art".

## Header (144 bytes)

| Off | Type | Field | Meaning |
|---|---|---|---|
| 0 | char[4] | `magic` | `KNPL` |
| 4 | u16 | `format_version` | 1. A loader skips any other value. |
| 6 | u16 | `header_size` | 144 for now. Later version-1 files may append fields; a loader reads the first 144 bytes and ignores the rest. |
| 8 | u32 | `file_size` | whole file in bytes; must equal the size read |
| 12 | u32 | `crc32` | CRC-32 (zlib/IEEE, poly 0xEDB88320, init and final XOR 0xFFFFFFFF) over bytes 0..`file_size`-1 with these 4 bytes taken as zero |
| 16 | u16 | `api_version` | `OP1_PLUGIN_API` of `synth_sdk/op1_plugin.h` the plugin was built with; must equal the core's |
| 18 | u8 | `kind` | 1 synth engine (`op1_engine_t`), 2 effect (`op1_fx_t`), 3 feature (`op1_feature_t`, `synth_sdk/op1_feature.h`; the loader also checks its `api` against `OP1_FEATURE_API`) |
| 19 | u8 | `legacy_order` | `plugin.json` `order`: old sounds select the engine by `knobs[4] = 0x5300 + order` (`synth_sdk/plugins/ORDERS.md`). 0 = none (new plugins without an old selector). 1..31. |
| 20 | char[16] | `type_name` | the saved name ("Names": derived from the id): saved sounds pick the engine by this name (`docs/preset-identity.md`). ASCII, 1..15 characters, NUL-padded. |
| 36 | u32 | `flags` | bit 0 `uses_sample` (the slot's `synth_<slot>.raw` is loaded at boot), bit 1 `page2_defaults` valid, bit 2 `stereo` FX entry, bit 3 `input_engine`, bit 4 `bigbuf` (a declared pool buffer, "Declared pool buffer"), bit 5 `own_envelope` (synth: the entry is a 20-byte `op1_engine_env_t`, "Own envelope"), bit 6 `sum_block` (synth: the entry is a 24-byte `op1_engine_sum_t`, "Voice-sum block"), bit 7 `t2_page` (with bit 5: the entry is a 28-byte `op1_engine_ext_t`, "Own T2 page"; with bit 6 too, +20 is the sum block), bit 8 `t2_swallow` (with bit 7: kennel takes the encoders on that page, "Own T2 page"), bits 9..11 `engine_input` / `t4_page` / `service` (synth, non-sampler, non-input: the entry is a 40-byte `op1_engine_ext2_t`, op1_plugin.h; kennel ARCHITECTURE.md "Engine hooks for engines with their own pages"), bit 12 `cold` (feature only: no audio-thread code, loads into the cold tier, "Plugin memory"; cores before 3.4 refuse it), bits 16..19 `coarse` synth knobs 0..3 (see "Coarse knobs"); unknown bits refused |
| 40 | i16[4] | `defaults` | initial knob positions 0..32767 (blue, green, white, red) |
| 48 | i16[4] | `page2_defaults` | initial page-2 words 5..7 (FX `params[5..7]`, a synth's knob words 5..7; the synth_types / fx_types row), fourth entry 0; only with flag bit 1. An op1r `.op1p` synth's are ignored, as op1r |
| 56 | u32 | `text_size` | `.text` bytes, at image offset 0 |
| 60 | u32 | `rodata_offset` | image offset of `.rodata` |
| 64 | u32 | `rodata_size` | |
| 68 | u32 | `data_offset` | image offset of `.data` |
| 72 | u32 | `data_size` | |
| 76 | u32 | `bss_offset` | offset of `.bss` from the load address (>= `image_size`) |
| 80 | u32 | `bss_size` | bytes the loader zeroes after the image |
| 84 | u32 | `image_size` | bytes of image in the file (`data_offset + data_size`) |
| 88 | u32 | `image_align` | the load address must be a multiple of this (power of two, >= 4) |
| 92 | u32 | `entry_offset` | offset of the `op1_engine_t` / `op1_fx_t` object (or `op1_fx_stereo_t` with flag bit 2) from the load address |
| 96 | u32 | `screen_offset` | offset of the `op1_screen_t` object, or 0xFFFFFFFF |
| 100 | u32 | `image_file_offset` | file offset of the image |
| 104 | u32 | `reloc_offset` | file offset of the relocation table |
| 108 | u32 | `reloc_count` | entries (12 bytes each) |
| 112 | u32 | `import_offset` | file offset of the import table |
| 116 | u32 | `import_count` | entries (4 bytes each) |
| 120 | u32 | `strings_offset` | file offset of the string table |
| 124 | u32 | `strings_size` | bytes; the table starts with a NUL and ends with one |
| 128 | u32 | `svg_offset` | reserved, 0 (the SVG is always in front) |
| 132 | u32 | `svg_size` | 0 = no screen SVG; else its text length + the NUL (the file starts with it) |
| 136 | u32 | `svg_name` | reserved, 0xFFFFFFFF |
| 140 | u32 | `ext_offset` | file offset of the extension table (u16 tag, u16 length, bytes padded to 4; tag 0 ends it): 1 claims, 2 author, 3 version, 4 bigbuf, 5 cost. 0 = none. A loader skips tags it doesn't know |

The packer writes the blocks after the header in this order: image, relocations, imports, strings, each
padded with zeros to 4 bytes. A loader must not rely on the order; it uses the offsets.

## Memory layout at load

```
base + 0                 .text
base + rodata_offset     .rodata
base + data_offset       .data
base + bss_offset        .bss (bss_size bytes, zeroed)
base + bss_offset + bss_size   end: the loader allocates this much
```

Each section starts at the next multiple of max(4, its ELF alignment). The image in the file covers
`0 .. image_size` (text, rodata, data and the padding between them).

## Relocation table

Entries sorted by `offset`, 12 bytes each:

| Off | Type | Field |
|---|---|---|
| 0 | u32 | `offset`: image offset of the field (see the types) |
| 4 | u8 | `type` |
| 5 | u8 | reserved, 0 |
| 6 | u16 | `sym`: 0xFFFF = local (target inside the plugin), else index into the import table |
| 8 | i32 | `addend` |

Target value `V`: local: `base + addend` (the addend is an offset from the load address, 0..end); import:
`import_address[sym] + addend`. All arithmetic is mod 2^32. The loader writes the whole field; the bytes the
file holds there do not matter (the packer leaves the value for base 0).

| type | Name | Field | Write |
|---|---|---|---|
| 1 | `ABS32` | u32 at `offset` | `V` |
| 2 | `HI16` | u16 at `offset` (the immediate half of a `reg.H = imm16` instruction) | `V >> 16` |
| 3 | `LO16` | u16 at `offset` (`reg.L = imm16`) | `V & 0xFFFF` |
| 4 | `PCREL24` | 32-bit `CALL` / `JUMP.L` starting at `offset - 2` | `d = V - (base + offset - 2)`; d must be even and in -2^24 .. 2^24-2, else the plugin is skipped. `d >>= 1` (24 bits): halfword at `offset - 2` keeps its high byte and gets `d >> 16` in the low byte; halfword at `offset` = `d & 0xFFFF`. |

`HI16` and `LO16` are independent entries, each with the full target: no pairing, no carry adjustment (Blackfin
loads the halves with separate instructions). `PCREL24` appears only with an import; calls inside the plugin are
resolved by the packer because they move with it. A local `PCREL24` is an error.

Mapping from the ELF types (binutils `include/elf/bfin.h`) the packer accepts; anything else stops the packer:

| ELF | Number | File type |
|---|---|---|
| `R_BFIN_BYTE4_DATA` | 0x12 | `ABS32` (local or import) |
| `R_BFIN_HUIMM16` | 0x07 | `HI16` |
| `R_BFIN_LUIMM16` | 0x06 | `LO16` |
| `R_BFIN_PCREL24` | 0x0A | resolved by the packer when local, `PCREL24` for an import |
| `R_BFIN_PCREL24_JUMP_L` | 0x0D | as `R_BFIN_PCREL24` |

ELF `r_offset` of the two PCREL24 types points at the second halfword of the instruction, as `offset` does here.
A relocation against an absolute symbol is resolved by the packer (except PC-relative: error).

## Imports

`import_count` entries of one u32 each: the string-table offset of a symbol name the plugin needs from the core.
Names are stored as the ELF symbol names, with the C leading underscore (`_op1_fx_page`, `_read_fx_param_safe`,
`_sq_text`). The core keeps a table of the symbols it exports; a name it lacks makes the loader skip the plugin.
libgcc is linked into each plugin (`__divsi3`, `__muldi3`, ...), so the core does not have to export it.

## Optional stereo FX entry

`plugin.json` may set `"stereo": true` for an FX. The entry is `op1_fx_stereo_t`: the existing
12-byte Blackfin `op1_fx_t` prefix followed by a 4-byte `render_stereo(pos, left[64], right[64], params)`
callback. The prefix remains the synth/drum implementation; the stereo callback processes both master
channels directly at position 2. All state remains per position. The packer checks the entry symbol's
size, and the loader requires all 16 bytes inside the initialized image. After relocation its init,
mono render and stereo render must be non-null, halfword-aligned addresses with at least one instruction
inside this plugin's `.text`. A truncated entry, non-FX flag or invalid callback skips the file.

Existing mono `.knl` and `.op1p` objects keep their original layout and master mono-sum routing. A separate
core callback table holds only validated stereo callbacks; registering a mono replacement clears that slot.

op1r 42 `.op1p` files mark a stereo FX with their own header flag `OP1P_F_STEREO` = 2 (`plugload/op1p.h`; not the
`.knl` flag 4): their `op1_fx_t` then has `render_stereo` at +12, the same 16 bytes as `op1_fx_stereo_t`. The loader
refuses unknown `.op1p` flag bits and the flag on a synth, needs all 16 entry bytes inside the image, checks the
three callbacks after relocation (inside the initialized image: `.op1p` has no text boundary) and registers
`render_stereo` in the same callback table. A flagless `.op1p` FX keeps its 12-byte entry and mono-sum routing.
Generated built-in tables initialize this callback table before file registration. No new legacy order or
Maiko selector is implied by the flag: an unordered loadable plugin keeps name-based identity at 32..63.
The optional entry does not change the file/header version or existing mono ABI.

## Coarse knobs

`plugin.json` may set `"coarse": [k, ...]` (distinct knob numbers 0..3) for a synth: on the engine screen each listed
knob turns in 8 steps over 0..32767 (0, 4681, .. 32767; one step per encoder detent) instead of the stock fine steps,
on both pages (page 2 edits `OP1_ENG_PAGE_WORD(k)` the same way). Use it for a selector or a mode. The packer sets
header flag bit 16 + k; the loader refuses the bits on an FX or a feature. op1r 44 `.op1p` files carry the same
mask in their flags bits 16..19 (`OP1P_COARSE`); on an `.op1p` FX it is ignored, as op1r does. Registering a file
writes the engine's mask (0 without the field), so a replacement without coarse knobs clears it. A built-in engine
gets its mask from the generated table. Cores before this field refuse such a file as "unknown plugin flags".

## Stepped page 2 (no header change)

A synth engine can set `press[k] = OP1_PRESS_PAGE_STEPS(n)` (`op1_plugin.h`, n = 2..63, byte 0x40+n) in its own `op1_engine_t`:
a push toggles page 2 as `OP1_PRESS_PAGE` does, and the page-2 word turns in n steps, one per encoder detent (word
`((2i+1)*32768)/(2n)` for step i; a word's step is `(word*n)>>15`, an unset word starts at 8192). Page 1 is unchanged.
It is code in the plugin, not a field in the header or `plugin.json`, so the .knl format is the same; a core before it
treats the byte as an unknown press (no page 2).

## Stepped page 1 (core call, no header change)

A synth engine calls `op1_engine_knob_steps(&ENGINE_x, k, n)` (`op1_plugin.h`, n = 2..127; kennel cores from 2026-11-06)
from its screen's init, and page 1 of knob k turns in n steps, one per encoder detent (`kn_step_turn_range` over
0..32767: step i's word is `(2i+1)*32767/(2n)`, read back as `(word*n)>>15`). The core keeps it per engine (8 engines
at most; dispatcher.c `eng_steps`), n = 0 turns it off; page 2 and coarse knobs are unchanged. Strum's Pattern uses it.
A core before it refuses the file (unknown import).

## Loader steps (reloc.py `parse` then `relocate`)
1. Read the whole file. Check `magic`, `format_version`, `header_size`, `file_size`, `crc32`, `api_version`,
   `kind`, `legacy_order` <= 31, a NUL-terminated non-empty `type_name`.
2. Check every block lies inside the file and is 4-aligned (SVG and strings: any alignment), the section
   layout is in order (`text_size <= rodata_offset <= rodata end <= data_offset <= data end == image_size <=
   bss_offset`), `image_align` is a power of two >= 4, every string ends inside the table.
3. Check every relocation: known type, reserved byte 0, field inside the image and halfword-aligned, a local
   target inside 0..end, an import index below `import_count`, no local `PCREL24`. Check `entry_offset`
   (required) and `screen_offset` (or 0xFFFFFFFF) lie inside 0..end and are 4-aligned.
4. Look up every import in the core's export table.
5. Allocate end bytes (plus room for call stubs, below) at a base aligned to `image_align`; copy the image, zero
   `.bss`.
6. Apply the relocations; a `PCREL24` out of reach goes through a call stub (below), or fails the plugin when the
   loader has no stub room (`kn_relocate`, reloc.py `relocate(stubs=False)`: free the block, skip the file).
   `kn_validate` checks complete initialized descriptors, nested feature descriptors, bounded strings/claims,
   and required/optional callbacks before registration. Callbacks must be halfword-aligned within this
   plugin's `.text`; wrap a core service in a local callback instead of storing an imported address directly.
   OP1P has no text boundary, so its callback range is the initialized image. Synth/FX/screen descriptors
   require16/12/8 bytes (stereo FX16); feature API1 requires84. Claims extensions must end in an empty string.
7. Flush the data cache and invalidate the instruction cache over the block before calling into it.
8. Register: `base + entry_offset` into the engine/FX table, the screen object and SVG, the type name and the
   legacy selector `0x5300 + legacy_order` (when non-zero).

### Call stubs (kennel cores from 2026-10-31)
The code arena is in R246's heap 0 (below), more than 16 MiB below the core, so a plugin's `CALL` / `JUMP.L` into the
core cannot reach. `kn_relocate_far` (reloc.py `relocate(stubs=True)`) then points the instruction at a 12-byte stub
after the plugin, which jumps to the target absolutely: `P1.L = target; P1.H = target; JUMP (P1); NOP` (`09 E1 lo lo
49 E1 hi hi 51 00 00 00`). One stub per distinct target (address + addend), in the order the relocations first need
one, from the first 4-byte boundary at or after `end` (the pad bytes are 0). The loader reserves `3 + 12 x
import_count` bytes after `end` and gives back what the stubs did not use. `P1` is call-clobbered in the Blackfin ABI,
so a C caller cannot notice; a hand-written caller must not expect `P1` to survive a call into the core (as with any
call). A call that reaches directly takes no stub; data relocations never do. The format does not change.

## Plugin memory (kennel cores from 2026-10-21; the code arena in heap 0 from 2026-10-31)

The core's SDRAM map is `synth_sdk/kn_mem.h` (Python: `synth_sdk/kn_mem.py`); no other file holds an address.

| Range | Size | Use |
|---|---|---|
| a block of R246's heap 0 (0x00000100..0x00FFFFFC), 16 KB aligned | 2.5 MiB | code arena: images + `.bss` + call stubs, loader records, static-art cache. One `malloc` at the start of the boot hook (`kn_boot.c` `arena_init`), never freed; `kn_arena_lo` / `kn_arena_hi` say where |
| a block of heap 0, 16 KB aligned (only when a loaded file imports `op1_fx_fast`) | 3 x 224 KiB | fast FX leases, one per position (synth, drum, master): `op1_fx_fast`. One `malloc` after loading (`kn_boot.c` `fx_fast_take`), cleared, never freed; `kn_fx_fast` says where (0: none) |
| 0x02800000..0x02980000 | 1.5 MiB | undo area (`op1_undo_area`, one owner) |
| 0x02980000..0x02C00000 | 2.5 MiB | the cold tier while the arena is the heap-0 block: features with flag bit 12 (`kn_cold_lo` / `kn_cold_next` / `kn_cold_hi`); the fixed code arena for every file when heap 0 can't give the block (within PCREL24 reach: no stubs) |
| 0x02C00000..0x02F00000 | 3 MiB | FX position leases, 1 MiB each (synth, drum, master): `op1_fx_big` |
| 0x02F00000..0x03000000 | 1 MiB | declared buffers (flag bit 4); at boot first the file being read (staging, `KN_FILE_MAX` 1 MiB) |

**Cold tier** (bit 12 `cold`, plugin.json `"cold": true`, kennel cores from 3.4, 2026-11-16). A feature with no
audio-thread code loads into the fixed range 0x02980000..0x02C00000 (`kn_mem.h` `KN_COLD_LO..HI`, SDRAM bank 2,
slower cold fills: fine for main-loop, KeyHandler and Gfx code) with its own bump pointer, and `arena_need` leaves its
image out of heap 0's block. The rules, checked by the packer (`reloc.py` `cold_problem`) and by the loader
(`kn_load.c` `kn_cold_err`): the kind is feature; none of the imports `reloc.py` `COLD_IMPORTS` lists
(`op1_input_observe`, `op1_bus_insert`, `op1_bus_mod_set`, `op1_tape_insert`, `op1_sampler_register`,
`op1_drum_synth_register`, `op1_l1_claim`, `op1_countin_register`, `op1_fx_big`, `op1_fx_fast`), checked before
memory is taken; and in the relocated `op1_feature_t` none of `tick`, `seq`, `lfo`, `drum`, `tape`, `note_on`,
`note_off`, `note_in`, `midi_in`, `midi_raw`, `drum_synth` set. A file that breaks a rule is refused (logged "cold
file has audio-thread code" / "... imports an audio-thread service"; no fallback to heap 0, since sizing counted it
cold); the boot goes on. When the cold tier is full, a cold file goes to the heap-0 arena (sizing counts it there once
the cold sum passes 2.5 MiB, in load order). Its per-file records, `kn_alloc` and `op1_alloc` memory and the
static-art / region caches stay in heap 0. When heap 0 can't give the arena there is no cold tier: cold files share
the fixed range and its one bump pointer with every other file, as before. The LIST header's memory field adds
` cold <used> <room>` after `decl` (0 0 without a tier).

Files are at most 1 MiB (512 KiB before). The pool is cleared once per boot, after the last file was read and
before any plugin code runs; then the declared buffers get their pointers.

**FX lease.** `void *op1_fx_big(int pos, uint32_t *size)` (core export, `OP1_POOL_API` 1 in `op1_plugin.h`): the
position's lease and its size, 0 when the core has none. The rules of `op1_fx_scratch`: only the active FX of that
position uses it; the contents are undefined after an FX switch; never a DMA target. It is not cleared on an FX
switch, and `init` runs in the audio path, so an FX keeps a valid length instead of clearing (Steve: the captured
length). Read the size at run time. A file that imports `op1_fx_big` is refused by an older core ("an import is not
exported by the core").

**Fast FX lease.** `void *op1_fx_fast(int pos, uint32_t *size)` (core export, `OP1_FAST_API` 1, kennel cores from
2026-11-06): 224 KiB per position in R246's heap 0 (SDRAM bank 0), with `op1_fx_big`'s rules. For state an FX reads
every block: the pool shares bank 2 with display framebuffer A, where the unit measured a cold line fill ~1.8x bank 0's
(K1b). The core takes the three leases (688 KiB of heap 0 with the alignment) after loading, and only when a loaded
file imports `op1_fx_fast`; when heap 0 can't give them it returns 0 with `*size` 0, and the FX falls back to
`op1_fx_big` (rackverb's QUAD does). Read the size; never assume it. A file that imports it is refused by an older
core.

## Declared pool buffer

For state that must survive FX switching (or a synth's large table). In C, a global in `.data`:

```c
OP1_BIGBUF(my_buf, 64 * 1024, 256 * 1024);   /* op1_bigbuf_t: magic "KNBB", version 1, min, max, ptr 0, size 0 */
```

and `"bigbuf": "my_buf"` in `plugin.json`. The packer sets flag bit 4 and adds extension tag 4 (length 4: the u32
image offset of the descriptor). The loader (`kn_load.c`, `reloc.py`, the same checks) refuses the file when the
flag and the tag disagree, the descriptor is not 4-aligned inside `.data`, magic or version differ, `min > max`,
`max` is 0, `min` is over 512 KiB (`KN_DECL_MAX`), `ptr` or `size` is not 0 in the file, or a relocation points into
the descriptor. At boot each file's request is reserved in load order (`plugins/` before `content/`, each sorted
by name): `max` (clamped to 512 KiB) if the 1 MiB range has room, else what is left (cache-line multiple) if that is
at least `min`; else the file is refused ("plugin buffer memory full", counted in the boot toast) and boot goes on.
A refused file gives its reservation back. After the pool is cleared the core writes `ptr` (32-byte aligned, zeroed)
and `size`; `min` 0 makes the buffer optional (`size` 0 = go without). Read `ptr` in `init` / `render` / feature
callbacks, never at load time. Cores from before the pool refuse the file ("unknown plugin flags": bit 4), so it
can't load without its buffer.

### Declared cost (extension tag 5)

`"cost"` in `plugin.json` gives the plugin's worst audio block in bcore packets: a synth `{"voice": N, "start": N}`
(the slowest six-voice block divided by six, which includes a voice start; a strike's extra per voice), an FX
`{"call": N, "init": N}` (the slowest steady call; the select block with `init`). `harness/plugin_cost.py --write`
measures and writes them (cost_check.py's burst regimes on a bcore emu with `--cycles`). The packer adds extension
tag 5, length 8: two u32. The loader parses them only at exactly that length; any other length, or no tag, is
ignored and never refuses the file. The core does not act on them (no voice cap since 2026-10-28): they are
information for tools. `harness/slot_budget.py` (make check) compares each plugin's declared cost with its slot of
the unit's block (ARCHITECTURE.md "Slot budget, no voice cap").

### Settings table (extension tag 7, cores from 3.3)

`"settings"` in `plugin.json` puts rows on the settings page (clock T3, ARCHITECTURE.md "Settings page"). Each entry
is a row, in order: row n goes on page n / 4 under encoder n % 4 (blue, green, white, red); `null` leaves that encoder
empty. A plugin has at most 8 rows (2 pages, titled the same), plus push targets, which take no row.

```json
"settings_title": "MIDI SEQ",
"settings": [
  { "id": "octlock", "label": "OCT LOCK", "type": "onoff", "default": 0 },
  { "id": "ppq", "label": "PPQ", "type": "choice", "default": 0, "push": "sync",
    "choices": [ {"label": "OFF"}, {"label": "24"}, {"label": "4"} ] },
  { "id": "sync", "label": "SYNC", "type": "onoff", "default": 0 },
  { "id": "level", "label": "LEVEL", "type": "number", "min": 0, "max": 7, "step": 1, "default": 3, "unit": "DB" },
  { "id": "lfo", "label": "LFO", "type": "choice", "key": "scope", "mask": 20, "default": 4,
    "choices": [ {"label": "OFF", "value": 0}, {"label": "KEEP TYPE", "value": 20}, {"label": "NEW TYPE", "value": 4} ] }
]
```

| Field | Rule |
|---|---|
| `id` | `[a-z0-9_]`, 1..15 characters, unique in the plugin. It never changes meaning (like configuration IDs). |
| `label` | 1..12 characters of the stroke font: `A-Z 0-9 space - + / . : # % _ ,`. The packer refuses anything else, lower case too. Label, a space and the longest value (with a space and the push tag) take at most 22 characters, one line. |
| `type` | `onoff`, `choice` or `number`. |
| `choices` | 2..8 `{label, value}`; labels 1..10 characters (same charset); `value` (int32) is what is stored, default the index. |
| `min`, `max`, `step`, `unit` | number only: int32, at most 64 steps from min to max; `unit` 0..3 characters drawn after the value. |
| `default` | the value when no row is saved; must be valid (on / off: 0 or 1). |
| `key` | the storage key, default `id`: the row is `"<plugin>.<key>"` in op1rsettings, as `op1_setting_get` reads it. Existing keys are declared with their current key and default, so they need no migration. |
| `mask` | rows may share a key as bit fields: read `stored & mask`, write `(stored & ~mask) \| value` (an on / off row stores the mask for on). Rows sharing a key must have masks that don't overlap; the key's default is the OR of their defaults. A number takes no mask. |
| `restart` | `true`: the change is saved and applies at the next boot; the page shows "restart to apply". |
| `only` | `"diag"`: the row exists only in the test build (KN_DIAG=1); its value is still kept. |
| `push` | on a choice or number row: the id of an on / off setting of this plugin; the encoder push flips it and its label is drawn after the value (as CLICK's FX). That setting gets no row. |
| `help` | workshop text only (any case, at most 120 characters); not packed. |
| `settings_title` | (plugin level) the page title, 1..14 characters; default the plugin name in capitals with `_` as a space. |

The packer (`reloc.settings_table`) writes extension tag 7: u8 version 1, u8 entries, the title NUL-terminated (empty
= the default); per entry u8 type (0 empty slot, 1 onoff, 2 choice, 3 number), u8 flags (1 restart, 2 diag, 4 push
target), u8 choices, u8 push (index + 1, 0 none), i32 default, min, max, step, u32 mask (little-endian, unaligned),
then id, label, key and unit NUL-terminated, then per choice its label NUL-terminated and its value as i32.
`reloc.settings_decode` reads it back (release.py). The loader records where the tag is and never refuses the file
for it; `kennel/kn_setpage.c` `kn_settings_add` checks it and copies it into a 6 KiB core arena after the plugin
registered. A malformed table drops that plugin's rows (logged); the plugin still loads. Older cores skip the tag.
Compiled-in features get the same table from `pack.py settings-c` (`build/kn_settings_builtin.c`). Tag 6 is
reserved (the randomiser's word layouts, branch `rnd-scope`).

Reading values: `op1_setting_get` as before (the core answers declared keys from RAM), or
`op1_setting_value(plugin, id)` from any thread; `OP1_EV_SETTING` (arg: the entry's index) follows a change on the
main loop (docs/feature-hooks.md "Settings"). A plugin that imports `op1_setting_value` refuses to load on a core
before 3.3 (an unknown import); plugins that must run on 3.2 use `op1_setting_get`.

## Loaded-image map (crash reports)

After a file registers, `kn_boot.c` appends a record to the image map (`synth_sdk/kennel/kn_images.h`): load
address, arena bytes (image + bss), initialized image size, text size (`.op1p`: the whole image), the file's CRC (the
inventory's), file size, format, kind, directory and id. The map takes 16 + 44 bytes per listed file (at most 128)
from the start of the plugin arena, before the first file loads; the core symbol `_kn_images` points at it (0 when
no file was listed or the boot skipped them). A file that fails, is switched off or is shadowed by an earlier
provider gives its memory back and leaves no record. It is read from memory (emulator peek, debugger) and is not
part of the inventory or any wire format; the header's magic `KIMG`, version and record size say how to read it. `tools/kennel/symbolicate.py --map <dump>
[--sym build/synth.sym] [--plugins <dir with pack --keep objects>] PC` names the file, offset, section and symbol.

## Constraints the C loader must keep
- **Call reach.** `PCREL24` reaches +-16 MB. The core's code (the exports) starts at 0x01E00000; plugin code lives
  in the heap-0 arena, 15..30 MB below it, so its core calls go through call stubs (above); the fixed arena
  0x02980000..0x02C00000 is 11.5..14 MB away and needs none (`kn_mem.h` asserts `KN_ARENA_HI <= KN_CALL_CEILING`).
- **libgcc.** Linked into each plugin (a few hundred bytes for the division helpers). Its `.eh_frame` is dropped
  by `merge.ld`.
- **Strings.** `ld -r` does not merge duplicate strings across `.rodata.str*`, a final link does. The file
  carries the `ld -r` layout, so the test compares against a final link of the `ld -r` object.
- **Alignment.** All current plugins have `image_align` 4.

## Packer (`tools/kennel/pack.py`)
1. Compile each `plugin.json` source with `bfin-elf-gcc -O2 -mcpu=bf524 -ffreestanding -fno-builtin -nostdlib
   -fno-common -Wall -Isynth_sdk` (as `make_firmware.py`).
2. `bfin-elf-ld -r -T tools/kennel/merge.ld *.o libgcc.a` -> one object with `.text`, `.rodata`, `.data`,
   `.bss`. Any other allocated section stops the packer.
3. Lay the sections out from 0, apply every relocation, keep the address-dependent ones in the table.
4. Fill the header from `plugin.json` (`name`, `kind`, `order`, `symbol`, `screen`, `defaults`,
   `page2_defaults`, `uses_sample`) and `OP1_PLUGIN_API` from `op1_plugin.h`; append the SVG; write the CRC.

## What the current plugins use (2026-10-15, gcc 13.3)
All ten plugins in `synth_sdk/plugins` pack. ELF relocations seen: `BYTE4_DATA`, `HUIMM16`, `LUIMM16`,
`PCREL24`, and `PCREL24_JUMP_L` (clouds, mixtur, sitting). Core imports: `_op1_eng_page`, `_op1_fx_page`,
`_read_fx_param_safe`, `_sq_text`, `_sq_line`, `_sq_num`, `_sq_cat`, `_sq_node_rotate`,
`_sq_synth_knobs_live`, `_sq_fx_knobs_live`. supersaw and fmbell import nothing.


## Continuous input synth extension (unreleased after 3.0)

`input_engine: true` sets KNPL flag8, valid only for a nonsampler synth. The entry is the 32-byte `op1_input_engine_t` in `op1_input.h`: unchanged16-byte voice prefix, mandatory audio reset/process, optional main-loop service and optional checked T2 screen descriptor. The loader validates the complete extension and all callbacks before registration. Old cores reject unknown flag8. Header API1 and ordinary synth/FX ABI stay unchanged. The packer requires the full entry size; use the SDK matching the new core. The new input callback replaces the64-sample post-decimator bus once/block, before T3. Parameters are a raw saved-word snapshot; voice-based T4 modulation is not applied. Audio input and output must not alias; no allocation, filesystem or unbounded service in audio. `reset(-1, rate)` deactivates; service/Gfx must use epochs/owned buffers, not race reset state. Rate is selected from observed400MHz callback cadence (22050 or44100); confirm physical hardware timing before claiming tuner calibration.

## Own envelope

A synth with `"own_envelope": true` in plugin.json sets header bit 5 and exports an `op1_engine_env_t`
(`op1_plugin.h`): the 16-byte `op1_engine_t` and, at +16, `int finished(void *self)`. The loader refuses the bit on
anything but a non-sampler, non-input synth, and checks that `finished` points into the plugin's text. At boot the
core records `finished` for the file's order. While a voice plays such an engine (built synth play mode, an iter slot),
the ADSR entry (`kn_sound_adsr`, `dispatcher.c` `kn_engine_adsr`) gives it a flat envelope at the stock full-sustain
level for velocity 127 and frees it only when `finished` returns nonzero (asked once a block, before render, as R246's
voice loop runs the envelope first); R246's steal and kill fades (states 6 and 8)
and an idle voice run the stock envelope. Without such a file loaded the ADSR entry takes its stock fast path as before.
Cores before 2026-11-10 refuse the file ("unknown plugin flags": bit 5).

## Voice-sum block

A synth with `"sum_block": true` in plugin.json sets header bit 6 and exports an `op1_engine_sum_t` (`op1_plugin.h`):
the 16-byte `op1_engine_t`, at +16 `finished` (required with `own_envelope`, else 0 or a function) and at +20
`void block(int16_t *bus, int fresh)`. The loader refuses the bit on anything but a non-sampler, non-input synth and
checks that `block` points into the plugin's text. At boot the core records `block` for the file's order. It runs once
an audio block on the synth bus, R246's `mix_bus` after the 2:1 decimator and the 35 Hz high-pass (64 samples at 44.1
kHz, in place), before the synth FX and whether the FX is on or off, while the built synth slot's sound is this
engine (blocks with no voice sounding too); never in drum or game mode. `fresh` is 1 when the block before it did not
call this engine (boot, another sound, drum mode, a muted engine). Its cycles count as the engine's (the synth class,
the audio budget). Cores before 2026-11-11 refuse the file ("unknown plugin flags": bit 6).

## Own T2 page

An own-envelope engine's T2 knobs reach no envelope, so it may replace the ADSR page (screen 22) with its own.
`"t2_page": true` in plugin.json (with `"own_envelope": true`) sets header bit 7 (`KN_FLAG_T2_PAGE`, 0x80), and the entry
is an `op1_engine_ext_t` (`op1_plugin.h`, 28 bytes; its first 24 bytes are `op1_engine_sum_t`, the layout the voice-sum
hook's bit 6, `KN_FLAG_SUM` 0x40, shares):

| offset | size | field |
|---|---|---|
| 0 | 16 | `op1_engine_t` |
| 16 | 4 | `finished` (own envelope) |
| 20 | 4 | `block`: with bit 6 (`sum_block`) too, the sum hook's block callback (checked as in "Voice-sum block"); without it 0 (`kn_validate.c` refuses anything else) |
| 24 | 4 | `const op1_screen_t *t2`: `init`, `update`, as any screen; required |

Minimum entry size with the T2 page: 28 bytes, with or without bit 6. The flags combine: bit 6 alone needs 24 bytes,
bit 7 (with bit 5) 28, both 28 with `block` at +20 and the page at +24.

It is the input engines' design: the same checks (`kn_validate.c` `screen()`: the descriptor 4-aligned inside the image,
both callbacks in the text; here the pointer must not be 0) and the same host (`kennel/kn_input.c`, decisions in
`kennel/kn_t2_page.h`): one screen object (iter class, `usbout.svg`, drawn in code) per order, swapped into screen 22
while a sound with this engine is the current synth slot, the stock object back after. Without the flag an
own-envelope engine keeps the stock T2 page. Packer (`pack.py`), `reloc.py` and `kn_load.c` refuse bit 7 without bit
5 ("t2 page requires own envelope") and an entry shorter than 28 bytes; `plugins.py` refuses `t2_page` without
`own_envelope`. Cores before 2026-11-11 refuse the file ("unknown plugin flags": bit 7), so a file with the page never
loads on a core that would show the dead stock page.

**The parameters.** The page's encoders stay R246's: blue, green, white and red turn the slot's T2 words 0..3
(`adsr_params`, 8 x int16 per slot at 0x01B60EF0; R246's attack, decay, sustain, release) over the stock ranges
(R246's range table at 0x01DE5710, read in the emulator 2026-11-11: words 0, 1 and 3 run 64..16320, word 2 0..32767) and
save them in the sound and its presets (key `adsr`), exactly as on the stock page; `op1_param_set(OP1_PARAM_ENV, k,
v)` and the MIDI CC maps reach the same words. Unlike an input engine's page, kennel takes no event on it
(`kn_t2_takes`). The engine gives the four words its own meaning and reads them with `op1_t2_words(slot)` (inline,
read only): render reads `op1_t2_words(op1_current_slot())`, the page `op1_t2_words(OP1_SCREEN_SLOT)`. The T4 LFO's
envelope target does not reach them (they are read as saved). Shift on T2 still shows R246's play-mode page (screen 40:
play mode, portamento, words 4 and 5). The pushes do nothing there (R246 has no T2 push; latch's red push needs the
stock ADSR object). Choosing the engine keeps the T2 words the slot had (emulator 2026-11-11: the words did not change
when the test engine was picked); an engine that needs set values has to say so in its presets.

**Swallowing the encoders (`"t2_swallow": true`).** An engine that ignores the four words (it uses the page only to show
something) would otherwise have blue, green, white and red change hidden values and mark the sound edited. With
`"t2_swallow": true` (needs `"t2_page": true`) the page takes every knob turn and the four pushes (0x3B..0x3E) away from
R246, with the same event rule as an input engine's page (`kn_t2_takes`): no T2 word changes and no edit mark. Everything
else passes: Shift still shows R246's play-mode page (screen 40, where the encoders are R246's again), other pages and
keys are unaffected. The declaration is header bit 8 (`KN_FLAG_T2_SWALLOW`, 0x100); the entry stays the 28-byte
`op1_engine_ext_t`, so there is no new entry word (a word at +28 would still need a header bit, or an older core would accept
the file and not swallow). Packer, `reloc.py` and `kn_load.c` refuse bit 8 without bit 7 ("t2 swallow requires t2 page"),
and `pack.py` / `plugins.py` refuse `t2_swallow` that is not a boolean or without `t2_page`. Cores before this change refuse
the file ("unknown plugin flags": bit 8), so the page never loads on a core where the knobs would still turn the words.
Only the encoders are swallowed: MIDI CC maps and `op1_param_set(OP1_PARAM_ENV, k, v)` still change the words (and mark
the sound), so such an engine must not depend on them.
