# DRIFT piano variant: plan

A piano engine built on DRIFT's engine (`synth_sdk/plugins/drift`), on branch `drift-piano`. DRIFT itself is not
changed by this work. Name and engine id (owner 2026-11-14): LUDWIG, `ludwig`, the plugin `synth_sdk/plugins/ludwig` (step A: the engine, 2026-11-14; README.md there).

## Steps

1. **Train the unchanged engine on piano samples** (host only, in progress). Salamander Grand Piano V3, 16-bit
   44.1 kHz set (Alexander Holm, CC-BY 3.0: credit it if anything derived ships). Output: demos against the
   samples, spectrograms, the measured gaps (bass above the 64th harmonic, stretched partials, attack). Report:
   OP1-Emulator `run/drift-piano-2026-11-14/REPORT.md`.
2. **Engine changes** (this branch). Owner 2026-11-14: these two are in the plan; the rest of the list is ranked
   by step 1's measured gaps.
   - **Keyframe tables from a note-rate net in SDRAM.** A net much larger than the 8 KB L1 lease lives in SDRAM
     and runs at note-on, sliced over blocks like DRIFT's envelope head (and deferred under load the same way). It
     writes about 16-32 waveforms for the note's future (age, pitch, velocity, knobs) into the voice's SDRAM; each
     block crossfades two of them (~1k cycles a voice against the table net and blend's ~3-4k). The small L1 net
     plays the first blocks until the keyframes are ready, so the onset is never late. Knob and LFO changes re-run
     the big net: timbre follows in tens of ms rather than one block (fine for a piano, not DRIFT's LFO feel).
     Open: whether the handover from the small net to the keyframes is audible (step 1's onset quality tells how
     good the small net alone is).
   - **Long waveforms played from SDRAM** (256-512 samples): 128-256 harmonics, so low notes get their top end
     (128 samples cap a note at 64 harmonics: ~1.76 kHz at A0, ~4.2 kHz at C2). The oscillator already reads its
     table from SDRAM, and a low note moves slowly through it (few cache lines a block), so long tables cost
     least where they are needed. They are written by the keyframe net, not blended every block.
   - Then, ranked by step 1's measured gaps (REPORT.md): retrain the L1 net with a log-spectral loss (table error
     5.7 -> 3.2 dB in float, no engine change); a learned hammer and body bed (the treble's 8-15 dB gap is a
     non-harmonic bed below f0); per-key decay and tuning (one ADSR decay misses by 4-31 dB, stretch -16..+23
     cents); stretched bass partials A0..D#1 (an allpass inside the comb's feedback loop, or a small exact partial
     bank: an allpass after the oscillator cannot move partials); dropping FM, comb and sync saves code size only.
   - Step 1 measured: 256-sample tables close the bass cap (4-9 dB at forte, A0..A1) to about 1 dB; 512 adds
     nothing; from C2 up the cap costs nothing. Keyframe targets need short-window onset data to judge the handover.
   - Bass analysis A0..C4 (2026-11-14, host only, source-only audio; OP1-Emulator
     `run/drift-piano-2026-11-14/bass/`, numbers in `bass.json` and `summary.txt`). Rung 3 against the left mic:
     - Pitch is the largest error from A0 to B2. Rung 3 plays equal temperament; the sample sits 19 c flat at A0..C1,
       9 c at D#1..B1 and 7 c at C2..B2, and varies key to key (A1 -5, C2 -10, D#2 -8 c), so a smooth stretch curve
       is still 3-4 c off. Fix: a per-key tuning table from partials 1-12 (free).
     - Inharmonicity at A0..C1: 13-25 % of the energy is more than 20 c off any harmonic series (partial 16 +60 c,
       partial 30 about +150 c). Exact slots at the measured frequencies close it and the 3.2 dB crest-factor gap.
     - A sustained non-partial component at A0..C1 (phantom partials, e.g. A0's 1796 Hz = f29 + f31), -17 to -33 dB,
       growing faster than the partials with velocity. A quadratic term on the inharmonic partials closes about half.
     - A knock residual lasting about 300 ms from D#1 up (-27 to -42 dB); rung 3 has none after 50 ms. A longer
       sample splice only masks it; keep the 50 ms splice and add a knock layer.
     - Interpolation-image haze above harmonic 64: +9 dB at D#1..B1, +19 dB at C2..B2. A 256-sample table removes it.
     - The detuned copies make every metric worse (the sample's beating is 0.15-0.45 Hz on most partials, not string
       detune). The owner heard rung 2's beating as an improvement: A/B segment c0 settles it by ear.
     - Training on one mic (or a power average) instead of the L/R magnitude average: envelope distance 0.7-0.8 dB
       without copies. Per-partial two-component decay fits are worse than the tables' own trajectories.
     - Recommended engine: per-key tuning; a spectral table source (per-partial magnitudes, one inverse FFT a block,
       phase-rotating inharmonic slots below about C3, 256 points at A0..B1, est. 1.6-5k cycles a voice); one-mic
       training without copies; a phantom term (A0..C1) and a short knock layer. Estimates, not measured on Blackfin.
     - Owner by ear (2026-11-14): all_engine (a + b + c0 + L + f + p) is clearly best; the stored 1 s residual (all)
       is a bit better still but too large. So: no detuned copies.
     - Knock layer: measured (`run/drift-piano-2026-11-14/knock/`; a stored residual of 27 KB for 88 keys kept most
       of the gain by the metrics) but dropped by ear (owner 2026-11-14: "no knock sounds good enough"). The engine is
       all_engine as it is, phantom term included.
     - C prototype (`run/drift-piano-2026-11-14/proto/`, fixed point, Blackfin output bit-identical to the host):
       matches the float within ~0.1 dB on the sample metrics. Cost per voice per block on bcore (cold model, tables
       and scratch in L1): A0 36k without the phantom term, 64k with it (the phantom alone ~28k); C4 25k / 51k. Six
       voices without phantom ~140k (24 %), with it ~290k (49 %): the phantom term as built does not fit the 35 % slot.
       Velocity: blending the two nearest layers' magnitudes before the one IFFT works (C2 between layers 10 and 16:
       body/decay 1.6/1.4 dB vs 2.4/2.6 for the nearest layer); 6 of 16 layers keep the error near one layer step.
       Keys between Salamander's sampled keys (every 3 semitones) do not blend: 5-13 dB off, no better than the
       nearest key; unsampled keys need a learned source (the keyframe net) or more samples. L1 use (7.6 KB) leaves
       no room for DRIFT's table net, so the spectral source replaces it.
     - Phantom term dropped by ear (owner 2026-11-14, `proto/phantom/phantom-ab.wav`; by the metrics it closed about
       half the residual gap at A0..C1, under 1 dB at C3). The engine: per-key tuning, spectral table with inharmonic
       slots (256 points below C4), left-mic data without copies, velocity-layer blend. About 25-36k cycles a voice.
       Open: unsampled keys (the keyframe net), and the asm/spreading work for the blend path.
     - Unsampled keys (`run/drift-piano-2026-11-14/keynet/`): a 1,679-parameter model (per partial: log f0, velocity,
       partial number and frequency -> 6 time basis weights) beats the nearest key and the two-key blend on held-out
       keys A0..B5 (env 5.3-7.1 dB vs blend 5.9-8.5) and ties the blend above C6. But 30 keys can't teach each key's own
       partial pattern: held-out error stays ~6-7 dB, about the gap between Salamander's two mics on one note.
       Velocity stays the layer blend (the model is 5.7 dB vs the blend's 1.6). Tuning/partials for unsampled keys:
       interpolate the neighbours' partial ratios (1-6 c). Deploy offline (bake 88 keys x 6 layers, ~1 MB, or ~550 KB
       storing the model's basis weights); a runtime net costs ~23k cycles a block for 22-54 ms a note and buys little.
       More data would help: a piano sampled on every key (University of Iowa MIS, "without restrictions"; not
       downloaded).
     - Decided by ear instead (owner 2026-11-14, `keynet/listen/chromatic5..7-*`): **spectral resampling**, no model.
       A played key uses the nearest sampled key's (zone +-1 semitone) partial levels n -> n and partial ratios, scaled
       to the played key's f0 (tuning interpolated between sampled keys), its keyframes read at r = f0 / f0_donor and
       its attack splice resampled by r, as a sampler resamples. "Very close" to the resampled samples. Plus a **zone
       gain**: each sampled key's level pulled onto a straight dB line across keys (Salamander's F#2 is ~2.3 dB loud,
       A2 ~2 dB quiet). Neighbour smoothing of partials and attack EQ was tried and dropped by ear. Known: Salamander's
       F#2 attack swells (peak +66 ms vs 11-16 ms for D#2/A2) and is darker at 1.6-3.2 kHz, in every layer and both
       mics: the recording, not our handling.
3. **Compare with LUDWIG** on the same notes: spectrograms, then by ear on the unit.

## Prior art: PianoForte (MIT)

github.com/tesserato/PianoForte (Carlos Tarjano, MIT; read 2026-11-14). A piano from a ~1,500-parameter net,
about the size of DRIFT's table net, trained on Iowa MIS piano, bitKlavier Grand (CC BY 4.0) and Salamander.
- The net maps pitch, velocity and time (counted in pitch periods, squashed with tanh) to the amplitudes of N exact
  harmonics; additive synthesis with random start phases per note. Inference runs asynchronously; amplitudes are
  smoothed per sample.
- Inharmonicity is not learned: a fixed bank of 13 inharmonic partials (hand-set ratios and levels, three key
  zones) with an exponential decay is mixed in, mostly in the bass.
- Ideas to test here: harmonic-amplitude targets or a harmonic-sine basis instead of 16 learned waves; time in
  pitch periods; a small fixed inharmonic partial bank in the bass as a cheaper alternative to the allpass chain.
  Ideas only so far: no code taken (if any is, record it in PROVENANCE.md with the MIT notice).

## Limits to keep

- Synth slot 35 % (unit model: cold cycles x 0.98 / 580,525) with a layout sweep; DRIFT is at about 33 %.
- SDRAM from the 5 MiB arena shared by all plugins: keep per-voice keyframe storage modest (32 x 512 x 2 B =
  32 KB a voice is the upper end).
- Audio path: integers only, no per-sample division, no libc. The GUI thread's spare time may refine, never
  carry a note.
