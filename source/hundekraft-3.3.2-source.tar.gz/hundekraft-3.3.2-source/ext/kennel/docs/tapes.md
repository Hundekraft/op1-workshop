# Four tapes

<!-- Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). -->

Status (2026-10-15, branch feat-tapes): design, core switch service (`kennel/kn_tapes.c`) and the tapes feature
(`plugins/tapes`). Behaviour follows Maiko's #250 guide (maikopruett.com/op-1/guide/tapes); no Maiko code. The
#250 firmware was diffed against R246 for leads only; every address below was checked in R246.

## Behaviour
- Hold tape and press T1..T4: switch to that tape. A popup over the reels shows the tape and its tempo ("TAPE 2" /
  "125 BPM"): the tape popup undo and redo use too (`synth_sdk/screens/tape_popup.h`), drawn with kennel's own lines
  and stroke font from a tape draw hook. Tape + the current tape's number only shows the popup. Refusals ("stop
  recording first", "a new tape needs 64 mb free", ...) stay toasts. T1..T4 alone select tracks as before.
- Each tape has its own four tracks, clips, loop, position, track, tempo and album (side a / b).
- Tape 1 is TE's tape (stock paths). Tapes 2..4 are made on first use: empty, at the tempo of that moment, and they
  take flash only for what is recorded (the image is sparse).
- A switch stops playback first. It is refused while recording (tape or album), in disk mode, while R246's
  clipboard queue has work, and for a new tape with less than 64 MB free. Each tape keeps its own undo
  history (the undo feature listens to `OP1_EV_TAPE_SWITCH`); only an undo job cut short by a switch drops that tape's
  history.
- Disk mode shows the current tape only (the disk layer is bound to the current image). Writes from the host skip
  zeros that are already zeros, and a write the flash can't take returns an error instead of R246's crash (a medium
  error after the host's reset recovery; "Disk mode writes" below).
- On tapes 2..4, REC shows "flash full" and does not record when less than 32 MB is free (ours: one full-length
  track take is 31.8 MB; their images are sparse, so a take that runs out of flash would be lost). Tape 1 is left
  stock: R246 fills its six files with silence when it makes the tape (242.5 MiB), so a take there only overwrites
  flash it already has. Until 2026-10-21 the rule applied to tape 1 too and refused REC on an empty tape 1 once
  anything else (undo history, tapes 2..4, files written into the image's free clusters in disk mode) had taken the
  flash under 32 MB.
- A take on tapes 2..4 that runs the flash down anyway (undo history, a take started just over 32 MB, any other
  writer) stops when less than 8 MB is free, from any screen: the tapes feature's main-loop `service` hook (free space
  read every 16th pass while recording) moves
  recording states 4 / 7 / 8 to 1 (what STOP does) and 5 (REC held while playing) to 10 (a punch-out), calls
  set_mode, and toasts "flash full, rec stopped". R246 makes the clip from what was recorded; 8 MB leaves room for the
  cache flush, the clip row and tape.db. (Maiko #251 lists the same fix: a take stops with FULL instead of being lost.)
  Album recording is not covered. Fake-core test only (`tapes_feature_test.c`); not run in the emulator or on the OP-1.
- Boot always opens tape 1 (decision: no path hook in the boot sequence, so stock's start-up and its marker
  recovery only ever see tape 1); the last tape comes back with one switch after boot ("Boot into the last tape"). No delete yet.
- Stock firmware sees tape 1 only; the other tapes sit in their own folders it never opens.

## Files
| Tape | Image | Database | Marker |
|---|---|---|---|
| 1 | `/yaffs2/user/tape_c.raw` | `/yaffs2/user/tape.db` | `/yaffs2/user/marker.txt` |
| 2..4 | `/yaffs2/user/tape<N>/tape_c.raw` | `/yaffs2/user/tape<N>/tape.db` | `/yaffs2/user/tape<N>/marker.txt` |

`/yaffs2/user/tape<N>/ready` is written last when a tape is made; a folder without it is incomplete and is made
again (never with R246's marker, see below). Each tape.db gets one extra table, `kn_tape (id INTEGER PRIMARY KEY,
bpm10 INTEGER)` (tempo x 10), which stock ignores.

## R246 facts the switch relies on (checked in the R246 export, OP1-Emulator run/r246-map/export/OP1_vdk)
- **Paths are RAM strings**: `tape_image_open_at_boot` (0x019971B0, once, guard 0xFF906EF8) builds the image path
  into 0x01AABCE4 and the marker path into 0x01AAC934 (0x200 each, snprintf 0x01A4CCD8). Every later user reads
  the buffers (recreate 0x01996E04, marker inc / dec / dirty 0x01997FA0 / 0x0199812C / 0x019987F8 open the marker
  by path each time). #250 replaces the image path snprintf at 0x0199725E (lead only; we don't patch it).
- **Image descriptor**: 0x018C180C, the tape cache's copy via `tape_set_file_handle` 0x01A5404C. FAT disk layer:
  `fat_disk_bind_tape_image` 0x019761D8(fd), FatFs volume 0x01AABEE4 (`f_mount(volume 0, fs)` 0x01998E74, R0 the volume, R1
  the object; fs 0 unmounts). `tape_image_mount_and_index` 0x01996F38 checks the six files (recreates the whole image if one is
  missing: zero fill, about 257 MB; recreates a bad track file and flags it in 0xFF906EFC..FF), defragments when
  fragmented (bracketed by the marker), then stores the data offsets (0x018C1810 tracks, 0xFF9002C0 / C4 album).
- **tape.db**: `db_open_all` (0x0196F6B4) opens `/yaffs2/user/tape.db` into a 4-byte box whose address is kept at
  0x01BAB72C (`FUN_0196dd50` returns it; every db2 call takes the box and dereferences it under the statement lock
  0x01BAB718). Close = sqlite 0x019D6134(sqlite*), open = 0x019D73C8(path, box, 2, 0) (sqlite3_open_v2: the fourth argument, the VFS name, goes on the stack; R246 passes 0). Holding the lock while swapping
  the sqlite pointer inside the same box keeps every holder of the box valid.
- **Background SQL**: clip statements go through the BgFile worker (enqueue 0x019410C8, ring head 0x01BA33E4, tail
  0x01BA33E8, job in progress 0x01BA29D8); after an empty queue the worker saves dirty objects
  (`bg_flush_dirty_objects` 0x0193EF64, the tape row through `tape_db_save`). Idle = head == tail and no job.
- **Clip pool**: 0x01AA8D70 (512 x 12 bytes), has_clip 0x01AAA570, free count 0x01AAA770, load guard 0x01AA7368,
  `tape_clips_load_from_db` 0x0195CE88(pool) (SELECTs through the box).
- **Tape row**: `tape_db_save` 0x01A569BC (no arguments: loop 0xFF8029C5, loop in / out, track 0xFF802964,
  position). Restore as the controller's first use does: loop on 0xFF8029C5 and loop effective 0xFF8029C6,
  `tape_set_loop_in` 0x01A550A8, `tape_set_loop_out` 0x01A55100, track 0xFF802964, `tape_locate` 0x01A55024.
- **Tempo**: the tempo controller 0x01B60D90 (built once, guard 0x01B60D8C) keeps knob objects; `tempobpmdecimal`
  at 0x01B60E18 holds bpm x 10 (value +0x10 = v x scale +0xC), `tempobpm` at 0x01B60D98. The tempo screen sets
  both with `ctl_knob_set` 0x019696E8 and calls `tempo_set_bpm` 0x01A5E9A4 (float bpm, 40..220).
- **Cache**: after a flush every node is clean; `tape_cache_invalidate_clean` 0x01A54078 drops them all and the
  loop seams.
- **Guards**: tape state 0x018C17D4 (4 / 5 recording), album state 0xFF9002B4 (6 / 7 recording), disk mode
  0xFF906EF9, clipboard queue 0x01AA7330 / 0x01AA7334.

## Making a tape (ours, sparse)
R246's own build writes silence through every file (about 257 MB of flash). Ours writes only the metadata and lets
YAFFS keep the audio as holes, which read back as zeros:
1. mkdir `/yaffs2/user/tape<N>`; open `tape_c.raw` (create, truncate), `tape_image_presize` (0x01A99FB4: 0x18000000
   bytes, no data written).
2. Write the FAT16 metadata as R246 lays it out (OP1-Emulator `docs/firmware/tape.md`): boot sector, both FATs
   (contiguous chains, entries 0 and 1 zero as R246 leaves them), root directory (TAPE, ALBUM), the TAPE and ALBUM
   directory clusters, and the six AIFC headers (tracks mono 0xF28000 frames, album sides stereo 0xF23FA0).
   Generated by `kn_tape_image_meta` and checked byte for byte against an installed R246 image
   (`harness/tapes_image_test.c` + OP1-Emulator `run/kennel-tapes/meta_check.py`).
3. Copy `/yaffs2/content/tape.db` (the factory copy) to `tape<N>/tape.db`, write `marker.txt` "0", then `ready`.
About 600 KB of flash. The 64 MB rule leaves room for recording on it.

## Switch (main loop, `kn_tapes_service` from `ci_service`)
Requested from the key hook (KeyHandler); runs on the main loop, which owns the tape file and the cache:
1. Refuse: recording, album recording, disk mode, clipboard queue busy, target new and less than 64 MB free.
2. Playing: press STOP (KeyHandler::dispatch_key 0x23) and retry on the next passes until stopped.
3. `tape_db_save()`; write the tempo into the current tape.db (`kn_tape`; not while boot's tempo is still R246's, see
   "Tempo per tape"); wait until the BgFile worker is idle;
   `op1_tape_flush()`.
4. `OP1_EV_TAPE_SWITCH` before (arg = old | new << 8 | 1 << 16).
5. `tape_cache_invalidate_clean()`; unmount (0x01998E74(0)); close the image; descriptor -1.
6. Make the tape if needed.
7. Both path buffers to the new tape; open, descriptor, `tape_set_file_handle`, bind, mount,
   `tape_image_mount_and_index`.
8. Statement lock: close tape.db, open the new one into the same box, unlock.
9. Clip pool: has_clip 0, free 512, guard 0, `tape_clips_load_from_db`; recreated-track flags as at boot.
10. Tape row via `db2_get`; loop, loop points, track, locate. Tempo from `kn_tape` (a new tape, or one without a row,
    stores the current).
11. `OP1_EV_TAPE_SWITCH` after (arg without the before bit); the popup.

### Tempo per tape (2026-11-24)
R246 keeps one tempo: the `tempobpm` / `tempobpmdecimal` knobs in op1.db (`ctl_knob_set` 0x019696E8 marks the knob
for the BgFile save; the tempo controller reads it back when it is built at boot). Each tape's own tempo is its
`kn_tape` row, kept by `kn_tapes.c`:
- Saved when it changes: `bpm_watch` (every main loop pass) stores a tempo that stayed 1.5 s (cycle counter), once the
  tape is stopped (or REC held) and nothing records, no disk mode, clip queue or BgFile work and no switch is asked;
  boot's apply of tape 1's row waits for the same. Also before every switch, and at power-off
  (`kn_tapes_shutdown`, called from `kn_bgs_stop` before BgFileWorker stops).
- At boot the live tempo is R246's last one, from any tape. `kn_tapes_boot_done` marks it as not tape 1's
  (`bpm_unset`) when a tape 2..4 exists: no save from it (not on the restore switch, not from `bpm_watch`) until tape 1's
  row is applied (no restore armed or the restore gave up, after the restore's settle passes) or the restore switch
  loads its tape's row.
- With only TE's tape (no tape 2..4 made) nothing writes or applies a tempo: stock.
Users on 3.3.1 (before this): a tempo set on tape 4 and a power-off left tape 4's row at its old tempo ("Tape 4 loaded,
125 BPM" after working at 90), and the restore switch saved R246's boot tempo (90) into tape 1's row; working on tape 1,
a boot kept R246's tempo instead of tape 1's. Host test: `harness/tapes_test.c` (both scenarios, the shutdown save, no
save while recording).

Marker safety: R246's marker forces a rebuild of whatever 0x01AABCE4 names at boot, and at boot that is tape 1.
Both buffers point at the current tape before any stock call that can raise the marker (mount check and
defragmenter), so a power cut during tape 2's defragmentation leaves tape 2's marker raised, never tape 1's. The
switch checks the target's marker first: raised = R246 rebuilds that tape in its mount check (its own recovery).

## Disk mode writes (2026-11-17, branch `tape-restore`, for 3.3)
R246's `usb_ms_write_sectors` (0x01A715DC; R0 buffer, R1 sector, R2 count, 0 = ok) seeks to sector x 512 in the
bound image (descriptor 0x018C180C) and writes; a short write is an assert (`usb_ms_yaffs.cpp:55`, the crash screen).
A backup written back through disk mode covers every sector of the six files, mostly zeros, and YAFFS gives each
written chunk new flash, so restoring a full backup onto tape 2..4 ran the flash out at about 171 MB and crashed
(OP1-Emulator `run/tape2-restore-2026-11-17/`). Tape 1 is filled when R246 makes it, so there a write only overwrites.

Kennel jumps from the function's entry (`.hook_mswrite`, LINK 0) to `kn_ms_write` (`kennel/kn_tapes.c`), same
arguments and result, R246's sector counter 0x018C1F34 kept:
- A 512-byte sector of zeros whose image sector already reads zero is not written (a hole reads zero and costs no
  flash). The buffer is checked first (bytewise); only zero sectors are read back, up to 8 at a time into a 4 KB
  `.farbss` buffer (the USB thread's stack is small). Every other sector is written, consecutive ones in one write.
  So a restore costs flash only for the real audio and tapes 2..4 stay sparse; for any tape, skipping a write whose
  data equals what is there changes nothing.
- A write that fails (seek, short write) returns non-zero instead of asserting. On tapes 2..4 a write is also refused
  while less than 8 MB is free (the take rule's margin; free space read again after each MB written, and whenever
  the estimate nears the margin). Tape 1 has no margin, as stock.
- R246's SCSI WRITE(10) handler (0x01A6F404, `usb_msc_scsi_handler` 0x01A6F06C) turns a non-zero result into sense
  key 3 (medium error) and a failed command. In the emulator (round 2, `full32/`: noise written in 8 KB WRITE(10)s
  until the flash ran under 8 MB, 168 MiB in) the failed command never completed on the bulk pipe (the host timed out,
  also on a new USB/IP connection); after a BOT reset recovery (mass storage reset, clear both halts) REQUEST SENSE
  answered sense key 3 (ASC 0x20, as R246 sets it) and a READ worked. A Mac or PC does that recovery itself after a
  timeout; what Finder then shows is not checked.

R246's own writes into the image go the same way on tapes 2..4 (round 2): FatFs `disk_write` (0x01976288, drive 0,
`.hook_diskwr` -> `kn_disk_write`: the mount check's `aifc_create_zero_file`, the boot sync's track copies, the FAT
window) and the defragmenter's cluster write (0x01974C58, `.hook_defragwr` -> `kn_defrag_write`) skip zero sectors
over zeros, with no free space margin (some callers panic on an error). On tape 1 both are R246's code path exactly.
The rule follows the tape whose image is bound (`img_tape`, set where an image is opened and bound, before the
mount check), not the current tape: a switch's mount check on tape N re-creates sparse, while `op1_tape_current()`
changes only after the mount check, as on 3.3. (Round 2's 12641d07 moved `cur` itself ahead of the mount check; a
plain switch hung once after it, round 3 did not reproduce that, see below, and went back to 3.3's order.)

### The sync after a delete-and-copy restore
A host that deletes the files and copies new ones changes directory entries, so leaving disk mode restarts the
OP-1 and the next boot runs `fat_sync_after_reboot` (0x01996530, called at 0x019F034E) against `presync_files` in
op1.db, filled when disk mode began. Boot mounts tape 1, so after disk mode on tape 2..4 R246 compared tape 1's files
with tape N's list (round 1: tape 1's clips dropped, tape N's files not imported). Now:
- `/yaffs2/user/kn_tape` names the tape in use while it is 2..4 (written by a switch, removed on a switch to tape 1).
  A switch is refused in disk mode and the restart after it is immediate, so at boot it names the tape disk mode was
  on.
- Boot (`.hook_btsync` -> `kn_boot_fat_sync`): no note, R246's sync as stock. A note and `was_mounted` set
  (0x01995764): the sync runs right there on tape N. That is where stock runs its own (`op_main_startup_and_service`:
  db open, clips loaded, `tape_image_open_at_boot` (tape 1 opened, bound, mounted), the sync, then
  `tape_image_mount_and_index`): tape N's tape.db in the box, tape 1's image closed, tape N's bound and mounted (no
  mount check), its clips loaded, R246's sync, the BgFile queue drained (clip rows into tape N's db; the worker is a
  VDK thread from start-up and `delay_ms` sleeps through VDK), tape 1's db and image bound again as boot left them and
  its clips reloaded. Boot then runs tape 1's mount check as stock. The hook returns the sync's result, so R246 shows
  its log on the boot console, "Press any key to continue.", waits for a key and clears both frame buffers, exactly
  as after a sync on tape 1. The note goes only after that, so a power cut retries. A note for a tape that isn't
  there (or with a raised marker) clears `was_mounted` and goes.
- Round 2 ran the sync from the first main loop pass instead: the log stayed on the screen, because the
  "press any key" wait and the frame buffer clear belong to start-up and only run when the boot call returns a
  message.
- One round 2 run (`delcopy4`, 12641d07) hung in the mount check of a plain switch to a new tape 2 after a tape 1
  take (emulator watchdog, guest 37.85 s). Round 3 ran the same steps on the same firmware four times without a hang
  (`sw4`, `sw4b` with delcopy4's breaks, `sw4c`, and `swxb` with `cur` moved back), and with breaks on
  `kn_disk_write` / `kn_defrag_write` (`sw4c`) neither was called in boot's or any switch's mount check, so the early
  `cur` had no consumer there. Cause unknown; not reproduced.
- Not done: the undo feature gets no switch events for this visit. (Synth / drum patches the host changed are
  imported at stock's point again, now that the sync runs in the boot call.)

Emulator (OP1-Emulator `run/tape-restore-2026-11-17/`, fw2 and later): with tape 2 bound the sync listed tape 2's
files and tape 1 kept its take's clip (`delcopy2`: tape.db clips `[(0, 1)]`; round 1: 0). A backup with a take
restored by delete-and-copy onto a new tape 2 (`fresh4`, lower-case names): "Changed: /tape/track_1.aif, Found 1
regions", tape 2's tape.db then holds the clip, its six files equal the backup byte for byte and its image takes
13.1 MiB of flash (R246's own tape 1: 256.7).

Round 3 (sync in the boot hook, `img_tape`; `p6*`, `p7*`, `p8a`): after a restore the OP-1 shows R246's sync log and
"Press any key to continue.", one key gives the normal tape screen. (a) tape 1 take, tape 2 take, backup, a second
take added on tape 2, delete-and-copy restore: tape 1 keeps its clip, tape 2 imports one region and its six files equal
the backup after its first mount check (one clip: the backup's take only). (b) the backup onto a new tape 2: the
same, and the clip shows on track 1 while it plays. (d) the same on tape 1: R246's own sync, clip and files kept.
Plain switches (`p6c1..3`) as 3.3. Audio (`p8a`, drum kit takes: the fixture's synth slots are
silent): after the restore tape 1 plays its take (peak 0.072, main frequency 449.5 Hz; the take 0.087, 448.8 Hz) and
tape 2 the restored take (0.104, 753.0 Hz; the take 0.130, 751.6 Hz). Each disk mode visit adds about 13 MiB to the bound image (tape 2: 13.1 MiB after
one visit, 26.6 after two; tape 1 256.7 -> 270.5), so it is R246's own disk mode entry and leave, not kennel; on a
sparse tape that flash stays used. A Mac's msdos driver writes the same entry as the OP-1 (8.3 name, NT lowercase
flags 0x18): Mac copies keep the names; its AppleDouble `._` files next to each copy are not tested.

### File names: R246 deletes upper-case copies
R246's sync tracks files by path, case-sensitively. Its own entries carry the NT lowercase flags, so a host shows
`track_1.aif`. A copy written back as `TRACK_1.AIF` (round 1's test copied the bare 8.3 names with mtools) is
"removed `/tape/track_1.aif`" plus "new `/tape/TRACK_1.AIF`"; the new-file pass then removes the stray files from
TAPE and ALBUM (`tape_dir_remove_stray_files`: every copied file), and the next mount check would re-create the six
files with silence (`aifc_create_zero_file`; not seen hit in round 2). Likely round 1's 190 MB on tape 2 (there the
sync ran on tape 1, so the mount check's own stray-file pass on the switch deleted them; the non-sparse re-creation was
cut by the test's end, hence the marker; inferred). Stock R246 does the same on tape 1. A Mac or PC copying the files
as they show them (lower case, a long name entry) should keep the names (assumed; Finder not tested); the break log in `delcopy2/` and `fresh/` (`brk.py`) shows the
upper-case case. The watchdog line in round 1's log was R246's own restart after disk mode.

An in-place restore (the host overwrites the files' own clusters, directory entries unchanged) needs no sync; on
tape 2 it completed without a crash and the image stayed sparse (the test wrote back the bytes already there, so it
does not prove changed data lands; the host test does).

## Boot into the last tape
Owner decision (2026-11-17): the OP-1 always boots back into the tape last used, no setting. Boot itself is unchanged
(tape 1; stock's start-up, recovery and the `kn_tape` marker never see another tape); the tape comes back by the normal
switch, a few seconds after the tape screen shows tape 1.
- Memory: setting `tapes.last` (op1rsettings, 1..4 = tape number, 0 = none). `do_switch` writes it after every
  successful switch (a switch to tape 1 writes 1), on the main loop, never the audio thread, and only when it changed.
  Separate from `/yaffs2/user/kn_tape`, which stays a disk mode restart marker.
- Restore: `kn_core_service` calls `kn_tapes_boot_done` right after `OP1_EV_BOOT_DONE`; it arms a one-shot step at the top
  of `kn_tapes_service`. After 30 passes (RS_SETTLE) it waits for a quiet machine (no recording / album / disk mode / clip
  queue, tape stopped, BgFile idle), then calls `op1_tape_switch` for tapes.last (2..4): same code, popup and
  `OP1_EV_TAPE_SWITCH` as a key press. 3000 passes (RS_GIVEUP) without a quiet moment: left, key kept.
- Failure: the tape's `ready` file missing or its marker raised (a switch would make the tape again), flash full, or
  the switch not done: stay on tape 1 and clear the key. A user's own switch before the restore fires cancels it. A
  switch refused only for a busy moment (clip queue) is tried again.
- Order with the disk mode sync: the boot sync (`kn_boot_fat_sync`, in the boot hook before the UI) runs first, on the
  tape disk mode was on, and ends with tape 1 bound and the marker removed. The restore comes later from the main loop
  and, since that tape is also `tapes.last`, switches back to it (writing the marker again, as any switch to 2..4). If the
  sync was left for the next boot (`SYNC_WAITING()` still set) there is no restore that boot. The restore never touches
  the boot hook, the path buffers or the marker logic; it is only an ordinary switch.
- Tests: `harness/tapes_test.c` (restore, waits, busy, missing tape, user switch, sync-then-restore). Not run in the
  emulator or on the unit: the pass counts are assumed, not timed.

## Not built / open
- Deleting a tape.
- FILE view: the storage walk counts `user/tape<N>/` under tape (`kn_storage.c`).

## Recording on the grid (quantized punch, 2026-11-17)
The punch plugin's QUANT PUNCH (settings page PUNCH) works on whichever tape is current: the grid is tape positions
from 0:00 at that tape's tempo, so a switch to a tape with another tempo moves the grid with it. A tape switch is
refused while recording, so a take never spans two tapes. ARCHITECTURE.md "Quantized punch".
