# Inventory over SysEx

The workshop web app reads what a kennel OP-1 has installed and what its last boot decided, and writes the list of
switched-off plugins. It uses the SysEx update protocol (`synth_sdk/devupd/`, OP1-Emulator `docs/sysex-update.md`)
with three more commands. This is the device side of PLAN phase 7: the page resolves conflicts against the real
install, not only against the files it is about to send.

## Messages

Same framing as the update: `F0 00 20 76 7D cmd seq_lo seq_hi <7-bit packed payload> F7`, reply `cmd | 0x40`, same
seq, payload `status, ...`. Every message both ways is at most 96 bytes (the OP-1's USB-MIDI input stops on longer
SysEx), and the host keeps one message in flight.

| cmd | Request | Reply (after the status byte) |
|---|---|---|
| 1 HELLO | | u32 protocol version (1), **u8 capabilities**: bit 0 = inventory, bit 1 = plugin files, bit 2 = core patches, bit 3 = content patches (below), bit 4 = presets (below), bit 5 = live presets, bit 6 = DX voice banks (below). Stock 2.x devupd builds send no byte 4. |
| 7 LIST | u32 offset | u32 total length, up to 64 bytes of the inventory text from offset. Offset past the end: status 5 (offset). |
| 8 OFF_GET | u8 which (0 stored, 1 in effect since boot), u16 offset | u32 total length, up to 64 bytes of the list |
| 9 OFF_SET | u16 offset, u16 total, up to 64 bytes | u16 bytes received. Complete -> stored, then OK. |
| 10 DELETE | path, NUL | staged: the plugin file is removed at the restart (see Plugin files); a `presets/...aif` path: that preset is removed (see Presets); a `user/dx/<name>.syx` path: that bank is removed at the restart (see DX voice banks) |
| 11 RESTART | | 9 (wait key) until T1 on the prompt, then OK and the restart; 2 (state) after T2 |
| 12 STAT | u32 offset, u32 length (at most 256 KB), u32 CRC so far, path `OP1_vdk.ldr` (with bit 3 also any `content/...` path), NUL | u32 file size, u32 CRC-32 continued over the bytes read, u32 bytes read (0 past the end). Other paths: 3 (path); a missing file: 7 (I/O). |
| 13 PRESET_APPLY | | staged presets only (else 3 path; nothing staged 2): applied now, no key, no restart -> u32 apply number. While an apply runs, BEGIN / DELETE / ABORT / COMMIT / RESTART / PRESET_APPLY answer 2 (state). Bit 5 (32). |
| 14 PRESET_LIST | u8 what, u32 from | what 0 / 1: user synth / drum rows with id > from: u32 last id given, u8 more, text `folder\tname\tT\n` (T: p plain synth, s sampler, k kit), whole records, at most 64 bytes; a row too long for a page alone goes out alone and cut, `folder\tname\tT\tc\n` (folder at most 24 bytes, the name what fits, cut at a UTF-8 character boundary), so `last` always moves on (before 2026-11-14 such a row stalled the list). what 2: the last apply's results from index from: u32 apply number, u8 running, u8 files, a result byte per sent file. what 3: u16 have, u16 cap for plain synth, sampler, kits (cap 0xFFFF: unknown). Other what: 1 (format). (15 is free again: the preset move-aside it was held for was ruled out, owner 2026-11-13; bit 6 = 64 is DX banks now. Upstream op1r-src numbers its own protocol, versions 3 and 4, differently from 7 on; the two never meet.) |

Without the inventory callbacks (`du_fs.inv_read` etc. = 0) the three commands answer status 1 (format).

END (2026-11-14): an END that comes right after an END (the host's resend after a lost or late reply) gets the
first one's status again (`du_session.end_last`); the file is counted once. Before, it answered state (no file open).

OFF_SET: a piece at offset 0 starts a new value; a piece at any other offset must continue where the last one ended,
else status 5 with the byte count the OP-1 has (a lost reply: the host resends from there; a resent last piece
answers 5 with count = total). The value is `[A-Za-z0-9 ._,:-]`, at most 1023 characters (`DU_OFF_MAX`: every plugin's id fits; `kn_off_store`). Entries are ids (`docs/plugin-format.md` "Names"),
stored as `op1rsettings` key `kennel.off` and read back before the reply. It applies at the next boot: the loader
and the registry read the list once (`kn_off_boot`), so OFF_GET with which = 1 still shows the old one. The built-in
`settings` (the T3 page: count-in and the features' on / off switches) is never switched off: the registry ignores the
name in the list, and the page shows it as always on.

## Core patches

A new core without the original R246 (root project `docs/sysex-update.md` "Core patches"): the page reads the CRC of
`/yaffs2/OP1_vdk.ldr` (the core file of the last boot-menu install; the SysEx flasher leaves it alone) with STAT in
256 KB pieces, and when it is a published core sends `OP1_vdk.ldr.knp` instead of `OP1_vdk.ldr`: `KNP1`, u32 base
size, base CRC, result size, result CRC, record count, then records `C` u32 offset u32 length (copy from the base) or
`L` u32 length + bytes. A core and a patch in one session are refused (state). At the restart `du_fw.c` checks the
base file's size and CRC, builds the core (`du_patch_apply`: every record's bounds, the total, the result CRC), runs
the usual LDR checks and flashes it; on any mismatch nothing changes (`du_fw_result` 84 other base file, 85 bad
patch, 86 no memory, or the LDR checks' 91/97).

### Content patches (HELLO bit 3)

The same `KNP1` script patches any content file: the staged path `content/<file>.knp` means "the new
`/yaffs2/content/<file>`, built from the OP-1's current copy of that file". The page reads that file's size and CRC
with STAT on `content/<file>` first. So a release can change a file derived from TE's firmware (`op1_factory.db`, a
stock SVG) without asking for op1_246.op1.

- Paths: the target has to be a valid `content/` path that doesn't end in `.knp` itself (`content/x.knp.knp`,
  `content/.knp` are refused). A file and a patch of it, or a DELETE of the file and a patch of it, in one session:
  2 (state).
- At the restart, before anything changes, `du_fw.c` `content_result` checks each patch's base (size and CRC),
  builds the result, checks its CRC and writes it to `/yaffs2/op1r_stage/rNNN`, then reads it back. Patches are built
  before the core's buffer is allocated, one at a time. The result then goes through the same backup, journal and
  rollback as a sent file. A reset after the file was replaced finishes from `rNNN`, or from the target if it already
  is the result; a resent patch whose target already is the result applies as is.
- On any mismatch the whole update is discarded and nothing changes: `du_fw_result` 87 the OP-1's file isn't the
  base (missing, size, CRC), 88 bad patch (header, a record, the total, the result CRC), 89 no memory, 83 the result
  couldn't be written to staging.
- Limits: the script and the result are each at most 127 x 128 KB (BEGIN's size check, `du_patch_header`). Both are
  held in memory (`NEW_ARR`, R246's heap at boot, before audio and the GUI) while one patch is built. Over USB a
  message is at most 96 bytes, so the path is at most 63 characters for STAT and 67 for BEGIN (with `.knp`).
  Patches count toward the 128 files of an update.
- Older firmware (no bit 3) accepts `content/<file>.knp` as an ordinary file and would store the script under that
  name. The host has to check bit 3 before it sends a content patch.

## Plugin files

After one core install the page sends, updates and removes single plugin files, without the firmware:
- Paths: BEGIN takes `plugins/<file>.knl|.op1p` as well as `OP1_vdk.ldr` and `content/...` (one level, no hidden
  names: `plugins/.boot` is the crash marker). DELETE takes a plugin file in `content/` or `plugins/` and nothing
  else (`du_plugin_path`). A path sent and deleted in one session is refused (state); a resent DELETE is fine.
- Staging as before: every file with its size and CRC, deletes as `D <path>` lines in the manifest, all of it
  only after T1 (COMMIT when files or deletes are staged, RESTART otherwise, e.g. only the switched-off list
  changed). T2 discards everything.
- At the restart the boot hook checks every staged file first, then copies and deletes. Without `OP1_vdk.ldr` in the
  manifest it boots on (no second restart): the loader runs later in the same boot and loads the new files.
- Same core: the LIST header carries `core <start> <len> <crc>`, the CRC-32 of the running core's `.text` +
  `.rodata` (0x01E00000 to link.ld's `__core_ro_end`, computed once at the first LIST). The page computes the same
  over its build's `OP1_vdk.ldr` blocks (`ldrRangeCrc`); equal means only plugin files need to go. Otherwise it
  sends the whole firmware as before.

## Presets (HELLO bit 4, branch devupd-presets 2026-11-06)

The page adds, replaces and removes user presets without disk mode. R246 keeps a user preset as a row in op1.db
(`synth_user` / `drum_user`: id, patch JSON, folder) and, for a sampler or drum preset, its sample in
`/yaffs2/user/audio/preset_<synth|drum>/<folder>/<name>.raw`; the preset browser and the loader read only the rows
(`patch_table_loader` 0x01A0567C), so a file placed in those folders alone is never listed. Evidence and addresses:
ARCHITECTURE.md "Presets over SysEx".
- Paths: BEGIN takes `presets/synth/<folder>/<name>.aif` and `presets/drum/<folder>/<name>.aif`, the file being an
  OP-1 patch AIFF as on the disk (AIFC `sowt` or `NONE`, or AIFF; APPL `op-1` + JSON; SSND for a sampler or drum kit,
  16-bit mono, at most 6 / 12 s), at most 1,100 KB. Folder 1..24 and name 1..32 characters of `a-z 0-9 space _ -`
  (R246's text entry charset), no space at either end, the folder not `user` (the slot snapshots on the disk), nothing
  with `te-boot` (`du_preset_path`). DELETE of the same `.aif` path stages its removal as an empty
  `presets/<kind>/<folder>/<name>.del` (an `F 0 00000000` manifest line); a `.del` is never accepted from BEGIN. One
  preset can't be sent and removed in one session (state); a resent DELETE is fine. A build without the importer
  (`du_fs.presets` 0) refuses these paths (path).
- The apply phase copies them like any file to `/yaffs2/presets/...` (backed up and rolled back with the rest). At the
  end of the same boot's plugin hook (`kennel/kn_presets.c`, databases open, before `fat_sync_after_reboot` and the
  loader) every queued file is handled and removed: removals first, then adds. An add sets the JSON's `"name"` to the
  file name, checks the caps of the running firmware (synth save gate, sampler limit, drum gate; factory rows
  counted) and goes in through R246's own insert (parse, `parse_patch_json`, INSERT); rows with the same folder and
  name are deleted after it worked, so a replace keeps one row with the new contents. Refused (logged as `preset: ...`
  in kennel's log, counted in `kn_preset_refused`, file removed): not a patch file, a `'` in the patch, no or two
  `name` keys, a sample that isn't 16-bit mono within the limit, no room, R246's patch check.
- Live (bit 5 = 32, branch usb-presets 2026-11-13): end the session with PRESET_APPLY instead of COMMIT. The OP-1
  answers at once with the apply's number and imports one preset per main loop pass; poll PRESET_LIST what 2 until that
  number shows with running 0, then read the result byte per sent file, in the session's order (files, then DELETEs):
  1 added, 2 replaced, 3 removed, 4 not there, 16 not a patch file, 17 patch text refused (a `'`, no or two `name`
  keys), 18 sample not 16-bit mono within the limit, 19 / 20 / 21 no room (plain synth / sampler / kits), 22 R246's
  patch check, 23 write failed, 24 cap unreadable, 25 delete failed, 26 bad name; 0 = not done (cut short). A removal
  goes through preset tools' delete (`.deleted/` keeps the newest 16). The tables are reloaded and an open browser
  rebuilt at the end; a toast says what changed. More than 128 files: several applies (the page puts every delete
  first). The restart path above still works for a mixed update.
  LIST's inventory text is built once per boot, so its `presets N cap C` doesn't follow a live apply: read PRESET_LIST
  what 3 for the current counts.

## DX voice banks (HELLO bit 6 = 64, branch dx-push 2026-11-14)

The dx engine reads its banks from `/yaffs2/user/dx/*.syx` (`plugins/dx/dx_bank.c` `bank_scan`: the first 16 good
files, sorted by name; a name is its first 13 characters before `.syx`, folded to lower case).
- Paths: BEGIN takes `user/dx/<name>.syx`, name 1..13 characters of `a-z 0-9 _ -` (lower case only, so two names never
  fold into one bank; nothing with `te-boot`; `du_dx_path`). Size exactly 4104 (a 32-voice bulk dump: `F0 43 0n 09 20
  00`, 4096 bytes, checksum, `F7`) or 163 (one voice: `F0 43 0n 00 01 1B`, 155 bytes, checksum, `F7`); anything else
  is 4 (size). The device does not read the bytes: the page checks the header and checksum, and the engine checks them
  again at its scan (a bad file is skipped). DELETE of the same path stages its removal (a `D user/dx/<name>.syx`
  manifest line, as a plugin file); one bank can't be sent and removed in one session (state). A build without the
  lane (`du_fs.dx_banks` 0) refuses both (path).
- Applied at the restart (COMMIT / T1) by the ordinary apply: copied to `/yaffs2/user/dx/<name>.syx` (the copy makes
  the folder), backed up and rolled back with the rest; a removal of a missing file is fine. PRESET_APPLY refuses them
  (path): banks need the restart.
- No listing command: the page remembers the names it sent from that browser and offers those for removal.

## Inventory text

Built once, on the first LIST, from records made at boot, so every page of one read belongs to the same text.

```
kennel-inventory 1\tcore <start hex8> <len hex8> <crc hex8>\tpresets <count dec5> cap <cap dec5>
<kind>\t<name>\t<source>\t<path>\t<version>\t<author>\t<size>\t<crc>\t<state>\t<claims>\t<reason>
...
```

Header fields are tab-separated and found by their first word, so a page ignores the ones it does not know.
`presets`: R246's count of user synth presets (0x018B610C, recounted from the database) and the cap of its save gate
(`R1 = cap (X)` at 0x019FEF02: 100 in R246, 300 in a 300 build), five digits each. A build with a smaller cap than
the count stops R246's boot on `patch.cpp:632 synthSynthes_patch_count <= kMaxSynthSynthes_patches`, so the page must
refuse it. The count is rewritten in the cached text at each LIST from offset 0 (saves since boot show); the field
is left out if the gate instruction is not `R1 = imm (X)` (0xE121).

| Field | Values |
|---|---|
| kind | `synth`, `fx`, `feature`, `-` (the file did not parse) |
| name | the plugin's id (`docs/plugin-format.md` "Names"): a file's name without `.knl` / `.op1p`, a built-in feature's name |
| source | `builtin`, `knl`, `op1p` |
| path | `plugins/<file>` or `content/<file>`; empty for built-ins |
| version, author | `.knl` extension table (tags 3, 2); empty if absent |
| size | file size in bytes (0 for built-ins) |
| crc | 8 hex digits: the CRC the file carries (`.knl` header offset 12, `.op1p` trailer); 0 for built-ins. Compare with the same field of the file the page has. |
| state | `loaded`, `failed` (a check failed), `skipped` (crash marker: the last boot did not reach the UI), `off` (switched off by the user, lost a claim, or a built-in replaced by a file) |
| claims | comma-separated, each with a prefix: `+` held, `!` lost (to the feature named in reason), `~` not held (the plugin is not running). From the `.knl` extension table, else the feature object (built-ins). |
| reason | why it failed / is off (`CRC mismatch`, `switched off`, `lost page:t4 to chord`, `replaced by a file`), `replaces the built-in` for a file that took a built-in's number, else empty |

Order: plugin files (plugins/ first, then content/), built-in engines and effects, built-in features. Tabs and
newlines in names become spaces. The page should match records by path (files) or kind + name (built-ins).

## Device side

- `kennel/kn_inv.c`, `kn_inv.h`: records (arena, `kn_alloc`), the text, `kn_inv_read`.
- `kennel/kn_boot.c` `load_file`: one record per file (path, size, state, reason); `load_knl` / `load_op1p` add kind,
  name, CRC and the extension table (`kn_parse` now returns claims, author and version in `kn_info`); a crash-marker
  skip records every file as skipped; built-in engines and effects are added after the loader.
- `kennel/kn_features.c`: `kn_feature_register` reports each decision (`kn_inv_feature_result`: a new record for a
  built-in, the file's record for a file); `resolve_claims` reports the loser, its claim and the winner
  (`kn_inv_lost`) before it compacts the list. Both are weak, so the registry's host test runs without them.
- `devupd/du.c`: LIST / OFF_GET / OFF_SET framing and the OFF_SET reassembly (`du_session.off_buf`, 1024 bytes);
  `devupd/du_fw.c`: the callbacks (`kn_inv_read`, `op1_setting_get_str`, `kn_off_store`, `kn_off_boot`).
- Memory: records and text in the arena (about 100 bytes per record plus the strings; the text about 80 bytes per
  line), nothing at boot beyond the records. BSS: `du_session` grew by 168 bytes.
- The DB write for OFF_SET runs in `du_service` (main loop), the same thread as the update's file writes.

## Page side (OP1-Emulator)

`web/firmware/op1push.js`: `session(port)` with `hello()`, `list()`, `getOff({atBoot})`, `setOff(names)`;
`readInventory(port)` = `{records, off, offBoot}` or null. Without the capability, `list()` and `getOff()` return
null and `setOff()` returns false. The read is part of Send: `push(port, files, {check})` calls `check(inventory)`
after the OP-1 answers and before anything is staged or cleared; throwing stops the push with nothing changed. That
is where the phase-7 conflict check goes; today app.js logs a summary and hands it to `web/firmware/inventory-debug.js`,
a raw view behind `?push` (the switched-off list can be saved from there; not the conflict screen).

## Tests

- `synth_sdk/harness/inventory_test.c` (build line in its header): a simulated boot with the real registry, the
  text, LIST paging, OFF get / set with resent pieces, refused characters and lengths, a build without the
  callbacks. Its `stdio` mode serves the device for OP1-Emulator `tools/firmware/qa/inventory_js_test.mjs`
  (op1push.js against it, with lost messages and lost replies, plus a stock devupd build).
- Presets: `harness/devupd_test.c` (paths, HELLO bit 4, BEGIN / DELETE refusals, the .del staging, manifest, the AIFF
  reader and the JSON name); emulator: OP1-Emulator `run/devupd-presets-2026-11-06/` (add, replace, remove, 50 in one
  batch, the cap, refusals, T2, an interrupted transfer, disk mode after).
- Emulator: OP1-Emulator `tools/firmware/qa/inventory_emu_test.py` boots a KN_DEVUPD=1 build twice over USB/IP MIDI:
  LIST, OFF_GET, OFF_SET in the first boot, the stored names switched off in the second.
