#!/usr/bin/env python3
"""Build custom synth engines and an installable OP-1 firmware (fw 246).

  ./make_firmware.py [--opz] [--release]   -> ../op1_246_custom-repacked.op1   (synths / FX: plugins/*/plugin.json)
                                              + ../op1_246_custom-delta.op1 (changes since the installed tree, docs/34)

  --release  boot screen shows only "op1r <VERSION>" (use for the patcher); local builds add the build time

  --opz   also enable the hidden OP-Z controller MIDI mode (docs/12). COM -> CTRL (T2) starts in the
          normal CTRL mode; the OP-Z mode is switched on by the host-mode SysEx F0 00 20 76 00 01 03 F7
          (01 = Ableton, 02 = Reason, other = off; flag cleared again on every CTRL entry).

Steps: generate engine table -> compile with dockerised bfin-elf-gcc -> patch OP1_vdk.ldr
(new code block @0x01E00000, iter vtable slots 2-5, JUMP.L hook at 0x019B975C) -> copy unpacked
firmware -> add synth_types rows (iter + one per engine, knobs[4] = 0x5300+n) -> op1repacker repack.
Encrypted LDR blocks: only the precomputed patches in l1_patches.json (see L1_IMM_PATCHES).
"""
import argparse, json, os, shutil, sqlite3, struct, subprocess, sys
import plugins
import kn_mem                                   # kn_mem.h: the one memory map

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC_FW = os.path.join(ROOT, 'op1_246')
OUT_FW = os.path.join(ROOT, 'op1_246_custom')
REPACKER = os.path.join(ROOT, 'op1repacker', '.venv', 'bin', 'op1repacker')
CODE_BASE = kn_mem.CORE_BASE
CODE_LIMIT = kn_mem.CORE_CODE_LIMIT   # loaded image must end below
BSS_LIMIT = kn_mem.BSS_LIMIT          # .bss at KN_BSS_LO (link.ld) must end below
MAGIC = 0x5300
MAX_ORDER = 63                                  # OP1_MAX_ORDER (op1_plugin.h): table size
BUILTIN_MAX_ORDER = 31                          # plugin.json orders (plugin files get 32..63 at boot)
BUILTIN = {'fm','digital','drwave','string','cluster','pulse','sampler','phase','drum','dbox',
           'ls','dna','dsynth','voltage','iter'}
VT_ITER, VT_FILTER, VT_FILTER_ST = 0x019103CC, 0x01910C94, 0x01910CB4   # _ST: master (stereo) filter
VT_DRUM = 0x0190FAC4                                                      # DrumSampler voice (docs/31)
SLOTS = {'kn_tombola_advance': (0x01911E04,6,0x01A65BBC),   # Tombola player advance: long frames in short steps (kennel/kn_tombola.c)
         'kn_ds_entry_render': (0x0190F8A4,2,0x01970EE8), 'kn_ds_entry_trigger': (0x0190F8A4,3,0x01970DE6), 'kn_ds_entry_status': (0x0190F8A4,4,0x01970E5C), 'kn_ds_entry_release': (0x0190F8A4,5,0x01970E7E), 'sp_fw_render': (0x019119F4,2,0x01A51A7C), 'sp_fw_note_on': (0x019119F4,3,0x01A518F4), 'sp_fw_note_off': (0x019119F4,5,0x01A51964), 'sp_type_job': (0x0190F3FC,2,0x0193FFAC),
'synth_render': (VT_ITER, 2, 0x019B99D4), 'synth_note_on': (VT_ITER, 3, 0x019B9B8A),
         'synth_query': (VT_ITER, 4, 0x019B9980), 'synth_note_off': (VT_ITER, 5, 0x019B996C),
         'fx_render': (VT_FILTER, 2, 0x019E7934), 'fx_init': (VT_FILTER, 3, 0x019E780A),
         'fx_render_stereo': (VT_FILTER_ST, 2, 0x019E7EE4), 'fx_init_stereo': (VT_FILTER_ST, 3, 0x019E78D0),
         # master LFO (screens/mlfo.c): the render slot of the seven other stock stereo (master) FX vtables
         'ml_st_delay': (0x0190FB8C, 2, 0x0197DC42), 'ml_st_grid': (0x01910224, 2, 0x019AF83C),
         'ml_st_punch': (0x01910C3C, 2, 0x019E662C), 'ml_st_phone': (0x01911314, 2, 0x01A1C25C),
         'ml_st_spring': (0x019113DC, 2, 0x01A32FFC), 'ml_st_nitro': (0x01910034, 2, 0x019A684C),
         'ml_st_cwo': (0x0190F594, 2, 0x019450FC),
         # FX switch declick (kennel/kn_declick.c): the render slot of the seven other stock mono FX vtables
         'kn_dc_mono_delay': (0x0190FB6C, 2, 0x0197D8C4), 'kn_dc_mono_grid': (0x01910204, 2, 0x019AF338),
         'kn_dc_mono_punch': (0x01910C1C, 2, 0x019E6260), 'kn_dc_mono_phone': (0x019112F4, 2, 0x01A1BB74),
         'kn_dc_mono_spring': (0x019113BC, 2, 0x01A326E8), 'kn_dc_mono_nitro': (0x01910014, 2, 0x019A62A4),
         'kn_dc_mono_cwo': (0x0190F574, 2, 0x0194480C),
         'dp_fw_render': (VT_DRUM, 2, 0x019789EC), 'dp_fw_note_on': (VT_DRUM, 3, 0x01978926),
         'dp_fw_note_off': (VT_DRUM, 5, 0x01978898),
         'dp_type_job': (0x0190F34C, 2, 0x0193F86C),                       # drum type browser job (docs/31)
         'kn_ds_slot_save_job': (0x0190F4AC, 2, 0x01940574),               # slot save job: live patch JSON busy (kn_drum_synth.c)
         'kn_ds_patch_job_a': (0x0190F2F4, 2, 0x0193F578),                 # .. other jobs that serialize a live patch
         'kn_ds_patch_job_b': (0x0190F3A4, 2, 0x019407DC)}
FX_BUILTIN = {'delay','grid','punch','phone','spring','filter','nitro','cwo'}
# fx_types filter (R246 has none; the plugin FX host): a fresh FILTER pick (synth, drum, master) starts at these words.
# Owner 2026-11-10: LP IV, FREQ fully open, DRIVE 60, RES 0 (until then op1repacker's [7548, 0, 8272, 19572]: AP,
# DRIVE 45). Words: 0 FREQ 64..14528 (a dial, no number), 1 RES 0..24576, 2 type 0..22528 in 2048 steps (0 LP IV,
# 2048 LP III, 4096 LP II, 6144 LP I, 8192 AP, .., 22528 HP IV), 3 DRIVE 8192..32767; RES / DRIVE show
# (w - min) * 99 // (max - min), so 23280 (a detent from 8192) shows 60. Words 4..7 as before.
FILTER_ROW = (2, 'filter', '[14528, 0, 0, 23280, 8000, 8000, 8000, 8000]')
ITER_PARAMS = '[1516, 16704, 0, 15168, 0, 0, 0, 0]'                              # synth_types iter (the engines' host)
DRUM_PARAMS = '[0, 0, 0, 0, 0, 0, 0, 0]'                                         # drum_types drum+
SEQ_ROWS = ('euclid', 'dots', 'oracle', 'peal')   # patch_db's own seq_types rows (features without "sequencer")
# Raw knob ranges of fx type 5 (filter), which every custom FX runs in: range table 0x01DE5C50 + 5*0x30,
# filled at boot by 0x01A1E914 (docs/15). read_fx_param asserts "Instr fx param out of range" (and the OP-1
# locks up, also at every boot while the value is stored) if a raw word lies outside. plugin.json FX
# defaults are knob positions 0..32767 and are mapped into these ranges.
FX_RANGES = [(64, 14528), (0, 24576), (0, 22528), (8192, 32767)]
HOOKS = {0x019674F8: ('hook_inputbus', bytes.fromhex('700508e114ac')),
         0x0197E956: ('hook_coop_dsynth', bytes.fromhex('4f32b16f')),   # coop-fw (dsp/coop): DSynth voice loop (LSETUP) -> coop_dsynth_voice_loop
         0x019457D2: ('hook_coop_cwo', bytes.fromhex('22e14000')),   # coop-fw (dsp/coop): cwo stereo per-sample loop
         0x0194569A: ('hook_coop_cwo_v0', bytes.fromhex('0ae3e4f0')),   # coop-fw (dsp/coop): cwo: CALL __cxa_vec_ctor (stack array 1)
         0x019456B6: ('hook_coop_cwo_v1', bytes.fromhex('0ae3d6f0')),   # coop-fw (dsp/coop): cwo: CALL __cxa_vec_ctor (stack array 2)
         0x019456DC: ('hook_coop_cwo_v2', bytes.fromhex('0ae3c3f0')),   # coop-fw (dsp/coop): cwo: CALL __cxa_vec_ctor (stack array 3)
         0x019456EE: ('hook_coop_cwo_v3', bytes.fromhex('0ae3baf0')),   # coop-fw (dsp/coop): cwo: CALL __cxa_vec_ctor (stack array 4)
         0x01A1BCAC: ('hook_coop_phone', bytes.fromhex('b2e04421')),   # coop-fw (dsp/coop): phone mono output loop
         0x01A1BBFC: ('hook_coop_phonecap', bytes.fromhex('a2e02e00')),   # coop-fw (dsp/coop): phone mono capture loop
         0x019AF92E: ('hook_coop_grid', bytes.fromhex('a2e0cd01')),   # coop-fw (dsp/coop): grid stereo per-sample loop
         0x0197DD46: ('hook_coop_delay', bytes.fromhex('b2e01a11')),   # coop-fw (dsp/coop): delay stereo per-sample loop
         0x019A64A4: ('hook_coop_nitro', bytes.fromhex('b2e0ef20')),   # coop-fw (dsp/coop): nitro mono loops
         0x01A3310A: ('hook_coop_spring', bytes.fromhex('a2e0c532')),   # coop-fw (dsp/coop): spring stereo per-sample loop
         0x01A0BCE0: ('hook_coop_phase', bytes.fromhex('a2e03d40')),   # coop-fw (dsp/coop): Phase voice loop
         
         0x01A862D4: ('hook_notesreset', bytes.fromhex('00e80000')),
         0x01A8624C: ('hook_morelease', bytes.fromhex('00e80000')),     # VoiceCtl MIDI release of its held list (LINK 0) -> kn_mo_release
         0x01A86420: ('hook_keyslot', bytes.fromhex('00e80400')),
         0x019AC288: ('hook_keydown', bytes.fromhex('06e3c6c6')),
         0x019AC3A0: ('hook_keyup', bytes.fromhex('06e33ac6')),
         0x01A17046: ('hook_keyoct0', bytes.fromhex('03e38978')),
         0x01A170E0: ('hook_keyoct1', bytes.fromhex('03e33c78')),
         0x01A42744: ('hook_keyoct2', bytes.fromhex('02e30a1d')),
         0x01A427C8: ('hook_keyoct3', bytes.fromhex('02e3c81c')),
         0x01A510AC: ('hook_keyoct4', bytes.fromhex('01e356a8')),
         0x01A510F0: ('hook_keyoct5', bytes.fromhex('01e334a8')),
         0x01A86236: ('hook_seqoct0', bytes.fromhex('fce36336')),   # CALL queue octave steps (synth_octave_step)
         0x01A86578: ('hook_seqoct1', bytes.fromhex('fce3c234')),   # CALL queue octave steps (slot select)
0x01A3BDB0: ('hook_lander1', bytes.fromhex('fce38e48')), 0x019C35F0: ('hook_lander2', bytes.fromhex('00e36e0c')), 0x019C369C: ('hook_lander3', bytes.fromhex('00e3180c')),
0x01912128: ('hook_knfadeadsr', bytes.fromhex('e3052a32')),
0x019B975C: ('hook_namecmp', bytes.fromhex('18300b32')),      # instr_types name compare
         0x01A01844: ('hook_samplecheck', bytes.fromhex('ffe328fc')),  # sample_path 'sampler' check
         0x019AAD8E: ('hook_fxnamecmp', bytes.fromhex('18300b32')),    # fx_types name compare
         0x019B9EF8: ('hook_iterread', bytes.fromhex('03e38c71')),     # iter screen: read knobs
         0x01A3BD58: ('hook_screenctor', bytes.fromhex('fbe3d0f2')),   # screen ctor list
         0x019F07D2: ('hook_screenload', bytes.fromhex('02e33f59')),   # boot: load all screens
         0x019427B8: ('hook_rfp019427b8', bytes.fromhex('07e3f432')),   # CALL read_fx_param
         0x01984F60: ('hook_rfp01984f60', bytes.fromhex('05e3201f')),   # CALL read_fx_param
         0x019A74D4: ('hook_rfp019a74d4', bytes.fromhex('04e3660c')),   # CALL read_fx_param
         0x019B05F8: ('hook_rfp019b05f8', bytes.fromhex('03e3d4c3')),   # CALL read_fx_param
         0x019E6A48: ('hook_rfp019e6a48', bytes.fromhex('02e3ac11')),   # CALL read_fx_param
         0x019E832C: ('hook_rfp019e832c', bytes.fromhex('02e33a05')),   # CALL read_fx_param
         0x01A1CFD2: ('hook_rfp01a1cfd2', bytes.fromhex('00e3e75e')),   # CALL read_fx_param
         0x01A33FB2: ('hook_rfp01a33fb2', bytes.fromhex('ffe3f7a6')),    # CALL read_fx_param
         0x019C2D3E: ('hook_keyev', bytes.fromhex('ffe39b9f')),          # KeyHandler: key event dispatch
         0x019C2E94: ('hook_knobev', bytes.fromhex('ffe3bc9e')),         # KeyHandler: encoder step dispatch
         0x01A85828: ('hook_chordon', bytes.fromhex('ffe3eef6')),        # key_down: CALL voicectl_synth_note_on
         0x01A858D0: ('hook_chordoff', bytes.fromhex('ffe3c4fb')),       # key_up: CALL voicectl_synth_note_off
         0x01A857B0: ('hook_mostockon', bytes.fromhex('fae35aeb')),      # key_down tail: CALL midi_note_on_out (kn_midiout.c)
         0x01A85880: ('hook_mostockoff', bytes.fromhex('fae3a0ea')),     # key_up tail: CALL midi_note_off_out (kn_midiout.c)
         0x01A042A2: ('hook_lforange', bytes.fromhex('00e37dce')),       # parse_patch_json: LFO word range check
         0x01A03884: ('hook_patchtype', bytes.fromhex('fde3c6af')),      # parse_patch_json: CALL instr_type_from_name
         0x01A04030: ('hook_fxpatchtype', bytes.fromhex('fde30a37')),    # parse_patch_json: CALL fx_type_from_name
         0x019F02EE: ('hook_knboot', bytes.fromhex('fbe3cd65')),         # boot: CALL Clips::load -> + plugin loader (kennel/kn_boot.c)
         0x019F02E0: ('hook_btopen', bytes.fromhex('fbe319fb')),         # boot: CALL db2::open -> L1 pokes (kn_l1rt.c), then timed (kn_boottime.c, op1r b220d08)
         0x019F02F4: ('hook_btfat', bytes.fromhex('fde35e37')),          # boot: CALL fat_manager::init -> timed
         0x019F0456: ('hook_btsnd', bytes.fromhex('00e3bdaa')),          # boot: CALL 0x01A059D0 (the five sound loads) -> each timed
         0x01A05766: ('hook_lpsyn1', bytes.fromhex('ffe3bbfd')),         # load_synth_presets: CALL set_synth_patch -> swap (kn_boottime.c)
         0x01A058D4: ('hook_lpsyn2', bytes.fromhex('ffe304fd')),         # .. user presets
         0x01A050A2: ('hook_lpdrm1', bytes.fromhex('ffe3d3fd')),         # load_drum_presets: CALL set_drum_patch -> swap
         0x01A05184: ('hook_lpdrm2', bytes.fromhex('ffe362fd')),         # .. user presets
         0x0197008E: ('hook_lpgrow', bytes.fromhex('82c6fb89')),         # db2::load_presets row vector: grow x33, not x1.5
         0x0196FF9A: ('hook_plparse', bytes.fromhex('02e3ff5f')),   # db2::load_presets: CALL Reader::parse -> light rows in a user-table load (kn_preset_store.c)
         0x01A0586E: ('hook_plsynu', bytes.fromhex('fbe30f53')),   # load_synth_presets: CALL db2::load_presets(synth_user) -> light mode
         0x01A05122: ('hook_pldrmu', bytes.fromhex('fbe3b556')),   # load_drum_presets: CALL db2::load_presets(drum_user) -> light, LIMIT the room
         0x01A01BCC: ('hook_plrcs', bytes.fromhex('fbe36071')),   # recount_presets: synth_user -> light
         0x01A01CD6: ('hook_plrcd', bytes.fromhex('fbe3db70')),   # recount_presets: drum_user -> light
         0x0193F58C: ('hook_dt1', bytes.fromhex('0ae1f8204ae1de01')),   # drum table address -> kn_drum_tab
         0x0193FBC6: ('hook_dt2', bytes.fromhex('02e1f82042e1de01')),   # drum table address -> kn_drum_tab
         0x01A01E14: ('hook_dt3', bytes.fromhex('00e1fc2040e1de01')),   # drum table address -> kn_drum_tab
         0x01A0265A: ('hook_dt4', bytes.fromhex('05e1fc2045e1de01')),   # drum table address -> kn_drum_tab
         0x01A0293A: ('hook_dt5', bytes.fromhex('07e1fc2047e1de01')),   # drum table address -> kn_drum_tab
         0x01A04E54: ('hook_dt6', bytes.fromhex('06e1fc2046e1de01')),   # drum table address -> kn_drum_tab
         0x01A05004: ('hook_dt7', bytes.fromhex('05e1f82045e1de01')),   # drum table address -> kn_drum_tab
         0x01A06018: ('hook_dt8', bytes.fromhex('00e1f82040e1de01')),   # drum table address -> kn_drum_tab
         0x01A060D8: ('hook_dt9', bytes.fromhex('00e1f82040e1de01')),   # drum table address -> kn_drum_tab
         0x01A06020: ('hook_dtctor', bytes.fromhex('04e321ec')),   # drum table ctor: CALL vector ctor -> 448 entries
         0x01A060E0: ('hook_dtdtor', bytes.fromhex('04e30eec')),   # drum table dtor: 448 entries
         0x019FEEE4: ('hook_dtgate', bytes.fromhex('09e11861')),   # drum save gate (count < 58) -> 256 user kits
         0x01A051B2: ('hook_dtassert', bytes.fromhex('d461')),   # drum loader user check: R4 = 58 -> R4 <<= 3 (448)
         0x01A18152: ('hook_brsort', bytes.fromhex('00e3c90a')),   # list child add: CALL std::sort -> skipped while a preset list builds
         0x01A50884: ('hook_brsyn', bytes.fromhex('fde3868f')),   # CALL synth preset list builder -> sort each folder once
         0x01977718: ('hook_brdrm', bytes.fromhex('04e3ea58')),   # CALL drum kit list builder -> sort each folder once
         0x019FB57C: ('hook_svgstart', bytes.fromhex('00e15c0a')),       # svg_parse_file after the BOM skip: R0.L = 0xA5C -> per-panel art (kn_svgvar.c)
         0x01A3B580: ('hook_lzfind', bytes.fromhex('00e80000')),         # Screen::find_node entry (LINK 0): lazy stock screens (kn_lzscr.c)
         0x019F054A: ('hook_knmaster', bytes.fromhex('ffe3393a')),       # boot: CALL MasterController::load -> + master FX by name
         0x019D97F0: ('hook_knmasterlist', bytes.fromhex('fce398ab')),   # master FX list: CALL get_master_fx_type -> the plugin's name (opening row)
         0x019F0BE2: ('hook_tapefinal', bytes.fromhex('03e3971d')),      # shutdown: CALL tape_c::service(1) loop -> kn_tape_final (held saves too)
         0x019F0BEA: ('hook_knunmount', bytes.fromhex('fde3652c')),      # shutdown: CALL yaffs unmount -> + remove the crash marker
         0x019F0C46: ('hook_gcrate', bytes.fromhex('05e30150')),         # main loop: CALL yaffs background GC -> at most 10 / s (op1r 49)
         0x01A715DC: ('hook_mswrite', bytes.fromhex('00e80000')),        # usb_ms_write_sectors entry (LINK 0) -> kn_ms_write: zero sectors over zeros skipped, a failed write a SCSI error, not an assert (kennel/kn_tapes.c)
         0x01976288: ('hook_diskwr', bytes.fromhex('00e80000')),         # FatFs disk_write entry (LINK 0) -> kn_disk_write: tapes 2..4 stay sparse under R246's own writes (kennel/kn_tapes.c)
         0x01974C58: ('hook_defragwr', bytes.fromhex('00e80800')),       # defragmenter cluster write (LINK 0x20) -> kn_defrag_write: tapes 2..4 stay sparse (kennel/kn_tapes.c)
         0x019F034E: ('hook_btsync', bytes.fromhex('fde3f130')),         # boot: CALL fat_sync_after_reboot -> kn_boot_fat_sync: after disk mode on tape 2..4 the sync runs on that tape (kennel/kn_tapes.c)
         0x0191995C: ('hook_crash', bytes.fromhex('00e80400')),          # te_fatal_show_message entry (LINK 0x10) -> the crash screen (kennel/kn_crash.c, op1r 8bf2f84)
         0x019411B8: ('hook_bgsqueue', bytes.fromhex('00e80000')),       # queue SaveSlotJob(is_drum, slot): LINK -> bgs_queue_slot (delayed, bgsave.c)
         0x019F0BDC: ('hook_bgsstop', bytes.fromhex('fae37c83')),        # shutdown: CALL BgFileWorker stop -> kn_bgs_stop (saves first, bgsave.c)
         0x0193F664: ('hook_psql1', bytes.fromhex('08e33a6b')),        # drum kit load job 0x0193F578: CALL snprintf(UPDATE ..._slots, 5000) -> kn_patch_sql
         0x0193FB28: ('hook_psql2', bytes.fromhex('08e3d868')),        # drum type job 0x0193F86C: CALL snprintf(UPDATE ..._slots, 5000) -> kn_patch_sql
         0x0193FE2C: ('hook_psql3', bytes.fromhex('08e35667')),        # drum type job 0x0193F86C (second): CALL snprintf(UPDATE ..._slots, 5000) -> kn_patch_sql
         0x01940468: ('hook_psql4', bytes.fromhex('08e33864')),        # synth type job 0x0193FFAC: CALL snprintf(UPDATE ..._slots, 5000) -> kn_patch_sql
         0x019405D4: ('hook_psql5', bytes.fromhex('08e38263')),        # slot save job 0x01940574, drum: CALL snprintf(UPDATE ..._slots, 5000) -> kn_patch_sql
         0x0194063E: ('hook_psql6', bytes.fromhex('08e34d63')),        # slot save job 0x01940574, synth: CALL snprintf(UPDATE ..._slots, 5000) -> kn_patch_sql
         0x019408AC: ('hook_psql7', bytes.fromhex('08e31662')),        # synth preset load job 0x019407DC: CALL snprintf(UPDATE ..._slots, 5000) -> kn_patch_sql
         0x019B2690: ('hook_knscreens', bytes.fromhex('04e3484a')),      # gfx_render_frame: CALL screens_update -> + toast
         0x019AB8C8: ('hook_gfxfinish', bytes.fromhex('07e3caaf')),      # Gfx_thread::Run: CALL flush -> kn_gfx_finish (flush + invalidate, present; or keep the shown frame)
         0x01A3BBE0: ('hook_gfxframe', bytes.fromhex('ffe3433c')),       # screens_update: CALL raster_begin_frame + update loop -> kn_gfx_frame (or skip)
         0x01A0D150: ('hook_euplayer', bytes.fromhex('ffe38801')),       # create_player case 3: finger or euclid
         0x01A42A2E: ('hook_seqname1', bytes.fromhex('ffe38bfc')),       # set_sequencer: SeqIds::from_name
         0x01A42BDC: ('hook_seqname2', bytes.fromhex('ffe3b4fb')),       # load (synth): SeqIds::from_name
         0x01A42CE0: ('hook_seqname3', bytes.fromhex('ffe332fb')),       # load (drum): SeqIds::from_name
         0x01A422EC: ('hook_seqtoname', bytes.fromhex('09e138a6')),      # SeqIds::name(type) entry -> eu_seq_name
         0x019C9C3A: ('hook_lfoname1', bytes.fromhex('ffe391ff')),       # lfo_types::from_name compare
         0x019C9BE2: ('hook_lfoname2', bytes.fromhex('ffe3bdff')),       # lfo_types is_valid compare
         0x0193DE2A: ('hook_rlp0193de2a', bytes.fromhex('07e3c95a')),   # CALL read_lfo_param
         0x01968C34: ('hook_rlp01968c34', bytes.fromhex('06e3c403')),   # CALL read_lfo_param
         0x01981EDA: ('hook_rlp01981eda', bytes.fromhex('05e3713a')),   # CALL read_lfo_param
         0x019E4A18: ('hook_rlp019e4a18', bytes.fromhex('02e3d224')),   # CALL read_lfo_param
         0x01A2D388: ('hook_rlp01a2d388', bytes.fromhex('ffe31ae0')),   # CALL read_lfo_param
         0x01A30C3C: ('hook_rlp01a30c3c', bytes.fromhex('ffe3c0c3')),   # CALL read_lfo_param
         0x01A48FE8: ('hook_rlp01a48fe8', bytes.fromhex('ffe3ea01')),    # CALL read_lfo_param
         0x01A50560: ('hook_t4scr', bytes.fromhex('ffe35e5d')),          # synth T4 page: CALL ScreenId::for_lfo -> kn_t4_screen_for (kennel/kn_eng_hooks.c)
         0x019AC8B4: ('hook_recA', bytes.fromhex('38080b10')),           # on_key input: type == sampler?
         0x019ACC7C: ('hook_recB', bytes.fromhex('01080710')),           # on_key_shift input: type == sampler?
         0x019DEEF2: ('hook_recend', bytes.fromhex('01e3aa1d')),        # record end: make slot a sampler patch
         0x01A85C8A: ('hook_midicc', bytes.fromhex('ffe381f9')),         # VoiceCtl::on_midi_rx: CALL midi_message (CC)
         0x019E39D6: ('hook_midistart', bytes.fromhex('03e3fdd6')),      # midi_rx_parse FA: CALL reset beat counters
         0x01A6ED96: ('hook_usbdesc', bytes.fromhex('ffe3adda')),        # USB init: CALL usb_audio::desc_init (6 ch)
         0x019E151C: ('hook_usbiso1', bytes.fromhex('04e3ac47')),        # usb_class_event_cb: iso IN, first packet
         0x019E161C: ('hook_usbiso2', bytes.fromhex('04e32c47')),        # .. iso IN (data)
         0x019E1812: ('hook_usbiso3', bytes.fromhex('04e33146')),        # .. iso IN (start-up, zero-filled)
         0x019F0A24: ('hook_ciservice', bytes.fromhex('03e3761e')),      # main loop tape_c::service(0): count-in PLAY
         0x0196F942: ('hook_sqlcache', bytes.fromhex('ffe3b9fe')),       # sqlite init: open all DBs, then cap page caches
         0x0191B9F0: ('hook_taperase', bytes.fromhex('09e38cc8')),       # clipboard cmd 4 (erase tape): only chunks with clips
         0x019F0A2A: ('hook_clipsvc', bytes.fromhex('f9e39b55')),         # main loop: CALL audio_clipboard_service -> + tape edit after events
         0x0191B65A: ('hook_clipdrop', bytes.fromhex('02e3490b')),        # clipboard cmd 0 (drop): CALL tape_clips_add -> before event
         0x0191B730: ('hook_clipdropall', bytes.fromhex('02e3de0a')),     # clipboard cmd 1 (drop all): first CALL tape_clips_add -> before event
         0x0191B89C: ('hook_cliplift', bytes.fromhex('09e3e0c7')),        # clipboard cmd 2 (lift): CALL lift -> before event
         0x0191B974: ('hook_cliplftall', bytes.fromhex('09e308c8')),      # clipboard cmd 3 (lift all): CALL lift all -> before event
         0x01A56F24: ('hook_split1', bytes.fromhex('f8e33c30')),          # scissors: CALL tape_clips_split -> split events
         0x01A57690: ('hook_split2', bytes.fromhex('f8e3862c')),          # Shift+lift loop: CALL tape_clips_split (loop in) -> split events
         0x01A5769C: ('hook_split3', bytes.fromhex('f8e3802c')),          # Shift+lift loop: CALL tape_clips_split (loop out) -> split events
         0x01A577C6: ('hook_join', bytes.fromhex('f8e31130')),            # Shift+scissors: CALL tape_clips_join -> join events
         0x01A5828A: ('hook_recadd1', bytes.fromhex('f8e33125')),         # set_mode, record end: CALL tape_clips_add -> rec events
         0x01A5830C: ('hook_recadd2', bytes.fromhex('f8e3f024')),         # set_mode, record end: CALL tape_clips_add -> rec events
         0x01A5838E: ('hook_recadd3', bytes.fromhex('f8e3af24')),         # set_mode, record end: CALL tape_clips_add -> rec events
         0x01A58432: ('hook_recadd4', bytes.fromhex('f8e35d24')),         # set_mode, record end: CALL tape_clips_add -> rec events
         0x01A5857E: ('hook_recadd5', bytes.fromhex('f8e3b723')),         # set_mode, record end: CALL tape_clips_add -> rec events
         0x01A584D0: ('hook_recstart', bytes.fromhex('ffe3a6e3')),        # set_mode, into recording: CALL tape_record_extent_reset -> REC before
         0x01A54842: ('hook_tapewrite', bytes.fromhex('02e3a12b')),       # tape cache writeback: CALL yaffs_write -> OP1_EV_TAPE_WRITE
         0x01A5478C: ('hook_taperead', bytes.fromhex('02e3822a')),        # tape cache load (4 tracks): CALL yaffs_read -> STEFAN's chunk-read mask
         0x01964336: ('hook_disk1', bytes.fromhex('01e37b98')),           # COM: CALL disk_mode_toggle -> flush the tape cache before disk mode
         0x0196443E: ('hook_disk2', bytes.fromhex('01e3f797')),           # COM: CALL disk_mode_toggle -> flush first
         0x01964616: ('hook_disk3', bytes.fromhex('01e30b97')),           # COM: CALL disk_mode_toggle -> flush first
         0x01964CFE: ('hook_disk4', bytes.fromhex('01e39793')),           # COM: CALL disk_mode_toggle (T3) -> flush first
         0x019F0A3C: ('hook_savesvc', bytes.fromhex('fde32ae3')),         # main loop: CALL global hold-to-save pass -> snapshot save hook
         0x019AD220: ('hook_stampsyn', bytes.fromhex('07e3f27d')),        # synth snapshot: CALL snprintf (date stamp) -> feature's name
         0x019AD5A6: ('hook_stampdrm', bytes.fromhex('07e32f7c')),        # drum snapshot: CALL snprintf (date stamp) -> feature's name
         0x01A85750: ('hook_vcdown', bytes.fromhex('00e80400')),         # VoiceCtl key_down entry (LINK): note input observers
         0x01A85840: ('hook_vcup', bytes.fromhex('00e80800')),           # VoiceCtl key_up entry (LINK): note input observers
         0x01A5CFA8: ('hook_tapepre', bytes.fromhex('ffe3c0fb')),        # tape draw: CALL recording state -> tape pre_draw
         0x01A54D5C: ('hook_tlookup', bytes.fromhex('00e80000')),        # tape_c chunk lookup entry (LINK 0): tape lookup owner
         0x019E193C: ('hook_altin', bytes.fromhex('00e80000')),          # audio callback's USB-in buffer fill entry (LINK 0): no re-clear of a zero buffer (hook.S)
         0x01A044A8: ('hook_dpkeep', bytes.fromhex('fde38ccc')),         # parse_patch_json: keep "op1r" (drum+, docs/31)
         0x01977900: ('hook_dpbrowse', bytes.fromhex('04e37f53')),       # DrumController Shift+T1: start row (user kit -> DRUM, drum+ -> DRUM+)
         0x01A04BC0: ('hook_dpload', bytes.fromhex('ffe3f4f5')),         # load_drum_patch: parse, then read drum+ pads
         0x019C9D04: ('hook_frsnap', bytes.fromhex('09e11e59')),         # LFO/seq tick (after tape_play_mix) -> fr_snap (FX2 routing)
         0x01995680: ('hook_pparse1', bytes.fromhex('03e39470')),  # insert_user_patch: shared sound repair
         0x0199F210: ('hook_pparse2', bytes.fromhex('03e3cc22')),  # drum preset import
         0x0199FA4E: ('hook_pparse3', bytes.fromhex('03e3ad1e')),  # synth preset import
         0x01A051F8: ('hook_synthload', bytes.fromhex('ffe3d8f2')),      # synth slot loader: parse, on failure reset FX/LFO (kn_patch_safe.c)
         0x01A05984: ('hook_smpover', bytes.fromhex('00e1301e')),        # preset loader, user sampler over the limit: R0.L = panic text -> skip the row (kn_sampler_guard.c)
         0x0199DD7A: ('hook_diskprobe', bytes.fromhex('07e33ddd')),      # disk-mode export, sampler row: CALL yaffs_open (existence check, never closed) -> closed (kn_sampler_guard.c)
         0x01A69730: ('hook_usbbuf1', bytes.fromhex('22e11401')),        # EP 0x86 transfer buffer 0x114 -> 828
         0x01A69740: ('hook_usbbuf2', bytes.fromhex('22e11401'))}        # .. second buffer
# exact GUI frame skip (screens/guiskip.c, from op1r-src 59; ARCHITECTURE.md "Gfx frames"): on by default; KN_GUISKIP=0
# leaves the hooks out and builds guiskip.c without GS_ON (stock drawing; kn_gfx_frame's gs_frame is then R246's
# clear), KN_GUISKIP_VERIFY=1 adds op1r's GS_VERIFY self-check. op1r's hook_gsframe (0x01A3BBE0) is kennel's
# hook_gfxframe above.
_SW = bytes.fromhex('09e1b45549e1a0ff')                                       # P1 = agg_sweep_scanlines
GUISKIP_HOOKS = {0x019149C4: ('hook_gsmove', bytes.fromhex('00e80000')),      # rasterizer move_to entry (LINK 0)
                 0x01914904: ('hook_gsline', bytes.fromhex('00e80000')),      # rasterizer line_to entry (LINK 0)
                 0x01A6259C: ('hook_gstext', bytes.fromhex('00e80900')),      # Text::draw entry (LINK 0x24)
                 0x01A2357A: ('hook_gsdim', bytes.fromhex('0032e505')),       # Raster::dim_all entry
                 0x01A22F3C: ('hook_gsfade', bytes.fromhex('0032e505')),      # Raster::fade entry (help's animated fade; op1r 8dd28bb)
                 0x01A24CBC: ('hook_gsdot', bytes.fromhex('00e80600')),       # Raster::dotted_hline entry (LINK 0x18)
                 0x01A24CA6: ('hook_gssw1', _SW), 0x01A254DC: ('hook_gssw2', _SW), 0x01A27316: ('hook_gssw3', _SW),
                 0x01A2749A: ('hook_gssw4', _SW), 0x01A274FE: ('hook_gssw5', _SW),
                 0x019B5A1E: ('hook_gsdna', bytes.fromhex('ffe3fbe5')),       # kennel: DNA page (screen_id_draw): CALL raster getter 0x019B2614
                 0x01A62726: ('hook_gsglyph', bytes.fromhex('09e14c8949e1a0ff'))}  # kennel: Text::draw: P1 = text sweep 0xFFA0894C (tape cache)
def guiskip():
    """KN_GUISKIP unset / 1: the frame skip (default); 0: off. KN_GUISKIP_VERIFY=1: the self-check (test builds)."""
    v, w = os.environ.get('KN_GUISKIP', '1'), os.environ.get('KN_GUISKIP_VERIFY', '')
    if v not in ('', '0', '1') or w not in ('', '0', '1'):
        raise SystemExit(f'KN_GUISKIP / KN_GUISKIP_VERIFY must be 0 or 1, not {v!r} / {w!r}')
    return v != '0', w == '1'
if guiskip()[0]:
    HOOKS.update(GUISKIP_HOOKS)
# data words: address -> (symbol, expected original value)
DATA_PATCHES = {0x018F7FF8: ('fx_screen_case5', 0x01A3BF26),          # ScreenId::for_fx case 5
                0x018F8074: ('synth_screen_case14', 0x01A3BFD0),      # ScreenId::for_synth case 14
                0x018F80F8: ('lfo_screen_case4', 0x01A3C078),         # ScreenId::for_lfo case 4 (midi)
                0x01910840: ('ql_vt_synth', 0x019CCE68),              # LfoMidi synth vtable: apply
                0x01910860: ('ql_vt_drum', 0x019CD048),               # LfoMidi drum vtable (0x0191084C): apply
                0x01910880: ('ql_vt_fx', 0x019CD104),                 # LfoMidi FX vtable (0x0191086C): apply
                0x01910848: ('kn_lfo_trig_synth', 0x019CCE30),        # LfoMidi synth vtable +0x1c: note-on trigger (RTS)
                0x01910868: ('kn_lfo_trig_drum', 0x019CCE2E),         # LfoMidi drum vtable +0x1c (RTS)
                0x01910888: ('kn_lfo_trig_fx', 0x019CCE2C),           # LfoMidi FX vtable +0x1c (RTS)
                0x01911B98: ('sm_idle_run', 0x01A5E240),              # kTE_Idle vtable run: remember thread (sysmon)
                0x0190F718: ('kn_cc_com_knob', 0x01962D30),           # com_controller on_encoder: OP-1 tab Shift + green / white / red (kennel/kn_ccmap.c)
                0x0190F750: ('kn_cc_com_draw', 0x019655E0),           # ComScreen update: + KEYS / PARAM CH, FEEDBACK in the MIDI CH panel
                0x019106F8: ('kn_lfo_bypass', 0x019C9780),            # lfo_bypass slot 2: "LFO OFF" up? not on an engine's T4 page (kennel/kn_eng_hooks.c)
                0x01911B78: ('tm_screen_draw', 0x01A5CF94)}           # tape screen draw: + markers (tape/markers.c)              # kTE_Idle vtable run: remember thread (sysmon)
# 32-bit immediates loaded as Rx.L = lo; Rx.H = hi (two 4-byte instructions): address -> (symbol, original value)
IMM_PATCHES = {0x0191AB52: ('sm_audio_cb', 0xFFA04804)}             # audio::init: DMA callback = audio render (sysmon)
# The same, in the encrypted L1 image. These patches are precomputed: public builds replay the byte differences in
# l1_patches.json; an optional patch-regeneration helper can refresh them. Their targets
# are the fixed L1 vector entries (hook.S .l1vec at CODE_BASE), so plugins and other code can change freely.
L1_IMM_PATCHES = {0xFFA01018: ('l1v_metro', 0x019DE548),             # audio callback: metronome render (count-in, accent)
                  0xFFA049FC: ('l1v_push_lr', 0x019E1B3C),           # audio callback: push master L/R to USB (+ tracks)
                  0xFFA0487C: ('l1v_push_interleaved', 0x019E1A88)}  # .. muted output: silent block (+ silent tracks)
L1_VECTOR = ['l1v_metro', 'l1v_push_lr', 'l1v_push_interleaved', 'l1v_rs_probe']   # hook.S order: CODE_BASE + 4 * i
L1_PATCHES_JSON = os.path.join(HERE, 'l1_patches.json')
# L1 call-outs: replace `n` original bytes at addr by  P1.L = sym; P1.H = sym; CALL (P1); NOP...  (the target must
# redo what the replaced instructions did; written in asm in hook.S)
L1_CALLS = {0xFFA0619A: ('l1v_rs_probe', bytes.fromhex('09e1dc2949e180ff0ae154214ae180ff'))}   # tape resampler prologue
#            (P1 = 0xFF8029DC; P2 = 0xFF802154) -> track-out resampling (screens/usbtrack.c), sets P1 / P2
# pc-relative CALLs in L1 to the trampolines in the free end of L1 (.l1tramp, plain LDR block at L1_TRAMP)
L1_PCCALLS = {0xFFA0709C: ('l1_tramp_fwd', bytes.fromhex('06c41000')),   # mix loop 1: R0 = MAX (R2, R0) (V)
              0xFFA0712C: ('l1_tramp_rev', bytes.fromhex('06c40100')),   # mix loop 2: R0 = MAX (R0, R1) (V)
              0xFFA01202: ('l1_tramp_mfx', bytes.fromhex('09e168ad'))}   # output stage, after the master EQ, before the
                                                                         # master FX pointer test: P1.L = 0xad68 (kn_declick.c gap)
L1_TRAMP, L1_TRAMP_MAX = 0xFFA0BFB4, 0xFFA0C000 - 0xFFA0BFB4
# STEFAN (tape/tm_on.c): written by DTEST only while it is on, never at boot and never into the LDR, so not in
# L1_PCCALLS / l1_patches.json. Listed here for the collision check: its block over R246's game-mode range and its
# three CALL pokes (each inside one 8-byte DTEST block: written atomically while audio runs).
STEFAN_L1, STEFAN_L1_ROOM = 0xFFA01D60, 0xFFA020A8 - 0xFFA01D60
STEFAN_POKES = {0xFFA0217A: ('tm_l1_rec', bytes.fromhex('00e3dd20')),      # CALL tape_record_block -> tm_rec_entry
                0xFFA02DCA: ('tm_l1_rec', bytes.fromhex('00e3b51a')),      # .. the other call site
                0xFFA06E04: ('tm_l1_tpskip', bytes.fromhex('30e41a00'))}   # tape_play_mix gather head: R0 = [SP + 0x68]
assert all((a & 7) + len(o) <= 8 for a, (_, o) in STEFAN_POKES.items())
# KN_L1_RUNTIME (default 1): the encrypted L1 blocks stay as TE built them and kennel/kn_l1rt.c writes the pokes above
# at boot through DTEST (build/kn_l1rt_table.c: address, kind, target symbol, original bytes; no keys, no recorded
# byte differences). KN_L1_RUNTIME=0: the old path, the pokes in the encrypted LDR blocks (l1_patches.json "ops",
# regenerated with the optional regeneration helper), kept until the runtime path is proven on the unit.
L1_RUNTIME = os.environ.get('KN_L1_RUNTIME', '1') != '0'
DEC_ADDR, DEC_ROOM = 0xFFA005D4, 176                  # R246's core_decimate_2to1: kennel/kn_dec.c (kn_dec.h KN_DEC_ADDR / ROOM)

def l1_runtime_rows():
    """(addr, kind, symbol, original bytes) of every L1 poke, in apply_l1's order; kinds as kennel/kn_l1rt.h"""
    rows = []
    for addr, (sym, orig) in L1_CALLS.items():
        rows.append((addr, 'KN_L1RT_CALL', sym, orig))
    for addr, (sym, orig) in L1_PCCALLS.items():
        rows.append((addr, 'KN_L1RT_PCCALL', sym, orig))
    for addr, (sym, orig) in L1_IMM_PATCHES.items():
        rows.append((addr + 2, 'KN_L1RT_IMM_LO', sym, struct.pack('<H', orig & 0xFFFF)))
        rows.append((addr + 6, 'KN_L1RT_IMM_HI', sym, struct.pack('<H', orig >> 16)))
    return rows

def write_l1_runtime_table():
    """build/kn_l1rt_table.c for kennel/kn_l1rt.c; empty in LDR mode (the LDR already carries the pokes)"""
    rows = l1_runtime_rows() if L1_RUNTIME else []
    out = ['/* generated by make_firmware.py: the L1 pokes kennel/kn_l1rt.c writes at boot (KN_L1_RUNTIME) */',
           '#include "../kennel/kn_l1rt.h"']
    out += [f'extern char {sym}[];' for sym in sorted({r[2] for r in rows})]
    out.append('const kn_l1rt_poke_t kn_l1rt_pokes[] = {')
    for addr, kind, sym, orig in rows:
        assert 0xFFA00000 <= addr and addr + len(orig) <= 0xFFA0C000 and len(orig) <= 16
        out.append(f'    {{ {addr:#010x}, (uint32_t){sym}, {len(orig)}, {kind}, '
                   f'{{ {", ".join(f"{b:#04x}" for b in orig)} }} }},')
    if not rows:
        out.append('    { 0, 0, 0, 0, { 0 } },')
    out += ['};', f'const unsigned kn_l1rt_npokes = {len(rows)};',
            f'const unsigned kn_l1rt_runtime = {1 if L1_RUNTIME else 0};   /* kennel/kn_dec.c: write the decimator by DTEST */']
    open(os.path.join(HERE, 'build', 'kn_l1rt_table.c'), 'w').write('\n'.join(out) + '\n')
FX_SCREEN_SVG = 'fxgeneric.svg'
QUAD_LFO_SVG = 'display/quadlfo.svg'
POND_LFO_SVG = 'display/pondlfo.svg'
EUCLID_SVG = 'display/euclid.svg'
DOTS_SVG = 'display/dots.svg'
ORACLE_SVG = 'display/oracle.svg'
PEAL_SVG = 'display/peal.svg'
SYSMON_SVG = 'display/sysmon.svg'
USBOUT_SVG = 'display/usbout.svg'
ITERLAB_SVG = 'display/iterlab.svg'   # stock iter screen (op1repacker iter-lab.svg, MIT)
# quad LFO defaults (lfo/quadlfo.c: 128-bit stream, LFO i at bit 30 i: rate 6 | sync 1 | wave 3 | smooth 3 | offset 3 |
# type 3 | target 5 | amount+32 6; marker 0xA5 in bits 120..127): ~0.3 / 1 / 3 / 8 Hz, sine, amount 0, VOIC, knobs b..r
def quad_words(lfos):
    bits = 0
    for i, (rate, tgt) in enumerate(lfos):
        bits |= (rate | tgt << 19 | 32 << 24) << (30 * i)
    bits |= 0xA5 << 120
    return [((bits >> (16 * k)) & 0xFFFF) - (0x10000 if (bits >> (16 * k)) & 0x8000 else 0) for k in range(8)]
QUAD_LFO_DEFAULTS = quad_words([(19, 0), (31, 1), (42, 2), (54, 3)])
# pond LFO (lfo/ql_pond.h pond_put; op1r-src f2aed5d): rate 31 (~1 Hz), chaos 24 (s ~ 1.0), free, species 1..4 -> knobs
# b g w r, amounts 0 (+32); marker 0xA7 in bits 120..127
def pond_words(rate=31, chaos=24):
    bits = rate | chaos << 8 | 0xA7 << 120
    for k in range(4): bits |= k << (13 + 11 * k) | 32 << (18 + 11 * k)
    return [((bits >> (16 * k)) & 0xFFFF) - (0x10000 if (bits >> (16 * k)) & 0x8000 else 0) for k in range(8)]
POND_LFO_DEFAULTS = pond_words()
# optional: hidden OP-Z controller mode, gated by host-mode SysEx 00 01 03 (docs/12_opz_mode_patch.md)
DEV_HOOKS = {0x019F01B8: ('hook_devboot', bytes.fromhex('05e37c52')),   # boot: access(te-boot.op1) -> apply a staged dev update first (docs/35)
             0x019E3CC8: ('hook_devrx', bytes.fromhex('ffe36efa'))}    # midi_poll: CALL midi_rx_parse -> copy our SysEx first
OPZ_HOOKS = {0x019E0CFC: ('hook_opzget', bytes.fromhex('00601000')),   # midi_opz_mode_enabled: R0=0; RTS
             0x019E3540: ('hook_opzset', bytes.fromhex('a5e60900'))}   # rx host-mode m!=1,2: B[P4+9]=R5

def sh(cmd):
    print('$', cmd); subprocess.run(cmd, shell=True, check=True)

def by_order(lst):
    """plugins indexed by order: [None (0 = stock), plugin with order 1 or None, ...] up to the highest order"""
    out = [None] * (max([e['order'] for e in lst], default=0) + 1)
    for e in lst:
        out[e['order']] = e
    return out

def builtin(lst):
    """plugins compiled into the core; \"loadable\": true ones ship as content/<name>.knl (kennel loader)"""
    return [e for e in lst if not e.get('loadable')]

def gen_table(engs, fxs):
    # every table is indexed by order (the number stored in patches); unused orders are 0 (stock iter / filter).
    # Writable, MAX_ORDER + 1 entries: the kennel loader (kennel/kn_boot.c) registers plugin files into the gaps.
    engs_all, fxs_all = engs, fxs
    engs, fxs = builtin(engs), builtin(fxs)
    eo, fo = by_order(engs), by_order(fxs)
    eo += [None] * (MAX_ORDER + 1 - len(eo)); fo += [None] * (MAX_ORDER + 1 - len(fo))
    lines = ['#include "op1_synth.h"']
    lines += [f'extern const op1_engine_t {e["symbol"]};' for e in engs]
    lines.append('const op1_engine_t *op1_engines[] = { 0' +
                 ''.join(', &' + e['symbol'] if e else ', 0' for e in eo[1:]) + ' };')
    lines.append(f'const int op1_engine_count = {len(eo)};')
    lines.append('const char *op1_engine_names[] = { ' +
                 ''.join(json.dumps(e['name'] if e else '') + ', ' for e in eo[1:]) + '0 };')
    lines.append('uint8_t op1_engine_coarse[OP1_SLOTS] = { 0' +    # by order: knobs (bit k) in 8 steps ("coarse")
                 ''.join(f', {sum(1 << k for k in e.get("coarse", []))}' if e else ', 0' for e in eo[1:]) + ' };')
    lines.append(f'const char *op1_sample_engine_names[{MAX_ORDER + 1}] = {{ ' +
                 ''.join(json.dumps(e['name']) + ', ' for e in engs if e.get('uses_sample')) + '0 };')
    lines += [f'extern const op1_screen_t {e["screen"]["symbol"]};' for e in engs if e.get('screen')]
    lines.append('const op1_screen_t *op1_engine_screens[] = { 0' +
                 ''.join(', &' + e['screen']['symbol'] if e and e.get('screen') else ', 0' for e in eo[1:]) + ' };')
    lines.append('const char *op1_engine_svgs[] = { 0' +
                 ''.join(', ' + json.dumps(os.path.basename(e['screen']['svg'])) if e and e.get('screen') else ', 0'
                         for e in eo[1:]) + ' };')
    lines += [f'extern const {"op1_fx_stereo_t" if f.get("stereo") else "op1_fx_t"} {f["symbol"]};' for f in fxs]
    lines += [f'extern const op1_screen_t {f["screen"]["symbol"]};' for f in fxs if f.get('screen')]
    lines.append('const op1_screen_t *op1_fx_screens[] = { 0' +
                 ''.join(', &' + f['screen']['symbol'] if f and f.get('screen') else ', 0' for f in fo[1:]) + ' };')
    lines.append('const char *op1_fx_svgs[] = { 0' +
                 ''.join(', ' + json.dumps(os.path.basename(f['screen']['svg'])) if f and f.get('screen') else ', 0'
                         for f in fo[1:]) + ' };')
    lines.append('const op1_fx_t *op1_fxs[] = { 0' + ''.join(', &' + f['symbol'] + ('.mono' if f.get('stereo') else '') if f else ', 0' for f in fo[1:]) + ' };')
    lines.append('op1_fx_stereo_render_t op1_fx_stereo_renders[OP1_SLOTS];')
    lines.append('void op1_fx_stereo_init(void) {')
    lines.append('  for (int i = 0; i < OP1_SLOTS; i++) op1_fx_stereo_renders[i] = 0;')
    for f in fxs:
        if f.get('stereo'):
            lines.append(f'  op1_fx_stereo_renders[{f["order"]}] = {f["symbol"]}.render_stereo;')
    lines.append('}')
    lines.append(f'const int op1_fx_count = {len(fo)};')
    lines.append('const char *op1_fx_order_names[] = { ' +          # by order - 1, "" for unused orders
                 ''.join(json.dumps(f['name'] if f else '') + ', ' for f in fo[1:]) + '0 };')
    lines.append(f'const char *op1_fx_names[{MAX_ORDER + 1}] = {{ ' +
                 ''.join(json.dumps(f['name']) + ', ' for f in fxs) + '0 };')
    drums = [f for f in plugins.load_features() if f.get('drum_synth')]
    if len(drums) > 4:
        raise ValueError('At most four native drum synth providers are supported')
    lines.append('const char *const kn_drum_synth_names[] = {' + ''.join(json.dumps(f['name']) + ',' for f in drums) + '0};')
    lines.append('const char *const kn_drum_synth_state_keys[] = {' + ''.join(json.dumps(f['drum_synth']['state_key']) + ',' for f in drums) + '0};')
    # kennel/kn_artcache.c: allocate the static-art cache when compiled-in code calls op1_screen_draw_cached (loaded
    # files that import it are found by the loader)
    def calls_cache(e):
        return any('op1_screen_draw_cached' in open(os.path.join(HERE, x), errors='replace').read()
                   for x in ([e['source']] if e.get('source') else []) + e.get('extra_sources', [])
                   if os.path.exists(os.path.join(HERE, x)))
    users = [e['name'] for e in engs + fxs + builtin(plugins.load_features()) if calls_cache(e)]
    lines.append(f'const uint8_t kn_artcache_builtin = {1 if users else 0};' + (f'   /* {", ".join(users)} */' if users else ''))
    # our factory-DB rows the core keeps right at boot (kennel/kn_core_rows.h, kn_boot.c kn_rows_finish)
    own = core_owned(engs_all, fxs_all, plugins.load_features())
    for k in ('synth', 'fx', 'seq'):
        lines.append(f'const char *const kn_own_{k}[] = {{' + ''.join(json.dumps(n) + ',' for n in own[k]) + '0};')
    lines.append(f'const char kn_row_iter[] = {json.dumps(ITER_PARAMS)};')
    lines.append(f'const char kn_row_filter[] = {json.dumps(FILTER_ROW[2])};')
    lines.append(f'const int kn_row_filter_id = {FILTER_ROW[0]};')
    lines.append(f'const char kn_row_quad[] = {json.dumps(json.dumps(QUAD_LFO_DEFAULTS))};')
    lines.append(f'const char kn_row_pond[] = {json.dumps(json.dumps(POND_LFO_DEFAULTS))};')
    lines.append(f'const char kn_row_drum[] = {json.dumps(DRUM_PARAMS)};')
    with open(os.path.join(HERE, 'build', 'engines_table.c'), 'w') as output:
        output.write('\n'.join(lines) + '\n')

def drum_synth_preparation():
    import importlib.util
    spec = importlib.util.spec_from_file_location('kennel_gin_prepare', os.path.join(HERE, 'plugins/gin/prepare.py'))
    preparation = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preparation)
    return preparation

def kn_diag():
    """KN_DIAG=1 in the environment: the test build, with monitor page 7 and the diagnostic core (kn_diag.c, the L1 audio
    stack kn_astack.c, the k1b / ic / stk / cdp switches). Unset, empty or 0: the release build, where all of that is
    compiled out (ARCHITECTURE.md "Release and test builds"). tools/kennel/pack.py reads the same variable for the
    plugin files (sysmon.knl's page 7)."""
    v = os.environ.get('KN_DIAG', '')
    if v not in ('', '0', '1'):
        raise SystemExit(f'KN_DIAG must be 0 or 1, not {v!r}')
    return v == '1'

# test build only (KN_DIAG=1): heap 0's low-water mark (kennel/kn_diag.c kd_h0_malloc, ARCHITECTURE.md "Heap 0
# low-water mark"). heap_malloc(heap, size) 0x01AA0318, which malloc, calloc, realloc and VDK's L1 allocations all call.
DIAG_HOOKS = {0x01AA0318: ('hook_h0malloc', bytes.fromhex('00e80000'))}   # heap_malloc entry (LINK 0) -> kd_h0_stub
if kn_diag():
    HOOKS.update(DIAG_HOOKS)

def kn_flag(name, default):
    """KN_CRASHTEST=1: the crash-test core (HELP crashes: an undefined instruction, kennel/kn_crash.c;
    Shift+HELP hangs with interrupts off, kennel/kn_wdog.c); KN_WDOG=0: the
    hang detector never arms (kennel/kn_wdog.c). The release build has KN_CRASHTEST unset and KN_WDOG unset or 1. The
    root builder keys its caches on both (op1r_plugins.kennel_gfx_flags)."""
    v = os.environ.get(name, default)
    if v not in ('0', '1'):
        raise SystemExit(f'{name} must be 0 or 1, not {v!r}')
    return v == '1'

def build(engs, fxs):
    drum_synth_preparation().prepare(HERE, SRC_FW, HOOKS)
    os.makedirs(os.path.join(HERE, 'build'), exist_ok=True)
    gen_table(engs, fxs)
    write_l1_runtime_table()
    engs, fxs = builtin(engs), builtin(fxs)
    diag = kn_diag()                                               # test build: page 7's diagnostic core (kn_diag, kn_astack)
    srcs = ['dispatcher.c', 'build/engines_table.c', 'kennel/kn_lfo.c', 'kennel/kn_lfo_rec.c', 'screens/iterlab.c', 'screens/sysmon_core.c', 'screens/usbtrack.c', 'screens/settings_store.c', 'kennel/kn_tape.c', 'kennel/kn_tapesvc.c', 'kennel/kn_tapes.c', 'screens/sampedit.c', 'screens/fxroute.c', 'screens/mlfo.c', 'screens/mixaux.c', 'drumplus/dp_voice.c', 'drumplus/dp_plus.c', 'drumplus/dp_fw.c', 'drumplus/dp_ui.c', 'devupd/du.c', 'devupd/du_preset.c', 'devupd/du_fw.c', 'kennel/kn_presets.c', 'screens/duprompt.c', 'kennel/kn_load.c', 'kennel/kn_boot.c', 'kennel/kn_exports.c', 'kennel/kn_features.c', 'kennel/kn_pages.c', 'screens/soon.c', 'plugload/op1p_load.c', 'kennel/kn_core.c', 'kennel/kn_screens.c', 'kennel/kn_artcache.c', 'kennel/kn_gfx.c', 'screens/guiskip.c', 'screens/tapecache.c', 'kennel/kn_settings.c', 'kennel/kn_setpage.c', 'kennel/kn_inv.c', 'kennel/kn_text.c', 'kennel/kn_save.c', 'kennel/kn_preset_tools.c', 'kennel/kn_storage.c', 'kennel/kn_flash.c', 'kennel/kn_midi.c', 'kennel/kn_mx.c', 'kennel/kn_ccmap.c', 'kennel/kn_sampler.c', 'kennel/kn_clips.c', 'kennel/kn_files.c', 'kennel/kn_seq.c', 'kennel/kn_patch_safe.c', 'kennel/kn_patch_sql.c', 'bgsave.c'] + [s for e in engs for s in [e['source']] + e.get('extra_sources', [])] + [s for f in fxs for s in [f['source']] + f.get('extra_sources', [])]
    srcs = [s for s in srcs if not s.startswith('drumplus/')] + ['kennel/kn_drum.c']   # drum+: plugins/drumplus (feature)
    srcs += ['kennel/kn_drum_synth.c', 'kennel/kn_input.c', 'kennel/kn_eng_hooks.c', 'kennel/kn_bus.c', 'kennel/kn_validate.c', 'kennel/kn_sound.c', 'kennel/kn_shed.c', 'kennel/kn_tombola.c', 'kennel/kn_declick.c', *(['kennel/kn_diag.c', 'kennel/kn_astack.c'] if diag else []), 'kennel/kn_l1.c', 'f3/him_f3.c', 'f3/him_f3_fill.c', 'f3/him_f3_trace.c', 'kennel/kn_l1rt.c', 'build/kn_l1rt_table.c', 'kennel/kn_dec.c', 'kennel/kn_sampler_guard.c', 'kennel/kn_boottime.c', 'kennel/kn_preset_store.c', 'kennel/kn_lzscr.c', 'kennel/kn_svgvar.c', 'kennel/kn_keys.c', 'kennel/kn_midiout.c', 'kennel/kn_wdog.c', 'kennel/kn_crash.c', 'samplerplus/sp_core.c', 'screens/sbrowse.c']
    print(f'kennel core: {"test build (KN_DIAG=1, monitor page 7)" if diag else "release build (no page 7)"}'
          f'; frame skip {"on" if guiskip()[0] else "off (KN_GUISKIP=0)"}{" + GS_VERIFY" if all(guiskip()) else ""}')
    srcs += [s for f in builtin(plugins.load_features()) for s in [f['source']] + f.get('extra_sources', [])]
    sys.path.insert(0, os.path.join(os.environ.get('KENNEL_ROOT', os.path.dirname(HERE)), 'tools', 'kennel'))
    import pack as _pack                         # compiled-in features' plugin.json "settings" (kennel/kn_setpage.c)
    open(os.path.join(HERE, 'build', 'kn_settings_builtin.c'), 'w').write(_pack.settings_c(builtin(plugins.load_features())))
    srcs += ['build/kn_settings_builtin.c']
    bridge = 'op' + 'us'                         # the plugin bridge's folder (its name only there: harness/names_check.py ALLOW_DIRS)
    srcs += sorted(f'{bridge}/{n}' for n in os.listdir(os.path.join(HERE, bridge)) if n.endswith('.c'))
    accel = f'{bridge}/accel'                    # the bridge's accelerators (kennel's kernels for known files): C and assembly
    srcs += sorted(f'{accel}/{n}' for n in os.listdir(os.path.join(HERE, accel)) if n.endswith('.c'))
    accel_asm = sorted(f'{accel}/{n}' for n in os.listdir(os.path.join(HERE, accel)) if n.endswith('.S'))
    srcs += ['tape/tm.c', 'tape/tm_on.c', 'screens/tfscreen.c']                          # STEFAN (last: its .bss / .farbss after everything else)
    srcs += ['dsp/coop/coop_fast.c']   # coop-fw's stock DSP switches and counters (its .data goes to link.ld .coop)
    objs = []
    cmds = []
    for s in srcs:
        o = 'build/' + s.replace('/', '_').replace('.c', '.o'); objs.append(o)
        extra = ''
        if s in ('screens/guiskip.c', 'screens/tapecache.c'):                               # the frame skip (+ self-check): make_firmware guiskip()
            gs_on, gs_verify = guiskip()
            extra = (' -DGS_ON' if gs_on else '') + (' -DGS_VERIFY' if gs_on and gs_verify else '')
        if s.startswith('f3/him_f3'):                       # facet3d: as the plugin builds had it (no memset calls)
            extra = ' -fno-tree-loop-distribute-patterns -DF3_CORE'
        if s == 'kennel/kn_lzscr.c' and os.environ.get('KN_LZ_NOBG', '') == '1':   # test build: no background parsing
            extra = ' -DKN_LZ_NOBG'
        if s == 'dispatcher.c' and kn_flag('KN_CRASHTEST', '0'):   # test build: HELP crashes (kennel/kn_crash.c)
            extra = ' -DKN_CRASH_TEST'
        if s == 'kennel/kn_wdog.c' and not kn_flag('KN_WDOG', '1'):   # test build: the hang detector never arms
            extra = ' -DKN_WDOG_OFF'
        cmds.append(f'bfin-elf-gcc -O2 -mcpu=bf524 -ffreestanding -fno-builtin -nostdlib -fno-common '
                    f'-Wall{" -DKN_DIAG=1" if diag else ""}{extra} -I. -c {s} -o {o}')
    cmds.append('bfin-elf-as -mcpu=bf524 kennel/kn_input.S -o build/kn_input_entry.o'); objs.append('build/kn_input_entry.o')
    cmds.append('bfin-elf-gcc -mcpu=bf524 -c kennel/kn_dec_l1.S -o build/kn_dec_l1.o'); objs.append('build/kn_dec_l1.o')   # the decimator for L1 (kennel/kn_dec.c)
    cmds.append('bfin-elf-gcc -mcpu=bf524 -c screens/tr_rs.S -o build/tr_rs.o'); objs.append('build/tr_rs.o')   # track outs: two tracks per dual MAC (screens/usbtrack.c)
    cmds.append('bfin-elf-as -mcpu=bf524 -I build kennel/kn_drum_synth.S -o build/kn_drum_synth_entry.o'); objs.append('build/kn_drum_synth_entry.o')
    cmds.append('bfin-elf-as -mcpu=bf524 kennel/kn_wdog_nmi.S -o build/kn_wdog_nmi.o'); objs.append('build/kn_wdog_nmi.o')   # the hang detector's NMI
    cmds.append('bfin-elf-as -mcpu=bf524 hook.S -o build/hook.o'); objs.append('build/hook.o')
    for s in accel_asm:                          # the accelerators' kernels (preprocessed: oa.h picks them)
        o = 'build/' + s.replace('/', '_').replace('.S', '.o'); objs.append(o)
        cmds.append(f'bfin-elf-gcc -mcpu=bf524 -I. -c {s} -o {o}')
    cmds.append('bfin-elf-gcc -mcpu=bf524 -c tape/tm_l1.S -o build/tm_l1.o'); objs.append('build/tm_l1.o')   # STEFAN's L1 block (tape/tm_on.c)
    for n in ('dsynth', 'cwo', 'punch', 'phone', 'nitro', 'grid', 'spring', 'delay', 'phase'):   # coop-fw's rewrites
        o = f'build/coop_{n}_fast.o'; objs.append(o)          # (dsp/coop; run counters on, CHECK sub-path counters off)
        cmds.append(f'bfin-elf-gcc -mcpu=bf524 -DOP1R_COOP_HITS -c dsp/coop/{n}_fast.S -o {o}')
    for o in [f'build/coop_{n}_fast.o' for n in ('dsynth', 'cwo', 'punch', 'phone', 'nitro', 'grid', 'spring', 'delay', 'phase')] + ['build/dsp_coop_coop_fast.o']:
        cmds.append(f'bfin-elf-objcopy --rename-section .text=.kn_coop --rename-section .near=.kn_coop '
                    f'--rename-section .data=.kn_coop {o}')                       # after STEFAN (link.ld .coop)
    for o in ('build/tape_tm.o', 'build/tape_tm_on.o', 'build/screens_tfscreen.o'):                # STEFAN after the rest of the image (link.ld .stefan)
        cmds.append(f'bfin-elf-objcopy --rename-section .text=.kn_stefan --rename-section .rodata=.kn_stefan '
                    f'--rename-section .data=.kn_stefan {o}')
    cmds.append(f'bfin-elf-ld -T link.ld {" ".join(objs)} $(bfin-elf-gcc -print-libgcc-file-name) -o build/synth.elf')
    cmds.append('bfin-elf-objcopy -O binary -j .text -j .rodata -j .data -j .stefan -j .coop build/synth.elf build/synth.bin')
    for sec, _ in list(HOOKS.values()) + list(OPZ_HOOKS.values()) + list(DEV_HOOKS.values()):
        cmds.append(f'bfin-elf-objcopy -O binary -j .{sec} build/synth.elf build/{sec}.bin')
    cmds.append('bfin-elf-objcopy -O binary -j .l1tramp build/synth.elf build/l1tramp.bin')
    cmds.append('bfin-elf-nm build/synth.elf > build/synth.sym')
    cmds.append('bfin-elf-nm -S -n build/synth.elf > build/synth.nms')   # with sizes: the symbol map (symmap.py)
    cmds.append('bfin-elf-objdump -d build/synth.elf > build/synth.lst && bfin-elf-size build/synth.elf')
    sh(f'docker run --rm -u {os.getuid()}:{os.getgid()} -v "{HERE}":/work bfin-elf-toolchain '
       f'sh -c \'{" && ".join(cmds)}\'')
    syms = {}
    for line in open(os.path.join(HERE, 'build', 'synth.sym')):
        a, t, n = line.split(); syms[n.lstrip('_')] = int(a, 16)
    code = open(os.path.join(HERE, 'build', 'synth.bin'), 'rb').read()
    code += b'\0' * (-len(code) % 4)
    hooks = {}
    for addr, (sec, orig) in list(HOOKS.items()) + list(OPZ_HOOKS.items()) + list(DEV_HOOKS.items()):
        hooks[addr] = open(os.path.join(HERE, 'build', sec + '.bin'), 'rb').read()
        assert len(hooks[addr]) == len(orig), (sec, hooks[addr])
    return code, hooks, syms

def ldr_hdr(flags_dma, addr, cnt, arg):
    h = bytearray(struct.pack('<IIII', 0xAD000000 | flags_dma, addr, cnt, arg)); x = 0
    for b in h: x ^= b
    h[2] ^= x
    return bytes(h)

def ldr_blocks(d):
    off = 0
    while off + 16 <= len(d):
        code, addr, cnt, arg = struct.unpack_from('<IIII', d, off)
        yield off, code, addr, cnt, arg
        off += 16 + (0 if code & 0x0100 else cnt)

def ldr_poke(d, addr, data, expect=None):
    for off, c, a, n, g in ldr_blocks(d):
        if c & 0x1500 or not n: continue            # skip FILL / IGNORE / CALLBACK(encrypted)
        if a <= addr and addr + len(data) <= a + n:
            p = off + 16 + addr - a
            if expect is not None:
                assert bytes(d[p:p+len(expect)]) == expect, f'{addr:#x}: unexpected original bytes'
            d[p:p+len(data)] = data; return
    raise SystemExit(f'address {addr:#x} not in a plain LDR block')

# boot screen text under the TE logo: drawn by 0x01A2FCB8 -> text overlay 0x019416EA(0x018F7358).
# Original: 17 newlines + 33 spaces + "R. 00246" (58 bytes, 0-terminated). Replaced in place by "op1r <VERSION>",
# right-aligned to the same column. VERSION = synth_sdk/VERSION, a counter bumped for every released change.
BOOT_TEXT_ADDR = 0x018F7358
BOOT_TEXT_ORIG = b'\n' * 17 + b' ' * 33 + b'R. 00246'
def boot_text(release=True):
    ver = open(os.path.join(HERE, 'VERSION')).read().strip()
    tag = f'op1r {ver}'.encode()
    if not release:                                               # local build: op1r <n> YYYY-MM-DD HH:MM
        import time
        tag += time.strftime(' %Y-%m-%d %H:%M').encode()
    assert 0 < len(tag) <= 41, tag
    return b'\n' * 17 + b' ' * (41 - len(tag)) + tag

def apply_l1(d, pokes):
    """pokes: [(addr, data, expect)] inside the encrypted L1 blocks. KN_L1_RUNTIME (default): the LDR stays as TE built
    it, kennel/kn_l1rt.c writes them at boot. LDR mode (KN_L1_RUNTIME=0): with the optional regeneration helper, patch and record the
    byte differences in l1_patches.json; without it (standard builds), replay the recorded differences."""
    want = [[f'{a:#010x}', x.hex(), e.hex()] for a, x, e in pokes]
    if L1_RUNTIME:
        return
    tool = os.environ.get('KN_L1_TOOL')                  # the folder holding l1_private.py (a builder copies synth_sdk
    try:                                                 # away from the checkout, so ROOT/analysis is rarely there)
        sys.path.insert(0, tool or os.path.join(ROOT, 'analysis'))
        import l1_private
    except ImportError:
        if tool:
            raise SystemExit(f'KN_L1_TOOL={tool}: no l1_private.py there')
        l1_private = None
    if l1_private:
        before = bytes(d)
        for a, x, e in pokes:
            l1_private.poke(d, ldr_blocks(d), a, x, e)
        ops, i = [], 0
        while i < len(d):                                        # changed byte ranges (same length)
            if d[i] != before[i]:
                j = i
                while j < len(d) and d[j] != before[j]: j += 1
                ops.append([i, before[i:j].hex(), bytes(d[i:j]).hex()]); i = j
            else:
                i += 1
        rec = {'_comment': 'encrypted L1 patch bytes, generated by make_firmware.py with the private tool; '
                           'public builds replay them (offsets in the original OP1_vdk.ldr)',
               'pokes': want, 'ops': ops}
        text = json.dumps(rec, indent=1)
        same = text == open(L1_PATCHES_JSON).read()
        open(L1_PATCHES_JSON, 'w').write(text)
        if not same:                                     # pokes changed: hand the new file back to the checkout too
            dest = os.path.join(os.environ.get('KENNEL_ROOT', ROOT), 'synth_sdk', 'l1_patches.json')
            open(dest, 'w').write(text)
            print(f'l1_patches.json regenerated: wrote {dest}; commit it', file=sys.stderr)
        print('l1_patches.json generated with l1_private: ' + ('unchanged' if same else 'changed'))
        return
    rec = json.load(open(L1_PATCHES_JSON))
    if rec['pokes'] != want:
        raise SystemExit('the L1 patches changed (hook addresses or L1 patch lists): l1_patches.json must be '
                         'regenerated by a maintainer with the private tool')
    for off, old, new in rec['ops']:
        assert bytes(d[off:off + len(old) // 2]).hex() == old, f'L1 bytes at {off:#x} differ from the original'
        d[off:off + len(new) // 2] = bytes.fromhex(new)

# Upstream op1r40 silent-start fix: data, replacement byte, checked stock byte.
KNOB_BYTE = (0x018B62A4, b'\x00', b'\xff')

def patch_ranges():
    """(start, end, label) of every byte the build patches in the firmware image"""
    r = []
    for tbl, name in ((HOOKS, 'HOOKS'), (DEV_HOOKS, 'DEV_HOOKS'), (OPZ_HOOKS, 'OPZ_HOOKS'), (L1_CALLS, 'L1_CALLS'),
                      (L1_PCCALLS, 'L1_PCCALLS')):
        r += [(a, a + len(orig), f'{name} {sym}') for a, (sym, orig) in tbl.items()]
    # Include native drum sites before private stock preimages are prepared too.
    r += [(a, a + size, f'HOOKS hook_{name}') for a, name, size in drum_synth_preparation().HOOKS if a not in HOOKS]
    r += [(a, a + 4, f'DATA_PATCHES {sym}') for a, (sym, _) in DATA_PATCHES.items()]
    for tbl, name in ((IMM_PATCHES, 'IMM_PATCHES'), (L1_IMM_PATCHES, 'L1_IMM_PATCHES')):
        r += [(a + 2, a + 4, f'{name} {sym} lo') for a, (sym, _) in tbl.items()]
        r += [(a + 6, a + 8, f'{name} {sym} hi') for a, (sym, _) in tbl.items()]
    r += [(vt + 8 * slot + 4, vt + 8 * slot + 8, f'SLOTS {n}') for n, (vt, slot, _) in SLOTS.items()]
    r += [(BOOT_TEXT_ADDR, BOOT_TEXT_ADDR + len(BOOT_TEXT_ORIG), 'boot text'),
          (KNOB_BYTE[0], KNOB_BYTE[0] + len(KNOB_BYTE[1]), 'volume knob byte'),
          (L1_TRAMP, L1_TRAMP + L1_TRAMP_MAX, 'L1 trampolines'),
          (STEFAN_L1, STEFAN_L1 + STEFAN_L1_ROOM, 'STEFAN L1 block')]
    r += [(a, a + len(o), f'STEFAN_POKES {sym}') for a, (sym, o) in STEFAN_POKES.items()]
    return r

def check_collisions():
    """two patches touching the same firmware bytes = build error (the later one would silently win)"""
    r = sorted(patch_ranges())
    bad = [(a, b) for a, b in zip(r, r[1:]) if b[0] < a[1]]
    assert not bad, 'patch collision: ' + '; '.join(f'{x[2]} [{x[0]:#x}..{x[1]:#x}) overlaps {y[2]} [{y[0]:#x}..{y[1]:#x})'
                                                   for x, y in bad)

def patch_ldr(src, dst, code, hooks, syms, opz=False, release=True, dev=False):
    d = bytearray(open(src, 'rb').read())
    if opz:
        for addr, (sec, orig) in OPZ_HOOKS.items():
            ldr_poke(d, addr, hooks[addr], orig)
        print('OP-Z mode enabled (switched on by SysEx F0 00 20 76 00 01 03 F7)')
    if dev:
        assert not release, '--dev is for development builds only'
        for addr, (sec, orig) in DEV_HOOKS.items():
            ldr_poke(d, addr, hooks[addr], orig)
        print('DEV: staged-update apply at boot (devupd, docs/35)')
    for name, (vt, slot, orig) in SLOTS.items():
        ldr_poke(d, vt + 8 * slot + 4, struct.pack('<I', syms[name]), struct.pack('<I', orig))
    for addr, data in hooks.items():
        if addr in HOOKS: ldr_poke(d, addr, data, HOOKS[addr][1])
    check_collisions()
    ldr_poke(d, *KNOB_BYTE)
    ldr_poke(d, BOOT_TEXT_ADDR, boot_text(release), BOOT_TEXT_ORIG)   # boot screen: op1r <version> [build time]
    for addr, (sym, orig) in DATA_PATCHES.items():
        ldr_poke(d, addr, struct.pack('<I', syms[sym]), struct.pack('<I', orig))
    for addr, (sym, orig) in IMM_PATCHES.items():              # keep the opcodes, swap the 16-bit halves
        v = syms[sym]
        ldr_poke(d, addr + 2, struct.pack('<H', v & 0xFFFF), struct.pack('<H', orig & 0xFFFF))
        ldr_poke(d, addr + 6, struct.pack('<H', v >> 16), struct.pack('<H', orig >> 16))
    for i, name in enumerate(L1_VECTOR):                        # encrypted L1 patches assume these addresses
        assert syms[name] == CODE_BASE + 4 * i, (name, hex(syms[name]))
    pokes = []
    for addr, (sym, orig) in L1_CALLS.items():
        v = syms[sym]
        new = struct.pack('<HHHHH', 0xE109, v & 0xFFFF, 0xE149, v >> 16, 0x0061)
        new += b'\0' * (len(orig) - len(new))                 # NOP (0x0000) fill
        assert len(new) == len(orig)
        pokes.append((addr, new, orig))
    for addr, (sym, orig) in L1_PCCALLS.items():               # CALL pcrel24: E3xx (offset >> 16) + low 16 bits
        o = ((syms[sym] - addr) >> 1) & 0xFFFFFF
        assert -0x800000 <= ((syms[sym] - addr) >> 1) < 0x800000
        pokes.append((addr, struct.pack('<HH', 0xE300 | (o >> 16), o & 0xFFFF), orig))
    for addr, (sym, orig) in L1_IMM_PATCHES.items():           # Rx.L / Rx.H pair in encrypted L1
        v = syms[sym]
        pokes.append((addr + 2, struct.pack('<H', v & 0xFFFF), struct.pack('<H', orig & 0xFFFF)))
        pokes.append((addr + 6, struct.pack('<H', v >> 16), struct.pack('<H', orig >> 16)))
    apply_l1(d, pokes)
    fin = [o for o, c, a, n, g in ldr_blocks(d) if c & 0x8000][0]
    blk = ldr_hdr(0x0006, CODE_BASE, len(code), 0) + code
    bss, bss_end = syms['bss_start'], syms['bss_end']        # .bss: zero FILL block (link.ld), no payload
    assert bss == kn_mem.BSS_LO, ('link.ld .bss must start at kn_mem.h KN_BSS_LO', hex(bss))
    assert CODE_BASE + len(code) <= CODE_LIMIT <= bss and bss_end <= BSS_LIMIT, (hex(CODE_BASE + len(code)), hex(bss_end))
    far, far_end = syms.get('farbss_start', kn_mem.FARBSS_LO), syms.get('farbss_end', kn_mem.FARBSS_LO)
    assert far == kn_mem.FARBSS_LO and far <= far_end <= kn_mem.FARBSS_HI, \
        ('.farbss outside kn_mem.h KN_FARBSS_LO..HI', hex(far), hex(far_end))
    if far_end > far:                                          # .farbss: a second zero FILL block (kn_mem.h)
        blk += ldr_hdr(0x0106, far, far_end - far, 0)
    if bss_end > bss:
        blk += ldr_hdr(0x0106, bss, bss_end - bss, 0)
    tm0, tm1 = syms['tm_l1_start'], syms['tm_l1_end']             # tape/tm_l1.S: STEFAN's block for 0xFFA01D60
    assert CODE_BASE <= tm0 < tm1 and tm1 - tm0 <= STEFAN_L1_ROOM, ('tape/tm_l1.S must fit 840 bytes', tm1 - tm0)
    dec0, dec1 = syms['kn_dec_l1_start'], syms['kn_dec_l1_end']   # kennel/kn_dec_l1.S: the decimator for 0xFFA005D4
    assert CODE_BASE <= dec0 < dec1 and dec1 - dec0 <= DEC_ROOM, ('kn_dec_l1.S must fit R246\'s 176 bytes', dec1 - dec0)
    if not L1_RUNTIME:                                          # LDR mode: a plain block over R246's routine (runtime:
        dec = code[dec0 - CODE_BASE:dec1 - CODE_BASE]           # kennel/kn_dec.c writes it by DTEST after checking R246's)
        blk += ldr_hdr(0x0006, DEC_ADDR, len(dec), 0) + dec
    tramp = open(os.path.join(HERE, 'build', 'l1tramp.bin'), 'rb').read()
    if tramp:                                                   # L1 trampolines: plain block in free L1 instruction SRAM
        assert len(tramp) <= L1_TRAMP_MAX, len(tramp)
        tramp += b'\0' * (-len(tramp) % 4)
        blk += ldr_hdr(0x0006, L1_TRAMP, len(tramp), 0) + tramp
    d[fin:fin] = blk
    c0, a0, n0, g0 = struct.unpack_from('<IIII', d, 0)
    d[0:16] = ldr_hdr(c0 & 0xffff, a0, n0, g0 + len(blk))
    open(dst, 'wb').write(d)

def patch_db(dbp, engs, fxs):
    # a plugin file without a fixed order gets its number and its synth_types / fx_types row from the loader at boot
    engs, fxs = [e for e in engs if 'order' in e], [f for f in fxs if 'order' in f]
    c = sqlite3.connect(dbp)
    have = {r[0] for r in c.execute('SELECT type FROM synth_types')}
    nid = c.execute('SELECT MAX(id) FROM synth_types').fetchone()[0] + 1
    if 'iter' not in have:
        c.execute('INSERT INTO synth_types VALUES (?,?,?)', (nid, 'iter', ITER_PARAMS)); nid += 1
    for e in engs:
        k = list(e['defaults']) + [0] * (4 - len(e['defaults']))
        params = json.dumps(k[:4] + [MAGIC + e['order'], 0, 0, 0])
        if e['name'] in have:
            c.execute('UPDATE synth_types SET default_params=? WHERE type=?', (params, e['name']))
        else:
            c.execute('INSERT INTO synth_types VALUES (?,?,?)', (nid, e['name'], params)); nid += 1
    have = {r[0] for r in c.execute('SELECT type FROM fx_types')}
    if 'filter' not in have:
        fid = FILTER_ROW[0] if not c.execute('SELECT 1 FROM fx_types WHERE id=?', (FILTER_ROW[0],)).fetchone() \
            else c.execute('SELECT MAX(id) FROM fx_types').fetchone()[0] + 1
        c.execute('INSERT INTO fx_types VALUES (?,?,?)', (fid,) + FILTER_ROW[1:])
    nid = c.execute('SELECT MAX(id) FROM fx_types').fetchone()[0] + 1
    for f in fxs:
        k = list(f['defaults']) + [0] * (4 - len(f['defaults']))
        raw = [lo + (min(max(v, 0), 32767) * (hi - lo)) // 32767 for v, (lo, hi) in zip(k[:4], FX_RANGES)]
        assert all(lo <= v <= hi for v, (lo, hi) in zip(raw, FX_RANGES)), (f['name'], raw)
        p2 = list(f.get('page2_defaults', [])) + [0] * 3                 # words 5..7: page-2 params, 0..32767
        params = json.dumps(raw + [MAGIC + f['order']] + [min(max(int(v), 0), 32767) for v in p2[:3]])
        if f['name'] in have:
            c.execute('UPDATE fx_types SET default_params=? WHERE type=?', (params, f['name']))
        else:
            c.execute('INSERT INTO fx_types VALUES (?,?,?)', (nid, f['name'], params)); nid += 1
    # quad LFO (lfo/quadlfo.c): runs in the midi LFO class; words 0..3 frequency, 4..7 0x4000|free|dest|group|amount
    if not c.execute("SELECT 1 FROM lfo_types WHERE type='quad'").fetchone():
        lid = c.execute('SELECT MAX(id) FROM lfo_types').fetchone()[0] + 1
        c.execute('INSERT INTO lfo_types VALUES (?,?,?)', (lid, 'quad', json.dumps(QUAD_LFO_DEFAULTS)))
    if not c.execute("SELECT 1 FROM lfo_types WHERE type='pond'").fetchone():   # pond LFO (lfo/quadlfo.c), marker 0xA7
        lid = c.execute('SELECT MAX(id) FROM lfo_types').fetchone()[0] + 1
        c.execute('INSERT INTO lfo_types VALUES (?,?,?)', (lid, 'pond', json.dumps(POND_LFO_DEFAULTS)))
    # euclid sequencer (seq/euclid.c): extra sequencer type, runs as finger (type 3) + flag
    if not c.execute("SELECT 1 FROM seq_types WHERE type='euclid'").fetchone():
        sid = c.execute('SELECT MAX(id) FROM seq_types').fetchone()[0] + 1
        c.execute('INSERT INTO seq_types VALUES (?,?)', (sid, 'euclid'))
    # dots step sequencer (seq/dots.c): same mechanism, own flag
    if not c.execute("SELECT 1 FROM seq_types WHERE type='dots'").fetchone():
        sid = c.execute('SELECT MAX(id) FROM seq_types').fetchone()[0] + 1
        c.execute('INSERT INTO seq_types VALUES (?,?)', (sid, 'dots'))
    # drum+ (drumplus/dp_fw.c): a drum_types row; dp_type_job handles its id (DP_TYPE_ID)
    if not c.execute("SELECT 1 FROM drum_types WHERE type='drum+'").fetchone():
        did = c.execute('SELECT MAX(id) FROM drum_types').fetchone()[0] + 1
        assert did == 2, did                                             # = OP1_DRUM_TYPE_ID (op1_feature_drum.h)
        c.execute('INSERT INTO drum_types VALUES (?,?,?)', (did, 'drum+', DRUM_PARAMS))
    # oracle geomancy sequencer (seq/oracle.c): same mechanism, own flag
    if not c.execute("SELECT 1 FROM seq_types WHERE type='oracle'").fetchone():
        sid = c.execute('SELECT MAX(id) FROM seq_types').fetchone()[0] + 1
        c.execute('INSERT INTO seq_types VALUES (?,?)', (sid, 'oracle'))
    # peal change-ringing sequencer (seq/peal.c): same mechanism, own flag
    if not c.execute("SELECT 1 FROM seq_types WHERE type='peal'").fetchone():
        sid = c.execute('SELECT MAX(id) FROM seq_types').fetchone()[0] + 1
        c.execute('INSERT INTO seq_types VALUES (?,?)', (sid, 'peal'))
    # New sequencer features declare their browser identity in metadata. Existing
    # built-in rows above retain their IDs; imported .knl files also add rows at boot.
    for feature in plugins.load_features():
        add_seq_feature_row(c, feature)
    gin_catalog(c)
    for feature in plugins.load_features():     # other drum synths: their own catalog (plugin.json drum_synth.catalog)
        cat = (feature.get('drum_synth') or {}).get('catalog')
        if cat:
            import importlib.util
            spec = importlib.util.spec_from_file_location(f'{feature["id"]}_catalog', os.path.join(HERE, 'plugins', feature['id'], cat))
            mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); mod.catalog(c)
    c.commit()
    for r in c.execute('SELECT * FROM synth_types ORDER BY id'): print('  ', r)
    for r in c.execute('SELECT * FROM fx_types ORDER BY id'): print('  fx', r)
    c.close()

def gin_catalog(c):
    """Gin's drum_types row and its kits in drum_presets (plugins/gin/prepare.py; needs R246's own presets)"""
    import importlib.util
    spec=importlib.util.spec_from_file_location('gin_catalog_prepare',os.path.join(HERE,'plugins/gin/prepare.py'))
    gin=importlib.util.module_from_spec(spec);spec.loader.exec_module(gin);gin.catalog(c,HERE)

def add_seq_feature_row(c, feature):
    """Own only rows this build creates for removable sequencer files."""
    if not feature.get('sequencer'):
        return
    name = feature['name']
    existed = c.execute("SELECT 1 FROM seq_types WHERE type=?", (name,)).fetchone()
    if not existed:
        c.execute("INSERT INTO seq_types SELECT COALESCE(MAX(id),0)+1,? FROM seq_types", (name,))
        if feature.get('loadable'):
            c.execute("CREATE TABLE IF NOT EXISTS kennel_seq_owned(type TEXT PRIMARY KEY)")
            c.execute("INSERT OR IGNORE INTO kennel_seq_owned VALUES(?)", (name,))


def core_owned(engs, fxs, features):
    """The type names the core owns in synth_types / fx_types / seq_types: their rows go at boot while the plugin isn't
    registered (kn_core_rows.h kn_cr_cleanup). Every plugin of this tree, compiled in or a file; never a stock name."""
    own = {'synth': [e['name'] for e in engs], 'fx': [f['name'] for f in fxs],
           'seq': list(SEQ_ROWS) + [f['name'] for f in features if f.get('sequencer') and f['name'] not in SEQ_ROWS]}
    assert not set(own['synth']) & BUILTIN and not set(own['fx']) & FX_BUILTIN, own
    return own


CORE_ROWS_JSON = os.path.join(HERE, 'core_rows.json')


def core_rows(engs, fxs, features):
    """synth_sdk/core_rows.json: every row patch_db adds to R246's factory DB, with what keeps it at boot. Only our
    rows (names, no TE data). A row listed here is ensured by the core whenever its plugin is registered (or always),
    so a factory-DB comparison between two releases of this core may leave it out (root tools/firmware/cores.py)."""
    def file(p):
        return p.get('loadable', False)
    rows = [{'table': 'synth_types', 'type': 'iter', 'plugin': None, 'ensured_by': 'kn_rows_finish (always)'}]
    rows += [{'table': 'synth_types', 'type': e['name'], 'plugin': e['id'], 'ensured_by': 'row_ensure'}
             for e in engs if 'order' in e and file(e)]
    rows += [{'table': 'fx_types', 'type': 'filter', 'plugin': None,
              'ensured_by': 'kn_rows_finish (always; default_params kept current)'}]
    rows += [{'table': 'fx_types', 'type': f['name'], 'plugin': f['id'], 'ensured_by': 'row_ensure'}
             for f in fxs if 'order' in f and file(f)]
    by_name = {f['name']: f for f in features}
    rows += [{'table': 'lfo_types', 'type': 'quad', 'plugin': by_name['quad']['id'], 'ensured_by': 'kn_rows_finish'},
             {'table': 'lfo_types', 'type': 'pond', 'plugin': by_name['quad']['id'], 'ensured_by': 'kn_rows_finish'}]
    seqs = [by_name[n] for n in SEQ_ROWS] + [f for f in features if f.get('sequencer') and f['name'] not in SEQ_ROWS]
    rows += [{'table': 'seq_types', 'type': f['name'], 'plugin': f['id'], 'ensured_by': 'kn_seq_row_ensure'}
             for f in seqs if file(f)]
    rows += [{'table': 'drum_types', 'type': by_name['drum+']['name'], 'plugin': by_name['drum+']['id'],
              'ensured_by': 'kn_rows_early (id 2)'}]
    for f in features:
        if f.get('drum_synth'):
            by = f['drum_synth'].get('ensured_by', ['gin_fw_database_open', 'gin_catalog_sql'])
            rows += [{'table': 'drum_types', 'type': f['name'], 'plugin': f['id'], 'ensured_by': by[0]},
                     {'table': 'drum_presets', 'folder': f['name'], 'plugin': f['id'],
                      'ensured_by': by[1] + ' (by kit name; hidden while absent: kn_ds_preset_query)'}]
    return {'schema': 1,
            'about': 'Rows kennel adds to R246 content/op1_factory.db that the core keeps right at boot '
                     '(kennel/kn_core_rows.h). Plugin rows: inserted when the plugin is registered, removed when it '
                     'is not (drum_presets: hidden). Generated: make_firmware.py --core-rows.',
            'tables': ['kennel_seq_owned', 'kennel_owned'],
            'rows': rows,
            # rows of retired ports an older build put in the factory DB, removed at boot while their type isn't
            # registered (3.3 -> 3.3.1 core patches: the same factory digest; root runtime.core_rows)
            'dropped': [{'table': 'lfo_types', 'type': 'matrix', 'plugin': None,
                         'removed_by': 'kn_cr_finish (unless the bridged matrix registers the name)'},
                        {'table': 'drum_types', 'type': 'him', 'plugin': None,
                         'removed_by': 'kn_cr_retired_drum (unless a him provider registers)'},
                        {'table': 'drum_presets', 'folder': 'him', 'plugin': None,
                         'removed_by': 'kn_cr_retired_drum (unless a him provider registers); user kits: kn_presets_retired'}]}


def main(opz=False, release=False, dev=False):
    engs, fxs = plugins.load()
    assert engs                                 # order = the number stored in patches (MAGIC + n): never renumber;
    for lst in (engs, fxs):                     # gaps are fine (an order no plugin has plays as stock iter / filter)
        assert all(1 <= e['order'] <= BUILTIN_MAX_ORDER for e in lst if 'order' in e), [e.get('order') for e in lst]
    for f in fxs:
        assert f['name'] not in FX_BUILTIN and f['name'].islower() and len(f['name']) <= 15, f['name']
    for e in engs:
        assert e['name'] not in BUILTIN and e['name'].islower() and len(e['name']) <= 15, e['name']
    stock = set(os.listdir(os.path.join(SRC_FW, 'content', 'display')))
    for f in (EUCLID_SVG, DOTS_SVG, ORACLE_SVG, PEAL_SVG, QUAD_LFO_SVG, POND_LFO_SVG, SYSMON_SVG, USBOUT_SVG):  # (oblique reuses usbout.svg: empty)
        assert os.path.basename(f) not in stock, f'{f} clashes with a stock content/display file'
    for e in engs + fxs:                         # never replace a firmware screen (boot assert "Can't find SVG object")
        if e.get('screen'):
            assert os.path.basename(e['screen']['svg']) not in stock, \
                f'{e["name"]}: {e["screen"]["svg"]} clashes with a stock content/display file, rename it'
    os.makedirs(os.path.join(HERE, 'build'), exist_ok=True)   # fresh checkout
    sys.path.insert(0, os.path.join(HERE, 'display'))
    import gen_oblique                           # cards wrapped with the stock font's widths (build time only)
    ob_cards, _ = gen_oblique.build(os.path.join(SRC_FW, 'content', 'display', 'opfont.svg'),
                                    os.path.join(HERE, 'screens', 'oblique', 'cards.txt'))
    gen_oblique.emit(ob_cards, os.path.join(HERE, 'build', 'oblique_data.c'))
    code, hooks, syms = build(engs, fxs)
    assert len(code) < 0x100000
    shutil.rmtree(OUT_FW, ignore_errors=True); shutil.copytree(SRC_FW, OUT_FW)
    patch_ldr(os.path.join(SRC_FW, 'OP1_vdk.ldr'), os.path.join(OUT_FW, 'OP1_vdk.ldr'), code, hooks, syms, opz, release, dev)
    print(f'code {len(code)} bytes @{CODE_BASE:#x}; ' + ', '.join(f'{k}={syms[k]:#x}' for k in SLOTS))
    patch_db(os.path.join(OUT_FW, 'content', 'op1_factory.db'), engs, fxs)
    disp = os.path.join(OUT_FW, 'content', 'display')
    for e in engs + fxs:
        if e.get('screen'):
            shutil.copy(os.path.join(HERE, e['screen']['svg']), os.path.join(disp, os.path.basename(e['screen']['svg'])))
    loadable = [e for e in engs + fxs + plugins.load_features() if e.get('loadable')]
    plug_syms = {}
    if loadable:                                 # plugin files for the kennel loader (kennel/kn_boot.c)
        kennel = os.environ.get('KENNEL_ROOT', os.path.dirname(HERE))
        sys.path.insert(0, os.path.join(kennel, 'tools', 'kennel'))
        import pack
        pdir = os.path.join(OUT_FW, 'content')          # v1: op1r's patcher cannot add folders
        for e in loadable:                       # <id>.knl (docs/plugin-format.md "Names"; plugins.py checks the id)
            name = e['id'] + '.knl'
            _, info = pack.pack_dir(os.path.join(HERE, os.path.dirname(e['source'])), os.path.join(pdir, name))
            plug_syms[e['id']] = info
            print(f'  plugin file content/{name}')
    import symmap                                # the crash screen's symbol map (symmap.py): build/symbols.json
    symmap.write(os.path.join(HERE, 'build', 'symbols.json'),
                 symmap.make(open(os.path.join(HERE, 'build', 'synth.nms')).read(), plug_syms,
                             open(os.path.join(HERE, 'build', 'synth.bin'), 'rb').read()))
    for f in filter(None, os.environ.get('KENNEL_EXTRA_CONTENT', '').split(os.pathsep)):   # test aid: plugin files
        shutil.copy(f, os.path.join(OUT_FW, 'content', os.path.basename(f)))           # (e.g. op1r .op1p) shipped too
    shutil.copy(os.path.join(HERE, QUAD_LFO_SVG), os.path.join(disp, os.path.basename(QUAD_LFO_SVG)))
    shutil.copy(os.path.join(HERE, POND_LFO_SVG), os.path.join(disp, os.path.basename(POND_LFO_SVG)))
    shutil.copy(os.path.join(HERE, EUCLID_SVG), os.path.join(disp, os.path.basename(EUCLID_SVG)))
    shutil.copy(os.path.join(HERE, DOTS_SVG), os.path.join(disp, os.path.basename(DOTS_SVG)))
    shutil.copy(os.path.join(HERE, ORACLE_SVG), os.path.join(disp, os.path.basename(ORACLE_SVG)))
    shutil.copy(os.path.join(HERE, PEAL_SVG), os.path.join(disp, os.path.basename(PEAL_SVG)))
    shutil.copy(os.path.join(HERE, SYSMON_SVG), os.path.join(disp, os.path.basename(SYSMON_SVG)))
    shutil.copy(os.path.join(HERE, USBOUT_SVG), os.path.join(disp, os.path.basename(USBOUT_SVG)))
    shutil.copy(os.path.join(HERE, ITERLAB_SVG), os.path.join(disp, os.path.basename(ITERLAB_SVG)))
    src_svg = os.path.join(HERE, 'display', FX_SCREEN_SVG)
    shutil.copy(src_svg if os.path.exists(src_svg) else os.path.join(disp, 'iter.svg'),
                os.path.join(disp, FX_SCREEN_SVG))
    sh(f'"{REPACKER}" repack "{OUT_FW}"')
    # development delta (tools/op1delta.py, docs/34): LDR + files changed since the tree recorded as installed
    delta = os.path.join(ROOT, os.path.basename(OUT_FW) + '-delta.op1')
    if os.path.exists(OUT_FW + '.delta-state.json'):
        sh(f'python3 "{os.path.join(ROOT, "tools", "op1delta.py")}" "{OUT_FW}" -o "{delta}"')
    else:
        print(f'no delta: record the installed tree first (tools/op1delta.py {os.path.basename(OUT_FW)} --init)')

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--dev', action='store_true', help='development build: apply staged updates at boot (docs/35)')
    ap.add_argument('--opz', action='store_true', help='enable hidden OP-Z controller mode (via SysEx 00 01 03)')
    ap.add_argument('--release', action='store_true', help='boot screen without build time (patcher builds)')
    ap.add_argument('--core-rows', action='store_true', help='write core_rows.json (the rows the core keeps) and exit')
    a = ap.parse_args()
    if a.core_rows:
        e, f = plugins.load()
        with open(CORE_ROWS_JSON, 'w') as out:
            json.dump(core_rows(e, f, plugins.load_features()), out, indent=1)
            out.write('\n')
        sys.exit(0)
    main(a.opz, a.release, a.dev)
