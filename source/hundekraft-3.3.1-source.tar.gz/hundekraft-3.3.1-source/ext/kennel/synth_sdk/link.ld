/* Custom code in SDRAM 0x01E00000.. (free: image+bss end 0x01DFFF34, heap0 0x100..0x1000000,
   heap1 0x03040000.., ICPLB maps 0..64MB). .hook_* sections are patched into the original image. */
ENTRY(_synth_render)
SECTIONS {
  . = 0x01E00000;
  .text   : { KEEP(*(.l1vec)) *(.text.kn_audio) *(.text*) }   /* .l1vec first: fixed L1 entry points (hook.S); then the
                                                                 per-block audio code together (kn_mem.h kn_audio_text) */
  .rodata : { *(.rodata*) __core_ro_end = .; }   /* code + constants end: the core's identity CRC (kn_inv.c) */
  .data   : { *(.data*) }
  .stefan : { *(.kn_stefan) }
  .coop : { *(.kn_coop) }   /* coop-fw's stock DSP rewrites (dsp/coop; make_firmware renames their .text / .near / .data):
                               after STEFAN, so the rest of the image keeps its addresses */   /* STEFAN (tape/tm.c, tm_on.c, tm_l1.S; make_firmware renames their .text / .rodata / .data):
                                   after everything else, so the code, constants and data of the rest keep their places
                                   (a precaution: layout moves change cache conflicts; not measured as a cost here) */
  __image_end = .;
  /* zero-initialised data lives apart from the code block, as LDR FILL blocks (no bytes in the image): the loaded
     image stays below 0x01EC0000 (kn_mem.h KN_CORE_CODE_LIMIT; 0x01E40000, which another project's module uses, until
     2026-11-11, then 0x01E60000 until .farbss moved up for 3.3 rc17). kennel builds never use that module's range.
     Core window (stock image ends 0x01DFFF34; heaps at 0x100.. and 0x03040000..): image 0x01E00000..0x01EC0000,
     .bss 0x01EC0000..0x01EF0000, the workshop's banner 0x01EF0000, preset table and the settings feature 0x01F00000..0x01F40000
     (OP1-Emulator builder), .farbss 0x01F40000..0x02000000; display framebuffer A at 0x02000000.
     .farbss: large zero-initialised core tables (kn_mem.h kn_farbss, KN_FARBSS_LO..HI). It comes before .bss here
     because the first matching rule takes .bss.kn_far. .bss starts with .bss.kn_hot (kn_mem.h kn_hot), line-aligned
     at both ends. Fixed addresses; the ASSERTs stop a test core (harness/matrix.py "builtin") whose image or .bss runs
     into the next region. make_firmware and tier 2 check the release layout against kn_mem.h. */
  .farbss 0x01F40000 (NOLOAD) : { __farbss_start = .; *(.bss.kn_far) . = ALIGN(4); __farbss_end = .; }
  .bss 0x01EC0000 (NOLOAD) : { __bss_start = .; . = ALIGN(32); __kn_hot_start = .; *(.bss.kn_hot) . = ALIGN(32); __kn_hot_end = .; *(.bss*) *(COMMON) . = ALIGN(4); __bss_end = .; }
  ASSERT(__image_end <= 0x01EC0000, "core image runs into .bss (kn_mem.h KN_CORE_CODE_LIMIT)")
  ASSERT(__bss_end <= 0x01F40000, "core .bss runs into .farbss")
  ASSERT(__farbss_end <= 0x02000000, "core .farbss runs into display framebuffer A (kn_mem.h KN_FARBSS_HI)")
  .l1tramp 0xFFA0BFB4 : { KEEP(*(.l1tramp)) }    /* free end of L1 instruction SRAM (image ends 0xFFA0BFB4) */
  .hook_keyslot 0x01A86420 : { KEEP(*(.hook_keyslot)) }
  .hook_coop_dsynth 0x0197E956 : { KEEP(*(.hook_coop_dsynth)) }
  .hook_coop_cwo 0x019457D2 : { KEEP(*(.hook_coop_cwo)) }
  .hook_coop_cwo_v0 0x0194569A : { KEEP(*(.hook_coop_cwo_v0)) }
  .hook_coop_cwo_v1 0x019456B6 : { KEEP(*(.hook_coop_cwo_v1)) }
  .hook_coop_cwo_v2 0x019456DC : { KEEP(*(.hook_coop_cwo_v2)) }
  .hook_coop_cwo_v3 0x019456EE : { KEEP(*(.hook_coop_cwo_v3)) }
  .hook_coop_phone 0x01A1BCAC : { KEEP(*(.hook_coop_phone)) }
  .hook_coop_phonecap 0x01A1BBFC : { KEEP(*(.hook_coop_phonecap)) }
  .hook_coop_grid 0x019AF92E : { KEEP(*(.hook_coop_grid)) }
  .hook_coop_delay 0x0197DD46 : { KEEP(*(.hook_coop_delay)) }
  .hook_coop_nitro 0x019A64A4 : { KEEP(*(.hook_coop_nitro)) }
  .hook_coop_spring 0x01A3310A : { KEEP(*(.hook_coop_spring)) }
  .hook_coop_phase 0x01A0BCE0 : { KEEP(*(.hook_coop_phase)) }
  /* coop-fw DSP rewrites (dsp/coop): the stock re-entry points (op1r-src e6219e4 link.ld) */
  _stock_dsynth_loop_back = 0x0197ea6c;
  _stock_dsynth_loop_entry = 0x0197e95a;
  _stock_cwo_loop_entry = 0x019457d6;
  _stock_cwo_loop_back = 0x01945ac8;
  _stock_vec_ctor = 0x01aa3862;
  _stock_phone_loop_top = 0x01a1bcb0;
  _stock_phone_loop_bottom = 0x01a1bf34;
  _stock_phone_loop_back = 0x01a1bf36;
  _stock_phone_capture_top = 0x01a1bc00;
  _stock_phone_capture_bottom = 0x01a1bc58;
  _stock_phone_capture_back = 0x01a1bc5a;
  _stock_punch_render = 0x019e662c;
  _stock_nitro_loop_top = 0x019a64a8;
  _stock_nitro_loop_bottom = 0x019a6682;
  _stock_nitro_loop_back = 0x019a67f8;
  _stock_grid_loop_top = 0x019af932;
  _stock_grid_loop_bottom = 0x019afcc8;
  _stock_grid_loop_back = 0x019afcca;
  _stock_spring_loop_top = 0x01a3310e;
  _stock_spring_loop_bottom = 0x01a33694;
  _stock_spring_loop_back = 0x01a33696;
  _stock_delay_loop_top = 0x0197dd4a;
  _stock_delay_loop_bottom = 0x0197df7a;
  _stock_delay_loop_back = 0x0197df7c;
  _stock_phase_loop_top = 0x01a0bce4;
  _stock_phase_loop_bottom = 0x01a0bd5a;
  _stock_phase_loop_back = 0x01a0bd5c;
  .hook_mswrite 0x01A715DC : { KEEP(*(.hook_mswrite)) }   /* usb_ms_write_sectors entry -> kn_ms_write (kennel/kn_tapes.c) */
  .hook_diskwr 0x01976288 : { KEEP(*(.hook_diskwr)) }     /* FatFs disk_write entry -> kn_disk_write (kennel/kn_tapes.c) */
  .hook_defragwr 0x01974C58 : { KEEP(*(.hook_defragwr)) } /* defragmenter cluster write -> kn_defrag_write */
  .hook_btsync 0x019F034E : { KEEP(*(.hook_btsync)) }     /* boot: CALL fat_sync_after_reboot -> kn_boot_fat_sync */
  .hook_crash 0x0191995C : { KEEP(*(.hook_crash)) }      /* te_fatal_show_message entry -> kn_crash_stub */
  _kn_keys_slot_cont = 0x01A86424;
  .hook_notesreset 0x01A862D4 : { KEEP(*(.hook_notesreset)) }
  _kn_notes_reset_cont = 0x01A862D8;
  .hook_morelease 0x01A8624C : { KEEP(*(.hook_morelease)) }
  _kn_mo_release_cont = 0x01A86250;
  .hook_keydown 0x019AC288 : { KEEP(*(.hook_keydown)) }
  .hook_keyup 0x019AC3A0 : { KEEP(*(.hook_keyup)) }
  .hook_keyoct0 0x01A17046 : { KEEP(*(.hook_keyoct0)) }
  .hook_keyoct1 0x01A170E0 : { KEEP(*(.hook_keyoct1)) }
  .hook_keyoct2 0x01A42744 : { KEEP(*(.hook_keyoct2)) }
  .hook_keyoct3 0x01A427C8 : { KEEP(*(.hook_keyoct3)) }
  .hook_keyoct4 0x01A510AC : { KEEP(*(.hook_keyoct4)) }
  .hook_keyoct5 0x01A510F0 : { KEEP(*(.hook_keyoct5)) }
  .hook_seqoct0 0x01A86236 : { KEEP(*(.hook_seqoct0)) }
  .hook_seqoct1 0x01A86578 : { KEEP(*(.hook_seqoct1)) }
  .hook_lander1 0x01A3BDB0 : { KEEP(*(.hook_lander1)) }
  .hook_lander2 0x019C35F0 : { KEEP(*(.hook_lander2)) }
  .hook_lander3 0x019C369C : { KEEP(*(.hook_lander3)) }
  .hook_knfadeadsr 0x01912128 : { KEEP(*(.hook_knfadeadsr)) }
  _kn_sound_adsr_cont = 0x0191212C;
  .hook_namecmp 0x019B975C : { KEEP(*(.hook_namecmp)) }
  .hook_samplecheck 0x01A01844 : { KEEP(*(.hook_samplecheck)) }
  .hook_fxnamecmp 0x019AAD8E : { KEEP(*(.hook_fxnamecmp)) }
  .hook_iterread 0x019B9EF8 : { KEEP(*(.hook_iterread)) }
  .hook_screenctor 0x01A3BD58 : { KEEP(*(.hook_screenctor)) }
  .hook_screenload 0x019F07D2 : { KEEP(*(.hook_screenload)) }
  .hook_rfp019427b8 0x019427B8 : { KEEP(*(.hook_rfp019427b8)) }
  .hook_rfp01984f60 0x01984F60 : { KEEP(*(.hook_rfp01984f60)) }
  .hook_rfp019a74d4 0x019A74D4 : { KEEP(*(.hook_rfp019a74d4)) }
  .hook_rfp019b05f8 0x019B05F8 : { KEEP(*(.hook_rfp019b05f8)) }
  .hook_rfp019e6a48 0x019E6A48 : { KEEP(*(.hook_rfp019e6a48)) }
  .hook_rfp019e832c 0x019E832C : { KEEP(*(.hook_rfp019e832c)) }
  .hook_rfp01a1cfd2 0x01A1CFD2 : { KEEP(*(.hook_rfp01a1cfd2)) }
  .hook_rfp01a33fb2 0x01A33FB2 : { KEEP(*(.hook_rfp01a33fb2)) }
  .hook_keyev 0x019C2D3E : { KEEP(*(.hook_keyev)) }
  .hook_midicc 0x01A85C8A : { KEEP(*(.hook_midicc)) }
  .hook_midistart 0x019E39D6 : { KEEP(*(.hook_midistart)) }
  .hook_knobev 0x019C2E94 : { KEEP(*(.hook_knobev)) }
  .hook_chordon 0x01A85828 : { KEEP(*(.hook_chordon)) }
  .hook_chordoff 0x01A858D0 : { KEEP(*(.hook_chordoff)) }
  .hook_mostockon 0x01A857B0 : { KEEP(*(.hook_mostockon)) }
  .hook_mostockoff 0x01A85880 : { KEEP(*(.hook_mostockoff)) }
  .hook_lforange 0x01A042A2 : { KEEP(*(.hook_lforange)) }
  .hook_knboot 0x019F02EE : { KEEP(*(.hook_knboot)) }
  .hook_btopen 0x019F02E0 : { KEEP(*(.hook_btopen)) }
  .hook_btfat 0x019F02F4 : { KEEP(*(.hook_btfat)) }
  .hook_btsnd 0x019F0456 : { KEEP(*(.hook_btsnd)) }
  .hook_lpsyn1 0x01A05766 : { KEEP(*(.hook_lpsyn1)) }
  .hook_lpsyn2 0x01A058D4 : { KEEP(*(.hook_lpsyn2)) }
  .hook_lpdrm1 0x01A050A2 : { KEEP(*(.hook_lpdrm1)) }
  .hook_lpdrm2 0x01A05184 : { KEEP(*(.hook_lpdrm2)) }
  .hook_lpgrow 0x0197008E : { KEEP(*(.hook_lpgrow)) }
  .hook_plparse 0x0196FF9A : { KEEP(*(.hook_plparse)) }
  .hook_plsynu 0x01A0586E : { KEEP(*(.hook_plsynu)) }
  .hook_pldrmu 0x01A05122 : { KEEP(*(.hook_pldrmu)) }
  .hook_plrcs 0x01A01BCC : { KEEP(*(.hook_plrcs)) }
  .hook_plrcd 0x01A01CD6 : { KEEP(*(.hook_plrcd)) }
  .hook_dt1 0x0193F58C : { KEEP(*(.hook_dt1)) }
  .hook_dt2 0x0193FBC6 : { KEEP(*(.hook_dt2)) }
  .hook_dt3 0x01A01E14 : { KEEP(*(.hook_dt3)) }
  .hook_dt4 0x01A0265A : { KEEP(*(.hook_dt4)) }
  .hook_dt5 0x01A0293A : { KEEP(*(.hook_dt5)) }
  .hook_dt6 0x01A04E54 : { KEEP(*(.hook_dt6)) }
  .hook_dt7 0x01A05004 : { KEEP(*(.hook_dt7)) }
  .hook_dt8 0x01A06018 : { KEEP(*(.hook_dt8)) }
  .hook_dt9 0x01A060D8 : { KEEP(*(.hook_dt9)) }
  .hook_dtctor 0x01A06020 : { KEEP(*(.hook_dtctor)) }
  .hook_dtdtor 0x01A060E0 : { KEEP(*(.hook_dtdtor)) }
  .hook_dtgate 0x019FEEE4 : { KEEP(*(.hook_dtgate)) }
  .hook_dtassert 0x01A051B2 : { KEEP(*(.hook_dtassert)) }
  .hook_brsort 0x01A18152 : { KEEP(*(.hook_brsort)) }
  .hook_brsyn 0x01A50884 : { KEEP(*(.hook_brsyn)) }
  .hook_brdrm 0x01977718 : { KEEP(*(.hook_brdrm)) }
  .hook_lzfind 0x01A3B580 : { KEEP(*(.hook_lzfind)) }
  .hook_svgstart 0x019FB57C : { KEEP(*(.hook_svgstart)) }
  .hook_knmaster 0x019F054A : { KEEP(*(.hook_knmaster)) }
  .hook_knmasterlist 0x019D97F0 : { KEEP(*(.hook_knmasterlist)) }
  .hook_tapefinal 0x019F0BE2 : { KEEP(*(.hook_tapefinal)) }
  .hook_knunmount 0x019F0BEA : { KEEP(*(.hook_knunmount)) }
  .hook_gcrate 0x019F0C46 : { KEEP(*(.hook_gcrate)) }
  .hook_bgsqueue 0x019411B8 : { KEEP(*(.hook_bgsqueue)) }
  _bgs_queue_cont = 0x019411BC;    /* SaveSlotJob queue after its LINK 0 (bgsave.c) */
  .hook_bgsstop 0x019F0BDC : { KEEP(*(.hook_bgsstop)) }
  .hook_psql1 0x0193F664 : { KEEP(*(.hook_psql1)) }
  .hook_psql2 0x0193FB28 : { KEEP(*(.hook_psql2)) }
  .hook_psql3 0x0193FE2C : { KEEP(*(.hook_psql3)) }
  .hook_psql4 0x01940468 : { KEEP(*(.hook_psql4)) }
  .hook_psql5 0x019405D4 : { KEEP(*(.hook_psql5)) }
  .hook_psql6 0x0194063E : { KEEP(*(.hook_psql6)) }
  .hook_psql7 0x019408AC : { KEEP(*(.hook_psql7)) }
  .hook_knscreens 0x019B2690 : { KEEP(*(.hook_knscreens)) }
  .hook_gfxfinish 0x019AB8C8 : { KEEP(*(.hook_gfxfinish)) }
  _kn_gfx_finish_ret = 0x019AB8D2;   /* Gfx_thread::Run: disp_draw_busy = 0 (kennel/kn_gfx.c) */
  .hook_gfxframe 0x01A3BBE0 : { KEEP(*(.hook_gfxframe)) }
  _kn_gfx_frame_ret = 0x01A3BC02;    /* screens_update after its update loop (kennel/kn_gfx.c) */
  .hook_gsmove 0x019149C4 : { KEEP(*(.hook_gsmove)) }      /* frame skip (screens/guiskip.c, op1r 59) */
  .hook_gsline 0x01914904 : { KEEP(*(.hook_gsline)) }
  .hook_gstext 0x01A6259C : { KEEP(*(.hook_gstext)) }
  .hook_gsdim 0x01A2357A : { KEEP(*(.hook_gsdim)) }
  .hook_gsfade 0x01A22F3C : { KEEP(*(.hook_gsfade)) }
  .hook_gsdot 0x01A24CBC : { KEEP(*(.hook_gsdot)) }
  .hook_gssw1 0x01A24CA6 : { KEEP(*(.hook_gssw1)) }
  .hook_gssw2 0x01A254DC : { KEEP(*(.hook_gssw2)) }
  .hook_gssw3 0x01A27316 : { KEEP(*(.hook_gssw3)) }
  .hook_gssw4 0x01A2749A : { KEEP(*(.hook_gssw4)) }
  .hook_gssw5 0x01A274FE : { KEEP(*(.hook_gssw5)) }
  .hook_gsdna 0x019B5A1E : { KEEP(*(.hook_gsdna)) }
  .hook_gsglyph 0x01A62726 : { KEEP(*(.hook_gsglyph)) }   /* kennel: Text::draw's glyph sweep (tape cache) */       /* kennel: DNA page's CALL of the raster getter (guiskip) */
  _rs_move_body = 0x019149C8;      /* rasterizer move_to after its LINK 0 (guiskip) */
  _rs_line_body = 0x01914908;      /* rasterizer line_to after its LINK 0 */
  _txt_draw_body = 0x01A625A0;     /* Text::draw after its LINK 0x24 (guiskip) */
  _dot_body = 0x01A24CC0;          /* Raster::dotted_hline after its LINK 0x18 */
  _fade_body = 0x01A22F40;         /* Raster::fade after P0 = R0; [--SP] = (R7:4, P5:5) (op1r 8dd28bb) */
  .hook_h0malloc 0x01AA0318 : { KEEP(*(.hook_h0malloc)) }   /* test build: heap_malloc -> kd_h0_stub (kennel/kn_diag.c) */
  _h0_malloc_body = 0x01AA031C;    /* heap_malloc after its LINK 0 (heap 0 low-water mark, test build) */
  _vec_ctor = 0x01AA3862;         /* vector ctor (the drum table, kennel/kn_preset_store.c) */
  _vec_dtor = 0x01AA38FC;
  _find_node_body = 0x01A3B584;    /* Screen::find_node after its LINK 0 (lazy stock screens, kn_lzscr.c) */
  _dim_body = 0x01A2357E;          /* Raster::dim_all after P0 = R0; [--SP] = (R7:4, P5:5) */
  .hook_patchtype 0x01A03884 : { KEEP(*(.hook_patchtype)) }
  .hook_fxpatchtype 0x01A04030 : { KEEP(*(.hook_fxpatchtype)) }
  .hook_euplayer 0x01A0D150 : { KEEP(*(.hook_euplayer)) }
  .hook_seqname1 0x01A42A2E : { KEEP(*(.hook_seqname1)) }
  .hook_seqname2 0x01A42BDC : { KEEP(*(.hook_seqname2)) }
  .hook_seqname3 0x01A42CE0 : { KEEP(*(.hook_seqname3)) }
  .hook_seqtoname 0x01A422EC : { KEEP(*(.hook_seqtoname)) }
  .hook_lfoname1 0x019C9C3A : { KEEP(*(.hook_lfoname1)) }
  .hook_lfoname2 0x019C9BE2 : { KEEP(*(.hook_lfoname2)) }
  .hook_rlp0193de2a 0x0193DE2A : { KEEP(*(.hook_rlp0193de2a)) }
  .hook_rlp01968c34 0x01968C34 : { KEEP(*(.hook_rlp01968c34)) }
  .hook_rlp01981eda 0x01981EDA : { KEEP(*(.hook_rlp01981eda)) }
  .hook_rlp019e4a18 0x019E4A18 : { KEEP(*(.hook_rlp019e4a18)) }
  .hook_rlp01a2d388 0x01A2D388 : { KEEP(*(.hook_rlp01a2d388)) }
  .hook_rlp01a30c3c 0x01A30C3C : { KEEP(*(.hook_rlp01a30c3c)) }
  .hook_rlp01a48fe8 0x01A48FE8 : { KEEP(*(.hook_rlp01a48fe8)) }
  .hook_t4scr 0x01A50560 : { KEEP(*(.hook_t4scr)) }
  _midi_apply_synth = 0x019CCE68;   /* LfoMidi::apply_synth / apply_fx / apply_drum (quad LFO stubs) */
  _midi_apply_fx = 0x019CD104;     /* FX object (vtable 0x0191086C) */
  _midi_apply_drum = 0x019CD048;   /* drum object (vtable 0x0191084C) */
  .hook_usbdesc 0x01A6ED96 : { KEEP(*(.hook_usbdesc)) }
  .hook_usbiso1 0x019E151C : { KEEP(*(.hook_usbiso1)) }
  .hook_usbiso2 0x019E161C : { KEEP(*(.hook_usbiso2)) }
  .hook_usbiso3 0x019E1812 : { KEEP(*(.hook_usbiso3)) }
  .hook_ciservice 0x019F0A24 : { KEEP(*(.hook_ciservice)) }
  .hook_sqlcache 0x0196F942 : { KEEP(*(.hook_sqlcache)) }
  .hook_taperase 0x0191B9F0 : { KEEP(*(.hook_taperase)) }
  .hook_clipsvc 0x019F0A2A : { KEEP(*(.hook_clipsvc)) }
  .hook_clipdrop 0x0191B65A : { KEEP(*(.hook_clipdrop)) }
  .hook_clipdropall 0x0191B730 : { KEEP(*(.hook_clipdropall)) }
  .hook_cliplift 0x0191B89C : { KEEP(*(.hook_cliplift)) }
  .hook_cliplftall 0x0191B974 : { KEEP(*(.hook_cliplftall)) }
  .hook_split1 0x01A56F24 : { KEEP(*(.hook_split1)) }
  .hook_split2 0x01A57690 : { KEEP(*(.hook_split2)) }
  .hook_split3 0x01A5769C : { KEEP(*(.hook_split3)) }
  .hook_join 0x01A577C6 : { KEEP(*(.hook_join)) }
  .hook_recadd1 0x01A5828A : { KEEP(*(.hook_recadd1)) }
  .hook_recadd2 0x01A5830C : { KEEP(*(.hook_recadd2)) }
  .hook_recadd3 0x01A5838E : { KEEP(*(.hook_recadd3)) }
  .hook_recadd4 0x01A58432 : { KEEP(*(.hook_recadd4)) }
  .hook_recadd5 0x01A5857E : { KEEP(*(.hook_recadd5)) }
  .hook_recstart 0x01A584D0 : { KEEP(*(.hook_recstart)) }
  .hook_tapewrite 0x01A54842 : { KEEP(*(.hook_tapewrite)) }
  .hook_taperead 0x01A5478C : { KEEP(*(.hook_taperead)) }
  .hook_disk1 0x01964336 : { KEEP(*(.hook_disk1)) }
  .hook_disk2 0x0196443E : { KEEP(*(.hook_disk2)) }
  .hook_disk3 0x01964616 : { KEEP(*(.hook_disk3)) }
  .hook_disk4 0x01964CFE : { KEEP(*(.hook_disk4)) }
  .hook_savesvc 0x019F0A3C : { KEEP(*(.hook_savesvc)) }
  .hook_stampsyn 0x019AD220 : { KEEP(*(.hook_stampsyn)) }
  .hook_stampdrm 0x019AD5A6 : { KEEP(*(.hook_stampdrm)) }
  .hook_vcdown 0x01A85750 : { KEEP(*(.hook_vcdown)) }
  .hook_vcup 0x01A85840 : { KEEP(*(.hook_vcup)) }
  .hook_tapepre 0x01A5CFA8 : { KEEP(*(.hook_tapepre)) }
  .hook_tlookup 0x01A54D5C : { KEEP(*(.hook_tlookup)) }
  .hook_altin 0x019E193C : { KEEP(*(.hook_altin)) }
  .hook_dpkeep 0x01A044A8 : { KEEP(*(.hook_dpkeep)) }
  .hook_dpload 0x01A04BC0 : { KEEP(*(.hook_dpload)) }
  .hook_frsnap 0x019C9D04 : { KEEP(*(.hook_frsnap)) }
  .hook_pparse1 0x01995680 : { KEEP(*(.hook_pparse1)) }
  .hook_pparse2 0x0199F210 : { KEEP(*(.hook_pparse2)) }
  .hook_pparse3 0x0199FA4E : { KEEP(*(.hook_pparse3)) }
  .hook_synthload 0x01A051F8 : { KEEP(*(.hook_synthload)) }
  .hook_smpover 0x01A05984 : { KEEP(*(.hook_smpover)) }
  .hook_diskprobe 0x0199DD7A : { KEEP(*(.hook_diskprobe)) }
  .hook_dpbrowse 0x01977900 : { KEEP(*(.hook_dpbrowse)) }
  .hook_usbbuf1 0x01A69730 : { KEEP(*(.hook_usbbuf1)) }
  .hook_usbbuf2 0x01A69740 : { KEEP(*(.hook_usbbuf2)) }
  .hook_opzget 0x019E0CFC : { KEEP(*(.hook_opzget)) }
  .hook_recA 0x019AC8B4 : { KEEP(*(.hook_recA)) }
  .hook_recB 0x019ACC7C : { KEEP(*(.hook_recB)) }
  .hook_recend 0x019DEEF2 : { KEEP(*(.hook_recend)) }
  .hook_opzset 0x019E3540 : { KEEP(*(.hook_opzset)) }
  _midi_rx_parse_next = 0x019E348E;   /* end of the SysEx dispatch in midi_rx_parse */
  .hook_devboot 0x019F01B8 : { KEEP(*(.hook_devboot)) }
  .hook_devrx 0x019E3CC8 : { KEEP(*(.hook_devrx)) }
  .hook_inputbus 0x019674F8 : { KEEP(*(.hook_inputbus)) }
  /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) }
  .hook_dsfactory 0x1967984 : { KEEP(*(.hook_dsfactory)) }
  .hook_dstype 0x19b9810 : { KEEP(*(.hook_dstype)) }
  .hook_dsnormalize 0x1a037a8 : { KEEP(*(.hook_dsnormalize)) }
  .hook_dsscreen 0x1a3bfee : { KEEP(*(.hook_dsscreen)) }
  .hook_dsjsonsave 0x19fffba : { KEEP(*(.hook_dsjsonsave)) }
  .hook_dsjsonload 0x1a00630 : { KEEP(*(.hook_dsjsonload)) }
  .hook_dspresetquery 0x1a0502a : { KEEP(*(.hook_dspresetquery)) }
  .hook_dspresetcopy 0x193f5c2 : { KEEP(*(.hook_dspresetcopy)) }
  .hook_dssnapread 0x19ad554 : { KEEP(*(.hook_dssnapread)) }
  .hook_dssnapsave 0x19ad776 : { KEEP(*(.hook_dssnapsave)) }
  _kn_ds_stock_trigger = 0x1970de6;
  _kn_ds_stock_render = 0x1970ee8;
  _kn_ds_stock_release = 0x1970e7e;
  _kn_ds_stock_status = 0x1970e5c;
}
