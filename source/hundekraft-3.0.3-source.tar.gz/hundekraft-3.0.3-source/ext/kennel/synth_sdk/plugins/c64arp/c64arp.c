/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "../../op1_feature_seq.h"
#include "../../op1_synth.h"
#define OCC_TEXT_IMPL
#include "../../seq/seq_text.h"
#include "arp.h"
static arp_state bank[2];
static unsigned page[2];static int accum[2][4];
#ifdef OP1_HOST
#define MODE() 0
#else
#define MODE() (*(volatile int *)0x01DE4C40==1)
#endif
#ifndef OP1_HOST
static sq_store_t store;
static int clamp(int x,int a,int b){return x<a?a:x>b?b:x;}
int arp_output_on(int m,int n,int k,int v){return op1_seq_note_on(m,n,k,v);}
void arp_output_off(int id){op1_seq_note_off(id);}
static void dirty(void){sq_store_dirty(&store);}
static void turn(int mode,int knob,int delta,int shift){
 if((unsigned)mode>1||(unsigned)knob>3)return;
 arp_state *s=&bank[mode];arp_config *c=&s->cfg;int *acc=&accum[mode][knob];*acc+=delta;
 int d=*acc/1024;*acc-=d*1024;if(!d)return;
 if(shift){
  /* Table edits switch TABLE OFF back on so the change can be heard. */
  if(knob==0){c->length=clamp(c->length+d,1,16);c->preset=8;arp_set_table(s,1);}
  else if(knob==3)c->gate=clamp(c->gate+d,10,100);
 }else if(page[mode]){
  unsigned sel=c->select;
  if(knob==0)c->select=clamp((int)sel+d,0,c->length-1);
  if(knob==1){c->offset[sel]=clamp(c->offset[sel]+d,-24,24);c->preset=8;arp_set_table(s,1);}
  if(knob==2){c->dwell[sel]=clamp(c->dwell[sel]+d,1,8);c->preset=8;arp_set_table(s,1);}
  if(knob==3)c->gate=clamp(c->gate+d,10,100);
 }else{
  /* Blue left of MAJOR, or left from CUSTOM, is TABLE OFF; turning right keeps the old table. */
  if(knob==0){
   if(!c->table){if(d>0)arp_set_table(s,1);}
   else if(d<0&&(c->preset==8||c->preset+d<0))arp_set_table(s,0);
   else arp_preset(s,(unsigned)clamp(c->preset+d,0,7));
  }
  if(knob==1)c->rate=clamp(c->rate+d,0,7);
  if(knob==2)c->octaves=clamp(c->octaves+d,1,4);
  if(knob==3)arp_set_latch(s,d>0); /* Stock arpeggio: orange right holds. */
 }
 if(c->select>=c->length)c->select=c->length-1;
 arp_bounds_changed(s);
 dirty();
}
static void press(int mode,int knob,int shift){(void)knob;(void)shift;page[mode]^=1;}
static int key(int mode,int code,int pressed,int shift){(void)mode;(void)pressed;(void)shift;return code>=10&&code<=12;}
static int down(void *self,int k){
 (void)self;if(k<0||k>23)return 0;int m=MODE();
 int slot=*(volatile int *)(m?0xFF8016D8:0xFF8016D4)&7;
 int octave=((const int *)(m?0x01DFE500:0x01DFE4E0))[slot];
 bank[m].run=1; /* The stock sequencer switch decides whether this player receives keys. */
 arp_key(&bank[m],(unsigned)k,k+53+octave*12,1);return 1;
}
static int up(void *self,int k){(void)self;if(k>=0&&k<24)arp_key(&bank[MODE()],(unsigned)k,0,0);return 1;}
static int nop(void *self){(void)self;return 0;}
static void reset(void *self){(void)self;arp_stop(&bank[MODE()]);}
static void tick(void *self,int n){(void)self;(void)n;bank[MODE()].run=1;arp_tick(&bank[MODE()],MODE());}
static void stop(void *self){(void)self;arp_stop(&bank[0]);arp_stop(&bank[1]);}
static const uint32_t vt[16]={0,0,0,(uint32_t)nop,0,(uint32_t)down,0,(uint32_t)up,0,(uint32_t)reset,0,(uint32_t)tick,0,(uint32_t)nop,0,(uint32_t)stop};
static struct {const uint32_t *vt;uint32_t pad[7];} player={vt,{0}};
/* Settings only: sounding IDs, held keys, latch root and playback never persist. */
static int serialize(int m,char *out,int n){
 const arp_config *c=&bank[m].cfg;int v[40];v[0]=2;v[39]=c->table;v[1]=c->length;v[2]=c->rate;v[3]=c->octaves;v[4]=c->gate;v[5]=c->latch;v[6]=c->preset;
 for(int i=0;i<16;i++){v[7+i*2]=c->offset[i]+24;v[8+i*2]=c->dwell[i];}
 return sq_join(out,n,v,40);
}
static int parse(int m,const char *text,int len){
 /* Version 1 (3.0.2 and earlier) has no TABLE OFF field: load it with the table on. */
 int v[40];int k=sq_split(text,len,v,40);if(k==39&&v[0]==1)v[39]=1;else if(k!=40||v[0]!=2||v[39]>1)return 0;
 if(v[1]<1||v[1]>16||v[2]>7||v[3]<1||v[3]>4||v[4]<10||v[4]>100||v[5]>1||v[6]>8)return 0;
 for(int i=0;i<16;i++)if(v[7+i*2]>48||v[8+i*2]<1||v[8+i*2]>8)return 0;
 arp_config *c=&bank[m].cfg;c->length=v[1];c->rate=v[2];c->octaves=v[3];c->gate=v[4];c->latch=v[5];c->preset=v[6];c->select=0;c->table=v[39];
 for(int i=0;i<16;i++){c->offset[i]=v[7+i*2]-24;c->dwell[i]=v[8+i*2];}return 1;
}
static char sql[512];
static sq_store_t store={.name="c64arpseq",.ser=serialize,.parse=parse,.sql=sql,.cap=sizeof sql,.maxlen=256};
static void *get_player(void){
 if(!store.ready){arp_init(&bank[0]);arp_init(&bank[1]);sq_store_load(&store);}return &player;
}
static void midi_start(void){for(int m=0;m<2;m++){if(bank[m].sounding>=0)arp_output_off(bank[m].sounding);bank[m].sounding=-1;bank[m].started=0;bank[m].step=bank[m].octave=0;bank[m].elapsed=0;}}
#else
void c64arp_host_state(arp_state **s,unsigned **p){*s=&bank[0];*p=&page[0];}
#endif
#ifdef OP1_HOST
static int test_ready;
#define C64ARP_READY test_ready
#else
#define C64ARP_READY store.ready
#endif
/* Observe the ordinary STOP key even when tape was already stopped. Do not
 * consume it: stock transport and the other features still receive the key. */
static int input(const op1_input *in){
 if(C64ARP_READY&&in->type==OP1_IN_KEY&&in->code==0x23&&in->pressed){arp_stop(&bank[0]);arp_stop(&bank[1]);}
 return 0;
}
#ifdef OP1_HOST
int c64arp_host_input(const op1_input *in,int ready){test_ready=ready;return input(in);}
#endif
static void text(void *r,int x,int y,int scale,const char *value,const uint8_t *color){
#ifdef OP1_HOST
 /* The shared stroke font deliberately has no lowercase glyphs. Validate every
  * label/value actually passed by the production screen in host fixtures. */
 for(const char *p=value;*p;p++)if(*p!=' '){unsigned k=0;while(k<sizeof sq_fc-1&&sq_fc[k]!=*p)k++;if(k==sizeof sq_fc-1)__builtin_trap();}
#endif
 /* Match the configured upward shift of the generated illustration. */
 sq_text(r,OP1_Q10(x),OP1_Q10(y-4),scale,value,768,color);
}
static void screen_init(void *scr){(void)scr;}
static void screen_update(void *scr,int dt){
 op1_screen_draw_cached(scr, dt, 0);void *r=op1_raster();arp_state *s=&bank[MODE()];arp_config *c=&s->cfg;
 const uint8_t white[4]={232,232,232,255},blue[4]={105,142,255,255},green[4]={0,223,160,255},red[4]={255,49,90,255};
 const uint8_t *col[4]={blue,green,white,red};const char *names[4];int values[4];
 const char *presets[9]={"MAJOR","MINOR","MAJ7","MIN7","FIFTH","SUS4","UPDOWN","MINDOWN","CUSTOM"};
 const char *rates[8]={"1/4","1/8","1/8T","1/16","1/16T","1/32","1/32T","1/64"};
 if(page[MODE()]){names[0]="STEP";names[1]="OFFSET";names[2]="DWELL";names[3]="GATE";values[0]=c->select+1;values[1]=c->offset[c->select];values[2]=c->dwell[c->select];values[3]=c->gate;}
 else{names[0]="TABLE";names[1]="RATE";names[2]="OCTAVES";names[3]="HOLD";values[0]=c->preset;values[1]=c->rate;values[2]=c->octaves;values[3]=c->latch;}
 for(int i=0;i<4;i++){
  char t[20];char *p=t;
  if(!page[MODE()]&&i==0)p=sq_cat(p,c->table?presets[c->preset]:"OFF");
  else if(!page[MODE()]&&i==1)p=sq_cat(p,rates[c->rate]);
  else if(!page[MODE()]&&i==3)p=sq_cat(p,c->latch?"ON":"OFF");
  else{if(values[i]<0)*p++='-';sq_num(p,(unsigned)(values[i]<0?-values[i]:values[i]),1);}
  text(r,226,18+i*28,OP1_Q10(1.1),names[i],col[i]);
  text(r,226,28+i*28,OP1_Q10(1.5),t,white);
 }
 char status[30];char *p=sq_cat(status,page[MODE()]?"EDIT ":"PLAY ");if(c->latch)p=sq_cat(p,"HOLD ");
 if(c->table){p=sq_num(p,s->step+1,1);*p++='/';sq_num(p,c->length,1);}
 else{unsigned n=arp_note_count(s);p=sq_cat(p,"KEYS ");p=sq_num(p,n?s->step%n+1:0,1);*p++='/';sq_num(p,n,1);}
 text(r,14,143,OP1_Q10(1.1),status,white);
}
const op1_screen_t SCREEN_c64arp={screen_init,screen_update};
#ifndef OP1_HOST
static const op1_seq_type_t type={.name="c64arp",.player=get_player,.svg="c64arp.svg",.screen=&SCREEN_c64arp,.key=key,.press=press,.turn=turn,.midi_start=midi_start};
const op1_feature_t FEATURE_c64arp={.api=OP1_FEATURE_API,.priority=1000,.name="c64arp",.seq=&type,.input=input};

#endif
