/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#ifndef C64ARP_H
#define C64ARP_H
#include <stdint.h>
#define ARP_STEPS 16
typedef struct {
 uint8_t length,rate,octaves,gate,latch,preset,select;
 int8_t offset[ARP_STEPS];uint8_t dwell[ARP_STEPS];
 uint8_t table; /* 0: TABLE OFF, cycle the held notes in pitch order. */
} arp_config;
typedef struct {
 arp_config cfg;int16_t keys[24],root,sounding,rootkey;
 uint8_t run,step,octave,started;uint16_t elapsed;
 uint32_t down; /* Physical keys; with hold on, keys[] keeps released notes. */
} arp_state;
void arp_init(arp_state *s);
void arp_preset(arp_state *s,unsigned n);
void arp_key(arp_state *s,unsigned key,int note,int pressed);
void arp_tick(arp_state *s,int mode);
void arp_stop(arp_state *s);
void arp_bounds_changed(arp_state *s);
void arp_set_latch(arp_state *s,int on);
void arp_set_table(arp_state *s,int on);
unsigned arp_note_count(const arp_state *s);
void arp_output_off(int id);
int arp_output_on(int mode,int note,int key,int velocity);
#endif
