/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "arp.h"
#include <assert.h>
#include <stdio.h>
static int ons,offs,last,ids;
int arp_output_on(int m,int n,int k,int v){(void)m;(void)k;(void)v;ons++;last=n;return ids++;}
void arp_output_off(int id){assert(id>=0);offs++;}
int main(void){
 arp_state s,t;arp_init(&s);arp_init(&t);assert(s.root==-1&&s.sounding==-1&&!s.run);
 s.run=1;for(int i=0;i<200;i++)arp_tick(&s,0);assert(!ons);
 arp_key(&s,0,60,1);arp_tick(&s,0);assert(last==60&&ons==1);
 for(int i=0;i<24;i++)arp_tick(&s,0);assert(last==64&&ons==2&&offs==1);
 for(int i=0;i<24;i++)arp_tick(&s,0);assert(last==67&&ons==3&&offs==2);
 arp_key(&s,0,60,0);assert(s.root==-1&&s.sounding==-1&&offs==3);
 s.cfg.latch=1;arp_key(&s,0,60,1);arp_key(&s,0,60,0);arp_tick(&s,0);assert(s.root==60&&s.sounding>=0);
 arp_stop(&s);assert(s.root==-1&&s.sounding==-1&&!s.run);int count=ons;
 for(int i=0;i<100;i++)arp_tick(&s,0);assert(ons==count);
 arp_init(&s);s.run=1;s.cfg.dwell[0]=2;arp_key(&s,0,60,1);arp_tick(&s,0);
 for(int i=0;i<47;i++)arp_tick(&s,0);assert(last==60);arp_tick(&s,0);assert(last==64);
 arp_stop(&s);assert(ons==offs);
 arp_init(&s);s.run=1;s.cfg.rate=7;s.cfg.offset[0]=-24;s.cfg.octaves=4;arp_key(&s,0,12,1);arp_tick(&s,0);assert(s.sounding==-1);
 for(int i=0;i<1000;i++)arp_tick(&s,0);arp_stop(&s);assert(ons==offs);
 arp_init(&s);s.run=1;s.cfg.octaves=4;s.octave=3;arp_key(&s,0,60,1);arp_tick(&s,0);assert(last==96);
 s.cfg.octaves=1;int offbefore=offs;arp_bounds_changed(&s);assert(offs==offbefore+1&&s.sounding==-1&&s.octave==0&&!s.started);
 arp_tick(&s,0);assert(last==60&&s.run&&s.root==60);arp_stop(&s);assert(ons==offs);
 /* TABLE OFF cycles held notes in pitch order, whatever order they were pressed. */
 arp_init(&s);s.run=1;arp_set_table(&s,0);arp_key(&s,1,67,1);arp_key(&s,2,60,1);arp_key(&s,3,64,1);
 int seq[7];for(int i=0;i<7;i++){arp_tick(&s,0);seq[i]=last;for(int k=0;k<23;k++)arp_tick(&s,0);}
 assert(seq[0]==60&&seq[1]==64&&seq[2]==67&&seq[3]==60&&seq[6]==60);
 s.cfg.octaves=2;arp_bounds_changed(&s);for(int i=0;i<6;i++){arp_tick(&s,0);seq[i]=last;for(int k=0;k<23;k++)arp_tick(&s,0);}
 assert(seq[0]==64&&seq[1]==67&&seq[2]==72&&seq[4]==79&&seq[5]==60);
 /* Releasing shrinks the set without hold; the last key stops it. */
 s.cfg.octaves=1;arp_bounds_changed(&s);arp_key(&s,1,0,0);assert(arp_note_count(&s)==2);
 for(int i=0;i<4;i++){arp_tick(&s,0);seq[i]=last;for(int k=0;k<23;k++)arp_tick(&s,0);}
 assert(seq[0]!=67&&seq[1]!=67&&seq[2]!=67&&seq[3]!=67);
 arp_key(&s,2,0,0);arp_key(&s,3,0,0);assert(s.root==-1&&s.sounding==-1);
 /* Hold keeps a released chord; the next press after a full release starts a new one. */
 arp_set_latch(&s,1);arp_key(&s,0,60,1);arp_key(&s,1,63,1);arp_key(&s,0,0,0);arp_key(&s,1,0,0);
 assert(arp_note_count(&s)==2&&s.root>=0);arp_tick(&s,0);assert(last==60);
 arp_key(&s,5,70,1);assert(arp_note_count(&s)==1);arp_key(&s,6,72,1);assert(arp_note_count(&s)==2);
 arp_key(&s,5,0,0);arp_set_latch(&s,0);assert(arp_note_count(&s)==1&&s.root==72);
 arp_key(&s,6,0,0);assert(s.root==-1&&s.sounding==-1);
 arp_set_table(&s,1);assert(s.cfg.length==3&&s.cfg.offset[1]==4);arp_stop(&s);assert(ons==offs);
 assert(t.root==-1&&t.sounding==-1&&!t.run);
 puts("c64arp timing, dwell, offsets, latch/release, table off, hold set, stop and mode isolation PASS");
}
