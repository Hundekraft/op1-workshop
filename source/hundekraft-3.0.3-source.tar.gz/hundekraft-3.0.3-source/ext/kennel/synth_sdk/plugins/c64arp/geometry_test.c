/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#define main unused_harness_main
#include "../../harness/screen_harness.c"
#undef main
#include "arp.h"
#include "../../op1_feature.h"
#include <assert.h>
static void nothing(int p){(void)p;}
static void render(int p,int16_t *b,const int16_t *q){(void)p;(void)b;(void)q;}
const op1_fx_t FX_dummy={nothing,render,{0}};
void c64arp_host_state(arp_state **s,unsigned **p);
int arp_output_on(int m,int n,int k,int v){(void)m;(void)n;(void)k;(void)v;return 0;}
static unsigned stop_offs;
void arp_output_off(int id){assert(id>=0);stop_offs++;}
int c64arp_host_input(const op1_input *in,int ready);
int main(void){
 arp_state *s;unsigned *page;c64arp_host_state(&s,&page);arp_init(s);
 for(unsigned pg=0;pg<2;pg++)for(unsigned preset=0;preset<10;preset++)for(int end=0;end<2;end++){
  /* preset 9: TABLE OFF with a full held set. */
  s->cfg.table=preset<9;for(int k=0;k<24;k++)s->keys[k]=preset==9&&end?(int16_t)(40+k):-1;
  *page=pg;s->cfg.preset=preset<9?preset:8;s->cfg.length=16;s->cfg.select=15;s->cfg.offset[15]=end?24:-24;s->cfg.dwell[15]=end?8:1;s->cfg.gate=end?100:10;
  s->cfg.rate=end?7:0;s->cfg.octaves=end?4:1;s->cfg.latch=end;s->step=15;
  SCREEN.update(0,1);
  for(int i=0;i<nlines;i++){
   int h=lines[i].w/2;
   assert(lines[i].x0-h>=0&&lines[i].x1-h>=0&&lines[i].x0+h<320*1024&&lines[i].x1+h<320*1024);
   assert(lines[i].y0-h>=0&&lines[i].y1-h>=0&&lines[i].y0+h<160*1024&&lines[i].y1+h<160*1024);
  }
 }
 arp_init(s);arp_init(s+1);s[0].run=s[1].run=1;s[0].root=60;s[1].root=72;s[0].sounding=5;s[1].sounding=6;
 op1_input in={.type=OP1_IN_KEY,.code=0x23,.pressed=0};
 assert(c64arp_host_input(&in,1)==0&&s[0].run&&s[1].run&&!stop_offs);
 in.pressed=1;assert(c64arp_host_input(&in,0)==0&&s[0].run&&!stop_offs);
 in.type=OP1_IN_KNOB;assert(c64arp_host_input(&in,1)==0&&s[0].run&&!stop_offs);
 in.type=OP1_IN_KEY;assert(c64arp_host_input(&in,1)==0&&!s[0].run&&!s[1].run&&s[0].root==-1&&s[1].root==-1&&stop_offs==2);
 puts("c64arp actual stroke text geometry40 states PASS");
}
