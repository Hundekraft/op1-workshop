/* Oxbow: zvenson's OberVave, an 8-voice American poly of 1979-84 in the OB-X / OB-8 manner from his FM-1 firmware, as a
 * kennel synth plugin (loaded from oxbow.knl). Per voice: two oscillators (saw, pulse, saw+pulse; OSC 2 with hard
 * sync, X-MOD into OSC 1, the filter envelope on its pitch), noise, drive, a state-variable filter (LP 12, HP 12,
 * BP 12, notch, LP 24, SEM morph), a filter ADSR with RC curves and the stock T2 amp envelope, one LFO, and each voice card's own
 * small tune, cutoff and envelope offsets plus a slow pitch drift ("vintage").
 *
 * Macro controls (2026-10-28: each knob moves several voicing settings along curves that stay musical; see macros()):
 * blue   (knob 0) TONE: cutoff and key tracking
 * green  (knob 1) SHAPE: PULSE, SAW+PULSE, SAW+SAW, FIFTH, SYNC, X-MOD, each with its own continuous control
 * white  (knob 2) CONTOUR: the filter envelope's amount, times and sustain, velocity to cutoff, a little resonance
 * orange (knob 3) WARMTH: OSC 2 detune, the vintage drift and voice-card spread
 * Pressed (page 2, saved with the sound; 0 = the macros' own voicing):
 * blue   RESONANCE (word 5), added to the base and CONTOUR's share
 * green  FILTER TYPE: LP 12, HP 12, BP 12, NOTCH, LP 24, SEM (word 6, as before)
 * white  DRIVE: drive before the filter (word 7, as before)
 * -DOXBOW_LEGACY_MAP builds the pre-macro raw controls (bit-exact with the earlier code: exact_check).
 *
 * The OP-1 allocates six voices and provides pitch, glide and the sole amplitude
 * envelope (T2). No internal programs or second amp envelope remain. The original
 * filter envelope and per-card drift remain; normal OP-1 presets hold sound choices.
 * Instrument state (the LFO, the cutoff and resonance slew) advances once per block, from the first
 * voice rendered in it (voices render in ascending order, as EVA does).
 * Synthesis runs at 22.05 kHz with control steps every eight internal samples;
 * pitch/control timing matches the native 44.1 kHz interface. Filter coefficients
 * use the internal sample rate; four-point interpolation reconstructs each output
 * block. Neutral voice constants replace the former program-bank setup. T2 is
 * still the sole amplitude envelope.
 *
 * From OberVave (github.com/zvenson/obervave a2fb3d0, firmware/src/obv_engine.h), the voice code nearly unchanged.
 * Copyright (C) 2026 zvenson (the synth), 2026 Hundekraft (the kennel port). Used in kennel with zvenson's
 * permission (2026-10-15). GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "op1_plugin.h"
#include "obv_dsp.h"
#include "obv_params.h"
#include "oxbow_geom.h"

/* Match the 22.05 kHz output bus. Control ticks keep their original duration;
 * native pitch increments remain expressed at 44.1 kHz. */
#define OBV_NATIVE_HALF_RATE 1
#define OBV_SAMPLES (OP1_BLOCK / 2)
_Static_assert(CTL == 8, "Oxbow ramp and table control rate must agree");
#define ENV_ONE (1 << 24)
#define LEVEL_FLOOR 2048                        /* -78 dB: a release below this ends the voice */
#define TICK (2 * (int)CTL)                     /* internal samples per control tick: 16, matching 32 native samples */
#define NT (OBV_SAMPLES / TICK)                   /* control ticks per block: 4 */
#define NA ((int)(OBV_SAMPLES / CTL))             /* envelope and amp steps per block (every CTL = 8 internal samples): 8 */
#define OUT_GAIN 26400                          /* Q15 output scaling; +2.4 dB (level pass 2026-10-29, was 20000): the
                                                   most the amp_up assert below allows without a saturating store */

enum { E_IDLE, E_ATT, E_DEC, E_SUS, E_REL };
typedef struct { uint32_t stage; int32_t level; } env_t;   /* level Q24 */

/* ---- a voice's numbers that hold through the block (the voice card, the note) */
typedef struct {
    int32_t fka, fkd, fkr;       /* envelope coefficients */
    int32_t p8, p2, cut, velg;                  /* pitch offsets, the cutoff's fixed part, the velocity gain */
    uint32_t spread;
    uint8_t lfo_on, to1, to2, pw_to1, pw_to2;   /* flags */
} vblk_t;

typedef struct {
    osc_t o1, o2;
    rcp_t r1, r2;
    uint32_t noise;
    env_t fe;
    svf_state_t f1, f2;
    svf_coef_t c1, c2;
    uint32_t inc1, inc2, pw1, pw2;              /* this tick's oscillator settings */
    uint32_t pk_base;                           /* the inputs inc1 / inc2 were made from: the OP-1's step and the pitch offsets (the pair (0, 0) gives 0) */
    int32_t pk_p1, pk_p2;
    int32_t up3,up2,up1;
    int32_t amp0, amp1;                         /* Q15: amp1 the amp at the block's end (the next one starts there) */
    int32_t drift;                              /* the vintage random walk */
    uint32_t lfo_blk;                           /* ticks since the note on (LFO delay / fade) */
    int32_t lfo_fade;                           /* Q15 */
    int32_t c1_cut, c1_k, c2_cut;               /* the inputs c1 / c2 were made from (made once they differ) */
    uint8_t note, vel, spare, fresh;            /* fresh: note and velocity still to be read in render (spare: the
                                                   former gate, now obv_gate) */
    uint8_t c1_ok, c2_ok;
    uint8_t blk_note, blk_vel;                  /* blk's inputs with blk_gen (voice_block) */
    uint32_t blk_gen;
    vblk_t blk;                                 /* the per-voice cache, kept with the voice's state */
} voice_t;

/* the key gate per voice: note_on sets it, note_off (VoiceCtl's thread) clears it, render reads it. Kept out of
 * voice_t so that note_off never writes the voice state. */
static volatile int32_t obv_gate[OP1_VOICES];

/* One neutral voice; normal OP-1 patches store every exposed sound choice. */
#define pv OBV_DEF


/* vintage: each voice card has its own small offsets, scaled by the neutral voice VINTAGE */
static const int16_t VINT_TUNE8[OP1_VOICES] = {-20, 12, 7, -15, 18, -9};        /* +-8 cents */
static const int16_t VINT_CUT8[OP1_VOICES] = {-300, 250, 120, -380, 60, 330};   /* +-1.5 semitones */
static const int8_t VINT_ENV[OP1_VOICES] = {10, -6, 14, -12, 3, -16};           /* /128: +-12 % on the times */

/* ---- instrument state, once per block (render only: block_shared writes it in the block's first call, the other
 * voices read it): part of the leased state (obv_hot_t below), reached as G.name */
typedef struct {
    int32_t t_cut[NA];                          /* the slewed CUTOFF at each step, Q8 semitones */
    uint32_t t_lfo_ph[NT], t_rnd_a[NT], t_rnd_b[NT];   /* the LFO at each control tick of this block */
    /* The voicing the macros set each block (block_shared); the DSP below reads only these. */
    uint32_t w1, w2, ftype, sync_on, xmod_q;
    int32_t lvl1, lvl2, sus_f, fenv_amt, reso_k_, drive_q12, vint, env_o2, lfo_pwd;
    uint32_t pw1_base, pw2_base, prog_gen;      /* prog_gen: bumped when an input of the per-voice cache (voice_block) moves */
    int32_t keytrk, velflt, det_fine8, p2_iv;   /* p2_iv: OSC 2's interval, Q8 semitones */
    uint8_t e_fa, e_fd, e_fr, pad;              /* ENV_K_* indices: attack 0..60, decay / release 60..100 */
    int32_t last_voice;
    uint32_t lfo_ph, lfo_rnd_a, lfo_rnd_b, rnd_state;
    int32_t cut_sm, reso_sm;
    int32_t drive_d, reso_prev;                 /* (the inputs of drive_q12 / reso_k) */
    int32_t cut_t, reso_t;                      /* the macros' cutoff and resonance targets */
    int32_t op1[4], op2[4];                     /* ox_osc's { lvl, step, pulse, ticks } per oscillator (knob_update) */
    int16_t mk[8];                              /* the knob words they were made from (word 4 not used) */
    int32_t mk_ok;
} inst_t;
#define G_INIT { .keytrk = 64, .velflt = 40, .vint = 30, .lvl1 = (110 * 110) >> 7, .lvl2 = (100 * 100) >> 7, \
                 .sus_f = 40 * (ENV_ONE / 127), .pw1_base = (64u << 25) + (1u << 24), .pw2_base = (64u << 25) + (1u << 24), \
                 .e_fa = 20, .e_fd = 70, .e_fr = 60, .prog_gen = 1, .rnd_state = 0x9E3779B9u, .cut_sm = -1, \
                 .drive_d = -1, .reso_prev = -1, .last_voice = OP1_VOICES }
#define LFO_RATE 56                             /* the PWM LFO, 0.8 Hz (LFO_INC index) */
static const int32_t lfo_pd=0,lfo_fd=0,lfo_ad=0,uni_det8=0;
static const int32_t lvln=0;
static const int32_t morph_q=0;
static const uint32_t lfo_dl=0;                         /* LFO delay in ticks */
static const int32_t lfo_fstep=32768;                       /* the LFO fade-in per tick after the delay, Q15 */

/* The persistent state: the voices and the instrument state. It lives in the L1 pool's synth partition when the core
 * gives it (op1_l1_claim_state, OP1_L1_API 2): the core copies it in from obv_home and back when another engine takes
 * the partition or the pool goes off. render and note_on claim first (obv_claim) and reach it through obv_hp for that
 * call only; note_off (obv_gate) and the screen (obv_blocks, obv_vblk, obv_venv) never touch obv_home. */
typedef struct {
    voice_t v[OP1_VOICES];
    inst_t g;
} obv_hot_t;
static obv_hot_t obv_home __attribute__((aligned(32))) = { .g = G_INIT };
static obv_hot_t *obv_hp = &obv_home;
#define G (obv_hp->g)
#define reso_k (G.reso_k_)                      /* (by its old name: harness/oxbow_test.c reads it) */

static volatile uint32_t obv_blocks;            /* for the screen: rendered blocks */
static volatile uint32_t obv_vblk[OP1_VOICES];  /* for the screen: obv_blocks when each voice last sounded */
static volatile int32_t obv_venv[OP1_VOICES];   /* for the screen: each voice's filter envelope, Q15 */

/* Filter selector: compact cyclic steps. Wave uses six stable full-range bands. */
static inline int32_t knob(const int16_t *k, int i) { return k[i] < 0 ? 0 : k[i]; }

/* Saturate before doubling, including pitches above the output Nyquist limit. */
static inline uint32_t phase_2x(uint32_t x)
{
    return x > 0x3fffffffu ? 0x7fffffffu : x << 1;
}

static int32_t lfo_shape(uint32_t ph, uint32_t shape, uint32_t ra, uint32_t rb)
{
    int32_t p;
    switch (shape) {
    case L_TRI:
        p = (int32_t)((ph + 0x40000000u) >> 15);
        return p < 65536 ? p - 32768 : 98303 - p;
    case L_SAW: return 32767 - (int32_t)(ph >> 16);
    case L_RAMP: return (int32_t)(ph >> 16) - 32768;
    case L_SQR: return ph < 0x80000000u ? 32767 : -32767;
    case L_SH: return (int32_t)(rb >> 16) - 32768;
    default: {                                  /* smooth random: a line from one random value to the next */
        int32_t a = (int32_t)(ra >> 16) - 32768, b = (int32_t)(rb >> 16) - 32768;
        return a + mulq24(b - a, (int32_t)(ph >> 8));
    }
    }
}

#ifndef OXBOW_LEGACY_MAP
/* a + (b - a) * f, f Q15 */
static inline int32_t lerp15(int32_t a, int32_t b, int32_t f) { return a + (((b - a) * f) >> 15); }

/* Level matching per SHAPE zone (oscillator levels as OberVave's (lvl * lvl) >> 7; oxbow_check.py measures the
 * zones within 2 dB of saw + saw on a held chord through the default filter) */
static const uint8_t ZONE_L1[6] = { 74, 80, 104, 104, 99, 102 }, ZONE_L2[6] = { 74, 80, 96, 97, 94, 106 };
#endif

/* The macros (main page) and the page-2 trims -> the voicing. Every input is a knob word; the curves are piecewise
 * linear in Q15 (no division). Shared by every voice, once per block.
 *   TONE    (word 0): cutoff 48..118 semitones above MIDI 8 at C4, key tracking 75 % -> 50 %
 *   SHAPE   (word 1): six zones, each with a continuous control: PULSE (width 50 -> 30 %, slow PWM), SAW+PULSE (OSC 2's
 *                     pulse the same), SAW+SAW (OSC 2 level 56 -> 100 %), FIFTH (OSC 2 +7, its level), SYNC (OSC 2 +7 -> +19 semitones
 *                     synced to OSC 1, the filter envelope sweeps it 4 -> 12 semitones), X-MOD (OSC 2 -> OSC 1 FM,
 *                     depth 24 -> 96)
 *   CONTOUR (word 2): the filter envelope: amount (squared) 0 -> 56, attack 54 -> 0.6 ms, decay 1.2 s -> 190 ms,
 *                     sustain 55 -> 4 %, velocity to cutoff 20 -> 60, resonance +0 -> +12
 *   WARMTH  (word 3): OSC 2 detune 1.2 -> 15.6 cents (squared), the vintage drift and voice-card spread 10 -> 80
 *   page 2: RESONANCE (word 5, adds to the 16 base, capped at 120), FILTER (word 6, as before), DRIVE (word 7, as before) */
static void macros(const int16_t *k, int32_t *cut_t, int32_t *reso_t)
{
#ifdef OXBOW_LEGACY_MAP                         /* the old raw controls (exact_check against the pre-macro hashes) */
    const int mode = knob(k, 5) * 6 >> 15;      /* saw, pulse, both, sync, cross-mod, fifth */
    *cut_t = (knob(k, 0) * 127) >> 7;
    *reso_t = (knob(k, 1) * 127) >> 7;
    G.fenv_amt = ((knob(k, 2) * 127) >> 15) - 64;
    G.det_fine8 = (knob(k, 3) * 128) >> 15;
    G.w1 = G.w2 = mode == 1 ? W_PLS : mode == 2 ? W_BOTH : W_SAW;
    G.sync_on = mode == 3; G.xmod_q = mode == 4 ? 96 : 0;
    G.p2_iv = mode == 5 ? 7 * 256 : mode == 3 || mode == 4 ? 12 * 256 : 0;
#else
    const int32_t tone = knob(k, 0), shape = knob(k, 1), cont = knob(k, 2), warm = knob(k, 3);
    const int32_t z = (shape * 6) >> 15, f = (shape * 6) & 32767;   /* SHAPE's zone and the position in it, Q15 */
    const int32_t c2 = (cont * cont) >> 15, wq = (warm * warm) >> 15;
    int32_t r;
    /* TONE */
    *cut_t = (48 << 8) + ((tone * 70) >> 7);
    G.keytrk = 96 - ((tone * 32) >> 15);
    /* SHAPE */
    G.w1 = z == 0 ? W_PLS : W_SAW;                /* SAW+PULSE: OSC 1 saw, OSC 2 pulse (one wave per oscillator) */
    G.w2 = z < 2 ? W_PLS : W_SAW;
    G.sync_on = z == 4; G.xmod_q = z == 5 ? (uint32_t)(24 + ((f * 72) >> 15)) : 0;
    G.p2_iv = z == 3 ? 7 * 256 : z == 4 ? (7 << 8) + ((f * 12) >> 7) : z == 5 ? 12 * 256 : 0;
    G.env_o2 = z == 4 ? 10 + ((f * 22) >> 15) : 0;
    G.lvl1 = (ZONE_L1[z] * ZONE_L1[z]) >> 7;
    G.lvl2 = z == 2 || z == 3 ? (lerp15(ZONE_L2[z] - 24, ZONE_L2[z], f) * lerp15(ZONE_L2[z] - 24, ZONE_L2[z], f)) >> 7
                            : (ZONE_L2[z] * ZONE_L2[z]) >> 7;
    G.pw1_base = z < 2 ? 0x80000000u - (uint32_t)f * 26214u : (64u << 25) + (1u << 24);   /* 50 % -> 30 % */
    G.pw2_base = z < 2 ? G.pw1_base + 0x04000000u : G.pw1_base;                                /* OSC 2 1.5 % wider */
    G.lfo_pwd = z < 2 ? 36 : 0;                   /* +-7 % PWM at 0.8 Hz on the pulse shapes */
    /* CONTOUR */
    G.fenv_amt = (c2 * 56) >> 15;
    G.e_fa = (uint8_t)lerp15(60, 2, cont);
    G.e_fd = (uint8_t)lerp15(100, 76, cont);
    G.e_fr = (uint8_t)(G.e_fd - 8);
    G.sus_f = lerp15(70, 5, cont) * (ENV_ONE / 127);
    G.velflt = lerp15(20, 60, cont);
    /* WARMTH */
    G.det_fine8 = 3 + ((wq * 37) >> 15);
    G.vint = 10 + ((warm * 70) >> 15);
    /* page 2: RESONANCE (with CONTOUR's share) */
    r = (16 << 8) + ((knob(k, 5) * 92) >> 7) + ((c2 * 12) >> 7);
    *reso_t = r > (120 << 8) ? 120 << 8 : r;
#endif
}

/* everything block_shared makes from the knob words alone (the macros, the filter type, the drive): only when a word
 * moved (the same words make the same values, so skipping it changes nothing) */
static __attribute__((noinline)) void knob_update(const int16_t *k)
{
    int32_t d, i;
    /* the voice cache's inputs: a change of any bumps G.prog_gen (a knob sweep rebuilds each voice's cache once) */
    const int32_t old[9] = { G.p2_iv, G.det_fine8, G.keytrk, G.velflt, G.vint, G.e_fa, G.e_fd, G.e_fr, G.lfo_pwd };
    macros(k, &G.cut_t, &G.reso_t);
    {
        const int32_t now[9] = { G.p2_iv, G.det_fine8, G.keytrk, G.velflt, G.vint, G.e_fa, G.e_fd, G.e_fr, G.lfo_pwd };
        for (i = 0; i < 9; i++) if (now[i] != old[i]) { G.prog_gen++; break; }
    }
    _Static_assert(NFTYPE == 6, "the filter type below is x % 6");
    i = (int)((unsigned)knob(k, 6) >> 9);       /* (x >> 9) % 6 without the division: (x * 43 >> 8) is x / 6 for x < 64 */
    G.ftype = (uint32_t)(i - 6 * ((i * 43) >> 8));
    d = pv[P_DRIVE] + ((knob(k, 7) * 127) >> 15);
    d = d > 127 ? 127 : d;
    if (d != G.drive_d) {                         /* (the divisions run when the knob has moved) */
        G.drive_d = d;
        G.drive_q12 = d ? 4096 + (d * d * 7 * 4096 / 16129) : 0;
    }
    for (i = 0; i < 8; i++) G.mk[i] = k[i];
    G.mk_ok = 1;
    G.op1[0] = G.lvl1; G.op1[1] = 0; G.op1[2] = G.w1 == W_PLS; G.op1[3] = NT;   /* (OSC 1 stores the mix, OSC 2 adds) */
    G.op2[0] = G.lvl2; G.op2[1] = 4; G.op2[2] = G.w2 == W_PLS; G.op2[3] = NT;
}

static __attribute__((noinline, optimize("Os"))) void block_shared(const int16_t *k)
{
    int32_t i, cut_t, reso_t;
    if (!G.mk_ok || k[0] != G.mk[0] || k[1] != G.mk[1] || k[2] != G.mk[2] || k[3] != G.mk[3] || k[5] != G.mk[5]
        || k[6] != G.mk[6] || k[7] != G.mk[7])
        knob_update(k);
    cut_t = G.cut_t;
    reso_t = G.reso_t;
    /* CUTOFF and RESO slew, tau 64 steps of CTL = 23 ms (a knob step glides) */
    if (G.cut_sm < 0) { G.cut_sm = cut_t; G.reso_sm = reso_t; }
#pragma GCC unroll 1
    for (i = 0; i < NA; i++) {
        G.cut_sm += (cut_t - G.cut_sm) >> 6;
        G.reso_sm += (reso_t - G.reso_sm) >> 6;
        G.t_cut[i] = G.cut_sm;
    }
    if (G.reso_sm != G.reso_prev) {
        G.reso_prev = G.reso_sm;
        reso_k = 8192 - G.reso_sm * 8400 / (127 * 256);
    }
    /* the LFO at each tick: OberVave's steps of CTL, a tick sees the first of its two half a step on */
#pragma GCC unroll 1
    for (i = 0; i < NA; i++) {
        uint32_t old_ph = G.lfo_ph;
        G.lfo_ph += LFO_INC[LFO_RATE];
        if (G.lfo_ph < old_ph) { G.lfo_rnd_a = G.lfo_rnd_b; G.lfo_rnd_b = xorshift(&G.rnd_state); }
        if (i & 1) continue;
        G.t_lfo_ph[i >> 1] = G.lfo_ph + (LFO_INC[LFO_RATE] >> 1);
        G.t_rnd_a[i >> 1] = G.lfo_rnd_a;
        G.t_rnd_b[i >> 1] = G.lfo_rnd_b;
    }
    obv_blocks++;
}

/* ---- envelopes: analog RC curves per tick (CTL samples), level Q24. ka, kd, kr: the stages' coefficients with the
 * voice card's offset (k + (k * vt >> 7), made once per block) */
static __attribute__((noinline, optimize("Os"))) void env_tick(env_t *e, int32_t ka, int32_t kd, int32_t sus, int32_t kr, int32_t gate)   /* (one copy) */
{
    if (gate && e->stage >= E_REL) e->stage = E_ATT;
    if (!gate && e->stage && e->stage < E_REL) e->stage = E_REL;
    switch (e->stage) {
    case E_ATT:                                 /* aims at 1.3, stops at 1.0 */
        e->level += mulq24(ENV_ONE + (ENV_ONE * 3 >> 3) - e->level, ka);
        if (e->level >= ENV_ONE) { e->level = ENV_ONE; e->stage = E_DEC; }
        break;
    case E_DEC:
        e->level += mulq24(sus - e->level, kd) - 16;
        if (e->level <= sus + 64) { e->level = sus; e->stage = E_SUS; }
        break;
    case E_SUS:
        e->level = sus;
        break;
    case E_REL:
        e->level += mulq24(-e->level, kr) - 32;
        if (e->level < LEVEL_FLOOR) { e->level = 0; e->stage = E_IDLE; }
        break;
    default:
        e->level = 0;
    }
}
static inline int32_t env_k(uint32_t k, int32_t vt) { return (int32_t)k + (((int32_t)k * vt) >> 7); }

/* base + mod * 256 clamped to 2^26 .. 2^32 - 1 - 2^26 (|mod * 256| < 2^31: lfo * G.lfo_pwd < 2^22) */
static inline uint32_t pw_mod(uint32_t base, int32_t mod)
{
    const uint32_t lo = 1u << 26, hi = 0xFFFFFFFFu - (1u << 26);
    uint32_t m = (uint32_t)(mod < 0 ? -mod : mod) << 8;
    if (mod < 0) return base < lo + m ? lo : (base - m > hi ? hi : base - m);
    return base > hi - m ? hi : (base + m < lo ? lo : base + m);
}

/* the MIDI note nearest a phase increment (key tracking follows the key): once per note */
static __attribute__((noinline)) uint8_t note_of(uint32_t inc)
{
    /* Same monotone thresholds as the descending scan, at most seven probes. */
    uint32_t lo = 0, hi = 127;
    while (lo < hi) {
        uint32_t n = (lo + hi + 1u) >> 1;
        uint32_t o = (n * 43u) >> 9;            /* n / 12 and n % 12 for n < 128 without a division (oxbow_test.c rcp mode) */
        uint32_t i = INC_C9[n - 12u * o] >> (10u - o);
        if (inc >= i - (i >> 5)) lo = n;
        else hi = n - 1u;
    }
    return (uint8_t)lo;
}


/* These values depend on the voicing (G.prog_gen: OSC 2's interval and detune, the envelope times, key and velocity
 * tracking, the vintage amount, the PWM), the card and the note / velocity. Kept across blocks and restrikes while
 * those are unchanged. */
static __attribute__((noinline)) const vblk_t *voice_block_fill(voice_t *v, int card);
static inline const vblk_t *voice_block(voice_t *v, int card)
{
    if (v->blk_gen == G.prog_gen && v->blk_note == v->note && v->blk_vel == v->vel)
        return &v->blk;
    return voice_block_fill(v, card);
}
static __attribute__((noinline)) const vblk_t *voice_block_fill(voice_t *v, int card)
{
    vblk_t *c = &v->blk;
    v->blk_gen = G.prog_gen; v->blk_note = v->note; v->blk_vel = v->vel;
    const int32_t vt = (G.vint * VINT_ENV[card]) >> 7;
    c->fka = env_k(ENV_K_ATT[G.e_fa], vt); c->fkd = env_k(ENV_K_DEC[G.e_fd - ENV_K_DEC0], vt); c->fkr = env_k(ENV_K_DEC[G.e_fr - ENV_K_DEC0], vt);
    c->p8 = (VINT_TUNE8[card] * G.vint) >> 7;
    c->p2 = ((int32_t)pv[P_O2_SEMI] - 24) * 256 + G.det_fine8 + uni_det8 + G.p2_iv;
    c->cut = 8 * 256 + ((int32_t)v->note - 60) * G.keytrk * 2 + (((int32_t)v->vel - 64) * G.velflt >> 1)
           + ((VINT_CUT8[card] * G.vint) >> 7);
    c->velg = 32767 - ((((127 - (int32_t)v->vel) * (int32_t)pv[P_VEL_AMP]) >> 7) * 258);
    c->spread = (uint32_t)card << 29;            /* (the PWM LFO: each card an eighth of a turn on) */
    c->lfo_on = (lfo_pd | G.lfo_pwd | lfo_fd | lfo_ad) != 0;   /* no depth: the LFO's value is never used */
    c->to1 = pv[P_LFO_PITCH_TO] != TO_O2; c->to2 = pv[P_LFO_PITCH_TO] != TO_O1;
    c->pw_to1 = pv[P_LFO_PWM_TO] != TO_O2; c->pw_to2 = pv[P_LFO_PWM_TO] != TO_O1;
    return c;
}

/* ---- the filter coefficients for one step (made only when the cutoff or the resonance moved) */
static __attribute__((noinline, optimize("Os"))) void voice_coef(voice_t *v, int32_t cut, svf_coef_t *c1, svf_coef_t *c2)   /* (one copy) */
{
    if (!v->c1_ok || cut != v->c1_cut || reso_k != v->c1_k) {
        svf_coef(&v->c1, cut, reso_k);
        v->c1_cut = cut; v->c1_k = reso_k; v->c1_ok = 1;
    }
    *c1 = v->c1;
    if (G.ftype == F_LP24) {
        if (!v->c2_ok || cut != v->c2_cut) {
            svf_coef(&v->c2, cut, 5793);
            v->c2_cut = cut; v->c2_ok = 1;
        }
        *c2 = v->c2;
    }
}

/* the OP-1's step offset by p8 (Q8 semitones), one out-of-line copy */
static __attribute__((noinline, optimize("Os"))) uint32_t obv_inc(uint32_t base, int32_t p8) { return inc_scale(base, pitch_ratio(p8)); }

/* each oscillator's step, pulse width and reciprocal for one tick (the passes read them) */
typedef struct { uint32_t inc, pw, sh, r; } otick_t;
/* The per-call scratch: written before it is read within each voice's call (the ticks leave their settings, the first
 * oscillator pass of each tick stores the mix). In the L1 partition after the state and TANH_P (obv_claim), or here. */
typedef struct {
    int32_t mix[OBV_SAMPLES];                   /* the block's mix */
    otick_t tk1[NT], tk2[NT];                   /* each oscillator's step, pulse width and reciprocal per tick */
    svf_coef_t tc1[NA], tc2[NA];                /* the filter coefficients per step */
    int32_t tamp[NA + 1];                       /* the amp at each step's start (and the block's end) */
} obv_scr_t;
static obv_scr_t obv_scr_home;
static obv_scr_t *obv_s = &obv_scr_home;
#define bmix (obv_s->mix)
#define tk1 (obv_s->tk1)
#define tk2 (obv_s->tk2)
#define tc1 (obv_s->tc1)
#define tc2 (obv_s->tc2)
#define tamp (obv_s->tamp)
static int32_t bnoise[OBV_SAMPLES];             /* (no noise in this voicing: lvln is 0) */

/* ---- one control tick (TICK samples) for a voice: pitch and pulse widths, and two steps (CTL samples each, as
 * OberVave) of the envelopes, the drift, the cutoff and the amp; amp: the amp after each step; c1, c2: the
 * filter coefficients of each step; noise: the noise samples of the tick (each step's after its drift draw, one
 * generator), when the voice has noise */
static __attribute__((noinline, optimize("Os"))) void voice_tick(voice_t *v, const vblk_t *c, int t, int32_t gate)
{
    const uint32_t base = phase_2x((uint32_t)OP1_PITCH_INC[t * TICK * 2]);
    int32_t *amp = tamp + 2 * t + 1, *noise = lvln ? bnoise + t * TICK : 0;
    svf_coef_t *c1 = tc1 + 2 * t, *c2 = tc2 + 2 * t;
    int32_t lfo = 0, p8, p1, p2, cut, fenv, tmp, trem, lfo_to, f1, a1;
    /* the LFO as this voice sees it */
    if (c->lfo_on) lfo = lfo_shape(G.t_lfo_ph[t] + c->spread, pv[P_LFO_SHAPE], G.t_rnd_a[t], G.t_rnd_b[t]);
    for (int s = 0; s < 2; s++)
        if (v->lfo_fade < 32767) {
            if (v->lfo_blk >= lfo_dl) { v->lfo_fade += lfo_fstep; if (v->lfo_fade > 32767) v->lfo_fade = 32767; }
            v->lfo_blk++;
        }
    lfo = (lfo * v->lfo_fade) >> 15;
    /* envelopes, two steps */
    env_tick(&v->fe, c->fka, c->fkd, G.sus_f, c->fkr, gate);
    f1 = v->fe.level;
    env_tick(&v->fe, c->fka, c->fkd, G.sus_f, c->fkr, gate);
    a1=ENV_ONE; /* T2 applies the sole amplitude envelope after engine render. */
    fenv = ((f1 >> 1) + (v->fe.level >> 1)) >> 9;   /* Q15: OSC 2's pitch holds the two steps' mean */
    /* vintage: a slow random walk on the pitch, a step per CTL */
    for (int s = 0; s < 2; s++) {
        v->drift += (int32_t)(xorshift(&v->noise) & 31u) - 16;
        v->drift -= v->drift >> 11;
        if (noise) {
            uint32_t ns = v->noise;
            for (int i = 0; i < (int)CTL; i++) *noise++ = ((int32_t)(xorshift(&ns) >> 16) - 32768) * lvln;
            v->noise = ns;
        }
    }
    /* pitch offsets, Q8 semitones, on top of the OP-1's phase increment */
    p8 = c->p8 + ((v->drift * G.vint) >> 10);
    lfo_to = (lfo * lfo_pd * 24) >> 15;
    p1 = p8 + (c->to1 ? lfo_to : 0);
    p2 = p8 + (c->to2 ? lfo_to : 0) + c->p2 + ((fenv * G.env_o2 * 97) >> 15);
    if (base != v->pk_base) { v->pk_base = base; v->pk_p1 = v->pk_p2 = INT32_MIN; }
    if (p1 != v->pk_p1) { v->pk_p1 = p1; v->inc1 = obv_inc(base, p1); }   /* (a step is made again only when */
    if (p2 != v->pk_p2) { v->pk_p2 = p2; v->inc2 = obv_inc(base, p2); }   /* its inputs moved) */
    tmp = lfo * G.lfo_pwd;
    v->pw1 = pw_mod(G.pw1_base, c->pw_to1 ? tmp : 0);
    v->pw2 = pw_mod(G.pw2_base, c->pw_to2 ? tmp : 0);
    /* cutoff, Q8 semitones, per step */
    cut = c->cut + ((lfo * lfo_fd * 97) >> 15);
    voice_coef(v, cut + G.t_cut[2 * t] + (((f1 >> 9) * G.fenv_amt * 390) >> 15), c1, c2);
    voice_coef(v, cut + G.t_cut[2 * t + 1] + (((v->fe.level >> 9) * G.fenv_amt * 390) >> 15), c1 + 1, c2 + 1);
    rcp_track(&v->r1, v->inc1);
    rcp_track(&v->r2, v->inc2);
    /* amp, after each step */
    trem = 32767 - (((32767 - lfo) * lfo_ad) >> 8);
    amp[0] = (((a1 >> 9) * c->velg >> 15) * trem) >> 15;
    amp[1] = (((a1 >> 9) * c->velg >> 15) * trem) >> 15;
    tk1[t].inc = v->inc1; tk1[t].pw = v->pw1; tk1[t].sh = v->r1.sh; tk1[t].r = v->r1.r;
    tk2[t].inc = v->inc2; tk2[t].pw = v->pw2; tk2[t].sh = v->r2.sh; tk2[t].r = v->r2.r;
}

/* ---- the samples: oscillators -> mix -> drive -> filter -> amp, in passes over the whole block (each pass keeps its
 * state in registers; the arithmetic is the one-sample-at-a-time code's). The ticks run first and leave their
 * settings per tick here; the coupled oscillators (sync, X-MOD) still run tick by tick, between the ticks. */

/* obv_dsp.S: the passes in Blackfin asm (see its header), bit for bit the C passes below, which host builds,
 * -DOXBOW_LEGACY_MAP (saw + pulse in one oscillator) and -DOXBOW_C_LOOP (kern_check.py's reference) use */
#if defined(__bfin__) && !defined(OXBOW_C_LOOP) && !defined(OXBOW_LEGACY_MAP)
#define OBV_ASM 1
void ox_osc(osc_t *o, const otick_t *tk, int32_t *mix, const int32_t *prm);
void ox_drive(int32_t *mix, int32_t drv, const int16_t *tanh);
void ox_svf(int32_t *mix, svf_state_t *f, const svf_coef_t *c, const int16_t *tanh, int32_t mode);
void ox_amp(const int32_t *mix, int16_t *out, int32_t *win, const int32_t *amp);
#else
#define OBV_ASM 0
#endif
#if !OBV_ASM || defined(OXBOW_KERN)
#define OBV_CPASS 1                             /* the C passes (the asm build's kern_check guest too) */
#else
#define OBV_CPASS 0
#endif

#if OBV_CPASS
/* one free-running oscillator (no sync, no X-MOD) through the block, out * lvl added to mix (or stored: first) */
static inline __attribute__((always_inline)) void osc_pass(osc_t *o, const otick_t *tk, uint32_t wave, int32_t hw,
                                                           int32_t lvl, int32_t *mix, int first, int nt)
{
    uint32_t ph = o->ph;
    int32_t prev = o->prev;
    for (int t = 0; t < nt; t++, tk++, mix += TICK) {
        const uint32_t inc = tk->inc, pw = tk->pw, sh = tk->sh, r = tk->r;
        const int ev = (inc >> 15) != 0;        /* a step below 2^15: no corrections (as osc_step) */
        if (!ev || (inc < (1u << 28) && ph + TICK * inc >= ph && (!(wave & OSC_PLS) || ph + pw + TICK * inc >= ph + pw))) {
            /* no wrap of the phase (nor of ph + pw for a pulse) within the tick: no event, the plain loop */
            for (int i = 0; i < TICK; i++) {
                const int32_t out = prev;
                ph += inc;
                prev = osc_naive(ph, pw, wave);
                mix[i] = first ? out * lvl : mix[i] + out * lvl;
            }
            continue;
        }
        for (int i = 0; i < TICK; i++) {
            int32_t cur, out = prev;
            ph += inc;
            cur = osc_naive(ph, pw, wave);
            if (ev) {
                if (ph < inc)                   /* wrapped: the saw(s) drop */
                    osc_event(&out, &cur, hw, rcp_at(sh, r, ph));
                if ((wave & OSC_PLS) && ph + pw < inc)   /* the subtracted saw wraps: the pulse rises */
                    osc_event(&out, &cur, 65536, rcp_at(sh, r, ph + pw));
            }
            prev = cur;
            mix[i] = first ? out * lvl : mix[i] + out * lvl;
        }
    }
    o->ph = ph;
    o->prev = prev;
}

#endif

#if OBV_ASM
/* one free-running oscillator through one tick (hard sync's ticks without a reset): obv_dsp.S ox_osc (hw is -65536 for
 * W_SAW and W_PLS) */
static void osc_pass_w1(osc_t *o, const otick_t *tk, uint32_t wave, int32_t hw, int32_t lvl, int32_t *mix, int first)
{
    const int32_t prm[4] = { lvl, first ? 0 : 4, wave == W_PLS, 1 };
    (void)hw;
    ox_osc(o, tk, mix, prm);
}
#else
static void osc_pass_w(osc_t *o, const otick_t *tk, uint32_t wave, int32_t hw, int32_t lvl, int32_t *mix, int first)
{
    switch (wave) {                             /* one loop per wave */
    case W_PLS: if (first) osc_pass(o, tk, W_PLS, hw, lvl, mix, 1, NT); else osc_pass(o, tk, W_PLS, hw, lvl, mix, 0, NT); break;
#ifdef OXBOW_LEGACY_MAP                         /* (saw + pulse in one oscillator: the old WAVE "both" only) */
    case W_BOTH: if (first) osc_pass(o, tk, W_BOTH, hw, lvl, mix, 1, NT); else osc_pass(o, tk, W_BOTH, hw, lvl, mix, 0, NT); break;
#endif
    default: if (first) osc_pass(o, tk, W_SAW, hw, lvl, mix, 1, NT); else osc_pass(o, tk, W_SAW, hw, lvl, mix, 0, NT); break;
    }
}
/* the same through one tick (hard sync's ticks without a reset) */
static void osc_pass_w1(osc_t *o, const otick_t *tk, uint32_t wave, int32_t hw, int32_t lvl, int32_t *mix, int first)
{
    switch (wave) {
    case W_PLS: if (first) osc_pass(o, tk, W_PLS, hw, lvl, mix, 1, 1); else osc_pass(o, tk, W_PLS, hw, lvl, mix, 0, 1); break;
#ifdef OXBOW_LEGACY_MAP                         /* (saw + pulse in one oscillator: the old WAVE "both" only) */
    case W_BOTH: if (first) osc_pass(o, tk, W_BOTH, hw, lvl, mix, 1, 1); else osc_pass(o, tk, W_BOTH, hw, lvl, mix, 0, 1); break;
#endif
    default: if (first) osc_pass(o, tk, W_SAW, hw, lvl, mix, 1, 1); else osc_pass(o, tk, W_SAW, hw, lvl, mix, 0, 1); break;
    }
}

#endif

/* the oscillators with hard sync or X-MOD through one tick: one sample at a time (OSC 2 follows OSC 1 within the
 * sample) */
static __attribute__((noinline)) void osc_coupled(voice_t *v, int t, int32_t *mix, int32_t hw1, int32_t hw2)
{
    if (!G.xmod_q) {                              /* hard sync only: a tick in which OSC 1's phase does not wrap resets nothing */
        const uint32_t i1 = v->inc1;
        if ((i1 >> 15) == 0 || (i1 < (1u << 28) && v->o1.ph + TICK * i1 >= v->o1.ph)) {
            osc_pass_w1(&v->o1, tk1 + t, G.w1, hw1, G.lvl1, mix, 1);
            osc_pass_w1(&v->o2, tk2 + t, G.w2, hw2, G.lvl2, mix, 0);
            return;
        }
    }
    uint32_t inc1 = v->inc1, inc2 = v->inc2, pw1 = v->pw1, pw2 = v->pw2, d1 = inc1 >> 15, d2 = inc2 >> 15;
    uint32_t xq = G.xmod_q, sy = G.sync_on, ww1 = G.w1, ww2 = G.w2;
    int32_t o2n = v->o2.prev, l1 = G.lvl1, l2 = G.lvl2;
    for (int i = 0; i < TICK; i++) {
        int32_t s1, s2, rt = -1;
        uint32_t ie = inc1;
        if (xq) {                               /* OSC2 -> OSC1 linear FM, the step never below inc/16 */
            int32_t m = (int32_t)(inc1 >> 8 > 0x200000u ? 0x200000u : inc1 >> 8) * (((o2n >> 8) * (int32_t)xq) >> 6);
            m = obv_add_sat(m, (int32_t)inc1);
            ie = m < (int32_t)(inc1 >> 4) ? inc1 >> 4 : (uint32_t)m;
            d1 = ie >> 15;
        }
        s1 = osc_step(&v->o1, ie, d1, pw1, ww1, hw1, -1, &v->r1);
        if (sy && v->o1.ph < ie && d1)
            rt = rcp_frac(&v->r1, ie, v->o1.ph);
        s2 = osc_step(&v->o2, inc2, d2, pw2, ww2, hw2, rt, &v->r2);
        o2n = v->o2.prev;
        mix[i] = s1 * l1 + s2 * l2;
    }
}

/* X-MOD without sync through one tick: OSC 2 runs free (its naive values kept: OSC 1's modulator, one sample
 * late), then OSC 1 with the step it modulates, sample by sample (the reciprocal tracked at each event) */
static inline __attribute__((always_inline)) void xmod_osc1(voice_t *v, int32_t *mix, const int32_t *o2c, int32_t o2n,
                                                            uint32_t wave, int32_t hw)
{
    const uint32_t inc1 = v->inc1, pw1 = v->pw1, xq = G.xmod_q, lim = inc1 >> 8 > 0x200000u ? 0x200000u : inc1 >> 8;
    const int32_t l1 = G.lvl1;
    for (int i = 0; i < TICK; i++) {
        int32_t m = (int32_t)lim * (((o2n >> 8) * (int32_t)xq) >> 6), s1;
        uint32_t ie;
        m = obv_add_sat(m, (int32_t)inc1);
        ie = m < (int32_t)(inc1 >> 4) ? inc1 >> 4 : (uint32_t)m;
        s1 = osc_step(&v->o1, ie, ie >> 15, pw1, wave, hw, -1, &v->r1);
        mix[i] += s1 * l1;
        o2n = o2c[i];
    }
}

static __attribute__((noinline)) void osc_xmod(voice_t *v, int32_t *mix, int32_t hw1, int32_t hw2)
{
    int32_t o2c[TICK];
    const int32_t o2n = v->o2.prev;
    uint32_t ph = v->o2.ph;                     /* OSC 2: osc_pass's loop, one tick, the naive values kept */
    int32_t prev = v->o2.prev;
    const uint32_t inc = v->inc2, pw = v->pw2, sh = v->r2.sh, r = v->r2.r, wave = G.w2;
    const int32_t l2 = G.lvl2, ev = (inc >> 15) != 0;
    for (int i = 0; i < TICK; i++) {
        int32_t cur, out = prev;
        ph += inc;
        cur = osc_naive(ph, pw, wave);
        if (ev) {
            if (ph < inc)
                osc_event(&out, &cur, hw2, rcp_at(sh, r, ph));
            if ((wave & OSC_PLS) && ph + pw < inc)
                osc_event(&out, &cur, 65536, rcp_at(sh, r, ph + pw));
        }
        prev = cur;
        o2c[i] = cur;
        mix[i] = out * l2;
    }
    v->o2.ph = ph;
    v->o2.prev = prev;
    switch (G.w1) {
#ifdef OXBOW_LEGACY_MAP
    case W_PLS: xmod_osc1(v, mix, o2c, o2n, W_PLS, hw1); break;
    case W_BOTH: xmod_osc1(v, mix, o2c, o2n, W_BOTH, hw1); break;
#endif
    default: xmod_osc1(v, mix, o2c, o2n, W_SAW, hw1); break;   /* (X-MOD is saw into saw) */
    }
}

#if OBV_CPASS
/* mix >> 7 -> drive (or the clamp) in place */
static void drive_pass(int32_t *mix)
{
    const int32_t drv = G.drive_q12;
    if (drv)
        for (int i = 0; i < OBV_SAMPLES; i++) mix[i] = softclip((((mix[i] >> 7) >> 3) * drv) >> 9);
    else
        for (int i = 0; i < OBV_SAMPLES; i++) mix[i] = clampi(mix[i] >> 7, -65535, 65535);
}
#endif

/* The filters' samples run in two loops per step (8 samples): the first takes the samples whose input to the
 * state-dependent products is within +-65536 (svf_dot's fast path: ic1 always is, see oxbow_test.c) with nothing but
 * that one test, and leaves at the first one that is not; the second loop finishes the step with the general code
 * (svf_dot's wide path, same results). Keeping the wide path out of the first loop frees registers. */
#define UNLIKELY(x) __builtin_expect(!!(x), 0)
#define WIDE(v) ((uint32_t)(((int32_t)(v) >> 16) + 1) > 1u)

/* the filter's first stage (svf_step) and the type's output, in place, for one filter type */
static inline __attribute__((always_inline)) void filter_pass(svf_state_t *f, int32_t *mix, uint32_t ft)
{
    int32_t ic1 = f->ic1, ic2 = f->ic2;
    const int32_t mq = morph_q;
    const svf_coef_t *c = tc1;
    for (int t = 0; t < NA; t++, c++, mix += CTL) {
        const int32_t a1 = c->a1, a2 = c->a2, a3 = c->a3, k = c->k;
        int i = 0;
        for (; i < (int)CTL; i++) {
            int32_t x = mix[i], v1, v2, v3 = x - ic2, n1, y;
            if (UNLIKELY(WIDE(v3))) break;
            v1 = (a1 * ic1 + a2 * v3) >> 13;
            v2 = ic2 + ((a2 * ic1 + a3 * v3) >> 13);
            n1 = 2 * v1 - ic1;
            ic1 = (uint32_t)((n1 >> 13) + 3) < 6u ? n1 : softclip(n1 >> 1) * 2;   /* linear below +-0.75 (-24576..24575), then soft */
            ic2 = clampi(2*v2-ic2,-SVF_STATE_MAX,SVF_STATE_MAX);
            switch (ft) {                       /* (a constant here: one loop per type; |v1| < 81,000: svf_damp's fast path) */
            case F_HP12: y = x - ((k * v1) >> 12) - v2; break;
            case F_BP12: y = v1; break;
            case F_NOTCH: y = x - ((k * v1) >> 12); break;   /* hp + lp */
            case F_SEM: y = v2 + (((x - ((k * v1) >> 12) - v2 - v2) * mq) >> 7); break;   /* LP .. notch .. HP pot */
            default: y = v2; break;             /* LP 12, and LP 24's first stage */
            }
            mix[i] = y;
        }
        for (; i < (int)CTL; i++) {
            int32_t x = mix[i], v1, v2, v3, n1, y;
            v3 = x - ic2;
            v1 = svf_dot(a1,ic1,a2,v3);
            v2 = ic2 + svf_dot(a2,ic1,a3,v3);
            n1 = 2 * v1 - ic1;
            ic1 = (uint32_t)(n1 + 24576) < 49152u ? n1 : softclip(n1 >> 1) * 2;
            ic2 = clampi(2*v2-ic2,-SVF_STATE_MAX,SVF_STATE_MAX);
            switch (ft) {
            case F_HP12: y = x - svf_damp(k,v1) - v2; break;
            case F_BP12: y = v1; break;
            case F_NOTCH: y = x - svf_damp(k,v1); break;
            case F_SEM: y = v2 + (((x - svf_damp(k,v1) - v2 - v2) * mq) >> 7); break;
            default: y = v2; break;
            }
            mix[i] = y;
        }
    }
    f->ic1 = ic1; f->ic2 = ic2;
}

#if OBV_CPASS
/* LP 24's second stage (svf_lp) in place */
static void lp2_pass(svf_state_t *f, int32_t *mix)
{
    int32_t jc1 = f->ic1, jc2 = f->ic2;
    const svf_coef_t *c = tc2;
    for (int t = 0; t < NA; t++, c++, mix += CTL) {
        const int32_t b1 = c->a1, b2 = c->a2, b3 = c->a3;
        int i = 0;
        for (; i < (int)CTL; i++) {
            int32_t v3 = mix[i] - jc2, n1, y;
            if (UNLIKELY(WIDE(v3) | WIDE(jc1))) break;   /* (jc1 reaches +-131071: both factors are tested) */
            n1 = (b1 * jc1 + b2 * v3) >> 13;
            y = jc2 + ((b2 * jc1 + b3 * v3) >> 13);
            jc1 = clampi(2*n1-jc1,-SVF_STATE_MAX,SVF_STATE_MAX);
            jc2 = clampi(2*y-jc2,-SVF_STATE_MAX,SVF_STATE_MAX);
            mix[i] = y;
        }
        for (; i < (int)CTL; i++) {
            int32_t v3 = mix[i] - jc2, n1, y;
            n1 = svf_dot(b1,jc1,b2,v3);
            y = jc2 + svf_dot(b2,jc1,b3,v3);
            jc1 = clampi(2*n1-jc1,-SVF_STATE_MAX,SVF_STATE_MAX);
            jc2 = clampi(2*y-jc2,-SVF_STATE_MAX,SVF_STATE_MAX);
            mix[i] = y;
        }
    }
    f->ic1 = jc1; f->ic2 = jc2;
}
#endif

#if OBV_CPASS
/* clamp -> amp (ramped through each tick) -> the output gain -> the 44.1 kHz block, in one loop: the four-point
 * interpolation of the 22.05 kHz samples (history h3, h2, h1 per voice; the stored sample s is the newest) needs no
 * saturation: the amp is 0..32766 (velocity gain times the constant tremolo; oxbow_test.c rcp mode), so |y| <= 65000 *
 * 32766 >> 16 = 32500 (and y * amp stays below 2^31), |s| <= 19836 and the interpolated sample is within +-24800. */
/* one sample: clamp, amp (amp0 + da * i >> 3, da * i kept as a sum), output gain; then the two outputs from the history
 * window (a = oldest, b, c = newest) and the new sample s */
#define AMP_UP_SAMPLE(i, a, b, c, s) \
    do { \
        int32_t y = clampi(mix[i], -65000, 65000); \
        y = (y * (amp0 + (acc >> 3))) >> 16; \
        acc += da; \
        s = (y * OUT_GAIN) >> 15; \
        out[2 * (i)] = (int16_t)(b); \
        out[2 * (i) + 1] = (int16_t)((-(a) + 9 * ((b) + (c)) - (s)) >> 4); \
    } while (0)
/* the interpolated maximum must fit int16 (the loop has no saturation): 20 * s_max / 16, s_max = 65000 * 32766 >> 16 * OUT_GAIN >> 15 */
_Static_assert((20 * (((65000 * 32766) >> 16) * OUT_GAIN >> 15)) >> 4 <= 32767, "amp_up has no saturation");
_Static_assert(OUT_GAIN == 26400, "obv_dsp.S ox_amp loads OUT_GAIN as an immediate: change both");
static void amp_up(voice_t *v, const int32_t *mix, int16_t *out)
{
    int32_t u0 = v->up3, u1 = v->up2, u2 = v->up1, u3;
    for (int t = 0; t < NA; t++, mix += CTL, out += 2 * CTL) {
        const int32_t amp0 = tamp[t], da = tamp[t + 1] - tamp[t];
        int32_t acc = 0;
        AMP_UP_SAMPLE(0, u0, u1, u2, u3);       /* four samples rotate the window through u0..u3 */
        AMP_UP_SAMPLE(1, u1, u2, u3, u0);
        AMP_UP_SAMPLE(2, u2, u3, u0, u1);
        AMP_UP_SAMPLE(3, u3, u0, u1, u2);
        AMP_UP_SAMPLE(4, u0, u1, u2, u3);
        AMP_UP_SAMPLE(5, u1, u2, u3, u0);
        AMP_UP_SAMPLE(6, u2, u3, u0, u1);
        AMP_UP_SAMPLE(7, u3, u0, u1, u2);
    }
    v->up3 = u0; v->up2 = u1; v->up1 = u2;     /* (eight samples: the window is back at u0..u2 and u3 is the next slot) */
}
#endif

/* a wrap's height for a wave: -65536 per saw component */
static inline int32_t osc_hw(uint32_t w) { return (w & OSC_SAW ? -65536 : 0) + (w & OSC_PLS ? -65536 : 0); }
/* the coupled oscillators (sync, X-MOD) through tick t, between the ticks (rare: out of line) */
static __attribute__((noinline)) void osc_coupled_tick(voice_t *v, int t)
{
    const int32_t hw1 = osc_hw(G.w1), hw2 = osc_hw(G.w2);
    if (G.sync_on) osc_coupled(v, t, bmix + t * TICK, hw1, hw2);
    else osc_xmod(v, bmix + t * TICK, hw1, hw2);
}

static void voice_block_samples(voice_t *v, int vi, int16_t *out)
{
    const int32_t gate = obv_gate[vi];
    const uint32_t coupled = G.xmod_q || G.sync_on;
    const vblk_t *c = voice_block(v, vi);
    tamp[0] = v->amp1;
#pragma GCC unroll 1
    for (int t = 0; t < NT; t++) {
        voice_tick(v, c, t, gate);
        if (coupled) osc_coupled_tick(v, t);
    }
    v->amp1 = tamp[NA];
    if (!coupled) {
#if OBV_ASM
        ox_osc(&v->o1, tk1, bmix, G.op1);
        ox_osc(&v->o2, tk2, bmix, G.op2);
#else
        osc_pass_w(&v->o1, tk1, G.w1, osc_hw(G.w1), G.lvl1, bmix, 1);
        osc_pass_w(&v->o2, tk2, G.w2, osc_hw(G.w2), G.lvl2, bmix, 0);
#endif
    }
    if (lvln)
        for (int i = 0; i < OBV_SAMPLES; i++) bmix[i] += bnoise[i];
#if OBV_ASM
    ox_drive(bmix, G.drive_q12, tanh_at);
    switch (G.ftype) {                          /* (with its morph at 0, SEM's output is LP 12's) */
    case F_HP12: filter_pass(&v->f1, bmix, F_HP12); break;
    case F_NOTCH: filter_pass(&v->f1, bmix, F_NOTCH); break;
    case F_BP12: ox_svf(bmix, &v->f1, tc1, tanh_at, 1); break;
    case F_SEM: if (morph_q) { filter_pass(&v->f1, bmix, F_SEM); break; }
        ox_svf(bmix, &v->f1, tc1, tanh_at, 0); break;
    default: ox_svf(bmix, &v->f1, tc1, tanh_at, 0); break;
    }
    if (G.ftype == F_LP24) ox_svf(bmix, &v->f2, tc2, tanh_at, 2);
    ox_amp(bmix, out, &v->up3, tamp);
#else
    drive_pass(bmix);
    switch (G.ftype) {
    case F_HP12: filter_pass(&v->f1, bmix, F_HP12); break;
    case F_BP12: filter_pass(&v->f1, bmix, F_BP12); break;
    case F_NOTCH: filter_pass(&v->f1, bmix, F_NOTCH); break;
    case F_SEM: filter_pass(&v->f1, bmix, F_SEM); break;
    default: filter_pass(&v->f1, bmix, F_LP12); break;
    }
    if (G.ftype == F_LP24) lp2_pass(&v->f2, bmix);
    amp_up(v, bmix, out);
#endif
}

/* The L1 pool's synth partition (OP1_L1_SYNTH, 8,192 B): the state (obv_hot_t) at 0, the tables' copies (obv_l1tab_t)
 * at OBV_L1_TAB, the scratch at OBV_L1_SCR. Without it (no pool, or another engine still holds it) the state is obv_home,
 * the tables and the scratch stay in SDRAM; the samples are the same. Called first in render and note_on: everything
 * after it in that call goes through obv_hp, obv_tp and obv_s. */
typedef struct {
    int16_t tanh[528];                          /* TANH_P (514) */
    uint32_t fine[256], lim[32], semi[12];
    uint16_t rq[256], rs[256], svfg[138];       /* SVF_G (137) */
    uint8_t os[100];                            /* OCT_SEMI (97) */
} obv_l1tab_t;
#define OBV_L1_TAB OP1_L1_ALIGN(sizeof(obv_hot_t))
#define OBV_L1_SCR OP1_L1_ALIGN(OBV_L1_TAB + sizeof(obv_l1tab_t))
#define OBV_L1_BYTES (OBV_L1_SCR + sizeof(obv_scr_t))
_Static_assert(sizeof(obv_hot_t) % 4 == 0 && OBV_L1_BYTES <= 8192, "the L1 synth partition layout");
#define OBV_COPY(d, s) for (unsigned i_ = 0; i_ < sizeof(s) / sizeof((s)[0]); i_++) (d)[i_] = (s)[i_]
static __attribute__((noinline, unused)) void obv_tab_fill(obv_l1tab_t *t)
{
    OBV_COPY(t->tanh, TANH_P);
    OBV_COPY(t->fine, FINE_Q16);
    OBV_COPY(t->lim, INC_LIM);
    OBV_COPY(t->semi, SEMI_Q16);
    OBV_COPY(t->rq, RCP_Q);
    OBV_COPY(t->rs, RCP_S);
    OBV_COPY(t->svfg, SVF_G);
    OBV_COPY(t->os, OCT_SEMI);
}
/* obv_tp -> the L1 copies at t, or (t = 0) the tables in SDRAM (when the partition moved: out of line) */
static __attribute__((noinline, unused)) void obv_tp_point(const obv_l1tab_t *t)
{
    if (t) {
        obv_tp.tanh = t->tanh; obv_tp.rq = t->rq; obv_tp.rs = t->rs; obv_tp.svfg = t->svfg;
        obv_tp.fine = t->fine; obv_tp.semi = t->semi; obv_tp.lim = t->lim; obv_tp.os = t->os;
    } else {
        obv_tp.tanh = TANH_P; obv_tp.rq = RCP_Q; obv_tp.rs = RCP_S; obv_tp.svfg = SVF_G;
        obv_tp.fine = FINE_Q16; obv_tp.semi = SEMI_Q16; obv_tp.lim = INC_LIM; obv_tp.os = OCT_SEMI;
    }
}
static obv_hot_t *obv_claim(void)
{
    obv_hot_t *h = &obv_home;
    obv_scr_t *sc = &obv_scr_home;
#if defined(__bfin__)
    int fresh;
    uint8_t *l = op1_l1_claim_state(OP1_L1_SYNTH, h, sizeof *h, OBV_L1_BYTES, &fresh);
    obv_l1tab_t *t = 0;
    if (l) {
        t = (obv_l1tab_t *)(l + OBV_L1_TAB);
        if (fresh)
            obv_tab_fill(t);
        h = (obv_hot_t *)l;
        sc = (obv_scr_t *)(l + OBV_L1_SCR);
    }
    if (obv_tp.tanh != (t ? t->tanh : TANH_P))
        obv_tp_point(t);
#endif
    obv_hp = h;
    obv_s = sc;
    return h;
}

static void obv_note_on(void *self, const int16_t *knobs)
{
    const int vi = op1_voice_index(self);
    voice_t *v = &obv_claim()->v[vi];
    int i, alone = 1;
    (void)knobs;
    for (i = 0; i < OP1_VOICES; i++) if (i != vi && obv_gate[i]) alone = 0;
    if (!v->noise) v->noise = 0x9E3779B9u ^ ((uint32_t)(vi + 1) * 0x85EBCA6Bu);
    obv_gate[vi] = 1;
    v->fresh = 1;
    v->fe.stage = E_ATT;
    v->lfo_blk = 0;
    v->lfo_fade = pv[P_LFO_DELAY] ? 0 : 32767;
    if (alone && pv[P_LFO_PHASE] == LP_SYNC) G.lfo_ph = 0;   /* the first key of a chord restarts the LFO */
}

static void obv_note_off(void *self)
{
    obv_gate[op1_voice_index(self)] = 0;
}

static __attribute__((optimize("Os"))) void obv_render(void *self, int16_t *out, const int16_t *knobs)
{
    const int vi = op1_voice_index(self);
    voice_t *v = &obv_claim()->v[vi];
    if (vi <= G.last_voice) block_shared(knobs);
    G.last_voice = vi;
    const uint32_t base = (uint32_t)OP1_PITCH_INC[0];
    if (v->fresh) {                             /* the firmware writes pitch and velocity around note_on */
        v->fresh = 0;
        v->note = note_of(base);
        v->vel = (uint8_t)(op1_voice_vel_gain(self) / 258);
    }
    /* Four-point interpolation preserves the shared 128-sample voice interface (amp_up).
     * History belongs to each voice and persists through ordinary restrikes. */
    voice_block_samples(v,vi,out);
    obv_vblk[vi] = obv_blocks;
    obv_venv[vi] = v->fe.level >> 9;
}

const op1_engine_t ENGINE_oxbow = { obv_note_on, obv_render, obv_note_off,
                                       { OP1_PRESS_PAGE, OP1_PRESS_PAGE, OP1_PRESS_PAGE, OP1_PRESS_NONE } };

/* ======================= screen (GUI thread) =======================
 * oxbow.svg (gen_svg.py, traced from the owner's design oxbow-reference.png; numbers in oxbow_geom.h). Every part
 * sits where the reference has it when its knob is at plugin.json's default, except the birds, which reach the
 * reference spot at DETUNE max. The full-size fit: the whole scene, the width of the screen, ink within y 2..138; no
 * text (the knobs show only through the moving parts).
 *   hornl, hornr  TONE: the horns widen (stretched out from their roots) as the filter opens, droop below the default
 *   birdl, birdr  WARMTH: the birds walk out along their horn's top edge to the reference spot (and ride the horn)
 *   bell          SHAPE (and page-2 RESONANCE): the bell swings about its ring, wider towards the hard shapes (sync,
 *                 X-MOD) and with the resonance; a little wider while notes play
 *   breath        CONTOUR: the breath streaks and clouds grow from the nostril with the filter envelope's amount; while
 *                 notes play they puff with the filter envelope
 *   s0..s5        one star per voice, lit while that voice sounds (a dim copy shows under each) */
#define ONE 1024
#define DEG 23                                   /* sine table steps per degree (8192 per turn), rounded */
static const int32_t KDEF[4] = { 17000, 13653, 19000, 12000 };   /* plugin.json's defaults: the reference pose */
static void *n_horn[2], *n_bird[2], *n_bell, *n_breath, *n_star[OP1_VOICES];
static uint32_t s_blocks, s_frame, s_swing;
static int32_t s_act, s_puff;

static inline int32_t sin15(int32_t a) { return OP1_SINE_TABLE[a & 8191]; }
static inline int32_t cos15(int32_t a) { return OP1_SINE_TABLE[(a + 2048) & 8191]; }

/* point (x, y) on horn s with stretch sx (Q10) and turn (c, sn: Q10 cos, sin) about the horn's root; Q10 */
static void horn_map(int s, int32_t sx, int32_t c, int32_t sn, int32_t x, int32_t y, int32_t *ox, int32_t *oy)
{
    const int32_t px = s ? OX_HORN_R_X : OX_HORN_L_X, py = s ? OX_HORN_R_Y : OX_HORN_L_Y;
    const int32_t dx = ((x - px) * sx) >> 10, dy = y - py;
    *ox = px + ((c * dx - sn * dy) >> 10);
    *oy = py + ((sn * dx + c * dy) >> 10);
}

/* x' = a x + c y + tx, y' = b x + d y + ty (Q10) */
static void set_m(void *n, int32_t a, int32_t b, int32_t c, int32_t d, int32_t tx, int32_t ty)
{
    if (!n) return;
    const int32_t m[9] = { a, b, 0, c, d, 0, tx, ty, ONE };
    op1_node_set_transform(n, m);
}

/* knob k (Q15) -> lo .. 0 (at the default d) .. hi */
static inline int32_t around(int32_t k, int32_t d, int32_t lo, int32_t hi)
{
    return k < d ? lo - (lo * k) / d : (hi * (k - d)) / (32767 - d);
}

static void ox_screen_init(void *scr)
{
    static const char *const stars[OP1_VOICES] = { "s0", "s1", "s2", "s3", "s4", "s5" };
    n_horn[0] = op1_find_node(scr, "hornl");
    n_horn[1] = op1_find_node(scr, "hornr");
    n_bird[0] = op1_find_node(scr, "birdl");
    n_bird[1] = op1_find_node(scr, "birdr");
    n_bell = op1_find_node(scr, "bell");
    n_breath = op1_find_node(scr, "breath");
    for (int i = 0; i < OP1_VOICES; i++) n_star[i] = op1_find_node(scr, stars[i]);
}

static void ox_screen_update(void *scr, int dt)
{
    int16_t kn[4];
    op1_synth_knobs_live(OP1_SCREEN_SLOT & 7, kn);
    int32_t k[4];
    for (int i = 0; i < 4; i++) k[i] = kn[i] < 0 ? 0 : kn[i];
    const uint32_t blocks = obv_blocks;
    const int on = blocks != s_blocks;
    s_blocks = blocks;
    s_frame++;

    /* stars: a voice that rendered in the last few blocks is sounding */
    int32_t env = 0, nv = 0;
    for (int i = 0; i < OP1_VOICES; i++) {
        const int lit = on && blocks - obv_vblk[i] < 4u;
        if (lit) {
            nv++;
            if (obv_venv[i] > env) env = obv_venv[i];
        }
        if (n_star[i]) op1_node_set_visible(n_star[i], lit);
    }
    s_act += ((nv ? ONE : 0) - s_act) >> 3;

    /* horns (CUTOFF): wider (stretched out from the root, 0.88 .. 1.12) as the cutoff opens; below the default
     * they also droop (tips down, up to 4 degrees). The birds (DETUNE) ride on them: each walks along its horn's top
     * edge from 60 reference px in towards the head (DETUNE 0) out to where the reference has it (DETUNE max);
     * the separate-axis OLED layout retains top/bottom clearance without shrinking the width. */
    const int32_t sx = ONE + around(k[0], KDEF[0], -123, 123);
    const int32_t droop = k[0] < KDEF[0] ? -(4 * DEG * (KDEF[0] - k[0])) / KDEF[0] : 0;
    const int32_t bd = (k[3] * ((OX_BIRD_N - 1) * 1024)) >> 15;
    const int32_t b0 = bd >> 10 < OX_BIRD_N - 1 ? bd >> 10 : OX_BIRD_N - 2, bt = bd - (b0 << 10);
    for (int s = 0; s < 2; s++) {
        const int32_t a = s ? -droop : droop;                     /* tips down: left anticlockwise, right clockwise */
        const int32_t c = (cos15(a) + 16) >> 5, sn = (sin15(a) + 16) >> 5;
        const int32_t px = s ? OX_HORN_R_X : OX_HORN_L_X, py = s ? OX_HORN_R_Y : OX_HORN_L_Y;
        set_m(n_horn[s], (c * sx) >> 10, (sn * sx) >> 10, -sn, c,
              px - ((((c * sx) >> 10) * px - sn * py) >> 10), py - ((((sn * sx) >> 10) * px + c * py) >> 10));
        const int32_t (*path)[2] = s ? OX_BIRD_R : OX_BIRD_L;
        const int32_t fx = s ? OX_FEET_R_X : OX_FEET_L_X, fy = s ? OX_FEET_R_Y : OX_FEET_L_Y;
        int32_t qx = fx + path[b0][0] + (((path[b0 + 1][0] - path[b0][0]) * bt) >> 10);
        int32_t qy = fy + path[b0][1] + (((path[b0 + 1][1] - path[b0][1]) * bt) >> 10);
        horn_map(s, sx, c, sn, qx, qy, &qx, &qy);
        set_m(n_bird[s], c, sn, -sn, c, qx - ((c * fx - sn * fy) >> 10), qy - ((sn * fx + c * fy) >> 10));
    }

    /* bell (SHAPE, page-2 RESONANCE): swings about its ring, 4 .. 22 degrees over SHAPE plus up to 8 with the resonance,
     * 1.5x while notes play; ~0.8 Hz at 60 frames/s */
    s_swing += 440;                                          /* 110 sine steps a frame: 0.8 Hz at 60 frames/s */
    const int16_t *w = op1_synth_knobs(OP1_SCREEN_SLOT & 7);
    const int32_t reso = w && w[5] > 0 ? w[5] : 0;
    const int32_t amp = ((4 * DEG + ((k[1] * 18 * DEG) >> 15) + ((reso * 8 * DEG) >> 15)) * (ONE + (s_act >> 1))) >> 10;
    const int32_t ba = (sin15((int32_t)(s_swing >> 2)) * amp) >> 15;
    const int32_t bc = (cos15(ba) + 16) >> 5, bs = (sin15(ba) + 16) >> 5;
    set_m(n_bell, bc, bs, -bs, bc, OX_BELL_X - ((bc * OX_BELL_X - bs * OX_BELL_Y) >> 10),
          OX_BELL_Y - ((bs * OX_BELL_X + bc * OX_BELL_Y) >> 10));

    /* breath (CONTOUR, filter envelope): 0.5 (none) .. 1 (the reference, at the default) .. 1.12 of its size; the big
     * cloud's right edge reaches the screen's at 1.16 */
    const int32_t amt = k[2], ad = KDEF[2];
    int32_t sc = amt < ad ? 512 + (512 * amt) / ad : ONE + (123 * (amt - ad)) / (32767 - ad);
    const int32_t puff = 780 + ((env * 260) >> 15);                 /* 0.76 .. 1.01 with the envelope */
    s_puff += ((on && nv ? puff : ONE) - s_puff) >> 2;
    if (s_frame < 2) s_puff = ONE;
    sc = (sc * s_puff) >> 10;
    if (n_breath) {
        const int32_t m[9] = { sc, 0, 0, 0, sc, 0, OX_BREATH_X - ((sc * OX_BREATH_X) >> 10),
                               OX_BREATH_Y - ((sc * OX_BREATH_Y) >> 10), ONE };
        op1_node_set_transform(n_breath, m);
    }
    (void)dt;
    op1_screen_draw(scr, dt);
}

const op1_screen_t SCREEN_oxbow = { ox_screen_init, ox_screen_update };
