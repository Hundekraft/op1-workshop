/*
 * Key velocity hook (kennel cores from 3.3): a feature that knows how hard a keyboard key was hit (plugins/keyvel,
 * the accelerometer) fills op1_key_velocity. The core calls fn at every keyboard key-down (R246's VoiceCtl note
 * record, 0x019AC288, kennel/kn_keys.c) on the KeyHandler thread with the stock velocity (0x7F) and uses what it
 * returns (1..127). fn = 0: the stock velocity, unchanged. MIDI in and the sequencers don't pass here.
 * diag points at the feature's live numbers (op1_keyvel_diag below) for the resource monitor's page; 0 = none.
 * An older core has no op1_key_velocity: a plugin that imports it refuses to load there (unknown import).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef OP1_KEYVEL_H
#define OP1_KEYVEL_H
#include <stdint.h>

typedef struct {
    int (*volatile fn)(int key, int velocity);      /* KeyHandler thread; key 0..23 (the physical key) */
    const void *volatile diag;                      /* const op1_keyvel_diag *, or 0 */
} op1_key_velocity_t;
extern op1_key_velocity_t op1_key_velocity;

/* the live numbers keyvel publishes for the monitor (screens/sysmon.c). Counts of the accelerometer: 10 bit, +-2 g,
 * left-justified, so 1 g = 16384 and one step (LSB) = 64. "hp" = the sum over X, Y, Z of the high-passed sample. */
#define OP1_KV_MAGIC   0x4B58u                    /* "KV", version 3 (2: calibration, gain, cmd; 3: no wait) */
#define OP1_KV_TRACE   24                          /* samples in the last press's trace */
#define OP1_KV_PRE     12                          /* of them before the key-down */
typedef struct {
    uint16_t magic;
    uint8_t on;                                    /* the feature is on (fast sampling) */
    uint8_t devid;                                 /* ADXL345 DEVID read at switch-on (0xE5), 0 = no answer */
    uint8_t rate;                                  /* BW_RATE written (0x0D = 800 Hz) */
    uint8_t curve;                                 /* the setting in use */
    uint8_t trace_n;                               /* samples in trace (fills to OP1_KV_TRACE after the press) */
    uint32_t samples, errors, clips;               /* reads done, failed, samples at full scale */
    uint32_t presses;
    int32_t noise;                                 /* hp at rest (slow average), counts */
    int32_t peak, peak_after;                      /* last press: the strike estimate (before the key's gain), and the
                                                    * largest hp in the OP1_KV_TRACE - OP1_KV_PRE samples after the key-down */
    int8_t peak_at;                                /* where the largest hp used was, from the key-down (-PRE..+4) */
    int8_t after_at;                               /* where peak_after was (1..) */
    uint8_t vel, key;                              /* last press: the velocity given and the key 0..23 */
    uint8_t window;                                /* samples the estimate used */
    uint8_t sens, floor_v, gated;                  /* settings; gated = tilt copy held (strike) */
    uint16_t trace[OP1_KV_TRACE];                  /* hp per sample around the last press, sample OP1_KV_PRE = key-down */
    uint16_t kmin[24], kmax[24];                   /* per key: smallest / largest estimate this session (0xFFFF / 0) */
    uint8_t kvmin[24], kvmax[24];                  /* per key: smallest / largest velocity */
    int16_t tilt[3];                               /* the tilt copy last published to R246 (X, Y, Z) */
    uint32_t held;                                 /* samples the tilt copy was held (strikes) */
    uint16_t gain;                                 /* last press: the key's gain, Q8 (256 = 1.0) */
    uint8_t cal;                                   /* per-key gains: 0 default, 1 calibrating, 2 calibrated */
    uint8_t cal_n;                                 /* calibrating: keys done of 24 */
    volatile uint8_t cmd;                          /* written by the monitor: OP1_KV_CMD_*; keyvel clears it */
} op1_keyvel_diag;
#define OP1_KV_CMD_CAL    1                        /* start a calibration run (one medium press per key) */
#define OP1_KV_CMD_RESET  2                        /* stop a run; with none going, back to the default gains */
#endif
