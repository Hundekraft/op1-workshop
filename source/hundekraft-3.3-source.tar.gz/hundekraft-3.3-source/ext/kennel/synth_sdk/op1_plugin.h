/*
 * op1r plugin API: custom synth engines and effects for the OP-1 (firmware R246).
 * Copyright (C) 2026 pcppcp. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 *
 * Include this header (and nothing else of the firmware build) from plugin code. Rules for plugin code
 * (it runs in the audio interrupt; a crash or a long block locks the OP-1):
 *   - integers only (no float: soft-float is far too slow), no per-sample divisions, small per-block work;
 *   - no libc (no malloc, printf, memcpy): state lives in the voice object (synths, 32 bytes per voice) or in
 *     the FX position's scratch buffer (op1_fx_scratch, 176 KB per position);
 *   - keep state per FX position 0..2 (synth, drum, master).
 *
 * All custom engines run inside the hidden "iter" engine slot (instr type 14), so they use the
 * iter screen/graphics (iter.svg: bar0..3 follow the 4 knobs). Extra synth_types DB rows are made
 * possible by hooking instr_types' name compare (0x019B975C): every configured engine name maps to
 * type 14. The engine is selected per patch by a selector word in knobs[4] (= default_params[4]):
 *     knobs[4] == OP1_ENGINE_MAGIC + n   ->  engine n (1..OP1_MAX_ORDER) = plugin.json "order" (plugins/);
 *                                            an order without a plugin in this build -> engine 0
 *     anything else                      ->  engine 0 = original TE "iter"
 * See docs/14_custom_synth.md.
 *
 * Calling convention: GCC Blackfin == VisualDSP ABI (args R0,R1,R2; return R0).
 * Voices: 6, object `self` = 0x24 bytes in scratchpad 0xFFB00000 + i*0x24; word 0 = vtable (never
 * write it). Bytes 4..0x23 are yours (state is shared with the original iter when switching).
 */
#ifndef OP1_PLUGIN_H
#define OP1_PLUGIN_H
#define OP1_PLUGIN_API 1                 /* a file built against another core layout is refused, not run. Not a version: it stays 1 until the first release */
#include <stdint.h>
/* Host build (harness/): firmware addresses are replaced by mocks, see harness/op1_host.h. */
#ifdef OP1_HOST
#include "harness/op1_host.h"
#endif

#define OP1_BLOCK        128
#define OP1_VOICES       6
#define OP1_SAMPLE_RATE  44100           /* output frames, sample and tape files; NOT the voice rate */
/* R246's rates (measured 2026-11-03): a voice render call gives OP1_BLOCK samples at OP1_VOICE_RATE (decimated 2:1
 * to 64 output frames) and OP1_PITCH_INC counts OP1_VOICE_RATE steps; an FX call gives OP1_FX_BLOCK samples at
 * OP1_FX_RATE. Both run OP1_CALL_RATE_Q8 / 256 = 689.06 calls per second (1.451 ms). Derive every time and
 * frequency constant from these, never from 344 calls/s or 22.05 kHz. */
#define OP1_VOICE_RATE   88200
#define OP1_FX_RATE      44100
#define OP1_CALL_RATE_Q8 176400          /* 44100 / 64 calls per second, Q8 */
#define OP1_ENGINE_MAGIC 0x5300          /* knobs[4] = 0x5300 + engine index (21248 + n) */
#define OP1_MAX_ORDER    63              /* highest selector number per kind (synth, FX); gaps allowed (as op1r 34) */
#define OP1_SLOTS        (OP1_MAX_ORDER + 1)
#define OP1_FILE_FIRST   32              /* built-in plugins use 1..31, plugin files without one of those 32..63 */

#ifndef OP1_HOST
/* per-sample phase increment of the voice being rendered (2^32 = one cycle/sample) */
#define OP1_VOICE_ENV ((const int16_t *)0xFF801D50) /* current voice stock envelope, read-only during render */
#define OP1_PITCH_INC    ((const int32_t *)0xFF801950)
/* firmware sine table: 8192 x int16, table[k] = sin(2*pi*k/8192) (verified on hardware via screen
 * rotations). Audio code may use index (int32 phase >> 19) + 4096 = -sin, inaudible; for geometry
 * (angles, windows that must be >= 0) index with (uint32 phase >> 19) or angle & 8191. */
#define OP1_SINE_TABLE   ((const int16_t *)0x0101E5E8)
#define OP1_VOICE_BASE   0xFFB00000u
/* note velocity per voice, int16 = velocity (1..127) << 8, written by VoiceCtl::note_on_synth */
#define OP1_VOICE_VEL    ((const volatile int16_t *)0xFF801064)
#endif

#define OP1_VOICE_SIZE   0x24u
static inline int op1_voice_index(const void *self)
{ return (int)(((uintptr_t)self - (uintptr_t)OP1_VOICE_BASE) / OP1_VOICE_SIZE); }
/* velocity of the voice's note as a Q15 gain (linear, 127 = 32766); 0 / out of range = full. Read it in render:
 * the firmware writes the velocity around the engine's note_on call. */
static inline int32_t op1_voice_vel_gain(const void *self)
{
    int32_t v = OP1_VOICE_VEL[op1_voice_index(self)] >> 8;
    return v > 0 && v <= 127 ? v * 258 : 32767;
}
/* Preset level trim: engines without a page 2 read preset word 7 as a hidden Q13 gain, 8192 = 1x (0 or unset = 1x,
 * 32767 = 4x). Presets set it to even out loudness; no knob shows it. Fold it into a gain once per block. */
#define OP1_TRIM_ONE 8192
static inline int32_t op1_preset_trim(const int16_t *params)
{
    return params[7] > 0 ? params[7] : OP1_TRIM_ONE;
}
/* voice object i (0..OP1_VOICES-1); readable from a screen update to show live voice state */
#define OP1_VOICE(i)     ((void *)((uintptr_t)OP1_VOICE_BASE + (uintptr_t)(i) * OP1_VOICE_SIZE))

/* One engine = these callbacks. params[0..3] = 4 knobs (0..32767), params[4] = selector,
 * params[5..7] = free preset words (default_params[5..7]). ADSR/gain applied after render. */
typedef struct {
    void (*note_on)(void *self, const int16_t *params);
    void (*render)(void *self, int16_t *out, const int16_t *params);   /* out[128] int16 */
    void (*note_off)(void *self);                                       /* may be 0 */
    uint8_t press[4];   /* encoder press per knob on the engine screen: OP1_PRESS_PAGE toggles page 2, where the
                         * knob edits preset word OP1_ENG_PAGE_WORD(k) (saved with the patch) instead of params[k];
                         * OP1_PRESS_BROWSE (engines with "uses_sample" only) opens the core's sample browser: the
                         * sampler presets as in sampler+, white loads one into the slot's sample buffer, the patch
                         * stays the engine's (screens/sbrowse.c); older cores ignore it */
} op1_engine_t;
/* Own envelope (kennel cores from 2026-11-10; plugin.json "own_envelope": true, header flag KN_FLAG_OWN_ENV: an older
 * core refuses the file, "unknown plugin flags"). The engine shapes its voices' level itself, as a drone that sustains
 * after the key is up: the entry is an op1_engine_env_t, and while a voice plays this engine R246's T2 envelope does
 * not run for it. The core's ADSR entry (kn_sound_adsr, dispatcher.c kn_engine_adsr) gives such a voice a flat
 * envelope at the stock full-sustain level for velocity 127 (velocity and the T2 knobs are not applied), so a key-up
 * (note_off is still called) changes the level only if the engine does it. The voice stays allocated until
 * finished(self) returns nonzero, asked once a block before render (R246's voice loop runs the envelope first; a voice
 * it ends is not rendered that block; audio thread: short, no division); then R246 frees
 * it. Steals, kills (sound, slot and mode changes, voice shedding, the overload bypass) still fade and free the voice
 * through the stock envelope. A loadable, non-sampler, non-input synth only. It may bring its own T2 page
 * (op1_engine_ext_t, below op1_screen_t). */
typedef struct {
    op1_engine_t voice;
    int (*finished)(void *self);                                        /* 1: silent and done, free the voice */
} op1_engine_env_t;
/* Voice-sum block (kennel cores from 2026-11-11; plugin.json "sum_block": true, header flag KN_FLAG_SUM: an older core
 * refuses the file, "unknown plugin flags"). block(bus, fresh) runs once an audio block on the synth bus: the summed
 * voices after R246's 2:1 decimator and its 35 Hz high-pass, 64 samples at 44.1 kHz, in place, before the synth FX
 * (with the FX on or off). It runs only while the built synth slot's sound is this engine (also in blocks with no
 * voice sounding, so tails ring out), never in drum or game mode. fresh is 1 when the previous block did not call it
 * (boot, another sound, drum mode, a muted engine): clear what the bus carried over. Audio thread, R246's interrupted
 * stack: keep the frame small (state and buffers static), no division per sample. finished may be 0 unless the file
 * also has own_envelope. A loadable, non-sampler, non-input synth only. With the T2 page flag too the entry is the
 * 28-byte op1_engine_ext_t (below op1_screen_t), whose first 24 bytes are this struct. */
typedef struct {
    op1_engine_t voice;
    int (*finished)(void *self);                                        /* own_envelope: as op1_engine_env_t; else 0 */
    void (*block)(int16_t *bus, int fresh);                             /* bus[64], 44.1 kHz */
} op1_engine_sum_t;
/* page-2 word per knob: blue 5, green 6, white 7, red 7 (white and red share word 7: page one of them only) */
#define OP1_ENG_PAGE_WORD(k) ((k) < 3 ? 5 + (k) : 7)
extern volatile uint8_t op1_eng_page[4];   /* synth engine screen: page 2 on per knob (blue..red) */

/* Stepped engine knob (kennel cores from 2026-11-06; an older core refuses the file: unknown import):
 * op1_engine_knob_steps(&ENGINE_x, k, n), n = 2..127, makes page 1 of knob k turn in n steps, one per encoder detent
 * (a selector: Strum's pattern). Step i's word is (2i+1) * 32767 / (2n), so (word * n) >> 15 reads i, and a word
 * saved by a finer control keeps the step it meant. n = 0 turns it back to the stock fine turn. Call it from the
 * screen's init (GUI thread). Page 2 and the coarse knobs are unchanged. */
#ifndef OP1_HOST
void op1_engine_knob_steps(const op1_engine_t *e, int knob, int n);
#endif
/* Shift + turn (kennel cores from 2026-11-10; an older core refuses the file: unknown import): op1_engine_shift(&ENGINE_x,
 * k, n) from the screen's init makes Shift + knob k on the engine's T1 page a second value, saved with the sound:
 * blue word 5 and green word 6 (n = 1: fine, delta / 4 a tick; n = 2..127: one step a detent, step i's word
 * (2i+1) * 32768 / (2n), an unset word starting at step 0), white and red two 7-bit fields of word 7 (white bits 0..6,
 * red bits 8..14; one unit a detent, through 0..n-1 for n = 2..127, 0..127 for n = 1). Bit 7 of word 7 is the engine's;
 * bit 15 is never set: R246's patch parser takes every word of a plugin engine only in 0..32767 (a saved word with bit 15
 * panics the save with error 15, and loading one would stop the boot), so the core clears it after every Shift turn
 * (kennel/kn_engshift.h). A setting that needs more room goes in the engine's record (below).
 * The turn never reaches page 1 or page 2. */
#ifndef OP1_HOST
void op1_engine_shift(const op1_engine_t *e, int knob, int n);
#else
#define op1_engine_shift(e, knob, n) ((void)(e), (void)(knob), (void)(n))
#endif

/* An engine's record (kennel cores from 2026-11-11; an older core refuses a file that imports these): up to
 * OP1_ENGINE_REC_N int16 saved with the sound beside its eight words, for settings with no room in them (outatime's
 * drive shape). The sound's JSON holds them as "eng_rec": {"e": "<engine name>", "p": [16 ints]}; the core keeps the
 * member through the patch parser (preset save and load, slots at boot) and caches each synth slot's record
 * (kennel/kn_lfo_rec.c). Stock and older firmware drop the member: the sound plays with the engine's defaults there,
 * so a record value 0 should mean the default. Picking the engine from the type list drops the record.
 *   op1_engine_rec_owner(name): the key of an engine's records, from its plugin.json "name"; work it out once.
 *   op1_engine_record(slot, owner): synth slot `slot`'s record when it is this engine's, else 0 (the defaults). Any
 *     thread, lock-free, no allocation: render reads op1_current_slot()'s, a screen OP1_SCREEN_SLOT's. The core keeps
 *     two copies a slot and switches between them, so a reader never sees half a record; the pointer stays valid, its
 *     contents change when the slot loads another sound or a record is stored.
 *   op1_engine_record_store(slot, name, p, n): the UI thread (a screen's input, the KeyHandler): n (1..16) values as
 *     the slot's record (the rest 0), playing at once; the core writes the JSON and marks the sound changed, so the
 *     stock save path saves it. -> 1, 0 for bad arguments. name: the engine's name, a string that stays.
 *   op1_engine_shift_record(e, knob, n, index): from the screen's init, like op1_engine_shift: Shift + knob steps
 *     record value `index` (0..15) through 0..n-1 (n = 2..127), one step a detent, stopping at the ends; the core
 *     stores the record (no record reads as step 0). It replaces an op1_engine_shift on that knob, and back. */
#define OP1_ENGINE_REC_N 16
static inline uint32_t op1_engine_rec_owner(const char *name)
{
    uint32_t h = 2166136261u;                    /* FNV-1a, 31 bits, never 0 */
    while (name && *name) h = (h ^ (uint8_t)*name++) * 16777619u;
    h &= 0x7FFFFFFFu;
    return h ? h : 1;
}
#ifndef OP1_HOST
const int16_t *op1_engine_record(int slot, uint32_t owner);
int op1_engine_record_store(int slot, const char *name, const int16_t *p, int n);
void op1_engine_shift_record(const op1_engine_t *e, int knob, int n, int index);
#elif !defined(KN_LFO_REC_HOST)                  /* host: a test sets host_eng_rec / host_eng_rec_owner */
__attribute__((weak)) int16_t host_eng_rec[8][OP1_ENGINE_REC_N];
__attribute__((weak)) uint32_t host_eng_rec_owner[8];
static inline const int16_t *op1_engine_record(int slot, uint32_t owner)
{ return owner && host_eng_rec_owner[slot & 7] == owner ? host_eng_rec[slot & 7] : 0; }
static inline int op1_engine_record_store(int slot, const char *name, const int16_t *p, int n)
{
    if (!name || !p || n < 1 || n > OP1_ENGINE_REC_N) return 0;
    for (int i = 0; i < OP1_ENGINE_REC_N; i++) host_eng_rec[slot & 7][i] = i < n ? p[i] : 0;
    host_eng_rec_owner[slot & 7] = op1_engine_rec_owner(name);
    return 1;
}
#define op1_engine_shift_record(e, knob, n, index) ((void)(e), (void)(knob), (void)(n), (void)(index))
#else
const int16_t *op1_engine_record(int slot, uint32_t owner);
int op1_engine_record_store(int slot, const char *name, const int16_t *p, int n);
#endif
/* An engine's data (kennel cores from 2026-11-14; an older core refuses a file that imports these): up to
 * OP1_ENGINE_DATA_MAX bytes kept with the sound, for an engine whose sound is more than its words (dx's edited voice
 * and envelope, 182 bytes). The same store as the record above (kennel/kn_lfo_rec.c: kept through the patch parser,
 * preset save and load, slots at boot, picking the engine drops it), its own JSON member "eng_data": {"e": "<engine
 * name>", "p": [104 ints]}: p[0] the byte count, then the bytes as a bit stream 15 bits a value, so every saved value is
 * 0..32767 (whatever the bytes). Stock and older firmware drop the member. Synth slots only.
 *   op1_engine_data(slot, owner, out, max): synth slot `slot`'s data when it is this engine's (owner =
 *     op1_engine_rec_owner(name)): copies up to max bytes to out -> the bytes copied, 0 for none (another engine's, no
 *     member, a store of 0 bytes). Any thread, lock-free (two copies a slot, as the record), no allocation; it unpacks
 *     the bytes, so call it on a change (a note-on, the service, a page), not every block. A store landing while it
 *     copies can mix the two (as for the record): a reader off the UI thread that must be exact reads twice and
 *     compares.
 *   op1_engine_data_store(slot, name, data, n): the UI thread (the engine's input callback, a screen's input, the
 *     KeyHandler): n bytes (0..OP1_ENGINE_DATA_MAX; 0 = no data) as the slot's data, read back at once; the core writes
 *     the JSON and marks the sound changed, so the stock save path saves it. -> 1, 0 for bad arguments. Never from the
 *     main loop (op1_engine_ext2_t.service): a store there can be preempted by one from the KeyHandler.
 *     name: the engine's name (plugin.json "name"), a string that stays. */
#define OP1_ENGINE_DATA_MAX   192
#define OP1_ENGINE_DATA_WORDS 103                /* ceil(192 * 8 / 15) */
#ifndef OP1_HOST
int op1_engine_data(int slot, uint32_t owner, void *out, int max);
int op1_engine_data_store(int slot, const char *name, const void *data, int n);
#elif !defined(KN_LFO_REC_HOST)                  /* host: plain bytes per slot (host_eng_data / host_eng_data_n) */
__attribute__((weak)) uint8_t host_eng_data[8][OP1_ENGINE_DATA_MAX];
__attribute__((weak)) int host_eng_data_n[8];
__attribute__((weak)) uint32_t host_eng_data_owner[8];
static inline int op1_engine_data(int slot, uint32_t owner, void *out, int max)
{
    if (!owner || host_eng_data_owner[slot & 7] != owner || !out || max <= 0) return 0;
    int n = host_eng_data_n[slot & 7] < max ? host_eng_data_n[slot & 7] : max;
    for (int i = 0; i < n; i++) ((uint8_t *)out)[i] = host_eng_data[slot & 7][i];
    return n;
}
static inline int op1_engine_data_store(int slot, const char *name, const void *data, int n)
{
    if (!name || !name[0] || n < 0 || n > OP1_ENGINE_DATA_MAX || (n && !data)) return 0;
    for (int i = 0; i < n; i++) host_eng_data[slot & 7][i] = ((const uint8_t *)data)[i];
    host_eng_data_n[slot & 7] = n;
    host_eng_data_owner[slot & 7] = op1_engine_rec_owner(name);
    return 1;
}
#else
int op1_engine_data(int slot, uint32_t owner, void *out, int max);
int op1_engine_data_store(int slot, const char *name, const void *data, int n);
#endif

/* ---- access to the built-in sampler's per-slot sample (record it with the "sampler" engine) ----
 * 0x01DF6F78[slot] -> { SampleBuffer *sb; rate }   SampleBuffer: +0 int16 *data (8 guard samples,
 * then up to 264600 samples = 6 s mono 44.1 kHz), +4 int16 peak[2067] (max per 256 samples),
 * +0x1038 int capacity. Current synth slot: *(int*)0x01AAAC0C.  Engines with "uses_sample" in their
 * plugin.json also get the slot's synth_<slot>.raw loaded at boot (like the sampler). */
#define OP1_SAMPLE_GUARD   8
#define OP1_SAMPLE_MAX     264600
#define OP1_PEAK_BUCKETS   0x813
#ifndef OP1_HOST
static inline int op1_current_slot(void) { return *(volatile int *)0x01AAAC0C; }
static inline const uint8_t *op1_sample_buffer(int slot)
{
    uint32_t *obj = ((uint32_t **)0x01DF6F78)[slot & 7];
    return obj ? (const uint8_t *)obj[0] : 0;
}
static inline const int16_t *op1_sample_data(const uint8_t *sb)
{ return *(int16_t *const *)sb + OP1_SAMPLE_GUARD; }
static inline const int16_t *op1_sample_peaks(const uint8_t *sb) { return (const int16_t *)(sb + 4); }
#endif

/* ---- custom effects (run inside the hidden "filter" FX slot, fx type 5, graphics mmmf.svg) ----
 * Mono FX objects (synth or drum FX, one active at a time) live at 0xFFB00600. The firmware calls
 *   init(self, pos)                       pos 0 = synth FX, 1 = drum FX
 *   render(self, int16 buf[64], params)  in place, 64 samples per call; params[0..3] = 4 FX knobs
 *                                          (0..32767), params[4] = selector (0x5300+n), [5..7] free.
 * Each position owns a scratch buffer shared by all built-in FX (delay/spring/...): 176460 bytes
 * (44115 int32) at op1_fx_scratch(pos); only the active FX of that position uses it.
 * FX output meter: int16 at 0xFF801774 + pos*16 (peak with decay, shown on screen). */
#define OP1_FX_BLOCK        64
#define OP1_FX_SCRATCH_BYTES 176460
/* Big FX buffer (kennel cores from 2026-10-21, OP1_POOL_API 1): a 1 MiB lease per position in kennel's pool, same
 * rules as the scratch (only the active FX of that position uses it, contents undefined after an FX switch, never a
 * DMA target). Cleared once at boot, not on an FX switch: don't clear it in init (a 128-sample block can't afford
 * 1 MiB of stores); keep a valid length instead. *size gets its size (read it: never assume 1 MiB); 0 = no lease.
 * A file that imports it is refused by older cores ("an import is not exported by the core"). */
#define OP1_POOL_API 1
/* Fast FX lease (kennel cores from 2026-11-06, OP1_FAST_API 1): a smaller lease per position in R246's heap 0 (SDRAM
 * bank 0), for state the FX reads every block; op1_fx_big's pool shares bank 2 with the display, where a cold cache
 * line costs the unit ~1.8x. The rules of op1_fx_big (only the active FX of that position, undefined after an FX
 * switch, cleared once at boot, never a DMA target). *size gets its size (224 KiB in these cores; read it, and fall
 * back to op1_fx_big when it is 0 or too small): the core takes the leases at boot only when a loaded file imports
 * op1_fx_fast and heap 0 can give them. A file that imports it is refused by older cores. */
#define OP1_FAST_API 1
#include "op1_l1.h"                              /* the L1 pool (kennel cores from 2026-10-30) */
/* op1_sin(k) = OP1_SINE_TABLE[k & 8191] = sin(2 pi k / 8192) x 32767 for any k (one turn = 8192, only k & 8191 is
 * used): the name and contract of op1r 55's op1_sin. op1r keeps the whole 16 KB table in L1; kennel's pool holds a
 * quarter of it (op1_l1_sine_quarter, entries 0..2048), so op1_sin folds: k's bits 0..11 sign-extended (-2048 ..
 * 2047, the place around the half-wave's peak), that entry's absolute index, negated when bit 12 is set. R246's
 * table is lrint(32767 sin(2 pi k / 8192)), exactly quarter-wave symmetric (s[4096 + k] = -s[k], s[2048 + i] =
 * s[2048 - i]; all 8192 k checked on the emulator's live table, OP1-Emulator run/sine-blot-2026-11-06/emu/
 * verify_fold.txt), so this returns the table's own value, bit for bit. Without the pool (off, a host build) it folds on OP1_SINE_TABLE's first quarter: the same numbers.
 * In a loop, fetch the table once per render (op1_sin_tab) and read with op1_sin_q(tab, k): op1_sin calls the core
 * for the pointer every time. Render and an FX's init only (not note_on, which can run on the key thread, nor a
 * screen): the core fills the L1 quarter at its first use, and a caller the audio callback preempts there could read
 * it half filled; elsewhere use OP1_SINE_TABLE.
 * A file that uses these imports op1_l1_sine_quarter (cores from 2026-10-30). */
static inline const int16_t *op1_sin_tab(void)
{
#if defined(__bfin__)
    const int16_t *q = op1_l1_sine_quarter();
    if (q) return q;
#endif
    return OP1_SINE_TABLE;
}
static inline int32_t op1_sin_q(const int16_t *tab, int32_t k)
{
    const int32_t i = (int32_t)((uint32_t)k << 20) >> 20;              /* -2048 .. 2047 */
    const int32_t n = (int32_t)((uint32_t)k << 19) >> 31;              /* -1: bit 12, the negative half-wave */
    const int32_t v = tab[__builtin_abs(i)];
    return (v ^ n) - n;
}
static inline int32_t op1_sin(int32_t k) { return op1_sin_q(op1_sin_tab(), k); }
#ifndef OP1_HOST
void *op1_fx_big(int pos, uint32_t *size);
void *op1_fx_fast(int pos, uint32_t *size);
#endif
/* Declared buffer (kennel cores from 2026-10-21): state that survives FX switching. In the plugin:
 *     OP1_BIGBUF(my_buf, 64 * 1024, 256 * 1024);      (a global, plugin.json "bigbuf": "my_buf")
 * After every file is loaded the core writes my_buf.ptr / my_buf.size (zeroed memory, 32-byte aligned): max if the
 * pool has room, else what is left if that is at least min; size 0 when min is 0 and nothing is left (go without).
 * At most 512 KiB per file; a file whose min doesn't fit is refused (a "not loaded" toast), first come first served in
 * load order. Read ptr in init / render, never at load. Older cores refuse the file (unknown flag bit 4). */
typedef struct { uint32_t magic, version, min, max; void *ptr; uint32_t size; } op1_bigbuf_t;
#define OP1_BIGBUF(name, mn, mx) op1_bigbuf_t name = { 0x42424E4Bu, 1, (mn), (mx), 0, 0 }
#ifndef OP1_HOST
static inline void *op1_fx_scratch(int pos) { return ((void **)0x01AB8BA0)[pos]; }
/* FX screens: which FX position is shown (0 synth, 1 drum) and its knob words of the current slot
 * (raw words [0..3] knobs - range depends on the FX type, use op1_fx_knobs_live for 0..32767; [4] selector) */
/* FX positions: 0 synth, 1 drum, 2 master (stereo, mixer). The FX screens' edit mode 0x01DF4E3C is 0/1/3 (3 =
 * master, as read_fx_param's pos). Master knob words: 0xFF8016C4 (one set), master FX type 0xFF801090. */
#define OP1_FX_MASTER 2
static inline int op1_fx_screen_pos(void) { int m = *(volatile int *)0x01DF4E3C; return m == 3 ? OP1_FX_MASTER : (m == 1); }
static inline const int16_t *op1_fx_knobs(int pos)
{
    if (pos == OP1_FX_MASTER) return (const int16_t *)0xFF8016C4;
    int slot = *(volatile int *)(pos ? 0xFF8016D8 : 0xFF8016D4) & 7;
    return (const int16_t *)((pos ? 0xFF8015C4 : 0xFF801444) + slot * 16);
}
/* raw FX knob word -> 0..32767 using the filter type's (fx type 5) range table {min, max, ?} per knob at
 * 0x01DE5C50 + type*0x30 (filled at boot; same scaling as read_fx_param). Custom FX run in the filter
 * slot, so their raw knob words cover only [min, max] of the filter's knobs. */
static inline int32_t op1_fx_param_q15(const int16_t *p, int i)
{
    const int16_t *rg = (const int16_t *)(0x01DE5C50 + 5 * 0x30 + i * 6);
    int32_t lo = rg[0], hi = rg[1], v = p[i];
    if (hi <= lo) return v < 0 ? 0 : v;                  /* table not filled: raw */
    v = (v - lo) * 32767 / (hi - lo);
    return v < 0 ? 0 : (v > 32767 ? 32767 : v);
}
static inline volatile int16_t *op1_fx_meter(int pos) { return (volatile int16_t *)(0xFF801774 + pos * 16); }
#endif

typedef struct {
    void (*init)(int pos);                                         /* FX (re)created at pos      */
    void (*render)(int pos, int16_t *buf, const int16_t *params);   /* 64 samples, in place       */
    uint8_t press[4];        /* encoder press per knob (blue..red): OP1_PRESS_NONE / _PAGE / _LATCH */
} op1_fx_t;
/* Optional kennel .knl extension (plugin.json "stereo": true, FX only).
 * The mono prefix is unchanged. Synth/drum still call mono.render; master calls
 * render_stereo once with independent L/R buffers. All three callbacks are required.
 * Legacy mono effects keep the original mono-sum master routing. An op1r 42 .op1p FX with header flag
 * OP1P_F_STEREO (its op1_fx_t has render_stereo at +12: this same layout) is loaded as a stereo FX too. */
typedef void (*op1_fx_stereo_render_t)(int pos, int16_t *left, int16_t *right, const int16_t *params);
typedef struct {
    op1_fx_t mono;
    op1_fx_stereo_render_t render_stereo;
} op1_fx_stereo_t;

/* Shift + turn and a push flag on a custom FX's page (kennel cores from 2026-11-11; an older core refuses the file:
 * unknown import), the FX twin of op1_engine_shift with the same word layout (kennel/kn_fxshift.h). From the screen's
 * init (GUI thread), with the FX's op1_fx_t (a stereo FX's .mono):
 *   op1_fx_shift(fx, k, n): Shift + knob k on the FX page sets a second value, saved with the sound: blue word 5 and
 *     green word 6 (n = 1: fine, delta / 4 a tick; n = 2..127: one step a detent, step i's word (2i+1) * 32768 / (2n),
 *     an unset word from step 0), white and red two 7-bit fields of word 7 (white bits 0..6, red bits 8..14; one unit a
 *     detent through 0..n-1, n = 2..127, or 0..127 for n = 1). The turn never reaches page 1 or page 2.
 *   op1_fx_push_bit(fx, k, bit): a push of knob k toggles bit 7 or 15 of word 7 (saved), instead of the knob's press.
 * Words 0..4 are not touched; an FX that calls neither keeps every stock path. */
#ifndef OP1_HOST
void op1_fx_shift(const op1_fx_t *fx, int knob, int n);
void op1_fx_push_bit(const op1_fx_t *fx, int knob, int bit);
#else
#define op1_fx_shift(fx, knob, n) ((void)(fx), (void)(knob), (void)(n))
#define op1_fx_push_bit(fx, knob, bit) ((void)(fx), (void)(knob), (void)(bit))
#endif
/* Encoder presses on a custom FX page (dispatcher.c hooks the KeyHandler dispatch):
 *  OP1_PRESS_PAGE : press toggles the knob between its normal parameter (params[k]) and a second
 *                   parameter in params[5 + k] (k = 0..2 only: words 5..7, 0..32767, saved with the patch)
 *  OP1_PRESS_LATCH: press toggles a flag (not saved), e.g. freeze
 *  OP1_PRESS_PAGE_SEMI: as _PAGE, but the second parameter is a pitch of -24 .. +24 semitones (the word law below):
 *                   one encoder detent = one semitone, snapped to whole semitones; Shift + turn = one cent
 * State per FX position (0 synth, 1 drum, 2 master): op1_fx_page[pos][k] = 1 while page 2 / latch is on.
 * FX state must be kept per position 0..2 (the master can run the same custom FX as an instrument). */
enum { OP1_PRESS_NONE = 0, OP1_PRESS_PAGE = 1, OP1_PRESS_LATCH = 2, OP1_PRESS_BROWSE = 3,   /* BROWSE: synth engines */
       OP1_PRESS_PAGE_SEMI = 4 };

/* Synth engines (op1_engine_t.press[k]): OP1_PRESS_PAGE_STEPS(n), n = 2..63, is OP1_PRESS_PAGE whose page-2 word turns in
 * n steps, one per encoder detent (a selector: Amp's voice). Step i is the word ((2i+1) * 32768) / (2n), the step of a
 * word is (word * n) >> 15; page 1 of the knob is unchanged. Use op1_press_steps(p) to tell the two kinds apart. */
#define OP1_PRESS_PAGE_STEPS(n)  (0x40 + (n))
static inline int op1_press_steps(unsigned p) { return p >= 0x42 && p <= 0x7F ? (int)p - 0x40 : 0; }

/* OP1_PRESS_PAGE_SEMI word law (HAIL's PITCH): centre 16384 = 0 with a dead band of +-600, then 15784 units for
 * 24 semitones each way. op1_semi_word / op1_semi_cents convert between the word and cents (-2400 .. +2400);
 * a whole semitone or cent round-trips exactly. */
#define OP1_SEMI_DEAD  600
#define OP1_SEMI_SPAN  (16384 - OP1_SEMI_DEAD)
static inline int op1_semi_word(int cents)
{
    if (cents > 2400) cents = 2400;
    if (cents < -2400) cents = -2400;
    if (!cents) return 16384;
    const int a = cents < 0 ? -cents : cents, u = OP1_SEMI_DEAD + (a * OP1_SEMI_SPAN + 2399) / 2400;   /* rounded up: the DSP's truncating semitone maths lands exactly */
    return cents < 0 ? 16384 - u : (16384 + u > 32767 ? 32767 : 16384 + u);
}
static inline int op1_semi_cents(int word)
{
    int pv = word - 16384;
    pv = pv > OP1_SEMI_DEAD ? pv - OP1_SEMI_DEAD : (pv < -OP1_SEMI_DEAD ? pv + OP1_SEMI_DEAD : 0);
    const int a = pv < 0 ? -pv : pv, c = (a * 2400 + OP1_SEMI_SPAN / 2) / OP1_SEMI_SPAN;
    return pv < 0 ? -c : c;
}
/* FX knobs in steps (kennel cores from 2026-11-04; dispatcher.c knob_event_hook, kn_coarse.h):
 *  press[k] = OP1_PRESS_PAGE_STEPS(n), k = 0..2: page 2 as OP1_PRESS_PAGE, its word turns in n steps (as for engines)
 *  press[k] = OP1_FX_STEPS(n), n = 2..127, k = 0..3: no press action; the page-1 word turns in n steps, one per
 *             detent, over the knob's range (a program selector). Read the step as (op1_fx_param_q15(params, k) * n) >> 15.
 * An older core turns such knobs in its fine steps (OP1_FX_STEPS) or not at all on page 2 (PAGE_STEPS). */
#define OP1_FX_STEPS(n)  (0x80 + (n))
static inline int op1_fx_steps(unsigned p) { return p >= 0x82 && p <= 0xFF ? (int)p - 0x80 : 0; }
extern volatile uint8_t op1_fx_page[3][4];
/* Wrapping stepped knob (kennel cores from 2026-11-06): op1_fx_wrap[pos][k] = m (2..n) makes the OP1_FX_STEPS(n) knob k
 * turn round within its steps 0..m-1 (past the last to the first and back); 0 (the default, and after the core picks
 * a new FX for the position) stops at the ends. The FX sets it, e.g. in render when its step count changes (rackverb:
 * the unit's program count). The words keep their meaning: step i's word is the same with or without it. */
extern volatile uint8_t op1_fx_wrap[3][4];

/* ---- sidechain sources (core export, op1r 52 61a1ccd; kennel cores from 2026-11-06, an older core refuses the file:
 * unknown import) ---- op1_sc_source(src, out) writes this block's 64 samples of a signal other than the FX's own input
 * into out and returns 1 if the source has data (0 and zeros: not available yet, or an unknown source).
 * T1..T4 = the tape tracks pre-fader (screens/usbtrack.c tr_out; asking starts the track work, which runs until 32
 * blocks after the last ask; the first block is zeros), TAPE = their sum, IN = R246's input block (mic / line / USB,
 * mono, 0xFF800CB4), INST = the instrument bus (mono, after its FX: meaningful for the master FX). Audio thread: call
 * from render only, once per block per source. */
enum { OP1_SC_T1 = 1, OP1_SC_T2, OP1_SC_T3, OP1_SC_T4, OP1_SC_TAPE, OP1_SC_IN, OP1_SC_INST };
int op1_sc_source(int src, int16_t *out);

/* ---- beat clock (read-only; read it once per render block, never per sample) ----
 * The stock metronome's beat clock (metronome.cpp state at 0x01AADABC; tape/countin.c counts in on it). It runs
 * whether the metronome is heard or not, at the OP-1 tempo (BPM setting or MIDI clock), restarts on a beat when the
 * tape starts and, while it follows the tape, moves with the tape speed (and stands still while the tape is stopped).
 * It is the OP-1's only shared beat phase: the op1r sequencers (euclid, dots, shield, peal) run at the same tempo
 * (player ticks, 96 per beat) but count their steps from where each one was started.
 * Times are in 1/16384 output samples (44.1 kHz), as the firmware keeps them: beat length = 2646000 / BPM * 16384
 * (120 BPM: 22050 << 14). The metronome render (64 samples) runs once per audio callback; `next` is exact for the
 * block being rendered if the FX runs before it in the callback, else it is one block (1.45 ms) early. */
typedef struct {
    int32_t len;            /* beat length, 1/16384 samples (<= 0: no clock yet) */
    int32_t next;           /* time to the next beat from the first sample of this block, 1/16384 samples (0 .. len) */
    int32_t step;           /* clock advance per 64-sample block: 0x100000 = real time, else the tape speed; 0 = stands still */
    int32_t tape_pos;       /* tape position (samples); with follows_tape a beat sits at a multiple of len >> 14 */
    uint8_t follows_tape;   /* 1: the clock moves with the tape (stands still while the tape is stopped) */
} op1_beat_t;
#ifndef OP1_HOST
static inline void op1_beat_clock(op1_beat_t *b)
{
    const volatile uint8_t *m = (const volatile uint8_t *)0x01AADABC;
    b->len = *(const volatile int32_t *)(m + 0x1C);
    b->next = *(const volatile int32_t *)(m + 0x20);
    b->follows_tape = m[0x14];
    uint32_t sp = *(const volatile uint32_t *)0xFF802970;       /* tape speed: phase step (sp >> 21) << 14, as the render */
    b->step = b->follows_tape ? (int32_t)((sp >> 21) << 14) : 0x100000;
    b->tape_pos = *(const volatile int32_t *)0xFF802974 >> 6;  /* 1/64 samples */
}
#else
/* host: the harness sets the clock through host_beat() (one clock per translation unit: include the plugin source) */
static inline op1_beat_t *host_beat(void) { static op1_beat_t b; return &b; }
static inline void op1_beat_clock(op1_beat_t *b) { *b = *host_beat(); }
#endif

static inline int16_t op1_sat16(int32_t x)
{ return x > 32767 ? 32767 : (x < -32768 ? -32768 : (int16_t)x); }
static inline int32_t op1_mul16(int32_t a, int32_t b) { return (a * b) >> 15; }  /* Q15 */

/* ---- custom screens (GUI thread) — see docs/16 ----
 * An engine may own a screen: an SVG in content/display plus init/update callbacks. The SDK builds a
 * screen object (iter screen slot 0x14) and shows it while that engine is selected. Geometry is SVG
 * user units (320x160) in Q10 fixed point (1.0 = 1024). */
typedef struct { int32_t x, y; } op1_pt;                 /* Q10 */
typedef struct {
    void (*init)(void *scr);                              /* after SVG load: look up nodes */
    void (*update)(void *scr, int dt);                    /* every frame while visible */
} op1_screen_t;
/* Own T2 page (kennel cores from 2026-11-11; plugin.json "t2_page": true next to "own_envelope": true, header flag
 * KN_FLAG_T2_PAGE, 0x80: an older core refuses the file, "unknown plugin flags"). An own-envelope engine's T2 knobs
 * reach no envelope, so it may bring its own T2 page instead of R246's ADSR page: the entry is op1_engine_ext_t (28 bytes; its block
 * field is the sum hook's when the file also has "sum_block", else 0), t2 (required with the flag) as an input engine's tuner (op1_input.h): an op1_screen_t the core builds a screen object
 * for (an empty SVG, drawn in code) and puts at screen 22 while a sound with this engine is the current synth slot.
 * Shift on T2 still shows R246's play mode page (screen 40). Without the flag the engine keeps the stock T2 page.
 * The encoders on the page are R246's own: blue, green, white and red turn the slot's four T2 words (adsr_params
 * words 0..3, "attack", "decay", "sustain", "release" in R246) over the stock ranges (0, 1, 3: 64..16320; 2: 0..32767;
 * picking the engine keeps the slot's words) and save them in the sound and
 * its presets (key "adsr"), as on the stock page; op1_param_set(OP1_PARAM_ENV, k, v) and MIDI CC maps reach them too.
 * The engine reads them as its parameters with op1_t2_words(slot) (below) and gives them its own meaning; nothing in
 * the core applies them to such a voice. The pushes do nothing on the page (R246 has none on T2; latch's red push
 * needs the stock ADSR page). Loader and packer refuse the flag without own_envelope.
 * "t2_swallow": true (with t2_page; header flag KN_FLAG_T2_SWALLOW, 0x100; older cores refuse it): kennel takes the encoders
 * and pushes on the page, so no T2 word changes and the sound is not marked edited; Shift still shows screen 40. MIDI CC and
 * op1_param_set(OP1_PARAM_ENV) still change the words. The entry stays 28 bytes. */
/* One entry layout for the hooks that grow the engine object past op1_engine_env_t (the sum hook, KN_FLAG_SUM 0x40,
 * and the T2 page, KN_FLAG_T2_PAGE 0x80). op1_engine_sum_t (above) is the first 24 bytes, op1_engine_ext_t all 28;
 * a file with the T2 page flag and no KN_FLAG_SUM gives a 28-byte entry with block = 0; with both, block is the sum
 * hook's callback. */
typedef struct {
    op1_engine_t voice;                                                 /* +0  */
    int (*finished)(void *self);                                        /* +16 own envelope (KN_FLAG_OWN_ENV) */
    void (*block)(int16_t *bus, int fresh);                             /* +20 op1_engine_sum_t.block: with KN_FLAG_SUM, else 0 */
    const op1_screen_t *t2;                                             /* +24 the T2 page; not 0 */
} op1_engine_ext_t;
/* Engine hooks for an engine with its own pages (kennel cores from 2026-11-14; dx). Three header flags, any of them makes
 * the entry an op1_engine_ext2_t (40 bytes): the 28-byte op1_engine_ext_t, then the fields below. A field whose flag is
 * not set must be 0, and so are +20 / +24 without sum_block / t2_page (+16 may be a callback; it is called only with
 * own_envelope). An older core refuses the
 * file ("unknown plugin flags"); the loader and packer refuse the flags on an FX, a sampler or an input engine.
 *   plugin.json "engine_input": true (KN_FLAG_ENG_INPUT, 0x200) -> input(page, ev, a, b), KeyHandler thread, on:
 *     page OP1_ENG_T1 (0): the engine's T1 screen (iter screen 0x14, synth mode, the current synth slot's sound is this
 *       engine; with or without a screen of its own);
 *     page OP1_ENG_T2 (1): its own T2 page (needs "t2_page"; with "t2_swallow" what input leaves goes nowhere, without it
 *       R246's T2 controller turns the T2 words as before);
 *     page OP1_ENG_T4 (3): its own T4 page ("t4_page"; what input leaves goes nowhere there: no stock LFO edit).
 *     ev OP1_ENG_TURN: a = encoder 0..3 (blue, green, white, red), b = R246's delta (OP1_ENG_DETENT a detent, more when
 *       turned fast: op1_eng_detents below counts detents);
 *     ev OP1_ENG_PUSH: a = encoder 0..3, b = 1 down / 0 up;
 *     ev OP1_ENG_KEY:  a = R246's key code of T1..T4 (0x06..0x09; the four keys only), b = 1 down / 0 up.
 *     Return 1: taken (R246 never sees it), 0: as without the hook. A key's or push's up goes where its down went: the
 *     engine gets the up of every down it took (even after the page changed) and never one whose down it left. Shift: op1_shift_held(), FN: op1_fn_held() (any
 *     thread). The T4 key on its own T4 page is always taken (the stock T4-again would switch the held-off LFO on).
 *     From input the engine may store its data (op1_engine_data_store), record, and words (op1_engine_word_set).
 *   plugin.json "t4_page": true (KN_FLAG_T4_PAGE, 0x400) -> t4: an op1_screen_t the core builds a screen object for (an
 *     empty SVG, drawn in code, as t2) and shows on T4 while the current synth slot's sound is this engine: R246's synth
 *     T4 page selector (ScreenId::for_lfo, CALL at 0x01A50560) gets screen 0x1C with it (the midi LFO class's id, as the
 *     quad LFO). For such sounds the stock LFO is held off (not verified natively yet that R246's audio path gates on
 *     the flag alone): the main loop clears the slot's live LFO-on flag
 *     (0x01AAAC28[slot]) while the sound is current and sets it back from the sound's "lfo_active" once the slot's
 *     sound is another engine's; the JSON is never changed (a saved sound keeps its LFO for other firmware). A few
 *     blocks after a load can run with the LFO before the main loop clears it.
 *   Off overlays (a core rule, 3.3 rc9): an engine's own T2 or T4 page is never covered by R246's "off" overlays. R246
 *     has three that follow the screen: LFO OFF on the LFO screens 24..30 while the slot's LFO is off, FX OFF on the FX
 *     screens 8..15 while that FX is bypassed, and the sequencer's off popup on its six screens. None is on screen 22,
 *     so a T2 page (t2_page, or an input engine's tuner) gets none. On T4 the stock LFO is held off (above), so the core
 *     skips LFO OFF while screen 0x1C holds any t4_page engine's page (kn_lfo_bypass, R246's check otherwise): the LFO
 *     there is the engine's own. An LFO plugin's page on 0x1C (the quad LFO's objects) is the slot's LFO and keeps
 *     R246's LFO OFF.
 *   plugin.json "service": true (KN_FLAG_ENG_SERVICE, 0x800) -> service(ev, arg) on the main loop (kennel's main-loop
 *     service, the thread of the feature events), for every loaded engine with it, whatever sound is current:
 *     OP1_EV_BOOT_DONE once after boot, OP1_EV_DISK (arg 0) when disk mode ends, OP1_EV_SERVICE (arg 0) every pass
 *     (keep that cheap). It may read (op1_engine_data, op1_engine_record, the op1_file_* calls of op1_feature.h) but
 *     must not store data, records or words: the KeyHandler preempts the main loop; set a flag and store from input. */
enum { OP1_ENG_T1 = 0, OP1_ENG_T2 = 1, OP1_ENG_T4 = 3 };
enum { OP1_ENG_TURN = 1, OP1_ENG_PUSH = 2, OP1_ENG_KEY = 3 };
#define OP1_ENG_DETENT 1024
typedef struct {
    op1_engine_ext_t ext;                                               /* +0..+27 */
    int (*input)(int page, int ev, int a, int b);                       /* +28 KN_FLAG_ENG_INPUT, else 0 */
    const op1_screen_t *t4;                                             /* +32 KN_FLAG_T4_PAGE, else 0 */
    void (*service)(int ev, int32_t arg);                               /* +36 KN_FLAG_ENG_SERVICE, else 0 */
} op1_engine_ext2_t;
/* whole detents in a turn's delta, the rest kept in *acc (one accumulator per encoder) */
static inline int op1_eng_detents(int32_t *acc, int delta)
{
    *acc += delta;
    const int d = *acc / OP1_ENG_DETENT;
    *acc -= d * OP1_ENG_DETENT;
    return d;
}
/* Set word k (0..3, 5..7; 4 is the selector) of the current synth slot's sound to v (0..32767: R246's patch parser
 * takes nothing else) and keep it (the patch setter: saved with the sound), when that sound is engine e's. UI thread
 * (input). -> 1, 0 for another sound or bad arguments. dx: word 5 the bank, 6 the voice. */
#ifndef OP1_HOST
int op1_engine_word_set(const op1_engine_t *e, int k, int v);
static inline int op1_shift_held(void) { return *(volatile uint8_t *)0x01DD7F78 != 0; }
static inline int op1_fn_held(void) { return *(volatile uint8_t *)0xFF9077F4 != 0; }
#else
__attribute__((weak)) int16_t host_eng_words[8][8];
__attribute__((weak)) uint8_t host_shift_held, host_fn_held;
static inline int op1_engine_word_set(const op1_engine_t *e, int k, int v)
{ if (!e || k < 0 || k > 7 || k == 4 || v < 0 || v > 32767) return 0; host_eng_words[0][k] = (int16_t)v; return 1; }
static inline int op1_shift_held(void) { return host_shift_held; }
static inline int op1_fn_held(void) { return host_fn_held; }
#endif
#define OP1_Q10(v)          ((int32_t)((v) * 1024))
#ifndef OP1_HOST
#define op1_find_node(scr, id) (((void *(*)(void *, const char *))0x01A3B580)((scr), (id)))
#define op1_node_set_transform(node, m9) (((void (*)(void *, const int32_t *))0x019EAD58)((node), (m9)))
#define op1_node_line_rgba(scr,id) (((uint8_t *(*)(void *,const char *))0x01A3B854)((scr),(id)))
#define op1_node_fill_rgba(scr,id) (((uint8_t *(*)(void *,const char *))0x01A3B96C)((scr),(id)))

/* node +0x50: visible flag; a group (<g>) with 0 skips its children (group draw 0x019EB818) */
#define op1_node_set_visible(node, on) (((volatile uint8_t *)(node))[0x50] = (uint8_t)((on) != 0))
#define op1_screen_draw(scr, dt) (((void (*)(void *, int))0x01A3B4C8)((scr), (dt)))   /* render SVG */
#define op1_raster()        (((void *(*)(void))0x01A3B490)())
#define op1_raster_line(r, p0, p1, w_q10, rgba) \
    (((void (*)(void *, const op1_pt *, const op1_pt *, int32_t, const uint8_t *))0x01A24A4C)((r), (p0), (p1), (w_q10), (rgba)))
#define OP1_SCREEN_SLOT     (*(volatile int *)0x01DF4E38)  /* instrument slot the screen shows */
static inline const int16_t *op1_synth_knobs(int slot) { return (const int16_t *)(0xFF8013C4 + (slot & 7) * 16); }
/* The four T2 words of a synth slot (R246's adsr_params, 8 x int16 per slot at 0x01B60EF0: words 0..3 are the T2
 * knobs, 4 the play mode, 5 portamento), as saved: no LFO applied. For an own-envelope engine's own T2 page and its
 * render (op1_engine_env_page_t): render reads op1_t2_words(op1_current_slot()), the slot the voices play; a screen
 * reads OP1_SCREEN_SLOT's. Read only: the knobs write them (any thread reads; a turn changes one word at a time). */
static inline const volatile int16_t *op1_t2_words(int slot) { return (const volatile int16_t *)(0x01B60EF0 + (slot & 7) * 16); }
#endif /* !OP1_HOST */
/* Gfx-only native static-prefix cache. Static prefix must be drawn first on the cleared raster.
 * first_live: first mutable top-level SVG child, NULL if all SVG children are static. The core bounds storage,
 * preserves native pixels and falls back on unsupported panels or a full arena. See docs/screen-art.md. */
/* op1_screen_cached_extra(fn), just before op1_screen_draw_cached: fn(scr) draws more static pixels (op1_raster_line
 * etc.) that join the cached prefix: called after the prefix on the frame that captures it, so later frames restore
 * them with the art; called after the whole SVG when there is no cache. Only drawing that never changes and does not
 * overlap the live suffix (the reel, ...) belongs there. Needs a core with it (2026-11-10). */
#ifndef OP1_HOST
void op1_screen_draw_cached(void *scr, int dt, void *first_live);
void op1_screen_cached_extra(void (*fn)(void *scr));
#else
static void (*op1_host_cached_extra)(void *scr) __attribute__((unused));
static inline void op1_screen_cached_extra(void (*fn)(void *scr)) { op1_host_cached_extra = fn; }
#define op1_screen_draw_cached(scr,dt,first_live) do { void (*op1_xf_)(void *) = op1_host_cached_extra; \
    op1_host_cached_extra = 0; op1_screen_draw((scr),(dt)); if (op1_xf_) op1_xf_(scr); } while (0)
#endif
/* Frame skip (kennel/kn_gfx.c, screens/guiskip.c from op1r-src 59): the core hashes what each frame draws through
 * R246's drawing calls (paths, SVG shapes, text, dims, dotted lines) and skips rasterising a frame that would equal
 * the one on the panel; screens need nothing for that. Code that writes raster pixels itself (not through those
 * calls) must feed the hash with what it drew (op1_screen_hash, any 32-bit values that change when its pixels do), or
 * the panel keeps the old picture. op1_screen_redraw (any thread) renders the next two frames whatever the hash says.
 * Needs a core with them (2026-11). */
#ifndef OP1_HOST
void op1_screen_hash(void *scr, uint32_t value);
void op1_screen_redraw(void);
#else
static inline void op1_screen_hash(void *scr, uint32_t value) { (void)scr; (void)value; }
static inline void op1_screen_redraw(void) { }
#endif
/* ---- the panel for code that writes raster pixels itself ----
 * R246's raster object (op1_raster()) is { pixels, columns, bytes per row, rows }. Its columns and rows are the display
 * geometry words 0xFF8017C0 / 0xFF8017BC, which display_geometry_init (0x019763B8) sets early in the main init, before
 * the panel probes, and again only from the register-pair probe: default panel 198 / 400, "C2" register-pair panel
 * 188 / 376, and on the SSD1963 panel and the 320-row 8-bit panel still 198 / 400 (read in the emulator's panel models,
 * OP1-Emulator docs/firmware/display.md "Panel variants"). So the raster's rows are not the panel's.
 * The stock UI draws through the screen matrix (0x01DE5E68, nine Q10 words, row vectors), which the raster's
 * constructor (0x01A2361C, once, after the probes; nothing else writes it) builds from the panel flags:
 * { 0, -s, 0,  s, 0, 0,  0, 320 s, 1024 } with s = 0x500 (400 rows), 0x4B3 (376) or 0x400 (320): unit (x, y) lands on
 * memory row 320 s - s x and column s y. Pixel (x, y) of a page laid out for the panel's rows is therefore
 * pixels[(rows - 1 - x) * 256 + y] on every panel: no column offset (the C2 panel's DMA from column 2 and the SSD1963
 * panel's bottom-up scan are R246's, below the frame, and stock drawing sits where this puts it), no flip.
 *   op1_panel_rows(raster): the rows to lay a page out for (columns: rows / 2), from the matrix: 400, 376 or 320 when it
 *     has the form above with 320 s == its row translation and the rows fit the raster's; else the raster's rows
 *     (a zero matrix before the constructor ran, anything unknown). The bytes per row stay the raster's (512).
 *     Pages laid out this way draw where the stock UI does; keep a margin of a few pixels at the edges as stock does
 *     (docs/screen-art.md: art inside x 2..318).
 *   op1_raster_live(raster): 0 in a frame-skip record frame (screens/guiskip.c), when the raster points at a scratch
 *     buffer that is neither cleared nor shown and R246's drawing calls draw nothing. Pixels a page draws there are
 *     thrown away, which is fine; pixels it reads back to keep (a still part cached from the frame) are not its
 *     picture, so a page builds such a cache only when this is 1. */
static inline int op1_panel_rows_m(const int32_t *m, uint32_t raster_rows)
{
    const int32_t s = m[3], rows = (m[7] + 1023) >> 10;
    if (m[0] == 0 && m[1] == -s && m[2] == 0 && m[4] == 0 && m[5] == 0 && m[6] == 0 && m[8] == 1024 && m[7] == 320 * s
        && (rows == 400 || rows == 376 || rows == 320) && (uint32_t)rows <= raster_rows)
        return (int)rows;
    return (int)raster_rows;
}
static inline int op1_panel_rows_of(int32_t scale_q10, uint32_t raster_rows)   /* R246's matrix for that scale */
{
    const int32_t m[9] = { 0, -scale_q10, 0, scale_q10, 0, 0, 0, 320 * scale_q10, 1024 };
    return op1_panel_rows_m(m, raster_rows);
}
#ifndef OP1_HOST
static inline int op1_panel_rows(const void *raster)
{
    const volatile int32_t *v = (const volatile int32_t *)0x01DE5E68;
    int32_t m[9];
    for (int i = 0; i < 9; i++) m[i] = v[i];
    return op1_panel_rows_m(m, ((const uint32_t *)raster)[3]);
}
static inline int op1_raster_live(const void *raster)
{
    return ((const uint32_t *)raster)[0] == *(const volatile uint32_t *)0x01D08520;   /* the buffer handed out this tick */
}
#else
__attribute__((weak)) int32_t host_screen_scale = 0x500;    /* tests: 0x4B3 the C2 / SSD1963 panels, 0x400 the 320-row one */
static inline int op1_panel_rows(const void *raster) { return op1_panel_rows_of(host_screen_scale, ((const uint32_t *)raster)[3]); }
__attribute__((weak)) int host_raster_record;              /* tests: 1 = a record frame */
static inline int op1_raster_live(const void *raster) { (void)raster; return !host_raster_record; }
#endif
/* ---- static / dynamic screen regions (opt-in, op1r docs/75; names as op1r 59) ----
 * A screen whose picture is mostly static declares the areas that change; the core then draws the static parts once into a
 * cache and each frame restores only the declared areas from it before the screen draws its moving parts:
 *     static const op1_rect_t dyn[] = { { 60, 20, 300, 34 }, ... };      (screen units, 320 x 160, inclusive)
 *     update(scr, dt):  op1_screen_regions(scr, dyn, n);
 *                       if (op1_screen_static(scr)) { op1_screen_draw(scr, dt); labels...; op1_screen_static_done(scr); }
 *                       moving parts (only inside the declared areas: the screen's responsibility, nothing clips)
 * op1_screen_static_dirty(scr): the static part changed (labels, page switch). Screens that never call these work as
 * before. Without the region support op1_screen_static always returns 1 (the screen draws everything). Kennel: the
 * region cache (200 KB of the plugin arena) is set up at boot only when a loaded file imports op1_screen_regions. */
typedef struct { int16_t x0, y0, x1, y1; } op1_rect_t;
#define OP1_REGIONS_MAX 16
#ifndef OP1_HOST
void op1_screen_regions(void *scr, const op1_rect_t *r, int n);
int  op1_screen_static(void *scr);
void op1_screen_static_done(void *scr);
void op1_screen_static_dirty(void *scr);
#else
static inline void op1_screen_regions(void *scr, const op1_rect_t *r, int n) { (void)scr; (void)r; (void)n; }
static inline int  op1_screen_static(void *scr) { (void)scr; return 1; }
static inline void op1_screen_static_done(void *scr) { (void)scr; }
static inline void op1_screen_static_dirty(void *scr) { (void)scr; }
#endif
/* op1_gfx_heavy (any thread): nonzero while the core's frame governor draws fewer frames because recent audio blocks
 * ran near the block length (1: 15 fps, 2: 10 fps; kennel/kn_gfx.c). A screen or engine may drop optional work
 * (extra animation, a second oscilloscope trace) while it is set. Needs a core with it (2026-11). */
#ifndef OP1_HOST
int op1_gfx_heavy(void);
#else
static inline int op1_gfx_heavy(void) { return 0; }
#endif
/* Knob values as the stock screens see them (incl. LFO modulation): ReadInterface 0x01A28210(slot)
 * returns a vector of 8 floats normalised 0..1 (struct {?, float *begin, float *end}). -> Q15 0..32767 */
static inline int32_t op1_f01_to_q15(uint32_t f)          /* IEEE float in [0,1] -> 0..32767, no libgcc */
{
    if ((int32_t)f <= 0) return 0;                        /* <= +0, or negative */
    int e = (int)((f >> 23) & 0xff) - 127;
    if (e >= 0) return 32767;
    uint32_t m = (f & 0x7fffff) | 0x800000;               /* 1.m * 2^e */
    int sh = 23 - 15 - e;                                 /* value*32768 = m >> sh */
    if (sh >= 32) return 0;
    uint32_t v = m >> sh;
    return v > 32767 ? 32767 : (int32_t)v;
}
#ifndef OP1_HOST
static inline void op1_synth_knobs_live(int slot, int16_t out[4])
{
    const uint32_t *const *vec = (const uint32_t *const *)((void *(*)(int))0x01A28210)(slot);
    const uint32_t *b = vec[1], *e = vec[2];
    for (int i = 0; i < 4; i++)
        out[i] = (b && b + i < e) ? (int16_t)op1_f01_to_q15(b[i]) : op1_synth_knobs(slot)[i];
}
/* FX knobs of the shown FX screen as the stock screens see them: read_fx_param 0x01A28DA0(screen slot,
 * screen pos 0x01DF4E3C) scales the raw words with a per-FX-type range table (filled at runtime; the raw
 * words of the filter-type slot do not span 0..32767). -> Q15 0..32767 */
static inline void op1_fx_knobs_live(int16_t out[4])
{
    int pos = *(volatile int *)0x01DF4E3C;
    extern void *read_fx_param_safe(int slot, int pos);       /* dispatcher.c: sanitize + 0x01A28DA0 */
    const uint32_t *const *vec = (const uint32_t *const *)read_fx_param_safe(OP1_SCREEN_SLOT, pos);
    const uint32_t *b = vec[1], *e = vec[2];
    for (int i = 0; i < 4; i++)
        out[i] = (b && b + i < e) ? (int16_t)op1_f01_to_q15(b[i]) : op1_fx_knobs(pos == 3 ? OP1_FX_MASTER : (pos & 1))[i];
}
#endif
/* rotate node around (cx,cy) by sin/cos (Q15): matrix for row vectors [a b 0; c d 0; tx ty 1] (Q10) */
static inline void op1_node_rotate(void *node, int32_t cx, int32_t cy, int32_t s15, int32_t c15)
{
    int32_t c = c15 >> 5, s = s15 >> 5;                 /* Q15 -> Q10 */
    int32_t m[9] = { c, s, 0, -s, c, 0,
                     cx - ((cx * c - cy * s) >> 10), cy - ((cx * s + cy * c) >> 10), 1024 };
    op1_node_set_transform(node, m);
}
/* The OP-1's clock (kennel cores from 2026-11-16; an older core refuses the file: unknown import). op1_clock_tm(out)
 * fills out[0..5] with year (full, e.g. 2026), month 1..12, day 1..31, hour 0..23, minute, second from R246's real-time
 * clock (clock_get_tm 0x01A325B4: a register read, started on first use). Never set on the unit: the base date
 * 2010-01-01 00:00:00 plus the time since the clock was last set. GUI or main thread, not the audio thread; cheap, but
 * cache what you draw (once a second is plenty). Host builds read host_clock_tm (set it before the call). */
#ifndef OP1_HOST
void op1_clock_tm(int32_t out[6]);
#elif __STDC_HOSTED__
__attribute__((weak)) int32_t host_clock_tm[6] = { 2010, 1, 1, 0, 0, 0 };
static inline void op1_clock_tm(int32_t out[6]) { for (int i = 0; i < 6; i++) out[i] = host_clock_tm[i]; }
#endif
/* debug print (op1r 42's op1_dbg): on the OP-1 an empty core call (no formatting, no I/O: any thread, but not per
 * sample); an emulator hooks the core symbol _op1_dbg (build/synth.sym) and logs "dbg: text a b"; host builds print
 * that line to stderr. A freestanding OP1_HOST compile (the bfin-elf layout probes in harness/emu) has no stdio:
 * there it is a no-op. */
#ifndef OP1_HOST
void op1_dbg(const char *text, int a, int b);
#elif !__STDC_HOSTED__
static inline void op1_dbg(const char *text, int a, int b) { (void)text; (void)a; (void)b; }
#else
#include <stdio.h>
static inline void op1_dbg(const char *text, int a, int b) { fprintf(stderr, "dbg: %s %d %d\n", text, a, b); }
#endif
#endif
