/*
 * The synth Randomiser's scope (plugins/randomiser, ARCHITECTURE.md "Randomiser"): the setting "randomiser.scope",
 * one word of bits, says which parts of the sound a new random step changes. The settings page writes it (the
 * RANDOMISER page: four rows on that key with masks, randomiser's plugin.json "settings"); the Randomiser reads it at
 * each Shift + drop. OP1_RND_SCOPE_DEF is the released behaviour: everything, with new FX and LFO types.
 * (Scope bits as on branch rnd-scope, op1_rnd.h; its word layouts and LFO generators are not part of this.)
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef OP1_RND_H
#define OP1_RND_H

#define OP1_RND_SYNTH     0x01               /* the engine's knobs (the engine itself never changes) */
#define OP1_RND_ENV       0x02               /* the envelope */
#define OP1_RND_LFO       0x04               /* the LFO */
#define OP1_RND_FX        0x08               /* the FX */
#define OP1_RND_LFO_KEEP  0x10               /* with OP1_RND_LFO: keep the LFO's type (and on / off), new values only */
#define OP1_RND_FX_KEEP   0x20               /* with OP1_RND_FX: keep the FX's type (and on / off), new values only */
#define OP1_RND_PARTS     0x0F
#define OP1_RND_MASK      0x3F
#define OP1_RND_SCOPE_DEF 0x0F               /* the released behaviour */
#endif
