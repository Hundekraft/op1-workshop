/*
 * kennel feature API, an LFO type's record (2026-11-11, for the matrix LFO type): a type whose settings don't fit the 8
 * LFO words keeps up to 64 int16 in the sound's JSON, as the top-level member "lfo_rec": {"id": <id>, "p": [64 ints]},
 * and puts the record's id into its words (matrix: w[0] = id & 0xFFFF, w[1] = id >> 16). The core keeps the member
 * through parse_patch_json (kennel/kn_drum.c dp_keep_op1r, every synth and drum patch) and holds each slot's record in
 * a cache (kennel/kn_lfo_rec.c), so the audio thread never reads JSON.
 * An id is 1 .. 0x7FFFFFFF (it is saved as a JSON int); 0 means no record (a fresh pick: the type's defaults).
 * Older cores don't export these names, so an older core refuses a file that imports them (the file is skipped, the
 * OP-1 boots). Stock and older parsers drop the unknown member.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef OP1_FEATURE_LFOREC_H
#define OP1_FEATURE_LFOREC_H
#include <stdint.h>

#define OP1_LFO_REC_N 64                         /* int16 a record */

/* the record of slot `slot` (0..7) of instrument `pos` (0 synth, 1 drum) when the core holds one with this id, else 0
 * (use the type's defaults). Any thread; the pointer stays valid (the cache is static), its contents change when the
 * slot loads another sound or a record is stored. */
const int16_t *op1_lfo_record(int pos, int slot, uint32_t id);

/* KeyHandler thread (an LFO page's turn or press): write n (1..64) values as the record of the slot's live sound
 * (patch JSON "lfo_rec", missing values 0), update the cache and return the record's new id (never 0, never the id it
 * had); 0 when pos, slot or n is out of range. The caller puts the id into its words; the core then saves the words
 * with the patch setter, which marks the sound changed, so the record is saved with it. */
uint32_t op1_lfo_record_store(int pos, int slot, const int16_t *p, int n);

/* the shift layer a kennel engine (fx 0, words = the synth stage words of apply pass 0) or custom FX (fx 1, the FX stage
 * words of pass 2 / 5) registered for knob 0..3 with op1_engine_shift / op1_fx_shift: 0 none, 1 fine (words 5 / 6:
 * 1..32767; fields: 0..127), 2..127 steps. words[4] names the engine / FX (magic + order). Any thread. */
int op1_shift_steps(int fx, const int16_t *words, int knob);

#endif
