/*
 * Key filter hook (kennel cores after 3.3): a feature that must see every key event before anything else does (plugins/
 * trigguard, the trigger guard) fills op1_key_filter. The core's key_event_hook (KeyHandler::Run's CALL key_dispatch,
 * 0x019C2D3E) then calls fn first with every event, before every consumer: the menu, the core's pages, the features'
 * input filters, the synth, the drums, the sequencers and USB MIDI out. fn passes on what it keeps by calling
 * deliver(code, pressed), zero, one or more times, at once or at a later event (KeyHandler thread only). fn = 0: every
 * event goes straight on, as before.
 * marked: kennel pushed this event itself (op1_key_push, MIDI keys, the CC map, op1_stock_seq_key ...); pass it on.
 * op1_key_push puts an event into R246's key queue with interrupts off and wakes the KeyHandler (any thread but the
 * KeyHandler's own dispatch, 0 when the queue is full); it reaches fn later with marked 1. A filter can push a private
 * event (e.g. code 0x3F with its own pressed byte: 0xA5 is kennel's MIDI param key) to get a call on the KeyHandler
 * thread from the main loop; it must not pass that one on.
 * An older core has neither: a plugin that imports them refuses to load there (unknown import).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef OP1_KEYFILTER_H
#define OP1_KEYFILTER_H

typedef void (*op1_key_deliver)(int code, int pressed);
typedef struct {
    void (*volatile fn)(int code, int pressed, int marked, op1_key_deliver deliver);
} op1_key_filter_t;
extern op1_key_filter_t op1_key_filter;
int op1_key_push(int code, int down);
#endif
