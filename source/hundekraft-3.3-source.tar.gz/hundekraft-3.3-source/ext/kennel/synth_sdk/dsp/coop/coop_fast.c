/* coop-fw's rewrites of stock DSP loops (dsp/coop/NAME_fast.S, coldsoldr, GPL-3.0-or-later with the OP-1 firmware
 * permission), taken through op1r-src e6219e4 (pcppcp: this glue and the run counters): their switches (1 = the
 * rewrite, 0 = the stock loop: words in .coop, poked for an A/B) and the run counters they keep. Patch sites:
 * make_firmware.py HOOKS (the stock bytes checked) and link.ld (the stock re-entry points). In kennel the run
 * counters coop_hits[] are always on (one increment per call); the sub-path counters g_*_hit_* count only in a build
 * with the per-file CHECK macros (ARCHITECTURE.md "coop-fw stock DSP").
 * Copyright (C) 2026 coldsoldr, (C) 2026 pcppcp. GPL-3.0-or-later with the OP-1 firmware permission (NOTICE). */
#include <stdint.h>
#ifndef COOP_FAST
#define COOP_FAST 1
#endif
volatile uint32_t g_coop_fast_dsynth = COOP_FAST, g_coop_fast_cwo = COOP_FAST, g_coop_fast_punch = COOP_FAST,
                  g_coop_fast_phone = COOP_FAST, g_coop_fast_nitro = COOP_FAST, g_coop_fast_grid = COOP_FAST,
                  g_coop_fast_spring = COOP_FAST, g_coop_fast_delay = COOP_FAST, g_coop_fast_phase = COOP_FAST,
                  g_coop_fast_voltage = COOP_FAST;
volatile uint32_t g_nitro_hit_calls, g_phase_hit_calls, g_phase_hit_wrap1, g_phase_hit_wrap2, g_phone_hit_capa,
                  g_phone_hit_capb, g_phone_hit_end, g_phone_hit_rise, g_phone_hit_slow, g_phone_hit_swap,
                  g_spring_hit_calls, g_spring_hit_split, g_spring_hit_stock, g_spring_hit_wrap, g_voltage_hit_calls;
volatile uint32_t coop_hits[10];   /* runs of dsynth cwo punch phone nitro grid spring delay phase voltage */
