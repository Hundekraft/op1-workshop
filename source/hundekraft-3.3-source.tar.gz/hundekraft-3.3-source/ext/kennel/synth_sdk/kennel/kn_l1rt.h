/* L1 patches at boot through DTEST (kennel/kn_l1rt.c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_L1RT_H
#define KN_L1RT_H
#include <stdint.h>

/* one poke: len bytes at addr (inside 0xFFA00000..0xFFA0C000), R246's original bytes, and what to write, made at
 * boot from target (a symbol address the linker fills in, so the table needs no second link):
 *   KN_L1RT_CALL    P1.L = target; P1.H = target; CALL (P1); then NOPs to len (make_firmware.py L1_CALLS)
 *   KN_L1RT_PCCALL  CALL pcrel24 to target (L1_PCCALLS)
 *   KN_L1RT_IMM_LO  the 16-bit immediate of an Rx.L = lo instruction: target & 0xFFFF (L1_IMM_PATCHES, + 2)
 *   KN_L1RT_IMM_HI  .. of the Rx.H = hi instruction: target >> 16 (+ 6) */
enum { KN_L1RT_CALL = 1, KN_L1RT_PCCALL, KN_L1RT_IMM_LO, KN_L1RT_IMM_HI };
typedef struct { uint32_t addr, target; uint8_t len, kind; uint8_t orig[16]; } kn_l1rt_poke_t;
/* the bytes a poke writes (len of them); 0 if the kind or length is wrong */
int kn_l1rt_encode(const kn_l1rt_poke_t *p, uint8_t *out);

extern volatile uint32_t kn_l1rt[6];
void kn_l1rt_apply_table(const kn_l1rt_poke_t *pk, unsigned n);
int kn_l1rt_text(char *m);
/* the pokes and the L1 decimator (kn_dec.c), from the db2::open hook before the timed call (kn_boottime.c) */
void kn_l1rt_boot(void);
/* L1 code bytes through DTEST (kn_dec.c); write: 0 if a block did not read back. R246's audio block counter. */
void kn_l1rt_read(uint32_t addr, uint8_t *out, uint32_t n);
int kn_l1rt_write(uint32_t addr, const uint8_t *in, uint32_t n);
uint16_t kn_l1rt_blocks(void);
#endif
