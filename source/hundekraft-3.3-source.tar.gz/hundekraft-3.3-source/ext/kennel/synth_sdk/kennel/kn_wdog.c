/*
 * Hang detector (after op1r-src de41b0d / 149e876 / aa7aab4, xoza, and tencur's PR #54 895267b; GPL-3.0-or-later with
 * the OP-1 firmware permission, PROVENANCE.md; ARCHITECTURE.md "Hang detector and crash screen").
 *
 * The BF524 watchdog raises an NMI when neither the audio callback (sm_audio_cb, every block) nor the Gfx thread
 * (kn_gfx_frame, every frame, skipped or drawn) has reloaded it for 0x20000000 SCLK ticks (6.7 s at the 80 MHz SCLK
 * kennel's 3.1i notes give for the unit, 5.4 s at op1emu's 100 MHz; op1r says 4-5 s: the whole
 * OP-1 froze; the stock error screen cannot be drawn from there). Either kick reloads it, so a stall that leaves the
 * audio interrupt running (a slow main-loop or Gfx job: NAND, disk, update, lazy screens, the sample editor) never
 * trips it. The NMI handler (kn_wdog_nmi.S) saves where the core was and 32 stack words into a record at the top of
 * SDRAM, then resets through the watchdog. The next boot takes the record (kn_wd_boot) and the resource monitor's
 * page 4 shows "hang RETN RETS" (screens/sysmon.c).
 *
 * Not the 3.1i diagnostic watchdog (removed 2026-10-29): nothing is serviced from the main loop, no ring, no log file.
 *
 * Armed from the Gfx frame once the boot has settled (kennel/kn_boot.c kn_boot_settled: the main loop ran and the
 * crash marker is gone, 10..21 s after loading) and disk mode is off. Off for good at power-off (kn_bgs_stop, before
 * the tape write-back that runs with the audio stopped); off while disk mode starts (kn_disk_toggle) and not re-armed
 * while it lasts or while kn_disk_toggle drains first (R246 leaves disk mode through its own watchdog reset). The crash screen (kn_crash.c) sets the
 * longest count (2^32 ticks: 54 s at 80 MHz, 43 s in op1emu) so a key or, failing that, the NMI restarts. R246 and devupd reboot through the
 * watchdog (CTL 0x0AD0, CNT 1, CTL 0x0FF0), which reprograms it; a later kick only reloads that count of 1.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>
#include "kn_mem.h"
#include "kn_wdog.h"

#ifdef OP1_HOST
static uint16_t host_ctl; static uint32_t host_cnt, host_stat, host_evt2;
uint32_t kn_wd_host_rec[64];
uint8_t kn_wd_host_disk;
#define WDOG_CTL  host_ctl
#define WDOG_CNT  host_cnt
#define WDOG_STAT host_stat
#define EVT2      host_evt2
#define REC       kn_wd_host_rec
#define DISK_ACTIVE kn_wd_host_disk
#else
#define WDOG_CTL  (*(volatile uint16_t *)0xFFC00200)
#define WDOG_CNT  (*(volatile uint32_t *)0xFFC00204)
#define WDOG_STAT (*(volatile uint32_t *)0xFFC00208)
#define EVT2      (*(volatile uint32_t *)0xFFE02008)          /* NMI vector */
#define REC       ((volatile uint32_t *)KN_HANG_REC)
#define DISK_ACTIVE (*(volatile uint8_t *)0xFF906EF9)          /* disk_mode_active */
#endif

volatile uint8_t kn_wd_armed kn_hot;                          /* read by every audio block (kn_wd_kick) */
static uint8_t wd_dead, wd_frames;                            /* dead: powered off; frames since the boot settled */
static uint8_t wd_hold, wd_held_disk;                         /* off for disk mode: until disk mode was seen and has ended,
                                                               * or kn_wd_resume (the toggle refused) */
volatile uint32_t kn_hang[KN_HANG_WORDS];                     /* the last hang's record (word 0 the magic, else 0) */

void kn_wd_nmi(void);                                         /* kn_wdog_nmi.S */
extern int kn_boot_settled(void);                             /* kennel/kn_boot.c */

void kn_wd_boot(void)                                         /* early boot: a record the NMI left before its reset */
{
    if (REC[0] != KN_HANG_MAGIC) return;
    for (int i = 0; i < KN_HANG_WORDS; i++) kn_hang[i] = REC[i];
    REC[0] = 0;
}

static void arm(void)
{
    EVT2 = (uint32_t)(uintptr_t)kn_wd_nmi;
    WDOG_CTL = 0x0AD0;                                        /* disabled, expired flag cleared */
    WDOG_CNT = KN_WD_COUNT;                                   /* SCLK ticks */
    WDOG_STAT = 0;
    WDOG_CTL = 0x0002;                                        /* enabled, event NMI */
    kn_wd_armed = 1;
}

void kn_wd_frame(void)                                        /* Gfx thread, every frame (kennel/kn_gfx.c) */
{
    if (kn_wd_armed) {
        if (!DISK_ACTIVE) { WDOG_STAT = 0; return; }
        kn_wd_off();                                          /* disk mode by another way in: off */
    }
#ifdef KN_WDOG_OFF
    return;                                                   /* test build KN_WDOG=0: never armed */
#endif
    if (wd_hold) {                                            /* kn_disk_toggle drains saves and the tape (up to 6 s)
                                                               * before disk mode starts: no re-arm meanwhile */
        if (DISK_ACTIVE) wd_held_disk = 1;
        else if (wd_held_disk) wd_hold = wd_held_disk = 0;
    }
    if (wd_dead || wd_hold || DISK_ACTIVE || !kn_boot_settled()) { wd_frames = 0; return; }
    if (++wd_frames >= 120) arm();                            /* two seconds of frames after the boot settled */
}

void kn_wd_off(void) { WDOG_CTL = 0x0AD0; kn_wd_armed = 0; wd_frames = 0; }
void kn_wd_disk(void) { kn_wd_off(); wd_hold = 1; wd_held_disk = 0; }   /* disk mode starting (kn_disk_toggle) */
void kn_wd_resume(void) { wd_hold = wd_held_disk = 0; }       /* it did not start (the toggle refused) */
void kn_wd_dead(void) { wd_dead = 1; kn_wd_off(); }           /* power-off: never again this boot */

void kn_wd_crash(void)                                        /* the crash screen: the longest count, then the NMI */
{
    if (!kn_wd_armed) return;
    WDOG_CTL = 0x0AD0;
    WDOG_CNT = 0xFFFFFFFFu;
    WDOG_STAT = 0;
    WDOG_CTL = 0x0002;
    kn_wd_armed = 0;                                          /* nothing kicks it any more */
}
