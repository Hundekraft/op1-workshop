/*
 * Light preset entries (kennel/kn_preset_store.c): the pure parts, shared with the host test
 * (harness/preset_store_test.c). No firmware calls.
 *
 * kn_pl_scan: a bounded scan of one preset's JSON text for its top-level "type" and "name" strings, without building
 * a jsoncpp tree. Nested objects and arrays are skipped (a "name" inside them does not count). Returns 1 when the text
 * is one object and both strings were found, short (< KN_PL_STR) and without escapes; otherwise 0, and the caller
 * parses the full patch as R246 does.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_PL_SCAN_H
#define KN_PL_SCAN_H
#include <stdint.h>

#define KN_PL_STR 64                                 /* type and name, NUL included */
#define KN_PL_USER_KITS 256                          /* user drum kits (owner, 2026-11-13: "3.3 gets 1024+256") */
#define KN_PL_DRUM_TABLE 448                         /* drum table entries: the loader's user check is 56 << 3 (hook.S) */

static inline const char *kn_pl_ws(const char *p) { while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++; return p; }

/* past a JSON string starting at its opening quote; 0 on an unterminated one */
static inline const char *kn_pl_skip_str(const char *p)
{
    for (p++; *p; p++) {
        if (*p == '\\') { if (!*++p) return 0; }
        else if (*p == '"') return p + 1;
    }
    return 0;
}

/* past one JSON value (string, object, array, number or literal); 0 on bad text */
static inline const char *kn_pl_skip_val(const char *p)
{
    p = kn_pl_ws(p);
    if (*p == '"') return kn_pl_skip_str(p);
    if (*p == '{' || *p == '[') {
        int depth = 0;
        while (*p) {
            if (*p == '"') { p = kn_pl_skip_str(p); if (!p) return 0; continue; }
            if (*p == '{' || *p == '[') depth++;
            else if (*p == '}' || *p == ']') { if (--depth == 0) return p + 1; }
            p++;
        }
        return 0;
    }
    const char *s = p;
    while (*p && *p != ',' && *p != '}' && *p != ']' && *p != ' ' && *p != '\n' && *p != '\r' && *p != '\t') p++;
    return p > s ? p : 0;
}

static inline int kn_pl_key_is(const char *k, int n, const char *w)
{
    int i = 0;
    for (; i < n && w[i] && k[i] == w[i]; i++) ;
    return i == n && !w[i];
}

/* copy a plain string value (opening quote at p) into out; 0 if it has an escape or is too long */
static inline const char *kn_pl_take_str(const char *p, char *out)
{
    int n = 0;
    for (p++; *p && *p != '"'; p++) {
        if (*p == '\\' || n >= KN_PL_STR - 1) return 0;
        out[n++] = *p;
    }
    if (*p != '"') return 0;
    out[n] = 0;
    return p + 1;
}

static inline int kn_pl_scan(const char *text, char *type, char *name)
{
    int have = 0;
    const char *p = kn_pl_ws(text ? text : "");
    if (*p++ != '{') return 0;
    p = kn_pl_ws(p);
    if (*p == '}') return 0;
    for (;;) {
        if (*p != '"') return 0;
        const char *k = p + 1, *e = kn_pl_skip_str(p);
        if (!e) return 0;
        int kn = (int)(e - 1 - k);
        p = kn_pl_ws(e);
        if (*p++ != ':') return 0;
        p = kn_pl_ws(p);
        char *dst = kn_pl_key_is(k, kn, "type") ? type : kn_pl_key_is(k, kn, "name") ? name : 0;
        if (dst) {
            if (*p != '"' || !(p = kn_pl_take_str(p, dst))) return 0;
            have |= dst == type ? 1 : 2;
        } else if (!(p = kn_pl_skip_val(p))) return 0;
        p = kn_pl_ws(p);
        if (*p == ',') { p = kn_pl_ws(p + 1); continue; }
        if (*p == '}') return have == 3;
        return 0;
    }
}

/* drum save gate: room for one more user kit (total counts factory kits too) */
static inline int kn_pl_drum_gate(int32_t total, int32_t factory)
{
    return total - factory < KN_PL_USER_KITS && total < KN_PL_DRUM_TABLE - 1;
}

/* rows the drum loader may still take: the table less the factory kits and the spare entry */
static inline int kn_pl_drum_room(int32_t factory)
{
    int room = KN_PL_DRUM_TABLE - 1 - factory;
    if (room > KN_PL_USER_KITS) room = KN_PL_USER_KITS;
    return room < 0 ? 0 : room;
}

/* Fill on choose copies the light entry's folder (the sampler's and kit's sample path) into the spare entry with R246's
 * std::string::assign(this, str, pos, n) 0x019FF0BC. It takes four arguments; the fourth, the count, comes from the
 * stack ([SP + 12] at the call), and R246's own callers pass npos (0x0190E4E0). Called with three (rc7 .. rc7b), the
 * count was whatever pl_fill had left there (0, Reader::parse's last argument), so every filled entry got an empty
 * folder and a user sampler stopped R246 at "SampleBuffer.cpp:225 /yaffs2//user/audio/preset_synth//<name>.raw not
 * found" (the crash screen; after a live USB add it was the first user sampler, 2026-11-14). */
#define KN_PL_NPOS 0xFFFFFFFFu
typedef void *(*kn_pl_assign_fn)(void *dst, const void *src, uint32_t pos, uint32_t n);
static inline void kn_pl_folder_copy(kn_pl_assign_fn assign, void *dst, const void *src)
{
    assign(dst, src, 0, KN_PL_NPOS);
}
#endif
