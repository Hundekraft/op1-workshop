/* Hang detector (kennel/kn_wdog.c, kn_wdog_nmi.S). Record words: 0 magic "HANG", 1 RETN (where the core was), 2 RETI,
 * 3 RETX, 4 RETS, 5 IPEND, 6 ILAT, 7 SEQSTAT, 8 SP, 9 FP, 10 USP, 11 0, 12..43 the 32 words at SP (if SP lies in SDRAM
 * below 0x03FFFC00 or in L1 scratch).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_WDOG_H
#define KN_WDOG_H
#include <stdint.h>

#define KN_HANG_MAGIC  0x48414E47u                /* "HANG" */
#define KN_HANG_WORDS  44
#define KN_WD_COUNT    0x20000000u                /* SCLK ticks: 6.7 s at 80 MHz (the unit, kennel's 3.1i notes), 5.4 s
                                                   * at op1emu's 100 MHz */

extern volatile uint8_t kn_wd_armed;
extern volatile uint32_t kn_hang[KN_HANG_WORDS];
void kn_wd_boot(void), kn_wd_frame(void), kn_wd_off(void), kn_wd_disk(void), kn_wd_resume(void), kn_wd_dead(void),
     kn_wd_crash(void);

#ifndef OP1_HOST                                  /* the audio block's kick: a byte load, a branch, one MMR store */
static inline void kn_wd_kick(void) { if (kn_wd_armed) *(volatile uint32_t *)0xFFC00208 = 0; }
#else
static inline void kn_wd_kick(void) {}
#endif
#endif
