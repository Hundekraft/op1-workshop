/*
 * The instrument bus decimator in L1 (kennel/kn_dec_l1.S), installed at boot from kn_l1rt_boot (kennel/kn_l1rt.c),
 * in the main thread before audio::init starts the audio callback.
 *
 * 1. The coefficient pairs: hp[k] = (h[k - 1] << 16) | h[k], k = 0..32, from R246's half-band table h (0x0106A6F0,
 *    32 int16, filled by a boot constructor) into 132 bytes of L1 data B at 0xFF906B7C (an 852-byte table a boot
 *    constructor copies to SDRAM; R246 does not read it afterwards). Refused if h is all zero (not filled yet).
 * 2. KN_L1_RUNTIME builds: R246's 176 bytes at 0xFFA005D4 are read through DTEST and must hash to R246's routine
 *    (FNV-1a 0xBE408D72: a hash, so no TE bytes here); then kennel's routine is written over them and read back. LDR
 *    builds: make_firmware.py already placed it with a plain LDR block, so there is nothing to compare or write.
 * 3. Stage check (after op1r-src dsp/stagecheck.h, xoza): 64 synthetic blocks (full-scale noise, quiet, extremes,
 *    silence; random delay lines, gain and step) run through the C model of R246's routine (dec_model, after op1r-src
 *    dsp/dec.c) and through the routine at 0xFFA005D4 from the same state; every byte they write (the 64 outputs, both
 *    delay lines, gain) must match. R246's buffers are restored afterwards. A difference in a runtime build writes
 *    R246's original bytes back (kept from step 2); in an LDR build it can only be reported.
 * Any refusal leaves R246's own decimator in place and is told once after boot (kn_dec_text, kn_core.c).
 *
 * kn_dec[8]: [0] state (0 not run, 1 installed, 2 R246's routine differs, 3 audio already running, 4 write failed and
 * restored, 5 h not filled, 6 stage check failed (runtime: restored), 7 stage check failed (LDR: still in place)),
 * [1] the hash read, [2] stage-check blocks, [3] differing blocks, [4] first differing byte (region << 16 | offset),
 * [5] 1 = runtime, [6] hash of h used for hp, [7] R246's block counter when it ran.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>
#include "kn_l1rt.h"
#include "kn_dec.h"

volatile uint32_t kn_dec[8];
uint32_t kn_dec_expect = KN_DEC_R246_FNV;               /* (the host test sets its own) */

#ifdef OP1_HOST                                       /* harness/dec_test.c: memory stands in for R246's */
int16_t kn_dec_host_x[128], kn_dec_host_y[64], kn_dec_host_ab[64], kn_dec_host_g[2], kn_dec_host_h[32];
uint32_t kn_dec_host_hp[33];
void (*kn_dec_host_l1)(void);                         /* what "calling 0xFFA005D4" runs */
#define DX  kn_dec_host_x
#define DY  kn_dec_host_y
#define DA  kn_dec_host_ab
#define DB  (kn_dec_host_ab + 32)
#define DG  kn_dec_host_g
#define DH  kn_dec_host_h
#define HP  kn_dec_host_hp
#define CALL_L1() kn_dec_host_l1()
#else
#define DX  ((volatile int16_t *)0xFF800BB4)
#define DY  ((volatile int16_t *)0xFF801E50)
#define DA  ((volatile int16_t *)0xFF80123C)
#define DB  ((volatile int16_t *)0xFF80127C)
#define DG  ((volatile int16_t *)0xFF80107C)
#define DH  ((volatile int16_t *)0x0106A6F0)
#define HP  ((volatile uint32_t *)KN_DEC_HP)
#define CALL_L1() ((void (*)(void))KN_DEC_ADDR)()
#endif

extern const uint8_t kn_dec_l1_start[], kn_dec_l1_end[];   /* kennel/kn_dec_l1.S */

static inline int16_t sat16(int32_t v) { return (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v); }
static inline int32_t sat32(int64_t v) { return v > 0x7FFFFFFFLL ? 0x7FFFFFFF : v < -0x80000000LL ? (int32_t)0x80000000 : (int32_t)v; }
static inline int16_t mulh16(int16_t a, int16_t b)   /* R.L = a * b: 2ab, rounded to 16 bits (ties to even), saturated */
{
    int32_t p = (a == -32768 && b == -32768) ? 0x7FFFFFFF : 2 * (int32_t)a * b;
    int32_t q = p >> 16, r = p & 0xFFFF;
    if (r > 0x8000 || (r == 0x8000 && (q & 1))) q++;
    return sat16(q);
}
/* R246's core_decimate_2to1 as C (after op1r-src dsp/dec.c dec_model, xoza): per output i,
 * B[i & 31] = x[2i + 1]; A[i & 31] = x[2i]; acc = B[(i + 16) & 31] << 15; acc = sat32(acc + 2 A[(i + 1 + n) & 31] h[n]),
 * n = 0..31; y[i] = (acc.H g) rounded; g = sat16(g + s). Every write of the routine. */
void kn_dec_model(void)
{
    int16_t g = DG[0];
    const int16_t s = DG[1];
    for (int i = 0; i < 64; i++) {
        DB[i & 31] = DX[2 * i + 1];
        DA[i & 31] = DX[2 * i];
        int32_t acc = (int32_t)DB[(i + 16) & 31] * 32768;           /* << 15 */
        for (int n = 0; n < 32; n++) {
            const int16_t a = DA[(i + 1 + n) & 31], h = DH[n];
            acc = sat32((int64_t)acc + ((a == -32768 && h == -32768) ? 0x7FFFFFFF : 2 * (int32_t)a * h));
        }
        DY[i] = mulh16((int16_t)(acc >> 16), g);
        g = sat16(g + s);
    }
    DG[0] = g;
}

static uint32_t fnv(const uint8_t *p, uint32_t n)
{
    uint32_t h = 0x811C9DC5u;
    for (uint32_t i = 0; i < n; i++) h = (h ^ p[i]) * 0x01000193u;
    return h;
}
static int hp_build(void)                             /* 0: h not filled */
{
    uint32_t any = 0, h = 0x811C9DC5u;
    int16_t prev = 0;
    for (int k = 0; k < 32; k++) {
        const int16_t v = DH[k];
        any |= (uint16_t)v;
        h = (h ^ (uint16_t)v) * 0x01000193u;
        HP[k] = (uint32_t)(uint16_t)prev << 16 | (uint16_t)v;
        prev = v;
    }
    HP[32] = (uint32_t)(uint16_t)prev << 16;
    kn_dec[6] = h;
    return any != 0;
}

/* the stage check: model vs the routine at 0xFFA005D4 from the same state; R246's buffers restored */
#define NX 128
#define NY 64
#define NAB 64
static int16_t keep_x[NX], keep_y[NY], keep_ab[NAB], keep_g[2];
static int16_t in_x[NX], in_ab[NAB], in_g[2], m_y[NY], m_ab[NAB], m_g[2];
static void save(int16_t *x, int16_t *y, int16_t *ab, int16_t *g)
{
    for (int i = 0; i < NX; i++) x[i] = DX[i];
    if (y) for (int i = 0; i < NY; i++) y[i] = DY[i];
    for (int i = 0; i < 32; i++) { ab[i] = DA[i]; ab[32 + i] = DB[i]; }
    g[0] = DG[0]; g[1] = DG[1];
}
static void load(const int16_t *x, const int16_t *y, const int16_t *ab, const int16_t *g)
{
    for (int i = 0; i < NX; i++) DX[i] = x[i];
    if (y) for (int i = 0; i < NY; i++) DY[i] = y[i];
    for (int i = 0; i < 32; i++) { DA[i] = ab[i]; DB[i] = ab[32 + i]; }
    DG[0] = g[0]; DG[1] = g[1];
}
static uint32_t rng = 0x2545F491u;
static int16_t val(int mode)
{
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    switch (mode) {
    case 0: return (int16_t)rng;                                  /* full-scale noise */
    case 1: return (int16_t)((int32_t)(int16_t)rng >> 8);         /* quiet */
    case 2: return (rng >> 31) ? 32767 : -32768;                  /* extremes */
    default: return 0;                                            /* silence */
    }
}
static int stage_check(void)
{
    save(keep_x, keep_y, keep_ab, keep_g);
    uint32_t bad = 0, first = 0;
    for (int b = 0; b < 64; b++) {
        const int mode = b & 3;
        for (int i = 0; i < NX; i++) in_x[i] = val(mode);
        for (int i = 0; i < NAB; i++) in_ab[i] = val(b & 4 ? 2 : mode);
        in_g[0] = (b & 8) ? 0x7FFF : val(0); in_g[1] = (b & 16) ? val(0) : (int16_t)(val(1) >> 2);
        load(in_x, 0, in_ab, in_g);
        kn_dec_model();
        for (int i = 0; i < NY; i++) m_y[i] = DY[i];
        for (int i = 0; i < 32; i++) { m_ab[i] = DA[i]; m_ab[32 + i] = DB[i]; }
        m_g[0] = DG[0];
        load(in_x, 0, in_ab, in_g);
        CALL_L1();
        uint32_t d = 0;
        for (int i = 0; i < NY && !d; i++) if (DY[i] != m_y[i]) d = 0x10000u | (uint32_t)i;
        for (int i = 0; i < 32 && !d; i++) if (DA[i] != m_ab[i] || DB[i] != m_ab[32 + i]) d = 0x20000u | (uint32_t)i;
        if (!d && DG[0] != m_g[0]) d = 0x30000u;
        if (d) { if (!bad) first = d; bad++; }
    }
    load(keep_x, keep_y, keep_ab, keep_g);
    kn_dec[2] = 64; kn_dec[3] = bad; kn_dec[4] = first;
    return bad == 0;
}

void kn_dec_install(int runtime)
{
    static uint8_t orig[KN_DEC_ROOM];
    const uint32_t n = (uint32_t)(kn_dec_l1_end - kn_dec_l1_start);
    kn_dec[5] = (uint32_t)runtime;
    kn_dec[7] = kn_l1rt_blocks();
    if (kn_dec[7]) { kn_dec[0] = 3; return; }
    if (runtime) {
        kn_l1rt_read(KN_DEC_ADDR, orig, KN_DEC_ROOM);
        kn_dec[1] = fnv(orig, KN_DEC_ROOM);
        if (kn_dec[1] != kn_dec_expect || n > KN_DEC_ROOM) { kn_dec[0] = 2; return; }
        if (!hp_build()) { kn_dec[0] = 5; return; }
        if (!kn_l1rt_write(KN_DEC_ADDR, kn_dec_l1_start, n)) {
            kn_l1rt_write(KN_DEC_ADDR, orig, KN_DEC_ROOM);
            kn_dec[0] = 4; return;
        }
        if (!stage_check()) { kn_l1rt_write(KN_DEC_ADDR, orig, KN_DEC_ROOM); kn_dec[0] = 6; return; }
    } else {
        if (!hp_build()) { kn_dec[0] = 5; return; }   /* (LDR: the routine is in place; reported) */
        if (!stage_check()) { kn_dec[0] = 7; return; }
    }
    kn_dec[0] = 1;
}

/* the boot toast after a refusal (kn_core.c); 0 when installed or not run. m holds 48 bytes. */
int kn_dec_text(char *m)
{
    const char *s;
    switch (kn_dec[0]) {
    case 2: s = "Decimator kept: firmware differs"; break;
    case 3: s = "Decimator kept: audio was running"; break;
    case 4: s = "Decimator kept: L1 write failed"; break;
    case 5: s = "Decimator kept: filter table not ready"; break;
    case 6: s = "Decimator kept: self-test failed"; break;
    case 7: s = "Decimator self-test failed: reflash"; break;
    default: return 0;
    }
    char *o = m;
    while (*s) *o++ = *s++;
    *o = 0;
    return 1;
}
