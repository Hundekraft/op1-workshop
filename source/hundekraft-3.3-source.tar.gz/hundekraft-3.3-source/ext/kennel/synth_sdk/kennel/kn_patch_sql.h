/* Patch saves that fit (kn_patch_sql.c). Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE). */
#ifndef KN_PATCH_SQL_H
#define KN_PATCH_SQL_H
#include <stdint.h>
/* our statement buffer: the largest known patch is a Gin kit after a reboot, 5,040 bytes (gin_fw_snapshot.c puts its
 * upper bound near 6,100 with every ' doubled); 8 KB as Gin's own working save (SQL_CAP) */
#define KN_PATCH_SQL_CAP 8192u
/* R246's snprintf(buf, cap, "UPDATE ..._slots SET patch='%s' WHERE id=%i", patch, id) at the seven patch-job sites
 * (make_firmware.py HOOKS hook_psql*): same arguments, same place on the stack */
int kn_patch_sql(char *buf, unsigned cap, const char *fmt, const char *patch, int id);
extern volatile uint32_t kn_patch_sql_big, kn_patch_sql_refused;
#endif
