/* R246's heap free list, walked safely: the monitor's RAM sample (screens/sysmon.c), heap 0's free bytes at boot
 * (kennel/kn_boot.c kn_heap0_free) and the test build's heap 0 counters (kennel/kn_diag.c h0_count) all read it under
 * the scheduler lock. Heap descriptor (HEAP_LOOKUP 0x01A9F2E2): base, size, ?, bump; the free list's first node at
 * +0x18; a node is {size, heap, next}. Every node is checked before it is read (inside this heap, 4-byte aligned, 8192
 * nodes at most): a damaged list ends the walk instead of faulting with the scheduler locked, where the exception can't
 * reach the error screen (a thread draws it) and the OP-1 freezes with frozen audio. After op1r-src 638be67 (xoza).
 * KN_HW_RD(a) reads the 32-bit word at address a; the host test maps it onto its own array.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_HEAPWALK_H
#define KN_HEAPWALK_H
#include <stdint.h>
#ifndef KN_HW_RD
#define KN_HW_RD(a) (*(const volatile uint32_t *)(uintptr_t)(a))
#endif

/* h: the descriptor's first 7 words. Returns the free list's bytes; *walk = nodes read (may be 0) */
static inline uint32_t kn_heap_free_list(const uint32_t *h, uint32_t *walk)
{
    const uint32_t lo = h[0], hi = h[0] + h[1];
    uint32_t b = h[0x18 / 4], fl = 0, n = 0;
    for (; b && n < 8192; n++) {
        if (b < lo || hi < 12 || b > hi - 12 || (b & 3)) break;   /* a bad node: the walk ends here */
        fl += KN_HW_RD(b);
        b = KN_HW_RD(b + 8);
    }
    if (walk) *walk = n;
    return fl;
}
#endif
