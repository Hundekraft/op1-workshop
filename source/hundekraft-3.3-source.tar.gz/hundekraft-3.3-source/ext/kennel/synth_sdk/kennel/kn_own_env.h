/* Own-envelope voices (op1_plugin.h op1_engine_env_t): the envelope block for one R246 voice_state, without the checks
 * of which voice it is (dispatcher.c kn_engine_adsr does those). Shared with harness/own_env_test.c.
 * R246's adsr_block (0x01912128): voice_state o = { state, age, level 1.31, pitch, velocity, key value (+0x14) }, the
 * 128-sample envelope out, return 1 when the voice is done (the caller clears its active flag). States 7 (start) and
 * 1..5 give a flat envelope at what the stock gives at full sustain for velocity 127: sat16(0x7F00 x key x 2, rounded)
 * / 2; the level is held at full (voice shedding reads it), the age counted as the stock does, and the voice ends (state
 * 0, return 1) when the engine's finished() says so. -1 for idle (0), steal (6) and kill (8): the stock envelope runs.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_OWN_ENV_H
#define KN_OWN_ENV_H
#include <stdint.h>
static inline int kn_own_env_block(int32_t *o, int16_t *env, int (*fin)(void *), void *self)
{
    int32_t st = o[0];
    if (st == 7 || st == 1 || st == 2) { st = 3; o[0] = 3; }                          /* sounding: "sustain" */
    if (st < 3 || st > 5) return -1;
    int32_t g = 0x7F00 * (int32_t)(int16_t)o[5] * 2;
    g = (g + 0x8000) >> 16;
    const int32_t lv = (g > 32767 ? 32767 : g < -32768 ? -32768 : g) >> 1;
    uint32_t *w = (uint32_t *)env;
    const uint32_t pair = ((uint32_t)lv & 0xFFFFu) * 0x10001u;
    for (int i = 0; i < 64; i++) w[i] = pair;
    o[2] = 0x40000000;
    o[1]++;
    if (fin(self)) { o[0] = 0; return 1; }
    return 0;
}
#endif
