/*
 * MIDI and synth services for features (op1_feature_midi.h, docs/feature-hooks.md "MIDI and synth services"):
 *   CCs taken        dispatcher.c midi_cc_hook skips its CC -> key / encoder mapping for them
 *   raw MIDI in      devupd/du_fw.c du_rx_poll hands every USB-MIDI packet of the RX ring to kn_midi_raw_packet
 *                    (before the stock parser; the RX hook at 0x019E3CC8 is the dev-update hook, which OP1-Emulator's
 *                    builder always installs, make_firmware only with --dev)
 *   note source      VoiceCtl key_down / key_up entry stubs (hook.S) pass their caller to kn_note_source_set
 *   parameters       op1_param_set queues; private key code KN_PARAM_KEY in the KeyHandler queue applies them
 *                    (dispatcher.c key_event_hook -> kn_param_apply), as the synth controller's on_knob does
 *   stock seq keys   op1_stock_seq_key pushes key events into the KeyHandler queue
 *   SEQ + TAPE view  kn_tapeview_key / _push / _knob (dispatcher.c), screen object in the tape screen's slot
 *   posted real time op1_midi_rx_post queues F8 / FA / FC; du_rx_poll writes them into R246's receive ring before the
 *                    parser (line clock). The ring push is ported from Pulse Sync (ESC_CODE), with the author's consent.
 * The parameter, key-queue and view parts follow op1r-src 5c90efb (op1r 35, midi/mx.c and seqdev/ms_fw.c, GPL,
 * pcppcp), PROVENANCE.md.
 * Copyright (C) 2026 Hundekraft, pcppcp; the receive-ring push (C) 2026 Volker Junginger (ESC_CODE).
 * GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_synth.h"
#include "../kn_mem.h"                 /* kn_audio_text */
#include "../op1_feature_midi.h"
#include "../op1_feature_seq.h"                       /* OP1_SEQ_MIDI_CALLER */
#include "../op1_keyfilter.h"                         /* op1_key_filter, op1_key_push */

int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);

#ifdef OP1_HOST
/* host: R246 state and calls as plain data (kennel harness/midi_core_test.c) */
extern int host_kq[256], host_kq_n;                     /* KeyHandler queue: code | down << 8 */
extern int host_mode, host_screen, host_synth_slot, host_midi_ch;
extern uint8_t host_shift;
extern int16_t host_eng_word[8][4], host_env_word[8][4], host_fx_word[8][4], host_lfo_word[8][4];
extern int16_t host_eng_range[32][4][4], host_env_range[4][3], host_fx_range[16][4][3], host_lfo_range[16][4][3];
extern int host_engine[8], host_fx_type[8], host_lfo_type[8], host_fx_on[8], host_lfo_on[8], host_patch_set[4];
extern void *host_screen_table[0x44];
extern void host_key_dispatch(int code, int pressed);
static uint32_t irq_off(void) { return 0; }
static void irq_on(uint32_t m) { (void)m; }
static int kq_push(int code, int down) { host_kq[host_kq_n++ & 255] = code | down << 8; return 1; }
#define CUR_MODE        host_mode
#define CUR_SCREEN      host_screen
#define SHIFT_HELD      host_shift
#define MIDI_CH         host_midi_ch
#define SLOT            (host_synth_slot & 7)
#define ENG_WORDS(s)    host_eng_word[s]
#define ENV_WORDS(s)    host_env_word[s]
#define FX_WORDS(s)     host_fx_word[s]
#define LFO_WORDS(s)    host_lfo_word[s]
#define ENG_RANGE(e, k) host_eng_range[e][k]
#define ENV_RANGE(k)    host_env_range[k]
#define FX_RANGE(t, k)  host_fx_range[t][k]
#define LFO_RANGE(t, k) host_lfo_range[t][k]
#define ENGINE(s)       host_engine[s]
#define FX_TYPE(s)      host_fx_type[s]
#define LFO_TYPE(s)     host_lfo_type[s]
#define FX_ON(s)        host_fx_on[s]
#define LFO_ON(s)       host_lfo_on[s]
#define SET(g, s, w)    (host_patch_set[g]++)
#define SCREEN_TABLE    host_screen_table
#define KEY_DISPATCH    host_key_dispatch
extern uint32_t host_rx_ring[1024], host_rx_wr, host_rx_rd;
#define RX_RING         host_rx_ring
#define RX_WR           host_rx_wr
#define RX_RD           host_rx_rd
static void rx_sync(void) { }
#else
static uint32_t irq_off(void) { uint32_t m; __asm__ volatile ("cli %0;" : "=d"(m)); return m; }
static void irq_on(uint32_t m) { __asm__ volatile ("sti %0;" : : "d"(m)); }
/* KeyHandler queue (s_key_queue, 256 x u16 code | pressed << 8; read 0x01DD5244, write 0x01DD5248, 0x01DD524D set
 * while it is being reset); 0x019C2F04 posts the KeyHandler semaphore, as the key-scan ISR does */
/* Every event pushed here is marked by its queue slot (kq_mark: the event | 0x10000), so a key filter
 * (op1_key_filter, op1_keyfilter.h: the trigger guard) lets it through untouched: kn_kq_marked, from key_event_hook
 * while KeyHandler::Run still has the event at the read index (it advances after the dispatch). The key-scan ISR's
 * pushes leave the slot's mark as the last reader cleared it. */
static volatile uint32_t kq_mark[256];
static int kq_push(int code, int down)
{
    volatile uint32_t *rd = (volatile uint32_t *)0x01DD5244, *wr = (volatile uint32_t *)0x01DD5248;
    uint32_t m = irq_off(), w = *wr, n = (w + 1) & 0xFF;
    int ok = n != *rd && !*(volatile uint8_t *)0x01DD524D;
    if (ok) {
        uint16_t ev = (uint16_t)(code | down << 8);
        ((volatile uint16_t *)0x01DD5044)[w] = ev;
        kq_mark[w] = 0x10000u | ev;
        *wr = n;
    }
    irq_on(m);
    if (ok) ((void (*)(void))0x019C2F04)();
    return ok;
}
int kn_kq_marked(int code, int down)                       /* key_event_hook (KeyHandler): 1 = kennel pushed it */
{
    uint32_t r = *(volatile uint32_t *)0x01DD5244 & 0xFF, mk = kq_mark[r];
    kq_mark[r] = 0;
    return mk == (0x10000u | (uint16_t)(code | down << 8));
}
int kn_kq_push(int code, int down) { return kq_push(code, down); }   /* kennel/kn_mx.c, kn_ccmap.c, op1_key_push */
op1_key_filter_t op1_key_filter;                           /* op1_keyfilter.h: first in key_event_hook (dispatcher.c) */
int op1_key_push(int code, int down) { return kq_push(code, down); }
#define CUR_MODE        (*(volatile int *)0xFF907D58)
#define CUR_SCREEN      (*(volatile int *)0x018B65C8)
#define SHIFT_HELD      (*(volatile uint8_t *)0x01DD7F78)
#define MIDI_CH         (*(volatile int *)0x01AADB20 & 15)      /* the OP-1's MIDI channel */
#define SLOT            (*(volatile int *)0xFF8016D4 & 7)
#define ENG_WORDS(s)    ((int16_t *)(0xFF8013C4 + (s) * 16))
#define ENV_WORDS(s)    ((int16_t *)(0x01B60EF0 + (s) * 16))
#define FX_WORDS(s)     ((int16_t *)(0xFF801444 + (s) * 16))
#define LFO_WORDS(s)    ((int16_t *)(0xFF8014C4 + (s) * 16))
#define ENG_RANGE(e, k) ((const int16_t *)(0x01DE5890 + (e) * 0x40 + (k) * 8))   /* {min, max, scale, mode} */
#define ENV_RANGE(k)    ((const int16_t *)(0x01DE5710 + (k) * 6))                /* {min, max, scale} */
#define FX_RANGE(t, k)  ((const int16_t *)(0x01DE5C50 + (t) * 0x30 + (k) * 6))
#define LFO_RANGE(t, k) ((const int16_t *)(0x01DE5740 + (t) * 0x30 + (k) * 6))
#define ENGINE(s)       (((volatile int *)0xFF8016E4)[s])
#define FX_TYPE(s)      (((volatile int *)0xFF801734)[s])
#define LFO_TYPE(s)     (((volatile int *)0xFF801384)[s])
#define FX_ON(s)        (((int (*)(int))0x0196727C)(s))
#define LFO_ON(s)       (((int (*)(int))0x0196726C)(s))
#define PATCH(s)        ((void *)(0x01DDD7E8 + (s) * 0x38))
static void (*const setters[4])(void *, int16_t *) = {
    (void (*)(void *, int16_t *))0x01A00D14,               /* patch::set_knobs */
    (void (*)(void *, int16_t *))0x01A00C98,               /* envelope */
    (void (*)(void *, int16_t *))0x019FF664,               /* set_fx */
    (void (*)(void *, int16_t *))0x019FF734 };             /* set_lfo_params */
#define SET(g, s, w)    setters[g](PATCH(s), (w))
#define SCREEN_TABLE    ((void **)0x01DF4E54)
#define KEY_DISPATCH    ((void (*)(int, int))0x019B6C74)
#define SCREEN_CTOR     ((void *(*)(void *, int, const char *))0x01A3BAB0)
#define ITER_SCREEN_VT  ((const uint32_t *)0x019103FC)
#define SVG_LOAD        ((void *(*)(void *))0x01A503D8)
/* USB-MIDI receive ring (docs/firmware/usb.md): 1024 packets, free-running write / read counters (& 0x3FF). The stock
 * writer is usb_app_event_handler event 2 (EP4 OUT, normally in the IVG7 pass); the parser 0x019E31A4 reads it on
 * the sequencer thread and switches on the CIN nibble only (the cable nibble is ignored). */
#define RX_RING         ((volatile uint32_t *)0x01AB0510)
#define RX_WR           (*(volatile uint32_t *)0x01AB1510)
#define RX_RD           (*(volatile uint32_t *)0x01AB1514)
static void rx_sync(void) { __asm__ volatile ("ssync;" : : : "memory"); }
#endif

/* ---- raw MIDI in ---- */
static const op1_feature_t *raw_features(int i) { return i < kn_feature_count() ? kn_feature_at(i) : 0; }
void kn_midi_raw(const uint8_t *msg, int len)
{
    const op1_feature_t *f;
    for (int i = 0; (f = raw_features(i)); i++) if (f->midi_raw) f->midi_raw(msg, len);
}
/* ---- posted real-time messages (op1_midi_rx_post, line clock) ----
 * A feature queues a real-time byte (any thread, cli-guarded); du_rx_poll drains the queue into R246's receive ring
 * right before it walks the ring and runs the parser, on the sequencer thread, so the stock parser handles it as if
 * it came over USB (F8: 4 pending ticks and the tempo estimate in sync modes 2 / 4; FA / FC: start / stop). The push
 * is Pulse Sync's (ESC_CODE, see plugins/lineclock): interrupts off across the room check, the slot, and the write
 * counter, with SSYNC; one slot always stays empty; the read counter is never touched. Posted packets carry cable 15
 * (KN_RX_POSTED_CABLE), which the parser ignores and kn_midi_raw_packet skips, so features' midi_raw sees USB MIDI only. */
#define KN_RX_POSTED 0xF0u                                 /* cable 15 in byte 0's high nibble */
#define POST_N 16
static volatile uint8_t post_q[POST_N];
static volatile uint32_t post_w, post_r, post_drop, usb_clocks;
int op1_midi_rx_post(int status)
{
    if (status < 0xF8 || status > 0xFF) return -1;
    uint32_t m = irq_off();
    int ok = post_w - post_r < POST_N;
    if (ok) { post_q[post_w % POST_N] = (uint8_t)status; post_w++; } else post_drop++;
    irq_on(m);
    return ok ? 0 : -1;
}
kn_audio_text uint32_t op1_midi_usb_clocks(void) { return usb_clocks; }
void kn_midi_rx_drain(void)                                /* du_rx_poll, before its walk and the parser */
{
    /* R246's F8 handler (parser 0x019E31A4) times each clock with tempo_from_clock_interval(0x018B6068, 0x018B606C):
     * the time of the last USB event (usb_app_event_handler 0x019E1124 copies the USB interrupt's stamp), and the
     * current time only when both words are 0. A posted clock has no USB event, so after any USB activity since boot
     * it got a stale stamp: the clock ring kept resetting, no tempo, no EXT, ticks piling up (2026-11-08, a user's
     * Pamela clock on line in; run/lineclock-lock-2026-11-08 in the full project). With posted bytes to drain, both words
     * are cleared so the parser takes the current time. Line clock stands back while a USB clock runs. */
#ifndef OP1_HOST
    if (post_r != post_w) {
        uint32_t m = irq_off();
        *(volatile uint32_t *)0x018B6068 = 0; *(volatile uint32_t *)0x018B606C = 0;
        irq_on(m);
    }
#endif
    while (post_r != post_w) {
        uint32_t word = KN_RX_POSTED | 0x0Fu | (uint32_t)post_q[post_r % POST_N] << 8;
        uint32_t m = irq_off(), wr = RX_WR, rd = RX_RD;
        int ok = wr - rd < 1023u;
        if (ok) { RX_RING[wr & 1023u] = word; rx_sync(); RX_WR = wr + 1u; rx_sync(); }
        irq_on(m);
        if (!ok) { post_drop++; break; }                    /* full: try again on the next poll */
        post_r++;
    }
}

/* one USB-MIDI packet (cable / CIN, then 3 bytes): channel messages and real time, not SysEx */
void kn_midi_raw_packet(const volatile uint8_t *pk)
{
    if ((pk[0] & 0xF0) == KN_RX_POSTED) return;           /* posted by a feature (op1_midi_rx_post), not USB */
    if ((pk[0] & 15) == 0xF && pk[1] == 0xF8) usb_clocks++;
    int cin = pk[0] & 15, len;
    switch (cin) {
    case 0x8: case 0x9: case 0xA: case 0xB: case 0xE: len = 3; break;
    case 0xC: case 0xD: len = 2; break;
    case 0xF: len = pk[1] >= 0xF8 ? 1 : 0; break;             /* single byte: real time only */
    default: len = 0;
    }
    if (!len || !(pk[1] & 0x80)) return;
    uint8_t m[3] = { pk[1], (uint8_t)(pk[2] & 127), (uint8_t)(pk[3] & 127) };
    kn_midi_raw(m, len);
}

static volatile uint32_t cc_taken[4];
void op1_midi_take_cc(int cc, int take)
{
    if (cc < 0 || cc > 127) return;
    uint32_t m = irq_off();
    if (take) cc_taken[cc >> 5] |= 1u << (cc & 31); else cc_taken[cc >> 5] &= ~(1u << (cc & 31));
    irq_on(m);
}
int kn_cc_taken(int cc) { return cc >= 0 && cc < 128 && (cc_taken[cc >> 5] >> (cc & 31) & 1); }

/* ---- note source ---- */
static volatile int note_src;
volatile int kn_src_force;                                 /* op1_seq_note_on: the next note is a player's */
int kn_note_source_of(uint32_t ret)                        /* VoiceCtl key_down / key_up's caller -> OP1_SRC_* */
{
    if ((ret >= 0x019AC0B0 && ret < 0x019AC2F2) || (ret >= 0x019AC2F8 && ret < 0x019AC3C6)) return OP1_SRC_KEYS;
    if (OP1_SEQ_MIDI_CALLER(ret)) return OP1_SRC_MIDI | MIDI_CH << 8;   /* VoiceCtl note on / off (MIDI) */
    if (ret >= 0x01E00000 && ret < 0xFF000000) return OP1_SRC_FEATURE;               /* kennel code and plugin files */
    return OP1_SRC_PLAYER;
}
void kn_note_source_set(uint32_t ret)
{
    int f = kn_src_force;
    int source=kn_note_source_of(ret);
    /* An interrupted native replay must not relabel stock USB MIDI/keyboard
     * or stock-player input. Only native callers request an explicit source. */
    note_src = f && source==OP1_SRC_FEATURE ? f : source;
}
int op1_note_source(void) { return note_src; }

/* ---- synth parameters (op1r 35 midi/mx.c) ---- */
#define KN_PARAM_KEY 0x3F                                  /* private key event: apply pending parameters */
#define KN_PARAM_DOWN 0xA5                                 /* ... marked by its state byte: R246 pushes key 0x3F
                                                            * itself (state 1) for the USB eject (0x019EFE6C) and its
                                                            * COM controller, which leaves disk mode on it */
static volatile uint8_t pval[16];
static volatile uint16_t pend;
static volatile uint8_t queued;
static int scale(const int16_t *rg, int v)                 /* 0..127 over [min, max] */
{
    int lo = rg[0], hi = rg[1];
    return hi <= lo ? lo : lo + (hi - lo) * (v & 127) / 127;
}
int op1_param_set(int group, int knob, int value)
{
    if (group < 0 || group > 3 || knob < 0 || knob > 3) return -1;
    int i = group * 4 + knob;
    uint32_t m = irq_off();
    pval[i] = (uint8_t)(value < 0 ? 0 : value > 127 ? 127 : value);
    pend |= (uint16_t)(1u << i);
    int push = !queued;
    if (push) queued = 1;                                  /* one pending KN_PARAM_KEY at a time */
    irq_on(m);
    if (push && !kq_push(KN_PARAM_KEY, KN_PARAM_DOWN)) queued = 0;   /* queue full: the next call tries again */
    return 0;
}
static int apply(int i, int v)                             /* KeyHandler thread; -1 = skipped */
{
    int s = SLOT, k = i & 3, g = i >> 2;
    int16_t *w; const int16_t *rg;
    switch (g) {
    case OP1_PARAM_ENGINE: {
        int e = ENGINE(s);
        if (e < 0 || e > 31) return -1;
        rg = ENG_RANGE(e, k);
        if (rg[3] != 0 && rg[3] != 1) return -1;           /* linked sample ranges: stock-only */
        w = ENG_WORDS(s);
        break;
    }
    case OP1_PARAM_ENV: rg = ENV_RANGE(k); w = ENV_WORDS(s); break;
    case OP1_PARAM_FX: {
        int t = FX_TYPE(s);
        if (!FX_ON(s) || t < 0 || t > 15) return -1;
        rg = FX_RANGE(t, k); w = FX_WORDS(s);
        break;
    }
    default: {
        int t = LFO_TYPE(s);
        if (!LFO_ON(s) || t < 0 || t > 15 || t == 4 || (t == 5 && k == 3) || (t == 6 && k == 0)) return -1;
        rg = LFO_RANGE(t, k); w = LFO_WORDS(s);
    }
    }
    if (rg[1] <= rg[0]) return -1;                         /* range table not filled */
    w[k] = (int16_t)scale(rg, v);
    SET(g, s, w);
    return 0;
}
void kn_param_apply(void);
int kn_param_key(int code, int pressed)                    /* key_event_hook: 1 = our event, applied */
{
    if (code != KN_PARAM_KEY || pressed != KN_PARAM_DOWN) return 0;   /* R246's own 0x3F goes on to the stock dispatch */
    kn_param_apply();
#ifndef OP1_HOST
    { extern void kn_mx_apply(void); kn_mx_apply(); }      /* PARAM channel CCs (kennel/kn_mx.c), the same event */
#endif
    return 1;
}
void kn_param_apply(void)                                  /* kn_param_key: KN_PARAM_KEY */
{
    uint32_t m = irq_off();
    uint16_t p = pend; pend = 0; queued = 0;
    uint8_t v[16];
    for (int i = 0; i < 16; i++) v[i] = pval[i];
    irq_on(m);
    for (int i = 0; i < 16; i++) if (p >> i & 1) apply(i, v[i]);
}

/* ---- notes into the stock sequencer: key i of the keyboard plays 53 + i at octave 0 (op1r 35 ms_fw.c) ---- */
static const uint8_t kb_keys[24] = { 39, 13, 40, 14, 41, 15, 42, 28, 32, 29, 22, 30, 31, 23, 48, 24, 49, 25, 50, 51, 26, 52, 27, 53 };
static volatile uint8_t kb_down[24];
void op1_stock_seq_key(int note, int down)
{
    int i = note - 53;
    while (i < 0) i += 12;
    while (i > 23) i -= 12;
    down = down != 0;
    uint32_t m = irq_off();
    int change = !down != !kb_down[i];                     /* never a second down of a held key (stock asserts) */
    if (change) kb_down[i] = (uint8_t)down;
    irq_on(m);
    if (change && !kq_push(kb_keys[i], down)) kb_down[i] = (uint8_t)!down;
}

/* ---- SEQ + TAPE view ---- */
static const op1_page_t *tv_page;                          /* the first feature with a tape_view (after boot) */
static volatile uint8_t tv_open, tv_req, seq_down, seq_chord, tv_swallow[0x40], tv_off;
static int tv_id = -1;
static void *tv_tape_obj;
void *volatile kn_tape_alt_obj;                            /* STEFAN's screen while it is on (screens/tfscreen.c): the view gives the slot back to it */
static uint32_t *tv_scr, *tv_vt;                           /* screen object and vtable, in the arena on first use */
void *kn_alloc(uint32_t size);
static const op1_page_t *view_page(void)
{
    if (!tv_page)
        for (int i = 0; i < kn_feature_count(); i++)
            if (kn_feature_at(i)->tape_view && kn_feature_at(i)->tape_view->screen) { tv_page = kn_feature_at(i)->tape_view; break; }
    return tv_page;
}
/* Construct with the other screens at boot, before Gfx starts. Lazy construction
 * on first SEQ+TAPE also exposed a partially constructed screen-table entry. */
void kn_tapeview_ctor(void)
{
#ifndef OP1_HOST
    if(!view_page())return;
    const int id=21; /* R246 tape screen; current Gfx id can still be settings. */
    tv_scr=kn_alloc(32*4);tv_vt=kn_alloc(10*4);
    if(!tv_scr || !tv_vt)return;
    void *saved=SCREEN_TABLE[id];
    SCREEN_CTOR(tv_scr,id,tv_page->svg);SCREEN_TABLE[id]=saved;
    for(int i=0;i<10;i++)tv_vt[i]=ITER_SCREEN_VT[i];
    tv_vt[7]=(uint32_t)tv_page->screen->update;
    tv_vt[9]=(uint32_t)tv_page->screen->init;
    tv_scr[3]=(uint32_t)tv_vt;
#endif
}
void kn_tapeview_load(void)
{
#ifndef OP1_HOST
    if(!tv_scr || !tv_scr[2] || !SCREEN_TABLE[21])return;
    tv_scr[0]=(uint32_t)SVG_LOAD((void*)tv_scr[2]);
    if(!tv_scr[0])return;
    tv_page->screen->init(tv_scr);tv_tape_obj=SCREEN_TABLE[21];tv_id=21;
#endif
}
static void view_set(int on)
{
#ifndef OP1_HOST
    if(tv_id<0)return;
    SCREEN_TABLE[tv_id]=on?(void*)tv_scr:kn_tape_alt_obj?kn_tape_alt_obj:tv_tape_obj;
#endif
    tv_open=(uint8_t)on;
}
int op1_tape_view_open(void) { return tv_open; }
void op1_tape_view_close(void) { if (tv_open) view_set(0); }
void op1_tape_view_enable(int on) { tv_off = !on; if (!on) { tv_req = 0; op1_tape_view_close(); } }
/* key_event_hook, before the features' input filter: 1 = consumed. Only with a tape_view feature registered. */
int kn_tapeview_key(int code, int pressed)
{
    if (code < 0 || code >= 0x40 || !view_page()) return 0;
    if (!pressed && tv_swallow[code]) { tv_swallow[code] = 0; return 1; }
    if (tv_off) {                                          /* switched off: stock, but a held SEQ still comes out */
        if (code == 0x15 && !pressed && seq_down) { seq_down = 0; if (!seq_chord) { KEY_DISPATCH(0x15, 1); KEY_DISPATCH(0x15, 0); } return 1; }
        return 0;
    }
    if (code == 0x15) {                                    /* SEQ: held for the SEQ + TAPE chord */
        if (pressed) { seq_down = 1; seq_chord = 0; return 1; }
        seq_down = 0;
        if (!seq_chord) { KEY_DISPATCH(0x15, 1); KEY_DISPATCH(0x15, 0); }   /* plain SEQ: stock, late */
        return 1;
    }
    if (code == 0x04 && pressed) {                         /* TAPE: with SEQ held opens the view, alone closes it */
        if (seq_down && CUR_MODE == 2) { seq_chord = 1; if (!tv_open) view_set(1); tv_swallow[code] = 1; return 1; }
        if (seq_down) { seq_chord = 1; tv_req = 1; return 0; }   /* not in tape mode yet: stock switches, then open */
        tv_req=0;
        if (tv_open) view_set(0);
        return 0;
    }
    return 0;
}
/* After feature input: let REC+metronome be consumed while the view is still open. Only an unconsumed mode
 * key closes it; SEQ/TAPE chord handling above remains reserved ahead of feature input. */
void kn_tapeview_after_input(int code, int pressed)
{
    if (pressed && (code==0x02 || code==0x03 || code==0x05 || code==0x00 || code==0x01 || code==0x2C)) {
        tv_req=0;
        if(tv_open)view_set(0);
    }
}
/* key_event_hook, after the tape features (red press = tape marker in the view too): encoder pushes to the view */
int kn_tapeview_push(int code, int pressed)
{
    if (!tv_open || !tv_page || !tv_page->push || code < 0x3B || code > 0x3E) return 0;
    if (pressed) tv_page->push(code - 0x3B);
    return 1;
}
int kn_tapeview_knob(int knob, int delta)                  /* knob_event_hook, after the input filter and tape */
{
    if (!tv_open || !tv_page || !tv_page->turn || knob < 0 || knob > 3) return 0;
    tv_page->turn(knob, delta);
    return 1;
}
void kn_tapeview_service(void)                             /* main loop: SEQ + TAPE pressed outside tape mode */
{
    if (tv_req && CUR_MODE == 2) { tv_req = 0; if (!tv_off) view_set(1); }
}

/* settings page switches (op1_switch, op1_switch_on, kn_switch_*): kennel/kn_setpage.c */
