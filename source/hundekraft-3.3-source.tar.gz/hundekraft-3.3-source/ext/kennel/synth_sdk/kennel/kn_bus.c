/* The instrument-bus insert and its modulation (op1_bus.h). kn_bus_run is called from kn_input_bus (kennel/kn_input.c)
 * after R246's high-pass, once a block, for the synth (pos 0) or the drum (pos 1) caller of core_bus_highpass; it
 * steps the master LFO's strip targets (screens/mlfo.c ml_bus_tick), sums the fresh modulation and calls the insert.
 * No insert registered: one load and a branch. The insert's time is charged to the FX class of the resource monitor.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../op1_synth.h"
#include "../op1_bus.h"
#include "../kn_mem.h"
#include "kn_bus.h"

#ifndef OP1_HOST
#define BLOCKS() (*(volatile uint16_t *)0x01AB8BAC)          /* R246's block count, a 16-bit word (core_block_process) */
#else
uint16_t kn_bus_host_blocks;
#define BLOCKS() (kn_bus_host_blocks)
#endif

static op1_bus_insert_fn insert kn_hot;
static int16_t mods[OP1_BUS_NSRC][2][OP1_BUS_NMOD] kn_hot;
static uint16_t stamp[OP1_BUS_NSRC][2] kn_hot;
static uint8_t seen[OP1_BUS_NSRC][2] kn_hot;
volatile uint32_t kn_bus_calls, kn_bus_cy_max;            /* emulator checks: blocks with the insert, its slowest */

int op1_bus_insert(op1_bus_insert_fn fn)
{
    if (fn && insert && insert != fn) return -1;
    insert = fn;
    return 0;
}
int op1_bus_insert_on(void) { return insert != 0; }

kn_audio_text void op1_bus_mod_set(int src, int pos, const int16_t *mod)
{
    if ((unsigned)src >= OP1_BUS_NSRC || (unsigned)pos > OP1_BUS_BOTH) return;
    for (int p = 0; p < 2; p++) {
        if (pos != OP1_BUS_BOTH && p != pos) continue;
        for (int k = 0; k < OP1_BUS_NMOD; k++) mods[src][p][k] = mod[k];
        stamp[src][p] = BLOCKS(); seen[src][p] = 1;
    }
    if (src == OP1_BUS_SRC_MASTER) {                       /* the tape strips that follow it (screens/usbtrack.c) */
        extern int16_t kn_tape_mod[OP1_BUS_NMOD]; extern volatile uint8_t kn_tape_mod_fresh;
        for (int k = 0; k < OP1_BUS_NMOD; k++) kn_tape_mod[k] = mod[k];
        kn_tape_mod_fresh = 3;
    }
}

kn_audio_text void kn_bus_run(int pos, int16_t *bus)
{
    const op1_bus_insert_fn fn = insert;
    if (!fn) return;
    ml_bus_tick();                                         /* the master LFO's strip targets (screens/mlfo.c) */
    int32_t sum[OP1_BUS_NMOD];
    for (int k = 0; k < OP1_BUS_NMOD; k++) sum[k] = 0;
    const uint16_t now = BLOCKS();
    for (int s = 0; s < OP1_BUS_NSRC; s++) {
        if (!seen[s][pos] || (uint16_t)(now - stamp[s][pos]) > 2) continue;   /* stale: the source stopped */
        for (int k = 0; k < OP1_BUS_NMOD; k++) sum[k] += mods[s][pos][k];
    }
    int16_t m[OP1_BUS_NMOD];
    for (int k = 0; k < OP1_BUS_NMOD; k++) m[k] = (int16_t)(sum[k] > 32767 ? 32767 : sum[k] < -32767 ? -32767 : sum[k]);
    const uint32_t t = op1_cycles();
    fn(pos, bus, m);
    const uint32_t d = op1_cycles() - t;
    sm_cy[SMC_FX] += d;
    kn_bus_calls++;
    if (d > kn_bus_cy_max) kn_bus_cy_max = d;
}
