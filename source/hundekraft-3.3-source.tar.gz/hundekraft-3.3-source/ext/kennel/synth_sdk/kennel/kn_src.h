/* Named audio sources for monitor page 7 (test build only, KN_DIAG=1; ARCHITECTURE.md "Diagnostic counters", named
 * breakdown). Every kennel-owned call in the audio callback charges its cycles to a source id: a synth engine, a
 * plugin FX at its position, a feature (LFO type passes and tick, drum synth renders, tape block hooks), sampler+,
 * drum+, or KN (kennel's own per-block work: wrappers, declick, routing, the callback's own frame). R246's stock work
 * is what is left of the callback (kn_diag.c kd_block_end), plus stock calls that run inside a kennel wrapper, which
 * the wrapper charges to KD_SRC_R246 itself. Wrappers that contain named calls use kd_nest0 / kd_wrap: the wrapper
 * gets its time minus everything charged inside it, so each cycle lands in exactly one source.
 * Release builds (KN_DIAG unset / 0): every tap is an empty inline, nothing is read or written.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_SRC_H
#define KN_SRC_H
#include <stdint.h>

/* source id: kind << 8 | index */
enum { KD_K_FIXED, KD_K_SYN, KD_K_FX0, KD_K_FX1, KD_K_FX2, KD_K_FEAT, KD_K_SMP, KD_K_DRP };
#define KD_SRC(kind, i)  ((uint32_t)(kind) << 8 | ((uint32_t)(i) & 0xFFu))
#define KD_SRC_KN        KD_SRC(KD_K_FIXED, 0)      /* kennel's own work */
#define KD_SRC_R246      KD_SRC(KD_K_FIXED, 1)      /* stock work (the rest of the callback, and stock calls in wrappers) */
#define KD_SRC_OTHER     KD_SRC(KD_K_FIXED, 2)      /* a source that found the table full (kn_diag.c KD_SRC_MAX) */
#define KD_SRC_FX(pos, order) KD_SRC(KD_K_FX0 + (pos), order)   /* pos 0 synth, 1 drum, 2 master */

#if KN_DIAG
extern volatile uint32_t kd_cb;                   /* 1 while page 7's counters run inside the audio callback */
extern volatile uint32_t kd_nested;               /* cycles charged so far (wraps): kd_wrap takes the inner ones off */
void kd_src_add(uint32_t id, uint32_t cycles);
static inline void kd_src(uint32_t id, uint32_t cycles) { if (kd_cb) kd_src_add(id, cycles); }
static inline uint32_t kd_nest0(void) { return kd_nested; }
/* a wrapper's whole time c, taken when kd_nest0() returned n0: charged minus what was charged inside it */
static inline void kd_wrap(uint32_t id, uint32_t c, uint32_t n0)
{
    if (!kd_cb) return;
    const uint32_t in = kd_nested - n0;
    kd_src_add(id, c > in ? c - in : 0);
}
#ifdef OP1_HOST
extern uint32_t kd_host_now;
static inline uint32_t kd_now(void) { return kd_host_now; }
#else
static inline uint32_t kd_now(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
#endif
#define KD_T0(v)          uint32_t v = kd_now()
#define KD_LEAF(id, t0)   kd_src((id), kd_now() - (t0))
#else
static inline void kd_src(uint32_t id, uint32_t cycles) { (void)id; (void)cycles; }
static inline uint32_t kd_nest0(void) { return 0; }
static inline void kd_wrap(uint32_t id, uint32_t c, uint32_t n0) { (void)id; (void)c; (void)n0; }
#define KD_T0(v)          ((void)0)
#define KD_LEAF(id, t0)   ((void)0)
#endif
#endif
