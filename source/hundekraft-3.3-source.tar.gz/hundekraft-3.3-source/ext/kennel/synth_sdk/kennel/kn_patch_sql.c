/*
 * Patch saves that fit (2026-11-12, OP1-Emulator run/gin-fxcrash-2026-11-12/).
 *
 * R246's patch jobs (BgFileWorker; the slot save 0x01940574, the kit / preset loads 0x0193F578 / 0x019407DC and the
 * type jobs 0x0193F86C / 0x0193FFAC) serialize the slot's patch and format
 *     snprintf(0x01BA340C, 5000, "UPDATE drum_slots SET patch='%s' WHERE id=%i", patch, slot)   (or synth_slots)
 * then run it with db2_exec (0x0196F950), which stops the OP-1 on any SQLite error (db2.cpp:129). A patch over
 * about 4,950 bytes is cut before its closing quote: "unrecognized token: "'{"dbox_data":..."". A Gin kit reloaded
 * after a reboot is 5,040 bytes (R246's normalize adds dbox_data, 24 x 8 nulls), so any stock save of that slot (an
 * FX change: on/off, type, a knob) crashed on 3.3 beta 4 and 3.2.x. The quote is not escaped either: a ' in a
 * patch string would end the literal early.
 *
 * Each of the seven snprintf calls (make_firmware.py HOOKS hook_psql*) comes here instead, same arguments. The
 * statement is built with every ' doubled. If it fits the stock buffer it goes there, as before. If not, it is built
 * in our own buffer and run here, the same db2_exec on the same handle the stock code is about to use, and the stock
 * buffer gets a statement that does nothing. Past our buffer too (no patch this side of KN_PATCH_SQL_CAP is known),
 * nothing is written and a toast says so: the sound stays as it is in memory, the OP-1 keeps running.
 * Only BgFileWorker runs these jobs (or bgs_flush_sync after it stopped), one at a time: one static buffer.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>
#include "kn_patch_sql.h"

#ifdef OP1_HOST
extern int kn_patch_sql_host_snprintf(char *, unsigned, const char *, const char *, int);
extern void *kn_patch_sql_host_db(void);
extern void kn_patch_sql_host_exec(void *, const char *);
#define STOCK_SNPRINTF kn_patch_sql_host_snprintf
#define DB_HANDLE      kn_patch_sql_host_db
#define DB2_EXEC       kn_patch_sql_host_exec
#else
#define STOCK_SNPRINTF ((int (*)(char *, unsigned, const char *, ...))0x01A4CCD8)
#define DB_HANDLE      ((void *(*)(void))0x0196DD44)                     /* the op1.db handle the jobs pass */
#define DB2_EXEC       ((void (*)(void *, const char *))0x0196F950)      /* db2_exec: panics on an SQLite error */
#endif
void op1_toast(const char *text);                                        /* kn_core.c */
void kn_log_line(const char *file, const char *msg);                     /* kn_boot.c */

static char big[KN_PATCH_SQL_CAP];
volatile uint32_t kn_patch_sql_big, kn_patch_sql_refused;               /* counts (monitor, tests) */
static const char nothing[] = "SELECT 1 WHERE 0;";

/* the statement fmt makes, ' doubled in %s, written to out when out is not 0; its length, or -1 for a format this
 * does not know (anything but %s, %i, %d, %%) */
static int build(char *out, const char *fmt, const char *patch, int id)
{
    int n = 0;
    for (const char *f = fmt; *f; f++) {
        if (*f != '%') { if (out) out[n] = *f; n++; continue; }
        f++;
        if (*f == '%') { if (out) out[n] = '%'; n++; }
        else if (*f == 's') {
            for (const char *p = patch ? patch : ""; *p; p++) {
                if (out) out[n] = *p;
                n++;
                if (*p == '\'') { if (out) out[n] = '\''; n++; }
            }
        } else if (*f == 'i' || *f == 'd') {
            char d[12]; int k = 0; uint32_t v = id < 0 ? 0u - (uint32_t)id : (uint32_t)id;
            do { d[k++] = (char)('0' + v % 10u); v /= 10u; } while (v);
            if (id < 0) { if (out) out[n] = '-'; n++; }
            while (k--) { if (out) out[n] = d[k]; n++; }
        } else return -1;
    }
    if (out) out[n] = 0;
    return n;
}

static void copy(char *dst, const char *src) { while ((*dst++ = *src++)) ; }

int kn_patch_sql(char *buf, unsigned cap, const char *fmt, const char *patch, int id)
{
    int n = build(0, fmt, patch, id);
    if (n < 0) return STOCK_SNPRINTF(buf, cap, fmt, patch, id);           /* not one of ours: as before */
    if ((unsigned)n < cap) { build(buf, fmt, patch, id); return n; }
    if (cap <= sizeof nothing) return STOCK_SNPRINTF(buf, cap, fmt, patch, id);   /* no room even for the no-op */
    if ((unsigned)n < sizeof big) {
        build(big, fmt, patch, id);
        DB2_EXEC(DB_HANDLE(), big);
        kn_patch_sql_big++;
    } else {
        kn_patch_sql_refused++;
        kn_log_line("sound", "patch too big to save, not saved");
        op1_toast("Sound too big to save");
    }
    copy(buf, nothing);
    return n;
}
