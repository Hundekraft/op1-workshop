/*
 * The settings page's rows (kn_setpage.h): core rows (kn_setting_core, op1_switch), plugin tables (plugin.json
 * "settings", extension tag 7, copied into an arena), the RAM word of every declared storage key, op1_setting_value,
 * OP1_EV_SETTING. The page itself is screens/settings.c. ARCHITECTURE.md "Settings page"; the table format is
 * docs/plugin-format.md "Settings table".
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC optimize("Os,no-tree-loop-distribute-patterns")   /* not hot; the core image is at its limit (kn_mem.h) */
#endif
#include "../op1_synth.h"
#include "../op1_feature.h"
#include "../op1_feature_midi.h"
#include "kn_setpage.h"
#ifndef KN_DIAG
#define KN_DIAG 0
#endif

void kn_log_line(const char *what, const char *msg);            /* kn_boot.c (fake core: a stub) */
int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);

typedef struct kn_sfeat kn_sfeat;
typedef struct {
    const char *id, *label, *unit;
    const char *const *clab;                 /* choice labels */
    const int32_t *cval;                     /* choice values (stored, before the mask) */
    int32_t def, min, max, step;
    uint32_t mask;
    uint8_t type, n, flags, index;           /* index: in the plugin's table (OP1_EV_SETTING's arg) */
    int8_t push;                             /* the push target's index in the table, -1 none */
    int8_t kc;                               /* key cache entry, -1: a core row */
    const kn_setting_core_t *core;
    kn_sfeat *owner;                         /* 0: a core row */
} kn_srow;
struct kn_sfeat {
    const char *name, *title;
    kn_srow *rows;                           /* n entries, in table order */
    uint8_t n, slots;                        /* slots: the rows that take a place on a page (n minus push targets) */
    volatile uint16_t pend;                  /* rows changed by the page: OP1_EV_SETTING due (bit = index) */
    kn_srow *slot[8];                        /* slot -> row, 0 = empty */
};

/* ---- arena ---- */
static uint8_t arena[KN_SET_ARENA] __attribute__((aligned(4)));
static uint32_t used;
static void *take(uint32_t n)
{
    n = (n + 3) & ~3u;
    if (used + n > sizeof arena) return 0;
    void *p = arena + used;
    used += n;
    return p;
}
static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }
static int same(const char *a, const char *b) { if (!a || !b) return 0; while (*a && *a == *b) { a++; b++; } return *a == *b; }
static int before(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return (uint8_t)*a < (uint8_t)*b; }
static char *dup_up(const char *s)           /* a copy in upper case (stroke font) */
{
    int n = slen(s);
    char *d = take((uint32_t)n + 1);
    if (!d) return 0;
    for (int i = 0; i <= n; i++) d[i] = s[i] >= 'a' && s[i] <= 'z' ? (char)(s[i] - 32) : s[i];
    return d;
}

/* ---- declared keys: the stored word in RAM ---- */
static struct { const char *feature, *key; volatile int32_t val; volatile uint8_t dirty; } kc[KN_SET_KEYS];
static int n_kc;
static int kc_find(const char *feature, const char *key)
{
    for (int i = 0; i < n_kc; i++) if (same(kc[i].feature, feature) && same(kc[i].key, key)) return i;
    return -1;
}
int kn_setcache_get(const char *feature, const char *key, int32_t *out)
{
    int i = kc_find(feature, key);
    if (i < 0) return 0;
    *out = kc[i].val;
    return 1;
}
void kn_setcache_put(const char *feature, const char *key, int32_t v)
{
    int i = kc_find(feature, key);
    if (i >= 0) { kc[i].val = v; kc[i].dirty = 0; }      /* op1_setting_set wrote the DB itself */
}
void kn_setpage_flush(void)
{
    for (int i = 0; i < n_kc; i++)
        if (kc[i].dirty) { kc[i].dirty = 0; op1_setting_set(kc[i].feature, kc[i].key, kc[i].val); }
}

/* ---- a row's value ---- */
static int32_t row_get(const kn_srow *r)
{
    if (r->core) return r->core->get ? r->core->get() : 0;
    int32_t s = kc[(int)r->kc].val;
    if (r->mask) s = (int32_t)((uint32_t)s & r->mask);
    if (r->type == KN_SET_ONOFF) return s != 0;
    if (r->type == KN_SET_CHOICE) {
        for (int i = 0; i < r->n; i++) if (r->cval[i] == s) return s;
        return r->def;
    }
    return s < r->min || s > r->max ? r->def : s;
}
static int choice_at(const kn_srow *r, int32_t v)            /* the index of value v (core rows: the index itself) */
{
    if (r->core || !r->cval) return v < 0 ? 0 : v >= r->n ? r->n - 1 : (int)v;
    for (int i = 0; i < r->n; i++) if (r->cval[i] == v) return i;
    return 0;
}
static void row_set(kn_srow *r, int32_t v)                   /* KeyHandler */
{
    if (r->core) { if (r->core->set) r->core->set(v); return; }
    int k = r->kc;
    uint32_t bits = (uint32_t)v;
    if (r->type == KN_SET_ONOFF) bits = v ? (r->mask ? r->mask : 1u) : 0;
    int32_t s = r->mask ? (int32_t)(((uint32_t)kc[k].val & ~r->mask) | (bits & r->mask)) : (int32_t)bits;
    if (s == kc[k].val) return;
    kc[k].val = s;
    if (r->type == KN_SET_ONOFF) { kc[k].dirty = 0; op1_setting_set(kc[k].feature, kc[k].key, s); }   /* saved at once */
    else kc[k].dirty = 1;                                        /* at the next key event (kn_setpage_flush) */
    if (r->owner) r->owner->pend |= (uint16_t)(1u << r->index);
    if (r->flags & KN_SET_RESTART) op1_toast("restart to apply");
}

/* ---- core rows ---- */
/* core rows live in static storage, never in the arena: plugin tables can't crowd them out */
static kn_srow *core_slot[KN_SET_CORE_SLOTS];
static kn_srow core_rows[KN_SET_CORE_SLOTS];
int kn_setting_core(const char *page, int slot, const kn_setting_core_t *row)
{
    if (!same(page, "core") || slot < 0 || slot >= KN_SET_CORE_SLOTS || !row || !row->label) return -1;
    if (core_slot[slot]) return core_slot[slot]->core == row ? 0 : -1;
    kn_srow *r = &core_rows[slot];
    r->label = row->label; r->type = row->type; r->n = row->n; r->clab = row->choices;
    r->min = row->min; r->max = row->max; r->step = row->step ? row->step : 1; r->def = row->def;
    r->push = -1; r->kc = -1; r->core = row;
    core_slot[slot] = r;
    return 0;
}

/* op1_switch: an on / off row with key "<feature>.on" (slot 1 first, then 6..11; 0, 2, 3 are COUNT-IN, STEFAN, CLICK, 4 and 5 are USB AUDIO and TRACKS FROM) */
#define KN_SW_MAX 9
static kn_srow *sw[KN_SW_MAX];
static int n_sw;
static int sw_find(const char *feature)
{
    for (int i = 0; i < n_sw; i++) if (same(sw[i]->id, feature)) return i;
    return -1;
}
static int free_switch_slot(void)
{
    if (!core_slot[1]) return 1;
    for (int s = KN_SET_SLOT_USBFROM + 1; s < KN_SET_CORE_SLOTS; s++) if (!core_slot[s]) return s;
    return -1;
}
int op1_switch(const char *feature, const char *label)
{
    if (!feature || !label) return -1;
    if (sw_find(feature) >= 0) return 0;
    int slot = free_switch_slot();
    if (slot < 0 || n_sw >= KN_SW_MAX || n_kc >= KN_SET_KEYS) return -1;
    static char labels[KN_SW_MAX][13];
    kn_srow *r = &core_rows[slot];
    char *lb = labels[n_sw];
    int i = 0;
    for (; label[i] && i < 12; i++) lb[i] = label[i] >= 'a' && label[i] <= 'z' ? (char)(label[i] - 32) : label[i];
    lb[i] = 0;
    int k = kc_find(feature, "on");
    if (k < 0) {
        k = n_kc++;
        kc[k].feature = feature; kc[k].key = "on"; kc[k].dirty = 0;
        kc[k].val = kn_setting_db_get(feature, "on", 0) != 0;
    }
    r->id = feature; r->label = lb; r->type = KN_SET_ONOFF; r->push = -1; r->kc = (int8_t)k; r->max = 1; r->step = 1;
    core_slot[slot] = r;
    sw[n_sw++] = r;
    return 0;
}
int op1_switch_on(const char *feature)
{
    int i = sw_find(feature);
    return i < 0 ? 0 : row_get(sw[i]) != 0;
}
/* the pre-3.3 page's switch list (still exported): the op1_switch rows in registration order */
int kn_switch_count(void) { return n_sw; }
const char *kn_switch_label(int i) { return i >= 0 && i < n_sw ? sw[i]->label : 0; }
int kn_switch_get(int i) { return i >= 0 && i < n_sw ? row_get(sw[i]) != 0 : 0; }
void kn_switch_set(int i, int on) { if (i >= 0 && i < n_sw && !row_get(sw[i]) != !on) row_set(sw[i], on != 0); }

/* ---- plugin tables ---- */
#define KN_SET_FEATS 24
static kn_sfeat *feats[KN_SET_FEATS];                            /* sorted by name */
static int n_feats;

static uint32_t rd32(const uint8_t *p) { return p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24; }
static int font_ok(const char *s, int max)                       /* the stroke font's characters, 1..max */
{
    int n = 0;
    for (; s[n]; n++) {
        char c = s[n];
        if (n >= max || !((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == ' ' || c == '-' || c == '+' ||
                          c == '/' || c == '.' || c == ':' || c == '#' || c == '%' || c == '_' || c == ','))
            return 0;
    }
    return n > 0;
}
static int id_ok(const char *s)                                  /* [a-z0-9_], 1..15 */
{
    int n = 0;
    for (; s[n]; n++) if (n >= 15 || !((s[n] >= 'a' && s[n] <= 'z') || (s[n] >= '0' && s[n] <= '9') || s[n] == '_')) return 0;
    return n > 0;
}
/* a NUL-terminated string at *o (within len), moved past; 0 if it runs off the end */
static const char *str_at(const uint8_t *t, uint32_t len, uint32_t *o)
{
    uint32_t i = *o;
    while (i < len && t[i]) i++;
    if (i >= len) return 0;
    const char *s = (const char *)t + *o;
    *o = i + 1;
    return s;
}
static const char *copy_str(const char *s)
{
    int n = slen(s);
    char *d = take((uint32_t)n + 1);
    if (d) for (int i = 0; i <= n; i++) d[i] = s[i];
    return d;
}

#define FAIL(m) do { why = m; goto bad; } while (0)
#define FULL() do { why = 0; goto bad; } while (0)
int kn_settings_add(const char *name, const uint8_t *t, uint32_t len)
{
    uint32_t mark = used;
    int kc_mark = n_kc;
    const char *why;
    if (!name || !t) return -1;
    for (int i = 0; i < n_feats; i++) if (same(feats[i]->name, name)) return -3;
    if (len < 3 || t[0] != 1) FAIL("settings: table version");
    int n = t[1];
    if (n < 1 || n > 16) FAIL("settings: row count");
    if (n_feats >= KN_SET_FEATS) FULL();
    uint32_t o = 2;
    const char *title = str_at(t, len, &o);
    if (!title || (*title && !font_ok(title, 14))) FAIL("settings: title");
    kn_sfeat *f = take(sizeof *f);
    kn_srow *rows = take(sizeof *rows * (uint32_t)n);
    const char *nm = copy_str(name);
    if (!f || !rows || !nm) FULL();
    for (unsigned i = 0; i < sizeof *f; i++) ((uint8_t *)f)[i] = 0;
    f->name = nm; f->rows = rows; f->n = (uint8_t)n;
    if (*title) f->title = copy_str(title);
    else {                                                       /* the name in capitals, _ as a space */
        char *d = dup_up(name);
        if (d) for (int i = 0; d[i]; i++) if (d[i] == '_') d[i] = ' ';
        f->title = d;
    }
    if (!f->title) FULL();
    for (int i = 0; i < n; i++) {
        kn_srow *r = &rows[i];
        for (unsigned b = 0; b < sizeof *r; b++) ((uint8_t *)r)[b] = 0;
        if (o + 24 > len) FAIL("settings: row runs past the table");
        const uint8_t *h = t + o;
        o += 24;
        r->type = h[0]; r->flags = h[1]; r->n = h[2]; r->push = (int8_t)(h[3] ? h[3] - 1 : -1);
        r->def = (int32_t)rd32(h + 4); r->min = (int32_t)rd32(h + 8); r->max = (int32_t)rd32(h + 12);
        r->step = (int32_t)rd32(h + 16); r->mask = rd32(h + 20);
        r->index = (uint8_t)i; r->owner = f; r->kc = -1;
        const char *id = str_at(t, len, &o), *lb = str_at(t, len, &o), *key = str_at(t, len, &o), *un = str_at(t, len, &o);
        if (!id || !lb || !key || !un) FAIL("settings: row strings");
        if (r->type == 0) { if (r->flags & KN_SET_HIDDEN) FAIL("settings: empty push target"); continue; }   /* an empty slot */
        if (r->type > KN_SET_NUMBER || (r->flags & ~7u)) FAIL("settings: row type or flags");
        if (!id_ok(id) || !id_ok(key) || !font_ok(lb, 12) || (*un && !font_ok(un, 3))) FAIL("settings: row id, key, label or unit");
        if ((r->type == KN_SET_CHOICE) != (r->n != 0) || r->n > 8 || (r->type == KN_SET_CHOICE && r->n < 2)) FAIL("settings: choices");
        if (r->push >= 0 && (r->push >= n || r->type == KN_SET_ONOFF || (r->flags & KN_SET_HIDDEN))) FAIL("settings: push");
        if ((r->flags & KN_SET_HIDDEN) && r->type != KN_SET_ONOFF) FAIL("settings: push target not on / off");
        for (int k = 0; k < i; k++) if (rows[k].id && same(rows[k].id, id)) FAIL("settings: id twice");
        r->id = copy_str(id); r->label = copy_str(lb); r->unit = *un ? copy_str(un) : 0;
        if (!r->id || !r->label || (*un && !r->unit)) FULL();
        if (r->type == KN_SET_CHOICE) {
            const char **cl = take(sizeof *cl * r->n);
            int32_t *cv = take(sizeof *cv * r->n);
            if (!cl || !cv) FULL();
            int def_ok = 0;
            for (int c = 0; c < r->n; c++) {
                const char *s = str_at(t, len, &o);
                if (!s || !font_ok(s, 10) || o + 4 > len) FAIL("settings: choice");
                cv[c] = (int32_t)rd32(t + o); o += 4;
                if (r->mask && ((uint32_t)cv[c] & ~r->mask)) FAIL("settings: choice outside its mask");
                for (int k = 0; k < c; k++) if (cv[k] == cv[c]) FAIL("settings: choice value twice");
                if (!(cl[c] = copy_str(s))) FULL();
                def_ok |= cv[c] == r->def;
            }
            r->clab = cl; r->cval = cv;
            if (!def_ok) FAIL("settings: default not a choice");
        } else if (r->type == KN_SET_NUMBER) {
            if (r->mask || r->step < 1 || r->min >= r->max || (r->max - r->min) / r->step > 64 || r->def < r->min || r->def > r->max)
                FAIL("settings: number range");
        } else if ((uint32_t)r->def > 1) FAIL("settings: on / off default");
        /* the key's RAM word: rows may share a key only through masks that do not overlap */
        int k = -1;
        for (int j = 0; j < i; j++) if (rows[j].type && rows[j].kc >= 0 && same(kc[(int)rows[j].kc].key, key)) {
            if (!r->mask || !rows[j].mask || (r->mask & rows[j].mask)) FAIL("settings: key shared without masks");
            k = rows[j].kc;
        }
        uint32_t dbits = r->type == KN_SET_ONOFF ? (r->def ? (r->mask ? r->mask : 1u) : 0) : (uint32_t)r->def;
        if (k < 0) {
            if (n_kc >= KN_SET_KEYS) FULL();
            k = n_kc++;
            kc[k].feature = f->name; kc[k].key = copy_str(key); kc[k].dirty = 0; kc[k].val = (int32_t)dbits;
            if (!kc[k].key) FULL();
        } else kc[k].val = (int32_t)((uint32_t)kc[k].val | dbits);   /* the key's default: its rows' defaults ORed */
        r->kc = (int8_t)k;
    }
    for (int i = 0; i < n; i++) if (rows[i].push >= 0 && !(rows[rows[i].push].flags & KN_SET_HIDDEN)) FAIL("settings: push target has a row");
    int s = 0;
    for (int i = 0; i < n; i++) {
        if (rows[i].flags & KN_SET_HIDDEN) continue;
        if (s >= 8) FAIL("settings: more than 8 rows");
        f->slot[s++] = rows[i].type && (!(rows[i].flags & KN_SET_DIAG) || KN_DIAG) ? &rows[i] : 0;
    }
    f->slots = (uint8_t)s;
    while (f->slots && !f->slot[f->slots - 1]) f->slots--;      /* trailing empty slots take no page */
    for (int i = kc_mark; i < n_kc; i++) kc[i].val = kn_setting_db_get(f->name, kc[i].key, kc[i].val);   /* saved values */
    if (!f->slots) return 0;                                     /* nothing to show (diag rows in a release) */
    int at = n_feats;
    while (at > 0 && before(name, feats[at - 1]->name)) { feats[at] = feats[at - 1]; at--; }
    feats[at] = f;
    n_feats++;
    return 0;
bad:                                                             /* nothing kept: the plugin loads without its rows */
    kn_log_line(name, why ? why : "settings: no room");
    used = mark; n_kc = kc_mark;
    return why ? -1 : -2;
}

int32_t op1_setting_value(const char *feature, const char *id)
{
    for (int i = 0; i < n_feats; i++) {
        if (!same(feats[i]->name, feature)) continue;
        for (int k = 0; k < feats[i]->n; k++) if (feats[i]->rows[k].type && same(feats[i]->rows[k].id, id)) return row_get(&feats[i]->rows[k]);
        return 0;
    }
    if (same(id, "on")) return op1_switch_on(feature);
    return 0;
}

void kn_setpage_service(void)                                    /* main loop */
{
    for (int i = 0; i < n_feats; i++) {
        kn_sfeat *f = feats[i];
        uint16_t p = f->pend;
        if (!p) continue;
        f->pend &= (uint16_t)~p;
        const op1_feature_t *ft = 0;
        for (int k = 0; k < kn_feature_count(); k++) { const op1_feature_t *x = kn_feature_at(k); if (x && same(x->name, f->name)) { ft = x; break; } }
        if (!ft || !ft->event) continue;
        for (int b = 0; b < 16; b++) if (p & (1u << b)) ft->event(OP1_EV_SETTING, b);
    }
}

/* ---- pages ---- */
static int core_pages(void)
{
    int last = 3;
    for (int s = 4; s < KN_SET_CORE_SLOTS; s++) if (core_slot[s]) last = s;
    return last / 4 + 1;
}
int kn_sp_pages(void)
{
    int n = core_pages();
    for (int i = 0; i < n_feats; i++) n += (feats[i]->slots + 3) / 4;
    return n > KN_SET_PAGES_MAX ? KN_SET_PAGES_MAX : n;
}
static kn_sfeat *page_feat(int page, int *base)                  /* 0: a core page (*base = its first slot) */
{
    int cp = core_pages();
    if (page < cp) { *base = page * 4; return 0; }
    page -= cp;
    for (int i = 0; i < n_feats; i++) {
        int np = (feats[i]->slots + 3) / 4;
        if (page < np) { *base = page * 4; return feats[i]; }
        page -= np;
    }
    *base = -1;
    return 0;
}
static kn_srow *row_at(int page, int slot)
{
    int base;
    if (page < 0 || page >= kn_sp_pages() || slot < 0 || slot > 3) return 0;
    kn_sfeat *f = page_feat(page, &base);
    if (base < 0) return 0;
    if (!f) return base + slot < KN_SET_CORE_SLOTS ? core_slot[base + slot] : 0;
    return base + slot < f->slots ? f->slot[base + slot] : 0;
}
const char *kn_sp_title(int page)
{
    int base;
    kn_sfeat *f = page_feat(page, &base);
    return f ? f->title : "SETTINGS";
}
static char *put_s(char *d, const char *s, char *end) { while (*s && d < end) *d++ = *s++; return d; }
static char *put_i(char *d, int32_t v, char *end)
{
    char t[12]; int n = 0;
    uint32_t u = v < 0 ? (uint32_t)-v : (uint32_t)v;
    do t[n++] = (char)('0' + u % 10); while (u /= 10);
    if (v < 0 && d < end) *d++ = '-';
    while (n && d < end) *d++ = t[--n];
    return d;
}
int kn_sp_row(int page, int slot, kn_sp_view *v)
{
    kn_srow *r = row_at(page, slot);
    if (!r) return 0;
    char *d = v->value, *end = v->value + sizeof v->value - 1;
    int32_t x = row_get(r);
    v->label = r->label;
    v->dim = r->core && r->core->inactive && r->core->inactive() ? 1 : 0;
    if (r->type == KN_SET_ONOFF) d = put_s(d, x ? "ON" : "OFF", end);
    else if (r->type == KN_SET_CHOICE) d = put_s(d, r->clab ? r->clab[choice_at(r, x)] : "", end);
    else { d = put_i(d, x, end); if (r->unit) d = put_s(d, r->unit, end); }
    const char *tag = 0;
    if (r->core && r->core->push_tag && r->core->push_get && r->core->push_get()) tag = r->core->push_tag;
    if (r->owner && r->push >= 0 && row_get(&r->owner->rows[(int)r->push])) tag = r->owner->rows[(int)r->push].label;
    if (tag) { d = put_s(d, " ", end); d = put_s(d, tag, end); }
    *d = 0;
    return 1;
}
void kn_sp_turn(int page, int slot, int dir)
{
    kn_srow *r = row_at(page, slot);
    if (!r || !dir) return;
    int32_t x = row_get(r);
    if (r->type == KN_SET_ONOFF) { if (!x != !(dir > 0)) row_set(r, dir > 0); return; }
    if (r->type == KN_SET_CHOICE) {
        int c = choice_at(r, x) + (dir > 0 ? 1 : -1);
        if (c < 0 || c >= r->n) return;
        row_set(r, r->core || !r->cval ? c : r->cval[c]);
        return;
    }
    int32_t y = x + (dir > 0 ? r->step : -r->step);
    if (y < r->min) y = r->min;
    if (y > r->max) y = r->max;
    if (y != x) row_set(r, y);
}
void kn_sp_push(int page, int slot)
{
    kn_srow *r = row_at(page, slot);
    if (!r) return;
    if (r->core && r->core->push_tag) { if (r->core->push_set && r->core->push_get) r->core->push_set(!r->core->push_get()); return; }
    if (r->owner && r->push >= 0) { kn_srow *p = &r->owner->rows[(int)r->push]; row_set(p, !row_get(p)); return; }
    if (r->type == KN_SET_ONOFF) row_set(r, !row_get(r));
    else if (row_get(r) != r->def) row_set(r, r->def);
}
const char *kn_switch_feature(int i) { return i >= 0 && i < n_sw ? sw[i]->id : 0; }   /* fake core's fc_set_switch */
uint32_t kn_setpage_used(void) { return used; }
