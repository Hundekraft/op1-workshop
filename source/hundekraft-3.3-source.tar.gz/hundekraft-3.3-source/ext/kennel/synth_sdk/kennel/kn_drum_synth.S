/* Native register preservation adapted from SquareWave Studio Gin ec5d6f7.
 * GPL-3.0-or-later with OP-1 firmware permission; see plugins/gin/vendor/NOTICE. */
.text
.align 2
.macro SAVE
 [--SP] = ASTAT;
 [--SP] = RETS;
 [--SP] = FP;
 [--SP] = (R7:0, P5:0);
 [--SP] = A0.w;
 [--SP] = A0.x;
 [--SP] = A1.w;
 [--SP] = A1.x;
 [--SP] = I0;
 [--SP] = I1;
 [--SP] = I2;
 [--SP] = I3;
 [--SP] = M0;
 [--SP] = M1;
 [--SP] = M2;
 [--SP] = M3;
 [--SP] = B0;
 [--SP] = B1;
 [--SP] = B2;
 [--SP] = B3;
 [--SP] = L0;
 [--SP] = L1;
 [--SP] = L2;
 [--SP] = L3;
 [--SP] = LC0;
 [--SP] = LC1;
 [--SP] = LT0;
 [--SP] = LT1;
 [--SP] = LB0;
 [--SP] = LB1;

 R0 = 0;
 L0 = R0;
 L1 = R0;
 L2 = R0;
 L3 = R0;
 LC0 = R0;
 LC1 = R0;
 SP += -12;
.endm
.macro RESTORE
 SP += 12;
 LB1 = [SP++];
 LB0 = [SP++];
 LT1 = [SP++];
 LT0 = [SP++];
 LC1 = [SP++];
 LC0 = [SP++];
 L3 = [SP++];
 L2 = [SP++];
 L1 = [SP++];
 L0 = [SP++];
 B3 = [SP++];
 B2 = [SP++];
 B1 = [SP++];
 B0 = [SP++];
 M3 = [SP++];
 M2 = [SP++];
 M1 = [SP++];
 M0 = [SP++];
 I3 = [SP++];
 I2 = [SP++];
 I1 = [SP++];
 I0 = [SP++];
 A1.x = [SP++];
 A1.w = [SP++];
 A0.x = [SP++];
 A0.w = [SP++];
 (R7:0, P5:0) = [SP++];
 FP = [SP++];
 RETS = [SP++];
 ASTAT = [SP++];
.endm




.macro OWN_ENTER op
 [SP] = P0;
 [SP + 4] = R0;
 R0 = ASTAT;
 [SP + 8] = R0;
 CLI R0;
 P0.L = _kn_ds_stack_top + 4*\op;
 P0.H = _kn_ds_stack_top + 4*\op;
 P0 = [P0];
 CC = P0 == 0;
 IF CC JUMP .Lstock_\op;
 [P0 + 8] = R0;
 R0 = SP;
 [P0] = R0;
 R0 = [SP + 8];
 ASTAT = R0;
 R0 = [SP + 4];
 SP = P0;
.global _kn_ds_stack_entered_\op
_kn_ds_stack_entered_\op:
.endm
.macro OWN_LEAVE tag, lane
 P0 = [SP];
 [P0 + 4] = R0;

 R0 = [SP + 8];
 SP = P0;
.global _kn_ds_stack_left_\tag
_kn_ds_stack_left_\tag:
 P0 = [SP];
 STI R0;
 R0 = [SP + 4];
.global _kn_ds_stack_left_end_\tag
_kn_ds_stack_left_end_\tag:
.endm


.global _kn_ds_entry_trigger
_kn_ds_entry_trigger:
 OWN_ENTER 0
 SAVE
 R0 = [SP + 168];
 R1 = [SP + 164];
 R2 = [SP + 160];
 CALL _kn_ds_trigger;
 [SP + 168] = R0;
 RESTORE
 OWN_LEAVE trigger, 0
 RTS;
.Lstock_0:
 STI R0;
 R0 = [SP + 8];
 ASTAT = R0;
 R0 = [SP + 4];
 P0 = [SP];
 JUMP.L _kn_ds_stock_trigger;

.global _kn_ds_entry_render
_kn_ds_entry_render:
 OWN_ENTER 1
 SAVE
 R0 = [SP + 168];
 R1 = [SP + 164];
 R2 = [SP + 160];
 CALL _kn_ds_render;
 [SP + 168] = R0;
 RESTORE
 OWN_LEAVE render, 1
 RTS;
.Lstock_1:
 STI R0;
 R0 = [SP + 8];
 ASTAT = R0;
 R0 = [SP + 4];
 P0 = [SP];
 JUMP.L _kn_ds_stock_render;

.global _kn_ds_entry_release
_kn_ds_entry_release:
 OWN_ENTER 2
 SAVE
 R0 = [SP + 168];
 R1 = [SP + 164];
 R2 = [SP + 160];
 CALL _kn_ds_release;
 [SP + 168] = R0;
 RESTORE
 OWN_LEAVE release, 2
 RTS;
.Lstock_2:
 STI R0;
 R0 = [SP + 8];
 ASTAT = R0;
 R0 = [SP + 4];
 P0 = [SP];
 JUMP.L _kn_ds_stock_release;

.global _kn_ds_entry_status
_kn_ds_entry_status:
 OWN_ENTER 3
 SAVE
 R0 = [SP + 168];
 R1 = [SP + 164];
 R2 = [SP + 160];
 CALL _kn_ds_status;
 [SP + 168] = R0;
 RESTORE
 OWN_LEAVE status, 3
 RTS;
.Lstock_3:
 STI R0;
 R0 = [SP + 8];
 ASTAT = R0;
 R0 = [SP + 4];
 P0 = [SP];
 JUMP.L _kn_ds_stock_status;

.text
.align 2
.global _kn_ds_entry_type
_kn_ds_entry_type:
 P0 = [SP++];
 SAVE
 R0 = [SP + 168];
 R1 = [SP + 164];
 R2 = [SP + 160];
 R1 = [SP + 176];
 R2 = P5;
 CALL _kn_ds_type;
 [SP + 168] = R0;
 RESTORE
 RTS;
.section .hook_dstype,"ax"
 [--SP] = P0;
 P0.L = _kn_ds_entry_type;
 P0.H = _kn_ds_entry_type;
 JUMP (P0);
 NOP;

.text
.align 2
.global _kn_ds_entry_factory
_kn_ds_entry_factory:
 P0 = [SP++];
 SAVE
 R0 = [SP + 168];
 R1 = [SP + 164];
 R2 = [SP + 160];
 CALL _kn_ds_factory;
 [SP + 168] = R0;
 RESTORE
 RTS;
.section .hook_dsfactory,"ax"
 [--SP] = P0;
 P0.L = _kn_ds_entry_factory;
 P0.H = _kn_ds_entry_factory;
 JUMP (P0);
 NOP;

.text
.align 2
.global _op1_drum_synth_stock_type
_op1_drum_synth_stock_type:
.include "ds_type.private.inc"
 P0.L = 0x981e;
 P0.H = 0x019b;
 JUMP (P0);
.global _op1_drum_synth_stock_normalize
_op1_drum_synth_stock_normalize:
.include "ds_normalize.private.inc"
 P0.L = 0x37ac;
 P0.H = 0x01a0;
 JUMP (P0);
.section .hook_dsnormalize,"ax"
 JUMP.L _kn_ds_normalize;
.text
.align 2
.global _kn_ds_snapshot_read_entry
_kn_ds_snapshot_read_entry:
 [--SP] = RETS;
 SP += -12;
 CALL _kn_ds_snapshot_read;
 SP += 12;
 RETS = [SP++];
 CC = R0 == 0;
 IF CC JUMP .Lds_snapshot_ok;
 P0.L = 0xd8f4;
 P0.H = 0x019a;
 JUMP (P0);
.Lds_snapshot_ok:
 RTS;
.global _kn_ds_screen_entry
_kn_ds_screen_entry:
 SAVE
 CALL _kn_ds_screen;
 [SP + 168] = R0;
 RESTORE
 P0 = [FP + 4];
 UNLINK;
 JUMP (P0);
.section .hook_dsscreen,"ax"
 JUMP.L _kn_ds_screen_entry;
 NOP;

.section .hook_dsjsonsave,"ax"
 CALL _kn_ds_json_equal;

.section .hook_dsjsonload,"ax"
 CALL _kn_ds_json_equal;

.section .hook_dspresetquery,"ax"
 CALL _kn_ds_preset_query;

.section .hook_dspresetcopy,"ax"
 CALL _kn_ds_preset_copy;

.section .hook_dssnapread,"ax"
 CALL _kn_ds_snapshot_read_entry;

.section .hook_dssnapsave,"ax"
 CALL _kn_ds_snapshot_save;
