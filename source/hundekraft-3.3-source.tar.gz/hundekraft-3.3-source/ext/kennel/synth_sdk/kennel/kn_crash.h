/* Crash screen (kennel/kn_crash.c): the text part, host-testable (harness/crash_test.c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_CRASH_H
#define KN_CRASH_H
#include <stdint.h>
#include "kn_images.h"

typedef struct { uint32_t sp, seq, reti, ipend, icplb; } kn_crash_regs;
/* appends the crash lines to buf (cap bytes, 0-terminated, keeps what is there); msg: R246's message or 0; rd reads a word of memory */
void kn_crash_text(char *buf, int cap, const char *msg, const char *ver, const kn_crash_regs *r, uint32_t (*rd)(uint32_t),
                   const kn_img_map *map);
void kn_crash_version(char *ver, int cap, const char *banner, const char *boot);
#endif
