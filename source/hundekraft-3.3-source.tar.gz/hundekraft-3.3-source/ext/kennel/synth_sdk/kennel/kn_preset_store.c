/*
 * Preset storage: 1,024 user synth presets and 256 user drum kits (owner, 2026-11-13, for 3.3). ARCHITECTURE.md
 * "Preset storage"; OP1-Emulator docs/preset-studio-storage-plan-2026-11-13.md and docs/ports/presets-design.md.
 *
 * R246 keeps every preset of both tables fully parsed in the TE heap (2,785 B a synth preset, about 11.9 KB a kit),
 * parses them all at each boot and reload, and re-sorts a browser folder after every child it adds. Kennel changes:
 *
 * Light entries. The loaders' user-table loads (CALL db2::load_presets at 0x01A0586E synth, 0x01A05122 drum, and
 * recount_presets' 0x01A01BCC / 0x01A01CD6) run with kn_pl_mode set. Inside, the row parser's CALL Reader::parse
 * (0x0196FF9A) comes here: a bounded scan (kn_pl_scan.h) gives the row {type, name} only; text the scan does not
 * take is parsed in full as before. The user rows' setters (hook_lpsyn2 / hook_lpdrm2) take a light value without
 * R246's patch check (it would reject it) and note the row id per entry. Every R246 reader of a table entry outside
 * the load jobs reads only type, name and folder (browser builders, slot -> preset 0x01A02030 / 0x01A01DC8, slot
 * loaders 0x01A05454 / 0x01A04DC0, engine and type lists 0x01A02440 / 0x01A025E8, the loader's sampler count), and
 * so do kennel's (sbrowse, preset tools, the sampler guard).
 *
 * Fill on choose. The jobs that load a table entry into a slot (0x019407DC, 0x0193F578, type jobs 0x0193FFAC /
 * 0x0193F86C with selection <= 0) are wrapped (kn_drum_synth.c, kn_drum.c, sp_core.c): a light entry's patch is read
 * by id from op1.db, parsed and checked (the slot loaders' kennel parse, with its repairs) into the table's last entry,
 * which the loader never reaches (the table count holds 16 + more than the gates allow), and the job is pointed at
 * that entry. Visible entries never change under the browser. After the job the spare value is freed. A preset that
 * can't be read or checked is refused with a toast and the slot keeps its sound (R246 would stop at boot instead).
 *
 * Drum table. 448 entries (KN_PL_DRUM_TABLE) here in .farbss instead of R246's 58 at 0x01DE20F8: the nine address
 * loads are repointed (hook.S), the vector ctor / dtor take 448 (stubs on their CALLs), the loader's user-row
 * assert (56 << 3) can't be reached because the user load is limited to the room left (kn_pl_drum_room), and the save
 * gate 0x019FEEE4 is kn_pl_drum_gate_fn (256 user kits). The factory check (58) stays.
 *
 * Browser. While the synth or drum builder runs (its two CALL sites and preset tools' rebuild), the per-child sort in
 * 0x01A18050 (CALL 0x01A196E4 at 0x01A18152) is skipped for that list's folders, and every folder is sorted once at
 * the end: same order (names are unique per folder), n log n instead of n^2 log n.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include <stdint.h>
#include "kn_pl_scan.h"
#include "../kn_mem.h"

#ifndef OP1_HOST
#include "../op1_feature.h"

#define JV_KEY      ((void *(*)(void *, const char *))0x019BFEB4)     /* Value::operator[](const char *) */
#define JV_FROM_STR ((void *(*)(void *, const char *))0x019BDC4C)     /* Value(const char *) */
#define JV_ASSIGN   ((void *(*)(void *, const void *))0x019BDDC0)     /* Value::operator= */
#define JV_DTOR     ((void (*)(void *, int))0x019BDD18)
#define JV_NULL_C   ((void *(*)(void *, int))0x019BFA30)             /* Value(ValueType) */
#define JV_SIZE     ((unsigned (*)(const void *))0x019BE8D8)
#define RD_CTOR     ((void *(*)(void *))0x019BB0BE)                  /* Json::Reader() (db2::load_presets) */
#define RD_PARSE    ((int (*)(void *, void *, void *, int))0x019BBF98)   /* Reader::parse(doc, root, comments) */
#define RD_DTOR     ((void (*)(void *, int))0x0196E4FC)
#define STR_SET     ((void (*)(void *, const char *))0x0196DFD0)      /* std::string = const char * (db2) */
#define STR_ASSIGN  ((kn_pl_assign_fn)0x019FF0BC)                 /* std::string::assign(str, pos, n) */
#define OP_DELETE   ((void (*)(void *))0x01A5E310)
#define LOAD_ROWS   ((void (*)(void *, void *, const char *))0x0196FE8C) /* db2::load_presets(out, db, table) */
#define LIST_SORT   ((void (*)(void *, void *, int))0x01A196E4)      /* std::sort of a folder's children (0x20 each) */
#define BUILD(k)    (((void *(*)(void))((k) ? 0x01A028EC : 0x01A02790))())
#define BR_LIST(k)  ((uint8_t *)((k) ? 0x01DDD698 : 0x01DDD688))
#define DB_HANDLE   ((void *(*)(void))0x0196DD44)
#define SQL_EXEC    ((int (*)(void *, const char *, int (*)(void *, int, char **, char **), void *, char **))0x019C9460)
#define N_SYNTH     (*(volatile int32_t *)0x018B6114)               /* entries in the synth table (factory + user) */
#define N_DRUM      (*(volatile int32_t *)0x018B6118)

typedef struct { uint32_t alloc; union { char buf[16]; char *ptr; } u; uint32_t size, cap; } st_str;   /* 0x1C */
static const char *st_c(const st_str *s) { return s->cap > 15 ? s->u.ptr : s->u.buf; }
static inline uint32_t cyc(void) { uint32_t c; __asm__ volatile("%0 = CYCLES;" : "=d"(c)); return c; }

int synth_load_parse(void *json, int mode);                       /* kn_patch_safe.c: the synth slot loader's parse */
int dp_load_parse(void *json, int mode);                          /* kn_drum.c: the drum slot loader's parse */
void kn_lp_take(uint32_t *entry, int slot, uint32_t *json);       /* kn_boottime.c */
void kn_lp_set_synth(uint32_t *e, int slot, uint32_t *json);
void kn_lp_set_drum(uint32_t *e, int slot, uint32_t *json);

#define SYN_MAX 2048                                              /* entries we keep ids for (the table holds 1,263 at cap 1,024) */
uint8_t kn_drum_tab[KN_PL_DRUM_TABLE * 0x38] __attribute__((aligned(4)));
static int32_t pl_id[2][SYN_MAX] kn_farbss;
static uint8_t pl_light[2][SYN_MAX] kn_farbss;
static char pl_text[8192] kn_farbss;

volatile uint32_t kn_pl_on = 1;          /* 0 (a poke): full entries at the next load, as R246 */
volatile uint32_t kn_pl_mode;            /* inside a user-table load */
volatile int32_t kn_pl_drum_factory = 24;
/* light rows, full rows (scan declined), fills, fills refused, sorts skipped, folders sorted,
 * last synth list build (us at 400 MHz: CYCLES / 400), last drum build, slowest synth build, slowest drum build */
volatile uint32_t kn_pl_stat[10];

static uint8_t *synth_base(void)                                  /* the (builder-relocated) table, as sp_core.c reads it */
{
    uint32_t b = *(const volatile uint16_t *)0x01940032;
    b |= (uint32_t)*(const volatile uint16_t *)0x01940036 << 16;
    return (uint8_t *)b;
}
static int tab_size(int k) { return k ? KN_PL_DRUM_TABLE : *(const volatile uint16_t *)0x01A05FFC; }
static uint8_t *tab(int k) { return k ? kn_drum_tab : synth_base(); }
uint8_t *kn_pl_drum_table(void) { return kn_drum_tab; }

/* ---- light rows ---- */
static void put(void *root, const char *key, const char *s)
{
    uint32_t tmp[4];
    JV_FROM_STR(tmp, s);
    JV_ASSIGN(JV_KEY(root, key), tmp);
    JV_DTOR(tmp, 2);
}
/* CALL Reader::parse in db2::load_presets (0x0196FF9A) */
int kn_pl_parse(void *reader, void *doc, void *root, int comments)
{
    if (kn_pl_mode && kn_pl_on) {
        char type[KN_PL_STR], name[KN_PL_STR];
        if (kn_pl_scan(st_c(doc), type, name)) {
            put(root, "type", type);
            put(root, "name", name);
            kn_pl_stat[0]++;
            return 1;
        }
        kn_pl_stat[1]++;
    }
    return RD_PARSE(reader, doc, root, comments);
}
/* CALL db2::load_presets for synth_user (loader 0x01A0586E, recount 0x01A01BCC) */
void kn_pl_load_synth(void *out, void *db, const char *table)
{
    kn_pl_mode = 1;
    LOAD_ROWS(out, db, table);
    kn_pl_mode = 0;
}
/* .. for drum_user (loader 0x01A05122, recount 0x01A01CD6): the factory kits are counted already */
void kn_pl_load_drum(void *out, void *db, const char *table)
{
    char q[48];
    int i = 0, f = N_DRUM, room = kn_pl_drum_room(f);
    kn_pl_drum_factory = f;
    for (; table[i] && i < 24; i++) q[i] = table[i];
    const char *lim = " LIMIT ";
    for (int j = 0; lim[j]; j++) q[i++] = lim[j];
    char d[6]; int n = 0;
    do d[n++] = (char)('0' + room % 10); while (room /= 10);
    while (n) q[i++] = d[--n];
    q[i] = 0;
    kn_pl_mode = 1;
    LOAD_ROWS(out, db, q);
    kn_pl_mode = 0;
}
static int entry_index(int k, const uint32_t *e)
{
    uint32_t off = (uint32_t)e - (uint32_t)tab(k);
    return off % 0x38 == 0 && off / 0x38 < SYN_MAX ? (int)(off / 0x38) : -1;
}
static void set_user(int k, uint32_t *e, int slot, uint32_t *json)
{
    int i = entry_index(k, e);
    if (i >= 0) pl_id[k][i] = (int32_t)json[-1];                 /* the row: id, patch value, folder */
    if (slot == -1 && i >= 0 && kn_pl_on && JV_SIZE(json) <= 2) {
        pl_light[k][i] = 1;
        kn_lp_take(e, slot, json);                                /* no patch check: it is not a patch */
        return;
    }
    if (i >= 0) pl_light[k][i] = 0;
    (k ? kn_lp_set_drum : kn_lp_set_synth)(e, slot, json);
}
void kn_lp_set_synth_user(uint32_t *e, int slot, uint32_t *json) { set_user(0, e, slot, json); }   /* hook_lpsyn2 */
void kn_lp_set_drum_user(uint32_t *e, int slot, uint32_t *json) { set_user(1, e, slot, json); }    /* hook_lpdrm2 */

/* drum save gate 0x019FEEE4 (R246: count < 58) */
int kn_pl_drum_gate_fn(void) { return kn_pl_drum_gate(N_DRUM, kn_pl_drum_factory); }

/* ---- fill on choose ---- */
static int text_row(void *arg, int n, char **v, char **c)
{
    (void)c;
    int *len = arg, i = 0;
    if (n < 1 || !v[0]) return 0;
    for (; v[0][i] && i < (int)sizeof pl_text - 1; i++) pl_text[i] = v[0][i];
    pl_text[i] = 0;
    *len = v[0][i] ? -1 : i;                                      /* too long: refuse */
    return 0;
}
static int db_text(int k, int32_t id)
{
    char q[64], *o = q;
    const char *a = k ? "SELECT patch FROM drum_user WHERE id=" : "SELECT patch FROM synth_user WHERE id=";
    while (*a) *o++ = *a++;
    uint32_t u = (uint32_t)id; char d[10]; int n = 0;
    do d[n++] = (char)('0' + u % 10); while (u /= 10);
    while (n) *o++ = d[--n];
    *o = 0;
    int len = -2;
    void *h = DB_HANDLE();
    void *sem = *(void *volatile *)0x01BAB718;                    /* db2's statement lock (kn_preset_tools.c db_run) */
    if (sem) ((void (*)(void *, int))0xFFA0B6E8)(sem, 0);
    int rc = SQL_EXEC(*(void **)h, q, text_row, &len, 0);
    if (sem) ((void (*)(void *))0xFFA0B96C)(sem);
    return rc ? -3 : len;
}
static void spare_clear(uint8_t *s)
{
    JV_DTOR(s + 4, 2);
    JV_NULL_C(s + 4, 0);
}
static volatile uint8_t filled[2];
static volatile int32_t saved_sel[2];

/* the entry index a job should use: idx itself, the spare entry holding the full patch, or -1 (refused) */
static int pl_fill(int k, int idx)
{
    int n = k ? N_DRUM : N_SYNTH, spare = tab_size(k) - 1;
    if (idx < 0 || idx >= n || idx >= SYN_MAX || !pl_light[k][idx]) return idx;
    if (spare <= n || spare >= tab_size(k)) goto fail;
    uint8_t *e = tab(k) + idx * 0x38, *s = tab(k) + spare * 0x38;
    if (db_text(k, pl_id[k][idx]) <= 0) goto fail;
    spare_clear(s);
    uint32_t rd[48];                                              /* Json::Reader: 120 bytes */
    st_str doc;
    doc.alloc = 0; doc.u.buf[0] = 0; doc.size = 0; doc.cap = 15;
    STR_SET(&doc, pl_text);
    RD_CTOR(rd);
    int ok = RD_PARSE(rd, &doc, s + 4, 0);
    RD_DTOR(rd, 2);
    if (doc.cap > 15 && doc.u.ptr) OP_DELETE(doc.u.ptr);
    if (!ok) { spare_clear(s); goto fail; }
    kn_pl_folder_copy(STR_ASSIGN, s + 0x14, e + 0x14);            /* folder (the sample path), all of it */
    *(int32_t *)s = -1;
    s[0x30] = 0;                                                  /* a user preset */
    if (k ? dp_load_parse(s + 4, 1) : synth_load_parse(s + 4, 0)) { spare_clear(s); goto fail; }
    kn_pl_stat[2]++;
    return spare;
fail:
    kn_pl_stat[3]++;
    op1_toast("This preset can't be loaded");
    return -1;
}
/* job threads (BgFileWorker): sel points at the job's table index (neg: the type jobs' -index). 0 = don't run it */
int kn_pl_job_fill(int k, int32_t *sel, int neg)
{
    k &= 1;
    filled[k] = 0;
    if (neg && *sel > 0) return 1;                                /* a type, not a preset */
    int idx = neg ? -*sel : *sel, use = pl_fill(k, idx);
    if (use < 0) return 0;
    if (use != idx) { saved_sel[k] = *sel; *sel = neg ? -use : use; filled[k] = 1; }
    return 1;
}
void kn_pl_job_done(int k, int32_t *sel)
{
    k &= 1;
    if (!filled[k]) return;
    *sel = saved_sel[k];
    spare_clear(tab(k) + (tab_size(k) - 1) * 0x38);
    filled[k] = 0;
}

/* ---- browser: sort each folder once ---- */
volatile uint32_t kn_br_p4;                                       /* hook.S: P4 at the sort CALL (folder + 0x20) */
static uint8_t *volatile defer_list;
void kn_br_sort(void *begin, void *end, int n)                    /* CALL std::sort at 0x01A18152 */
{
    uint8_t *l = defer_list;
    if (l) {
        uint8_t *f = (uint8_t *)kn_br_p4 - 0x20;
        if (f >= *(uint8_t **)(l + 4) && f < *(uint8_t **)(l + 8)) { kn_pl_stat[4]++; return; }
    }
    LIST_SORT(begin, end, n);
}
void *kn_pl_build(int k)
{
    k &= 1;
    uint32_t c = cyc();
    uint8_t *l = BR_LIST(k);
    defer_list = l;
    void *r = BUILD(k);
    defer_list = 0;
    for (uint8_t *f = *(uint8_t **)(l + 4); f < *(uint8_t **)(l + 8); f += 0x30) {
        uint8_t *b = *(uint8_t **)(f + 0x24), *e = *(uint8_t **)(f + 0x28);
        int n = (int)((e - b) >> 5);
        if (n > 1) { LIST_SORT(b, e, n); kn_pl_stat[5]++; }
    }
    uint32_t us = (cyc() - c) / 400u;
    kn_pl_stat[6 + k] = us;
    if (us > kn_pl_stat[8 + k]) kn_pl_stat[8 + k] = us;
    return r;
}
void *kn_pl_build_synth(void) { return kn_pl_build(0); }          /* CALL 0x01A02790 at 0x01A50884 */
void *kn_pl_build_drum(void) { return kn_pl_build(1); }           /* CALL 0x01A028EC at 0x01977718 */
#endif
