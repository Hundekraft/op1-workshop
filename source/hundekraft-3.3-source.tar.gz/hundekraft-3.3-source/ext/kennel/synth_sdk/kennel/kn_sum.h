/* Voice-sum blocks (op1_plugin.h op1_engine_sum_t): when the core calls an engine's block on the synth bus, and with
 * which fresh flag. dispatcher.c kn_engine_sum does the R246 reads (built slot, its type, its engine, the block count);
 * this decides. Shared with harness/sum_block_test.c.
 *   caller: core_bus_highpass's return address; only core_block_process's synth call (0xFFA02896) runs a block, so
 *           drum (0xFFA02464) and game (0xFFA01EC2) mode never do
 *   type:   the built slot's synth type (14 = iter, the plugin engines' row); e: its engine order (0 = stock or muted)
 *   fn:     that engine's block (0: none, nothing runs: the cost of an engine without one)
 *   blk:    core_block_process's block count (a 16-bit word: compared modulo 2^16); fresh = 1 when the previous block
 *           did not call this engine
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_SUM_H
#define KN_SUM_H
#include <stdint.h>

#define KN_SUM_CALLER_SYNTH 0xFFA02896u

typedef void (*kn_sum_fn)(int16_t *bus, int fresh);
struct kn_sum_state { uint32_t last_blk; uint8_t last_e; };

/* 1 when fn ran */
static inline int kn_sum_run(struct kn_sum_state *s, uint32_t caller, int32_t type, int e, kn_sum_fn fn, uint32_t blk,
                             int16_t *bus)
{
    if (caller != KN_SUM_CALLER_SYNTH || type != 14 || !e || !fn) { s->last_e = 0; return 0; }
    const int fresh = e != s->last_e || (uint16_t)(blk - s->last_blk) != 1u;
    s->last_e = (uint8_t)e;
    s->last_blk = blk;
    fn(bus, fresh);
    return 1;
}
#endif
