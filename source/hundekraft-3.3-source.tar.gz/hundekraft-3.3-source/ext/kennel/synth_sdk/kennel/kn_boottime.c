/*
 * Boot stage timers (after op1r-src b220d08 "Boot time", xoza; GPL-3.0-or-later with the OP-1 firmware permission,
 * PROVENANCE.md): the db stage (db2::open, Clips::load with kennel's plugin loader, FAT init) and the snd stage (the
 * five preset / slot / sample loads OP_Main runs through 0x01A059D0) timed per call, read by the resource monitor's
 * boot pages (screens/sysmon.c). R246's own stage timers (OP_Main 0x019EFEEC: 25 x ms at 0x01AB3030) give the totals.
 *
 * Hooks (make_firmware.py HOOKS, hook.S, link.ld): CALL db2::open at 0x019F02E0, CALL fat_manager::init at 0x019F02F4,
 * CALL 0x01A059D0 at 0x019F0456 (that function is LINK, five CALLs, return: kn_bt_sounds makes the same five calls).
 * Clips::load and kennel's loader are timed inside kn_boot_hook (kennel/kn_boot.c), the screen stage's kennel share in
 * screens_load_hook (dispatcher.c). Times in ms from CYCLES at 400 MHz (the unit's clock; the emulator's cycles are
 * its own, so on the emulator read R246's stage timers or guest time instead).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>
#include "kn_l1rt.h"

/* ms: db2::open, Clips::load, FAT init, synth presets, drum presets, synth slots, drum slots, sample path */
volatile uint32_t kn_bt_split[8];
/* ms: kennel's plugin loader (kn_boot_hook less Clips::load), kennel's share of the screen stage */
volatile uint32_t kn_bt_kennel[2];

#ifdef OP1_HOST
static inline uint32_t cyc(void) { return 0; }
#else
static inline uint32_t cyc(void) { uint32_t c; __asm__ volatile("%0 = CYCLES;" : "=d"(c)); return c; }
#endif
uint32_t kn_bt_now(void) { return cyc(); }
uint32_t kn_bt_ms(uint32_t c0) { return (cyc() - c0) / 400000u; }

#ifndef OP1_HOST
void kn_bt_db_open(const char *root)                 /* CALL @0x019F02E0 db2::open(root) */
{
    kn_l1rt_boot();                                  /* first, untimed: the L1 pokes and decimator (kn_l1rt.c), as op1r 20581ac */
    const uint32_t c = cyc();
    ((void (*)(const char *))0x0196F912)(root);
    kn_bt_split[0] = kn_bt_ms(c);
}
void kn_bt_fat_init(const char *root)                /* CALL @0x019F02F4 fat_manager::init(root) */
{
    const uint32_t c = cyc();
    ((void (*)(const char *))0x019971B0)(root);
    kn_bt_split[2] = kn_bt_ms(c);
}
void kn_bt_sounds(void)                              /* CALL @0x019F0456 0x01A059D0: its five calls, each timed */
{
    static void (*const f[5])(void) = { (void (*)(void))0x01A0567C, (void (*)(void))0x01A04FE8,
        (void (*)(void))0x01A05454, (void (*)(void))0x01A04DC0, (void (*)(void))0x01A017DC };
    for (int i = 0; i < 5; i++) { const uint32_t c = cyc(); f[i](); kn_bt_split[3 + i] = kn_bt_ms(c); }
}

/* Preset table fill (after op1r-src b220d08, "faster preset load"). load_synth_presets / load_drum_presets call
 * set_*_patch(entry, -1, row json) for each row (0x01A05766 / 0x01A058D4, 0x01A050A2 / 0x01A05184); for slot -1 that
 * stores the slot, Json::Value::operator= (0x019BDDC0: a deep copy, then a swap) into entry + 4, clears byte +0x30 and
 * calls the patch load (0x01A051E8 / 0x01A04BB0, where kennel's own hooks run as before); the row vector is freed
 * right after. Here the 16-byte value header is swapped instead (jsoncpp values hold no pointers to themselves): the
 * same table, one deep copy and one free fewer per preset. The loader reads the entry afterwards (its type, for the
 * sampler count; 0x01A05910) and the row only for its folder (row + 0x14), so the row's old contents are not read
 * again. A sampler row past kennel's limit (kn_sampler_guard.c) is not counted and the next row lands in the same
 * entry: the swap hands the skipped value to that row, which is freed with the vector. Other slots: the stock setter.
 * kn_lp_on = 0 (a poke) gives the stock deep copy on the next load. kn_lp_stat: rows swapped, rows copied. */
#endif
volatile uint32_t kn_lp_on = 1, kn_lp_stat[2];
/* the stock setter's slot -1 work without the deep copy: the entry takes the row's value, the row the entry's old one */
void kn_lp_take(uint32_t *entry, int slot, uint32_t *json)
{
    entry[0] = (uint32_t)slot;
    for (int i = 0; i < 4; i++) { const uint32_t t = entry[1 + i]; entry[1 + i] = json[i]; json[i] = t; }
    *(volatile uint8_t *)((uint8_t *)entry + 0x30) = 0;
}
#ifndef OP1_HOST
static void lp_set(uint32_t *entry, int slot, uint32_t *json, uint32_t stock, uint32_t load)
{
    if (slot != -1 || !kn_lp_on) {
        kn_lp_stat[1]++;
        ((void (*)(uint32_t *, int, uint32_t *))stock)(entry, slot, json);
        return;
    }
    kn_lp_stat[0]++;
    kn_lp_take(entry, slot, json);
    ((void (*)(uint32_t *))load)(entry);
}
void kn_lp_set_synth(uint32_t *e, int slot, uint32_t *json) { lp_set(e, slot, json, 0x01A052DC, 0x01A051E8); }
void kn_lp_set_drum(uint32_t *e, int slot, uint32_t *json)  { lp_set(e, slot, json, 0x01A04C48, 0x01A04BB0); }
#endif
