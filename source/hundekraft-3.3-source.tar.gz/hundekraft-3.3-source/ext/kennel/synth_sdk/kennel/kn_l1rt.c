/*
 * L1 patches at boot (after op1r-src 20581ac "L1 patches at boot", xoza; GPL-3.0-or-later with the OP-1 firmware
 * permission, PROVENANCE.md). R246's L1 code comes from encrypted LDR blocks. Instead of changing those blocks (the
 * optional regeneration helper, l1_patches.json's "ops"), the build leaves them as TE made them and kennel writes its L1 pokes
 * (make_firmware.py L1_CALLS / L1_PCCALLS / L1_IMM_PATCHES -> build/kn_l1rt_table.c: address, kind, the target symbol,
 * R246's original bytes) into L1 instruction SRAM here, through the DTEST registers: L1 instruction memory can't be
 * written by a core store. The new bytes are encoded here from the target's linked address (kn_l1rt_encode), the same
 * encoding as make_firmware.py's LDR path.
 *
 * When: CALL db2::open at 0x019F02E0 (OP_Main's db stage) comes here first, in the main thread, before audio::init
 * starts the audio DMA callback that runs the patched code. If R246's audio block counter has already moved, nothing
 * is written (a poke spans up to two 8-byte DTEST blocks; the audio interrupt must not run half-patched code).
 *
 * All or nothing: every 8-byte block every poke covers is read first and each poke's original bytes are compared. One
 * difference (another firmware, a build in LDR mode that already patched, a damaged image) and nothing is written:
 * R246's own L1 code then runs unpatched: the OP-1 boots and plays, but kennel's per-block work behind the metronome
 * vector stops with it (ci_metro_render: FX2 routing capture, the features' ticks such as chord and undo, the tape
 * hooks' blocks such as the MIDI sequencer and punch-in, the count-in click), as do the USB track outputs, the tape
 * resampler probe and the mix-loop meters. Each written block is read back. R246's block counter lives in an LDR
 * zero-fill block (0x01AA7078.., 0x358EBC bytes), so it reads 0 until core_block_process first runs. The
 * result is told once after boot (kn_core.c, kn_l1rt_text) and on the resource monitor's boot line (kn_l1rt).
 *
 * DTEST access as the Linux kernel's isram_write / isram_read (arch/blackfin/mm/isram-driver.c, Copyright 2008 Analog
 * Devices Inc., GPL-2 or later): IADDR2DTEST address bits, interrupts off around data + command, CSYNC before and after
 * the command, the command cleared to 0 afterwards. BF527 anomaly list (rev I, via Linux mach-bf527 anomaly.h): the
 * only test-register item is 05000481 (reads of ITEST_COMMAND / ITEST_DATA corrupt the cache): ITEST is never touched.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>
#include "kn_l1rt.h"

/* [0] pokes written, [1] refused (original differs / audio running / read-back), [2] the poke count in the build,
 * [3] state: 0 not run, 1 written, 2 refused: original differs, 3 refused: audio already running, 4 read-back failed,
 * [4] the first differing poke's address, [5] R246's block counter when it ran */
volatile uint32_t kn_l1rt[6];

#ifdef OP1_HOST
/* host test: an L1 image to read and write (harness/l1rt_test.c) */
uint8_t kn_l1rt_host_l1[0xC000];
uint16_t kn_l1rt_host_blocks;
int kn_l1rt_host_fail_write = -1;                        /* the n-th block write of a run drops its data (read-back test) */
static int host_writes;
static void dtest_read(uint32_t a, uint32_t *d0, uint32_t *d1)
{
    const uint8_t *p = kn_l1rt_host_l1 + (a - 0xFFA00000u);
    *d0 = p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24;
    *d1 = p[4] | p[5] << 8 | p[6] << 16 | (uint32_t)p[7] << 24;
}
static void dtest_write(uint32_t a, uint32_t d0, uint32_t d1)
{
    if (host_writes++ == kn_l1rt_host_fail_write) return;
    uint8_t *p = kn_l1rt_host_l1 + (a - 0xFFA00000u);
    for (int i = 0; i < 4; i++) { p[i] = (uint8_t)(d0 >> (8 * i)); p[4 + i] = (uint8_t)(d1 >> (8 * i)); }
}
#define BLOCKS() (kn_l1rt_host_blocks)
#else
#define BLOCKS() (*(volatile uint16_t *)0x01AB8BAC)     /* R246's audio block counter (core_block_process) */
#define DTEST_COMMAND (*(volatile uint32_t *)0xFFE00300)
#define DTEST_DATA0   (*(volatile uint32_t *)0xFFE00400)
#define DTEST_DATA1   (*(volatile uint32_t *)0xFFE00404)
/* Linux IADDR2DTEST: instruction access (bit 24), data array (bit 2), way / bank / subbank / index bits of the address */
static uint32_t dtest_cmd(uint32_t a)
{
    return ((a & (1u << 11)) << (26 - 11)) | (1u << 24) | ((a & (1u << 15)) << (23 - 15)) | ((a & (3u << 12)) << (16 - 12))
         | (a & 0x47F8u) | (1u << 2);
}
static void dtest_read(uint32_t a, uint32_t *d0, uint32_t *d1)
{
    uint32_t m;
    __asm__ volatile ("cli %0;" : "=d"(m));
    __asm__ volatile ("csync;");
    DTEST_COMMAND = dtest_cmd(a);
    __asm__ volatile ("csync;");
    *d0 = DTEST_DATA0; *d1 = DTEST_DATA1;
    DTEST_COMMAND = 0;
    __asm__ volatile ("csync; sti %0;" : : "d"(m));
}
static void dtest_write(uint32_t a, uint32_t d0, uint32_t d1)
{
    uint32_t m;
    __asm__ volatile ("cli %0;" : "=d"(m));
    DTEST_DATA0 = d0; DTEST_DATA1 = d1;
    __asm__ volatile ("csync;");
    DTEST_COMMAND = dtest_cmd(a) | 2u;                  /* write */
    __asm__ volatile ("csync;");
    DTEST_COMMAND = 0;
    __asm__ volatile ("csync; sti %0;" : : "d"(m));
}
#endif

#define L1_LO 0xFFA00000u
#define L1_HI 0xFFA0C000u                                /* R246's L1 code SRAM (48 KB) */

/* the bytes of the 8-byte blocks a poke covers (up to 16 bytes + alignment: 4 blocks) */
static int covers(const kn_l1rt_poke_t *p, uint32_t *a0, uint32_t *a1)
{
    *a0 = p->addr & ~7u; *a1 = (p->addr + p->len + 7) & ~7u;
    return p->len && p->len <= 16 && *a0 >= L1_LO && *a1 <= L1_HI && *a1 - *a0 <= 32;
}
static void read_blocks(uint32_t a0, uint32_t a1, uint8_t *blk)
{
    for (uint32_t a = a0; a < a1; a += 8) {
        uint32_t d0, d1;
        dtest_read(a, &d0, &d1);
        for (int i = 0; i < 4; i++) { blk[a - a0 + i] = (uint8_t)(d0 >> (8 * i)); blk[a - a0 + 4 + i] = (uint8_t)(d1 >> (8 * i)); }
    }
}
/* Byte ranges of L1 code through DTEST (kennel/kn_dec.c): 8-byte blocks read, merged, written, read back */
void kn_l1rt_read(uint32_t addr, uint8_t *out, uint32_t n)
{
    for (uint32_t a = addr & ~7u; a < addr + n; a += 8) {
        uint32_t d0, d1;
        dtest_read(a, &d0, &d1);
        for (int i = 0; i < 8; i++) {
            const uint32_t at = a + (uint32_t)i;
            if (at >= addr && at < addr + n) out[at - addr] = (uint8_t)((i < 4 ? d0 : d1) >> (8 * (i & 3)));
        }
    }
}
int kn_l1rt_write(uint32_t addr, const uint8_t *in, uint32_t n)
{
    for (uint32_t a = addr & ~7u; a < addr + n; a += 8) {
        uint32_t d[2], r0, r1;
        dtest_read(a, &d[0], &d[1]);
        for (int i = 0; i < 8; i++) {
            const uint32_t at = a + (uint32_t)i;
            if (at < addr || at >= addr + n) continue;
            const uint32_t sh = 8 * (uint32_t)(i & 3);
            d[i >> 2] = (d[i >> 2] & ~(0xFFu << sh)) | (uint32_t)in[at - addr] << sh;
        }
        dtest_write(a, d[0], d[1]);
        dtest_read(a, &r0, &r1);
        if (r0 != d[0] || r1 != d[1]) return 0;
    }
    return 1;
}
uint16_t kn_l1rt_blocks(void) { return BLOCKS(); }

int kn_l1rt_encode(const kn_l1rt_poke_t *p, uint8_t *out)
{
    uint16_t h[8];
    unsigned n;
    const uint32_t t = p->target;
    switch (p->kind) {
    case KN_L1RT_CALL:                                   /* E109 lo, E149 hi, 0061, NOP (0000) fill */
        if (p->len < 10 || p->len > 16 || (p->len & 1)) return 0;
        h[0] = 0xE109; h[1] = (uint16_t)t; h[2] = 0xE149; h[3] = (uint16_t)(t >> 16); h[4] = 0x0061;
        for (n = 5; n < p->len / 2u; n++) h[n] = 0;
        n = p->len / 2u;
        break;
    case KN_L1RT_PCCALL: {                               /* CALL pcrel24: E3xx (offset >> 16) + low 16 bits */
        if (p->len != 4) return 0;
        const int32_t d = (int32_t)(t - p->addr) >> 1;
        if (d < -0x800000 || d >= 0x800000) return 0;
        const uint32_t o = (uint32_t)d & 0xFFFFFF;
        h[0] = (uint16_t)(0xE300 | (o >> 16)); h[1] = (uint16_t)o; n = 2;
        break;
    }
    case KN_L1RT_IMM_LO: if (p->len != 2) return 0; h[0] = (uint16_t)t; n = 1; break;
    case KN_L1RT_IMM_HI: if (p->len != 2) return 0; h[0] = (uint16_t)(t >> 16); n = 1; break;
    default: return 0;
    }
    for (unsigned i = 0; i < n; i++) { out[2 * i] = (uint8_t)h[i]; out[2 * i + 1] = (uint8_t)(h[i] >> 8); }
    return 1;
}
static uint32_t word(const uint8_t *b) { return b[0] | b[1] << 8 | b[2] << 16 | (uint32_t)b[3] << 24; }

void kn_l1rt_apply_table(const kn_l1rt_poke_t *pk, unsigned n)
{
    kn_l1rt[0] = 0; kn_l1rt[1] = 0; kn_l1rt[2] = n; kn_l1rt[4] = 0;
#ifdef OP1_HOST
    host_writes = 0;
#endif
    kn_l1rt[5] = BLOCKS();
    if (kn_l1rt[5]) { kn_l1rt[1] = n; kn_l1rt[3] = 3; return; }
    uint8_t blk[32], data[16];
    for (unsigned i = 0; i < n; i++) {                   /* pass 1: every original, nothing written */
        uint32_t a0, a1;
        if (!covers(&pk[i], &a0, &a1) || !kn_l1rt_encode(&pk[i], data)) { kn_l1rt[1] = n; kn_l1rt[3] = 2; kn_l1rt[4] = pk[i].addr; return; }
        read_blocks(a0, a1, blk);
        const uint8_t *b = blk + (pk[i].addr - a0);
        for (unsigned k = 0; k < pk[i].len; k++)
            if (b[k] != pk[i].orig[k]) { kn_l1rt[1] = n; kn_l1rt[3] = 2; kn_l1rt[4] = pk[i].addr; return; }
    }
    for (unsigned i = 0; i < n; i++) {                   /* pass 2: merge, write, read back */
        uint32_t a0, a1;
        covers(&pk[i], &a0, &a1);
        kn_l1rt_encode(&pk[i], data);
        read_blocks(a0, a1, blk);
        for (unsigned k = 0; k < pk[i].len; k++) blk[pk[i].addr - a0 + k] = data[k];
        for (uint32_t a = a0; a < a1; a += 8) {
            const uint8_t *b = blk + (a - a0);
            uint32_t r0, r1;
            dtest_write(a, word(b), word(b + 4));
            dtest_read(a, &r0, &r1);
            if (r0 != word(b) || r1 != word(b + 4)) {   /* (not expected: the unit and the emulator read back) */
                kn_l1rt[1] = n - kn_l1rt[0]; kn_l1rt[3] = 4; kn_l1rt[4] = pk[i].addr; return;
            }
        }
        kn_l1rt[0]++;
    }
    kn_l1rt[3] = 1;
}

/* The boot toast after a refusal (kn_core.c, once after the boot toast); 0 when everything was written or nothing
 * was asked. m holds 48 bytes. */
int kn_l1rt_text(char *m)
{
    const char *s;
    switch (kn_l1rt[3]) {
    case 2: s = "L1 patches not applied: firmware differs"; break;
    case 3: s = "L1 patches not applied: audio was running"; break;
    case 4: s = "L1 patches: write failed, restart"; break;
    default: return 0;
    }
    char *o = m;
    while (*s) *o++ = *s++;
    *o = 0;
    return 1;
}

#ifndef OP1_HOST
extern const kn_l1rt_poke_t kn_l1rt_pokes[];          /* build/kn_l1rt_table.c (make_firmware.py) */
extern const unsigned kn_l1rt_npokes, kn_l1rt_runtime;
void kn_dec_install(int runtime);                     /* kennel/kn_dec.c: the decimator in L1 */
void kn_l1rt_boot(void)                                 /* first thing in the db2::open hook (kn_boottime.c kn_bt_db_open) */
{
    kn_l1rt_apply_table(kn_l1rt_pokes, kn_l1rt_npokes);
    kn_dec_install((int)kn_l1rt_runtime);             /* independent of the pokes: R246's own routine stays on a refusal */
}
#endif
