/*
 * An engine's Shift layer on its T1 page (op1_plugin.h op1_engine_shift, op1_engine_shift_record), the turns
 * dispatcher.c's knob_event_hook runs; here so the host test (harness/eng_shift_test.c) runs the same code.
 *   kn_eng_shift_turn: a Shift + turn of a word field, kn_fxshift.h's layout (blue word 5, green word 6, white bits
 *     0..6 and red bits 8..14 of word 7), then the guard: R246's patch parser takes every word of a plugin engine (type
 *     14) only in 0..32767 (loop 0x01A04A24..0x01A04A56, range check 0x01A1DEB0: a saved word outside panics the save
 *     with error 15, and a sound holding one stops the boot at load), so words 5..7 leave in 0..32767 whatever they
 *     held: bit 15 of word 7 cleared, a negative word 5 or 6 set to 0. (FX words keep their bit 15 push flags:
 *     kn_fxshift.h; the filter type's range row is another one.)
 *   kn_rec_field_turn: a Shift + turn of a record value (op1_engine_shift_record): one step a detent through 0..n-1,
 *     stopping at the ends; a value outside 0..n-1 starts from its nearest end.
 * Include after kn_fxshift.h. UI (KeyHandler) thread.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_ENGSHIFT_H
#define KN_ENGSHIFT_H
#include <stdint.h>
#include "kn_coarse.h"

/* words 5..7 of a plugin engine into R246's range for type 14 (0..32767) */
static inline void kn_eng_words_guard(int16_t *w)
{
    if (w[5] < 0) w[5] = 0;
    if (w[6] < 0) w[6] = 0;
    w[7] = (int16_t)(w[7] & 0x7FFF);
}

/* -> 1 when a word changed (as kn_fx_shift_turn); the words are guarded either way */
static inline int kn_eng_shift_turn(int32_t *acc, int16_t *w, int knob, int delta, int n)
{
    const int16_t before[3] = { w[5], w[6], w[7] };
    int r = kn_fx_shift_turn(acc, w, knob, delta, n);
    kn_eng_words_guard(w);
    return r || w[5] != before[0] || w[6] != before[1] || w[7] != before[2];
}

/* -> 1 when the value changed */
static inline int kn_rec_field_turn(int32_t *acc, int16_t *v, int delta, int n)
{
    if (n < 2) return 0;
    if ((*acc > 0 && delta < 0) || (*acc < 0 && delta > 0)) *acc = 0;
    *acc += delta;
    const int32_t st = *acc / KN_COARSE_DETENT;
    if (!st) return 0;
    *acc -= st * KN_COARSE_DETENT;
    int32_t i = *v < 0 ? 0 : (*v > n - 1 ? n - 1 : *v);
    i += st;
    i = i < 0 ? 0 : (i > n - 1 ? n - 1 : i);
    if (i == *v) return 0;
    *v = (int16_t)i;
    return 1;
}
#endif
