/*
 * Crash screen (after op1r-src 8bf2f84 "Crash screen", xoza, docs/65 there; GPL-3.0-or-later with the OP-1 firmware
 * permission, PROVENANCE.md; ARCHITECTURE.md "Hang detector and crash screen").
 *
 * R246's fatal message printer te_fatal_show_message 0x0191995C (R0 = the message) runs for a CPU exception (the
 * stock handler 0xFFA00380 prints "SEQSTAT : RETX" / "ADDR : STATUS") and for R246's panic / assert 0x01919AA8 (with
 * interrupts off). Its own frame-pointer printer could only show the handler's frames and faulted on kennel's -O2 code,
 * which uses FP as a register. Hooked at its entry (make_firmware.py HOOKS hook_crash, hook.S kn_crash_stub): the
 * stock text, then our lines, then the printer's own tail (built-in bitmap font, frame sent to the panel), then a key
 * restarts (kn_crash_wait). Our lines:
 *   The OP-1 crashed. / Take a photo of this screen and report it. / R246's message (R0)
 *   the boot label (the workshop's banner, e.g. "hundekraft 3.3"), the cause (EXCAUSE, or "assert") and IPEND
 *   sp / fp / reti, r0..r2, p0..p2 from the stock handler's frame; the ICPLB fault address for instruction faults
 *   calls: the crashed code's FP chain; if that gives fewer than 3, stack: words that look like code addresses
 *   Press any key to restart
 * Code addresses as 0x..., plugin code as <file id>+0x<offset in its image> (the loaded-image map, kn_images.h);
 * data values bare hex, so the decoder (tools/kennel/op1crash.py, with that build's symbols.json) skips them.
 * Exception context: no allocation, reads only inside the stack window the handler just used, no libc.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>
#include "kn_mem.h"
#include "kn_images.h"
#include "kn_crash.h"

/* ---------------- the text (host-tested: harness/crash_test.c) ---------------- */
static const kn_img_map *cmap;
static uint32_t (*crd)(uint32_t);
static uint32_t win_lo, win_hi;

static int plug_of(uint32_t v)
{
    if (!cmap || cmap->magic != KN_IMG_MAGIC) return -1;
    for (uint32_t i = 0; i < cmap->count && i < cmap->cap && i < 128; i++)
        if (v - cmap->rec[i].base < cmap->rec[i].text_size) return (int)i;
    return -1;
}
static int code_addr(uint32_t v)
{
    if (v & 1) return 0;
    return (v >= 0x01900000u && v < 0x01B00000u) || (v >= KN_CORE_BASE && v < KN_CORE_CODE_LIMIT) ||
           (v >= 0xFFA00000u && v < 0xFFA14000u) || plug_of(v) >= 0;
}
/* only inside the stack window the handler itself just used (SP .. SP + 2 KB): anything else can miss the CPLBs, and
 * a miss inside the exception handler is a double fault that locks the core (no screen, no reset) */
static int ram_ok(uint32_t a)
{
    return !(a & 3) && a >= win_lo && a + 4 <= win_hi &&
           ((a >= 0x1000u && a < 0x02000000u) || (a >= 0xFFB00000u && a < 0xFFB01000u));
}

typedef struct { char *p, *end; } out_t;
static void add(out_t *o, const char *s) { while (*s && o->p < o->end) *o->p++ = *s++; *o->p = 0; }
static void hex(out_t *o, uint32_t v, int prefix)
{
    char t[12]; int n = 0;
    if (prefix) { t[n++] = '0'; t[n++] = 'x'; }
    int i = 28;
    while (i > 0 && !(v >> i & 15)) i -= 4;
    for (; i >= 0; i -= 4) t[n++] = "0123456789abcdef"[v >> i & 15];
    t[n] = 0; add(o, t);
}
static void code_txt(out_t *o, uint32_t w)                   /* plugin file+offset, else the raw address */
{
    int pi = plug_of(w);
    if (pi < 0) { hex(o, w, 1); return; }
    char f[17]; int k = 0;
    for (; k < 16 && cmap->rec[pi].id[k]; k++) f[k] = cmap->rec[pi].id[k];
    f[k] = 0;
    add(o, f); add(o, "+"); hex(o, w - cmap->rec[pi].base, 1);
}
static const char *cause(const kn_crash_regs *r)
{
    if (!(r->ipend & 0x8)) return "assert";                  /* not in the exception level: R246's panic */
    switch (r->seq & 0x3F) {
    case 0x21: return "undefined instruction"; case 0x22: return "illegal instr combination";
    case 0x23: return "data access protection"; case 0x24: return "misaligned data access";
    case 0x26: return "data cplb miss"; case 0x27: return "data cplb multiple hits";
    case 0x28: return "watchpoint"; case 0x29: return "misaligned instruction";
    case 0x2A: return "instruction protection"; case 0x2B: return "instruction cplb miss";
    case 0x2C: return "instruction cplb multiple"; case 0x2D: return "illegal supervisor instr";
    case 0x2E: return "illegal supervisor access"; case 0x3F: return "hardware error";
    default: return "exception";
    }
}

/* the stock handler's frame (0xFFA00374: LINK 0x14 then ASTAT, R0..R3, R7, P0..P2 pushed): [fp] = the crashed code's
 * FP, [fp + 4] = the vector stub's return 0xFFA035A8, its SP = fp + 8; the saved registers below fp */
#define HF_RET 0xFFA035A8u
#define HF_R0 (-0x1C)
#define HF_R1 (-0x20)
#define HF_R2 (-0x24)
#define HF_P0 (-0x30)
#define HF_P1 (-0x34)
#define HF_P2 (-0x38)

void kn_crash_text(char *buf, int cap, const char *msg, const char *ver, const kn_crash_regs *r, uint32_t (*rd)(uint32_t),
                   const kn_img_map *map)
{
    static const char last[] = "\nPress any key to restart\n";
    out_t o = { buf, buf + cap - (int)sizeof last };         /* room kept for the last line */
    while (*o.p && o.p < buf + cap - 1) o.p++;                       /* after what is there (the stock lines, the message) */
    cmap = map; crd = rd;
    win_lo = r->sp; win_hi = r->sp + 2048;
    add(&o, "\nThe OP-1 crashed.\nTake a photo of this screen and report it.\n\n");
    if (msg && !(msg >= buf && msg < buf + cap)) { add(&o, msg); add(&o, "\n"); }   /* R0: R246's message */
    add(&o, ver); add(&o, "\n");
    add(&o, cause(r)); add(&o, " ipend "); hex(&o, r->ipend, 0); add(&o, "\n");
    uint32_t hf = 0;                                         /* the slot of HF_RET above SP (1 KB at most) */
    for (uint32_t a = r->sp; ram_ok(a) && a < r->sp + 1024; a += 4) if (crd(a) == HF_RET) { hf = a - 4; break; }
    if (hf && !(ram_ok(hf) && ram_ok(hf + HF_P2))) hf = 0;
    if (hf) {
        add(&o, "sp "); hex(&o, hf + 8, 0); add(&o, " fp "); hex(&o, crd(hf), 0); add(&o, " reti "); hex(&o, r->reti, 1);
        add(&o, "\nr0 "); hex(&o, crd(hf + HF_R0), 0); add(&o, " r1 "); hex(&o, crd(hf + HF_R1), 0);
        add(&o, " r2 "); hex(&o, crd(hf + HF_R2), 0);
        add(&o, "\np0 "); hex(&o, crd(hf + HF_P0), 0); add(&o, " p1 "); hex(&o, crd(hf + HF_P1), 0);
        add(&o, " p2 "); hex(&o, crd(hf + HF_P2), 0); add(&o, "\n");
    } else { add(&o, "sp "); hex(&o, r->sp, 0); add(&o, " reti "); hex(&o, r->reti, 1); add(&o, "\n"); }
    if ((r->seq & 0x3F) >= 0x29 && (r->seq & 0x3F) <= 0x2C && (r->ipend & 0x8)) {
        add(&o, "icplb addr "); hex(&o, r->icplb, 0); add(&o, "\n");
    }
    int found = 0;                                           /* the FP chain: [fp + 4] return, [fp] the caller's fp */
    if (hf) {
        uint32_t fp = crd(hf);
        add(&o, "calls");
        for (int k = 0; k < 8 && ram_ok(fp) && ram_ok(fp + 4); k++) {
            const uint32_t ret = crd(fp + 4), nx = crd(fp);
            if (!code_addr(ret)) break;
            if (found && found % 3 == 0) add(&o, "\n");
            add(&o, " "); code_txt(&o, ret);
            found++;
            if (nx <= fp) break;                             /* callers lie higher: else the chain is broken */
            fp = nx;
        }
        add(&o, found ? "\n" : " -\n");
    }
    if (found < 3) {                                         /* leaf functions keep no frame: candidates, nearest first */
        const uint32_t lo = hf ? hf + 8 : r->sp, hi = lo + 1024;
        int st = 0;
        add(&o, "stack");
        for (uint32_t a = lo; ram_ok(a) && a < hi && st < 6; a += 4) {
            const uint32_t w = crd(a);
            if (!code_addr(w)) continue;
            if (st == 3) add(&o, "\n");
            add(&o, " "); code_txt(&o, w);
            st++;
        }
        add(&o, st ? "\n" : " -\n");
    }
    if (o.p > o.end) o.p = o.end;
    o.end = buf + cap - 1;
    add(&o, last);
}

/* the boot label: the workshop's banner (builder.py, 0x01EF0000: 17 newlines, spaces, the label) or R246's boot text
 * 0x018F7358 (make_firmware.py boot_text: "op1r <n>"), without the leading newlines and spaces */
void kn_crash_version(char *ver, int cap, const char *banner, const char *boot)
{
    const char *v = banner[0] == '\n' ? banner : boot;
    for (int i = 0; i < 64 && (*v == '\n' || *v == ' '); i++) v++;
    int n = 0;
    while (n < cap - 1 && v[n] >= ' ' && v[n] < 127) { ver[n] = v[n]; n++; }
    ver[n] = 0;
    if (!n) { ver[0] = '?'; ver[1] = 0; }
}

#ifndef OP1_HOST
#include "kn_wdog.h"
#define CRASH_TXT  ((char *)0x01BA138C)                      /* 512 bytes shown on the error screen */
#define FLUSH_RANGE ((void (*)(uint32_t, uint32_t, int))0x01AA185C)   /* flush_data_cache_range */
static uint32_t rd_mem(uint32_t a) { return *(const volatile uint32_t *)a; }

void kn_crash_print(const char *msg)
{
    kn_wd_crash();                                           /* the hang detector waits 2^32 SCLK ticks (kn_wdog.c) */
    /* a black screen under the text: the stock tail (hook.S kn_crash_stub) draws it with the built-in bitmap font into
     * both display frame buffers (16-bit pixels, rows of 0x200 bytes; the DMA sends up to 0x190 rows) and sends one */
    for (int b = 0; b < 2; b++) {
        const uint32_t a = b ? 0x03000000u : 0x02000000u;
        for (uint32_t i = 0; i < 0x32000; i += 4) *(volatile uint32_t *)(a + i) = 0;
        FLUSH_RANGE(a, a + 0x32000, 0);
    }
    kn_crash_regs r;
    __asm__ volatile ("%0 = SP; %1 = SEQSTAT; %2 = RETI;" : "=d"(r.sp), "=d"(r.seq), "=d"(r.reti));
    r.ipend = *(const volatile uint32_t *)0xFFE02108;
    r.icplb = *(const volatile uint32_t *)0xFFE0100C;
    char ver[44];
    kn_crash_version(ver, sizeof ver, (const char *)0x01EF0000, (const char *)0x018F7358);
    kn_crash_text(CRASH_TXT, 512, msg, ver, &r, rd_mem, kn_images);
}

/* ---- after the screen: wait for a key, then restart (no interrupts run here: the keys are read by polled TWI) ----
 * The key expanders (MCP23017 at TWI 0x22..0x26) as R246 sets them up (bank 0, no address increment): GPIOA 0x12,
 * GPIOB 0x13, one byte per read. A bit going 1 -> 0 (a key pressed; active low) restarts through the watchdog as
 * R246 reboots (0x01A88794); the key held at the crash must be let go first. The hang detector's long count
 * (kn_wd_crash) stays the fallback. op1r-src 8bf2f84 crash_wait, unchanged. */
#define TWI(o)        (*(volatile uint16_t *)(0xFFC01400u + (o)))
#define TWI_MCTL      0x14
#define TWI_MADDR     0x1C
#define TWI_ISTAT     0x20
#define TWI_IMASK     0x24
#define TWI_FIFOCTL   0x28
#define TWI_XMT       0x80
#define TWI_RCV       0x88
#define TWI_MCOMP     0x10
#define TWI_MERR      0x20
static int twi_wait(void)                                    /* 1 done, 0 error / timeout */
{
    for (int i = 0; i < 400000; i++) {
        const uint16_t st = TWI(TWI_ISTAT);
        if (st & TWI_MERR) { TWI(TWI_ISTAT) = 0xFF; return 0; }
        if (st & TWI_MCOMP) { TWI(TWI_ISTAT) = 0xFF; return 1; }
    }
    return 0;
}
static int twi_reg(int dev, int reg)                         /* one register byte, -1 if the transfer failed */
{
    TWI(TWI_MCTL) = 0; TWI(TWI_FIFOCTL) = 3; TWI(TWI_FIFOCTL) = 0; TWI(TWI_ISTAT) = 0xFF;
    TWI(TWI_MADDR) = (uint16_t)dev;
    TWI(TWI_XMT) = (uint16_t)reg;
    TWI(TWI_MCTL) = (1u << 6) | 1u;                          /* 1 byte, transmit, master on */
    if (!twi_wait()) return -1;
    TWI(TWI_MCTL) = (1u << 6) | 4u | 1u;                     /* 1 byte, receive */
    if (!twi_wait()) return -1;
    return TWI(TWI_RCV) & 0xFF;
}
/* only the key pins: 0x22 the encoder pushes (B 4..7; its other pins are the encoders' quadrature), 0x23..0x25 all,
 * 0x26 A 0..5 */
static const uint8_t key_mask[10] = { 0x00, 0xF0, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x3F, 0x00 };
static void keys_read(uint8_t *k, uint8_t *ok)
{
    for (int d = 0; d < 5; d++)
        for (int r = 0; r < 2; r++) {
            const int i = d * 2 + r;
            if (!key_mask[i]) { k[i] = 0xFF; ok[i] = 1; continue; }
            const int v = twi_reg(0x22 + d, 0x12 + r);
            ok[i] = v >= 0; k[i] = (uint8_t)(v < 0 ? 0xFF : v);
        }
}
void kn_crash_wait(void)
{
    TWI(TWI_IMASK) = 0;                                       /* polled (the TWI ISR cannot run anyway) */
    uint8_t k[10], ok[10];
    int idle = 0, seen = 0;                                   /* armed after 2 scans with no key down, then a press
                                                               * read twice in a row restarts */
    for (;;) {
        keys_read(k, ok);
        int down = 0, good = 0;
        for (int i = 0; i < 10; i++) if (ok[i]) { good++; down |= ~k[i] & key_mask[i]; }
        if (good < 8) { seen = 0; continue; }
        if (idle < 2) { idle = down ? 0 : idle + 1; continue; }
        seen = down ? seen + 1 : 0;
        if (seen >= 2) break;
    }
    *(volatile uint16_t *)0xFFC00200 = 0x0AD0;                /* watchdog: reset event, at once (as R246's reboot) */
    *(volatile uint32_t *)0xFFC00204 = 0x100;
    *(volatile uint32_t *)0xFFC00208 = 0;
    *(volatile uint16_t *)0xFFC00200 = 0x0FF0;
    for (;;) __asm__ volatile ("IDLE;");
}
#endif
