/*
 * Saved presets (op1_feature.h op1_preset_*): overwrite, rename and delete user presets (synth presets and drum
 * kits), for the naming feature. docs/feature-hooks.md "Preset tools", ARCHITECTURE.md "Preset tools".
 *
 * R246 (docs/ports/presets-design.md in the full project, section 1): a user preset is a row (id, patch JSON, folder) of
 * synth_user / drum_user in op1.db plus /yaffs2/user/audio/preset_<synth|drum>/<folder>/<name>.raw (the sample of a
 * sampler preset or sampled kit, 0 bytes otherwise). The patch table (synth: the builder may relocate it, its base is
 * read from the type job's immediates as sp_core.c does; drum 0x01DE20F8) holds factory entries, then the user rows in
 * rowid order: entry +4 Json::Value, +0x14 folder (std::string), +0x30 factory byte. It has no row id; a preset is
 * found by folder + the JSON name (as its file path). R246 reloads the table after a save (0x01A0567C synth,
 * 0x01A04FE8 drum); so do we. R246 does not keep which preset a slot came from: we record it at every preset load
 * (the job wrappers in kn_drum_synth.c, sp_core.c, kn_drum.c) and stock save (kn_save.c), saved in op1rsettings
 * ("presets.src<kind><slot>"); without a record, R246's own rule (0x01A02030: the first entry with the slot's name and
 * type) is used.
 *
 * The sound preset browser is R246's list picker (mode 8). Its list (0x01DE511C) is a static tree rebuilt by the
 * builder (synth 0x01A02790, list 0x01DDD688; drum 0x01A028EC, list 0x01DDD698): root +4/+8 folders (0x30 each:
 * name std::string +0, id +0x1C, children +0x24/+0x28), children 0x20 each (name +0, id +0x1C = table index). The
 * selection is folder = [0x01DE5138] / [0x01DE5134], entry = [0x01DE5158] / [0x01DE5154]; 0x01A172D4(id, flag)
 * moves it (preset_browser_open's own step). The browser screen reads the tree only when its dirty byte 0x018B6300
 * is set. After a rename or delete the tree is rebuilt on the KeyHandler thread (where stock builds it), through the
 * private key event 0x3F / 0xA7 (as kn_midi.c's 0x3F / 0xA5), when the screen has nothing pending.
 *
 * Files: R246's YAFFS has no rename (yaffs_rename was not linked), so a rename or move is copy, then the row, then
 * unlink: the database statement is the commit point (one statement, atomic). A crash before it leaves an extra
 * file; after it, at most the old file. An overwrite of a sampler preset copies the slot's sample to <name>.raw.new
 * first, then updates the row, then copies it over <name>.raw and removes the .new; a sample that did not change is
 * not written at all. Never touched: user/audio/synth/synth_N.raw, drum_N.raw (the slots' samples), content/.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* the firmware has no memcpy / memset */
#include "../op1_synth.h"
#include "../op1_feature.h"

#define TXT OP1_PRESET_TEXT
#define PATCH_MAX 8192                                   /* R246 formats slot rows into 0x1388 / 0x2000 bytes */
#define SQL_MAX (2 * PATCH_MAX + 256)
#define KEEP_DELETED 16
#define CLOCK_START 320                                  /* the stock clock is drawn from 320 down to 0 */
#define REFRESH_KEY 0x3F
#define REFRESH_STATE 0xA7                               /* kn_mx.c uses 0xA5, the trigger guard 0xA6; R246 pushes 0x3F with state 1 */

typedef int (*row_cb)(void *, int, char **, char **);

#ifdef OP1_HOST                                          /* harness/fake_r246.c */
int host_tab_n(int kind), host_tab_factory(int kind, int i);
const char *host_tab_str(int kind, int i, const char *key);        /* "name", "type", "folder" */
const char *host_slot_str(int kind, int slot, const char *key);
int host_slot_text(int kind, int slot, char *out, int size);       /* the live patch as JSON text, its length */
int host_db_exec(const char *sql, row_cb cb, void *arg);
void host_table_reload(int kind);
int host_br_kind(void), host_br_sel(int *f, int *e), host_br_dirty(void);
int host_br_nf(void), host_br_ne(int f);
const char *host_br_folder(int f);
const char *host_br_leaf(int f, int e, int *id);
void host_br_rebuild(int kind), host_br_select(int id);
extern int host_clock_visible, host_clock_state, host_clock_slot, host_clock_synth, host_clock_count;
extern int host_mode_key[2], host_cur_slot[2];
extern char host_saved_name[2][256];
int host_y_open(const char *p, int flags, int mode), host_y_close(int fd), host_y_read(int fd, void *d, int n);
int host_y_write(int fd, const void *s, int n), host_y_unlink(const char *p), host_y_mkdir(const char *p, int mode);
int32_t host_y_lseek(int fd, int32_t off, int whence);
int host_access(const char *path);
void *host_opendir(const char *path);
void *host_readdir(void *dir);
void host_closedir(void *dir);
uint32_t host_free(void);
int host_bgs_drain(int ms);
int host_kq_push(int code, int state);
#define Y_OPEN    host_y_open
#define Y_CLOSE   host_y_close
#define Y_READ    host_y_read
#define Y_WRITE   host_y_write
#define Y_LSEEK   host_y_lseek
#define Y_UNLINK  host_y_unlink
#define Y_MKDIR   host_y_mkdir
#define ACCESS(p) host_access(p)
#define OPENDIR   host_opendir
#define READDIR(d) ((uint8_t *)host_readdir(d))
#define CLOSEDIR  host_closedir
#define FREE()    host_free()
#define DRAIN(ms) host_bgs_drain(ms)
#define KQ_PUSH(c, s) host_kq_push((c), (s))
#define MODE_KEY(k) host_mode_key[(k) & 1]
#define CUR_SLOT(k) host_cur_slot[(k) & 1]
#define SAVED_NAME(k) host_saved_name[(k) & 1]
#define FARBSS
#else
#include "../kn_mem.h"
#define FARBSS kn_farbss
#define Y_OPEN    ((int (*)(const char *, int, int))0x01A997F4)
#define Y_CLOSE   ((int (*)(int))0x01A99908)
#define Y_READ    ((int (*)(int, void *, int))0x01A99C90)
#define Y_WRITE   ((int (*)(int, const void *, int))0x01A99F84)
#define Y_LSEEK   ((int32_t (*)(int, int32_t, int))0x01A9A0E4)
#define Y_UNLINK  ((int (*)(const char *))0x01A9A3FC)
#define Y_MKDIR   ((int (*)(const char *, int))0x01A9A886)
#define ACCESS(p) (((int (*)(const char *, int))0x01A9A6B0)((p), 0))    /* yaffs_access: 0 = exists */
#define OPENDIR(p)   (((void *(*)(const char *))0x01A9B450)(p))
#define READDIR(d)   (((uint8_t *(*)(void *))0x01A9B648)(d))
#define CLOSEDIR(d)  (((int (*)(void *))0x01A9B74C)(d))
#define FREE()    ((uint32_t)((int (*)(const char *))0x01A9B1C0)("/yaffs2"))
int bgs_drain(int ms);                                   /* bgsave.c */
int kn_kq_push(int code, int down);                      /* kn_midi.c */
#define DRAIN(ms) bgs_drain(ms)
#define KQ_PUSH(c, s) kn_kq_push((c), (s))
#define MODE_KEY(k) (*(volatile int32_t *)((k) ? 0x01AAD4A4 : 0x01AAD4A0))   /* drum / synth key held */
#define CUR_SLOT(k) (*(volatile int32_t *)((k) ? 0xFF8016D8 : 0xFF8016D4) & 7)
#define SAVED_NAME(k) ((const char *)((k) ? 0x01AAD178 : 0x01AACE78))   /* the stock save's final name (with _N) */
#define CUR_MODE_ID (*(volatile int32_t *)0xFF907D58)
#define BR_ROOT     (*(uint8_t *volatile *)0x01DE511C)
#define BR_LIST(k)  ((uint8_t *)((k) ? 0x01DDD698 : 0x01DDD688))
void *kn_pl_build(int k);                                 /* preset-storage: the builder, one sort per folder */
#define BR_BUILD(k) kn_pl_build(k)
#define BR_SELECT   ((void (*)(int, int))0x01A172D4)
#define BR_FLAG     (*(volatile uint8_t *)0x01DE5120)
#define BR_DIRTY    (*(volatile uint8_t *)0x018B6300)
#define CLOCK_SHOW  ((void (*)(int, int, int))0x01A3AAA0)  /* (slot, count, is_synth) */
#define CLOCK_HIDE  ((void (*)(void))0x01A3AA58)
#define CLOCK_DONE  ((void (*)(void))0x01A3AA84)
#define CLOCK_FAIL  ((void (*)(void))0x01A3AA68)
#define CLOCK_VIS   (*(volatile uint8_t *)0x01DF4D98)
#define CLOCK_STATE (*(volatile int32_t *)0x01DF4D9C)
#define CLOCK_SYNTH (*(volatile uint8_t *)0x01DF4DA0)
#define CLOCK_SLOT  (*(volatile int32_t *)0x01DF4DA4)
#define RELOAD(k)   (((void (*)(void))((k) ? 0x01A04FE8 : 0x01A0567C))())
#define JV_CGET     ((const void *(*)(const void *, const char *))0x019BEB70)
#define WRITE_PATCH ((void (*)(void *, void *))0x019FF604)  /* (patch object, std::string out), as the slot save job */
#define OP_DELETE   ((void (*)(void *))0x01A5E310)
#define DB_HANDLE   ((void *(*)(void))0x0196DD44)
#define SQL_EXEC    ((int (*)(void *, const char *, row_cb, void *, char **))0x019C9460)   /* sqlite3_exec */
typedef struct { uint32_t alloc; union { char buf[16]; char *ptr; } u; uint32_t size, cap; } st_str;   /* 0x1C */
#endif

/* ---------------- small text helpers ---------------- */
static int slen(const char *s) { int n = 0; while (s && s[n]) n++; return n; }
static int seq(const char *a, const char *b)
{
    if (!a || !b) return 0;
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}
static void scpy(char *d, const char *s, int size)
{
    int i = 0;
    for (; s && s[i] && i < size - 1; i++) d[i] = s[i];
    d[i] = 0;
}
static char *cat(char *o, const char *e, const char *s) { while (*s && o < e - 1) *o++ = *s++; *o = 0; return o; }   /* e: one past the buffer */
static char *cat_u(char *o, const char *e, uint32_t n)
{
    char d[10]; int k = 0;
    do d[k++] = (char)('0' + n % 10); while (n /= 10);
    while (k && o < e - 1) *o++ = d[--k];
    *o = 0;
    return o;
}
static char *cat_q(char *o, const char *e, const char *s)   /* SQL text: ' doubled */
{
    for (; *s && o < e - 2; s++) { if (*s == '\'') *o++ = '\''; *o++ = *s; }
    *o = 0;
    return o;
}
/* a folder or file name we accept in a path: no '/', not "." or "..", printable, not too long */
static int part_ok(const char *s)
{
    int n = slen(s);
    if (!n || n >= TXT || (n == 1 && s[0] == '.') || (n == 2 && s[0] == '.' && s[1] == '.')) return 0;
    for (int i = 0; i < n; i++) if (s[i] == '/' || s[i] == '\\' || (uint8_t)s[i] < 0x20 || s[i] == '\'') return 0;
    return 1;
}
static int name_char(char c) { return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == ' ' || c == '_' || c == '-'; }
static int new_name_ok(const char *s)
{
    int n = slen(s);
    if (!n || n > OP1_PRESET_NAME_MAX || s[0] == ' ' || s[n - 1] == ' ') return 0;
    for (int i = 0; i < n; i++) if (!name_char(s[i])) return 0;
    return 1;
}

/* ---------------- JSON text: the top-level string member `key` ---------------- */
static int ws(char c) { return c == ' ' || c == '\t' || c == '\r' || c == '\n'; }
static int str_end(const char *t, int i)                 /* t[i] == '"': index of the closing quote, -1 */
{
    for (i++; t[i]; i++) {
        if (t[i] == '\\') { if (!t[++i]) return -1; continue; }
        if (t[i] == '"') return i;
    }
    return -1;
}
/* the value's quotes: *a = index of its opening quote, *b = its closing quote; 0 found */
static int json_member(const char *t, const char *key, int *a, int *b)
{
    int depth = 0, klen = slen(key);
    for (int i = 0; t[i]; i++) {
        char c = t[i];
        if (c == '{' || c == '[') depth++;
        else if (c == '}' || c == ']') depth--;
        else if (c == '"') {
            int e = str_end(t, i);
            if (e < 0) return -1;
            int j = e + 1;
            while (ws(t[j])) j++;
            if (depth == 1 && t[j] == ':' && e - i - 1 == klen) {
                int m = 0;
                while (m < klen && t[i + 1 + m] == key[m]) m++;
                if (m == klen) {
                    j++;
                    while (ws(t[j])) j++;
                    if (t[j] != '"') return -1;
                    int f = str_end(t, j);
                    if (f < 0) return -1;
                    *a = j; *b = f;
                    return 0;
                }
            }
            i = e;
        }
    }
    return -1;
}
static int json_str(const char *t, const char *key, char *out, int size)   /* unescaped; 0 found */
{
    int a, b, n = 0;
    if (json_member(t, key, &a, &b)) return -1;
    for (int i = a + 1; i < b && n < size - 1; i++) {
        char c = t[i];
        if (c == '\\') {
            c = t[++i];
            if (c == 'u') { i += 4; c = '?'; }
            else if (c == 'n') c = '\n';
            else if (c == 't') c = '\t';
        }
        out[n++] = c;
    }
    out[n] = 0;
    return 0;
}
/* t with the member's value replaced by `name` into out; its length, -1 */
static int json_rename(const char *t, const char *name, char *out, int size)
{
    int a, b;
    if (json_member(t, "name", &a, &b)) return -1;
    int n = 0, tl = slen(t), nl = slen(name);
    if (a + 1 + nl + (tl - b) >= size) return -1;
    for (int i = 0; i <= a; i++) out[n++] = t[i];
    for (int i = 0; i < nl; i++) out[n++] = name[i];
    for (int i = b; i < tl; i++) out[n++] = t[i];
    out[n] = 0;
    return n;
}

/* ---------------- R246: patch tables, slots, database ---------------- */
#ifdef OP1_HOST
static int tab_n(int k) { return host_tab_n(k); }
static int tab_factory(int k, int i) { return host_tab_factory(k, i); }
static int tab_str(int k, int i, const char *key, char *out, int size)
{
    const char *s = host_tab_str(k, i, key);
    if (!s) return -1;
    scpy(out, s, size);
    return 0;
}
static int slot_str(int k, int s, const char *key, char *out, int size)
{
    const char *v = host_slot_str(k, s, key);
    if (!v) return -1;
    scpy(out, v, size);
    return 0;
}
static int slot_text(int k, int s, char *out, int size) { return host_slot_text(k, s, out, size); }
static int db_run(const char *sql, row_cb cb, void *arg) { return host_db_exec(sql, cb, arg); }
static void table_reload(int k) { host_table_reload(k); }
#else
static const uint8_t *tab_entry(int k, int i)
{
    if (k) {
        int n = *(const volatile int32_t *)0x018B6118;
        extern uint8_t *kn_pl_drum_table(void);         /* preset-storage: the 448-entry table (kn_preset_store.c) */
        return i >= 0 && i < n && n <= 448 ? kn_pl_drum_table() + i * 0x38 : 0;
    }
    const uint8_t *json = op1_sampler_preset(i);          /* sp_core.c: the (relocated) synth table, entry + 4 */
    return json ? json - 4 : 0;
}
static int tab_n(int k) { return k ? *(const volatile int32_t *)0x018B6118 : op1_sampler_preset_count(); }
static int tab_factory(int k, int i) { const uint8_t *e = tab_entry(k, i); return e && e[0x30]; }
static const char *st_c(const void *p) { const st_str *s = p; return s->cap > 15 ? s->u.ptr : s->u.buf; }
static int jv_get(const void *json, const char *key, char *out, int size)
{
    const void *v = json ? JV_CGET(json, key) : 0;
    if (!v || ((const uint8_t *)v)[8] != 4 || !*(const char *const *)v) return -1;   /* stringValue */
    scpy(out, *(const char *const *)v, size);
    return 0;
}
static int tab_str(int k, int i, const char *key, char *out, int size)
{
    const uint8_t *e = tab_entry(k, i);
    if (!e) return -1;
    if (key[0] == 'f') { const st_str *s = (const st_str *)(e + 0x14); if (s->size >= TXT) return -1; scpy(out, st_c(s), size); return 0; }
    return jv_get(e + 4, key, out, size);
}
static uint8_t *slot_obj(int k, int s) { return (uint8_t *)(k ? 0x01DDD9A8 : 0x01DDD7E8) + (s & 7) * 0x38; }
static int slot_str(int k, int s, const char *key, char *out, int size) { return jv_get(slot_obj(k, s) + 4, key, out, size); }
static int slot_text(int k, int s, char *out, int size)
{
    st_str str;
    WRITE_PATCH(slot_obj(k, s), &str);                   /* constructs str (the job passes raw stack) */
    int n = (int)str.size;
    const char *p = st_c(&str);
    if (n >= size) n = -1;
    else { for (int i = 0; i < n; i++) out[i] = p[i]; out[n] = 0; }
    if (str.cap > 15 && str.u.ptr) OP_DELETE(str.u.ptr);
    return n;
}
static int db_run(const char *sql, row_cb cb, void *arg)  /* sqlite3_exec on op1.db under db2's statement lock */
{
    void *h = DB_HANDLE();
    void *sem = *(void *volatile *)0x01BAB718;
    if (sem) ((void (*)(void *, int))0xFFA0B6E8)(sem, 0);
    int rc = SQL_EXEC(*(void **)h, sql, cb, arg, 0);
    if (sem) ((void (*)(void *))0xFFA0B96C)(sem);
    if (rc) op1_db_last_err = rc;
    return rc;
}
static void table_reload(int k) { RELOAD(k); }
#endif

static const char *const TABLE[2] = { "synth_user", "drum_user" };
static const char *const KIND_DIR[2] = { "/yaffs2/user/audio/preset_synth/", "/yaffs2/user/audio/preset_drum/" };
static const char *const SAMPLED[2] = { "sampler", "drum" };   /* the type whose .raw is the preset's sample */

static char patch[PATCH_MAX] FARBSS, patch2[PATCH_MAX] FARBSS, sql[SQL_MAX] FARBSS;

/* the row of folder/name: id, its patch into `patch`; matches = how many rows have that name */
typedef struct { const char *name; int32_t id; int matches; int too_long; int32_t *ids; int max; } find_t;   /* ids: every match (USB) */
static int find_cb(void *arg, int n, char **v, char **col)
{
    (void)col;
    find_t *f = arg;
    char nm[TXT];
    if (n < 2 || !v[0] || !v[1] || json_str(v[1], "name", nm, sizeof nm) || !seq(nm, f->name)) return 0;
    int32_t id = 0;
    for (const char *p = v[0]; *p >= '0' && *p <= '9'; p++) id = id * 10 + (*p - '0');
    if (f->ids && f->matches < f->max) f->ids[f->matches] = id;
    if (++f->matches == 1) {
        f->id = id;
        int l = slen(v[1]);
        if (l >= PATCH_MAX) f->too_long = 1;
        else scpy(patch, v[1], PATCH_MAX);
    }
    return 0;
}
static int32_t row_find(int kind, const char *folder, const char *name)   /* the row id, -1 none / unclear */
{
    if (!part_ok(folder) || !part_ok(name)) return -1;
    char *o = cat(sql, sql + SQL_MAX, "SELECT id,patch FROM ");
    o = cat(o, sql + SQL_MAX, TABLE[kind & 1]);
    o = cat(o, sql + SQL_MAX, " WHERE ifnull(folder,'')='");
    o = cat_q(o, sql + SQL_MAX, folder);
    cat(o, sql + SQL_MAX, "'");
    find_t f = { name, -1, 0, 0, 0, 0 };
    if (db_run(sql, find_cb, &f) || f.matches != 1 || f.too_long) return -1;
    return f.id;
}
static int row_exec(const char *s) { return db_run(s, 0, 0); }

/* ---------------- files ---------------- */
static char *path(char *o, int kind, const char *folder, const char *name, const char *ext)
{
    char *e = o + 160;
    char *p = cat(o, e, KIND_DIR[kind & 1]);
    p = cat(p, e, folder);
    p = cat(p, e, "/");
    p = cat(p, e, name);
    cat(p, e, ext);
    return o;
}
static uint8_t cbuf[2][2048];
static int32_t fsize(const char *p)
{
    int fd = Y_OPEN(p, 0, 0);
    if (fd < 0) return -1;
    int32_t n = Y_LSEEK(fd, 0, 2);
    Y_CLOSE(fd);
    return n;
}
static int fcopy(const char *from, const char *to)       /* 0 done; the target is created or truncated */
{
    int a = Y_OPEN(from, 0, 0);
    if (a < 0) return -1;
    int b = Y_OPEN(to, 0x241, 0x180);
    if (b < 0) { Y_CLOSE(a); return -1; }
    int rc = 0;
    for (;;) {
        int n = Y_READ(a, cbuf[0], sizeof cbuf[0]);
        if (n < 0) { rc = -1; break; }
        if (!n) break;
        if (Y_WRITE(b, cbuf[0], n) != n) { rc = -1; break; }
    }
    Y_CLOSE(a);
    if (Y_CLOSE(b)) rc = -1;
    if (rc) Y_UNLINK(to);
    return rc;
}
static int fsame(const char *p1, const char *p2)         /* 1 when both exist with the same bytes */
{
    int32_t n = fsize(p1);
    if (n < 0 || n != fsize(p2)) return 0;
    int a = Y_OPEN(p1, 0, 0), b = Y_OPEN(p2, 0, 0), same = a >= 0 && b >= 0;
    while (same) {
        int x = Y_READ(a, cbuf[0], sizeof cbuf[0]), y = Y_READ(b, cbuf[1], sizeof cbuf[1]);
        if (x != y || x < 0) { same = 0; break; }
        if (!x) break;
        for (int i = 0; i < x; i++) if (cbuf[0][i] != cbuf[1][i]) { same = 0; break; }
    }
    if (a >= 0) Y_CLOSE(a);
    if (b >= 0) Y_CLOSE(b);
    return same;
}
static int fspace(int32_t need) { return need < 0 || FREE() >= (uint32_t)need + (1u << 20); }

/* ---------------- the source of each slot ---------------- */
typedef struct { uint8_t valid, user; char folder[TXT], name[TXT]; } src_t;
static src_t src[2][8];
static volatile uint16_t src_dirty;                      /* bit kind * 8 + slot: to save */
static uint8_t src_loaded;

static void src_set(int kind, int slot, int user, const char *folder, const char *name)
{
    src_t *s = &src[kind & 1][slot & 7];
    s->valid = 0;
    s->user = (uint8_t)(user != 0);
    scpy(s->folder, folder, TXT);
    scpy(s->name, name, TXT);
    s->valid = 1;
    src_dirty |= (uint16_t)(1u << ((kind & 1) * 8 + (slot & 7)));
}
/* a preset was loaded into a slot from table entry `index` (BgFileWorker, after the stock job) */
void kn_presets_loaded(int kind, int slot, int index)
{
    char f[TXT] = "", n[TXT];
    if (index < 0 || tab_str(kind, index, "name", n, TXT)) return;
    int user = !tab_factory(kind, index);
    if (user && tab_str(kind, index, "folder", f, TXT)) return;
    src_set(kind, slot, user, f, n);
}
/* R246's hold-to-save has just saved a slot (kn_save.c, main loop): its source is the new preset */
void kn_presets_saved(int kind, int slot)
{
    char n[TXT];
    scpy(n, SAVED_NAME(kind), TXT);
    if (n[0]) src_set(kind, slot, 1, "snapshot", n);
}
static void src_key(char *k, int kind, int slot) { k[0] = 's'; k[1] = 'r'; k[2] = 'c'; k[3] = (char)('0' + kind); k[4] = (char)('0' + slot); k[5] = 0; }
static void src_load(void)                               /* main loop, once: "u:folder:name" / "f:name" */
{
    src_loaded = 1;
    for (int k = 0; k < 2; k++)
        for (int s = 0; s < 8; s++) {
            char key[8], v[2 * TXT + 4];
            src_key(key, k, s);
            if (src[k][s].valid || op1_setting_get_str("presets", key, v, sizeof v) <= 2 || v[1] != ':') continue;
            src_t *d = &src[k][s];
            const char *p = v + 2;
            if (v[0] == 'u') {
                int i = 0;
                while (p[i] && p[i] != ':') i++;
                if (!p[i] || i >= TXT) continue;
                for (int j = 0; j < i; j++) d->folder[j] = p[j];
                d->folder[i] = 0;
                scpy(d->name, p + i + 1, TXT);
                d->user = 1;
            } else { d->folder[0] = 0; scpy(d->name, p, TXT); d->user = 0; }
            d->valid = 1;
        }
}
static void src_save(void)                               /* main loop: the changed records */
{
    uint16_t d = src_dirty;
    if (!d) return;
    src_dirty = 0;
    for (int b = 0; b < 16; b++) {
        if (!(d >> b & 1)) continue;
        src_t *s = &src[b >> 3][b & 7];
        char key[8], v[2 * TXT + 4], *o = v, *e = v + sizeof v - 1;
        src_key(key, b >> 3, b & 7);
        o = cat(o, e, s->user ? "u:" : "f:");
        if (s->user) { o = cat(o, e, s->folder); o = cat(o, e, ":"); }
        cat(o, e, s->name);
        op1_setting_set_str("presets", key, v);         /* refused (kept in memory only) for other characters */
    }
}
/* every record of folder/name: renamed (to != 0) or forgotten */
static void src_follow(int kind, const char *folder, const char *name, const char *to)
{
    for (int s = 0; s < 8; s++) {
        src_t *r = &src[kind & 1][s];
        if (!r->valid || !r->user || !seq(r->folder, folder) || !seq(r->name, name)) continue;
        if (to) src_set(kind, s, 1, folder, to);
        else { r->valid = 0; src_set(kind, s, 0, "", ""); }
    }
}

int op1_preset_source(int kind, int slot, op1_preset_ref *out)
{
    if (kind < 0 || kind > 1 || slot < 0 || slot > 7 || !out) return -1;
    out->kind = (uint8_t)kind; out->next_folder[0] = out->next_name[0] = 0;
    const src_t *s = &src[kind][slot];
    if (s->valid && s->name[0]) {
        out->user = s->user;
        scpy(out->folder, s->folder, TXT); scpy(out->name, s->name, TXT);
        return s->user;
    }
    if (s->valid) return -1;                             /* recorded: unknown (its preset was deleted) */
    char n[TXT], t[16], tn[TXT], tt[16];                 /* no record: R246's rule (0x01A02030) */
    if (slot_str(kind, slot, "name", n, TXT) || slot_str(kind, slot, "type", t, sizeof t)) return -1;
    int count = tab_n(kind);
    for (int i = 0; i < count; i++) {
        if (tab_str(kind, i, "name", tn, TXT) || !seq(tn, n) || tab_str(kind, i, "type", tt, sizeof tt) || !seq(tt, t)) continue;
        out->user = (uint8_t)!tab_factory(kind, i);
        out->folder[0] = 0;
        if (out->user && tab_str(kind, i, "folder", out->folder, TXT)) return -1;
        scpy(out->name, n, TXT);
        return out->user;
    }
    return -1;
}

/* ---------------- the browser (KeyHandler) ---------------- */
#ifdef OP1_HOST
static int br_kind(void) { return host_br_kind(); }
static int br_sel(int *f, int *e) { return host_br_sel(f, e); }
static int br_nf(void) { return host_br_nf(); }
static int br_ne(int f) { return host_br_ne(f); }
static const char *br_folder(int f) { return host_br_folder(f); }
static const char *br_leaf(int f, int e, int *id) { return host_br_leaf(f, e, id); }
static int br_dirty(void) { return host_br_dirty(); }
static void br_rebuild(int kind) { host_br_rebuild(kind); }
static void br_select(int id) { host_br_select(id); }
#else
static int ptr_ok(const void *p) { return (uintptr_t)p >= 0x1000 && (uintptr_t)p < 0x08000000 && !((uintptr_t)p & 3); }
static int br_kind(void)
{
    if (CUR_MODE_ID != 8) return -1;
    uint8_t *r = BR_ROOT;
    return r == BR_LIST(0) ? 0 : r == BR_LIST(1) ? 1 : -1;
}
static int vec_n(const uint8_t *v, int stride, int max)   /* begin at +0, end at +4 */
{
    const uint8_t *b = *(uint8_t *const *)v, *e = *(uint8_t *const *)(v + 4);
    if (b == e) return 0;
    if (!ptr_ok(b) || e < b || (e - b) % stride || (e - b) / stride > max) return -1;
    return (int)((e - b) / stride);
}
static const uint8_t *br_fnode(int f)
{
    const uint8_t *r = BR_ROOT;
    int n = vec_n(r + 4, 0x30, 512);
    return f >= 0 && f < n ? *(uint8_t *const *)(r + 4) + f * 0x30 : 0;
}
static int br_nf(void) { return vec_n(BR_ROOT + 4, 0x30, 512); }
static int br_ne(int f) { const uint8_t *n = br_fnode(f); return n ? vec_n(n + 0x24, 0x20, 2048) : -1; }
static const char *st_text(const uint8_t *s)
{
    const st_str *t = (const st_str *)s;
    if (t->size >= TXT || t->size > t->cap) return 0;
    const char *p = st_c(t);
    return t->cap > 15 && !ptr_ok((const void *)((uintptr_t)p & ~3u)) ? 0 : p;
}
static const char *br_folder(int f) { const uint8_t *n = br_fnode(f); return n ? st_text(n) : 0; }
static const char *br_leaf(int f, int e, int *id)
{
    const uint8_t *n = br_fnode(f);
    if (!n || e < 0 || e >= br_ne(f)) return 0;
    const uint8_t *l = *(uint8_t *const *)(n + 0x24) + e * 0x20;
    *id = *(const int32_t *)(l + 0x1C);
    return st_text(l);
}
static int br_sel(int *f, int *e)
{
    int32_t fs = *(volatile int32_t *)0x01DE5134, fv = *(volatile int32_t *)0x01DE5138;
    int32_t es = *(volatile int32_t *)0x01DE5154, ev = *(volatile int32_t *)0x01DE5158;
    if (fs <= 0 || es <= 0 || fv < 0 || ev < 0) return -1;
    *f = fv / fs; *e = ev / es;
    return 0;
}
static int br_dirty(void) { return BR_DIRTY != 0; }
static void br_rebuild(int kind) { BR_BUILD(kind); }
static void br_select(int id) { BR_SELECT(id, 1); BR_FLAG = 1; }   /* the entry column active: the next turn goes on from it */
#endif

int op1_preset_pick(op1_preset_ref *out)
{
    int kind = br_kind(), f, e, id;
    if (kind < 0 || !out || br_sel(&f, &e)) return -1;
    const char *fn = br_folder(f), *ln = br_leaf(f, e, &id);
    if (!fn || !ln || id < 0 || id >= tab_n(kind)) return -1;
    char tn[TXT];
    if (tab_str(kind, id, "name", tn, TXT) || !seq(tn, ln)) return -1;   /* the list and the table must agree */
    out->kind = (uint8_t)kind;
    out->user = (uint8_t)!tab_factory(kind, id);
    scpy(out->folder, fn, TXT);
    scpy(out->name, ln, TXT);
    out->next_folder[0] = out->next_name[0] = 0;
    int ne = br_ne(f), nf = br_nf(), nid;
    const char *nx = 0, *nfold = fn;
    if (e + 1 < ne) nx = br_leaf(f, e + 1, &nid);
    else if (e > 0) nx = br_leaf(f, e - 1, &nid);
    else if (f + 1 < nf) { nfold = br_folder(f + 1); nx = br_leaf(f + 1, 0, &nid); }
    else if (f > 0) { nfold = br_folder(f - 1); nx = br_leaf(f - 1, 0, &nid); }
    if (nx && nfold) { scpy(out->next_folder, nfold, TXT); scpy(out->next_name, nx, TXT); }
    return out->user;
}

/* rebuild on the KeyHandler thread, positioned on want_folder/want_name */
static volatile uint8_t refresh_kind = 0xFF, refresh_posted;
static char want_folder[TXT], want_name[TXT];
int kn_presets_key(int code, int pressed)                /* dispatcher.c key_event_hook: 1 = our event */
{
    if (code != REFRESH_KEY || pressed != REFRESH_STATE) return 0;
    refresh_posted = 0;
    int kind = refresh_kind;
    if (kind > 1) return 1;
    if (br_kind() != kind) { refresh_kind = 0xFF; return 1; }   /* the browser was closed meanwhile */
    if (br_dirty()) return 1;                            /* the screen still reads the list: next main loop pass */
    refresh_kind = 0xFF;
    br_rebuild(kind);
    int nf = br_nf(), id = -1, first = -1;
    for (int f = 0; f < nf && id < 0; f++) {
        const char *fn = br_folder(f);
        int ne = br_ne(f);
        for (int e = 0; e < ne; e++) {
            int lid;
            const char *ln = br_leaf(f, e, &lid);
            if (first < 0 && ln) first = lid;
            if (ln && seq(fn, want_folder) && seq(ln, want_name)) { id = lid; break; }
        }
    }
    br_select(id >= 0 ? id : first);
    return 1;
}

/* ---------------- the save clock ---------------- */
int op1_mode_key_held(int kind) { return kind >= 0 && kind <= 1 && MODE_KEY(kind) != 0; }
int op1_save_clock(int *kind, int *slot)
{
#ifdef OP1_HOST
    if (!host_clock_visible || host_clock_state) return 0;
    if (kind) *kind = !host_clock_synth;
    if (slot) *slot = host_clock_slot & 7;
#else
    if (!CLOCK_VIS || CLOCK_STATE) return 0;
    if (kind) *kind = !CLOCK_SYNTH;
    if (slot) *slot = CLOCK_SLOT & 7;
#endif
    return 1;
}
void op1_save_clock_show(int kind, int slot, int count)
{
    if (slot < 0) slot = CUR_SLOT(kind);
#ifdef OP1_HOST
    if (count >= 0) { host_clock_visible = 1; host_clock_state = 0; host_clock_slot = slot; host_clock_synth = !kind; host_clock_count = count; }
    else { host_clock_visible = 0; host_clock_state = count == -2 ? 1 : count == -3 ? 2 : 0; }
#else
    if (count >= 0) CLOCK_SHOW(slot, count > CLOCK_START ? CLOCK_START : count, kind == 0);
    else if (count == -2) CLOCK_DONE();
    else if (count == -3) CLOCK_FAIL();
    else CLOCK_HIDE();
#endif
}

/* ---------------- the operations (main loop) ---------------- */
enum { PR_NONE, PR_OVERWRITE, PR_RENAME, PR_DELETE };
static struct {
    volatile uint8_t op;
    uint8_t kind, slot;
    int32_t row;
    char folder[TXT], name[TXT], to[TXT], next_folder[TXT], next_name[TXT];
} req;

static int is_sampled(int kind, const char *patch_text)
{
    char t[16];
    return !json_str(patch_text, "type", t, sizeof t) && seq(t, SAMPLED[kind & 1]);
}
static void refresh(int kind, const char *folder, const char *name)
{
    scpy(want_folder, folder, TXT);
    scpy(want_name, name, TXT);
    refresh_kind = (uint8_t)kind;
}

int op1_preset_overwrite(int kind, int slot)
{
    op1_preset_ref r;
    if (req.op || op1_preset_source(kind, slot, &r) != 1) return -1;
    int32_t row = row_find(kind, r.folder, r.name);
    if (row < 0) return -1;                              /* gone, or not one row: save as new instead */
    req.kind = (uint8_t)kind; req.slot = (uint8_t)slot; req.row = row;
    scpy(req.folder, r.folder, TXT); scpy(req.name, r.name, TXT);
    req.op = PR_OVERWRITE;
    return 0;
}
int op1_preset_rename(const op1_preset_ref *ref, const char *name)
{
    if (!ref || req.op || ref->kind > 1) return -1;
    if (!ref->user) { op1_toast("factory preset"); return -1; }
    if (!new_name_ok(name)) { op1_toast("name not allowed"); return -1; }
    req.kind = ref->kind; req.row = -1;
    scpy(req.folder, ref->folder, TXT); scpy(req.name, ref->name, TXT); scpy(req.to, name, TXT);
    req.op = PR_RENAME;
    return 0;
}
int op1_preset_delete(const op1_preset_ref *ref)
{
    if (!ref || req.op || ref->kind > 1) return -1;
    if (!ref->user) { op1_toast("factory preset"); return -1; }
    req.kind = ref->kind; req.row = -1;
    scpy(req.folder, ref->folder, TXT); scpy(req.name, ref->name, TXT);
    scpy(req.next_folder, ref->next_folder, TXT); scpy(req.next_name, ref->next_name, TXT);
    req.op = PR_DELETE;
    return 0;
}

static int update_row(int kind, int32_t row, const char *text)   /* UPDATE <table> SET patch='text' WHERE id=row */
{
    char *e = sql + SQL_MAX, *o = cat(sql, e, "UPDATE ");
    o = cat(o, e, TABLE[kind]);
    o = cat(o, e, " SET patch='");
    o = cat_q(o, e, text);
    o = cat(o, e, "' WHERE id=");
    o = cat_u(o, e, (uint32_t)row);
    if (o >= e - 1) return -1;
    return row_exec(sql);
}

static const char *do_overwrite(void)
{
    int kind = req.kind, slot = req.slot;
    char p[164], pn[168], sp[64];
    DRAIN(3000);                                         /* queued slot saves and preset loads first */
    if (row_find(kind, req.folder, req.name) != req.row) return "not saved";
    int n = slot_text(kind, slot, patch2, PATCH_MAX);
    if (n <= 0 || json_rename(patch2, req.name, patch, PATCH_MAX) < 0) return "not saved";
    path(p, kind, req.folder, req.name, ".raw");
    int sampled = is_sampled(kind, patch), staged = 0;
    if (sampled) {                                       /* the slot's sample: user/audio/<synth|drum>/<kind>_N.raw */
        char *o = cat(sp, sp + sizeof sp - 1, kind ? "/yaffs2/user/audio/drum/drum_" : "/yaffs2/user/audio/synth/synth_");
        o = cat_u(o, sp + sizeof sp - 1, (uint32_t)slot);
        cat(o, sp + sizeof sp - 1, ".raw");
        if (!fsame(sp, p)) {
            if (!fspace(fsize(sp))) return "storage full";
            scpy(pn, p, sizeof pn); cat(pn + slen(pn), pn + sizeof pn - 1, ".new");
            if (fcopy(sp, pn)) return "not saved";
            staged = 1;
        }
    }
    if (update_row(kind, req.row, patch)) { if (staged) Y_UNLINK(pn); return "not saved"; }
    if (staged && !fcopy(pn, p)) Y_UNLINK(pn);          /* a failed copy keeps <name>.raw.new */
    table_reload(kind);
    return 0;
}

static int32_t del_seq(void) { int32_t s = op1_setting_get("presets", "delseq", 0) + 1; op1_setting_set("presets", "delseq", s); return s; }
static uint32_t lead_num(const char *s, int *ok) { uint32_t v = 0; *ok = 0; while (*s >= '0' && *s <= '9') { v = v * 10 + (uint32_t)(*s++ - '0'); *ok = 1; } if (*s != '_') *ok = 0; return v; }
static void prune(int kind)                              /* .deleted keeps the newest KEEP_DELETED numbers */
{
    char dir[64], f[200];
    cat(cat(dir, dir + sizeof dir - 1, KIND_DIR[kind]), dir + sizeof dir - 1, ".deleted");
    for (int guard = 0; guard < 64; guard++) {
        void *d = OPENDIR(dir);
        if (!d) return;
        uint32_t lo = 0xFFFFFFFFu; int seen = 0, distinct = 0;
        uint32_t nums[64]; int nn = 0;
        for (uint8_t *de; (de = READDIR(d)) != 0;) {
            int ok; uint32_t v = lead_num((const char *)de + 11, &ok);
            if (!ok) continue;
            seen = 1;
            int dup = 0;
            for (int i = 0; i < nn; i++) if (nums[i] == v) dup = 1;
            if (!dup && nn < 64) nums[nn++] = v;
            if (v < lo) lo = v;
        }
        CLOSEDIR(d);
        distinct = nn;
        if (!seen || distinct <= KEEP_DELETED) return;
        d = OPENDIR(dir);                                /* remove the oldest number's files */
        if (!d) return;
        char victims[4][TXT + 12]; int nv = 0;
        for (uint8_t *de; (de = READDIR(d)) != 0;) {
            int ok; const char *nm = (const char *)de + 11;
            if (lead_num(nm, &ok) == lo && ok && nv < 4 && slen(nm) < TXT + 12) scpy(victims[nv++], nm, TXT + 12);
        }
        CLOSEDIR(d);
        if (!nv) return;
        for (int i = 0; i < nv; i++) {
            char *o = cat(f, f + sizeof f - 1, dir);
            o = cat(o, f + sizeof f - 1, "/");
            cat(o, f + sizeof f - 1, victims[i]);
            Y_UNLINK(f);
        }
    }
}

/* the one delete path (on the device and over USB): row `row` of folder/name, its JSON in `patch` (row_find) */
static const char *delete_row(int kind, const char *folder, const char *name, int32_t row)
{
    char p[164], dp[200], dir[64], stem[TXT + 12];
    path(p, kind, folder, name, ".raw");
    cat(cat(dir, dir + sizeof dir - 1, KIND_DIR[kind]), dir + sizeof dir - 1, ".deleted");
    Y_MKDIR(dir, 0);                                     /* -1 when it exists */
    char *o = cat_u(stem, stem + sizeof stem - 1, (uint32_t)del_seq());
    o = cat(o, stem + sizeof stem - 1, "_");
    cat(o, stem + sizeof stem - 1, name);
    if (ACCESS(p) == 0) {                                /* the preset's own file (never the slot's sample) */
        if (!fspace(fsize(p))) return "storage full";
        o = cat(cat(cat(dp, dp + sizeof dp - 1, dir), dp + sizeof dp - 1, "/"), dp + sizeof dp - 1, stem);
        cat(o, dp + sizeof dp - 1, ".raw");
        if (fcopy(p, dp)) return "not deleted";
    }
    o = cat(cat(cat(dp, dp + sizeof dp - 1, dir), dp + sizeof dp - 1, "/"), dp + sizeof dp - 1, stem);
    cat(o, dp + sizeof dp - 1, ".json");                 /* {"folder":"..","patch":{..}}: enough to bring it back */
    int fd = Y_OPEN(dp, 0x241, 0x180);
    if (fd >= 0) {
        char head[TXT + 24];
        char *h = cat(head, head + sizeof head - 1, "{\"folder\":\"");
        h = cat(h, head + sizeof head - 1, folder);
        cat(h, head + sizeof head - 1, "\",\"patch\":");
        Y_WRITE(fd, head, slen(head));
        Y_WRITE(fd, patch, slen(patch));
        Y_WRITE(fd, "}", 1);
        Y_CLOSE(fd);
    }
    char *e = sql + SQL_MAX;
    o = cat(sql, e, "DELETE FROM ");
    o = cat(o, e, TABLE[kind]);
    o = cat(o, e, " WHERE id=");
    cat_u(o, e, (uint32_t)row);
    if (row_exec(sql)) return "not deleted";
    Y_UNLINK(p);
    src_follow(kind, folder, name, 0);
    prune(kind);
    return 0;
}
static const char *do_delete(void)
{
    int kind = req.kind;
    int32_t row = row_find(kind, req.folder, req.name);
    if (row < 0) return "not deleted";
    const char *err = delete_row(kind, req.folder, req.name, row);
    if (err) return err;
    DRAIN(3000);
    table_reload(kind);
    refresh(kind, req.next_folder, req.next_name);
    return 0;
}

static const char *do_rename(void)
{
    int kind = req.kind;
    char from[164], to[164];
    if (seq(req.name, req.to)) return 0;
    int32_t row = row_find(kind, req.folder, req.name);
    if (row < 0) return "not renamed";
    path(from, kind, req.folder, req.name, ".raw");
    path(to, kind, req.folder, req.to, ".raw");
    if (ACCESS(to) == 0) return "name taken";
    {   /* another row of that name in the folder (its file may be missing) */
        char *o = cat(sql, sql + SQL_MAX, "SELECT id,patch FROM ");
        o = cat(o, sql + SQL_MAX, TABLE[kind]);
        o = cat(o, sql + SQL_MAX, " WHERE ifnull(folder,'')='");
        o = cat_q(o, sql + SQL_MAX, req.folder);
        cat(o, sql + SQL_MAX, "'");
        find_t f = { req.to, -1, 0, 0, 0, 0 };
        scpy(patch2, patch, PATCH_MAX);                  /* find_cb fills `patch` on a match */
        if (db_run(sql, find_cb, &f)) return "not renamed";
        scpy(patch, patch2, PATCH_MAX);
        if (f.matches) return "name taken";
    }
    if (json_rename(patch, req.to, patch2, PATCH_MAX) < 0) return "not renamed";
    int had = ACCESS(from) == 0;
    if (had) { if (!fspace(fsize(from))) return "storage full"; if (fcopy(from, to)) return "not renamed"; }   /* none: a disk-synced plain preset */
    if (update_row(kind, row, patch2)) { if (had) Y_UNLINK(to); return "not renamed"; }
    if (had) Y_UNLINK(from);
    src_follow(kind, req.folder, req.name, req.to);
    DRAIN(3000);
    table_reload(kind);
    refresh(kind, req.folder, req.to);
    return 0;
}

void kn_presets_service(void)                            /* kn_core.c kn_core_service: every main loop pass */
{
    if (!src_loaded) src_load();
    int op = req.op;
    if (op) {
        const char *err = op == PR_OVERWRITE ? do_overwrite() : op == PR_RENAME ? do_rename() : do_delete();
        if (op == PR_OVERWRITE) op1_save_clock_show(req.kind, req.slot, err ? -3 : -2);
        if (op == PR_DELETE) op1_save_clock_show(req.kind, -1, err ? -3 : -2);
        op1_toast(err ? err : op == PR_OVERWRITE ? "overwritten" : op == PR_RENAME ? "renamed" : "deleted");
        req.op = PR_NONE;
    }
    src_save();
    if (refresh_kind <= 1 && !refresh_posted) {          /* the list rebuild, on the KeyHandler thread */
        refresh_posted = 1;
        if (!KQ_PUSH(REFRESH_KEY, REFRESH_STATE)) refresh_posted = 0;   /* queue full: the next pass */
    }
}

/* ---------------- for the USB importer (kn_presets.c, docs/inventory.md "Presets"): the same lookup and delete ----
 * kind 0 synth, 1 drum. */
int kn_pt_rows(int kind, const char *folder, const char *name, int32_t *ids, int max)   /* matching row ids; -1 error */
{
    if (!part_ok(folder) || !part_ok(name)) return 0;
    char *o = cat(sql, sql + SQL_MAX, "SELECT id,patch FROM ");
    o = cat(o, sql + SQL_MAX, TABLE[kind & 1]);
    o = cat(o, sql + SQL_MAX, " WHERE ifnull(folder,'')='");
    o = cat_q(o, sql + SQL_MAX, folder);
    cat(o, sql + SQL_MAX, "' ORDER BY id");
    find_t f = { name, -1, 0, 0, ids, max };
    return db_run(sql, find_cb, &f) ? -1 : f.matches;
}
int kn_pt_query(const char *q, row_cb cb, void *arg) { return db_run(q, cb, arg); }   /* op1.db, under db2's lock */
int kn_pt_json_str(const char *t, const char *key, char *out, int size) { return json_str(t, key, out, size); }
int kn_pt_factory(int kind, const char *type)             /* factory entries in the loaded table (of that type; 0 = all) */
{
    int n = 0, count = tab_n(kind & 1);
    char t[16];
    for (int i = 0; i < count; i++)
        if (tab_factory(kind & 1, i) && (!type || (!tab_str(kind & 1, i, "type", t, sizeof t) && seq(t, type)))) n++;
    return n;
}
/* every row of folder/name: the first through the delete path (.deleted keeps the newest 16, slot records forgotten),
 * extra copies (disk mode leaves some) dropped. 0 done, "not there", or why not */
const char *kn_pt_delete(int kind, const char *folder, const char *name)
{
    int32_t ids[16];
    int n = kn_pt_rows(kind, folder, name, ids, 16);      /* (fills `patch` with the first one's JSON) */
    if (n < 0) return "not deleted";
    if (n == 0) return "not there";
    if (n > 16) n = 16;
    const char *err = delete_row(kind & 1, folder, name, ids[0]);
    if (err) return err;
    for (int i = 1; i < n; i++) {
        char *e = sql + SQL_MAX, *o = cat(sql, e, "DELETE FROM ");
        o = cat(o, e, TABLE[kind & 1]);
        o = cat(o, e, " WHERE id=");
        cat_u(o, e, (uint32_t)ids[i]);
        row_exec(sql);
    }
    return 0;
}
/* after the importer changed rows of `kind`: queued saves first, the table reloaded, an open browser rebuilt on the
 * preset it showed (KeyHandler, kn_presets_key) */
void kn_pt_changed(int kind)
{
    op1_preset_ref r;
    int open = br_kind() == (kind & 1) && op1_preset_pick(&r) >= 0;
    DRAIN(3000);
    table_reload(kind & 1);
    if (br_kind() == (kind & 1)) refresh(kind & 1, open ? r.folder : "", open ? r.name : "");
}
