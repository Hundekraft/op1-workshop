/*
 * FX switch declick (2026-11-11, ARCHITECTURE.md "FX switch declick"): the arithmetic, shared by the core
 * (kennel/kn_declick.c) and the host test (harness/declick_test.c).
 *
 * R246 swaps an effect with no fade: the FX list builds the new object in place and the next block renders it from
 * an empty state, so the output jumps from the old effect's last sample to the new one's first. On a change of
 * identity this adds the jump back as an offset that decays by 1/16 a sample (off -= off >> 4, then 1 a sample at
 * the end): about 3 ms from a full-scale step to 0, over as many blocks as it takes. Integers only, no division.
 *
 * The jump is measured against the last output sample when the previous render was this block or the one before
 * (R246 renders the mono FX once a block); after a longer gap (the effect was off, or R246's swap left the FX
 * pointer empty for a block, which passes the dry bus) against this block's dry input sample.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_DECLICK_H
#define KN_DECLICK_H
#include <stdint.h>

typedef struct {
    uint32_t id;          /* identity of the last effect rendered (0: none yet) */
    uint32_t blk;         /* block (R246 frame_counter) of that render */
    int32_t off;          /* offset still to add, decays to 0 */
    int32_t step;         /* the offset at the last switch (diagnostics) */
    int16_t last;         /* last output sample of that render */
    uint16_t switches;    /* identity changes seen (diagnostics) */
} kn_dc_t;

/* One channel of one render: x[0..n) is the effect's output, dry0 its input's first sample (before the render).
 * id != 0 names the effect (type, plugin, init epoch); blk the audio block. */
static inline void kn_dc_run(kn_dc_t *s, uint32_t id, int16_t *x, int n, int16_t dry0, uint32_t blk)
{
    if (n <= 0) return;
    if (s->id && id != s->id) {
        int32_t ref = (uint32_t)(blk - s->blk) <= 1u ? s->last : dry0;
        s->off = s->step = ref - x[0];
        s->switches++;
    }
    s->id = id;
    int32_t off = s->off;
    for (int i = 0; off && i < n; i++) {
        int32_t v = x[i] + off;
        x[i] = (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v);
        int32_t d = off >> 4;
        if (!d) d = off > 0 ? 1 : -1;
        off -= d;
    }
    s->off = off;
    s->last = x[n - 1];
    s->blk = blk;
}

/* A block in which the effect does not render although it did in the block before: R246's swap has the position's FX
 * pointer empty, so the dry bus x goes out. Called before the render would have run; fades from the last output into
 * the dry signal the same way and marks the state dry, so the next render (the new effect) counts as a switch measured
 * from this block's last sample. Later dry blocks carry the decay on. Returns 1 when it acted. */
#define KN_DC_DRY 0xFFFFFFFEu
static inline int kn_dc_gap(kn_dc_t *s, int16_t *x, int n, uint32_t blk)
{
    if (n <= 0 || !s->id || blk - s->blk != 1u) return 0;        /* nothing went out in the block before */
    kn_dc_run(s, KN_DC_DRY, x, n, x[0], blk);                     /* first dry block: a switch from s->last; later: the decay goes on */
    return 1;
}

/* Plugin FX init outside the audio callback (dispatcher.c fx_init / fx_init_stereo): one handoff per FX position.
 * The thread that builds the effect (R246's swap, the position's FX pointer empty meanwhile) marks the plugin busy,
 * runs its init, then leaves it as pre-initialised; the audio thread's first render of that plugin takes it.
 *   kn_fxpre_take -> -1: the plugin is being initialised (here or at the other position): pass the block dry;
 *                     1: the render must run init itself (word 4 changed after the swap, or nothing was prepared);
 *                     0: render. *cur is the plugin this position ran last (-1 after a swap). */
typedef struct { volatile int pre, busy; } kn_fxpre_t;
static inline void kn_fxpre_reset(kn_fxpre_t *s) { s->pre = -1; }
static inline void kn_fxpre_begin(kn_fxpre_t *s, int e) { s->busy = e; }
static inline void kn_fxpre_done(kn_fxpre_t *s, int e) { s->pre = e; s->busy = 0; }
static inline int kn_fxpre_take(kn_fxpre_t *s, const kn_fxpre_t *other, int e, int *cur)
{
    if (e == s->busy || e == other->busy) return -1;
    if (e == *cur) return 0;
    *cur = e;
    if (s->pre == e) { s->pre = -1; return 0; }
    return 1;
}

#endif
