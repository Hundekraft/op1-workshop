/* core side of op1_bus.h (kennel/kn_bus.c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_BUS_H
#define KN_BUS_H
#include <stdint.h>
void kn_bus_run(int pos, int16_t *bus);                   /* kn_input_bus: after the high-pass, pos 0 synth, 1 drum */
void ml_bus_tick(void);                                   /* screens/mlfo.c: the master LFO's strip targets, once a block */
#endif
