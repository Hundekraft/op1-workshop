/* An engine's own T2 page (screen 22, the ADSR page): the decisions kennel/kn_input.c makes for it, without R246
 * addresses, shared with harness/env_page_test.c. Two kinds of engine bring one, both as an op1_screen_t:
 *   an input engine (op1_input.h op1_input_engine_t.tuner, optional): its page takes every T2 knob and push (blue
 *     turns INPUT GAIN, kn_input_control);
 *   an own-envelope engine with plugin.json "t2_page" (op1_plugin.h op1_engine_ext_t.t2, KN_FLAG_T2_PAGE): its
 *     page takes nothing, so R246's synth controller keeps turning the four T2 knob words (ADSR words 0..3) and
 *     saving them in the sound; the engine reads them as its own parameters (op1_t2_words). With
 *     "t2_swallow" (KN_FLAG_T2_SWALLOW) the page takes the knobs and pushes like an input engine's, and nothing
 *     happens (the engine ignores the words).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_T2_PAGE_H
#define KN_T2_PAGE_H
#include "../op1_feature.h"                /* op1_plugin.h, OP1_IN_KEY / OP1_IN_KNOB */
#include "../op1_input.h"

/* The page a loaded synth file brings for its order (kn_boot.c), or 0: an input engine's tuner, else an own-envelope
 * engine's t2 when the file has KN_FLAG_T2_PAGE (the loader checked the flag needs KN_FLAG_OWN_ENV). */
static inline const op1_screen_t *kn_t2_page_of(int input, int t2_page, const void *entry)
{
    if (input) return ((const op1_input_engine_t *)entry)->tuner;                  /* +28 */
    if (t2_page) return ((const op1_engine_ext_t *)entry)->t2;                         /* +24 */
    return 0;
}

/* Puts target (an engine's page object, or 0 for none) into the screen table entry *slot. *shown is what this host
 * put there, *prior what it replaced. Another host (sampler+'s spu_sync) may write the entry: then this host lets go
 * of it without restoring anything. */
static inline void kn_t2_sync(void **slot, void **shown, void **prior, void *target)
{
    if (*shown && *slot != *shown) { *shown = 0; *prior = 0; }       /* another scoped host restored stock */
    if (!target) { if (*shown && *slot == *shown) *slot = *prior; *shown = *prior = 0; return; }
    if (*slot != target) { if (!*shown) *prior = *slot; *slot = target; *shown = target; }
}

/* While an engine's page is up: 1 when kennel takes the event away from R246. An input engine's page takes every
 * knob and the four pushes (0x3B..0x3E); an own-envelope engine's page takes nothing, or, with swallow
 * (KN_FLAG_T2_SWALLOW), the same events and does nothing with them. Other keys (Shift: R246's play-mode page) pass. */
static inline int kn_t2_takes(int input, int swallow, int type, int code)
{
    if (!input && !swallow) return 0;
    return type == OP1_IN_KNOB || (type == OP1_IN_KEY && code >= 0x3B && code <= 0x3E);
}
#endif
