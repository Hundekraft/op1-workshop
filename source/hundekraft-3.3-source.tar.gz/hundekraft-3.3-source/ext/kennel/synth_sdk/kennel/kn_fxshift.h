/*
 * Shift + turn and a push flag on a custom FX's page (op1_plugin.h op1_fx_shift, op1_fx_push_bit; 2026-11-11, for
 * KHORUS's shift layer and sweep): the FX twin of op1_engine_shift, the same word layout. A file calls them from its
 * screen's init; only an FX that did so is touched (kn_fx_shift_n / kn_fx_push return 0 for every other FX, and
 * dispatcher.c then runs its paths as before). The words:
 *   blue word 5, green word 6: n = 2..127 one step a detent, step i's word (2i+1) * 32768 / (2n), an unset word (<= 0)
 *     from step 0; n = 1 fine (delta / 4 a tick, 1 .. 32767)
 *   white bits 0..6, red bits 8..14 of word 7: a 7-bit field, one unit a detent through 0 .. n-1 (n = 2..127) or
 *     0..127 (n = 1); bits 7 and 15 are the FX's own (a push flag may own one)
 *   a push of knob k registered with op1_fx_push_bit toggles bit 7 or 15 of word 7 (press only; the release is taken)
 * Words 0..4 are never written here. Included once, after op1_plugin.h, by dispatcher.c (the exported functions) and
 * by host tests (harness/fx_shift_test.c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_FXSHIFT_H
#define KN_FXSHIFT_H
#include <stdint.h>
#include "kn_coarse.h"

#undef op1_fx_shift                                   /* a host build's no-op macros (op1_plugin.h): the real ones here */
#undef op1_fx_push_bit
#define KN_FX_SHIFT_MAX 8
static struct { const op1_fx_t *fx; uint8_t sh[4]; int8_t bit[4]; } kn_fx_shift_tab[KN_FX_SHIFT_MAX];

static int kn_fx_shift_slot(const op1_fx_t *fx, int make)
{
    int f = -1;
    for (int i = 0; i < KN_FX_SHIFT_MAX; i++) {
        if (kn_fx_shift_tab[i].fx == fx) return i;
        if (f < 0 && !kn_fx_shift_tab[i].fx) f = i;
    }
    if (f < 0 || !make) return -1;                    /* table full: the FX keeps the stock shift turn */
    kn_fx_shift_tab[f].fx = fx;
    for (int k = 0; k < 4; k++) kn_fx_shift_tab[f].bit[k] = -1;
    return f;
}

void op1_fx_shift(const op1_fx_t *fx, int knob, int n)
{
    if (!fx || knob < 0 || knob > 3 || n < 0 || n > 127) return;
    const int f = kn_fx_shift_slot(fx, 1);
    if (f >= 0) kn_fx_shift_tab[f].sh[knob] = (uint8_t)n;
}

void op1_fx_push_bit(const op1_fx_t *fx, int knob, int bit)
{
    if (!fx || knob < 0 || knob > 3 || (bit != 7 && bit != 15)) return;
    const int f = kn_fx_shift_slot(fx, 1);
    if (f >= 0) kn_fx_shift_tab[f].bit[knob] = (int8_t)bit;
}

/* the FX's shift steps for knob k (0: not registered: the stock path) */
static inline int kn_fx_shift_n(const op1_fx_t *fx, int knob)
{
    const int f = fx && knob >= 0 && knob < 4 ? kn_fx_shift_slot(fx, 0) : -1;
    return f < 0 ? 0 : kn_fx_shift_tab[f].sh[knob];
}

/* a Shift + turn of knob k on the FX words w (n from kn_fx_shift_n). -> 1 when a word changed */
static inline int kn_fx_shift_turn(int32_t *acc, int16_t *w, int knob, int delta, int n)
{
    if (knob < 2) {                                   /* blue word 5, green word 6 */
        int16_t *wd = &w[5 + knob];
        if (n > 1) {
            if (*wd <= 0) *wd = (int16_t)(32768 / (2 * n));   /* unset: from step 0 */
            return kn_step_turn(acc, wd, delta, n);
        }
        const int32_t v = (*wd > 0 ? *wd : 0) + delta / 4;
        *wd = (int16_t)(v < 1 ? 1 : (v > 32767 ? 32767 : v));
        return 1;
    }
    const int sh = knob == 2 ? 0 : 8;                 /* white bits 0..6, red bits 8..14 of word 7 */
    const int m = n > 1 ? n : 128;
    int f = (w[7] >> sh) & 127;
    f = f < m ? f : m - 1;
    int16_t t = (int16_t)(((2 * f + 1) * 32768) / (2 * m));
    if (!kn_step_turn(acc, &t, delta, m)) return 0;
    const int g = (t * m) >> 15;
    w[7] = (int16_t)((w[7] & ~(127 << sh)) | g << sh);
    return 1;
}

/* word 7 written by anything but the FX's own push (a MIDI CC map, kn_mx.c): the push-owned bits (7 / 15, those the FX
 * registered with op1_fx_push_bit) keep their old value, so only the push changes them (PLATE's mode, owner
 * 2026-11-12). An FX with no push bit gets v unchanged. */
static inline int16_t kn_fx_keep_push_bits(const op1_fx_t *fx, int16_t old, int16_t v)
{
    const int f = fx ? kn_fx_shift_slot(fx, 0) : -1;
    if (f < 0) return v;
    uint16_t m = 0;
    for (int k = 0; k < 4; k++) if (kn_fx_shift_tab[f].bit[k] >= 0) m |= (uint16_t)(1u << kn_fx_shift_tab[f].bit[k]);
    return (int16_t)(((uint16_t)v & ~m) | ((uint16_t)old & m));
}

/* a push of knob k on the FX words w: -> 1 when the FX owns it (pressed: its bit of word 7 toggled) */
static inline int kn_fx_push(const op1_fx_t *fx, int16_t *w, int knob, int pressed)
{
    const int f = fx && knob >= 0 && knob < 4 ? kn_fx_shift_slot(fx, 0) : -1;
    if (f < 0 || kn_fx_shift_tab[f].bit[knob] < 0) return 0;
    if (pressed) w[7] = (int16_t)(w[7] ^ (1 << kn_fx_shift_tab[f].bit[knob]));
    return 1;
}

#endif
