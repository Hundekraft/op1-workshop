/* The instrument bus decimator in L1 (kennel/kn_dec.c), in place of R246's core_decimate_2to1 (L1 0xFFA005D4, 176 B,
 * called from core_block_process at 0xFFA01EB4 game, 0xFFA02456 drum, 0xFFA02888 synth, no arguments). After op1r-src
 * dsp/dec_l1.S (a48d1e6, 9c0038d; xoza, GPL-3.0-or-later with the OP-1 firmware permission): two outputs per pass with
 * both multipliers, R246's results bit for bit. kennel's change: the coefficient pairs hp[k] = (h[k - 1] high, h[k]
 * low), k = 0..32 (h[-1] = h[32] = 0; h = R246's table 0x0106A6F0) live in L1 data at KN_DEC_HP (kn_dec.c builds them
 * once at boot), not on the audio stack every block (that stack is SDRAM in the release build), and there is no helper
 * call. With v_k = A[(i + 1 + k) & 31] (A[i] = x[2i] already written) and v_32 = x[2i + 2]:
 *   y[i]: A0 = B[i + 16] << 15, += h[k] v_k (k = 0..31); y[i + 1]: A1 = B[i + 17] << 15, += h[k - 1] v_k (k = 1..32),
 * both in R246's order (W32, saturating per MAC); y = (acc.H x gain) rounded, gain += step (saturating) per output.
 *
 * Registers (R246's routine and its three call sites, kennel ARCHITECTURE "Decimator in L1"): R246 changes R0-R2,
 * P0-P2, I0-I3, B1-B3, L1-L3 (left 0), M0, LC0 / LC1, LT0-LB1, A0, ASTAT and keeps everything else (it saves P3-P5).
 * This routine changes R0-R2, P0, P2, I1-I3, B1-B3, L1-L3 (left 0), M0, LC0 / LC1, LT / LB, A0, A1 and ASTAT, and saves
 * R4-R7 and P3-P5. A1 is the one register outside R246's set: every caller goes straight on to `P1 = 0x019674F8;
 * CALL (P1)`, whose prologue is kennel's hook (kennel/kn_input.S -> C code, which GCC lets clobber A0 / A1), so A1 is
 * dead there in every kennel build. It never touches R3 or M1-M3 (the synth caller keeps its frame in M1 across both
 * calls; op1r's 9c0038d crash was a clobbered M1 / R3), nor L0, I0, B0 (y goes out through P4). harness/tier2/dec_guest.c
 * proves the register contract and the results on bcore.
 *
 * Position-independent bytes (absolute addresses only as immediates, PC-relative LSETUP, no CALL): kn_dec.c copies them
 * from here to 0xFFA005D4 (DTEST, KN_L1_RUNTIME), or make_firmware.py puts them there as a plain LDR block (LDR mode).
 * Never executed at this address. At most 176 bytes (make_firmware.py checks).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#define KN_DEC_HP 0xFF906B7C                    /* kn_dec.c: L1 data B, the constructor-copied table R246 no longer reads */
	.section .rodata.kn_dec,"a"
	.align 4
	.global _kn_dec_l1_start, _kn_dec_l1_end
_kn_dec_l1_start:
	[--SP] = (R7:4, P5:3);
	P3.L = 0x0BB4; P3.H = 0xFF80;		/* x: 128 int16 at 88.2 kHz */
	P4.L = 0x1E50; P4.H = 0xFF80;		/* y: 64 int16 */
	P5.L = 0x107C; P5.H = 0xFF80;		/* gain (.L), step (.H) */
	R7 = [P5];
	R0 = 64 (X);				/* (register moves: the routine must fit R246's 176 bytes) */
	I1.L = 0x123C; I1.H = 0xFF80; B1 = I1; L1 = R0;	/* A (even samples), written and read */
	I3.L = 0x127C; I3.H = 0xFF80; B3 = I3; L3 = R0;	/* B (odd samples), written */
	I2 = I3; B2 = I3; L2 = R0;
	P2 = 32;				/* the pair count, also the inner loop's tap count (P2 stays 32) */
	M0 = P2; I2 += M0;			/* B, read from index 16 */
	LSETUP (1f, 3f) LC1 = P2;
1:	R4 = [P3++];				/* x[2i], x[2i+1] */
	R5 = [P3++];				/* x[2i+2], x[2i+3] */
	W[I3++] = R4.H;
	W[I3++] = R5.H;
	W[I1++] = R4.L;				/* A[i] */
	R0.L = W[I2++];
	R0 = R0.L (X);
	R0 <<= 15;
	A0 = R0;
	R0.L = W[I2++];
	R0 = R0.L (X);
	R0 <<= 15;
	A1 = R0;
	P0.L = KN_DEC_HP & 0xFFFF; P0.H = (KN_DEC_HP >> 16) & 0xFFFF;
	R1 = [P0++];
	R0.L = W[I1++];
	LSETUP (2f, 2f) LC0 = P2;
2:	A1 += R0.L * R1.H, A0 += R0.L * R1.L (W32) || R1 = [P0++] || R0.L = W[I1++];
	A1 += R5.L * R1.H, A0 += R5.L * R1.L (W32);
	I1 -= 2;				/* the pass read one past: back to A[i + 1] */
	W[I1++] = R5.L;				/* A[i + 1] */
	R2 = A0;
	R6.L = R2.H * R7.L;
	R7.L = R7.L + R7.H (S);
	R1 = A1;
	R6.H = R1.H * R7.L;
	R7.L = R7.L + R7.H (S);
3:	[P4++] = R6;
	W[P5] = R7;
	R0 = 0;
	L1 = R0; L2 = R0; L3 = R0;
	(R7:4, P5:3) = [SP++];
	RTS;
	.align 4
_kn_dec_l1_end:
