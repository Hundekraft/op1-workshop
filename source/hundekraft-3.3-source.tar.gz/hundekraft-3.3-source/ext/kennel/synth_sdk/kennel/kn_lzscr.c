/*
 * Lazy stock screens (after op1r-src b220d08 "Boot time", xoza; GPL-3.0-or-later with the OP-1 firmware permission,
 * PROVENANCE.md). R246's boot parses every stock screen's SVG (Screen::load_all 0x01A3BA50: svg_load, then the
 * screen's init). Here screens_load_hook (dispatcher.c) leaves the stock screens that have an SVG and that kennel does
 * not touch at boot unparsed, and they are parsed (svg_load + their init, as the stock loop does) later:
 *   - on the Gfx thread at the start of a frame (kn_screens_frame), when the frame will show one;
 *   - on the Gfx thread in the background, one a frame, from KN_LZ_BG_FRAMES frames after the first frame, and only
 *     after KN_LZ_QUIET frames without a key press or knob turn (kn_lz_input, from dispatcher.c's key and knob hooks),
 *     so a parse doesn't make a frame late while someone is playing (owner, 2026-11-13: animation stutter on the unit);
 *   - when code looks a node up in one (Screen::find_node 0x01A3B580, hook_lzfind -> kn_lz_guard): on the Gfx thread
 *     or before the Gfx thread has drawn (boot), parsed there; on any other thread it asks Gfx and sleeps (VDK_Sleep
 *     1 ms steps) until Gfx has parsed it, so the TE heap and the parse stay on the Gfx thread. After
 *     KN_LZ_WAIT_MS without Gfx (Gfx itself waiting on that thread) it parses there. A lookup that comes from the
 *     screen's own parse (its init) passes. A Gfx frame that finds a parse running on another thread waits for it
 *     (up to 1 s) before it draws.
 * op1r parses on whatever thread calls find_node and lets a second thread through while a parse runs; kennel keeps the
 * parse on Gfx and makes other threads wait for it (ARCHITECTURE.md "Boot time: lazy stock screens").
 *
 * Kept eager (parsed at boot as before): screens kennel reads or swaps at boot or whose loader kennel shares
 * (KN_LZ_EAGER below). Switch: the setting "boot" / "lazy_screens", read at boot, OFF by default (owner, 2026-11-11):
 * 0 = R246's own Screen::load_all, nothing deferred, no background parse. A TEST that can crash: R246 calls a stock
 * screen's own methods from the key handler when its page is selected (synth T4, the LFO page, crashed at once in a
 * build without background parsing, no find_node first), and a deferred screen's init has not run yet. The planned
 * fix (3.3): a stand-in vtable per deferred screen whose every entry first makes sure the screen is parsed
 * (ARCHITECTURE.md "Boot time"). kn_lz_stat: [0] parsed for a frame,
 * [1] parsed in a lookup on Gfx / at boot, [2] lookups that waited for Gfx, [3] background, [4] slowest parse
 * (cycles), [5] waits that ran out (parsed on the caller's thread), [6] deferred at boot, [7] still pending.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include <stdint.h>

#define LZ_N            0x44
#define KN_LZ_BG_FRAMES 120                      /* the background starts two seconds after the first frame */
#define KN_LZ_QUIET     30                       /* .. and waits half a second after the last key press or knob turn */
#define KN_LZ_WAIT_MS   200                      /* a non-Gfx lookup waits this long for Gfx, then parses itself */

#ifdef OP1_HOST
extern void *host_svg_load(void *loader);
extern void host_sleep_ms(int ms);
extern void *host_thread(void);
#define SVG_LOAD   host_svg_load
#define DELAY_MS   host_sleep_ms
#define THREAD()   host_thread()
#define IRQ_OFF(m) ((void)(m))
#define IRQ_ON(m)  ((void)(m))
extern int host_locked(void);
#define LOCKED()   host_locked()
static inline uint32_t cyc(void) { return 0; }
#else
#define SVG_LOAD   ((void *(*)(void *))0x01A503D8)
#define DELAY_MS   ((void (*)(int))0x0193E5C0)                       /* VDK_Sleep (kn_tape.c, bgsave.c) */
#define THREAD()   (*(void *volatile *)0xFF802DE4)                    /* tmk_current_thread */
#define IRQ_OFF(m) __asm__ volatile("cli %0;" : "=d"(m))
#define IRQ_ON(m)  __asm__ volatile("sti %0;" : : "d"(m))
/* a context that must not sleep: interrupts masked, the kernel lock held (tmk_master_kernel_lock 0xFF802DE8) or an
 * unscheduled region (vdk_unscheduled_region_count 0xFF802F8C; docs/firmware/kernel.md) */
static inline int LOCKED(void)
{
    uint32_t m;
    __asm__ volatile("cli %0; sti %0;" : "=d"(m));
    return !(m & 0xFFE0u) || *(volatile uint32_t *)0xFF802DE8 || *(volatile uint32_t *)0xFF802F8C;
}
static inline uint32_t cyc(void) { uint32_t c; __asm__ volatile("%0 = CYCLES;" : "=d"(c)); return c; }
#endif

/* stock screen ids parsed at boot as before: sampler (6, 0x16, 0x28: sampler+), filter / FX (0x0B), drum (0x10,
 * 0x17: drum+ shares their loaders), iter / engines (0x14), 21 (MIDI), MIDI LFO (0x1C), mixer (0x1F: mx_attach),
 * COM (0x26), clock (0x2A: clock pages), finger / sequencers (0x2D), signal flow (0x30: FX routing, master LFO), 0x3F */
static const uint8_t KN_LZ_EAGER[] = { 0x06, 0x0B, 0x10, 0x14, 0x15, 0x16, 0x17, 0x1C, 0x1F, 0x26, 0x28, 0x2A, 0x2D,
                                       0x30, 0x3F };

static uint32_t *lz_obj[LZ_N];
static volatile uint8_t lz_state[LZ_N];          /* 0 none / done, 1 pending, 2 parsing */
static volatile uint8_t lz_want[LZ_N];           /* a lookup on another thread asks Gfx for it */
static void *volatile lz_owner[LZ_N];            /* the thread parsing it */
volatile uint32_t kn_lz_input;                   /* key presses and knob turns (dispatcher.c): pauses the background */
static void *volatile gfx_thread;                /* set by the first kn_lz_frame */
volatile uint32_t kn_lz_on;                      /* this boot defers (the setting, read at boot; 0 by default) */
#ifdef KN_LZ_NOBG
volatile uint32_t kn_lz_bg = 0;                  /* test build (KN_LZ_NOBG=1): no background parsing, screens stay pending */
#else
volatile uint32_t kn_lz_bg = 1;                  /* background parsing */
#endif
volatile uint32_t kn_lz_pending;
volatile uint32_t kn_lz_stat[8];
/* the last 16 lookups of a pending screen off the Gfx thread: id | locked << 8, the thread (diagnostics) */
volatile uint32_t kn_lz_ctx[16][2], kn_lz_ctx_n;

int kn_lz_defer(int id, uint32_t *o)              /* the boot loop: 1 = left pending (no svg_load, no init now) */
{
    if (!kn_lz_on || id < 0 || id >= LZ_N || !o || o[0] || !o[2]) return 0;
    for (unsigned k = 0; k < sizeof KN_LZ_EAGER; k++) if (KN_LZ_EAGER[k] == id) return 0;
    lz_obj[id] = o; lz_state[id] = 1;
    kn_lz_pending++; kn_lz_stat[6]++; kn_lz_stat[7] = kn_lz_pending;
    return 1;
}

void kn_lz_stock_init(uint32_t *o)               /* as Screen::load_all: svg_load if no document, then the init */
{
    if (!o[0] && o[2]) o[0] = (uint32_t)(uintptr_t)SVG_LOAD((void *)(uintptr_t)o[2]);
#ifndef OP1_HOST
    const uint8_t *vt = (const uint8_t *)o[3];
    ((void (*)(void *))*(const uint32_t *)(vt + 0x24))((uint8_t *)o + *(const int16_t *)(vt + 0x20));
#else
    extern void host_stock_init(uint32_t *o);
    host_stock_init(o);
#endif
}

static int lz_load(int i)                         /* 1 = parsed now by this thread */
{
    uint32_t m;
    IRQ_OFF(m);
    const int mine = lz_state[i] == 1;
    if (mine) { lz_state[i] = 2; lz_owner[i] = THREAD(); }
    IRQ_ON(m);
    if (!mine) return 0;
    const uint32_t c0 = cyc();
    kn_lz_stock_init(lz_obj[i]);
    const uint32_t c = cyc() - c0;
    if (c > kn_lz_stat[4]) kn_lz_stat[4] = c;
    lz_owner[i] = 0; lz_want[i] = 0;
    IRQ_OFF(m);
    lz_state[i] = 0; kn_lz_pending--; kn_lz_stat[7] = kn_lz_pending;
    IRQ_ON(m);
    return 1;
}

/* Screen::find_node entry (hook.S _lz_find_stub): o = the screen object about to be searched */
void kn_lz_guard(uint32_t *o)
{
    if (!kn_lz_pending) return;
    int i = 0;
    while (i < LZ_N && lz_obj[i] != o) i++;
    if (i == LZ_N || !lz_state[i]) return;
    void *me = THREAD();
    if (lz_state[i] == 2 && lz_owner[i] == me) return;        /* its own init looking itself up */
    if (!gfx_thread || me == gfx_thread) {                    /* boot (Gfx not drawing yet) or Gfx: parse here */
        if (lz_load(i)) { kn_lz_stat[1]++; return; }
    }
    const int locked = LOCKED();
    { const uint32_t k = kn_lz_ctx_n++ & 15; kn_lz_ctx[k][0] = (uint32_t)i | (uint32_t)locked << 8;
      kn_lz_ctx[k][1] = (uint32_t)(uintptr_t)me; }
    if (locked) {                                             /* may not sleep: parse here (as op1r) */
        kn_lz_stat[5]++;
        if (lz_load(i)) return;
        while (lz_state[i]) ;                                 /* (another thread's parse cannot run meanwhile) */
        return;
    }
    lz_want[i] = 1;                                           /* another thread: Gfx parses it at its next frame */
    int waited = 0;
    while (lz_state[i] && waited < KN_LZ_WAIT_MS) { DELAY_MS(1); waited++; }
    if (!lz_state[i]) { kn_lz_stat[2]++; return; }
    kn_lz_stat[5]++;                                          /* Gfx did not come (it may be waiting on us) */
    if (lz_load(i)) return;
    while (lz_state[i]) DELAY_MS(1);                          /* Gfx took it meanwhile: its parse ends */
}

/* Gfx, the start of a frame (kn_screens_frame, before the frame's resets and drawing): what the frame shows, what a
 * lookup asked for, else one in the background */
void kn_lz_frame(void *const *frame, int cur)
{
    static uint32_t frames;
    void *me = THREAD();
    if (!gfx_thread) gfx_thread = me;
    if (!kn_lz_pending) return;
    /* a parse on another thread (boot, or a lookup whose wait ran out): no drawing (TE heap) until it is done */
    for (int i = 0, n = 0; i < LZ_N && n < 1000; i++)
        while (lz_state[i] == 2 && lz_owner[i] != me && n < 1000) { DELAY_MS(1); n++; }
    int did = 0;
    for (int i = 0; i < LZ_N; i++) {
        if (lz_state[i] != 1) continue;
        if (lz_want[i]) { if (lz_load(i)) did = 1; continue; }
        uint32_t *o = lz_obj[i];
        int shown = 0;
        for (int k = 0; k < LZ_N && !shown; k++) shown = frame[k] == (void *)o;
        if (!shown) continue;
#ifndef OP1_HOST
        const uint8_t *vt = (const uint8_t *)o[3];
        const int vis = ((int (*)(void *, int))*(const uint32_t *)(vt + 0x14))((uint8_t *)o + *(const int16_t *)(vt + 0x10), cur);
#else
        extern int host_screen_visible(uint32_t *o, int cur);
        const int vis = host_screen_visible(o, cur);
#endif
        if (vis && lz_load(i)) { kn_lz_stat[0]++; did = 1; }
    }
    static uint32_t seen, quiet;
    const uint32_t in = kn_lz_input;
    if (in != seen) { seen = in; quiet = 0; } else if (quiet < KN_LZ_QUIET) quiet++;
    if (frames < KN_LZ_BG_FRAMES) frames++;
    if (!kn_lz_bg || did || frames < KN_LZ_BG_FRAMES || quiet < KN_LZ_QUIET) return;
    for (int i = 0; i < LZ_N; i++)
        if (lz_state[i] == 1) { if (lz_load(i)) kn_lz_stat[3]++; return; }   /* one a frame */
}
