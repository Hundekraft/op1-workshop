/*
 * Hook point "LFO types" (op1_feature_lfo.h, docs/feature-hooks.md): the core side. R246's sites stay patched by the
 * core (hook.S, make_firmware.py, dispatcher.c); they ask here whether a word set belongs to a feature LFO and call
 * the registered types (up to KN_LFO_MAX, from one feature or several: op1_lfo_type.next), running in the MIDI LFO class.
 * Reserved: quad's, pond's and matrix's word encodings are known here even when no feature registers them (the file
 * missing or broken), so their words never reach R246's range assert (patch.cpp:390, a lock at boot) on any path and
 * do nothing. Their names are another matter (kn_lfo_known_name): a sound whose LFO type is not registered once the
 * loader has run falls back to tremolo, off, with a toast (kn_patch_safe.c), as 3.2.6 does for matrix.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_feature_lfo.h"
#include "kn_src.h"                              /* page 7's named sources (test build): the passes under the feature */

const op1_lfo_type *kn_lfo_owner(const int16_t *w);
int kn_feature_count(void);
const op1_feature_t *kn_feature_at(int i);

const op1_lfo_type *kn_lfo_types[KN_LFO_MAX];    /* the registered LFO types, in registration order */
int kn_lfo_n;                                    /* how many; 0 = none (all sites stock) */
#if KN_DIAG
static uint8_t lfo_feat[KN_LFO_MAX];             /* the registering feature's index (kn_feature_at), page 7's source */
#endif
const op1_lfo_type *kn_lfo_type;                 /* the first one (the page / press / turn sites ask kn_lfo_owner) */
uint8_t kn_lfo_keep_reserved;                    /* kn_boot.c: this boot skipped every plugin file (kn_skipped) */
static uint8_t lfo_finished;                     /* kn_lfo_finish ran: the registered types are final */

#define QUAD_MARK 0xA5                           /* quad (lfo/quadlfo.c): word 7 = 0xA5xx */
#define POND_MARK 0xA7                           /* pond (lfo/quadlfo.c, same file): word 7 = 0xA7xx */
#define MATRIX_MARK 0xB3                         /* matrix (plugins/matrix): word 7 = 0xB300, words 0..1 the record id */
/* quad's marker byte also holds the four per-LFO mutes (lfo/ql_dsp.h ql_mark_quad): bits 6, 3, 2, 0 vary around 0xA5
 * (never 0xB3: bit 4 is 0 in every quad marker) */
static inline int quad_mark(unsigned hi) { return (hi & 0xB2) == 0xA0; }
static inline int quad_old_ctrl(int16_t c) { uint16_t m = (uint16_t)c & 0xE000; return m == 0x4000 || m == 0x6000; }

/* words of a released feature LFO, registered or not: quad's current format, and op1r <= 15 quad
 * (0x4000 / 0x6000 control words in 4..7) */
static int kn_lfo_reserved(const int16_t *w)
{
    const int hi = (uint16_t)w[7] >> 8;
    if (quad_mark((unsigned)hi) || hi == POND_MARK || hi == MATRIX_MARK) return 1;
    return quad_old_ctrl(w[4]) && quad_old_ctrl(w[5]) && quad_old_ctrl(w[6]) && quad_old_ctrl(w[7]);
}

static int same(const char *a, const char *b)
{
    if (!a || !b) return 0;
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}

/* kn_features_finish: every usable LFO type of every feature (and its `next` chain), a name and a marker once */
void kn_lfo_finish(void)
{
    kn_lfo_n = 0; kn_lfo_type = 0;
    for (int i = 0; i < kn_feature_count(); i++) {
        int guard = 0;                           /* a cyclic `next` ends here */
        for (const op1_lfo_type *t = kn_feature_at(i)->lfo; t && guard < KN_LFO_MAX; t = t->next, guard++) {
            if (!t->name || !t->match || t->stock_class != OP1_LFO_CLASS_MIDI || t->marker < 0x80) continue;
            if (quad_mark(t->marker) && !same(t->name, "quad")) continue;   /* quad's marker family is quad's */
            int dup = 0;
            for (int k = 0; k < kn_lfo_n; k++) if (same(kn_lfo_types[k]->name, t->name) || kn_lfo_types[k]->marker == t->marker) dup = 1;
            if (!dup && kn_lfo_n < KN_LFO_MAX) {
#if KN_DIAG
                lfo_feat[kn_lfo_n] = (uint8_t)i;
#endif
                kn_lfo_types[kn_lfo_n++] = t;
            }
        }
    }
    kn_lfo_type = kn_lfo_n ? kn_lfo_types[0] : 0;
    lfo_finished = 1;
}

const char *kn_lfo_name(void) { return kn_lfo_type ? kn_lfo_type->name : 0; }
const char *kn_lfo_name_at(int i) { return i >= 0 && i < kn_lfo_n ? kn_lfo_types[i]->name : 0; }
/* 1: `name` is a registered type's */
int kn_lfo_is_name(const char *name)
{
    for (int i = 0; i < kn_lfo_n; i++) if (same(kn_lfo_types[i]->name, name)) return 1;
    return 0;
}

/* A feature LFO type name a sound may load with (kn_patch_safe.c known_lfo; stock names are checked there): a
 * registered type's. An unknown name, or a reserved one (quad, pond, matrix) whose feature is not registered (its file
 * left out of the build or broken), is not: the sound's LFO becomes tremolo, off, with a toast, as on 3.2.6, instead of
 * the MIDI LFO class switched on and doing nothing. Before kn_lfo_finish, and on a boot that skipped every plugin file
 * (a recovery boot: the files come back on the next one), the reserved names stay known: the LFO loads and does
 * nothing, and the sound is not rewritten. */
int kn_lfo_known_name(const char *name)
{
    if (kn_lfo_is_name(name)) return 1;
    if (lfo_finished && !kn_lfo_keep_reserved) return 0;
    return same(name, "quad") || same(name, "pond") || same(name, "matrix");
}

/* patch range check (dispatcher.c lfo_range_ok): word 7's high byte marks a feature LFO's words */
int kn_lfo_marker(int hi)
{
    if (quad_mark((unsigned)hi) || hi == POND_MARK || hi == MATRIX_MARK) return 1;
    for (int i = 0; i < kn_lfo_n; i++) if (hi == kn_lfo_types[i]->marker) return 1;
    return 0;
}

/* not stock MIDI LFO words: read_lfo_param must not range-check them, LfoMidi must not run them */
int kn_lfo_claims(const int16_t *w)
{
    return kn_lfo_reserved(w) || kn_lfo_owner(w);
}

/* the registered type whose words these are, or 0 */
const op1_lfo_type *kn_lfo_owner(const int16_t *w)
{
    for (int i = 0; i < kn_lfo_n; i++) if (kn_lfo_types[i]->match(w)) return kn_lfo_types[i];
    return 0;
}
static inline const op1_lfo_type *owner(const int16_t *w) { return kn_lfo_owner(w); }

/* LfoMidi vtable apply entries for claimed words (hook.S QL_STUB); unowned (reserved) words: no modulation */
#if KN_DIAG
/* test build: each pass timed and charged to the type's feature (page 7: "lfo matrix 13"); the lookup is R246's share */
static int apply_timed(int (*fn)(void *, const int16_t *, int), const op1_lfo_type *t, void *self, const int16_t *w, int pass)
{
    if (!kd_cb) return fn(self, w, pass);        /* page 7 not counting: the call alone */
    KD_T0(t0);
    const int r = fn(self, w, pass);
    const uint32_t c = kd_now() - t0;
    int k = 0;
    while (k < kn_lfo_n && kn_lfo_types[k] != t) k++;
    kd_src(KD_SRC(KD_K_FEAT, k < kn_lfo_n ? lfo_feat[k] : 0xFF), c);
    return r;
}
#define APPLY(t, fn, self, w, pass) apply_timed((t)->fn, (t), (self), (w), (pass))
#else
#define APPLY(t, fn, self, w, pass) (t)->fn((self), (w), (pass))
#endif
int kn_lfo_apply_synth(void *self, const int16_t *w, int pass)
{
    const op1_lfo_type *t = owner(w);
    return t && t->apply_synth ? APPLY(t, apply_synth, self, w, pass) : 0;
}
int kn_lfo_apply_drum(void *self, const int16_t *w, int pass)
{
    const op1_lfo_type *t = owner(w);
    return t && t->apply_drum ? APPLY(t, apply_drum, self, w, pass) : 0;
}
int kn_lfo_apply_fx(void *self, const int16_t *w, int pass)
{
    const op1_lfo_type *t = owner(w);
    return t && t->apply_fx ? APPLY(t, apply_fx, self, w, pass) : 0;
}

/* LfoMidi vtable +0x1c note-on triggers (make_firmware DATA_PATCHES); the stock ones are bare RTS */
void kn_lfo_trig_synth(void *self, const int16_t *w)
{
    const op1_lfo_type *t = owner(w);
    if (t && t->trig_synth) t->trig_synth(self, w);
}
void kn_lfo_trig_drum(void *self, const int16_t *w)
{
    const op1_lfo_type *t = owner(w);
    if (t && t->trig_drum) t->trig_drum(self, w);
}
void kn_lfo_trig_fx(void *self, const int16_t *w)
{
    const op1_lfo_type *t = owner(w);
    if (t && t->trig_fx) t->trig_fx(self, w);
}

/* dispatcher.c midi_cc_hook / midi_start_hook */
void kn_lfo_midi_cc(int cc, int value)
{
    for (int i = 0; i < kn_lfo_n; i++) if (kn_lfo_types[i]->midi_cc) kn_lfo_types[i]->midi_cc(cc, value);
}
void kn_lfo_midi_start(void)
{
    for (int i = 0; i < kn_lfo_n; i++) if (kn_lfo_types[i]->midi_start) kn_lfo_types[i]->midi_start();
}
