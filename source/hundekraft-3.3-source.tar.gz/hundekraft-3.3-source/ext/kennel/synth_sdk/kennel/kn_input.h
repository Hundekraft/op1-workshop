/* Private continuous-input host. GPL-3.0-or-later with OP-1 firmware permission. */
#ifndef KN_INPUT_H
#define KN_INPUT_H
#include "../op1_input.h"
#include "kn_t2_page.h"
extern const op1_input_engine_t *op1_input_engines[OP1_SLOTS];
extern const op1_screen_t *kn_t2_pages[OP1_SLOTS];   /* an engine's own T2 page by order (kn_boot.c, kn_t2_page.h) */
extern uint8_t kn_t2_swallow[OP1_SLOTS];              /* 1: that page takes the encoders and pushes (KN_FLAG_T2_SWALLOW) */
void kn_input_bus(uint32_t *monitor, uint32_t caller);
void kn_input_clock(uint32_t now);
void kn_input_end(void);
void kn_input_service(void);
void kn_input_ctor(void);
void kn_input_load(void);
void kn_input_screen_sync(void);
int kn_input_control(int type, int code, int down, int delta);
#define KN_GAIN_KNOB 0                 /* blue turns INPUT GAIN on an input engine's T2 page */
int kn_input_tuner_visible(void);
int kn_t2_page_visible(void);       /* an engine's own T2 page is up: its order, else 0 */   /* an input engine's page is up */
void kn_input_budget(int order, uint32_t used);
#endif
