/* The instrument bus decimator in L1 (kennel/kn_dec.c, kn_dec_l1.S).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_DEC_H
#define KN_DEC_H
#include <stdint.h>

#define KN_DEC_ADDR      0xFFA005D4u            /* R246's core_decimate_2to1 (L1 code) */
#define KN_DEC_ROOM      176u                   /* its bytes: kennel's routine must fit */
#define KN_DEC_R246_FNV  0xBE408D72u            /* FNV-1a of R246's 176 bytes (the decrypted L1 code, 2026-11-12) */
#define KN_DEC_HP        0xFF906B7Cu            /* 33 coefficient pairs in L1 data B (kn_dec_l1.S has the same) */

extern volatile uint32_t kn_dec[8];
extern uint32_t kn_dec_expect;
void kn_dec_model(void);
void kn_dec_install(int runtime);
int kn_dec_text(char *m);
#endif
