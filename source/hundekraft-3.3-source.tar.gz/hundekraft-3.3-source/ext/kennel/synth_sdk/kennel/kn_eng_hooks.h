/* Engine hooks for an engine with its own pages (op1_plugin.h op1_engine_ext2_t; kennel/kn_eng_hooks.c): the decisions,
 * without R246 addresses, shared with harness/eng_hooks_test.c.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KN_ENG_HOOKS_H
#define KN_ENG_HOOKS_H
#include "../op1_feature.h"                /* op1_plugin.h, OP1_IN_KEY / OP1_IN_KNOB, OP1_EV_* */

#define KN_EH_INPUT   1u                   /* kn_eng_hook_flags[n]: KN_FLAG_ENG_INPUT */
#define KN_EH_T4      2u                   /* KN_FLAG_T4_PAGE */
#define KN_EH_SERVICE 4u                   /* KN_FLAG_ENG_SERVICE */
#define KN_T4_SCREEN  0x1C                 /* the screen id the engine's T4 page takes (the midi LFO class's, as quad) */
#define KN_KEY_T1     0x06                 /* R246 key codes T1..T4 0x06..0x09; encoder pushes 0x3B..0x3E */
#define KN_KEY_T4     0x09

/* The table entry of a loaded synth file for its order (kn_boot.c): the ext2 entry and its hook bits from the header
 * flags (any of bits 9..11), else 0 / 0. */
static inline uint8_t kn_eng_hooks_of(uint32_t flags, uint32_t f_input, uint32_t f_t4, uint32_t f_service)
{
    return (uint8_t)((flags & f_input ? KN_EH_INPUT : 0) | (flags & f_t4 ? KN_EH_T4 : 0) | (flags & f_service ? KN_EH_SERVICE : 0));
}

/* One event for an engine page: page OP1_ENG_T1 / _T2 / _T4, ev / a / b as op1_engine_ext2_t.input gets them; take: the
 * event goes nowhere else even when input returns 0 (on the engine's own T4 page: turns, pushes and the T4 key). */
typedef struct { int page, ev, a, b, take; } kn_eng_ev;
/* -> 1 when the R246 input event (type OP1_IN_KEY / OP1_IN_KNOB, code, pressed, delta) on that page goes to the engine:
 * encoder turns 0..3, encoder pushes 0x3B..0x3E (encoder code - 0x3B, kennel's press_knob order) and the keys T1..T4;
 * anything else (note keys, Shift, mode keys) never. */
static inline int kn_eng_event(int page, int type, int code, int pressed, int delta, kn_eng_ev *e)
{
    e->page = page; e->take = 0;
    if (type == OP1_IN_KNOB && code >= 0 && code < 4) { e->ev = OP1_ENG_TURN; e->a = code; e->b = delta; }
    else if (type == OP1_IN_KEY && code >= 0x3B && code <= 0x3E) { e->ev = OP1_ENG_PUSH; e->a = code - 0x3B; e->b = pressed != 0; }
    else if (type == OP1_IN_KEY && code >= KN_KEY_T1 && code <= KN_KEY_T4) { e->ev = OP1_ENG_KEY; e->a = code; e->b = pressed != 0; }
    else return 0;
    if (page == OP1_ENG_T4) e->take = e->ev != OP1_ENG_KEY || code == KN_KEY_T4;
    return 1;
}

/* Key pairing: a key's up goes where its down went. The T4 press that opens the engine's T4 page reaches R246 (the page
 * is not up yet), so its up must too; a down the engine took (on any page) takes its up, even when the page has changed.
 * idx: kn_eng_key_idx (0..7, -1 for a turn). down[idx]: 0 not taken, else the engine order + 1 that took it, with
 * *page the page it was on. */
static inline int kn_eng_key_idx(int type, int code)
{
    if (type != OP1_IN_KEY) return -1;
    if (code >= KN_KEY_T1 && code <= KN_KEY_T4) return code - KN_KEY_T1;
    if (code >= 0x3B && code <= 0x3E) return 4 + code - 0x3B;
    return -1;
}
typedef struct { uint8_t order[8], page[8]; } kn_eng_keys;
/* a key up: -> the order (and *page) that took its down, cleared; 0 when its down was not taken */
static inline int kn_eng_up_owner(kn_eng_keys *k, int idx, int *page)
{
    if (idx < 0 || !k->order[idx]) return 0;
    const int n = k->order[idx] - 1;
    *page = k->page[idx];
    k->order[idx] = 0;
    return n;
}
static inline void kn_eng_down(kn_eng_keys *k, int idx, int n, int page, int taken)
{
    if (idx >= 0) { k->order[idx] = (uint8_t)(taken ? n + 1 : 0); k->page[idx] = (uint8_t)page; }
}

/* T4: the screen entry KN_T4_SCREEN holds `target` (the current sound's T4 page object) or, with target 0, what this
 * host replaced (*prior). ours(p): p is one of the core's T4 page objects. Called at R246's T4 page choice
 * (kn_t4_screen_for, also from kn_eng_t4_sync when kn_t4_follow says so) and on every frame while the T4 page is up
 * (one engine's page to another's under it). */
static inline void kn_t4_swap(void **slot, void **prior, void *target, int (*ours)(const void *))
{
    if (target) {
        if (*slot == target) return;
        if (!ours(*slot)) *prior = *slot;                 /* the stock / quad object to give back */
        *slot = target;
        return;
    }
    if (ours(*slot)) *slot = *prior;                      /* (lfo_screen_select may already have replaced it: left) */
}

/* kn_eng_t4_sync's choice on the synth T4 page (each frame, Gfx). t4: the synth controller is on T4 (mode 0, page 3) and
 * the screen is one of R246's LFO screens 24..30; shown: screen 0x1C is current and holds one of the core's T4 page
 * objects; want: the current sound is a T4-page engine's. -> 1: redo R246's T4 page choice (kn_t4_screen_for) and show
 * the id it gives, as the T4 key does: the sound changed to a T4-page engine under a stock LFO page (24..30, mostly not
 * 0x1C), or from one under its page (the new sound's LFO type picks the stock screen). 0 in the steady states and for
 * an LFO plugin's page (quad: not shown, not wanted), so it acts once per change. */
static inline int kn_t4_follow(int t4, int shown, int want) { return t4 && shown != want; }

/* R246's LFO-off overlay ("LFO OFF" over a dimmed page; the lfo_bypass object, vtable 0x019106E4, slot 2 at
 * 0x019106F8: is it up on screen `id`): never on an engine's own T4 page. Its LFO is the engine's, which runs while
 * the stock one is held off below, so "LFO OFF" there read as dx's LFO being off (owner, 3.3 rc9). ours: screen 0x1C
 * holds one of the core's T4 page objects. -> 1: skip the stock check (no overlay). */
static inline int kn_lfo_overlay_skip(int id, int ours) { return id == KN_T4_SCREEN && ours; }

/* The stock LFO held off for a slot whose sound is a T4-page engine's (op1_plugin.h t4_page). owned: the slot's sound is
 * such an engine's; on: the live LFO-on flag; *held: this host cleared it; json_on: the sound's "lfo_active" (-1:
 * unreadable). -> the flag to write (0 / 1), or -1 for none. The JSON is never written. */
static inline int kn_lfo_hold_step(int owned, int on, uint8_t *held, int json_on)
{
    if (owned) {
        if (!on) return -1;
        *held = 1;
        return 0;
    }
    if (!*held) return -1;
    *held = 0;
    return json_on > 0 && !on ? 1 : -1;
}

/* the main-loop service: every engine with the service hook, in order (any sound current) */
static inline void kn_eng_service_all(void (*const *svc)(int, int32_t), const uint8_t *hooks, int n, int ev, int32_t arg)
{
    for (int i = 1; i < n; i++) if ((hooks[i] & KN_EH_SERVICE) && svc[i]) svc[i](ev, arg);
}

/* op1_engine_word_set's check: word k of a sound may be set to v */
static inline int kn_eng_word_ok(int k, int v) { return k >= 0 && k <= 7 && k != 4 && v >= 0 && v <= 32767; }
#endif
