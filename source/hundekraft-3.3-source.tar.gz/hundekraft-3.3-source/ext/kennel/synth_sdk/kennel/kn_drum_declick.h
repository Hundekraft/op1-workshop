/*
 * Drum sampler declick (2026-11-15, ARCHITECTURE.md "Drum sampler declick"): the arithmetic, shared by the core
 * (kennel/kn_drum.c, the DrumSampler vtable render slot) and the host test (harness/drum_declick_test.c).
 *
 * R246's DrumSampler voice (render 0x019789EC) plays a pad's slice with a hard edge at both ends: it starts at the
 * slice start whatever the sample there is, writes 0 from the first position past the slice end, and a gate release
 * (note_off sets state 0; so does a held loop's release) lets the L1 drum loop (0xFFA00684) render one more full
 * block before query (0x019788B0) returns 0 and the voice goes silent. A steal (all 12 voices busy, VoiceCtl takes the
 * one with the largest block count) restarts a sounding voice. Each edge is a step in the output: a click.
 *
 * The declick only scales the voice's output block after the render (128 samples at 88.2 kHz: N = 128 is 1.45 ms);
 * position, state, play value, pitch and the timing of every start and stop stay R246's:
 *   - fade-in: the first block after note_on (the play value +0x10 is 0: note_on clears it, every render counts it)
 *     ramps 1/IN .. 1 over its first IN samples;
 *   - gate / loop release: a block that starts with state 0 is the voice's last: it ramps 1 .. 1/N to its end;
 *   - slice end (one-shot, released loop; not a held loop, whose wrap is left alone): before the render, the samples
 *     the voice still plays (from the position, the slice bound and this block's step, as the render counts them) give
 *     a ramp OUT/OUT .. 1/OUT over the last OUT of them, across the block boundary if it falls there;
 *   - steal: note_on of a voice that still sounds (play value != 0) keeps its last output sample; the new note's
 *     first block adds it back as an offset that decays by 1/16 a sample (as kn_declick.h), so the old note's cut
 *     joins the new note's fade-in.
 * Integers only, no division (the samples-left count is an 8-step shift-subtract), and outside the edge blocks the
 * cost is a few loads and compares per voice block.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef KN_DRUM_DECLICK_H
#define KN_DRUM_DECLICK_H
#include <stdint.h>

#define KN_DDK_N      128      /* voice samples a block (88.2 kHz) */
#define KN_DDK_IN_SH  6        /* fade-in length 1 << 6 = 64 voice samples, 0.73 ms at 88.2 kHz (owner 2026-11-15; at most N) */
#define KN_DDK_OUT_SH 7        /* fade-out length 1 << 7 = 128 voice samples, 1.45 ms (at most N) */
#define KN_DDK_IN     (1 << KN_DDK_IN_SH)
#define KN_DDK_OUT    (1 << KN_DDK_OUT_SH)

/* per voice, across blocks */
typedef struct {
    int32_t off;               /* steal offset still to add, decays to 0 */
    uint32_t blk;              /* audio block of the last render */
    int16_t last;              /* last output sample of that render */
    int16_t pend;              /* steal offset for the next first block (note_on of a sounding voice) */
    uint8_t noend;             /* this note's position did not follow the prediction once: no end ramp */
} kn_ddk_voice;

/* one render: what to do to its output, from the voice before the render */
typedef struct {
    uint8_t in;                /* first block after note_on: fade in */
    uint8_t gate;              /* the voice's last block (state 0 on entry): fade out to the block end */
    int16_t left;              /* samples it plays before the slice end (0..255), -1: the end is further away */
    int32_t pos, step;         /* entry position and step (signed: reverse), for the check after the render */
} kn_ddk_plan;

/* a pad's slice bound from its hi / lo words, as R246's note_on 0x01978926 and render compute it (drumplus/dp_voice.c
 * dp_bound, the same arithmetic: the core has no drum+ linked) */
static inline int32_t kn_ddk_bound(int16_t hi_w, int16_t lo_w)
{
    int64_t s = (int64_t)(int32_t)((uint32_t)(uint16_t)hi_w << 16) + ((int32_t)((uint32_t)(uint16_t)lo_w << 16) >> 15);
    int32_t x = s > 0x7FFFFFFF ? 0x7FFFFFFF : s < -0x7FFFFFFFLL - 1 ? (int32_t)0x80000000 : (int32_t)s;
    int32_t h = x >> 16;
    uint32_t l = (uint32_t)x & 0xFFFF;
    /* 32-bit products (each fits), 64-bit sums only: no libgcc multiply */
    int64_t a1 = ((int64_t)(int32_t)(l >> 1) + (int32_t)(l * 0x4099u) + (int32_t)(h * 0x8000)) >> 15;
    int64_t r = (int64_t)(h * 0x4099 * 2) + a1;
    return r > 0x7FFFFFFF ? 0x7FFFFFFF : r < -0x7FFFFFFFLL - 1 ? (int32_t)0x80000000 : (int32_t)r;
}

/* pos / state / blocks: the voice's +8 / +0xC / +0x10 before the render; w: the pad words the render gets (0 pitch,
 * 1 / 5 start hi / lo, 2 / 6 end hi / lo, 3 playmode, 4 reverse); inc0: this block's first increment (the L1 loop
 * writes one value 128 times; the render steps inc >> 17 a sample) */
static inline void kn_ddk_pre(kn_ddk_plan *p, int32_t pos, int32_t state, uint32_t blocks, const int16_t *w, int32_t inc0)
{
    p->in = blocks == 0;
    p->gate = state == 0;
    p->left = -1;
    p->pos = pos;
    p->step = 0;
    if (((int32_t)w[3] >> 13) == 2 && state == 1) return;                  /* held loop: wraps, no end */
    int32_t step = inc0 >> 17;
    if (step <= 0) return;
    int32_t e;                                                              /* played: n * step <= e */
    if ((int32_t)w[4] >> 14) { e = pos - kn_ddk_bound(w[1], w[5]); p->step = -step; }   /* reverse: pos - n*step >= start */
    else { e = kn_ddk_bound(w[2], w[6]) - pos - 1; p->step = step; }       /* forward: pos + n*step < end */
    if (e < 0) { p->left = 0; return; }
    if (e >= step * (KN_DDK_N + KN_DDK_OUT - 1)) return;                    /* the fade starts in a later block */
    int32_t q = 0;                                                          /* q = e / step, q < 255 */
    for (int b = 7; b >= 0; b--)
        if (e >= (step << b)) { e -= step << b; q |= 1 << b; }
    p->left = (int16_t)(q + 1);
}

/* after the render: scale out[0..N) by the plan, add a steal offset, keep the last sample. pos / state: the voice
 * after the render. The ramps are applied only where the render did what the plan predicted (a drum type may change
 * the step, restart the position or revive the voice): the end ramp when the position moved exactly min(left, N)
 * steps (else none for the rest of the note), the release ramp when the state is still 0. blk: the audio block. */
static inline void kn_ddk_post(const kn_ddk_plan *p, kn_ddk_voice *s, int16_t *out, int32_t pos, int32_t state,
                               uint32_t blk)
{
    if (p->in) {
        for (int n = 0; n < KN_DDK_IN; n++) out[n] = (int16_t)((out[n] * (n + 1)) >> KN_DDK_IN_SH);
        s->off = s->pend;
        s->pend = 0;
        s->noend = 0;
    }
    if (p->left >= 0 && !s->noend && pos != p->pos + (p->left < KN_DDK_N ? p->left : KN_DDK_N) * p->step) s->noend = 1;
    if (p->left >= 0 && !s->noend) {
        int n = p->left - KN_DDK_OUT;
        if (n < 0) n = 0;
        int e = p->left < KN_DDK_N ? p->left : KN_DDK_N;
        for (; n < e; n++) out[n] = (int16_t)((out[n] * (p->left - n)) >> KN_DDK_OUT_SH);
    }
    if (p->gate && state == 0)
        for (int n = 0; n < KN_DDK_N; n++) out[n] = (int16_t)((out[n] * (KN_DDK_N - n)) >> 7);
    int32_t off = s->off;
    for (int n = 0; off && n < KN_DDK_N; n++) {
        int32_t v = out[n] + off;
        out[n] = (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v);
        int32_t d = off >> 4;
        if (!d) d = off > 0 ? 1 : -1;
        off -= d;
    }
    s->off = off;
    s->last = out[KN_DDK_N - 1];
    s->blk = blk;
}

/* note_on (before R246's): blocks = the voice's play value, != 0 while it still sounds (a steal); blk: the audio
 * block. The last sample counts only if the voice rendered in this block or the one before (a rebuilt kit or mode
 * change can leave a stale play value). */
static inline void kn_ddk_note_on(kn_ddk_voice *s, uint32_t blocks, uint32_t blk)
{
    s->pend = blocks && blk - s->blk <= 1u ? s->last : 0;
}

#endif
