/* Sound naming: hold a sound key to save, keep holding and a letter grid opens; press the same sound key again to
 * save under the typed name, as Maiko Pruett's #249 does. A clean re-implementation from the behaviour in
 * docs/maiko-rebuild.md (no #249 code or bytes). Also the preset tools (our own design, OP1-Emulator
 * docs/trigger-guard-preset-tools-plan-2026-11-09.md section 2; core side kennel/kn_preset_tools.c):
 *   - overwrite: hold SYNTH (or DRUM) and a sound key through the save clock: the save screen says OVERWRITING and
 *     the slot's sound replaces the user preset it was loaded from (its name stays). A factory or unsaved sound
 *     gets the normal grid (a new preset).
 *   - the grid starts with the slot's preset name (factory names too); confirming a taken name gives R246's _1.
 *   - in the sound preset browser (Shift + a sound key), a user preset selected: the white push renames it (the
 *     grid, with its name); Shift + white held through the save clock (DELETING) deletes it, letting go cancels.
 *     Factory presets: a toast. Stock R246 uses none of the four encoder pushes in the browser (mode 8's key
 *     handler 0x01A16F8C passes 0x3B..0x3E on, and the global handler ignores them).
 *
 * When R246's hold-to-save is about to save (OP1_EV_SAVE_HOLD, kennel/kn_save.c) naming holds the save back
 * (op1_snapshot_defer) and opens the core's text entry: the wide grid below, up to 12 characters (#249's limit).
 * The same sound key pressed again finishes it and R246 saves that sound under the name (op1_snapshot_save; R246
 * adds _1, _2 when the name is taken). A mode key or an empty name saves under R246's own date stamp. Releases are
 * not presses, so the release of the key that opened the grid does nothing.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#pragma GCC optimize("no-tree-loop-distribute-patterns")          /* a plugin file imports no memcpy / memset */
#include "../op1_feature.h"
#include "../screens/stroke_font.h"

#define NAMING_MAX 12
#define MODE_BROWSER 8                         /* R246's list picker (the preset browser) */
#define KEY_WHITE 0x3D                         /* encoder pushes 0x3B..0x3E: blue, green, white, red */
#define KEY_SHIFT 0x26
#define DELETE_PASSES 400                      /* as the stock clock: 400 main loop passes, drawn from 320 */
/* key codes of sound keys 1..8: 1..3 are 0x2D..0x2F, 4..8 are 0x10..0x14 (op1emu gui/ui.json, docs/firmware/input.md;
 * seq is 0x15 right after sound key 8). Found in the emulator: a table in key order missed the confirm. */
static const uint8_t sound_key[8] = {0x2D, 0x2E, 0x2F, 0x10, 0x11, 0x12, 0x13, 0x14};

static volatile int nm_kind = -1, nm_slot;     /* the held-back save; -1: none */
static volatile int nm_renaming;               /* the grid is a rename (nm_ref) */
static op1_preset_ref nm_ref;                  /* the browser entry being renamed or deleted */
static volatile int nm_del = -1;               /* delete clock: passes left, -1 none */
static volatile uint8_t nm_white_down;         /* our white press: its release is ours too */

static void nm_done(const char *text, int ok)  /* main loop */
{
    if (nm_renaming) {
        nm_renaming = 0;
        if (ok && text[0]) op1_preset_rename(&nm_ref, text);   /* toasts "renamed" or why not */
        return;
    }
    int kind = nm_kind;
    nm_kind = -1;
    if (kind < 0) return;
    if (op1_snapshot_save(kind, nm_slot, ok ? text : "")) op1_toast("sound not saved");
}

static int nm_entry_key(int code, int pressed, int shift)   /* KeyHandler, before the entry's own handling */
{
    (void)shift;
    if (!pressed || nm_renaming || nm_kind < 0 || code != sound_key[nm_slot]) return 0;   /* releases and other keys: the entry's */
    op1_text_entry_close(1);                    /* the same sound key again: save under the name */
    return 1;
}

/* the wide knob-coded grid : 13 per row, a..z, then digits, '-', '_' and space. R246 takes all three: factory
 * presets use space and '-' ("low end", "k-pulse"), its own snapshot names '_' (%i%02i%02i_%02i%02i, _%d). */
static const char nm_charset[] = "abcdefghijklm" "nopqrstuvwxyz" "0123456789-_ ";
static char nm_initial[NAMING_MAX + 1];
static op1_text_entry_t nm_entry = { "NAME", nm_initial, nm_charset, NAMING_MAX, 13, nm_done, nm_entry_key };

/* the grid's start text: a preset name in the grid's characters (capitals lowered), cut to 12; "" otherwise */
static void nm_prefill(const char *name)
{
    int n = 0;
    nm_initial[0] = 0;
    for (; name && name[n] && n < NAMING_MAX; n++) {
        char c = name[n];
        if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
        if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == ' ')) { nm_initial[0] = 0; return; }
        nm_initial[n] = c;
    }
    while (n && nm_initial[n - 1] == ' ') n--;
    nm_initial[n] = 0;
}

static void ref_copy(op1_preset_ref *d, const op1_preset_ref *s)   /* not "*d = *s": GCC makes that a memcpy call */
{
    const volatile uint8_t *a = (const volatile uint8_t *)s;
    uint8_t *b = (uint8_t *)d;
    for (unsigned i = 0; i < sizeof *d; i++) b[i] = a[i];
}

static void nm_del_stop(int hide)
{
    if (nm_del < 0) return;
    nm_del = -1;
    if (hide) op1_save_clock_show(nm_ref.kind, -1, -1);
}

static void nm_event(int id, int32_t arg)       /* main loop */
{
    if (id == OP1_EV_SERVICE) {                 /* the delete clock */
        if (nm_del < 0) return;
        op1_preset_ref cur;
        if (op1_preset_pick(&cur) < 0) { nm_del_stop(1); return; }   /* the browser was left */
        int left = --nm_del;
        if (left >= 0) { if (left <= 320) op1_save_clock_show(nm_ref.kind, -1, left); return; }
        nm_del = -1;
        if (op1_preset_delete(&nm_ref)) op1_save_clock_show(nm_ref.kind, -1, -3);   /* the core toasts and ticks */
        return;
    }
    if (id != OP1_EV_SAVE_HOLD || op1_text_entry_open()) return;
    int kind = arg >> 8 & 0xff, slot = arg & 0xff;
    if (kind > 1 || slot > 7) return;
    if (op1_mode_key_held(kind) && op1_preset_overwrite(kind, slot) == 0) {   /* SYNTH / DRUM held: overwrite */
        op1_snapshot_defer();
        return;
    }
    op1_preset_ref src;
    nm_prefill(op1_preset_source(kind, slot, &src) >= 0 ? src.name : 0);
    nm_entry.title = "NAME";
    nm_kind = kind; nm_slot = slot;
    if (op1_text_entry(&nm_entry)) { nm_kind = -1; return; }   /* no grid: stock saves under its stamp */
    op1_snapshot_defer();
}

static int nm_input(const op1_input *in)       /* KeyHandler: the preset browser's white push */
{
    if (in->type != OP1_IN_KEY) return 0;
    if (!in->pressed) {
        if (in->code == KEY_SHIFT) { nm_del_stop(1); return 0; }   /* Shift goes on to R246 */
        if (in->code != KEY_WHITE || !nm_white_down) return 0;
        nm_white_down = 0;
        nm_del_stop(1);                         /* let go before the clock ran out: nothing deleted */
        return 1;
    }
    if (in->code != KEY_WHITE || in->mode != MODE_BROWSER || op1_text_entry_open()) return 0;
    op1_preset_ref r;
    int user = op1_preset_pick(&r);
    if (user < 0) return 0;                     /* another list (engines, FX, LFO, sequencers): not ours */
    if (!user) { nm_white_down = 1; op1_toast("factory preset"); return 1; }
    ref_copy(&nm_ref, &r);
    if (in->shift) { nm_white_down = 1; nm_del = DELETE_PASSES; return 1; }
    /* rename: the release goes to the text entry (it passes it on to R246), so it is not marked as ours */
    nm_prefill(r.name);
    nm_entry.title = "RENAME";
    nm_renaming = 1;
    if (op1_text_entry(&nm_entry)) nm_renaming = 0;
    return 1;
}

/* the save screen's band (save.svg, drawn 1:1 from its coordinates, measured in a native capture): black x 69..273,
 * y 65..99; SAVING in strokes at x 85..162, y 71..92; the slot's wave icon from x 184, the clock at x 238..258. Our
 * word replaces SAVING: the letters are covered with black (12 px lines, kn_text.c's way: x 69..182, y 68..94) and the
 * word is drawn in the stroke font in SAVING's colour, x 72..175 (11 characters at 1.5625), y 77..86. */
static void nm_overlay(void *r, int32_t screen)
{
    static const uint8_t lavender[4] = { 0xD7, 0xD7, 0xFF, 0xFF }, black[4] = { 0, 0, 0, 0xFF };
    (void)screen;
    int kind, slot;
    if (!op1_save_clock(&kind, &slot)) return;
    const char *word = 0;
    op1_preset_ref src;
    if (nm_del >= 0) word = "DELETING";
    else if (op1_mode_key_held(kind) && op1_preset_source(kind, slot, &src) == 1) word = "OVERWRITING";
    if (!word) return;
    for (int y = 74; y <= 88; y += 7) sf_line(r, OP1_Q10(75), OP1_Q10(y), OP1_Q10(176), OP1_Q10(y), OP1_Q10(12), black);
    sf_text(r, OP1_Q10(72), OP1_Q10(77), 1600, word, 0x600, lavender);
}

/* one feature holds the hold-to-save back; the browser's white push and Shift + white are ours */
static const char *const nm_claims[] = { "snapshot.save", "key:browser:white", "key:browser:shift+white", 0 };
const op1_feature_t FEATURE_naming = {
    .api = OP1_FEATURE_API, .priority = 600, .name = "naming", .event = nm_event, .input = nm_input,
    .overlay = nm_overlay, .claims = nm_claims,
};
