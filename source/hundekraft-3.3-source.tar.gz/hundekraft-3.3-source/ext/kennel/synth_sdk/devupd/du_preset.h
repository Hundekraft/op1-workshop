/* User presets over SysEx, the pure part (kennel/kn_presets.c is the firmware side; docs/inventory.md "Presets"):
 * reading an OP-1 patch AIFF (FORM AIFC / AIFF; COMM, APPL "op-1" + JSON, SSND) and preparing its JSON for R246's own
 * insert (fat_interface 0x019955EC: parse, parse_patch_json, INSERT INTO <table> (patch,folder) VALUES('%s','%s')).
 * No libc: the same code runs in the host tests (harness/devupd_test.c) and in the firmware.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef DU_PRESET_H
#define DU_PRESET_H
#include <stdint.h>

#define DU_PJSON_MAX   7680                 /* JSON bytes: R246 formats the INSERT into an 8 KB buffer (0x01CFEBC0) */
#define DU_SYNTH_RAW_MAX  529200u           /* a sampler preset's sample: 6 s (R246's synth_<n>.raw size) */
#define DU_DRUM_RAW_MAX   1058400u          /* a drum kit: 12 s */

typedef struct {
    uint32_t json_off, json_len;            /* the APPL chunk's text after "op-1" (0 if there is none) */
    uint32_t snd_off, snd_len;              /* SSND sample bytes (after its offset / block size words) */
    int channels, bits, little;             /* COMM; little: AIFC 'sowt' (else big-endian samples) */
} du_aif;
/* read(ctx, off, dst, n): exactly n bytes at off, 0 ok. size: the file's length. 0 ok, else a reason:
 * 1 not FORM AIFF / AIFC, 2 bad chunk, 3 no COMM, 4 no op-1 APPL, 5 compression not NONE / sowt */
int du_aif_scan(int (*read)(void *ctx, uint32_t off, uint8_t *dst, uint32_t n), void *ctx, uint32_t size, du_aif *a);
/* the patch JSON (n bytes, trailing blanks / NULs dropped) with its "name" set to name, into out (cap bytes, NUL
 * terminated): the length, or -1: not one JSON object, no or several "name" keys, a ' anywhere (R246 quotes the
 * INSERT with '), a backslash or control byte in the name's old value, too long */
int du_preset_json(const char *in, int n, const char *name, char *out, int cap);
/* 1 if the patch's "type" is "sampler" (its sound is a sample: the .raw holds it) */
int du_preset_sampler(const char *json);
#endif
