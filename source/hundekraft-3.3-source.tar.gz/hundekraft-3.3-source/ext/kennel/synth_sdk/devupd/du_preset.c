/* User presets over SysEx, the pure part: see du_preset.h.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "du_preset.h"

static uint32_t be32(const uint8_t *p) { return (uint32_t)p[0] << 24 | (uint32_t)p[1] << 16 | (uint32_t)p[2] << 8 | p[3]; }
static int id_is(const uint8_t *p, const char *s) { return p[0] == s[0] && p[1] == s[1] && p[2] == s[2] && p[3] == s[3]; }

int du_aif_scan(int (*read)(void *ctx, uint32_t off, uint8_t *dst, uint32_t n), void *ctx, uint32_t size, du_aif *a)
{
    uint8_t h[26];
    a->json_off = a->json_len = a->snd_off = a->snd_len = 0; a->channels = a->bits = a->little = 0;
    if (size < 12 || read(ctx, 0, h, 12) || !id_is(h, "FORM")) return 1;
    int aifc = id_is(h + 8, "AIFC");
    if (!aifc && !id_is(h + 8, "AIFF")) return 1;
    uint32_t end = be32(h + 4) + 8 < size ? be32(h + 4) + 8 : size;    /* (a FORM size past the file: the file) */
    int comm = 0;
    for (uint32_t at = 12; at + 8 <= end;) {
        if (read(ctx, at, h, 8)) return 2;
        uint32_t len = be32(h + 4), body = at + 8;
        if (len > end - body) return 2;
        if (id_is(h, "COMM")) {
            if (len < 18 || read(ctx, body, h, len < 22 ? 18 : 22)) return 2;
            a->channels = h[0] << 8 | h[1]; a->bits = h[6] << 8 | h[7];
            if (aifc && len >= 22) {
                if (id_is(h + 18, "sowt")) a->little = 1;
                else if (!id_is(h + 18, "NONE")) return 5;
            }
            comm = 1;
        } else if (id_is(h, "APPL")) {
            if (len >= 4 && !read(ctx, body, h, 4) && id_is(h, "op-1") && !a->json_len) {
                a->json_off = body + 4; a->json_len = len - 4;
            }
        } else if (id_is(h, "SSND")) {
            if (len >= 8) { a->snd_off = body + 8; a->snd_len = len - 8; }
        }
        at = body + len + (len & 1);                              /* chunks are padded to even lengths */
    }
    if (!comm) return 3;
    if (!a->json_len) return 4;
    return 0;
}

static int key_at(const char *p, const char *k)                   /* "k" at p */
{
    if (*p++ != '"') return 0;
    while (*k) if (*p++ != *k++) return 0;
    return *p == '"';
}

int du_preset_json(const char *in, int n, const char *name, char *out, int cap)
{
    while (n > 0 && (in[n - 1] == ' ' || in[n - 1] == 0 || in[n - 1] == '\n' || in[n - 1] == '\r' || in[n - 1] == '\t')) n--;
    int b = 0;
    while (b < n && (in[b] == ' ' || in[b] == '\n' || in[b] == '\r' || in[b] == '\t')) b++;
    if (n - b < 2 || in[b] != '{' || in[n - 1] != '}') return -1;
    int at = -1, vs = -1, ve = -1, instr = 0;
    for (int i = b; i < n; i++) {
        char c = in[i];
        if (c == '\'' || c == 0) return -1;                       /* the INSERT quotes with ' (and C strings end at 0) */
        if (instr) { if (c == '\\') i++; else if (c == '"') instr = 0; continue; }
        if (c != '"') continue;
        if (i + 6 <= n && key_at(in + i, "name")) {
            int j = i + 6;
            while (j < n && (in[j] == ' ' || in[j] == '\t' || in[j] == '\n' || in[j] == '\r')) j++;
            if (j < n && in[j] == ':') {                          /* a key, not a value "name" */
                if (at >= 0) return -1;                           /* several: which one would R246 use? */
                at = i; j++;
                while (j < n && (in[j] == ' ' || in[j] == '\t' || in[j] == '\n' || in[j] == '\r')) j++;
                if (j >= n || in[j] != '"') return -1;
                vs = j; ve = j + 1;
                while (ve < n && in[ve] != '"') { if (in[ve] == '\\' || in[ve] == '\'' || (unsigned char)in[ve] < 0x20) return -1; ve++; }
                if (ve >= n) return -1;
                i = ve;                                           /* past the value */
                continue;
            }
        }
        instr = 1;
    }
    if (at < 0 || instr) return -1;
    int o = 0, nl = 0;
    while (name[nl]) nl++;
    if ((n - b) - (ve - vs - 1) + nl + 1 > cap) return -1;
    for (int i = b; i <= vs; i++) out[o++] = in[i];
    for (int i = 0; i < nl; i++) out[o++] = name[i];
    for (int i = ve; i < n; i++) out[o++] = in[i];
    out[o] = 0;
    return o;
}

int du_preset_sampler(const char *j)
{
    for (; *j; j++) {
        if (!key_at(j, "type")) continue;
        const char *p = j + 6;
        while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
        if (*p++ != ':') continue;
        while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
        if (key_at(p, "sampler")) return 1;
    }
    return 0;
}
