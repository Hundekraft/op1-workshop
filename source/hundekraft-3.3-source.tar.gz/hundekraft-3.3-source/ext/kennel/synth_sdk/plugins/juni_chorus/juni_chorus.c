/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* "juni chorus": a stereo ensemble chorus in the manner of an early-80s polysynth BBD chorus (modes I, II, I+II).
 * Pairs with the JUNI engine; see README.md.
 *
 *   blue  (knob 0): MODE. I (slow) -> II (a bit faster) -> I+II (fast and shallow), smooth crossfades between
 *   green (knob 1): DEPTH of the delay sweep (never fully off)
 *   white (knob 2): TONE: the corner of the wet path's last pole, from 17.5 kHz (FM-106's line driver) down to 1.3 kHz
 *   red   (knob 3): MIX: the dry falls 1 -> 0.647 as the wet rises 0 -> 0.943 (FM-106's 0.863 : 1.257 at the top)
 *
 * The voicing is FM-106's chorus (PatttF/fm-106 48ca1b6, `fm106_chorus.h`, from Ultramaster KR-106; see PROVENANCE.md):
 * a 9.66 kHz 2nd-order Butterworth before the delay line and another after it, centre 3.5 ms, I 0.514 Hz +-81
 * samples, II 0.863 Hz +-75, I+II 9.75 Hz +-9 (the triangle rounded to 1.5 x - 0.5 x^3, both sides in phase), 4-point
 * Hermite reads, the 106's dry : wet ratio and a rational soft limiter at the output. One modulated delay per side:
 *   stereo (master): L = dry + delay(L, centre + lfo), R = dry + delay(R, centre - lfo) (I and II: two BBDs in
 *                    opposite phase; into I+II the right side's sign glides to +, as FM-106 has them together)
 *   mono (synth, drum): dry + delay(x, centre + lfo), the left side alone, as the original's mono output
 * Integers only. 16 x 16 products are one Blackfin fractional multiply (fmul). The state is tiny (two 256 sample
 * rings per position, mono uses one), so it lives in .bss and needs no scratch memory. Each 64 sample block runs in small passes.
 * Rate: R246 calls an FX with 64 samples at 44,100 Hz; every constant below is at that rate (2026-11-03: they were
 * written for 22,050 Hz, so the LFOs ran at twice their rates and the delays at half their times on the unit).
 */
#include "op1_plugin.h"

#define RING   256                       /* samples per ring: longest delay 234 + 1, read before the block is written */
#define CENTRE (154 << 8)                /* Q8 samples: 3.5 ms at 44.1 kHz */
#define SWEEP1 (81 << 8)                 /* Q8: I +-1.85 ms, so 1.66 .. 5.35 ms at full depth */
#define SWEEP2 (75 << 8)                 /* II +-1.7 ms */
#define SWEEP3 (9 << 8)                  /* I+II +-0.2 ms */
/* the read pass runs before the write pass: the shortest delay must lie behind the whole block (the Hermite read
 * takes one sample newer), the longest within the ring (it takes two older) */
_Static_assert(CENTRE - SWEEP1 >= (OP1_FX_BLOCK + 2) << 8 && CENTRE + SWEEP1 + (3 << 8) < RING << 8, "ring");

/* LFO increments per sample at 44.1 kHz, FM-106's own constants */
#define INC_I   50098u                   /* 0.514 Hz */
#define INC_II  84114u                   /* 0.863 Hz */
#define INC_III 950112u                  /* 9.75 Hz */

typedef struct {
    int16_t ring[2][RING];
    int32_t bq[2][6];                    /* per side: the pre-line and post-line Butterworth states (ic1, ic2 each) and
                                          * the TONE pole (index 2 of the post part; the sixth is unused); the Butterworth states in quarter scale (sample >> 2) */
    uint32_t w, ph;
    int32_t depth;                       /* Q16 of the Q8 sweep, ramped over each block */
} state_t;

static state_t st[3];
volatile uint32_t juni_chorus_blocks[3];
/* what the screen (juni_chorus_screen.c) reads, written once per block, never read back here: the LFO phase after the
 * block, its increment, the ramped sweep (Q8 samples) and the input's peak (every 8th sample) */
volatile uint32_t juni_chorus_ph[3], juni_chorus_inc[3];
volatile int32_t juni_chorus_depth[3];
volatile int16_t juni_chorus_level[3];

static void telemetry(int pos, const state_t *s, uint32_t inc, const int16_t *a, const int16_t *b)
{
    int32_t pk = 0;
    for (int i = 0; i < OP1_FX_BLOCK; i += 8) {
        int32_t v = a[i] < 0 ? -a[i] : a[i];
        if (v > pk) pk = v;
        if (b) { v = b[i] < 0 ? -b[i] : b[i]; if (v > pk) pk = v; }
    }
    juni_chorus_ph[pos] = s->ph;
    juni_chorus_inc[pos] = inc;
    juni_chorus_depth[pos] = s->depth >> 16;
    juni_chorus_level[pos] = (int16_t)(pk > 32767 ? 32767 : pk);
}

/* (a * b) << 1 for 16-bit a and b: one fractional multiply on Blackfin (a plain int product is a 32 x 32 one) */
#ifdef __bfin__
static inline __attribute__((always_inline)) int32_t fmul(int32_t a, int32_t b)
{ return __builtin_bfin_mult_fr1x32((short)a, (short)b); }
#else
static inline int32_t fmul(int32_t a, int32_t b)
{ int32_t p = (int32_t)(int16_t)a * (int16_t)b; return p == 0x40000000 ? 0x7FFFFFFF : p * 2; }
#endif

static void init(int pos)
{
    state_t *s = &st[(unsigned)pos > 2 ? 0 : pos];
    for (int i = 0; i < RING; i++) s->ring[0][i] = s->ring[1][i] = 0;
    for (int i = 0; i < 6; i++) s->bq[0][i] = s->bq[1][i] = 0;
    s->w = 0;
    s->ph = 0;
    s->depth = 0;
}

typedef struct { uint32_t inc; int32_t depth_q8, a, gd, gw, sgn, t2; } block_t;

/* the four knobs (Q15) -> what this block needs */
static void block_params(block_t *b, const int16_t *p)
{
    const int32_t k0 = op1_fx_param_q15(p, 0), k1 = op1_fx_param_q15(p, 1);
    const int32_t k2 = op1_fx_param_q15(p, 2), k3 = op1_fx_param_q15(p, 3);
    /* MODE: I below 9216, II 13312..19456, I+II above 23552; linear ramps between (4096 wide) */
    int32_t t1 = (k0 - 9216) * 8, t2 = (k0 - 19456) * 8;
    t1 = t1 < 0 ? 0 : (t1 > 32767 ? 32767 : t1);
    t2 = t2 < 0 ? 0 : (t2 > 32767 ? 32767 : t2);
    const uint32_t r2 = INC_I + (uint32_t)(((int32_t)(INC_II - INC_I) * t1) >> 15);
    b->inc = r2 + (uint32_t)((((int32_t)(INC_III - INC_II) >> 6) * t2) >> 9);
    const int32_t d2 = SWEEP1 - (((SWEEP1 - SWEEP2) * t1) >> 15);             /* 20736 * 32767 < 2^31 */
    const int32_t dm = d2 - (((d2 - SWEEP3) * t2) >> 15);
    const int32_t dk = 6554 + ((k1 * 26214) >> 15);                           /* 0.2 .. 1.0: never fully static */
    b->depth_q8 = fmul(dm, dk) >> 16;
    b->t2 = t2;
    b->sgn = 2 * t2 - 32767;                                                  /* the right tap: -1 (I, II) .. +1 (I+II) */
    /* TONE: the wet's last one-pole, y += (x - y) a: 0.7495 (17.5 kHz, FM-106's line driver) .. 0.169 (1.3 kHz) */
    b->a = 24557 - ((k2 * 19017) >> 15);
    b->gd = 32767 - ((k3 * 11559) >> 15);                                     /* the dry falls to 0.647 (21209 / 32768) */
    b->gw = (k3 * 30892) >> 15;                                               /* the wet rises to 0.943 (FM-106's 1.257 / 0.863 x 0.647) */
}

/* pass 1: the LFO as a signed delay offset in Q8 samples (-depth .. +depth) for the left tap, the depth ramped to its new
 * value; the triangle goes towards a sine as the mode goes to I+II (1.5 x - 0.5 x^3, the analog RC rounding) */
static void lfo_pass(state_t *s, const block_t *b, uint32_t inc, int16_t *off)
{
    int32_t d = s->depth;
    const int32_t dd = ((b->depth_q8 << 16) - d) >> 6;
    const int32_t h = b->t2 >> 1;
    uint32_t ph = s->ph;
    for (int i = 0; i < OP1_FX_BLOCK; i++) {
        const int32_t t = (int32_t)ph >> 16;                 /* saw -32768 .. 32767 */
        int32_t tri = 2 * (t ^ (t >> 31)) - 32767;           /* triangle */
        const int32_t x2 = fmul(tri, tri) >> 16;             /* x^2, Q15 */
        tri += fmul(fmul(tri, 32767 - x2) >> 16, h) >> 16;   /* tri + t2 x (1 - x^2) / 2 */
        off[i] = (int16_t)(fmul(d >> 16, tri) >> 16);
        d += dd;
        ph += inc;
    }
    s->depth = d;
    s->ph = ph;
}

/* the right tap's offsets: the left's times sgn (-1 .. +1) */
static void flip_pass(const int16_t *off, int32_t sgn, int16_t *offr)
{
    for (int i = 0; i < OP1_FX_BLOCK; i++) offr[i] = (int16_t)(fmul(off[i], sgn) >> 16);
}

/* FM-106's 2nd-order Butterworth at 9,661 Hz, TPT form (g 0.82608, a1 0.35199, a2 0.29074), in quarter scale: x and
 * the result are sample >> 2, so no state can leave 16 bits (a full-scale step overshoots by a few %) and the
 * fractional multiplies need no clamps */
#define BQ_A1 11534
#define BQ_A2 9527
#define BQ_G  27068
static inline int32_t bq_step(int32_t *st, int32_t x)
{
    const int32_t ic1 = st[0], ic2 = st[1];
    const int32_t v3 = x - ic2;
    const int32_t v1 = (fmul(ic1, BQ_A1) + fmul(v3, BQ_A2) + 32768) >> 16;
    const int32_t v2 = ic2 + ((fmul(v1, BQ_G) + 32768) >> 16);
    st[0] = 2 * v1 - ic1;
    st[1] = 2 * v2 - ic2;
    return v2;
}
/* after a block: the rounded integer poles can sit in a limit cycle of a few LSB once a sound has ended; with the last
 * input zero and the states this small, they are zero */
static inline void bq_settle(int32_t *st, int32_t last_x)
{
    if (!last_x && st[0] > -4 && st[0] < 4 && st[1] > -4 && st[1] < 4) st[0] = st[1] = 0;
}

/* pass 2 (after the read): the input through the pre-line Butterworth into the ring */
static void write_pass(int16_t *ring, uint32_t w, const int16_t *in, int32_t *st)
{
    for (int i = 0; i < OP1_FX_BLOCK; i++) ring[(w + (uint32_t)i) & (RING - 1)] = (int16_t)(bq_step(st, in[i] >> 2) * 4);
    bq_settle(st, in[OP1_FX_BLOCK - 1] >> 2);
}

/* pass 3: one 4-point Hermite tap, CENTRE + off behind the write position: the value at pos = n - delay lies between
 * ring[k] and ring[k + 1] (k = floor(pos)) at t = pos - k, with ring[k - 1] and ring[k + 2] as neighbours; Horner form on half-scale samples */
static void read_pass(const int16_t *ring, uint32_t w, const int16_t *off, int16_t *out)
{
    for (int i = 0; i < OP1_FX_BLOCK; i++) {
        const uint32_t pos = ((w + (uint32_t)i) << 8) - (uint32_t)(CENTRE + off[i]);
        const uint32_t k = (pos >> 8) & (RING - 1);          /* the sample D back */
        const int32_t t = (int32_t)(pos & 255) << 7;         /* Q15: how far towards D + 1 back? (position falls) */
        const int32_t y0 = ring[(k - 1) & (RING - 1)] >> 1, y1 = ring[k] >> 1;      /* half scale: no coefficient can leave */
        const int32_t y2 = ring[(k + 1) & (RING - 1)] >> 1, y3 = ring[(k + 2) & (RING - 1)] >> 1;   /* 16 bits */
        const int32_t c1 = (y2 - y0) >> 1;
        const int32_t c2 = y0 - ((5 * y1) >> 1) + 2 * y2 - (y3 >> 1);
        const int32_t c3 = ((y3 - y0) >> 1) + ((3 * (y1 - y2)) >> 1);
        int32_t r = c2 + (fmul(c3, t) >> 16);
        r = c1 + (fmul(r, t) >> 16);
        r = y1 + (fmul(r, t) >> 16);
        out[i] = (int16_t)op1_sat16(2 * r);
    }
}

/* pass 4: the wet path after the line: the second Butterworth, then the TONE pole, y += (x - y) a (rounded) */
static void lp_pass(int16_t *x, int32_t *st, int32_t a)
{
    int32_t y = st[2];
    const int32_t last = x[OP1_FX_BLOCK - 1] >> 2;
    for (int i = 0; i < OP1_FX_BLOCK; i++) {
        const int32_t v = bq_step(st, x[i] >> 2) * 4;
        y += (fmul((v - y) >> 1, a) + 16384) >> 15;
        x[i] = (int16_t)y;
    }
    bq_settle(st, last);
    if (!last && y > -4 && y < 4) y = 0;                     /* the rounded pole stalls a few LSB from zero */
    st[2] = y;
}

/* FM-106's output limiter (fm106_soft_limit): linear to 24576, then 24576 + 7424 e / (7424 + e) in e = |x| - 24576,
 * asymptote 32000. The division is a 257-entry table over e in steps of 512 with a linear read (gen above; error under
 * 9 units); e beyond 131071 saturates at the last entry. */
static const int16_t LIMTAB[257] = {
    0, 479, 900, 1273, 1605, 1904, 2173, 2417, 2640, 2843, 3030, 3203,
    3362, 3510, 3647, 3775, 3895, 4007, 4112, 4211, 4304, 4392, 4475, 4553,
    4628, 4699, 4766, 4830, 4891, 4949, 5005, 5058, 5109, 5158, 5204, 5249,
    5292, 5334, 5374, 5412, 5449, 5484, 5519, 5552, 5584, 5615, 5645, 5674,
    5702, 5729, 5755, 5781, 5805, 5829, 5852, 5875, 5897, 5918, 5939, 5959,
    5979, 5998, 6017, 6035, 6053, 6070, 6087, 6103, 6119, 6135, 6150, 6165,
    6180, 6194, 6208, 6221, 6235, 6248, 6260, 6273, 6285, 6297, 6308, 6320,
    6331, 6342, 6353, 6363, 6374, 6384, 6394, 6404, 6413, 6423, 6432, 6441,
    6450, 6459, 6467, 6476, 6484, 6492, 6500, 6508, 6516, 6523, 6531, 6538,
    6545, 6552, 6559, 6566, 6573, 6580, 6586, 6593, 6599, 6605, 6612, 6618,
    6624, 6630, 6635, 6641, 6647, 6652, 6658, 6663, 6669, 6674, 6679, 6684,
    6689, 6694, 6699, 6704, 6709, 6713, 6718, 6723, 6727, 6732, 6736, 6741,
    6745, 6749, 6753, 6757, 6762, 6766, 6770, 6774, 6777, 6781, 6785, 6789,
    6793, 6796, 6800, 6804, 6807, 6811, 6814, 6818, 6821, 6824, 6828, 6831,
    6834, 6837, 6841, 6844, 6847, 6850, 6853, 6856, 6859, 6862, 6865, 6868,
    6871, 6873, 6876, 6879, 6882, 6884, 6887, 6890, 6892, 6895, 6898, 6900,
    6903, 6905, 6908, 6910, 6913, 6915, 6917, 6920, 6922, 6924, 6927, 6929,
    6931, 6934, 6936, 6938, 6940, 6942, 6944, 6947, 6949, 6951, 6953, 6955,
    6957, 6959, 6961, 6963, 6965, 6967, 6969, 6971, 6973, 6975, 6976, 6978,
    6980, 6982, 6984, 6986, 6987, 6989, 6991, 6993, 6994, 6996, 6998, 6999,
    7001, 7003, 7004, 7006, 7008, 7009, 7011, 7012, 7014, 7015, 7017, 7019,
    7020, 7022, 7023, 7025, 7026,
};
static inline int32_t soft_limit(int32_t x)
{
    const int32_t ax = x < 0 ? -x : x;
    if (ax <= 24576) return x;
    int32_t e = ax - 24576;
    if (e > 131071) e = 131071;
    const int32_t i = e >> 9, f = e & 511;
    const int32_t c = 24576 + LIMTAB[i] + (fmul(LIMTAB[i + 1] - LIMTAB[i], f << 6) >> 16);
    return x < 0 ? -c : c;
}

/* pass 5: the mix into io: dry gd + wet gw, through the limiter (MIX 0 leaves the dry untouched) */
static void mix_pass(int16_t *io, const int16_t *wet, int32_t gd, int32_t gw)
{
    if (!gw) return;
    for (int i = 0; i < OP1_FX_BLOCK; i++) {
        const int32_t m = ((fmul(io[i], gd) >> 1) + (fmul(wet[i], gw) >> 1)) >> 15;
        io[i] = (int16_t)soft_limit(m);
    }
}

static void stereo(int pos, int16_t *l, int16_t *r, const int16_t *p)
{
    state_t *s = &st[(unsigned)pos > 2 ? 0 : pos];
    block_t b;
    int16_t off[OP1_FX_BLOCK], offr[OP1_FX_BLOCK], wl[OP1_FX_BLOCK], wr[OP1_FX_BLOCK];
    block_params(&b, p);
    const uint32_t w = s->w;
    lfo_pass(s, &b, b.inc, off);
    flip_pass(off, b.sgn, offr);
    telemetry((unsigned)pos > 2 ? 0 : pos, s, b.inc, l, r);
    read_pass(s->ring[0], w, off, wl);                      /* before the write: the static assert at RING */
    read_pass(s->ring[1], w, offr, wr);
    write_pass(s->ring[0], w, l, s->bq[0] + 0);
    write_pass(s->ring[1], w, r, s->bq[1] + 0);
    lp_pass(wl, s->bq[0] + 2, b.a);
    lp_pass(wr, s->bq[1] + 2, b.a);
    mix_pass(l, wl, b.gd, b.gw);
    mix_pass(r, wr, b.gd, b.gw);
    s->w = w + OP1_FX_BLOCK;
    juni_chorus_blocks[(unsigned)pos > 2 ? 0 : pos]++;
}

/* mono (synth, drum): one tap and the dry, as the original's mono output (one chorus side). The two opposite taps
 * summed would cancel each other's pitch movement and leave only a faint comb (host measure, 2026-10-28) */
static void mono(int pos, int16_t *io, const int16_t *p)
{
    state_t *s = &st[(unsigned)pos > 2 ? 0 : pos];
    block_t b;
    int16_t off[OP1_FX_BLOCK], wa[OP1_FX_BLOCK];
    block_params(&b, p);
    const uint32_t w = s->w;
    lfo_pass(s, &b, b.inc, off);
    telemetry((unsigned)pos > 2 ? 0 : pos, s, b.inc, io, 0);
    read_pass(s->ring[0], w, off, wa);
    write_pass(s->ring[0], w, io, s->bq[0] + 0);
    lp_pass(wa, s->bq[0] + 2, b.a);
    mix_pass(io, wa, b.gd, b.gw);
    s->w = w + OP1_FX_BLOCK;
    juni_chorus_blocks[(unsigned)pos > 2 ? 0 : pos]++;
}

const op1_fx_stereo_t FX_juni_chorus = {
    { init, mono, { OP1_PRESS_NONE, OP1_PRESS_NONE, OP1_PRESS_NONE, OP1_PRESS_NONE } }, stereo };
