#!/usr/bin/env python3
"""Twelve normal OP-1 presets for arc (the engine has no internal program bank).
    python3 presets.py [OUT_DIR]      -> OUT_DIR/*.aif (default: presets/ next to this script)
Knob words (arc.c): 0 current (mu, sine -> buzz -> scream), 1 carbon (even harmonics), 2 hiss (plasma noise, pitch
wander), 3 strike (attack pitch sag + ignition noise; random re-strikes while held), 4 the selector 0x5300 + order 9
(plugins/ORDERS.md, as the core saves it), 5 2nd lamp ratio
(detents 1:2 140, 2:3 3400, 3:4 4790, 1:1 8192, 5:4 16100, 4:3 17400, 3:2 22567, 5:3 26300, 2:1 32767; between
detents the ratio glides, so 9000 is about 13 cents sharp), 6 coupling (0 = 2nd lamp off), 7 brightness (0 = neutral,
1..8191 darker, above 8192 brighter). Levels were matched on the host against the default patch (dry, no OP-1
envelope/FX/LFO); FX and LFO values stay inside the factory presets' ranges (tools/op1r_presets.py).
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later + OP-1 firmware permission.
"""
import json, math, struct, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent


def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def aifc(meta):
    comm = struct.pack(">hIh", 1, 0, 16) + ieee_extended(44100) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    js = json.dumps(meta, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + chunk(b"APPL", b"op-1" + js)
            + chunk(b"SSND", struct.pack(">II", 0, 0)))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


SELECTOR = 0x5300 + 9                  # order 9
FX_OFF = ('delay', [8000, 8000, 8000, 8000])
LFO_OFF = ('tremolo', [16000, 0, 0, 16000])
DELAY = ('delay', [9000, 14000, 8000, 12000])
SPRING = ('spring', [16448, 15000, 2000, 10239])


def patch(name, knobs, adsr, fx=None, lfo=None, octave=0):
    f, l = fx or FX_OFF, lfo or LFO_OFF
    return {'adsr': list(adsr) + [2048, 5568, 4000, 4000], 'fx_active': fx is not None, 'fx_params': f[1] + [0, 0, 0, 0],
            'fx_type': f[0], 'knobs': knobs[:4] + [SELECTOR] + knobs[4:], 'lfo_active': lfo is not None,
            'lfo_params': l[1] + [0, 0, 0, 0], 'lfo_type': l[0], 'name': name, 'octave': octave, 'synth_version': 2,
            'type': 'arc'}


# knobs: current, carbon, hiss, strike, ratio, coupling, brightness; adsr: attack, decay, sustain, release
# Release words (2026-11-15): R246 reads the release word inverted (rate table 0x7F - (v >> 7), audio-graph.md): HIGH
# release = SHORT. To -60 dB: 4800 = 2.9 s, 6000 = 2.1 s, 10400 = 0.9 s, 13500 = 0.4 s, 15000 = 0.2 s. Pads and drones
# sit at 3600..8000, leads and keys at 7000..13500, basses, plucks, stabs and organs at 13500..16320.
PATCHES = [
    patch('singing arc', [14000, 5000, 4500, 6000, 0, 0, 0], [400, 8000, 26000, 11300], SPRING),
    patch('glass sine', [1200, 3500, 1500, 0, 0, 0, 0], [64, 9000, 6000, 6000], DELAY, octave=1),
    patch('reed organ', [9500, 4000, 1500, 0, 140, 5000, 7000], [200, 6000, 32767, 13800]),
    patch('arc bass', [17000, 12000, 0, 13000, 0, 0, 4500], [64, 6500, 26000, 14300], octave=-1),
    patch('scream lead', [30000, 7000, 5000, 4000, 0, 0, 9000], [100, 7000, 28000, 12300], DELAY),
    patch('fifth lamp', [10500, 3000, 2000, 3000, 22567, 5000, 0], [150, 7500, 24000, 11800],
          ('punch', [6000, 8000, 12000, 18000])),
    patch('beat pad', [8000, 1500, 3000, 0, 9000, 3000, 9000], [9000, 12000, 28000, 5300], SPRING,
          ('value', [1500, 4000, 2000, 2000])),
    patch('sputter lamp', [20000, 6000, 12000, 30000, 0, 0, 0], [64, 9000, 22000, 10300], SPRING),
    patch('rough drone', [26000, 4000, 4000, 0, 17400, 12000, 5000], [6000, 12000, 30000, 7000],
          ('cwo', [5000, 10000, 20000, 24000])),
    patch('plasma wind', [3000, 2000, 32767, 0, 0, 0, 10000], [8000, 12000, 30000, 6300], SPRING),
    patch('zap perc', [22000, 9000, 6000, 24000, 0, 0, 8000], [64, 4500, 0, 13500]),
    patch('octave keys', [5000, 8000, 1000, 2000, 32767, 4000, 7000], [64, 8000, 12000, 11800],
          lfo=('tremolo', [4000, 3000, 2000, 2000])),
]


def main():
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / 'presets'
    out.mkdir(parents=True, exist_ok=True)
    for meta in PATCHES:
        (out / (meta['name'] + '.aif')).write_bytes(aifc(meta))
    print(f'{len(PATCHES)} arc presets in {out}')


if __name__ == '__main__':
    main()
