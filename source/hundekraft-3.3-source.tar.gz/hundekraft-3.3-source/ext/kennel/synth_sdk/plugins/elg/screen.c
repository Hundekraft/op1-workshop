/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* The folk-art moose crown (elg.svg + elg_geom.h, both from gen_svg.py and the owner's approved concept elg-art.png)
 * in motion. elg.svg holds the still parts (landscape, knotwork, moon ring and clouds, the fur under the breath) and
 * the two breath clouds; this file draws the rest with raster lines from elg_geom.h, so R246's drawing heap doesn't
 * hold them: the aurora, the moon's glow and shadow, the antlers, the fur and face shading, the stars. iter's draw
 * turns the hidden bar0..bar3. The knobs are scene parts (screen px), every one eased by a spring (a little
 * overshoot, settled in about 0.4 s) instead of jumping, and every part keeps a slow idle motion:
 *   antlers  blue Interval: the antlers spread with the third voice's interval (0 .. 4: unison .. two octaves):
 *            93 .. 107 % wide and 96.5 .. 103.5 % tall about their base (160, 59), the concept's size at the octave
 *            (the default); they spring there with a small toss, sway a little at rest, and dim while the third saw
 *            crossfades to its new interval (elg_xg, as the sound dips); they ignore the slot LFO
 *   breath   green Detune: each breath cloud is 87.5 .. 137.5 % about its nostril (100 % at the default); it breathes
 *            slowly (1 % at rest, 2.5 % while notes play), puffs on each new note and swells with the level
 *   moon     white Timbre over the whole knob: below its default a shadow eats the ring from the right (a darker sound,
 *            a waning moon: up to two thirds of it at 0), above it up to three dim glow arcs outside the ring; the
 *            default is the concept's pose; a little glow with the level while notes play
 *   aurora   red Movement: the ribbons sink and the fringe stretches in a wave running along them, 0.3 .. 3 px and
 *            3 .. 45 % (a slow ripple at 0), faster with the movement and while notes play, the wave's depth
 *            swinging with Elg's LFO while notes play
 *   stars    twinkle slowly at rest, more while notes play
 * The other knob parts follow the slot LFO while notes play (elg_knobs, copied by engine_render).
 */
#ifndef ENGINE_HOST_TEST
#include "hk/engine.h"
#ifndef HK_SCREEN_HOST
#include "op1_synth.h"                          /* the stock text object (the CLASSIC tag) */
#endif
#include "elg_geom.h"
#include "elg_mode.h"

extern volatile uint32_t elg_blocks;
extern volatile int32_t elg_level, elg_lfo, elg_xg;
extern volatile int16_t elg_knobs[4];
extern int elg_interval(int32_t value);
extern volatile int32_t elg2_open, elg2_calls, elg2_band[2];   /* elg2.c, v2 */

#define ONE 1024
#define Q2Q10(v) ((int32_t)(v) << 8)            /* quarter px -> Q10 */

static void *e_breath_l, *e_breath_r;
static uint32_t last_blocks, aph, tph, bph, sph;
static int32_t act, playing, prev_level, puff;
/* a spring per eased part: position and speed in Q16 (Q10 << 6), so it settles exactly */
typedef struct { int32_t x, v; } spring_t;
static spring_t s_ax, s_ay, s_br, s_glow, s_wane, s_mov;
static int ready;
static int32_t asx, asy, ant_dim, aur_amp, aur_str, glow, wane;   /* this frame's values, Q10 (glow 0 .. 3072) */
static int classic;                              /* the shown sound plays CLASSIC (elg_mode.h) */
static int32_t last_calls, call_open;
/* a knob as the voices hear it (after the slot LFO) while notes play, else as set */
#define K(i) screen_knob_live(elg_knobs, (i), act > 64)

static const uint8_t C_RED[4] = {0xFF, 0x3A, 0x5D, 0xFF}, C_BLUE[4] = {0x69, 0x8E, 0xFF, 0xFF},
                     C_BROWN[4] = {0xB0, 0x7A, 0x50, 0xFF}, C_LAV[4] = {0xDE, 0xD7, 0xFF, 0xFF},
                     C_WHITE[4] = {0xFF, 0xFF, 0xFF, 0xFF}, C_BLACK[4] = {0, 0, 0, 0xFF};

/* one frame of a spring toward t (Q10): stiffness 1/16, damping 0.8 of critical; -> the position, Q10 */
static int32_t spring(spring_t *s, int32_t t)
{
    if (!ready) { s->x = t << 6; s->v = 0; return t; }
    s->v += ((t << 6) - s->x) >> 4;
    s->v -= (s->v * 13) >> 5;
    s->x += s->v;
    return s->x >> 6;
}
static int32_t clampi(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }

void engine_screen_load(void *screen)
{
    e_breath_l = SVG_FIND(screen, "breathL");
    e_breath_r = SVG_FIND(screen, "breathR");
    ready = 0;                                   /* the first frame starts every part at its target */
}

void engine_screen_animate(void *screen)
{
    (void)screen;
    const uint32_t blocks = elg_blocks;
    const int on = blocks != last_blocks;
    last_blocks = blocks;
    act += ((on ? ONE : 0) - act) >> 4;
    playing = act > 64;
    const int32_t level = on ? elg_level : 0, lfo = on ? elg_lfo : 0;

    int16_t w[8];
    for (int i = 0; i < 8; i++) w[i] = SCREEN_KNOB(i);
    classic = elg_classic(w);
    if (classic) {
        /* antlers: spread with the interval step (the knob as set, no LFO), sprung there, a slow sway at rest (0.4 %);
           dimmed to 45 % while the third saw is down in its crossfade */
        const int32_t step = elg_interval(SCREEN_KNOB(0) < 0 ? 0 : SCREEN_KNOB(0));
        sph += 21;                                                    /* a sway every 6.5 s at 60 frames */
        const int32_t sway = SVG_SIN(sph) >> 13;                      /* -4 .. 4 */
        asx = clampi(spring(&s_ax, ONE + (step - 2) * 36) + sway, ONE - 72, ONE + 72);
        asy = clampi(spring(&s_ay, ONE + (step - 2) * 18) - (sway >> 1), ONE - 36, ONE + 36);
        ant_dim = playing ? 461 + (((elg_xg < 0 ? 0 : elg_xg) * 563) >> 15) : ONE;
        /* breath: 87.5 .. 137.5 % with the detune, sprung; breathing (1 % at rest, 2.5 % playing), a puff on each new
           note (5 %, a quarter second), up to 6 % with the level; at most 145 % (gen_svg.py BREATH_MAX) */
        if (playing && level > prev_level + (prev_level >> 1) + 600) puff = ONE;
        prev_level = level;
        puff -= puff >> 4;
        bph += playing ? 50 : 34;
        const int32_t breathe = (SVG_SIN(bph) * (playing ? 25 : 10)) >> 15;
        const int32_t b = clampi(spring(&s_br, 896 + ((K(1) * 512) >> 15)) + breathe + ((puff * 51) >> 10)
                                 + ((level * act) >> 19), 860, 1484);
        svg_scale(e_breath_l, b, b, Q2Q10(EG_NOSE_LX), Q2Q10(EG_NOSE_Y));
        svg_scale(e_breath_r, b, b, Q2Q10(EG_NOSE_RX), Q2Q10(EG_NOSE_Y));
        /* moon: above the default timbre up to 3 glow arcs at the top, below it the shadow (0 .. ONE: up to 2/3 of the
           ring); plus up to half an arc of glow with the level */
        const int32_t t = K(2) - 20000;
        glow = clampi(spring(&s_glow, (t > 0 ? (t * 246) >> 10 : 0) + ((level * act) >> 16)), 0, 3072);
        wane = clampi(spring(&s_wane, t < 0 ? (-t * 53) >> 10 : 0), 0, ONE);   /* 20000 * 53 >> 10 = 1035 */
        /* aurora: the wave runs along the ribbons; its depth with the movement (a slow ripple at 0), swinging with the
           LFO while playing; faster with the movement and while notes play */
        const int32_t m = clampi(spring(&s_mov, K(3)), 0, 32767);   /* 0 .. 32767 */
        aph += 12 + ((m * 40) >> 15) + (playing ? 6 : 0);
        const int32_t swing = 24576 + (lfo >> 2);                     /* 0.75 +- 0.25 */
        aur_amp = 307 + ((((m * 2765) >> 15) * swing) >> 15);         /* Q10 px, 0.3 .. 3 px */
        aur_str = 31 + ((((m * 430) >> 15) * swing) >> 15);           /* Q10, 0.03 .. 0.45 */
    } else {
        /* v2. antlers: spread with CALL (93 .. 107 % wide, 96.5 .. 103.5 % tall, the default in the middle), a little
           more while a call opens the throat, sized by THROAT (bull larger: +-2 %), tossed up on each call; sway */
        const int32_t calls = elg2_calls;
        const int call = playing && calls != last_calls;
        last_calls = calls;
        const int32_t open = playing ? elg2_open : 0;
        elg2_open = 0;                                            /* the voices' widest throat since the last frame */
        call_open += ((open > call_open ? open : call_open - (call_open >> 3)) - call_open) >> 1;
        sph += 21;
        const int32_t sway = SVG_SIN(sph) >> 13;
        const int32_t c = K(0) - 16384, size = (((16384 - (w[5] < 0 ? 0 : w[5])) * 20) >> 14);
        if (call && ready) s_ay.v += 40 << 6;                        /* the toss */
        asx = clampi(spring(&s_ax, ONE + ((c * 56) >> 14) + size + ((call_open * 14) >> 15)) + sway, ONE - 72, ONE + 72);
        asy = clampi(spring(&s_ay, ONE + ((c * 26) >> 14) + (size >> 1)) - (sway >> 1), ONE - 36, ONE + 36);
        ant_dim = ONE;
        /* breath: 87.5 .. 137.5 % with BREATH, a puff on each call (8 %), bigger while the throat is open (up to
           5 %), breathing; at most 145 % */
        if (call) puff = ONE;
        if (playing && level > prev_level + (prev_level >> 1) + 600) puff = puff > 600 ? puff : 600;
        prev_level = level;
        puff -= puff >> 4;
        bph += playing ? 50 : 34;
        const int32_t breathe = (SVG_SIN(bph) * (playing ? 25 : 10)) >> 15;
        const int32_t b = clampi(spring(&s_br, 896 + ((K(1) * 512) >> 15)) + breathe + ((puff * 82) >> 10)
                                 + ((call_open * 51) >> 15) + ((level * act) >> 19), 860, 1484);
        svg_scale(e_breath_l, b, b, Q2Q10(EG_NOSE_LX), Q2Q10(EG_NOSE_Y));
        svg_scale(e_breath_r, b, b, Q2Q10(EG_NOSE_RX), Q2Q10(EG_NOSE_Y));
        /* moon: BODY about its default (13000): the shadow below, up to three glow arcs above; with the level */
        const int32_t t = K(2) - 13000;
        glow = clampi(spring(&s_glow, (t > 0 ? (t * 159) >> 10 : 0) + ((level * act) >> 16)), 0, 3072);
        wane = clampi(spring(&s_wane, t < 0 ? (-t * 80) >> 10 : 0), 0, ONE);   /* 13000 * 80 >> 10 = 1015 */
        /* aurora: AURORA sets the wave's depth and speed; while notes play its depth follows the sky's two bands
           (elg2_band: where each band-pass has drifted, 0 .. 32767) */
        const int32_t m = clampi(spring(&s_mov, K(3)), 0, 32767);
        aph += 12 + ((m * 40) >> 15) + (playing ? 6 : 0);
        const int32_t swing = playing ? 16384 + ((elg2_band[0] + elg2_band[1]) >> 2) : 24576;   /* 0.5 .. 1 */
        aur_amp = 307 + ((((m * 2765) >> 15) * swing) >> 15);
        aur_str = 31 + ((((m * 430) >> 15) * swing) >> 15);
    }
    tph += playing ? 96 : 24;
    ready = 1;
}

static void seg(void *canvas, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, const uint8_t *c)
{
    const svg_pt a = {x0, y0}, p = {x1, y1};
    SVG_LINE(canvas, &a, &p, w, c);
}

/* the strokes first .. last of elg_geom.h as they are, each at its own measured width */
static void strokes(void *canvas, int first, int last, const uint8_t *c)
{
    for (int s = first; s < last; s++) {
        const int16_t *p = EG_PTS + 2 * EG_STROKE[s][0];
        for (int i = 1; i < EG_STROKE[s][1]; i++, p += 2)
            seg(canvas, Q2Q10(p[0]), Q2Q10(p[1]), Q2Q10(p[2]), Q2Q10(p[3]), EG_STROKE[s][2], c);
    }
}

/* the aurora's drop at x (Q2 px): 0 .. aur_amp, a wave of 75 px running right */
static int32_t drop(int32_t xq2)
{
    const int32_t c = SVG_SIN(aph * 8 - xq2 * 27 + 2048);    /* 8192 a turn: 300 quarter px a period */
    return (aur_amp * (32767 - c)) >> 16;
}

static void aurora(void *canvas)
{
    const int32_t w = EG_W_RED;
    for (int s = EG_RIBBON_0; s < EG_RIBBON_1; s++) {
        const int16_t *p = EG_PTS + 2 * EG_STROKE[s][0];
        int32_t x0 = Q2Q10(p[0]), y0 = Q2Q10(p[1]) + drop(p[0]);
        for (int i = 1; i < EG_STROKE[s][1]; i++) {
            p += 2;
            const int32_t x1 = Q2Q10(p[0]), y1 = Q2Q10(p[1]) + drop(p[0]);
            seg(canvas, x0, y0, x1, y1, w, C_RED);
            x0 = x1, y0 = y1;
        }
    }
    /* the fringe hangs from its top end: dropped with the ribbon, stretched by up to aur_str in a second wave */
    for (int s = EG_FRINGE_0; s < EG_FRINGE_1; s++) {
        const int16_t *p = EG_PTS + 2 * EG_STROKE[s][0];
        const int32_t d = drop(p[0]);
        const int32_t st = ONE + ((aur_str * (32767 + SVG_SIN(aph * 5 + p[0] * 19))) >> 16);
        const int32_t top = Q2Q10(p[1]);
        int32_t x0 = Q2Q10(p[0]), y0 = top + d;
        for (int i = 1; i < EG_STROKE[s][1]; i++) {
            const int16_t *q = p + 2 * i;
            const int32_t x1 = Q2Q10(q[0]), y1 = top + d + (((Q2Q10(q[1]) - top) * st) >> 10);
            seg(canvas, x0, y0, x1, y1, w, C_RED);
            x0 = x1, y0 = y1;
        }
    }
}

static void antlers(void *canvas)
{
    const int32_t bx = Q2Q10(EG_ANT_X), by = Q2Q10(EG_ANT_Y);
    const uint8_t c[4] = {(uint8_t)((C_BLUE[0] * ant_dim) >> 10), (uint8_t)((C_BLUE[1] * ant_dim) >> 10),
                          (uint8_t)((C_BLUE[2] * ant_dim) >> 10), 0xFF};
    for (int s = EG_ANTLERS_0; s < EG_ANTLERS_1; s++) {
        const int16_t *p = EG_PTS + 2 * EG_STROKE[s][0];
        int32_t x0 = bx + ((Q2Q10(p[0]) - bx) * asx >> 10), y0 = by + ((Q2Q10(p[1]) - by) * asy >> 10);
        for (int i = 1; i < EG_STROKE[s][1]; i++) {
            p += 2;
            const int32_t x1 = bx + ((Q2Q10(p[0]) - bx) * asx >> 10), y1 = by + ((Q2Q10(p[1]) - by) * asy >> 10);
            seg(canvas, x0, y0, x1, y1, EG_STROKE[s][2], c);
            x0 = x1, y0 = y1;
        }
    }
}

/* glow arcs 2.5, 5 and 7.5 px outside the ring, along its drawn arcs (each end pulled in 4 degrees an arc so they
   clear the head and antlers), white dimmed: the inner one brightest */
static void moon_glow(void *canvas)
{
    /* the shadow: the ring's drawn arcs in black, 3.5 px wide, where cos(angle) > 1 - 1.33 wane (from the right) */
    if (wane > 8) {
        const int32_t thr = 32767 - ((wane * 43690) >> 10);     /* Q15 cosine threshold, down to -0.33 */
        const int32_t r = Q2Q10(EG_MOON_R);
        for (int a = 0; a < EG_NARCS; a++)
            for (int d = EG_ARC[a][0]; d < EG_ARC[a][1]; d += 4) {   /* 4 degree pieces, each from 1 degree back */
                const int d0 = d > EG_ARC[a][0] ? d - 1 : d, d1 = d + 4 < EG_ARC[a][1] ? d + 4 : EG_ARC[a][1];
                const uint32_t a0 = (uint32_t)((d0 * 23302) >> 10) & 8191, a1 = (uint32_t)((d1 * 23302) >> 10) & 8191;
                if (SVG_SIN(a0 + 2048) <= thr && SVG_SIN(a1 + 2048) <= thr) continue;
                seg(canvas, Q2Q10(EG_MOON_X) + ((r >> 5) * SVG_SIN(a0 + 2048) >> 10), Q2Q10(EG_MOON_Y) + ((r >> 5) * SVG_SIN(a0) >> 10),
                    Q2Q10(EG_MOON_X) + ((r >> 5) * SVG_SIN(a1 + 2048) >> 10), Q2Q10(EG_MOON_Y) + ((r >> 5) * SVG_SIN(a1) >> 10),
                    3584, C_BLACK);
            }
    }
    for (int k = 0; k < 3; k++) {
        int32_t f = glow - k * 1024;                          /* this arc's share, Q10 */
        if (f <= 0) break;
        if (f > ONE) f = ONE;
        const int32_t lvl = (f * (120 - 32 * k)) >> 10;       /* 0 .. 120 */
        const uint8_t c[4] = {(uint8_t)lvl, (uint8_t)lvl, (uint8_t)lvl, 0xFF};
        const int32_t r = Q2Q10(EG_MOON_R) + (5 * 512) * (k + 1);
        for (int a = 0; a < EG_NARCS; a++) {
            const int32_t a0 = EG_ARC[a][0] + 4 * (k + 1), a1 = EG_ARC[a][1] - 4 * (k + 1);
            if (a1 - a0 < 4) continue;
            int32_t px = 0, py = 0;
            for (int d = a0;; d += 6) {
                if (d > a1) d = a1;
                const uint32_t ang = (uint32_t)((d * 23302) >> 10) & 8191;   /* degrees -> 8192 a turn, no divide */
                const int32_t x = Q2Q10(EG_MOON_X) + ((r >> 5) * SVG_SIN(ang + 2048) >> 10);
                const int32_t y = Q2Q10(EG_MOON_Y) + ((r >> 5) * SVG_SIN(ang) >> 10);
                if (d != a0) seg(canvas, px, py, x, y, EG_W_WHITE, c);
                px = x, py = y;
                if (d == a1) break;
            }
        }
    }
}

/* four-point sparkles: two arms, a short brighter cross at the middle; the arms breathe while notes play */
static void stars(void *canvas)
{
    for (int i = 0; i < EG_NSTARS; i++) {
        const int32_t x = Q2Q10(EG_STAR[i][0]), y = Q2Q10(EG_STAR[i][1]);
        int32_t r = Q2Q10(EG_STAR[i][2]);
        if (playing) r = (r * (26 + (SVG_SIN(tph * 3 + i * 1500) >> 12))) >> 5;   /* 56 .. 106 % */
        else r = (r * (30 + (SVG_SIN(tph * 3 + i * 1500) >> 13))) >> 5;          /* at rest 81 .. 106 % */
        seg(canvas, x - r, y, x + r, y, EG_W_LAV, C_LAV);
        seg(canvas, x, y - r, x, y + r, EG_W_LAV, C_LAV);
        const int32_t h = r >> 1, g = r >> 3;                /* the concave four-point body: a thicker inner cross, a dot */
        seg(canvas, x - h, y, x + h, y, EG_W_LAV * 2, C_LAV);
        seg(canvas, x, y - h, x, y + h, EG_W_LAV * 2, C_LAV);
        seg(canvas, x - g, y, x + g, y, EG_W_LAV * 4, C_LAV);
    }
}

/* CLASSIC (elg_mode.h; the white push): a small "classic" in white at the lower left, above the left knotwork's line
   and left of the fur (an empty 46 x 11 px box at x 37 .. 83, y 106 .. 116 in every pose; native size 8 is about
   42 px wide), as Father's tag */
#define TAG_X 39
#define TAG_Y 105
static uint8_t tag[OP1_TEXT_SIZE] __attribute__((aligned(4)));
static int tag_made;
static void classic_tag(void *canvas)
{
    static const int32_t ident[9] = {1024, 0, 0, 0, 1024, 0, 0, 0, 1024};
    if (!tag_made) {
        op1_text_ctor(tag, OP1_Q10(TAG_X), TAG_Y, 8, C_WHITE);
        op1_text_set(tag, "classic");
        tag_made = 1;
    }
    op1_text_draw(tag, canvas, ident);
}

void engine_screen_draw(void *screen, void *canvas)
{
    (void)screen;
    moon_glow(canvas);
    aurora(canvas);
    antlers(canvas);
    strokes(canvas, EG_FUR_0, EG_FUR_1, C_BROWN);
    strokes(canvas, EG_FACE_LAV_0, EG_FACE_LAV_1, C_LAV);
    strokes(canvas, EG_FACE_WHITE_0, EG_FACE_WHITE_1, C_WHITE);
    stars(canvas);
    if (classic) classic_tag(canvas);
}
#endif
