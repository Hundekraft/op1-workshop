/* ELG v2's sample passes for the Blackfin (2026-11-12): the same arithmetic as elg2_dsp.h's C, bit for bit
 * (kern_check.py runs both on bcore and compares every output and the state).
 *
 * void elg2_osc(e2_osc_t *o, int16_t *src, int16_t *asp, int16_t *aur, int16_t *sub)
 *   pass 1, 64 samples: R7 p4, R6 / R5 the aurora phases with bit 31 flipped (so a phase's high half is its signed
 *   saw: adding to a flipped phase is adding to the phase), R4 the xorshift32 noise; the increments ramp in I0 / I1 /
 *   I2 (+= M0 / M3 / M2 once a sample); P5 the struct, P4 the constants; P0 src, P1 asp, P2 aur, I3 sub
 * void elg2_mix(const int16_t *sub, const int16_t *aur, int32_t *v, int32_t gd)
 *   v[j] = sub[j] + (aur[j] * gd >> 15)
 * void elg2_svf(const int16_t *x, int32_t *v, int32_t *st, const int32_t *c)
 *   one Chamberlin band-pass over the call, its band times g added into v: st = { low, band }, c = { f, d, g }; v[-1]
 *   is scratch.
 *   Every a * b >> 15 (floor) of a 32-bit a and 0 <= b < 2^15 is (a.L * b, unsigned, >> 15) + a.H * b doubled (the
 *   default fractional mode doubles); f * band and d * band in one dual MAC
 * void elg2_hp(const int16_t *x, int32_t *v, int32_t *st, const int32_t *c)
 *   the breath's high band: st[0] += (x - st[0]) * a >> 15, v += (x - st[0]) * g >> 15; c = { a, g }
 * void elg2_out(const int32_t *v, int16_t *y, e2_res_t *r)
 *   the two one-poles (r->a, r->lp1, r->lp2), the output gain ramp (r->gain << 6 form, r->dgain) and its 16-bit
 *   saturation (the doubled low pass's high half times the gain in integer mode, as elg_dsp.S's elg_svf)
 * void elg2_up(int16_t *out, int32_t *prev): pass 3
 * Mixed-mode (IS,M) products are MAC1 only. Each kernel zeroes the L registers it uses; elg2.c restores the caller's
 * L0..L3 after the block, as elg.c does. M1 is never touched (R246's PmSynth keeps its frame there); P3..P5 and
 * R4..R7 are saved where used.
 * Host builds assemble it empty.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifdef __bfin__
	.section .rodata
	.align 4
_e2_k:
	.long 0x5999999A                                 /* the glottis open: the first 35 % of its period */
	.long 32768

	.text

/* ---- elg2_osc ---- */
	.align 4
	.global _elg2_osc
	.type _elg2_osc, STT_FUNC
_elg2_osc:
	[--SP] = (R7:4, P5:3);
	P5 = R0;
	P0 = R1;
	P1 = R2;
	R3 = [SP + 40];                                  /* aur: 12 + 7 x 4 saved (R7:4, P5:3) */
	P2 = R3;
	R3 = [SP + 44];                                  /* sub */
	I3 = R3;
	P4.L = _e2_k;
	P4.H = _e2_k;
	R3 = 0;
	L0 = R3;
	L1 = R3;
	L2 = R3;
	L3 = R3;
	R7 = [P5];                                       /* p4 */
	R6 = [P5 + 4];
	BITTGL (R6, 31);                                 /* pa0, flipped */
	R5 = [P5 + 8];
	BITTGL (R5, 31);                                 /* pa2, flipped */
	R4 = [P5 + 12];                                  /* nz */
	R3 = [P5 + 16];
	I0 = R3;
	R3 = [P5 + 20];
	M0 = R3;
	R3 = [P5 + 24];
	I1 = R3;
	R3 = [P5 + 28];
	M3 = R3;
	R3 = [P5 + 32];
	I2 = R3;
	R3 = [P5 + 36];
	M2 = R3;
	P3 = 64;
	LSETUP (.Los_b, .Los_e) LC0 = P3;
.Los_b:
	/* the glottis: two steps of p4; s = ((p4 << 2) ^ 2^31) >> 16 each */
	R0 = I0;
	R7 = R7 + R0 (NS);
	R1 = R7 << 2;
	R7 = R7 + R0 (NS);
	BITTGL (R1, 31);
	R1 = R1 >>> 16;
	R2 = R7 << 2;
	BITTGL (R2, 31);
	R2 = R2 >>> 16;
	R1 = R1 + R2;                                    /* g, the pair's sum */
	/* the aurora: pa0 and pa2 two steps each, their saws and the glottis' summed */
	R0 = I1;
	R6 = R6 + R0 (NS);
	R2 = R6 >>> 16;
	R6 = R6 + R0 (NS);
	R3 = R6 >>> 16;
	R2 = R2 + R3;
	R0 = I2;
	R5 = R5 + R0 (NS);
	R3 = R5 >>> 16;
	R2 = R2 + R3;
	R5 = R5 + R0 (NS) || I0 += M0 || NOP;            /* the ramps */
	R3 = R5 >>> 16;
	R2 = R2 + R3 (NS) || I1 += M3 || NOP;
	R2 = R2 + R1 (NS) || I2 += M2 || NOP;
	R2 = R2 >>> 3 || R0 = [P5 + 40] || NOP;          /* aur; gr */
	R1 = R1 >>> 1 || W[P2++] = R2;                   /* g, the mean */
	/* the growl: g +- g gr >> 15 by bit 30 of p4 */
	R3 = R1.L * R0.L (IS);
	R3 = R3 >>> 15;
	CC = BITTST (R7, 30);
	R0 = R1 - R3;
	R1 = R1 + R3;
	IF !CC R1 = R0;
	/* the noise: xorshift32 */
	R0 = R4 << 13;
	R4 = R4 ^ R0;
	R0 = R4 >> 17;
	R4 = R4 ^ R0;
	R0 = R4 << 5;
	R4 = R4 ^ R0;
	R2 = [P4];
	/* the breath: n = nz >> 16 times ah while (p4 << 2) < 0.35, else al */
	R3 = R7 << 2;
	CC = R3 < R2 (IU);
	R0 = [P5 + 44];
	R2 = [P5 + 48];
	IF !CC R0 = R2;
	R2 = R4.H * R0.L (IS);
	R2 = R2 >>> 15;                                  /* a, |a| <= 32767 */
	/* drive: sat16((g + a) >> 1) * drv >> 11, saturated */
	R1 = R1 + R2 (NS) || W[P1++] = R2;               /* asp */
	R1 = R1 >>> 1 || R0 = [P5 + 52] || NOP;          /* drv */
	R1 = R1 << 16 (S);
	R1 = R1 >>> 16;
	R1 = R1.L * R0.L (IS);
	R1 = R1 >>> 11;
	R1 = R1 << 16 (S);
	R1 = R1 >>> 16 || R2 = [P4 + 4] || NOP;          /* x; 32768 */
	/* the soft clip: (x (32768 - (x x >> 15)) >> 16) + x */
	R0 = R1.L * R1.L (IS);
	R0 = R0 >>> 15;
	R0 = R2 - R0;
	A1 = R1.L * R0.L (IS,M);
	A1 = A1 >>> 16;
	R3 = A1;
	R1 = R1 + R3;
	/* the sub: two parabolas at once, x (32768 - |x|) >> 13 saturated to 16 bits, x the high half of (p4 << 1) and
	   p4, flipped; |x| saturates (-32768 -> 32767); 32768 - |x| as a 16-bit pattern (0x8000 only where x = 0) */
	R0 = R7 << 1 || W[P0++] = R1;                    /* src */
	BITTGL (R0, 31);
	R3 = R7;
	BITTGL (R3, 31);
	R0 = PACK (R0.H, R3.H);                          /* .H x1, .L x2 */
	R1 = ABS R0 (V);
	R3 = PACK (R2.L, R2.L);                          /* 0x8000 0x8000 */
	R1 = R3 -|- R1;
	A1 = R0.H * R1.H, A0 = R0.L * R1.L (IS);
	A1 = A1 >>> 13;
	A0 = A0 >>> 13 || R2 = [P5 + 56] || NOP;         /* .L l1, .H l2 */
	R0.H = A1, R0.L = A0 (IS);                       /* y1, y2 */
	A0 = R0.H * R2.L (IS);
	A0 += R0.L * R2.H (IS);
	A0 = A0 >>> 15;
	R0 = A0;
.Los_e:
	W[I3++] = R0.L;
	[P5] = R7;
	BITTGL (R6, 31);
	[P5 + 4] = R6;
	BITTGL (R5, 31);
	[P5 + 8] = R5;
	[P5 + 12] = R4;
	R3 = I0;
	[P5 + 16] = R3;
	R3 = I1;
	[P5 + 24] = R3;
	R3 = I2;
	[P5 + 32] = R3;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _elg2_osc, .-_elg2_osc

/* ---- elg2_mix ---- */
	.align 4
	.global _elg2_mix
	.type _elg2_mix, STT_FUNC
_elg2_mix:
	P0 = R0;                                         /* sub */
	I0 = R1;                                         /* aur */
	I1 = R2;                                         /* v */
	R3 = [SP + 12];                                  /* gd */
	R0 = 0;
	L0 = R0;
	L1 = R0;
	P1 = 64;
	LSETUP (.Lmx_b, .Lmx_e) LC0 = P1;
.Lmx_b:
	MNOP || R1 = W[P0++] (X) || R0.L = W[I0++];
	A0 = R0.L * R3.L (IS);
	A0 = A0 >>> 15;
	R2 = A0;
	R2 = R2 + R1;
.Lmx_e:
	[I1++] = R2;
	RTS;
	.size _elg2_mix, .-_elg2_mix

/* ---- elg2_svf: 15 packets a sample ---- */
/* R6 low, R7 band; R2 .H f, .L d; R3.L g; R4 x, then high; R5 v; R0 / R1 products. Pipelined: a sample's band times g
 * goes into v at the start of the next one (v[-1] is the caller's scratch word for the first), the last one after */
	.align 4
	.global _elg2_svf
	.type _elg2_svf, STT_FUNC
_elg2_svf:
	[--SP] = (R7:4);
	P0 = R0;
	I0 = R1;
	R1 += -4;
	I1 = R1;                                         /* v - 1 */
	P2 = R2;
	R3 = [SP + 28];                                  /* c: 12 + 4 x 4 saved */
	P1 = R3;
	R0 = 0;
	L0 = R0;
	L1 = R0;
	R6 = [P2];
	R7 = [P2 + 4];
	R0 = [P1];
	R1 = [P1 + 4];
	R3 = [P1 + 8];
	R2 = PACK (R0.L, R1.L);
	R5 = 0;
	P1 = 64;
	LSETUP (.Lsv_b, .Lsv_e) LC0 = P1;
.Lsv_b:
	A0 = R7.L * R3.L (FU) || R4 = W[P0++] (X) || NOP;
	A0 = A0 >> 15;
	R0 = (A0 += R7.H * R3.L);                        /* g band, the previous sample's */
	R5 = R5 + R0 (NS);
	A1 = R7.L * R2.H, A0 = R7.L * R2.L (FU) || [I1++] = R5;
	A1 = A1 >> 15 || R5 = [I0++] || NOP;
	A0 = A0 >> 15;
	R1 = (A1 += R7.H * R2.H), R0 = (A0 += R7.H * R2.L);   /* f band, d band */
	R6 = R6 + R1 (NS);                               /* low */
	R4 = R4 - R6 (NS);
	R4 = R4 - R0 (NS);                               /* high */
	A1 = R4.L * R2.H (FU);
	A1 = A1 >> 15;
	R1 = (A1 += R4.H * R2.H);                        /* f high */
.Lsv_e:
	R7 = R7 + R1 (NS);                               /* band */
	A0 = R7.L * R3.L (FU);
	A0 = A0 >> 15;
	R0 = (A0 += R7.H * R3.L);
	R5 = R5 + R0 (NS);
	[I1++] = R5;
	[P2] = R6;
	[P2 + 4] = R7;
	(R7:4) = [SP++];
	RTS;
	.size _elg2_svf, .-_elg2_svf

/* ---- elg2_hp ---- */
/* R6 the one-pole; R2.L a, R3.L g; R4 x; R5 v */
	.align 4
	.global _elg2_hp
	.type _elg2_hp, STT_FUNC
_elg2_hp:
	[--SP] = (R7:4);
	P0 = R0;
	I0 = R1;
	I1 = R1;
	P2 = R2;
	R3 = [SP + 28];
	P1 = R3;
	R0 = 0;
	L0 = R0;
	L1 = R0;
	R6 = [P2];
	R2 = [P1];
	R3 = [P1 + 4];
	P1 = 64;
	LSETUP (.Lhp_b, .Lhp_e) LC0 = P1;
.Lhp_b:
	R0 = R6;
	MNOP || R4 = W[P0++] (X) || R5 = [I0++];
	R0 = R4 - R0 (NS);
	A1 = R0.L * R2.L (FU);
	A1 = A1 >> 15;
	R1 = (A1 += R0.H * R2.L);
	R6 = R6 + R1 (NS);
	R0 = R4 - R6 (NS);
	A0 = R0.L * R3.L (FU);
	A0 = A0 >> 15;
	R0 = (A0 += R0.H * R3.L);
	R5 = R5 + R0 (NS);
.Lhp_e:
	[I1++] = R5;
	[P2] = R6;
	(R7:4) = [SP++];
	RTS;
	.size _elg2_hp, .-_elg2_hp

/* ---- elg2_out ---- */
/* R6 lp1, R7 lp2, R2.L a, I2 the gain ramp (+= M2) */
	.align 4
	.global _elg2_out
	.type _elg2_out, STT_FUNC
_elg2_out:
	[--SP] = (R7:4);
	I0 = R0;
	R1 += -2;
	I1 = R1;                                         /* y - 1: the first store is a scratch (out[63], written later) */
	P2 = R2;
	R0 = 0;
	L0 = R0;
	L1 = R0;
	L2 = R0;
	R2 = [P2 + 112];                                 /* a */
	R0 = [P2 + 116];
	I2 = R0;                                         /* gain << 6 */
	R0 = [P2 + 120];
	M2 = R0;                                         /* dgain */
	R6 = [P2 + 196];
	R7 = [P2 + 200];
	P1 = 64;
	LSETUP (.Lou_b, .Lou_e) LC0 = P1;
.Lou_b:
	MNOP || R0 = [I0++] || W[I1++] = R0.L;           /* the previous sample out */
	R0 = R0 - R6 (NS);
	A1 = R0.L * R2.L (FU);
	A1 = A1 >> 15;
	R1 = (A1 += R0.H * R2.L);
	R6 = R6 + R1 (NS);                               /* lp1 */
	R0 = R6 - R7 (NS);
	A1 = R0.L * R2.L (FU);
	A1 = A1 >> 15;
	R1 = (A1 += R0.H * R2.L);
	R7 = R7 + R1 (NS);                               /* lp2 */
	R3 = I2;
	R3 >>>= 6;                                       /* the gain, Q15 */
	R0 = R7 + R7 (NS) || I2 += M2 || NOP;
	A0 = R0.L * R3.L (FU);
	A0 = A0 >> 16;
.Lou_e:
	R0.L = (A0 += R0.H * R3.L) (IS);                 /* sat16(lp2 gain >> 15) */
	W[I1++] = R0.L;
	[P2 + 196] = R6;
	[P2 + 200] = R7;
	(R7:4) = [SP++];
	RTS;
	.size _elg2_out, .-_elg2_out

/* ---- elg2_up: 44.1 -> 88.2 kHz in place (y at out[64..127]): out[2j] = (prev + y) >> 1, out[2j + 1] = y ---- */
	.align 4
	.global _elg2_up
	.type _elg2_up, STT_FUNC
_elg2_up:
	P0 = R0;
	P1 = 128;
	P0 = P0 + P1;                                    /* y */
	I1 = R0;
	P2 = R1;
	R0 = 0;
	L1 = R0;
	R0 = [P2];                                       /* prev */
	P1 = 64;
	LSETUP (.Lup_b, .Lup_e) LC0 = P1;
.Lup_b:
	R1 = W[P0++] (X);
	R2 = R0 + R1;
	R2 >>>= 1;
	W[I1++] = R2.L;
	R0 = R1;
.Lup_e:
	W[I1++] = R1.L;
	[P2] = R0;
	RTS;
	.size _elg2_up, .-_elg2_up
#endif
