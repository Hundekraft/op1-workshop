/* ELG's saved words and its two modes (2026-11-12, branch elg-v3): v2 (the layered moose) and CLASSIC (ELG as it was
 * on branch elg-v2, sample for sample). Shared by the engine (elg2.c), the screen and the host tests.
 *
 * R246 saves a plugin engine's eight words and takes each only in 0..32767 (a word with bit 15 panics the save), and
 * no ELG before this one wrote words 5 or 6: it had no page 2 and no Shift layer, and its presets set only word 7, the
 * hidden preset trim (Q13, 0 = 1x). So:
 *   words 5 and 6 both 0   a legacy sound (saved before v2, or a factory preset): CLASSIC, word 7 the trim, as before
 *   otherwise              the v2 layout: word 5 THROAT, word 6 CALL TIME (Shift + blue / green, fine turns that never
 *                          reach 0), word 7 bits 0..6 SUB and 8..14 DRIFT (Shift + white / orange), bit 7 CLASSIC
 * A fresh pick of ELG gets the v2 layout from the type row (plugin.json page2_defaults = ELG_W5_DEF, ELG_W6_DEF,
 * ELG_W7_DEF), so a new sound starts in v2 and every older sound keeps its sound in CLASSIC.
 * The white push (screen.c) flips the mode: on a legacy sound it writes the v2 defaults to words 5..7 (the preset
 * trim is dropped: v2 has its own level), else it toggles bit 7. CLASSIC from the v2 layout plays as a legacy sound
 * with words 5..7 at 0 (the trim 1x).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef ELG_MODE_H
#define ELG_MODE_H
#include <stdint.h>

#define ELG_W7_CLASSIC 0x80     /* word 7 bit 7 in the v2 layout */
#define ELG_SUB_N 4             /* Shift + white: off, one octave down, two octaves down, both */
#define ELG_DRIFT_N 4           /* Shift + orange: the aurora's band set: low, wide, high, fifths */
#define ELG_W5_DEF 8937         /* THROAT 0.60 (0.45 .. 1.0 over 1 .. 32767) */
#define ELG_W6_DEF 13000        /* CALL TIME about 1.1 s (0.4 .. 2.5 s) */
#define ELG_W7_DEF 0x0101       /* SUB one octave down, DRIFT wide, v2 */

static inline int elg_legacy(const int16_t *w) { return w[5] <= 0 && w[6] <= 0; }
static inline int elg_classic(const int16_t *w) { return elg_legacy(w) || (w[7] & ELG_W7_CLASSIC); }
static inline int elg_sub(const int16_t *w) { const int f = w[7] & 127; return f < ELG_SUB_N ? f : ELG_SUB_N - 1; }
static inline int elg_drift(const int16_t *w) { const int f = (w[7] >> 8) & 127; return f < ELG_DRIFT_N ? f : ELG_DRIFT_N - 1; }

/* the white push on words w (0..7): -> 1 (the words changed) */
static inline int elg_push_mode(int16_t *w)
{
    if (elg_legacy(w)) {
        w[5] = ELG_W5_DEF;
        w[6] = ELG_W6_DEF;
        w[7] = ELG_W7_DEF;
    } else {
        w[7] = (int16_t)((w[7] ^ ELG_W7_CLASSIC) & 0x7FFF);
    }
    return 1;
}
#endif
