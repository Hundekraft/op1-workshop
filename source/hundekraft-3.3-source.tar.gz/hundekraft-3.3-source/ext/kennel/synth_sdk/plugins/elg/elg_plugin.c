/* adapter as tools/firmware/op1r_plugins.py makes it: hundekraft elg (tools/engines/elg) as an op1r plugin.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "op1_plugin.h"
#include "elg_mode.h"
void elg_note_on(void *, const int16_t *);
void elg_render(void *, int16_t *, const int16_t *);
void elg_note_off(void *, const int16_t *);
#ifdef OP1_HOST
uint32_t engine_host_pitch[128];
#define VOICE(self) ((void *)(uintptr_t)(0xFFB00000u + op1_voice_index(self) * OP1_VOICE_SIZE))
#else
#define VOICE(self) (self)
#endif
static const int16_t no_knobs[8];
static void note_on(void *self, const int16_t *p) { elg_note_on(VOICE(self), p); }
static void render(void *self, int16_t *out, const int16_t *p)
{
#ifdef OP1_HOST
    for (int i = 0; i < OP1_BLOCK; i++) engine_host_pitch[i] = (uint32_t)OP1_PITCH_INC[i];
#endif
    elg_render(VOICE(self), out, p);
}
static void note_off(void *self) { elg_note_off(VOICE(self), no_knobs); }
/* white's push is CLASSIC (elg_mode.h): a page-2 press the screen takes at once (screen_update) */
const op1_engine_t ENGINE_elg = { note_on, render, note_off, {0, 0, OP1_PRESS_PAGE_STEPS(2), 0} };

#ifndef OP1_HOST
__attribute__((weak)) void elg_screen_load(void *s) { (void)s; }
__attribute__((weak)) void elg_screen_animate(void *s) { (void)s; }
__attribute__((weak)) void elg_screen_draw(void *s, void *c) { (void)s; (void)c; }
#define ITER_SCREEN_VT ((const uint32_t *)0x019103FCu)        /* +0x1C draw, +0x24 on_load */
/* the shown sound's mode sets the knobs (dispatcher.c's tables are per engine, so they follow the slot on screen):
 * CLASSIC blue turns one 512-unit band a detent (the next interval in order; R246's own step is 328 a tick, which
 * skipped or repeated intervals; every saved word keeps its band: elg_sweep_test part B) and has no Shift layer, as
 * on elg-v2 (a Shift turn there would write words 5..7 and turn a legacy sound into the v2 layout); v2 blue is CALL,
 * a fine turn, and Shift + blue / green / white / orange are THROAT / CALL TIME (fine, never 0) / SUB / DRIFT */
static int shown_mode = -1;
static void follow_mode(const int16_t *w)
{
    const int m = elg_classic(w);
    if (m == shown_mode) return;
    shown_mode = m;
    op1_engine_knob_steps(&ENGINE_elg, 0, m ? 64 : 0);
    op1_engine_shift(&ENGINE_elg, 0, m ? 0 : 1);
    op1_engine_shift(&ENGINE_elg, 1, m ? 0 : 1);
    op1_engine_shift(&ENGINE_elg, 2, m ? 0 : ELG_SUB_N);
    op1_engine_shift(&ENGINE_elg, 3, m ? 0 : ELG_DRIFT_N);
}
/* the white push: the core's page-2 flag (OP1_PRESS_PAGE_STEPS(2)) taken before a turn can use it; a turn that slipped
 * into page 2 in between (it writes word 7) is undone; the words saved with the patch's knob setter (0x01A00D14), as
 * the core saves its own knob writes (hk/eng_push.h) */
#define ELG_SET_KNOBS(slot, w) \
    ((void (*)(void *, const int16_t *))0x01A00D14)((void *)(0x01DDD7E8 + ((slot) & 7) * 0x38), (w))
static int16_t seen_w7;
static int seen_slot = -1;
static void take_push(int slot, int16_t *w)
{
    if (op1_eng_page[2]) {
        op1_eng_page[2] = 0;
        if (seen_slot == slot) w[7] = seen_w7;
        elg_push_mode(w);
        ELG_SET_KNOBS(slot, w);
    }
    seen_w7 = w[7];
    seen_slot = slot;
}
static void screen_init(void *s)
{
    ((void (*)(void *))ITER_SCREEN_VT[0x24 / 4])(s);
    shown_mode = -1;
    seen_slot = -1;
    follow_mode(op1_synth_knobs(OP1_SCREEN_SLOT & 7));
    elg_screen_load(s);
}
static void screen_update(void *s, int dt)
{
    const int slot = OP1_SCREEN_SLOT & 7;
    int16_t *w = (int16_t *)op1_synth_knobs(slot);
    take_push(slot, w);
    follow_mode(w);
    elg_screen_animate(s);
    ((int (*)(void *, int))ITER_SCREEN_VT[0x1C / 4])(s, dt);
    elg_screen_draw(s, ((void *(*)(void))0x01A3B490)());
}
const op1_screen_t SCREEN_elg = { screen_init, screen_update };
#else   /* host previews (harness/golden.py): the screen code on the harness's mocks (hk/engine.h HK_SCREEN_HOST) */
__attribute__((weak)) void elg_screen_load(void *s) { (void)s; }
__attribute__((weak)) void elg_screen_animate(void *s) { (void)s; }
__attribute__((weak)) void elg_screen_draw(void *s, void *c) { (void)s; (void)c; }
static void screen_init(void *s) { elg_screen_load(s); }
static void screen_update(void *s, int dt) { elg_screen_animate(s); op1_screen_draw(s, dt); elg_screen_draw(s, op1_raster()); }
const op1_screen_t SCREEN_elg = { screen_init, screen_update };
#endif
