/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* ELG v2, the layered moose (OP1-Emulator docs/elg-v2-sound-2026-11-12.md, owner 2026-11-12), and the dispatcher
 * between it and CLASSIC (elg.c, ELG as on branch elg-v2, untouched; elg_mode.h says which a sound plays).
 *
 * Per voice: a glottis (a saw with a period-doubling growl), its breath (noise gated by the glottal phase, a puff on
 * each call), driven into a soft clip; the bellow (three formants that open from "oo" to CALL's vowel on every call);
 * the chest (two modal resonators); a high band of the breath; a sine sub one or two octaves down; and the aurora
 * (three saws a few cents apart through two band-passes drifting slowly). A per-voice scheduler restarts the call:
 * the formants open, the pitch scoops up and sags.
 * Rates: R246 asks for 128 samples at 88.2 kHz and decimates the voice sum 2:1 straight after. The oscillators run
 * at 88.2 kHz and are summed in pairs (a cheap anti-alias) to 44.1 kHz, where everything else runs (64 samples a
 * call), and the result is interpolated linearly back to 128.
 * Knobs (page 1): blue CALL, green BREATH, white BODY, orange AURORA; Shift: blue THROAT (word 5), green CALL TIME
 * (word 6), white SUB and orange DRIFT (word 7's fields). The white push is CLASSIC (screen.c, elg_mode.h).
 * Integers only, no division, no libc. The sample loop is three passes (elg2_dsp.h: e2_osc, e2_res, e2_up); on the
 * Blackfin elg2_dsp.S runs the first two, bit for bit (kern_check.py on bcore).
 * Included by elg_src_elg.c after elg.c (its helpers: exp2q, sine_lfo, mul_u32_s, mul_q15; its screen globals). */
#include "elg_mode.h"

#ifndef ELG_FORCE_LEGACY
#define ELG_FORCE_LEGACY 0            /* 1: every sound plays as a legacy one (exact_check against elg-v2) */
#endif
#ifndef ELG_FORCE_V2
#define ELG_FORCE_V2 0                /* 1: every sound plays v2 (cost runs: tier2's regimes leave words 5..7 at 0) */
#endif
#ifndef ELG2_ASM
#define ELG2_ASM 1                    /* the Blackfin passes of elg2_dsp.S (0: the C passes there too) */
#endif
#define ELG2_LEVEL 7900               /* the output level, Q12 */

#include "elg2_dsp.h"

typedef struct {
    e2_osc_t o;
    e2_res_t r;
    uint32_t rnd, d0, d1;             /* scheduler LCG, aurora drift phases */
    int32_t u, next, puff, jit, prev, gain;
} e2_voice_t;

static e2_voice_t e2v[ENGINE_VOICES];
static int16_t e2_src[E2_N], e2_asp[E2_N], e2_aur[E2_N], e2_sub[E2_N];
volatile int32_t elg2_open, elg2_calls, elg2_band[2], elg2_body;   /* for the screen */

/* vowels F1..F3 (Hz, adult): oo, oh, aa, eh; scaled by THROAT */
static const int16_t e2_vowel[4][3] = { { 300, 870, 2240 }, { 500, 900, 2500 }, { 730, 1090, 2440 }, { 530, 1840, 2480 } };
/* 1/Q, Q15, over 17 knob steps: the body 4 .. 18, aurora bands 3 .. 7 and 4 .. 9 */
static const int16_t e2_d_body[17] = { 8192, 6722, 5699, 4946, 4369, 3913, 3542, 3236, 2979, 2759, 2570, 2405, 2260, 2131, 2016, 1913, 1820 };
/* the chest's gain over BODY: (0.25 + 0.5 BODY) / 4 x sqrt(4 / Q), so a ringing chest grows a little, not 13x */
static const int16_t e2_g_body[17] = { 2048, 2087, 2135, 2188, 2243, 2300, 2357, 2414, 2470, 2526, 2581, 2635, 2689, 2742, 2794, 2846, 2896 };
static const int16_t e2_d_a1[17] = { 10923, 10082, 9362, 8738, 8192, 7710, 7282, 6899, 6554, 6242, 5958, 5699, 5461, 5243, 5041, 4855, 4681 };
static const int16_t e2_d_a2[17] = { 8192, 7598, 7085, 6637, 6242, 5891, 5578, 5296, 5041, 4810, 4599, 4406, 4228, 4064, 3913, 3772, 3641 };
/* the output low-pass over BODY: two one-poles, each 1 - exp(-2 pi 1.55 fc / 44100), Q15, so the pair is -3 dB near
   fc = 1.2 .. 11 kHz (the sketch's two-pole) */
static const int16_t e2_lp[17] = { 7628, 8599, 9669, 10839, 12111, 13480, 14942, 16485, 18093, 19745, 21415, 23070, 24676, 26196, 27592, 28834, 29898 };
/* the aurora's band sets (DRIFT): band 1 base Hz and span (Q12 octaves), band 2; base 0 = the key's 3rd / 6th harmonic */
static const int16_t e2_sky[4][4] = { { 200, 8192, 600, 6144 }, { 400, 9011, 1200, 6554 }, { 900, 6554, 2200, 4915 }, { 0, 4096, 0, 3277 } };

static inline int32_t e2_tab(const int16_t *t, int32_t k)   /* t over 17 steps of k 0..32767, lerped */
{
    const int32_t i = k >> 11, f = k & 2047;
    return i >= 16 ? t[16] : t[i] + (((t[i + 1] - t[i]) * f) >> 11);
}
static inline int32_t e2_fhz(int32_t hz)                    /* 2 sin(pi fc / 44100) ~ 2 pi fc / 44100, Q15 */
{
    int32_t f = (hz * 4781) >> 10;
    return f < 16 ? 16 : f > 16000 ? 16000 : f;
}
/* 2^20 / x for 1 <= x < 2^15, within 1.6 % (a normalised 32-step table; no division) */
static int32_t e2_recip(int32_t x)
{
    static const uint16_t t[32] = { 32768, 31775, 30840, 29959, 29127, 28340, 27594, 26887, 26214, 25575, 24966, 24385,
                                    23831, 23302, 22795, 22310, 21845, 21400, 20972, 20560, 20165, 19784, 19418, 19065,
                                    18725, 18396, 18079, 17772, 17476, 17190, 16913, 16644 };
    int sh = 0;
    if (x < 1) x = 1;
    while (x >= 64) { x >>= 1; sh++; }
    while (x < 32) { x <<= 1; sh--; }
    const int32_t r = t[x - 32];                       /* 2^20 / x for x in 32..63 */
    return sh >= 0 ? r >> sh : r << -sh;
}


static uint32_t e2_rand(uint32_t *s) { *s = *s * 1664525u + 1013904223u; return *s; }

static void e2_note_on(int vi)
{
    e2_voice_t *v = &e2v[vi];
    const uint32_t seed = v->rnd + 0x9E3779B9u * (uint32_t)(vi + 1);
    for (int i = 0; i < (int)(sizeof *v / 4); i++) ((uint32_t *)v)[i] = 0;
    v->rnd = seed;
    v->o.pa0 = e2_rand(&v->rnd);
    v->o.pa2 = e2_rand(&v->rnd);
    v->o.nz = e2_rand(&v->rnd) | 1u;                  /* xorshift32: never 0 */
    v->d0 = e2_rand(&v->rnd);
    v->d1 = e2_rand(&v->rnd);
    v->puff = 32767;                                  /* a note starts with a call: the throat opens, a puff */
    v->next = -1;                                     /* the next call: set on the first render (CALL's period) */
    v->gain = -1;
}

/* the v2 render: 128 samples at 88.2 kHz into out */
static void e2_render(int vi, int16_t *out, const int16_t *knobs)
{
    e2_voice_t *v = &e2v[vi];
    int vel = ENGINE_VELOCITY(vi);
    if (vel < 1 || vel > 127) vel = 100;
    const int32_t c = knobs[0] < 0 ? 0 : knobs[0], b = knobs[1] < 0 ? 0 : knobs[1];
    const int32_t y = knobs[2] < 0 ? 0 : knobs[2], a = knobs[3] < 0 ? 0 : knobs[3];
    const int32_t w5 = knobs[5] < 0 ? 0 : knobs[5], w6 = knobs[6] < 0 ? 0 : knobs[6];
    const int sub = elg_sub(knobs), sky = elg_drift(knobs);

    /* the call: a new one every 8 .. 2.5 s with CALL (0.75 .. 1.25 of it, at random); the first after half to one
       period; the contour u (Q19 of the call time, to two call times) and the puff */
    const int32_t period = 5512 - ((c * 3789) >> 15);               /* calls: 8 .. 2.5 s at 689.06 calls/s */
    if (v->next < 0) v->next = (period * (16384 + (int32_t)(e2_rand(&v->rnd) >> 18))) >> 15;
    else if (--v->next <= 0) {
        v->next = (period * (24576 + (int32_t)(e2_rand(&v->rnd) >> 18))) >> 15;
        v->u = 0;
        v->puff = 32767;
        elg2_calls++;
    }
    /* CALL TIME 0.4 .. 2.5 s (exponential over word 6): u's step 32768 * 16 / calls, 304 (2.5 s) .. 1900 (0.4 s) */
    const int32_t du = (304 * exp2q(((32767 - w6) * 10830) >> 15)) >> 12;
    v->u += du;
    if (v->u > (1 << 20)) v->u = 1 << 20;
    v->puff -= v->puff >> 7;
    const int32_t pos = v->u >> 4;                                   /* Q15 of the call time, 0 .. 65536 */
    const int32_t open = pos >= 16384 ? 32767 : pos * 2;
    const int32_t arc = pos >= 32768 ? 0 : ((pos * (32768 - pos)) >> 13) > 32767 ? 32767 : (pos * (32768 - pos)) >> 13;
    const int32_t sag = pos <= 32768 ? 0 : pos - 32768 > 32768 ? 32768 : pos - 32768;
    /* jitter: a slow random walk (about 0.25 s), +-0.05 semitone at full BREATH */
    v->jit += (((int32_t)(e2_rand(&v->rnd) >> 16) - 32768) * 1363 >> 15) - ((v->jit * 197) >> 15);
    if (v->jit > 32767) v->jit = 32767;
    if (v->jit < -32767) v->jit = -32767;
    /* the pitch: up to +0.5 semitone over the call, then down 0.35 (with CALL), plus the jitter; Q15 semitones */
    const int32_t semi = ((c * ((arc >> 1) - ((sag * 11469) >> 15))) >> 15) + ((v->jit * (2621 + ((b * 5243) >> 15))) >> 15);
    {   /* the increments: R246's first and last step of the call (a glide ramps across it), times 2^(semi / 12)
           (~ 1 + semi ln2 / 12, Q16); the aurora's saws spread 3 .. 13 cents with BREATH */
        const int32_t m = (semi * 3785) >> 15, sp = 111 + ((b * 380) >> 15);
        const uint32_t p0 = ENGINE_PITCH[0], p1 = ENGINE_PITCH[ENGINE_BLOCK - 1];
        const uint32_t a0 = p0 + mul_u32_s(p0, m, 16), a1 = p1 + mul_u32_s(p1, m, 16);
        const int32_t dd = (int32_t)(a1 - a0) >> 6;                  /* the change a 44.1 kHz sample, 64 a call */
        const int32_t s0 = (int32_t)mul_u32_s(a0, sp, 16), sd = (int32_t)mul_u32_s((uint32_t)(dd < 0 ? -dd : dd), sp, 16);
        v->o.i4 = (int32_t)(a0 >> 2); v->o.d4 = dd >> 2;
        v->o.ia0 = (int32_t)(a0 - (uint32_t)s0); v->o.da0 = dd - (dd < 0 ? -sd : sd);
        v->o.ia2 = (int32_t)((a0 + (uint32_t)s0) << 1); v->o.da2 = (dd + (dd < 0 ? -sd : sd)) * 2;
    }
    v->o.gr = (((y * y) >> 15) * 14745) >> 15;                      /* 0.45 BODY^2 */
    /* animal and sky: AURORA slides from one to the other */
    const int32_t xa = 32767 - ((a * 24576) >> 15);                  /* the animal 1 .. 0.25 */
    {
        const int32_t base = 1311 + ((b * 16384) >> 15);             /* breath 0.04 + 0.5 BREATH */
        const int32_t pf = (((v->puff * 19661) >> 15) * b) >> 15;    /* the puff, 0.6 BREATH */
        v->o.ah = base + pf > 32767 ? 32767 : base + pf;
        v->o.al = ((base * 6554) >> 15) + pf;                        /* 0.2 while the glottis is closed */
    }
    v->o.drv = 4096 + ((y * 12288) >> 15);                           /* 1 .. 4 */
    {
        const int32_t sl = (((2458 + ((y * 9830) >> 15)) * xa) >> 15) >> 3;   /* 0.5 (0.15 + 0.6 BODY) / 4 */
        v->o.l1 = sub == 1 || sub == 3 ? (sub == 3 ? (sl * 23170) >> 15 : sl) : 0;
        v->o.l2 = sub >= 2 ? (sub == 3 ? (sl * 23170) >> 15 : sl) : 0;
    }

    /* the bellow: the vowel opens from oo to CALL's (oh, aa, eh) over the first half of the call; THROAT scales it */
    const int32_t thr = 14746 + ((w5 * 18022) >> 15);                /* 0.45 .. 1.0 */
    const int32_t f0 = (int32_t)(((ENGINE_PITCH[0] >> 8) * 345u) >> 16);   /* the key, Hz: inc * 88200 / 2^32 */
    {
        const int32_t vp = (open * (2458 + ((c * 9830) >> 15))) >> 15;   /* Q12, 0 .. 3 */
        int32_t vi2 = vp >> 12, vf = vp & 4095;
        if (vi2 >= 3) { vi2 = 2; vf = 4096; }
        static const int16_t fg[3] = { 7373, 4424, 1843 };          /* 0.9 x (1, 0.6, 0.25) / 4 */
        static const int16_t fd[3] = { 3641, 2341, 1725 };          /* Q 9, 14, 19 */
        for (int k = 0; k < 3; k++) {
            const int32_t hz = e2_vowel[vi2][k] + (((e2_vowel[vi2 + 1][k] - e2_vowel[vi2][k]) * vf) >> 12);
            const int32_t fc = (hz * thr) >> 15;
            v->r.f[k] = e2_fhz(fc);
            /* a bandwidth of at least 0.6 of the key: a high note's harmonic on a narrow formant doesn't boom */
            int32_t dmin = (f0 * e2_recip(fc)) >> 5;                /* f0 / fc, Q15 */
            dmin = dmin > 65535 ? 65535 : dmin;
            const int32_t dk = (dmin * 19661) >> 15;
            v->r.d[k] = dk > fd[k] ? (dk > 32767 ? 32767 : dk) : fd[k];
            v->r.g[k] = (fg[k] * xa) >> 15;
        }
    }
    /* the chest: two modes, 95 and 166 Hz at THROAT 0.6 (the lower 71 .. 158 Hz over THROAT), Q 4 .. 18 with BODY */
    {
        static const int16_t bm[2] = { 158, 277 };
        const int32_t d = e2_tab(e2_d_body, y), g = (e2_tab(e2_g_body, y) * xa) >> 15;
        for (int k = 0; k < 2; k++) {
            v->r.f[3 + k] = e2_fhz((thr * bm[k]) >> 15);
            v->r.d[3 + k] = d;
            v->r.g[3 + k] = k == 0 ? g : (g * 19661) >> 15;          /* 0.6 */
        }
    }
    /* the breath's high band: above a one-pole at 1.2 kHz (1 - exp(-2 pi 1200 / 44100)), 0.8 BREATH / 4 */
    v->r.f[6] = 5149;
    v->r.d[6] = 0;
    v->r.g[6] = (((b * 6554) >> 15) * xa) >> 15;
    /* the aurora: two bands drifting (0.03 .. 0.28 and 0.02 .. 0.19 Hz with AURORA squared), Q 3..7 and 4..9 */
    {
        const int32_t a2 = (a * a) >> 15;
        v->d0 += 193227u + (uint32_t)((97392 * (a2 >> 4)) >> 7);
        v->d1 += 143364u + (uint32_t)((66227 * (a2 >> 4)) >> 7);
        const int32_t s0 = (sine_lfo(v->d0) + 32768) >> 1, s1 = (sine_lfo(v->d1) + 32768) >> 1;   /* 0 .. 32767 */
        const int16_t *k = e2_sky[sky];
        int32_t b1 = k[0], b2 = k[2];
        if (!b1) {                                                   /* fifths: the key's 3rd and 6th harmonic */
            b1 = 3 * f0; b2 = 6 * f0;
            b1 = b1 < 100 ? 100 : b1 > 1700 ? 1700 : b1;
            b2 = b2 < 200 ? 200 : b2 > 2400 ? 2400 : b2;
        }
        v->r.f[7] = e2_fhz((b1 * exp2q((k[1] * s0) >> 15)) >> 12);
        v->r.f[8] = e2_fhz((b2 * exp2q((k[3] * s1) >> 15)) >> 12);
        for (int j = 0; j < 2; j++) {               /* Q 3..7 and 4..9, a bandwidth of at least 0.6 of the key */
            const int32_t fc = (int32_t)((((j ? b2 : b1) * exp2q((k[1 + 2 * j] * (j ? s1 : s0)) >> 15)) >> 12));
            const int32_t dq = e2_tab(j ? e2_d_a2 : e2_d_a1, a), r0 = (f0 * e2_recip(fc)) >> 5,
                          dk = ((r0 > 65535 ? 65535 : r0) * 19661) >> 15;
            v->r.d[7 + j] = dk > dq ? (dk > 32767 ? 32767 : dk) : dq;
        }
        const int32_t sk = (a * 21299) >> 15;                         /* 0.65 AURORA (the sketch 0.9, levelled) */
        v->r.g[7] = sk;
        v->r.g[8] = (sk * 22938) >> 15;                              /* 0.7 */
        v->r.gd = (sk * 3932) >> 15;                                 /* 0.12 */
        elg2_band[0] = s0; elg2_band[1] = s1;
    }
    {   /* the output low-pass: BODY's, but never under twice the key (a high note keeps its fundamental) */
        const int32_t amin = f0 * 15 > 30000 ? 30000 : f0 * 15;    /* 2 f0: 2 pi 1.55 x 2 f0 / 44100, Q15 */
        const int32_t al = e2_tab(e2_lp, y);
        v->r.a = al > amin ? al : amin;
    }
    {
        const int32_t g = (((((15180 * vel) >> 7) * ELG2_LEVEL) >> 12) * (32767 - ((y * 9830) >> 15))) >> 15;   /* velocity as
                                                                       CLASSIC; the level; -3 dB at full BODY (the drive) */
        const int32_t gt = g > 32767 ? 32767 : g;
        if (v->gain < 0) v->gain = gt;
        v->r.gain = v->gain << 6;
        v->r.dgain = gt - v->gain;                                   /* << 6 / 64 */
        v->gain = gt;
    }

    int32_t peak = 0;
#if defined(__bfin__) && ELG2_ASM
    {
        uint32_t l0, l1, l2, l3;
        __asm__ volatile("%0 = L0;\n\t%1 = L1;\n\t%2 = L2;\n\t%3 = L3;" : "=d"(l0), "=d"(l1), "=d"(l2), "=d"(l3));
        elg2_osc(&v->o, e2_src, e2_asp, e2_aur, e2_sub);
        e2_res_asm(&v->r, e2_src, e2_asp, e2_aur, e2_sub, out + E2_N);
        elg2_up(out, &v->prev);
        peak = elg_peak(out);
        __asm__ volatile("L0 = %0;\n\tL1 = %1;\n\tL2 = %2;\n\tL3 = %3;" : : "d"(l0), "d"(l1), "d"(l2), "d"(l3));
    }
#else
    e2_osc(&v->o, e2_src, e2_asp, e2_aur, e2_sub);
    e2_res(&v->r, e2_src, e2_asp, e2_aur, e2_sub, out + E2_N);
    e2_up(out, &v->prev);
    for (int i = 0; i < ENGINE_BLOCK; i++) peak = out[i] > peak ? out[i] : -out[i] > peak ? -out[i] : peak;
#endif
    elg_level = peak;
    elg2_body = y;
    if (open > elg2_open) elg2_open = open;           /* the screen takes it and clears it */
}

/* ---- the dispatcher: R246's entry points ---- */
static uint8_t e2_mode[ENGINE_VOICES];               /* per voice: the mode its state is for, 1 CLASSIC, 2 v2 */
static inline int e2_mode_of(const int16_t *knobs) { return !ELG_FORCE_V2 && (ELG_FORCE_LEGACY || elg_classic(knobs)) ? 1 : 2; }

/* a note starts in its sound's mode, only that mode's state set up (CLASSIC as elg-v2 did, its random sequence too) */
void elg_note_on(void *self, const int16_t *knobs)
{
    const int vi = ENGINE_VOICE(self), mode = e2_mode_of(knobs);
    if (mode == 1) elg_classic_note_on(self, knobs);
    else e2_note_on(vi);
    e2_mode[vi] = (uint8_t)mode;
}

void elg_render(void *self, int16_t *out, const int16_t *knobs)
{
    const int vi = ENGINE_VOICE(self), mode = e2_mode_of(knobs), classic = mode == 1;
    if (e2_mode[vi] != mode) {                        /* switched while sounding: the other mode starts clean */
        if (classic) elg_classic_note_on(self, knobs);
        else e2_note_on(vi);
    }
    e2_mode[vi] = (uint8_t)mode;
    if (!classic) {
        for (int i = 0; i < 4; i++) elg_knobs[i] = knobs[i];
        e2_render(vi, out, knobs);
        elg_blocks++;
        elg_lfo = 0;
        elg_xg = 32767;
    } else if (ELG_FORCE_LEGACY || elg_legacy(knobs)) {
        elg_classic_render(self, out, knobs);         /* ELG as on elg-v2, word 7 its preset trim */
    } else {
        int16_t k[8];                                 /* CLASSIC from the v2 layout: as a legacy sound, trim 1x */
        for (int i = 0; i < 8; i++) k[i] = i < 5 ? knobs[i] : 0;
        elg_classic_render(self, out, k);
    }
}

void elg_note_off(void *self, const int16_t *knobs)
{
    elg_classic_note_off(self, knobs);
}
