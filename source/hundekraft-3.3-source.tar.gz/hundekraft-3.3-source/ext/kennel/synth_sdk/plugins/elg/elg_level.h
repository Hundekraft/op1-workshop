/* Bounded static output trims, Q12. Generated from production AC RMS at MIDI48/60/72, velocity100.
 * 5 intervals x17 timbres, movement off; -6.02..+3dB, nominal -18dBFS.
 * No signal detector/AGC: velocity, envelopes, detune and movement remain expressive.
 * Calibration/method: tools/presets/calibrate_levels.py.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
static const int16_t elg_level_trim[85] = {
 5786,5786,5786,3298,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,2048,
 2048,2048,5786,5786,5786,5786,3319,2251,2048,2048,2048,2048,2048,2048,2048,
 2048,2048,2048,2048,5786,5786,5786,5786,3676,2814,2048,2048,2048,2048,2048,
 2048,2048,2048,2048,2048,2048,5786,5786,5786,5786,4098,3669,2398,2048,2048,
 2048,2048,2048,2048,2048,2048,2048,2048,5786,5786,5786,5786,4034,3718,2584,
 2258,2048,2048,2048,2048,2048,2048,2048,2048,2048,
};
/* row r's trim at the timbre position (r 0..4) */
static inline int32_t elg_trim_row(int32_t r,int32_t index,int32_t pos)
{
    const int32_t a=elg_level_trim[r*17+index];
    return a+(((elg_level_trim[r*17+index+1]-a)*(pos&32767))>>15);
}
/* during the interval crossfade (elg.c, xf 0 .. 32768): between the two steps' rows; on a step its own row */
static inline int32_t elg_trim_xf(int32_t from,int32_t to,int32_t xf,int32_t index,int32_t pos)
{
    const int32_t a=elg_trim_row(from,index,pos);
    return to==from?a:a+(((elg_trim_row(to,index,pos)-a)*(xf>>3))>>12);
}
