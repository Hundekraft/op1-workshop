/* ELG v2's sample passes in C (2026-11-12): the reference the Blackfin kernels in elg2_dsp.S match bit for bit
 * (kern_check.py on bcore), and the code host builds run. elg2.c fills the control structs once a call.
 *   pass 1 e2_osc   64 samples at 44.1 kHz from oscillators at 88.2 kHz summed in pairs: the glottis (p4 << 2: a saw)
 *                   with its growl (bit 30 of p4: every other period louder or softer by gr), the breath (xorshift32,
 *                   gain ah in the first 35 % of the glottal period, al after), the two added and halved, saturated to
 *                   16 bits, driven (drv) into a soft clip -> src; the breath -> asp; the aurora's three saws (p4 << 2,
 *                   pa0, pa2) summed over both halves, >> 3 -> aur; the sub, two parabolic sines (p4 << 1, p4) -> sub.
 *                   The increments ramp over the call (i += d after each 44.1 kHz sample), from R246's first to its last.
 *   pass 2 e2_res   seven Chamberlin band-passes (formants 0..2 and body 3..4 on src, the aurora 7..8 on aur) and the
 *                   breath's high band (6: asp minus a one-pole low-pass), each band times its gain, plus the sub and the aurora's dry saws; two one-pole
 *                   low-passes; the output gain ramped over the call -> 64 samples (16 bits) and their peak
 *   pass 3 e2_up    44.1 -> 88.2 kHz, linear, in place
 * Every product of a 32-bit value and a Q15 coefficient is floor(a b / 2^15) (e2_mq), which the Blackfin forms
 * exactly as (a.L x 2b >> 16) + a.H x 2b in an accumulator.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef ELG2_DSP_H
#define ELG2_DSP_H
#include <stdint.h>

#define E2_N 64                       /* 44.1 kHz samples a call */
#define E2_NSVF 9                     /* formants 0..2, body 3..4 (5 unused), breath 6, aurora 7..8 */

/* elg2_dsp.S reads both structs by these offsets: keep the order */
typedef struct {
    uint32_t p4, pa0, pa2, nz;        /* 0 phases (the glottis is p4 << 2, the subs p4 << 1 and p4), 12 the noise LCG */
    int32_t i4, d4, ia0, da0, ia2, da2;   /* 16 increments (an 88.2 kHz step) and their change a 44.1 kHz sample */
    int32_t gr;                       /* 40 growl Q15, 0 .. 14745 */
    int32_t ah, al;                   /* 44 breath gain Q15 while the glottis is open / closed, 0 .. 32767 */
    int32_t drv;                      /* 52 drive Q12, 4096 .. 16384 */
    int16_t l1, l2;                   /* 56, 58 sub levels Q15, 0 .. 2047 (one 32-bit load) */
} e2_osc_t;
typedef struct {
    int32_t f[E2_NSVF], d[E2_NSVF], g[E2_NSVF];   /* 0, 36, 72: SVF coefficient (16 .. 16000), damping 1/Q, gain; Q15 */
    int32_t gd;                       /* 108 the aurora's dry saws, Q15 */
    int32_t a;                        /* 112 the output low-pass coefficient, Q15 */
    int32_t gain, dgain;              /* 116 output gain Q15 << 6 at the first sample, 120 its step a sample */
    int32_t st[E2_NSVF][2];           /* 124 SVF states: low, band */
    int32_t lp1, lp2;                 /* 196, 200 */
} e2_res_t;

static inline int32_t e2_mq(int32_t a, int32_t b)          /* floor(a b / 2^15), 0 <= b < 2^15, |a| < 2^30 */
{
    return (a >> 15) * b + (((a & 0x7FFF) * b) >> 15);
}
static inline int32_t e2_par(uint32_t ph)                   /* a sine, +-32767, as a parabola (3rd harmonic -29 dB) */
{
    const int32_t x = (int32_t)(ph ^ 0x80000000u) >> 16, ax = x < -32767 ? 32767 : x < 0 ? -x : x;   /* |x| saturates */
    const int32_t y = (x * (32768 - ax)) >> 13;
    return y > 32767 ? 32767 : y;
}
static inline int32_t e2_s16(int32_t x) { return x > 32767 ? 32767 : x < -32768 ? -32768 : x; }

static void e2_osc(e2_osc_t *o, int16_t *src, int16_t *asp, int16_t *aur, int16_t *sub)
{
    uint32_t p4 = o->p4, pa0 = o->pa0, pa2 = o->pa2, nz = o->nz;
    int32_t i4 = o->i4, ia0 = o->ia0, ia2 = o->ia2;
    for (int j = 0; j < E2_N; j++) {
        int32_t g = 0, as = 0;
        for (int h = 0; h < 2; h++) {                                  /* two steps at 88.2 kHz */
            p4 += (uint32_t)i4; pa0 += (uint32_t)ia0; pa2 += (uint32_t)ia2;
            const int32_t s = (int32_t)(((p4 << 2) ^ 0x80000000u)) >> 16;
            g += s;
            as += s + ((int32_t)(pa0 ^ 0x80000000u) >> 16) + ((int32_t)(pa2 ^ 0x80000000u) >> 16);
        }
        i4 += o->d4; ia0 += o->da0; ia2 += o->da2;                     /* the ramp, a 44.1 kHz step */
        g >>= 1;                                                       /* the pair's mean */
        const int32_t gw = (g * o->gr) >> 15;                          /* the growl: period doubling */
        g = p4 & 0x40000000u ? g + gw : g - gw;
        nz ^= nz << 13; nz ^= nz >> 17; nz ^= nz << 5;                 /* xorshift32 */
        const int32_t a = (((int32_t)nz >> 16) * ((p4 << 2) < 0x5999999Au ? o->ah : o->al)) >> 15;
        int32_t x = (e2_s16((g + a) >> 1) * o->drv) >> 11;             /* glottis and breath, driven */
        x = e2_s16(x);
        x = ((x * (32768 - ((x * x) >> 15))) >> 16) + x;               /* soft clip, 1.5x - 0.5x^3 */
        src[j] = (int16_t)x;
        asp[j] = (int16_t)e2_s16(a);
        aur[j] = (int16_t)(as >> 3);
        sub[j] = (int16_t)((e2_par(p4 << 1) * o->l1 + e2_par(p4) * o->l2) >> 15);
    }
    o->p4 = p4; o->pa0 = pa0; o->pa2 = pa2; o->nz = nz;
    o->i4 = i4; o->ia0 = ia0; o->ia2 = ia2;
}

/* one Chamberlin step, the band-pass out (f <= 16000 and Q <= 19 keep it stable; |band| stays far under 2^30) */
static inline int32_t e2_bp(int32_t *s, int32_t x, int32_t f, int32_t d)
{
    int32_t low = s[0], band = s[1];
    low += e2_mq(band, f);
    const int32_t high = x - low - e2_mq(band, d);
    band += e2_mq(high, f);
    s[0] = low; s[1] = band;
    return band;
}

static int32_t e2_res(e2_res_t *r, const int16_t *src, const int16_t *asp, const int16_t *aur, const int16_t *sub, int16_t *y)
{
    int32_t lp1 = r->lp1, lp2 = r->lp2, gw = r->gain, peak = 0;
    for (int j = 0; j < E2_N; j++) {
        const int32_t x = src[j], b = asp[j], s = aur[j];
        int32_t v = sub[j] + e2_mq(s, r->gd);
        for (int k = 0; k < 5; k++) v += e2_mq(e2_bp(r->st[k], x, r->f[k], r->d[k]), r->g[k]);
        r->st[6][0] += e2_mq(b - r->st[6][0], r->f[6]);              /* the breath's high band: b minus a one-pole */
        v += e2_mq(b - r->st[6][0], r->g[6]);
        for (int k = 7; k < 9; k++) v += e2_mq(e2_bp(r->st[k], s, r->f[k], r->d[k]), r->g[k]);
        lp1 += e2_mq(v - lp1, r->a);
        lp2 += e2_mq(lp1 - lp2, r->a);
        const int32_t o = e2_s16(e2_mq(lp2, gw >> 6));
        gw += r->dgain;
        y[j] = (int16_t)o;
        peak = o > peak ? o : -o > peak ? -o : peak;
    }
    r->lp1 = lp1; r->lp2 = lp2;
    return peak;
}

/* 44.1 -> 88.2 kHz, linear, in place (y at out[64..127]); prev: the last call's last sample */
static void e2_up(int16_t *out, int32_t *prev)
{
    int32_t p = *prev;
    for (int j = 0; j < E2_N; j++) {
        const int32_t y = out[E2_N + j];
        out[2 * j] = (int16_t)((p + y) >> 1);
        out[2 * j + 1] = (int16_t)y;
        p = y;
    }
    *prev = p;
}

#ifdef __bfin__
/* elg2_dsp.S */
void elg2_osc(e2_osc_t *o, int16_t *src, int16_t *asp, int16_t *aur, int16_t *sub);
void elg2_mix(const int16_t *sub, const int16_t *aur, int32_t *v, int32_t gd);
void elg2_svf(const int16_t *x, int32_t *v, int32_t *st, const int32_t *c);
void elg2_hp(const int16_t *x, int32_t *v, int32_t *st, const int32_t *c);
void elg2_out(const int32_t *v, int16_t *y, e2_res_t *r);
void elg2_up(int16_t *out, int32_t *prev);
/* pass 2 on the kernels: the same sum as e2_res, term by term (integer adds in another order); no peak */
static void e2_res_asm(e2_res_t *r, const int16_t *src, const int16_t *asp, const int16_t *aur, const int16_t *sub, int16_t *y)
{
    static int32_t vb[E2_N + 1];                    /* vb[0]: elg2_svf's scratch */
    int32_t *const v = vb + 1, c[3];
    elg2_mix(sub, aur, v, r->gd);
    for (int k = 0; k < E2_NSVF; k++) {
        if (k == 5) continue;
        c[0] = r->f[k]; c[1] = k == 6 ? r->g[k] : r->d[k]; c[2] = r->g[k];
        if (k == 6) elg2_hp(asp, v, r->st[6], c);
        else elg2_svf(k < 6 ? src : aur, v, r->st[k], c);
    }
    elg2_out(v, y, r);
}
#endif
#endif
