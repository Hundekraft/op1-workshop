#!/usr/bin/env python3
# Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""CLASSIC against ELG as it was on branch elg-v2 (kennel 6e084ceb): builds classic_run.h's run (host C) once through
this ELG's dispatcher with legacy words (CLASSIC) and once with 6e084ceb's elg.c / elg_level.h taken from git (that
ELG has only the one mode), prints both hashes and exits 1 when they differ. A match is the same output sample for
sample for that run. harness/elg2_test.c asserts the hash printed here (CLASSIC_HASH in classic_run.h). Prints SKIP
when the commit is not in this clone.

    python3 synth_sdk/plugins/elg/classic_check.py
"""
import subprocess
import sys
import tempfile
from pathlib import Path

P = Path(__file__).resolve().parent
SDK = P.parent.parent
OLD = '6e084ceb'                                       # branch elg-v2: ELG before v2
DRIVER = '''#define ENGINE_HOST_TEST
%(renames)s
#include "elg.c"
%(extra)s
#include <stdio.h>
uint32_t engine_host_pitch[128];
#define CR_ON(s, k) %(on)s(s, k)
#define CR_RENDER(s, o, k) %(render)s(s, o, k)
#include "%(run)s"
int main(void){printf("%%016llx\\n",(unsigned long long)classic_run());return 0;}
'''


def build_run(tmp, name, inc, **kw):
    d = tmp / (name + '.c')
    d.write_text(DRIVER % dict(kw, run=P / 'classic_run.h'))
    exe = tmp / (name + '.exe')
    subprocess.run(['cc', '-O1', '-w', f'-I{inc}', f'-I{SDK}', str(d), '-o', str(exe)], check=True)
    return subprocess.run([str(exe)], check=True, capture_output=True, text=True).stdout.strip()


def main():
    root = subprocess.run(['git', 'rev-parse', '--show-toplevel'], cwd=P, capture_output=True, text=True).stdout.strip()
    rel = P.relative_to(Path(root).resolve()) if root else None
    with tempfile.TemporaryDirectory(prefix='elg-classic-') as tmp:
        tmp = Path(tmp)
        old = tmp / 'old'
        old.mkdir()
        for f in ('elg.c', 'elg_level.h'):
            r = subprocess.run(['git', 'show', f'{OLD}:{rel}/{f}'], cwd=P, capture_output=True)
            if r.returncode:
                print(f'elg classic: SKIP ({OLD} not in this clone)')
                return 0
            (old / f).write_bytes(r.stdout)
        ren = ('#define engine_note_on elg_classic_note_on\n#define engine_render elg_classic_render\n'
               '#define engine_note_off elg_classic_note_off')
        a = build_run(tmp, 'now', P, renames=ren, extra='#include "elg2.c"', on='elg_note_on', render='elg_render')
        b = build_run(tmp, 'old', old, renames='', extra='', on='engine_note_on', render='engine_render')
    print(f'elg classic: CLASSIC {a}, {OLD} {b}', 'same' if a == b else 'DIFFER')
    return 0 if a == b else 1


if __name__ == '__main__':
    sys.exit(main())
