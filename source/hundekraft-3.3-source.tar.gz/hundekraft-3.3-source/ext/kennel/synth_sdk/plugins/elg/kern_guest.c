/* ELG v2's Blackfin kernels (elg2_dsp.S) against their C (elg2_dsp.h) on bcore (kern_check.py): e2_osc / elg2_osc and
 * e2_res / e2_res_asm on the same control, every output sample and the whole state compared after every
 * call (and e2_up / elg2_up on the output). Scenarios: every control at its ends with phases and states at random (the saturating drive, the clip at
 * -32768, the sub at its ends), random controls every call over long runs (glides: the ramps up and down), and the
 * filter states grown large (a high-Q band rung by full-scale input).
 * Prints "KERN ok calls=N" or the first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdint.h>
#include "elg2_dsp.h"
void t2_write(const char *, int);
uint32_t t2_r246_calls[2];
static e2_osc_t oc, oa;
static e2_res_t rc, ra;
static int16_t u3[2 * E2_N], u4[2 * E2_N];
static int16_t s1[E2_N], a1[E2_N], u1[E2_N], b1[E2_N], s2[E2_N], a2[E2_N], u2[E2_N], b2[E2_N], y1[E2_N], y2b[E2_N + 2];
static int16_t *const y2 = y2b + 2;                   /* elg2_out writes y[-1] (out[63] in elg2.c) */
static unsigned calls, bad;
static char line[120];
static int n;
static void put(const char *p) { while (*p) line[n++] = *p++; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = '0' + v % 10; while (v /= 10); put(b + i); }
static int same(const void *a, const void *b, unsigned len)
{
    const uint8_t *x = a, *y = b;
    for (unsigned i = 0; i < len; i++) if (x[i] != y[i]) return 0;
    return 1;
}
static uint32_t rng = 777;
static uint32_t r32(void) { rng = rng * 1664525u + 1013904223u; return rng ^ (rng >> 15); }
static int32_t rr(int32_t lo, int32_t hi) { return lo + (int32_t)(r32() % (uint32_t)(hi - lo + 1)); }
static void call(unsigned what)
{
    oa = oc; ra = rc;
    int32_t q1 = (int32_t)(r32() >> 16) - 32768, q2 = q1;
    e2_osc(&oc, s1, a1, u1, b1);
    elg2_osc(&oa, s2, a2, u2, b2);
    const int32_t p1 = e2_res(&rc, s1, a1, u1, b1, y1);
    e2_res_asm(&ra, s1, a1, u1, b1, y2);
    (void)p1;
    for (int i = 0; i < E2_N; i++) { u3[E2_N + i] = y1[i]; u4[E2_N + i] = y1[i]; u3[i] = u4[i] = 0x5555; }
    e2_up(u3, &q1);
    elg2_up(u4, &q2);
    if (q1 != q2) u3[0] ^= 1;
    calls++;
    if (bad) return;
    const char *w = !same(s1, s2, sizeof s1) ? "src" : !same(a1, a2, sizeof a1) ? "asp" : !same(u1, u2, sizeof u1) ? "aur" :
                    !same(b1, b2, sizeof b1) ? "sub" : !same(&oc, &oa, sizeof oc) ? "osc state" : !same(y1, y2, sizeof y1) ? "out" :
                    !same(&rc, &ra, sizeof rc) ? "res state" : !same(u3, u4, sizeof u3) ? "up" : 0;
    if (w) { bad = 1; put("KERN differ "); put(w); put(" scenario="); num(what); put(" call="); num(calls); put("\n"); }
}
static void controls(int ends)
{
    const int e = ends ? (int)(r32() & 1) : -1;
#define PICK(lo, hi) (ends ? (r32() & 1 ? (hi) : (lo)) : rr(lo, hi))
    oc.i4 = PICK(0, 0x7FFFFFF); oc.d4 = PICK(-40000, 40000);
    oc.ia0 = PICK(0, 0x7FFFFFFF); oc.da0 = PICK(-200000, 200000);
    oc.ia2 = (int32_t)PICK(0, 0x7FFFFFFF) * 2; oc.da2 = PICK(-400000, 400000);
    oc.gr = PICK(0, 14745); oc.ah = PICK(0, 32767); oc.al = PICK(0, 32767); oc.drv = PICK(4096, 16384);
    oc.l1 = (int16_t)PICK(0, 2047); oc.l2 = (int16_t)PICK(0, 2047);
    for (int k = 0; k < E2_NSVF; k++) {
        rc.f[k] = k == 6 ? PICK(1, 32767) : PICK(16, 16000);
        rc.d[k] = PICK(1724, 32767);
        rc.g[k] = PICK(0, 32767);
    }
    rc.gd = PICK(0, 32767); rc.a = PICK(1, 32767);
    rc.gain = PICK(0, 32767) << 6; rc.dgain = PICK(-512, 511);
    if ((rc.gain >> 6) + ((rc.dgain * 64) >> 6) > 32767 || (rc.gain >> 6) + ((rc.dgain * 64) >> 6) < 0) rc.dgain = 0;
    (void)e;
}
int main(void)
{
    oc.nz = 1;
    for (unsigned s = 0; s < 400 && !bad; s++) {                        /* ends, phases and states at random */
        controls(1);
        oc.p4 = r32(); oc.pa0 = r32(); oc.pa2 = r32(); oc.nz = r32() | 1;
        for (int k = 0; k < E2_NSVF; k++) { rc.st[k][0] = rr(-300000, 300000); rc.st[k][1] = rr(-300000, 300000); }
        rc.lp1 = rr(-200000, 200000); rc.lp2 = rr(-200000, 200000);
        for (int c = 0; c < 6 && !bad; c++) call(1);
    }
    for (unsigned s = 0; s < 3000 && !bad; s++) { controls(0); call(2); }   /* random controls every call */
    controls(0);
    for (int k = 0; k < E2_NSVF; k++) { rc.d[k] = 1724; rc.g[k] = 32767; }
    oc.drv = 16384; oc.ah = oc.al = 32767;
    for (unsigned s = 0; s < 1500 && !bad; s++) call(3);                  /* high Q rung hard: big states */
    if (!bad) { put("KERN ok calls="); num(calls); put("\n"); }
    t2_write(line, n);
    return 0;
}
