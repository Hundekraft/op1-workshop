/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* One fixed six-voice run through ELG's entry points, hashed (64-bit FNV-1a over every output sample of every call):
 * harness/elg2_test.c runs it through the dispatcher with legacy words (words 5 and 6 at 0: CLASSIC) and asserts
 * CLASSIC_HASH; classic_check.py builds the same run against kennel 6e084ceb's elg.c (branch elg-v2, which has only
 * the one mode) and prints both hashes. The run: 4,000 calls, a voice struck every 37 calls at a new pitch (C1 .. C8,
 * voice 5 left to release), knob words changing every 41 calls (blue across the bands, so the interval crossfades
 * run, and slow ramps between), word 7 the preset trim (0, then factory trims, then every 997th word).
 * Define CR_ON(self, k) and CR_RENDER(self, out, k) and engine_host_pitch before including. */
#ifndef ELG_CLASSIC_RUN_H
#define ELG_CLASSIC_RUN_H
#define CLASSIC_HASH 0x1fcd579b6c9641b6ull   /* kennel 6e084ceb (classic_check.py) */
static uint64_t cr_hash;
static uint64_t classic_run(void)
{
    static const int16_t trims[6] = { 0, 10081, 15795, 6434, 18218, 12403 };
    int16_t k[8] = { 16384, 8192, 20000, 8192, 0, 0, 0, 0 }, out[128];
    uint32_t rng = 4242, inc[6];
    cr_hash = 0xCBF29CE484222325ull;
    for (int v = 0; v < 6; v++) inc[v] = 0;
    for (unsigned n = 0; n < 4000; n++) {
        if (n % 41 == 0) {
            for (int i = 0; i < 4; i++) {
                rng = rng * 1664525u + 1013904223u;
                k[i] = (int16_t)((n / 41) % 3 == 0 ? (rng >> 17) : (k[i] + (int32_t)((rng >> 22) & 1023) - 512) & 32767);
            }
            k[7] = n < 1500 ? trims[(n / 41) % 6] : (int16_t)((n * 997u) & 32767);
        }
        if (n % 37 == 0) {
            const int v = (int)((n / 37) % 5);
            rng = rng * 1664525u + 1013904223u;
            inc[v] = 2000000u + (rng >> 4) % 200000000u;
            for (int i = 0; i < 128; i++) engine_host_pitch[i] = inc[v];
            CR_ON((void *)(uintptr_t)(0xFFB00000u + 36u * (unsigned)v), k);
            if (n == 0) { inc[5] = 9000000u; CR_ON((void *)(uintptr_t)(0xFFB00000u + 36u * 5u), k); }
        }
        for (int v = 0; v < 6; v++) {
            if (!inc[v]) continue;
            for (int i = 0; i < 128; i++) engine_host_pitch[i] = inc[v] + (uint32_t)(i * (v + 1));
            CR_RENDER((void *)(uintptr_t)(0xFFB00000u + 36u * (unsigned)v), out, k);
            for (int i = 0; i < 128; i++) cr_hash = (cr_hash ^ (uint16_t)out[i]) * 0x100000001B3ull;
        }
    }
    return cr_hash;
}
#endif
