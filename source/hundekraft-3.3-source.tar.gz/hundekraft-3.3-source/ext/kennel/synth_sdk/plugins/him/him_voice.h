/* HIM's drum voice: the original drum engine's synthesis (ported with the author's permission per the owner,
 * 2026-11-09; spec: OP1-Emulator docs/ports/him-spec.md section 3, model him-data/him-voice-model.py, bit-exact).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HIM_VOICE_H
#define HIM_VOICE_H
#include <stdint.h>

/* A block's values for the sample loops (him_voice.c's C loops, him_kern.S's assembly), worked out by
 * him_voice_render into one scratch shared by all voices (it stays in the data cache over a block's voices); the
 * assembly reads it at these byte offsets (him_voice.c checks them). */
typedef struct {
    uint32_t r[6];           /*   0 the metal's six increments */
    int32_t m0, mi;          /*  24 metal level at the block's start, its step a sample */
    int32_t nz0, ni;         /*  32 noise level, step */
    int32_t inc0, dinc;      /*  40 body increment and its step */
    int32_t b0, bi;          /*  48 body level, step */
    int32_t flag;            /*  56 him_k_noise: metal; him_k_body: add; him_k_drive: crunch */
} him_kp;

/* the voice's constants that depend only on the key's numbers, the pitch and choke, and what they were worked out
 * for (him_voice.c derive); the assembly reads the first nine at these byte offsets from the voice */
typedef struct {
    int32_t fc, cmix, G;     /*  0 filter frequency, mix, output gain */
    int32_t colhi;           /* 12 0: low pass to band pass, 1: band pass to high pass */
    int32_t g;               /* 16 body shape gain */
    int32_t dgs, douts;      /* 20 drive gain in, out */
    int32_t hold, mask;      /* 28 crunch: sample-and-hold length, bit mask */
    uint32_t f1, f2, f3;
    int32_t u, samt, msc, b, q, crunch;
    int16_t par[8];
    int32_t logp, choke, ok, inc_ok;
    uint32_t inc_swp, inc;   /* the body increment for sweep level inc_swp (the last block's end) */
} him_vcache;

typedef struct {
    uint32_t ph[7];          /* body phase, six metal phases (2^32 a cycle) */
    uint32_t seed;           /* xorshift32 noise */
    int32_t lp, bp;          /* colour filter states */
    uint32_t env, nenv;      /* main and noise envelopes (velocity 127: 0x7FFE00) */
    uint32_t swp;            /* sweep envelope, 0x10000 = full */
    int32_t hold_n, hold_v;  /* crunch sample-and-hold */
    int32_t choke;           /* 1: silent / choked (x1/4 a block) */
    uint32_t ratio;          /* last pitch ratio x 65536 and its log2 (Q12) */
    int32_t logp;
    him_vcache c;            /* at 72 */
} him_voice;

uint32_t him_exp2q(int32_t x);                       /* 65536 * 2^(x / 4096) */
int32_t him_log2q(uint32_t r);                       /* 4096 * log2(r / 65536) */
void him_voice_init(him_voice *v, int index);
void him_voice_note(him_voice *v, int velocity);     /* 1..127 */
static inline void him_voice_choke(him_voice *v) { v->choke = 1; }
static inline int him_voice_finished(const him_voice *v) { return v->env < 0x300 && v->nenv < 0x300; }
/* one block: 64 samples at 44.1 kHz, each written twice into out[128] (88.2 kHz); par = the key's eight numbers,
 * ratio = pitch ratio x 65536 (0 = 1) */
void him_voice_render(him_voice *v, int16_t *out, const int16_t *par, uint32_t ratio);
/* the sample loops (C in him_voice.c, Blackfin assembly in him_kern.S; HIM_KERN_C builds the C everywhere):
 * metal and noise through the filter into out[64..127] (metal only if kp->flag), the body added there (written if
 * !kp->flag), then the drive (crunch if kp->flag) from out[64..127] into out[0..127], each sample twice */
void him_k_noise(him_voice *v, int16_t *out, const him_kp *kp);
void him_k_body(him_voice *v, int16_t *out, const him_kp *kp);
void him_k_drive(him_voice *v, int16_t *out, const him_kp *kp);
/* the original's choke-group rule: (max(knob 6, 0) + 0x1000) >> 13, 0 = none */
static inline int him_group(const int16_t *par) { return ((par[6] > 0 ? par[6] : 0) + 0x1000) >> 13; }

#endif
