/* HIM's T1 page: the original drum engine's page (ported with the author's permission per the owner, 2026-11-09;
 * OP1-Emulator docs/ports/him-spec.md section 8): the box (him.svg, drawn through the static-prefix cache), the scope
 * band, throw trails, impact rings, the solids back to front with their outline, centre cross and speed arrow,
 * sparks, choke links, debris, the preview of the current key while a knob turns, the value labels (green push) and
 * the choke / values labels. The page only draws: the world runs in the main loop (him_fw.c).
 * Inputs come through him_src_* (him_fw.c on the OP-1, test/screen_test.c on the host). GUI thread.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "him_page.h"
#include "him_f3.h"
#include "him_mesh.h"
#include "him_data.h"
#include "him_voice.h"

#ifdef HIM_F3_ROUTE
#include HIM_F3_ROUTE                                           /* tests: the original renderer instead */
#endif

#define E0 0x698EFFu     /* stock encoder colours: blue, green, white, orange (the original reads the theme's) */
#define E1 0x00ED95u
#define E2 0xDFD9FFu
#define E3 0xFF3A5Du
#define U(x) ((int)((x) * 256))                               /* page units -> Q8 */
/* the original's camera and placement (gen_data.py): an owner-approved exception to the OLED bottom-margin target */
#define PAGE_SCALE HIM_SCALE
#define PAGE_CY HIM_CY
#define LABEL_YMAX U(132)

static him_world W;
static int16_t last_knobs[8];
static int last_key = -1, ov_active, ov_knob, last_values = -1;
static int ov_t, choke_t = -1, values_t = -1, spin, step_frac;
static int bbox[HIM_BODIES][4];

static inline int pk(const int16_t *k, int i) { return k[i] > 0 ? k[i] : 0; }
static inline int p_min(int a, int b) { return a < b ? a : b; }
static inline int p_max(int a, int b) { return a > b ? a : b; }

/* ---- text ---- */
static char *sput(char *p, const char *s) { while (*s) *p++ = *s++; *p = 0; return p; }
static char *num(char *p, int v)
{
    char t[12];
    int n = 0;
    if (v < 0) { *p++ = '-'; v = -v; }
    do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n) *p++ = t[--n];
    *p = 0;
    return p;
}
static int len(const char *s) { int n = 0; while (s[n]) n++; return n; }

static void label(int x, int y, uint32_t colour, int alpha, const char *text)
{
    const int w = f3_text_width(2, len(text));
    x = x < U(4) ? U(4) : p_min(x, U(316) - w);
    y = y < U(30) ? U(30) : y > LABEL_YMAX ? LABEL_YMAX : y;
    const int box[4][2] = { { x - U(2), y - U(2) }, { x + w + U(2), y - U(2) }, { x + w + U(2), y + U(13) }, { x - U(2), y + U(13) } };
    f3_fill_alpha(box, 4, alpha);
    f3_ink(F3_RGB(colour), alpha | 0x10000);
    f3_text(x, y, 2, text);
}

/* ---- a solid ---- */
static int px[HIM_MESH_V][2];
static int hull[64][2];
static int full[HIM_MESH_E][4];
static uint8_t front[HIM_MESH_F];

static int hull_of(int n)
{
    static int s[HIM_MESH_V][2];
    for (int i = 0; i < n; i++) { s[i][0] = px[i][0]; s[i][1] = px[i][1]; }
    for (int i = 1; i < n; i++)                                   /* by X, then Y */
        for (int j = i; j > 0 && (s[j][0] < s[j - 1][0] || (s[j][0] == s[j - 1][0] && s[j][1] < s[j - 1][1])); j--) {
            int a = s[j][0], b = s[j][1];
            s[j][0] = s[j - 1][0]; s[j][1] = s[j - 1][1]; s[j - 1][0] = a; s[j - 1][1] = b;
        }
    int k = 0;
#define CROSS(o, a, b) (((((a)[0] - (o)[0]) >> 4) * (((b)[1] - (o)[1]) >> 4)) - ((((a)[1] - (o)[1]) >> 4) * (((b)[0] - (o)[0]) >> 4)))  /* the original's >> 4 */
    for (int i = 0; i < n; i++) {
        while (k >= 2 && CROSS(hull[k - 2], hull[k - 1], s[i]) <= 0) k--;
        hull[k][0] = s[i][0]; hull[k][1] = s[i][1]; k++;
    }
    for (int i = n - 2, t = k + 1; i >= 0; i--) {
        while (k >= t && CROSS(hull[k - 2], hull[k - 1], s[i]) <= 0) k--;
        hull[k][0] = s[i][0]; hull[k][1] = s[i][1]; k++;
    }
#undef CROSS
    k = k > 1 ? k - 1 : k;
    return k > 32 ? 32 : k;
}

static uint32_t mix(uint32_t a, uint32_t b, int t)          /* per channel a + ((b - a) t >> 8), as the original */
{
    uint32_t r = 0;
    for (int s = 0; s < 24; s += 8) {
        const int ca = (int)((a >> s) & 255), cb = (int)((b >> s) & 255);
        r |= (uint32_t)(ca + (((cb - ca) * t) >> 8)) << s;
    }
    return r;
}
static uint32_t scale(uint32_t c, int t) { return mix(0, c, t); }

static void draw_solid(const him_body *b, int alpha, int *bb)
{
    const him_mesh *m = him_mesh_get(him_shape_index(b->knobs[5]));
    int R[9];
    f3_rotation(R, b->yaw, 0, b->roll);
    const int drv = pk(b->knobs, 7), crunch = b->knobs[7] >= 0x4CCE;
    const int g = crunch ? 0x100 + (drv - 0x4CCD) * 0x480 / 0x3332 : 0;
    bb[0] = bb[1] = 0x7fffffff; bb[2] = bb[3] = -0x7fffffff;
    for (int i = 0; i < m->nv; i++) {
        int w[3], p[3];
        f3_apply(w, R, (const int *)m->v[i], 0);
        p[0] = b->x + ((w[0] * b->r + 0x800) >> 12); p[1] = b->y + ((w[1] * b->r + 0x800) >> 12); p[2] = b->z + ((w[2] * b->r + 0x800) >> 12);
        int X, Y;
        f3_project(p, &X, &Y);
        if (crunch) { X = (X + g / 2) - (X + g / 2) % g; Y = (Y + g / 2) - (Y + g / 2) % g; }
        px[i][0] = X; px[i][1] = Y;
        bb[0] = p_min(bb[0], X); bb[1] = p_min(bb[1], Y); bb[2] = p_max(bb[2], X); bb[3] = p_max(bb[3], Y);
    }
    for (int f = 0; f < m->nf; f++) {
        int s = 0;
        for (int i = 0; i < m->fv; i++) {
            const int *a = px[m->f[f][i]], *c = px[m->f[f][(i + 1) % m->fv]];
            s += (a[0] >> 4) * (c[1] >> 4) - (c[0] >> 4) * (a[1] >> 4);
        }
        front[f] = s < 0;
    }
    const int nh = hull_of(m->nv);                                /* black silhouette: hides what is behind */
    if (alpha >= 256) f3_fill(hull, nh); else f3_fill_alpha(hull, nh, alpha);
    const uint32_t C = mix(E1, E3, drv >> 7);
    int nf = 0;
    for (int e = 0; e < m->ne; e++) {
        const int f1 = m->e[e][2], f2 = m->e[e][3], w = m->w[e];
        const int *a = px[m->e[e][0]], *c = px[m->e[e][1]];
        if (front[f1] != front[f2] || (front[f1] && w >= 0xFA)) {
            full[nf][0] = a[0]; full[nf][1] = a[1]; full[nf][2] = c[0]; full[nf][3] = c[1]; nf++;
        } else if (front[f1] && w > 0) {
            const int seg[1][4] = { { a[0], a[1], c[0], c[1] } };
            f3_ink(F3_RGB(scale(C, w)), alpha | 0x10000);
            f3_lines(seg, 1, 1);
        }
    }
    f3_ink(F3_RGB(C), (alpha) | 0x10000);
    f3_lines(full, nf, 1);
}

static void outline(const him_body *b, const int *bb, int alpha)
{
    const int n = (6 * pk(b->knobs, 4) + 0x3FFF) / 0x7FFF;
    if (n <= 0) return;
    f3_ink(F3_RGB(E0), (alpha) | 0x10000);
    f3_rect(bb[0] - U(2), bb[1] - U(2), bb[2] + U(2), bb[3] + U(2), n, 6 - n, 2);
}

static void project(int x, int y, int z, int *X, int *Y)
{
    const int p[3] = { x, y, z };
    f3_project(p, X, Y);
}

static void overlays(const him_body *b, const int *bb)
{
    const int a = b->alpha;
    outline(b, bb, a * 3 / 4);
    int X, Y;
    project(b->x, b->y, b->z, &X, &Y);
    const int cross[2][4] = { { X - U(2.5), Y, X + U(2.5), Y }, { X, Y - U(2.5), X, Y + U(2.5) } };
    f3_ink(F3_RGB(0xFFFFFF), (a * 4 / 5) | 0x10000);
    f3_lines(cross, 2, 2);
    const int sp = him_isqrt((uint32_t)((b->vx >> 4) * (b->vx >> 4) + (b->vy >> 4) * (b->vy >> 4))) * 16;
    if (sp <= 0xCCD) return;
    /* the original's speed arrow (page 0x3D00..0x3DE0): Q12 unit vector, length, then a 0x380 head at +-28.5 degrees */
    const int ux = (b->vx * 16) / (sp >> 8), uy = (b->vy * 16) / (sp >> 8);
    const int L = (((((pk(b->knobs, 7) >> 3) * 0x1EC + 0x800) >> 12) + 0xCD) * p_min(sp, 0x1E000) + 0x800) >> 12;
    int TX, TY;
    project(b->x + ((ux * L + 0x800) >> 12), b->y + ((uy * L + 0x800) >> 12), b->z, &TX, &TY);
    f3_ink(F3_RGB(E2), (a * 9 / 10) | 0x10000);
    int seg[3][4] = { { X, Y, TX, TY } };
    int n = 1;
    const int dx = TX - X, dy = TY - Y, d = him_isqrt((uint32_t)((dx >> 4) * (dx >> 4) + (dy >> 4) * (dy >> 4))) * 16;
    if (d > 0x100) {
        const int ex = dx * 0x380 / d, ey = dy * 0x380 / d;
        const int hx = TX - ((ex * 0xE0B + 0x800) >> 12), hy = TY - ((ey * 0xE0B + 0x800) >> 12);
        const int ox = (ey * 0x7AC + 0x800) >> 12, oy = (ex * 0x7AC + 0x800) >> 12;
        seg[1][0] = hx + ox; seg[1][1] = hy - oy; seg[1][2] = TX; seg[1][3] = TY;
        seg[2][0] = hx - ox; seg[2][1] = hy + oy; seg[2][2] = TX; seg[2][3] = TY;
        n = 3;
    }
    f3_lines(seg, n, 1);
}

/* ---- the preview of the current key ---- */
static int path[200][2];
static void value_label(int k, const int16_t *kn8, const int *bb, int xf, int yf, int xt, int yt,
                        int np, int A)
{
    char t[32], *p = t;
    uint32_t col = E0;
    int x = 0, y = 0;
    switch (k) {
    case 0: {
        const int p0 = kn8[0] < -0x5F00 ? -0x5F00 : kn8[0] > 0x6100 ? 0x6100 : kn8[0], u = ((p0 + 0x5F00) * 2) / 3;
        p = sput(p, "pitch "); p = num(p, (int)((him_exp2q(u) * 7) >> 14)); sput(p, " hz");
        col = E0; x = bb[2] + U(5); y = bb[1];
        break;
    }
    case 1: {
        const int ms = (int)((him_exp2q(pk(kn8, 1)) * 15u) >> 16);
        p = sput(p, "decay ");
        if (ms < 1000) { p = num(p, ms); sput(p, " ms"); }
        else { p = num(p, ms / 1000); p = sput(p, "."); p = num(p, ms % 1000 / 100); sput(p, " s"); }
        col = E1;
        if (np) { const int i = p_min(np, 13) - 1; x = path[i][0] + U(6); y = path[i][1] - U(12); }
        else { x = xf + U(6); y = yf - U(12); }
        break;
    }
    case 2: {
        const int tt = pk(kn8, 2) * 50 / 32767;
        p = sput(p, "sweep "); p = num(p, tt / 10); p = sput(p, "."); p = num(p, tt % 10); sput(p, " oct");
        col = E2; x = xt + U(6); y = (yt + yf) / 2 - U(6);
        break;
    }
    case 3:
        p = sput(p, "noise "); num(p, pk(kn8, 3) * 99 / 32767);
        col = E3; x = xf + U(47.1); y = yf - U(29.5);
        break;
    case 4: {
        const int c = pk(kn8, 4), hz = (int)((300u * him_exp2q((c * 71) >> 7)) >> 16);
        p = sput(p, "colour "); p = sput(p, c < 0x2000 ? "low " : c < 0x6000 ? "band " : "high ");
        if (hz < 1000) { p = num(p, hz); sput(p, " hz"); }
        else { p = num(p, hz / 1000); p = sput(p, "."); p = num(p, hz % 1000 / 100); sput(p, " khz"); }
        col = E0; x = bb[2] + U(5); y = bb[3] - U(4);
        break;
    }
    case 5: case 7: {
        if (k == 5) { p = sput(p, "shape "); sput(p, HIM_SHAPE_NAMES[p_min((pk(kn8, 5) + 0x1000) >> 13, 4)]); col = E1; }
        else { p = sput(p, "drive "); p = num(p, pk(kn8, 7) * 99 / 32767); if (kn8[7] >= 0x4CCE) sput(p, " crunch"); col = E3; }
        const int w = f3_text_width(2, len(t)), cx = (bb[0] + bb[2]) / 2;
        x = cx > U(160) ? bb[0] - U(6) - w : bb[2] + U(5);
        y = (bb[1] + bb[3]) / 2 - U(6);
        break;
    }
    default: return;
    }
    label(x, y, col, A, t);
}

static void preview(int key, const int16_t *k, int values)
{
    const int A = ov_t < 432 ? 256 : 256 + (ov_t - 432) * 256 / -96;
    if (A <= 0) return;
    him_body t, s;
    uint8_t *z = (uint8_t *)&t;
    for (unsigned i = 0; i < sizeof t; i++) z[i] = 0;
    him_throw(&t, k, him_key_x(key), 0, 0);
    s = t;
    int np = 0;
    for (int st = 0; st < 400; st++) {
        const int was = s.landed;
        him_body_step(0, &s);
        int rec = 0;
        if (!was && s.landed) { s.vx = s.x > 0 ? -0xE66 : 0xE66; rec = 1; }
        else if (was && !(st & 1)) rec = 1;
        if (rec && np < 200) { project(s.x, s.y - s.r, 0, &path[np][0], &path[np][1]); np++; }
    }
    int xt, yt, xf, yf;
    project(t.x0, t.h0 - t.r, 0, &xt, &yt);
    project(t.x0, 0, 0, &xf, &yf);
    if (np) { path[0][0] = xf; path[0][1] = yf; }
    const int kk = ov_knob;
    const int drop[2][2] = { { xf, yf }, { xt, yt } };
    f3_ink(F3_RGB(E2), (kk == 2 ? A : A / 2) | 0x10000);
    f3_seg(drop, 2, 0, kk == 2 ? 0 : 1, 0x280, 0x280);
    f3_ink(F3_RGB(E1), (kk == 1 ? A : A / 2) | 0x10000);
    if (np > 1) f3_seg((const int (*)[2])path, np, 0, kk == 1 ? 0 : 1, 0, 0);
    f3_ink(F3_RGB(E3), (kk == 3 ? A : A / 2) | 0x10000);
    for (int i = 0; i < ((pk(k, 3) * 15) >> 14) && i < 30; i++)
        f3_dot(xf + ((HIM_FAN[i][0] * PAGE_SCALE) >> 12), yf - ((HIM_FAN[i][1] * PAGE_SCALE) >> 12), 0x200);
    t.yaw = spin; t.roll = 0;
    int bb[4];
    draw_solid(&t, A, bb);
    outline(&t, bb, (kk == 0 || kk == 4) ? A : A / 2);
    if (values && kk != 6) value_label(kk, k, bb, xf, yf, xt, yt, np, A);
}

static void centre_label(int t, uint32_t colour, const char *text)
{
    const int a = t < 288 ? 256 : (432 - t) * 256 / 144;
    if (a > 0) label(U(160) - f3_text_width(2, len(text)) / 2, LABEL_YMAX, colour, a, text);
}

/* ---- the frame ---- */
static uint16_t *frame_px;
static int frame_rows;
static uint16_t *page_pixels(int *rows) { *rows = frame_rows; return frame_px; }
/* the box is the original's still part: drawn once onto the cleared frame and kept as runs of equal lit pixels (offset in the
 * frame | length << 17, colour), then written back each frame instead of drawn (the original host's still-part job).
 * Too many runs (another panel) leave it drawn every frame. */
#define BOX_RUNS 6400
static uint32_t box_run[BOX_RUNS];
static uint16_t box_col[BOX_RUNS];
static int box_n, box_rows;
static void keep_box(void)
{
    int n = 0;
    for (int r = 0; r < frame_rows; r++) {
        const uint16_t *row = frame_px + r * 256;
        for (int y = 0; y < 256;) {
            const uint16_t c = row[y];
            if (!c) { y++; continue; }
            int k = y;
            while (k < 256 && row[k] == c) k++;
            if (n == BOX_RUNS) { box_n = 0; return; }
            box_run[n] = (uint32_t)(r * 256 + y) | (uint32_t)(k - y) << 17; box_col[n] = c; n++;
            y = k;
        }
    }
    box_n = n; box_rows = frame_rows;
}

/* the frame skip (op1_screen_hash, op1_plugin.h): the page writes its pixels itself, so the core cannot see them change.
 * The hash covers what the picture is made of: the solids, rings, sparks, links, debris, the scope band, the preview
 * and the labels (their timers). Not the world's counters (steps, rng, cycles), which move without drawing. */
static uint32_t page_hash;
static void hmix(const void *p, unsigned bytes)
{
    const uint8_t *b = p;
    uint32_t h = page_hash;
    while (bytes--) h = (h ^ *b++) * 16777619u;
    page_hash = h;
}
static void hval(uint32_t v) { hmix(&v, 4); }
uint32_t him_page_hash(void) { return page_hash; }

/* him_page_panel: the rows to lay out for and whether the frame is shown (him_fw.c: op1_panel_rows, op1_raster_live) */
static int panel_rows, panel_live = 1;
void him_page_panel(int rows, int live) { panel_rows = rows; panel_live = live; }

void him_page_reset(void) { last_key = -1; ov_active = 0; choke_t = values_t = -1; last_values = -1; }

void him_page_draw(void *raster, int dt)
{
    if (dt <= 0 || dt > 250) dt = dt <= 0 ? 33 : 250;
    step_frac += dt * 240;
    const int n = step_frac / 1000;
    step_frac %= 1000;
    int16_t k[8];
    const int key = him_src_key(k);
    if (key >= 0 && key == last_key) {
        int hi = -1;
        for (int i = 0; i < 8; i++) if (k[i] != last_knobs[i]) hi = i;
        if (hi >= 0) {
            if (!ov_active) spin = 0;
            ov_active = 1; ov_knob = hi; ov_t = 0;
            if (k[6] != last_knobs[6]) choke_t = 0;
        }
    }
    for (int i = 0; i < 8; i++) last_knobs[i] = k[i];
    last_key = key;
    if (ov_active && (ov_t += n) >= 528) ov_active = 0;
    if (choke_t >= 0 && (choke_t += n) >= 432) choke_t = -1;
    const int values = him_src_values();
    if (last_values >= 0 && values != last_values) values_t = 0;
    last_values = values;
    if (values_t >= 0 && (values_t += n) >= 432) values_t = -1;
    if (key >= 0) spin += ((((pk(k, 7) * 0xCBC) >> 15) + 0xC4) * n) / 240;
    him_src_world(&W);

    /* R246's raster object: pixels, columns used, stride (bytes), rows; the renderer addresses a 256-word stride */
    const struct { uint16_t *px; uint32_t w, stride, h; } *r = raster;
    frame_px = r && r->px && r->stride == 512 && r->h >= 320 && r->h <= 400 ? r->px : 0;
    frame_rows = frame_px ? (panel_rows > 0 && panel_rows <= (int)r->h ? panel_rows : (int)r->h) : 0;
    f3_page_pixels = page_pixels;
    f3_begin(0, HIM_PITCH, PAGE_SCALE, HIM_CX, PAGE_CY, F3_RGB(E1), 0);
    if (frame_px && box_rows == frame_rows && box_n) {            /* the box from its still-part cache */
        for (int i = 0; i < box_n; i++) {
            uint16_t *p = frame_px + (box_run[i] & 0x1ffff);
            for (int k = (int)(box_run[i] >> 17); k > 0; k--) *p++ = box_col[i];
        }
    } else if (frame_px) for (int i = 0; i < HIM_BOX_N; i++) {    /* the box (the original's still part), line by line */
        const int a[3] = { HIM_BOX[i].a[0], HIM_BOX[i].a[1], HIM_BOX[i].a[2] }, b[3] = { HIM_BOX[i].b[0], HIM_BOX[i].b[1], HIM_BOX[i].b[2] };
        int pt[2][2];
        f3_project(a, &pt[0][0], &pt[0][1]);
        f3_project(b, &pt[1][0], &pt[1][1]);
        f3_ink(F3_RGB(E1), HIM_BOX[i].alpha | 0x10000);
        f3_seg((const int (*)[2])pt, 2, 0, HIM_BOX[i].style, 0, 0);
        if (i == HIM_BOX_N - 1 && panel_live) keep_box();          /* not from a record frame's uncleared scratch */
    }
    static int16_t lo[512], hi[512];
    him_src_scope(lo, hi);
    f3_ink(F3_RGB(E1), (0xE6) | 0x10000);
    f3_band(lo, hi, 512, U(8), U(12), U(304), U(7));

    for (int i = 0; i < HIM_BODIES; i++) {                        /* throw trails */
        const him_body *b = &W.body[i];
        if (!b->active || b->age >= 96) continue;
        int seg[2][2];
        project(b->x0, b->h0 - b->r, b->z, &seg[0][0], &seg[0][1]);
        if (b->landed) project(b->land_x, 0x52, b->z, &seg[1][0], &seg[1][1]);
        else project(b->x, b->y - b->r, b->z, &seg[1][0], &seg[1][1]);
        f3_ink(F3_RGB(E2), ((96 - b->age) * 230 / 96) | 0x10000);
        f3_seg(seg, 2, 0, 1, 640, 640);
    }
    for (int i = 0; i < W.n_rings; i++) {                         /* impact rings */
        const him_ring *g = &W.ring[i];
        const int R = g->r + ((him_isqrt((uint32_t)((g->age << 12) / 120) << 12) * g->rmax + 0x800) >> 12);   /* the original: sqrt(age / 120) */
        int cx, cy, rx, ry, t, clip[4];
        project(g->x, g->wy, g->z, &cx, &cy);
        project(g->x + R, g->wy, g->z, &rx, &t);
        project(g->x, g->wy, g->z + R, &t, &ry);
        project(-HIM_WALL, g->wy, -HIM_DEPTH, &clip[0], &clip[1]);
        project(HIM_WALL, g->wy, HIM_DEPTH, &clip[2], &clip[3]);
        f3_ink(F3_RGB(E1), ((120 - g->age) * 230 / 120) | 0x10000);
        f3_ellipse(cx, cy, rx - cx, ry > cy ? ry - cy : cy - ry, 0x180, clip);
    }
    int order[HIM_BODIES], no = 0;                                /* solids, far first */
    int vz[HIM_BODIES];
    for (int i = 0; i < HIM_BODIES; i++) {
        if (!W.body[i].active) continue;
        int v[3];
        const int p[3] = { W.body[i].x, W.body[i].y, W.body[i].z };
        f3_to_view(p, v);
        vz[i] = v[2];
        int j = no++;
        for (; j > 0 && vz[order[j - 1]] > v[2]; j--) order[j] = order[j - 1];
        order[j] = i;
    }
    for (int j = 0; j < no; j++) draw_solid(&W.body[order[j]], W.body[order[j]].alpha, bbox[order[j]]);
    for (int j = 0; j < no; j++) overlays(&W.body[order[j]], bbox[order[j]]);
    for (int i = 0; i < W.n_sparks; i++) {                        /* sparks */
        const him_spark *s = &W.spark[i];
        int X, Y;
        project(s->x, s->y, s->z, &X, &Y);
        f3_ink(F3_RGB(0xFFFFFF), ((72 - s->age) * 256 / 72) | 0x10000);
        f3_dot(X, Y, 0x300);
        const int seg[1][4] = { { X, Y, X + ((s->nx * 7 * 256) >> 12), Y - ((s->ny * 7 * 256) >> 12) } };
        f3_lines(seg, 1, 2);
    }
    for (int i = 0; i < W.n_links; i++) {                         /* choke links */
        const him_link *l = &W.link[i];
        int p[3][2];
        project(l->x0, l->h0, l->z0, &p[0][0], &p[0][1]);
        project(l->x, l->y, l->z, &p[2][0], &p[2][1]);
        p[1][0] = (p[0][0] + p[2][0]) / 2 + U(6); p[1][1] = (p[0][1] + p[2][1]) / 2 - U(6);
        f3_ink(F3_RGB(E2), ((72 - l->age) * 256 / 72) | 0x10000);
        f3_seg(p, 3, 0, 0, 0, 0);
    }
    for (int i = 0; i < W.n_debris; i++) {                        /* debris */
        const him_debris *d = &W.debris[i];
        int X, Y;
        project(d->x, d->y, d->z, &X, &Y);
        f3_ink(F3_RGB(E3), ((d->life - d->age) * 256 / d->life) | 0x10000);
        f3_dot(X, Y, 0x200);
    }
    if (ov_active && key >= 0) preview(key, k, values);
    page_hash = 2166136261u;
    hval((uint32_t)frame_rows); hval((uint32_t)values); hval((uint32_t)key);
    hval((uint32_t)ov_t); hval((uint32_t)choke_t); hval((uint32_t)values_t);
    if (ov_active && key >= 0) { hval((uint32_t)spin); hval((uint32_t)ov_knob); hmix(k, sizeof k); }
    else if (choke_t >= 0) hmix(k, sizeof k);
    hmix(W.body, sizeof W.body);
    hmix(W.ring, (unsigned)W.n_rings * sizeof W.ring[0]);
    hmix(W.spark, (unsigned)W.n_sparks * sizeof W.spark[0]);
    hmix(W.link, (unsigned)W.n_links * sizeof W.link[0]);
    hmix(W.debris, (unsigned)W.n_debris * sizeof W.debris[0]);
    hmix(lo, sizeof lo); hmix(hi, sizeof hi);
    char t[24];
    if (values_t >= 0) centre_label(values_t, E1, values ? "values on" : "values off");
    else if (choke_t >= 0 && key >= 0) {
        const int g = him_group(k);
        if (g) { num(sput(t, "choke group "), g); centre_label(choke_t, E2, t); }
        else centre_label(choke_t, E2, "choke off");
    }
    f3_end();
}
