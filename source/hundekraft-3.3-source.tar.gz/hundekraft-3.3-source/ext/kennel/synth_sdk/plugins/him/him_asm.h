/* HIM: which sample loops come from him_kern.S (all of them on the Blackfin, none on a host). HIM_KERN_C builds the C
 * ones everywhere (test/kern_check.py's reference); HIM_ASM_SOME with HIM_ASM_NOISE / _BODY / _DRIVE picks single ones
 * (development). Included by him_voice.c and him_kern.S.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#if defined(__bfin__) && !defined(HIM_KERN_C) && !defined(HIM_ASM_SOME)
#define HIM_ASM_NOISE 1
#define HIM_ASM_BODY 1
#define HIM_ASM_DRIVE 1
#endif
