/* HIM's solids: the original drum engine's solid builder (ported with the author's permission per the owner,
 * 2026-11-09), line for line with him-data/him-mesh-model.py; check.py compares all 65 shapes. Page thread only.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "him_mesh.h"
#include "him_world.h"

static int32_t smooth(int32_t t) { return (0x800 + (((t * t) >> 12) * (0x1800 - t)) * 2) >> 12; }

typedef struct { him_mesh *m; int8_t key[HIM_MESH_V][3]; } builder;

static int vid(builder *b, int px, int py, int pz, const int32_t *v)
{
    him_mesh *m = b->m;
    for (int i = 0; i < m->nv; i++) if (b->key[i][0] == px && b->key[i][1] == py && b->key[i][2] == pz) return i;
    const int i = m->nv++;
    b->key[i][0] = (int8_t)px; b->key[i][1] = (int8_t)py; b->key[i][2] = (int8_t)pz;
    m->v[i][0] = v[0]; m->v[i][1] = v[1]; m->v[i][2] = v[2];
    return i;
}

void him_mesh_build(him_mesh *m, int s)
{
    static const int DU[4] = { 0, 1, 1, 0 }, DV[4] = { 0, 0, 1, 1 }, CB[4] = { -1, 1, 1, -1 }, CC[4] = { -1, -1, 1, 1 };
    builder bd;
    bd.m = m;                                                   /* keys are written before they are read */
    m->s = s; m->nv = m->nf = m->ne = 0;
    if (s <= 32) {
        const int32_t b = smooth(s << 7);
        m->fv = 4;
        for (int a = 0; a < 3; a++) {
            const int a1 = (a + 1) % 3, a2 = (a + 2) % 3;
            for (int side = -3; side <= 3; side += 6)
                for (int i = 0; i < 3; i++)
                    for (int j = 0; j < 3; j++) {
                        uint8_t *f = m->f[m->nf++];
                        for (int k = 0; k < 4; k++) {
                            int p[3];
                            p[a] = side; p[a1] = (DU[k] + i) * 2 - 3; p[a2] = (DV[k] + j) * 2 - 3;
                            int32_t g[3], n[3], v[3];
                            for (int c = 0; c < 3; c++) g[c] = (p[c] * 4096) / 3;
                            const int32_t L = him_isqrt((uint32_t)(g[0] * g[0] + g[1] * g[1] + g[2] * g[2]));
                            for (int c = 0; c < 3; c++) {
                                n[c] = (g[c] * 4096) / L;
                                const int32_t cc = (g[c] * 0xccd + 0x800) >> 12;
                                v[c] = (((cc - n[c]) * b + 0x800) >> 12) + n[c];
                            }
                            f[k] = (uint8_t)vid(&bd, p[0], p[1], p[2], v);
                        }
                    }
        }
    } else {
        const int32_t b = smooth((s - 32) << 7);
        const int32_t k_in = ((-0x8cd * b + 0x800) >> 12) + 0xccd, k_out = ((-0xcd * b + 0x800) >> 12) + 0xccd;
        m->fv = 3;
        for (int a = 0; a < 3; a++) {
            const int a1 = (a + 1) % 3, a2 = (a + 2) % 3;
            for (int side = -1; side <= 1; side += 2) {
                int idx[4], flag[4];
                for (int k = 0; k < 4; k++) {
                    int p[3];
                    p[a] = side; p[a1] = CB[k]; p[a2] = CC[k];
                    flag[k] = p[0] * p[1] * p[2] > 0;
                    const int32_t kk = flag[k] ? k_out : k_in, v[3] = { p[0] * kk, p[1] * kk, p[2] * kk };
                    idx[k] = vid(&bd, p[0], p[1], p[2], v);
                }
                const int u = flag[0] ? 0 : 1;
                uint8_t *f = m->f[m->nf++];
                f[0] = (uint8_t)idx[u]; f[1] = (uint8_t)idx[(u + 1) & 3]; f[2] = (uint8_t)idx[(u + 2) & 3];
                f = m->f[m->nf++];
                f[0] = (uint8_t)idx[u]; f[1] = (uint8_t)idx[(u + 2) & 3]; f[2] = (uint8_t)idx[(u + 3) & 3];
            }
        }
    }
    const int fv = m->fv;
    for (int fi = 0; fi < m->nf; fi++) {
        uint8_t *f = m->f[fi];
        int32_t n[3] = { 0, 0, 0 }, cs[3] = { 0, 0, 0 };
        for (int i = 0; i < fv; i++) {
            const int32_t *p = m->v[f[i]], *q = m->v[f[(i + 1) % fv]];
            n[0] += (p[1] - q[1]) * (p[2] + q[2]); n[1] += (p[2] - q[2]) * (p[0] + q[0]); n[2] += (p[0] - q[0]) * (p[1] + q[1]);
            for (int c = 0; c < 3; c++) cs[c] += p[c];
        }
        for (int c = 0; c < 3; c++) n[c] >>= 12;
        if ((cs[0] >> 2) * n[0] + (cs[1] >> 2) * n[1] + (cs[2] >> 2) * n[2] < 0) {
            for (int i = 0; i < fv / 2; i++) { uint8_t t = f[i]; f[i] = f[fv - 1 - i]; f[fv - 1 - i] = t; }
            for (int c = 0; c < 3; c++) n[c] = -n[c];
        }
        const int32_t L = him_isqrt((uint32_t)(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]));
        for (int c = 0; c < 3; c++) m->n[fi][c] = (int16_t)(L ? (n[c] * 4096) / L : 0);
    }
    for (int fi = 0; fi < m->nf; fi++) {
        const uint8_t *f = m->f[fi];
        for (int i = 0; i < fv; i++) {
            const int a = f[i], bb = f[(i + 1) % fv];
            int hit = -1;
            for (int e = 0; e < m->ne && hit < 0; e++)
                if ((m->e[e][0] == a && m->e[e][1] == bb) || (m->e[e][0] == bb && m->e[e][1] == a)) hit = e;
            if (hit >= 0) {
                m->e[hit][3] = (uint8_t)fi;
                const int16_t *n1 = m->n[m->e[hit][2]], *n2 = m->n[fi];
                const int32_t dot = (n1[0] * n2[0] + n1[1] * n2[1] + n1[2] * n2[2]) >> 12, w = (0xffb - dot) * 0x100;
                m->w[hit] = (int16_t)(w < -0xf2 ? 0 : w < 0xf3f3 ? w / 0xf3 : 0x100);
            } else if (m->ne < HIM_MESH_E) {
                uint8_t *e = m->e[m->ne];
                e[0] = (uint8_t)a; e[1] = (uint8_t)bb; e[2] = e[3] = (uint8_t)fi;
                m->w[m->ne++] = 0x100;
            }
        }
    }
}

static him_mesh cache[6];
static int next, ready;
const him_mesh *him_mesh_get(int s)
{
    if (!ready) { for (int i = 0; i < 6; i++) cache[i].s = -1; ready = 1; }
    for (int i = 0; i < 6; i++) if (cache[i].s == s) return &cache[i];
    him_mesh *m = &cache[next];
    next = (next + 1) % 6;
    him_mesh_build(m, s);
    return m;
}
