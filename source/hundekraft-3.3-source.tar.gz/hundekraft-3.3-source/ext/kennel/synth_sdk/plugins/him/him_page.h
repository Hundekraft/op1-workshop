/* HIM's T1 page (him_page.c) and what it reads (him_fw.c on the OP-1, test/screen_test.c on the host).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HIM_PAGE_H
#define HIM_PAGE_H
#include <stdint.h>
#include "him_world.h"

uint32_t him_page_hash(void);                  /* after him_page_draw: what the frame was made of (for op1_screen_hash) */
void him_page_draw(void *raster, int dt);     /* after the box (him.svg) is drawn */
void him_page_panel(int rows, int live);      /* before it (him_fw.c): op1_panel_rows, op1_raster_live; rows 0: the raster's */
void him_page_reset(void);

int him_src_key(int16_t knobs[8]);            /* the current drum key 0..23 and its eight numbers; -1: none */
void him_src_world(him_world *out);           /* a copy of the box */
void him_src_scope(int16_t lo[512], int16_t hi[512]);   /* the drum output's last 512 blocks, oldest first */
int him_src_values(void);                     /* show values: 0 / 1 */

#endif
