/* HIM on kennel: a native drum-synth provider (op1_feature_drum_synth.h, the DBox family: R246 type 9, the kit is
 * R246's own 24 x 8 dbox_data words). The R246 glue follows Gin's (plugins/gin/vendor/src/tonic/sdk_drum/gin_fw.c,
 * gin_controls.c by SquareWave Studio, GPL-3.0-or-later; the same verified addresses, no new ones): type
 * activation per slot, the stock factory then the twelve receivers' check, route, the screen object on 0x11.
 * The voices are the original engine's (him_voice.c); the box runs here on the main loop (him_world.c) and the page only draws.
 * Threads: trigger / render / status on the audio side (kennel's guarded 4 KiB stacks), service on the main loop,
 * the page on the GUI thread, key presses on the KeyHandler thread.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../op1_feature_drum_synth.h"
#include "../../op1_synth.h"
#include "him_voice.h"
#include "him_world.h"
#include "him_page.h"
#include "him_data.h"
#include "him_presets.h"
#include "him_boot.h"
#include "him_knob.h"

#define CORE_SLOT       (*(volatile uint32_t *)0x01aaac10)          /* the slot whose voices exist */
#define SELECTED_SLOT   (*(volatile uint32_t *)0xff8016d8)          /* the drum slot shown */
#define SHIFT_HELD      (*(volatile uint8_t *)0x01dd7f78)           /* R246's shift flag (adds 4 to the knob) */
#define LAST_PAD        (*(volatile uint32_t *)0xff801044)
#define DRUM_MODE       (*(volatile uint32_t *)0x01de4c40)
#define CURRENT_SCREEN  (*(volatile uint32_t *)0x018b65c8)
#define TABLE           ((void *volatile *)0x01df4e54)
#define SCREEN_ID       0x11u
#define PUBLICATION     ((void **)0x01aaad30)
#define GAIN            ((const int16_t *)0xff801d50)               /* synth_env_buf: velocity << 8, per voice */
#define VOICE_PITCH     ((const volatile int32_t *)0xff801304)       /* drum voice base pitch: 2^26 = drum octave 0 and no
                                                                       transposition (measured in op1emu, 2026-11-09) */
#define BASE(slot)      ((const int16_t *)(0x01aaadb4u + (slot) * 384u))
#define STOCK_FACTORY(t, p, s) (((uint32_t (*)(uint32_t, void **, uint32_t))0x01a1b9c0)((t), (p), (s)))
#define JSON_GET(j, k)  (((const void *(*)(const void *, const char *))0x019BEB70)((j), (k)))
#define DB_FACTORY()    (((void *(*)(void))0x0196DD38)())
#define BLOCK_CYCLES    580525u                                     /* one 64-sample block at 400 MHz (the original's) */
#define DEFAULT_ROW     "[0,16000,0,0,0,0,0,0]"                     /* the original's engine default knobs */

typedef struct { uint32_t alloc; union { char buf[16]; const char *ptr; } u; uint32_t size, cap; } name_string;

static uint8_t selected[8], bound, registered;
static void *receiver[12];
static him_voice voice[12];
static uint8_t vkey[12], vfirst[12];

/* ---- shared with the page and the main loop ---- */
static him_hit_ring hits;
static him_world world;
static volatile uint32_t world_seq;
static volatile int show_values;
static volatile uint8_t pending_setting;                            /* show values changed: saved by the service */
typedef struct { int16_t lo, hi; uint32_t block; } scope_entry;
static scope_entry scope[512];
static int32_t acc[32];
static uint32_t scope_mark, scope_block;

static int is_him(const name_string *s)
{
    if (!s || s->size != 3) return 0;
    const char *p = s->cap > 15 ? s->u.ptr : s->u.buf;
    return p && p[0] == 'h' && p[1] == 'i' && p[2] == 'm';
}
static int receiver_ok(uint32_t i, const void *p)
{
    return (uintptr_t)p == 0xffb00000u + 72u * i && *(volatile const uint32_t *)p == 0x0190f8a4u &&
           *(volatile const uint32_t *)((const unsigned char *)p + 20) == i && PUBLICATION[i] == p;
}
static int voice_of(const void *p) { for (int i = 0; i < 12; i++) if (receiver[i] == p) return i; return -1; }
static int ready(void) { const uint32_t s = CORE_SLOT; return bound && s < 8 && selected[s]; }

/* ---- the provider ---- */
static uint32_t type(const void *s, uint32_t caller, const void *patch)
{
    const int him = is_him(s);
    if (caller == 0x01a006f4u && patch) {                           /* a slot's type is being set (Gin's rule) */
        const uint32_t slot = *(const uint32_t *)patch;
        if (slot < 8) selected[slot] = (uint8_t)him;
    }
    return him ? 9u : op1_drum_synth_stock_type(s);
}

static void silence(void) { for (int i = 0; i < 12; i++) him_voice_init(&voice[i], i); }

static uint32_t factory(uint32_t t)
{
    const uint32_t slot = CORE_SLOT, r = STOCK_FACTORY(t, PUBLICATION, slot);
    bound = 0;
    silence();
    if (t != 9u || slot >= 8 || !selected[slot]) return r;
    for (uint32_t i = 0; i < 12; i++) { if (!receiver_ok(i, PUBLICATION[i])) return r; receiver[i] = PUBLICATION[i]; }
    /* a new HIM kit (every key at the drum_types default row) starts as the original's default kit */
    int16_t *base = (int16_t *)(uintptr_t)BASE(slot);
    static const int16_t row[8] = { 0, 16000, 0, 0, 0, 0, 0, 0 };
    /* R246 hands a new type-9 kit over with every word 0 (seen in op1emu, 2026-11-09), not the drum_types row */
    int fresh = 1, zero = 1;
    for (int k = 0; k < 24 && (fresh || zero); k++)
        for (int j = 0; j < 8; j++) { if (base[k * 8 + j] != row[j]) fresh = 0; if (base[k * 8 + j]) zero = 0; }
    fresh |= zero;
    if (fresh) for (int k = 0; k < 24; k++) for (int j = 0; j < 8; j++) base[k * 8 + j] = HIM_KIT[0][k][j];
    bound = 1;
    return r;
}

static uint32_t route(const void *p) { return ready() && voice_of(p) >= 0; }

static uint32_t trigger(void *p, const int16_t *canonical)
{
    const int v = voice_of(p);
    const uint32_t slot = CORE_SLOT;
    if (v < 0 || !ready() || !canonical) return 1;
    const uintptr_t d = (uintptr_t)canonical - (uintptr_t)BASE(slot);
    if ((uintptr_t)canonical < (uintptr_t)BASE(slot) || d >= 384u || (d & 15u)) return 1;
    const int key = (int)(d >> 4);
    const uint32_t now = op1_cycles();
    him_voice_note(&voice[v], 127);
    vfirst[v] = 1;                                                     /* velocity from R246's gain at the first block */
    vkey[v] = (uint8_t)key;
    const int g = him_group(canonical);
    if (g)
        for (int u = 0; u < 12; u++)
            if (u != v && !voice[u].choke && !him_voice_finished(&voice[u]) && vkey[u] != key &&
                him_group(BASE(slot) + vkey[u] * 8) == g)
                him_voice_choke(&voice[u]);
    him_hit_push(&hits, canonical, key, now);
    return 0;
}

static uint32_t render(void *p, int16_t *out, const int16_t *working)
{
    const int v = voice_of(p);
    if (v < 0 || !ready() || !working) { for (int i = 0; i < 128; i++) out[i] = 0; return 1; }
    him_voice *vc = &voice[v];
    if (vfirst[v]) {
        vfirst[v] = 0;
        int vel = GAIN[0] >> 8;
        vel = vel < 1 ? 127 : vel > 127 ? 127 : vel;                     /* no gain word: play full, not silent */
        if (vel != 127) vc->env = vc->nenv = (uint32_t)vel * 0x10200u;
    }
    /* the drum octave and the sequencer's transposition: R246's base pitch of this voice, 2^26 = ratio 1 */
    const uint32_t base = (uint32_t)VOICE_PITCH[v], ratio = base ? base >> 10 : 0x10000;
    him_voice_render(vc, out, working, ratio);
    /* the scope tap (the original 3.4): every fourth sample summed over the block's voices, min / max per block */
    const uint32_t now = op1_cycles(), el = now - scope_mark;
    if (el > BLOCK_CYCLES / 2) {
        uint32_t adv = (el + BLOCK_CYCLES / 2) / BLOCK_CYCLES;
        scope_block += adv ? adv : 1;
        scope_mark = now;
        for (int i = 0; i < 32; i++) acc[i] = 0;
    }
    int32_t lo = 32767, hi = -32768;
    for (int i = 0; i < 32; i++) {
        acc[i] += out[i * 4];
        if (acc[i] < lo) lo = acc[i];
        if (acc[i] > hi) hi = acc[i];
    }
    scope_entry *e = &scope[scope_block & 511];
    e->lo = (int16_t)(lo < -32768 ? -32768 : lo); e->hi = (int16_t)(hi > 32767 ? 32767 : hi); e->block = scope_block;
    return 0;
}

/* busy while the voice sounds */
static uint32_t status(const void *p)
{
    const int v = voice_of(p);
    if (v < 0 || !ready()) return 0;
    return !him_voice_finished(&voice[v]);
}
static uint32_t release(void *p, const int16_t *w) { (void)p; (void)w; return 0; }   /* drums: no note off */

/* ---- the box, on the main loop ---- */
static uint32_t last_service, last_settings;
static void service(void)
{
    const uint32_t now = op1_cycles();
    if (!last_settings) {                                              /* once: then HIM is the setting's only writer */
        last_settings = 1;
        show_values = op1_setting_get("him", "values", 0) == 1;      /* a "him.ghost" left by an older build is never read */
    }
    if (pending_setting) {
        pending_setting = 0;
        op1_setting_set("him", "values", show_values);
    }
    const uint32_t dt = now - last_service;
    last_service = now;
    world_seq++;
    const int n = him_hit_drain(&hits, &world, now, 80000000u);
    if (n || him_world_busy(&world)) him_world_advance(&world, dt);
    else world.acc = 0;
    world_seq++;
}

/* ---- what the page reads ---- */
int him_src_key(int16_t k[8])
{
    const uint32_t slot = SELECTED_SLOT, key = LAST_PAD;
    if (slot >= 8 || key >= 24) { for (int i = 0; i < 8; i++) k[i] = 0; return -1; }
    const int16_t *w = BASE(slot) + key * 8;
    for (int i = 0; i < 8; i++) k[i] = w[i];
    return (int)key;
}
void him_src_world(him_world *out)
{
    for (int tries = 0; tries < 3; tries++) {
        const uint32_t s = world_seq;
        *out = world;
        if (!(s & 1) && s == world_seq) return;
    }
}
void him_src_scope(int16_t lo[512], int16_t hi[512])
{
    const uint32_t cur = scope_block + (op1_cycles() - scope_mark + BLOCK_CYCLES / 2) / BLOCK_CYCLES;
    for (int i = 0; i < 512; i++) {
        const uint32_t b = cur - 511u + (uint32_t)i;
        const scope_entry *e = &scope[b & 511];
        const int ok = e->block == b && b <= scope_block;
        const int32_t l = ok ? e->lo * 8 / 5 : 0, h = ok ? e->hi * 8 / 5 : 0;
        lo[i] = (int16_t)(l < -32768 ? -32768 : l); hi[i] = (int16_t)(h > 32767 ? 32767 : h);
    }
}
int him_src_values(void) { return show_values; }

/* ---- the screen (Gin's construction on screen 0x11) ---- */
static uint32_t screen[32], vtable[10];
static void *original_screen;
static uint8_t screen_ready;
static void scr_init(void *scr) { (void)scr; him_page_reset(); }
static void scr_update(void *scr, int dt)
{
    op1_screen_draw(scr, dt);                                      /* him.svg is empty: the page draws the box itself */
    void *ras = op1_raster();
    him_page_panel(op1_panel_rows(ras), op1_raster_live(ras));    /* not the raster's rows: 400 on the SSD1963 panel too */
    him_page_draw(ras, dt);
    op1_screen_hash(scr, him_page_hash());                         /* the page writes its pixels: feed the frame skip */
}
const op1_screen_t SCREEN_him = { scr_init, scr_update };           /* plugin.json "screen" (the SVG's owner) */
static void screen_ctor(void)
{
    const char *asset = op1_drum_synth_svg("him");
    original_screen = TABLE[SCREEN_ID];
    if (!asset) return;
    ((void *(*)(void *, int, const char *))0x01a3bab0)(screen, SCREEN_ID, asset);
    TABLE[SCREEN_ID] = original_screen;
    for (unsigned i = 0; i < 10; i++) vtable[i] = ((const uint32_t *)0x019103fc)[i];
    vtable[7] = (uint32_t)(uintptr_t)scr_update; vtable[9] = (uint32_t)(uintptr_t)scr_init;
    screen[3] = (uint32_t)(uintptr_t)vtable;
}
static void screen_load(void *table)
{
    (void)table;
    original_screen = TABLE[SCREEN_ID];
    if (!screen[3]) return;
    if (screen[2]) screen[0] = (uint32_t)(uintptr_t)((void *(*)(void *))0x01a503d8)((void *)(uintptr_t)screen[2]);
    if (screen[0]) { scr_init(screen); screen_ready = 1; }
}
static uint32_t screen_select(void)
{
    const uint32_t slot = SELECTED_SLOT;
    if (original_screen) TABLE[SCREEN_ID] = screen_ready && slot < 8 && selected[slot] ? (void *)screen : original_screen;
    return SCREEN_ID;
}
static int page_shown(void)
{
    const uint32_t slot = SELECTED_SLOT;
    return screen_ready && slot < 8 && selected[slot] && DRUM_MODE == 1 && CURRENT_SCREEN == SCREEN_ID && TABLE[SCREEN_ID] == screen;
}
/* on the page: green push = show values on / off. The blue push is not HIM's (R246's drum T1 and kennel don't use it
 * there either), so it reaches R246 as before. */
static uint8_t push_owned;
static int key(int code, int down)
{
    if (code != 60) return 0;
    if (push_owned) { if (!down) push_owned = 0; return 1; }
    if (!down || !page_shown()) return 0;
    push_owned = 1;
    show_values = !show_values;
    pending_setting = 1;
    return 1;
}

/* the T1 turn on a HIM kit (him_knob.h): R246's own handler gets a larger delta, so one detent moves a number as far as a
 * stock synth knob does; choke steps one group a detent. */
static void knob_delta(int k, int16_t *delta)
{
    if (k < 0 || k > 3 || !page_shown()) return;
    const int idx = k + (SHIFT_HELD ? 4 : 0);
    if (idx != 6) { *delta = him_knob_scale(idx, *delta); return; }
    static int32_t choke_acc;
    int16_t w[8];
    if (him_src_key(w) < 0) return;
    *delta = him_choke_turn(&choke_acc, w[6], *delta);
}

static const op1_drum_synth_t provider = {
    .api = OP1_DRUM_SYNTH_API, .size = sizeof(op1_drum_synth_t), .name = "him", .state_key = "him_state",
    .type = type, .factory = factory, .route = route, .trigger = trigger, .render = render, .status = status,
    .release = release, .screen_ctor = screen_ctor, .screen_load = screen_load, .screen_select = screen_select,
    .key = key, .knob_delta = knob_delta, .service = service, .reset = silence,
};

static void db(void)
{
    void *f = DB_FACTORY();
    if (!f) return;
    if (!op1_db_has(f, "SELECT id FROM drum_types WHERE type='him'"))
        op1_db_write(f, "INSERT INTO drum_types(id,type,default_params) SELECT (SELECT COALESCE(MAX(id),-1)+1 FROM drum_types),"
                        "'him','" DEFAULT_ROW "' WHERE NOT EXISTS(SELECT 1 FROM drum_types WHERE type='him');");
    /* a fourth row exists: R246's SQLite refuses HAVING without GROUP BY (db2.cpp:129 asserts at boot) */
    if (!op1_db_has(f, "SELECT id FROM drum_presets WHERE folder='him' LIMIT 1 OFFSET 3"))
        for (unsigned i = 0; him_preset_sql[i]; i++) op1_db_write(f, him_preset_sql[i]);
}

static void event(int id, int32_t arg)
{
    (void)arg;
    if (id == OP1_EV_NOTES_RESET) silence();
    if (id == OP1_EV_REGISTER) {
        silence();
        him_world_init(&world);
        if (op1_drum_synth_register(&provider)) { op1_toast("HIM unavailable"); return; }
        registered = 1;
        db();
        for (unsigned slot = 0; slot < 8; slot++) {                   /* slots loaded before this file registered */
            const void *v = JSON_GET((const void *)(0x01DDD9ACu + slot * 0x38), "type");
            if (v && ((const unsigned char *)v)[8] == 4) {
                const char *s = *(const char *const *)v;
                selected[slot] = s && s[0] == 'h' && s[1] == 'i' && s[2] == 'm' && !s[3];
            }
        }
    }
    if (id == OP1_EV_BOOT_DONE && registered)                          /* bind the receivers built before us (drum mode only) */
        if (him_boot_rebind(CORE_SLOT, selected, *(volatile int32_t *)0xFF801038)) factory(9);
}

static const char *const claims[] = { "drum:him", 0 };
const op1_feature_t FEATURE_him = { .api = OP1_FEATURE_API, .priority = 50, .name = "him", .event = event,
                                    .claims = claims, .drum_synth = &provider };
