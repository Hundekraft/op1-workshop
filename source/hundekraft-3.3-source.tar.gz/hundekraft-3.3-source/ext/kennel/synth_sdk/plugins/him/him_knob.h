/* HIM's T1 turn. R246's D-Box controller steps a number by its range row's step a tick (1024 delta = one tick, two
 * ticks a detent; measured in op1emu 2026-11-11): 327.7 words for decay, sweep, noise, shape and choke (100 ticks end
 * to end), 194 for pitch (253), 153.6 for colour (213) and 256 for drive (128), where a stock synth knob takes 32. HIM
 * hands R246's handler a larger delta instead (the handler does the writing, the range clamp and the save marks):
 *   him_knob_scale  the numbers with a continuous meaning: delta x a factor (Q8) chosen for the ticks end to end in
 *                   HIM_TICKS (pitch 64, colour 32, decay, sweep, noise and drive 32, shape 16);
 *   him_choke_turn  choke: one group a detent (off, 1..4), as the delta that lands R246's own write on the new
 *                   group's word (0, 8192, 16384, 24576, 32767), so every word of a saved kit keeps its group.
 * Rows (op1emu, R246): step per knob 6208, 10485 x3, 4915, 10485 x2, 8192; a word moves delta x step / 32768.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HIM_KNOB_H
#define HIM_KNOB_H
#include <stdint.h>

#define HIM_STEP_DETENT 2048              /* two ticks of 1024 */
#define HIM_ROW_STEP_CHOKE 10485          /* R246's range row step of knob 6 */

/* knob 0..7 (Shift adds 4): factor x 256 on R246's delta; 256 = unchanged (choke is not scaled here) */
static const uint16_t him_knob_q8[8] = { 1013, 800, 800, 800, 1707, 1600, 256, 1024 };

static inline int16_t him_knob_scale(int knob, int delta)
{
    if ((unsigned)knob >= 8) return (int16_t)delta;
    const int32_t v = (int32_t)delta * him_knob_q8[knob] / 256;
    return (int16_t)(v > 32767 ? 32767 : v < -32767 ? -32767 : v);
}

static const int16_t him_choke_word[5] = { 0, 8192, 16384, 24576, 32767 };
static inline int him_choke_group(int word) { return ((word > 0 ? word : 0) + 0x1000) >> 13; }

/* acc: this knob's turn accumulator (starts over when the direction changes). -> the delta for R246: 0 between
 * detents and at the ends. One group per call at most: a larger move would leave R246's delta range (+-32767 = +-10485
 * words), and a one-group move from any word of a group lands inside the next group's band even when clamped. */
static inline int16_t him_choke_turn(int32_t *acc, int word, int delta)
{
    if ((*acc > 0 && delta < 0) || (*acc < 0 && delta > 0)) *acc = 0;
    *acc += delta;
    if (*acc > -HIM_STEP_DETENT && *acc < HIM_STEP_DETENT) return 0;
    const int st = *acc > 0 ? 1 : -1;
    *acc -= st * HIM_STEP_DETENT;
    const int g = him_choke_group(word), g2 = g + st < 0 ? 0 : g + st > 4 ? 4 : g + st;
    if (g2 == g) return 0;
    int32_t t = him_choke_word[g2] - word;            /* words to move; R246's delta reaches +-10485 of them */
    if (t > HIM_ROW_STEP_CHOKE) t = HIM_ROW_STEP_CHOKE;
    if (t < -HIM_ROW_STEP_CHOKE) t = -HIM_ROW_STEP_CHOKE;
    int32_t d = t * 32768 / HIM_ROW_STEP_CHOKE;
    if (d > 32767) d = 32767;
    if (d < -32767) d = -32767;
    return (int16_t)d;
}
#endif
