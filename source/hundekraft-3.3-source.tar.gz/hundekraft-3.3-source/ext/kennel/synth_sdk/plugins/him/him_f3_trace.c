/* facet3d: the original 3D renderer 0.2.6's two additions, ported from its machine code (OP1-Emulator
 * docs/ports/khorus-spec.md, "The 3D library"), with the author's permission per the owner: f3_seg_width (0x23d0) and
 * f3_traces (0x24a0). KHORUS's page uses them; HIM does not build this file. Proven pixel-identical with the original
 * 0.2.6 image through KHORUS's page (plugins/khorus/test/orc.py --guest test/page_guest.c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "him_f3_int.h"

/* a 2D polyline at any width (Q8 panel px, at least 256), dashes on / off as f3_seg's, never a dark gap (0x23d0) */
void f3_seg_width(const int (*xy)[2], int n, int closed, int width, int on, int off)
{
    if (n < 2) return;
    f3s.nseg = 0; f3s.phase = 0;
    int k = 0;
    for (int i = 0; i < n - (closed == 0); i++) {
        const int j = i + 1 < n ? i + 1 : 0;
        if (k < 320) { f3s.seg[k][0] = xy[i][0]; f3s.seg[k][1] = xy[i][1]; f3s.seg[k][2] = xy[j][0]; f3s.seg[k][3] = xy[j][1]; k++; }
    }
    f3s.nseg = k;
    f3s.open = closed == 0;
    f3i_flush(width < 0x100 ? 0x100 : width, 0, on, off);
}

/* f3_traces' own tables (the renderer's zero fill): half-widths by slope, sqrt((i^2 + 64) x 1024), made at the first
 * call; a column's red, green and blue (max of every trace's coverage), cleared as the column is written */
static uint16_t tr_sqrt[128];
static uint8_t col_r[256], col_g[256], col_b[256];

static inline int tr_y(const int *t, int pos, int n1q, int S)
{
    int i0 = 0, i1 = 1, f = 0;
    if (pos >= 0) {
        if (pos < n1q) { i0 = pos >> 16; i1 = i0 + 1; f = pos >> 8 & 0xff; }
        else { i0 = (n1q - 1) >> 16; i1 = i0 + 1; f = 0xff; }
    }
    const int a = t[i0];
    return (((t[i1] - a) * f >> 8) + a >> 4) * S >> 12;
}

/* count traces (16 at most) of n points each, spread over x0 .. x1 (Q8 page units), drawn a column at a time from x0
 * to x1: each trace a run between its last column's y and this one's, widened by its half-width x the slope's sqrt
 * profile; every channel the brightest coverage of any trace; the column's covered pixels written as RGB565 (0x24a0) */
void f3_traces(const int *const *tr, int n, int x0, int x1, const unsigned *colour, const int *width, int count)
{
    if (!f3s.frame || n < 2 || count < 1 || x1 <= x0) return;
    const int m = count < 16 ? count : 16, mm = m < 1 ? 1 : m;
    if (!tr_sqrt[0])
        for (int i = 0; i < 128; i++) tr_sqrt[i] = (uint16_t)f3i_isqrt((unsigned)((i * i + 0x40) * 0x400));
    int r[16], g[16], b[16], hw[16], prev[16];
    for (int j = 0; j < mm; j++) {
        const int c = (int)colour[j], w = width[j] < 0x100 ? 0x100 : width[j];
        r[j] = c >> 16 & 0xff; g[j] = c >> 8 & 0xff; b[j] = c & 0xff;
        hw[j] = w >> 1;
    }
    const int S = f3s.S, rows = f3s.rows, ylo8 = f3s.ylo << 8, yhi8 = (f3s.yhi + 1) << 8;
    int cend = (x1 >> 4) * S >> 20;
    int cstart = (x0 >> 4) * S >> 20;
    if (cstart < 0) cstart = 0;
    if (rows <= cend) cend = rows - 1;
    const int n1 = n - 1, n1q = n1 << 16;
    const int step = (int)(((int64_t)n1 * 0x14000 << 16) / ((int64_t)rows * (x1 - x0)));
    const int64_t xpos = (int64_t)cstart * 0x14000 / rows;
    int pos = (int)(((xpos - x0) * n1 << 16) / (x1 - x0));
    for (int j = 0; j < mm; j++) prev[j] = tr_y(tr[j], pos, n1q, S);
    if (cend < cstart) return;
    int base = (rows - 1 - cstart) << 8;
    for (int cols = cend - cstart + 1; cols; cols--) {
        pos += step;
        int lo_[16], hi_[16], spans = 0;
        for (int j = 0; j < mm; j++) {
            const int old = prev[j], y = tr_y(tr[j], pos, n1q, S);
            prev[j] = y;
            int d = (y < old ? old - y : y - old) >> 5;
            if (d > 127) d = 127;
            const int half = tr_sqrt[d] * hw[j] >> 8;
            int lo = (y < old ? y : old) - half, hi = (y > old ? y : old) + half;
            if (lo < ylo8) lo = ylo8;
            if (hi > yhi8) hi = yhi8;
            if (lo >= hi) continue;
            const int a = lo >> 8, e = (hi - 1) >> 8;
            int cov, k;
            if (a == e) {
                cov = hi - lo;
                k = a;
            } else {
                cov = ((a + 1) << 8) - lo;
                const int pr = r[j] * cov >> 8, pg = g[j] * cov >> 8, pb = b[j] * cov >> 8;
                if (col_r[a] < pr) col_r[a] = (uint8_t)pr;
                if (col_g[a] < pg) col_g[a] = (uint8_t)pg;
                if (col_b[a] < pb) col_b[a] = (uint8_t)pb;
                for (int q = a + 1; q < e; q++) {
                    if (col_r[q] < r[j]) col_r[q] = (uint8_t)r[j];
                    if (col_g[q] < g[j]) col_g[q] = (uint8_t)g[j];
                    if (col_b[q] < b[j]) col_b[q] = (uint8_t)b[j];
                }
                cov = hi - (e << 8);
                k = e;
            }
            const int pr = r[j] * cov >> 8, pg = g[j] * cov >> 8, pb = b[j] * cov >> 8;
            if (col_r[k] < pr) col_r[k] = (uint8_t)pr;
            if (col_g[k] < pg) col_g[k] = (uint8_t)pg;
            if (col_b[k] < pb) col_b[k] = (uint8_t)pb;
            lo_[spans] = a; hi_[spans] = e; spans++;
        }
        for (int s = 0; s < spans; s++)
            for (int q = lo_[s]; q <= hi_[s]; q++)
                if (col_r[q] | col_g[q] | col_b[q]) {
                    f3s.frame[base + q] = (uint16_t)((col_r[q] >> 3) << 11 | (col_g[q] >> 2) << 5 | col_b[q] >> 3);
                    col_r[q] = col_g[q] = col_b[q] = 0;
                }
        base -= 0x100;
    }
}
