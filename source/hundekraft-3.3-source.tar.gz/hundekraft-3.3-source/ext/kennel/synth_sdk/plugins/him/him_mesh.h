/* HIM's solids: the original drum engine's solid builder (ported with the author's permission per the owner,
 * 2026-11-09; OP1-Emulator docs/ports/him-spec.md 8.4, model him-data/him-mesh-model.py, exact). Shape index
 * s = (max(shape, 0) + 0x100) >> 9, 0..64: sphere -> rounded cube -> cube (32) -> folded star -> tetrahedron (64).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HIM_MESH_H
#define HIM_MESH_H
#include <stdint.h>

#define HIM_MESH_V 56
#define HIM_MESH_F 54
#define HIM_MESH_E 108
typedef struct {
    int32_t s;                       /* shape index, -1 = empty slot */
    int32_t nv, nf, ne, fv;          /* counts; fv = vertices per face (4 or 3) */
    int32_t v[HIM_MESH_V][3];        /* unit-size vertices, Q12 */
    uint8_t f[HIM_MESH_F][4];
    int16_t n[HIM_MESH_F][3];        /* Q12 face normals */
    uint8_t e[HIM_MESH_E][4];        /* a, b, face 1, face 2 */
    int16_t w[HIM_MESH_E];           /* crease weight 0..256 */
} him_mesh;

static inline int him_shape_index(int16_t shape) { return ((shape > 0 ? shape : 0) + 0x100) >> 9; }
void him_mesh_build(him_mesh *m, int s);
/* the cache: 6 slots, round robin (the original's), built on demand */
const him_mesh *him_mesh_get(int s);

#endif
