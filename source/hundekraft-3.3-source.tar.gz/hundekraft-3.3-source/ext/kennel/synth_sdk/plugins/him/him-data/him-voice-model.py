# Python model of the the original drum engine 0.1.9 drum voice (image 0x0000..0x11ea), written from the disassembly for the
# kennel port (used with the author's permission, per the owner 2026-11-09). Integer maths as in the binary;
# render() returns the 128 samples (88.2 kHz) the engine writes for one block.
import struct, math
M32=0xffffffff
def s32(x): x&=M32; return x-(1<<32) if x>>31 else x
def s16(x): x&=0xffff; return x-0x10000 if x>>15 else x
def clamp(x,a,b): return a if x<a else b if x>b else x
EXP=[round(32768*2**(i/16)) for i in range(17)]   # image 0x4ed0
AMP=(962,1002,1019,1013,962,853,730,604,493,420,337,274,231,201,181,165,149)  # image 0x4eac
def exp2q(x):            # image 0x0000: 65536*2^(x/4096), unsigned
    x=s32(x); o=x>>12; i=(x>>8)&15; f=x&0xff
    v=(((EXP[i+1]-EXP[i])*f>>8)+EXP[i])*2
    if x>=0: return 0xffffffff if o>=15 else (v<<o)&M32
    return 0 if o<-17 else v>>(-o)
def sdiv(a,b): q=abs(a)//abs(b); return q if (a<0)==(b<0) else -q
def log2q(r):              # render 0x1044..0x10c4 / 0x11cc: log2(r/65536) in Q12 by 12 squarings
    if r==0x10000: return 0
    u=r; e=-1
    if r<0x10000:
        while u<0x8000: u<<=1; e-=1
    else:
        while True:
            u>>=1; e+=1
            if u<=0xffff: break
    f=0; bit=0x800
    for _ in range(12):
        sq=u*u
        if (sq>>15)>0xffff: u=sq>>16; f|=bit
        else: u=sq>>15
        bit>>=1
    return e*0x1000+f
class Voice:
    def __init__(s,index):           # init 0x11ec + 0x54
        s.ph=[0]*7; s.seed=((index+1)*0x9E3779B9)&M32 or 0x2545f491
        s.lp=s.bp=0; s.env=s.nenv=0; s.swp=0; s.hold_n=0; s.hold_v=0; s.choke=1
        s.ratio=0x10000; s.logp=0
    def note(s,vel):                  # 0x74
        g=clamp(vel,1,127)*0x10200 if vel>=1 else 0x10200
        s.ph=[0,0,0x2aaaaaaa,0x55555554,0x7ffffffe,0xaaaaaaa8,0xd5555552]
        s.lp=s.bp=0; s.env=s.nenv=g; s.swp=0x10000; s.hold_n=s.hold_v=0; s.choke=0
    def finished(s): return s.env<0x300 and s.nenv<0x300
    def render(s,par,ratio=0x10000):  # 0x1044 -> 0x20c ; returns 128 samples
        if ratio==0: ratio=0x10000
        if ratio!=s.ratio:
            s.ratio=ratio; s.logp=log2q(ratio)
        return s.core(par,s.logp)
    def core(s,par,logp):
        p0=clamp(par[0],-0x5f00,0x6100); dec=max(par[1],0); swp=max(par[2],0); noi=max(par[3],0)
        col=max(par[4],0); colraw=par[4]; shp=max(par[5],0); shpraw=par[5]; drv=max(par[7],0); drvraw=par[7]
        k=((exp2q(0x60f2-dec)>>8)*0x3b3d)>>16
        nq=((0x7fff-noi)**2)>>15
        rate=sdiv(k<<15, 0x8000-((noi*0x599a)>>15))
        srate=max(rate*4,0x1ee)
        if s.choke==0:
            f1=exp2q(-rate); f2=exp2q(-(((((nq*nq>>15)*3)>>3)+0x1000)*k>>12))
        else: f1=f2=0x4000
        f3=exp2q(-srate)
        e0=s.env>>8; env1=(e0*f1)&M32; n0=s.nenv>>8; nenv1=(n0*f2)&M32; swp1=(s.swp*f3)&M32
        u=sdiv((p0+0x5f00)*2,3); samt=swp*5>>3
        def inc(sw):
            x=clamp(((sw>>1)*samt>>15)+u+logp,0,0x9287)
            return ((exp2q(x&0xfff)*0x5338)>>9)<<(x>>12)
        inc0=inc(s.swp); inc1=inc(swp1>>16); dinc=s32(inc1-inc0)>>6
        one_n2=0x7fff-(noi*noi>>15)
        if shpraw<=0x3fff:
            t=(shp*2)**2>>15; gain=(t*15>>7)+0x100; body=0x7fff; m0=m1=0
        else:
            m=(shp-0x4000)*2; body=0x7fff-m; m=m*one_n2>>15
            m1=(env1>>16)*m>>7; m0=e0*m>>7; gain=0x1000
        i=col>>11; G=(((AMP[i+1]-AMP[i])*(col&0x7ff)>>11)+AMP[i])*2
        b=one_n2*body>>15; b0=e0*b>>7; b1=(env1>>16)*b>>7
        q=0x7fff-nq; nz0=n0*q>>7; nz1=(nenv1>>16)*q>>7
        f=(exp2q((col*71)>>7)*700); fc=16000 if f>0x3e80ffff else (f>>16)
        cmix=col-0x4000 if colraw>0x3fff else col
        dg=(((drv*drv>>15)*15)>>7)+0x100; dout=0x3ccd-(drv*0xc29>>15)
        if drvraw<=0x4ccd: hold=1; mask=-1
        else:
            t=((drv-0x4ccd)*5>>1)*5; mask=-1<<(t>>14); hold=(t>>15)+1
        out=[0]*64
        R=(0x1000,0x17b9,0x1cce,0x28bd,0x2a16,0x3e59)
        if (m0|m1)>0x3ff:
            base=inc0>>12; mi=s32(m1-m0)>>6; me=m0
            for n in range(64):
                neg=0
                for j in range(6):
                    s.ph[1+j]=(s.ph[1+j]+base*R[j])&M32; neg+=s.ph[1+j]>>31
                me+=mi; out[n]=s32((3-neg)*s16(me>>8))>>4
        hasm=(m0|m1)>0x3ff
        if hasm or (nz0|nz1)>0x3ff:
            ne=nz0; ni=s32(nz1-nz0)>>6
            for n in range(64):
                x=s.seed; x^=(x<<13)&M32; x^=x>>17; x^=(x<<5)&M32; s.seed=x
                ne=s32(ne+ni); nz=s32(s16(x>>16)*s16(ne>>8))>>17
                s.lp+=s32(fc*s16(s.bp))>>14
                hp=clamp((out[n] if hasm else 0)+nz-s.lp-s.bp,-0x7fff,0x7fff)
                s.bp+=s32(fc*hp)>>14
                if colraw<=0x3fff: y=(s16(s.lp)*(0x4000-cmix)+s16(s.bp)*cmix)>>14
                else: y=(s16(s.bp)*(0x4000-cmix)+hp*cmix)>>14
                out[n]=clamp(s16(y)*G>>8,-0x7fff,0x7fff)
        if (b0|b1)>0x3ff:
            ph=s.ph[0]; ii=inc0; be=b0; bi=s32(b1-b0)>>6; add=hasm or (nz0|nz1)>0x3ff
            for n in range(64):
                ph=(ph+ii)&M32; ii=s32(ii+dinc)
                x=s16(ph>>16); y=s32(x*s16(0x7fff-abs(x)))>>13
                y=clamp(s32(s16(y)*s16(gain))>>8,-0x7fff,0x7fff)
                be=s32(be+bi); v=s32(y*s16(be>>8))>>16
                out[n]=clamp((out[n] if add else 0)+v,-0x7fff,0x7fff)
            s.ph[0]=(s.ph[0]+64*inc0+0x7e0*dinc)&M32
        for n in range(64):
            x=clamp(s32(s16(out[n])*s16(dg))>>7,-0x7fff,0x7fff)
            c=s32(x*s16(s32(x*x)>>15))
            if hold==1 and mask==-1:
                y=clamp(x+(x>>1)-(c>>16),-0x7fff,0x7fff)
            else:
                s.hold_n-=1
                if s.hold_n<=0:
                    s.hold_v=clamp(x+(x>>1)-(c>>16),-0x7fff,0x7fff)&mask; s.hold_n=hold
                y=s.hold_v
            out[n]=s32(s16(y)*s16(dout))>>15
        s.env=(env1>>8); s.nenv=(nenv1>>8); s.swp=swp1>>16
        o=[]
        for v in out: o+= [v,v]
        return o
