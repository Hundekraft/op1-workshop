#!/usr/bin/env python3
"""HIM's generated data: him_data.h (tables, kits, debris fan, 5x7 font, camera), him.svg (the box, the page's
still part) and him_presets.h (the factory kits as drum_presets rows). Reads him-data/ (the original drum engine 0.1.9 and
3D renderer 0.2.5, imported with the author's permission per the owner, 2026-11-09).

    python3 synth_sdk/plugins/him/gen_data.py            (writes the three files next to this script)
    python3 synth_sdk/plugins/him/gen_data.py --check    (exit 1 if a checked-in file differs)

Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE / 'him-data'

# Camera: the original's own, f3_begin(yaw 0, pitch 0x82, scale 0x1D64, cx 0xA000, cy 0x869A): the box spans page y 23..144,
# labels to 145. An owner-approved exception to kennel's OLED bottom-margin target (docs/screen-art.md): a photo of
# the original on the owner's OP-1 shows the whole box on the OLED (2026-11-09).
PITCH = 0x82
SCALE = 0x1D64
CX = 0xA000
CY = 0x869A

STYLE_PX = (2.0, 1.5, 1.0)          # the renderer line_width table (0x4000): Q8 panel px 512, 384, 256
E1 = 0x00ED95                       # stock green encoder colour (the original's box ink, the host accent 1)


def T(k):                            # the textbook sine; the original host's sincos differs by up to 1.5 (README)
    return round(4096 * math.sin(2 * math.pi * k / 4096))


def sincos(a):
    q, i = (a >> 10) & 3, a & 1023
    return [(T(i), T(1024 - i)), (T(1024 - i), -T(i)), (-T(i), -T(1024 - i)), (-T(1024 - i), T(i))][q]


def view_matrix():
    s, c = sincos(PITCH)
    return [[4096, 0, 0], [0, c, -s], [0, s, c]]   # Rx(pitch) * Ry(0)


def to_page(p, M=None):
    M = M or view_matrix()
    v = [sum((M[r][k] * p[k] + 0x800) >> 12 for k in range(3)) for r in range(3)]
    return CX + ((v[0] * SCALE) >> 12), CY - ((v[1] * SCALE) >> 12)


def kit_raw(hz, ms, octs, noise, colour, shape, group, drive):
    """A key from readable values: pitch Hz, decay ms, sweep octaves, noise 0..99, raw colour, raw shape, choke
    group 0..4, drive 0..99 (crunch above 46)."""
    u = 4096 * math.log2(hz / 28)
    p0 = max(-24320, min(24832, round(u * 3 / 2) - 0x5F00))
    d = max(0, min(32767, round(4096 * math.log2(ms / 15))))
    return [p0, d, round(octs * 32767 / 5), round(noise * 32767 / 99), colour, shape,
            min(32767, group * 8192), round(drive * 32767 / 99)]


def kits():
    orig = [k['raw'] for k in json.load(open(DATA / 'him-kit.json'))['keys']]
    K = kit_raw
    # RANGE: one key per corner of the sound: the deepest sub, a 5-octave zap, the sine -> metal shapes, the colour
    # sweep low -> band -> high, the crunch, pure noise, the highest tick
    rng = [K(28, 3000, 1.0, 0, 4000, 0, 0, 10), K(36, 1400, 5.0, 0, 8000, 2000, 0, 30), K(60, 600, 3.0, 5, 9000, 9000, 0, 45),
           K(90, 400, 2.0, 10, 12000, 16000, 0, 55), K(140, 300, 1.0, 20, 14000, 22000, 0, 40), K(200, 250, 0.5, 30, 16384, 26000, 0, 35),
           K(300, 220, 0.2, 40, 20000, 30000, 0, 30), K(420, 200, 0, 50, 24000, 32767, 0, 25), K(600, 120, 0, 70, 28000, 32767, 1, 20),
           K(600, 900, 0, 70, 28000, 32767, 1, 20), K(800, 60, 0, 99, 31000, 32767, 1, 10), K(1000, 1800, 0, 30, 20000, 32767, 0, 30),
           K(55, 350, 2.5, 0, 6000, 16000, 0, 99), K(80, 250, 1.5, 15, 10000, 16000, 0, 90), K(110, 180, 1.0, 40, 14000, 12000, 0, 80),
           K(150, 120, 0.5, 60, 18000, 8000, 0, 70), K(200, 900, 0, 99, 2000, 0, 2, 0), K(200, 900, 0, 99, 12000, 0, 2, 0),
           K(200, 900, 0, 99, 22000, 0, 2, 0), K(200, 900, 0, 99, 32000, 0, 2, 0), K(2000, 40, 0.8, 20, 26000, 16000, 0, 40),
           K(3500, 25, 0.5, 10, 30000, 20000, 0, 50), K(5000, 15, 0, 0, 32767, 16000, 0, 60), K(7168, 15, 0, 0, 32767, 0, 0, 0)]
    # him ghost (the preset's name since 2026-11-09, kept): woody and skinny hits whose solids bounce long (decay is the
    # bounciness) and collide (big, low solids in four lanes). Hats in choke group 1.
    gho = [K(48, 700, 2.0, 2, 9000, 2500, 0, 40), K(60, 500, 2.5, 4, 9500, 5000, 0, 50), K(42, 1100, 1.5, 0, 8000, 0, 0, 30),
           K(420, 45, 0, 75, 29000, 32767, 1, 15), K(180, 260, 1.0, 55, 17000, 6000, 0, 45), K(420, 500, 0, 70, 28500, 32767, 1, 15),
           K(240, 160, 1.4, 60, 21000, 9000, 0, 60), K(70, 900, 1.2, 6, 10000, 3000, 0, 35), K(600, 70, 0, 85, 26000, 32767, 1, 10),
           K(90, 800, 1.0, 8, 12000, 4000, 0, 35), K(320, 600, 0.3, 10, 15000, 14000, 0, 45), K(120, 700, 1.0, 8, 13000, 4000, 0, 35),
           K(160, 650, 1.0, 8, 14000, 4000, 0, 35), K(700, 350, 0, 20, 20000, 12000, 0, 30), K(220, 550, 0.6, 10, 15500, 8000, 0, 40),
           K(900, 300, 0, 15, 22000, 13000, 0, 30), K(260, 500, 0.5, 12, 16000, 7000, 0, 40), K(1200, 250, 0, 10, 23000, 15000, 0, 30),
           K(330, 450, 0.4, 14, 17000, 7000, 0, 45), K(1500, 200, 0, 10, 24000, 16000, 0, 30), K(400, 400, 0.3, 16, 18000, 6000, 0, 50),
           K(35, 2000, 1.2, 0, 7000, 0, 0, 25), K(2400, 120, 0.4, 25, 26000, 16000, 0, 35), K(1800, 900, 0, 30, 25000, 20000, 0, 40)]
    # METAL: square -> six-oscillator metal across the keys, bells and gongs, crunched clanks, two choke groups
    met = [K(50, 900, 3.0, 0, 9000, 16384, 0, 85), K(70, 600, 2.0, 10, 11000, 20000, 0, 95), K(110, 1500, 0.5, 0, 14000, 24000, 0, 60),
           K(300, 60, 0, 60, 30000, 32767, 1, 30), K(150, 2500, 0.2, 5, 16000, 27000, 0, 40), K(300, 700, 0, 60, 30000, 32767, 1, 30),
           K(200, 350, 1.0, 20, 18000, 25000, 0, 90), K(250, 3000, 0, 10, 20000, 30000, 0, 35), K(450, 90, 0, 80, 31000, 32767, 1, 20),
           K(330, 1200, 0.1, 0, 21000, 28000, 2, 45), K(500, 400, 0, 30, 24000, 31000, 0, 70), K(330, 80, 0.1, 0, 21000, 28000, 2, 45),
           K(400, 1800, 0, 5, 23000, 29000, 0, 40), K(800, 150, 0.4, 40, 27000, 32767, 0, 95), K(550, 2200, 0, 0, 25000, 30000, 0, 35),
           K(1100, 600, 0, 20, 28000, 32767, 0, 50), K(650, 1000, 0, 10, 26000, 31000, 0, 45), K(1300, 300, 0.2, 30, 29000, 32767, 0, 80),
           K(750, 1600, 0, 0, 26500, 30500, 0, 40), K(1600, 200, 0, 40, 30000, 32767, 0, 60), K(900, 800, 0, 15, 27000, 32000, 0, 55),
           K(60, 3500, 0.8, 0, 9000, 22000, 0, 70), K(2500, 60, 0, 50, 32000, 32767, 0, 99), K(1000, 2500, 0.3, 20, 28000, 32767, 0, 75)]
    return [('default', 'him default', orig), ('range', 'him range', rng), ('ghost', 'him ghost', gho), ('metal', 'him metal', met)]


def box_svg():
    box = json.load(open(DATA / 'him-box.json'))
    groups = {}
    ys = []
    for ln in box['lines']:
        x0, y0 = to_page(ln['a'])
        x1, y1 = to_page(ln['b'])
        a = ln['alpha']
        colour = '#%02x%02x%02x' % tuple(((E1 >> s) & 255) * a // 256 for s in (16, 8, 0))   # glow over black
        w = STYLE_PX[ln['style']] * 320 / 400                                              # panel px -> units
        groups.setdefault((colour, w), []).append((x0 / 256, y0 / 256, x1 / 256, y1 / 256))
        ys += [y0 / 256 + w / 2, y1 / 256 + w / 2]
    out = ['<svg xmlns="http://www.w3.org/2000/svg" width="320" height="160" viewBox="0 0 320 160">',
           '<g id="box" fill="none" stroke-linecap="butt">']
    for (colour, w), segs in sorted(groups.items()):
        d = ' '.join(f'M{x0:.2f} {y0:.2f}L{x1:.2f} {y1:.2f}' for x0, y0, x1, y1 in segs)
        out.append(f'<path d="{d}" stroke="{colour}" stroke-width="{w:.2f}"/>')
    out += ['</g>', '</svg>', '']
    return '\n'.join(out), max(ys)


def debris_fan():
    """him-debris-fan.json's formula with the textbook sine (the same as its stored points)"""
    out = []
    for i in range(30):
        v = ((((573 * (i % 5) + 1229) * sincos((i * 0x61D) & 0xFFF)[0] + 0x800) >> 12) * 7)
        out.append([int(v / 5), ((((7 * i) % 11) * 3686) // 11 + 410) * 11 // 10])
    return out


def header():
    t = json.load(open(DATA / 'him-tables.json'))
    fan = debris_fan()
    font = json.load(open(DATA / 'f3-font-5x7.json'))
    L = ['/* Generated by gen_data.py from him-data/ (the original drum engine 0.1.9 and 3D renderer 0.2.5, imported with the',
         ' * author\'s permission per the owner, 2026-11-09). Do not edit.',
         ' * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */',
         '#ifndef HIM_DATA_H', '#define HIM_DATA_H', '#include <stdint.h>', '',
         f'#define HIM_PITCH {PITCH}            /* camera: Rx(pitch), 4096 a turn */',
         f'#define HIM_SCALE {SCALE:#x}         /* Q12, the original: 0x1D64 */',
         f'#define HIM_CX {CX:#x}            /* page Q8 */',
         f'#define HIM_CY {CY:#x}            /* page Q8, the original: 0x869A */', '']
    s, c = sincos(PITCH)
    L.append(f'#define HIM_CAM_S {s}\n#define HIM_CAM_C {c}\n')
    L.append('static const uint32_t HIM_EXP[17] = {' + ', '.join(map(str, t['exp2_table']['values'])) + '};')
    L.append('static const int16_t HIM_AMP[17] = {' + ', '.join(map(str, t['filter_gain_table']['values'])) + '};')
    L.append('static const int32_t HIM_LANE[4] = {' + ', '.join(map(str, t['lane_z']['values'])) + '};')
    L.append('static const int16_t HIM_FAN[30][2] = {' + ', '.join(f'{{{x}, {y}}}' for x, y in fan) + '};')
    L.append('/* sine quarter wave, round(4096 sin(2 pi k / 4096)), k = 0..1024 (the renderer sincos) */')
    L.append('static const int16_t HIM_SIN[1025] = {' + ','.join(str(T(k)) for k in range(1025)) + '};')
    rows = [g['rows_hex'] for g in sorted(font['glyphs'], key=lambda g: g['index'])]
    L.append('/* 5x7 font: A-Z, 0-9, \'.\', \'-\', blank; bit 4 = leftmost column */')
    L.append('static const uint8_t HIM_FONT[39][7] = {' + ', '.join('{' + ','.join('0x' + h for h in r) + '}' for r in rows) + '};')
    names = json.load(open(DATA / 'him-strings.json'))['shape_names']
    L.append('static const char *const HIM_SHAPE_NAMES[5] = {' + ', '.join(json.dumps(n) for n in names) + '};')
    box = json.load(open(DATA / 'him-box.json'))['lines']
    L.append('/* the box (the original\'s still part): model ends (Q12 u), glow alpha, line style; drawn in this order */')
    L.append(f'#define HIM_BOX_N {len(box)}')
    L.append('static const struct { int16_t a[3], b[3]; uint8_t alpha, style; } HIM_BOX[HIM_BOX_N] = {' +
             ', '.join('{{%d,%d,%d},{%d,%d,%d},%d,%d}' % (*l['a'], *l['b'], l['alpha'], l['style']) for l in box) + '};')
    ks = kits()
    L.append(f'#define HIM_KITS {len(ks)}')
    L.append('static const int16_t HIM_KIT[HIM_KITS][24][8] = {')
    for name, title, k in ks:
        L.append(f' /* {title} */ {{' + ', '.join('{' + ','.join(map(str, key)) + '}' for key in k) + '},')
    L.append('};')
    L += ['', '#endif', '']
    return '\n'.join(L)


def presets_sql():
    """drum_presets rows (folder "him"), one per kit, inserted at registration when missing (by name)."""
    sql = []
    for name, title, k in kits():
        patch = {'dbox_data': k, 'dyna_env': [0, 8192, 0, 6912, 0, 0, 0, 0], 'fx_active': False,
                 'fx_params': [16448, 11552, 15360, 7712, 8000, 8000, 8000, 8000], 'fx_type': 'spring',
                 'lfo_active': False, 'lfo_params': [1024, 6304, 11120, 15360, 5808, 5808, 5584, 5808], 'lfo_type': 'midi',
                 'name': title, 'octave': 0, 'synth_version': 1, 'type': 'him'}
        text = json.dumps(patch, separators=(',', ':'))
        q = "'" + text.replace("'", "''") + "'"
        sql.append("INSERT INTO drum_presets(id,patch,folder) SELECT (SELECT COALESCE(MAX(id),-1)+1 FROM drum_presets),"
                   + q + ",'him' WHERE NOT EXISTS (SELECT 1 FROM drum_presets WHERE folder='him' AND patch LIKE '%\"name\":\""
                   + title + "\"%');")
    return sql


def presets():
    sql = presets_sql()
    return ('/* Generated by gen_data.py: HIM\'s kits as drum_presets rows (folder "him"). Do not edit.\n'
            ' * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */\n'
            'static const char *const him_preset_sql[] = {\n' + ''.join(' ' + json.dumps(s) + ',\n' for s in sql) + ' 0};\n')


def catalog(c):
    """make_firmware.py patch_db (plugin.json drum_synth.catalog): the same rows him_fw.c ensures at boot."""
    if not c.execute("SELECT 1 FROM drum_types WHERE type='him'").fetchone():
        c.execute("INSERT INTO drum_types SELECT COALESCE(MAX(id),-1)+1,'him','[0,16000,0,0,0,0,0,0]' FROM drum_types")
    for _, title, k in kits():
        sql = [s for s in presets_sql() if f'"name":"{title}"' in s][0]
        c.execute(sql)


def main():
    svg, ymax = box_svg()
    assert ymax <= 146, f'box ink reaches y {ymax:.2f}'   # the OP-1 window: page y 2..146 (the renderer's clip)
    # the page draws the box itself with the facet3d port (pixel-exact with the original's still part); the screen object
    # only needs a document: an empty one
    svg = '<svg xmlns="http://www.w3.org/2000/svg" width="320" height="160" viewBox="0 0 320 160"/>\n'
    files = {'him_data.h': header(), 'him.svg': svg, 'him_presets.h': presets()}
    if '--check' in sys.argv:
        bad = [n for n, t in files.items() if not (HERE / n).exists() or (HERE / n).read_text() != t]
        print('gen_data: ' + ('differs: ' + ', '.join(bad) if bad else 'up to date'))
        return 1 if bad else 0
    for n, t in files.items():
        (HERE / n).write_text(t)
    print(f'gen_data: wrote {", ".join(files)} (box ink to y {ymax:.2f})')
    return 0


if __name__ == '__main__':
    sys.exit(main())
