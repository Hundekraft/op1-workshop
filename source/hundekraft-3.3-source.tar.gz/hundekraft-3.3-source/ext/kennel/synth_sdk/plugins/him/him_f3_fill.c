/* HIM's facet3d port, part 2: convex fills (black or darkened), dots, the 5x7 pixel font, dashed rectangles,
 * ellipses, the scope band and waves, and the sphere fill. the original 3D renderer (0.2.5), ported with the author's
 * permission (per the owner, 2026-11-09), statement by statement so the pixels are the same (test/f3_oracle.py).
 * GUI thread only. Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission. */
#include "him_f3_int.h"
#include "him_data.h"


/* one pixel without coverage (dots, text, rectangles: the renderer writes these inline) */
static inline void put(uint16_t *p)
{
    if (f3s.mode == 2) {
        const uint16_t c = f3s.ramp2[32];
        if (c) *p = f3s.alpha < 0x100 ? f3i_max(*p, c) : c;
    } else if (f3s.mode == 0) {
        if ((*p & 0x7e0) < (f3s.ramp0[32] & 0x7e0)) *p = f3s.ramp0[32];
    } else if (f3s.alpha > 0) *p = f3s.alpha < 0x100 ? f3i_blend(*p, f3s.alpha) : f3s.ramp0[32];
}

/* ---- convex fill (0x0598): per panel column, black or every lit pixel x (256 - alpha) / 256 ---- */
static void fill(const int (*xy)[2], int n, int a)
{
    const int k = 0x100 - a, rows = f3s.rows;
    if (n < 1) return;
    int X[32], Y[32], sl[32], xmax = -0x40000000, xmin = 0x40000000;
    for (int i = 0; i < n; i++) {
        X[i] = (xy[i][0] >> 4) * f3s.S >> 16;
        Y[i] = (xy[i][1] >> 4) * f3s.S >> 16;
        xmax = imax(xmax, X[i]); xmin = imin(xmin, X[i]);
    }
    for (int i = 0; i < n; i++) {
        const int j = i + 1 < n ? i + 1 : 0;
        sl[i] = X[j] == X[i] ? 0 : (Y[j] - Y[i]) * 0x1000 / (X[j] - X[i]);
    }
    int xr = (xmax - 8) >> 4, xl = (xmin + 8) >> 4;
    xl = xl < 0 ? 0 : xl;
    if (rows <= xr) xr = rows - 1;
    if (xr < xl) return;
    for (int col = xl; col <= xr; col++) {
        const int xc = col * 0x10 + 8;
        int lo = 0x40000000, hi = -0x40000000;
        for (int i = 0; i < n; i++) {
            const int j = i + 1 < n ? i + 1 : 0, xa = X[i], xb = X[j];
            if (xa == xb) continue;
            if ((xa <= xc && xc <= xb) || (xb <= xc && xc <= xa)) {
                const int y = ((xc - xa) * sl[i] >> 12) + Y[i];
                lo = imin(lo, y); hi = imax(hi, y);
            }
        }
        if (hi < lo) continue;
        const int y1 = imin(f3s.yhi, (hi - 8) >> 4), y0 = imax((lo + 8) >> 4, f3s.ylo);
        uint16_t *base = f3s.frame + (rows - 1 - col) * 0x100;
        for (int y = y0; y <= y1; y++) {
            uint16_t *p = base + y;
            if (!k) *p = 0;
            else if (*p) {
                const unsigned q = *p;
                *p = (uint16_t)((((q >> 11) * k >> 8) << 11) | (((q & 0x1f) * k) >> 8) | ((((q >> 5) & 0x3f) * k >> 8) << 5));
            }
        }
    }
}

void f3_fill(const int (*xy)[2], int n) { if (f3s.frame && (unsigned)(n - 3) < 0x1e) fill(xy, n, 0x100); }
void f3_fill_alpha(const int (*xy)[2], int n, int alpha)
{
    if (f3s.frame && (unsigned)(n - 3) < 0x1e && alpha > 0) fill(xy, n, alpha > 0x100 ? 0x100 : alpha);
}

/* ---- dot (0x239C) ---- */
void f3_dot(int x, int y, int size)
{
    if (!f3s.frame) return;
    const int h = size >> 1, S = f3s.S;
    const int xe0 = ((h + x) >> 4) * S >> 20, x0 = ((x - h) >> 4) * S >> 20;
    const int ye0 = ((h + y) >> 4) * S >> 20, y0 = ((y - h) >> 4) * S >> 20;
    const int x1 = xe0 <= x0 ? x0 : xe0 - 1, y1 = ye0 <= y0 ? y0 : ye0 - 1;
    for (int xx = x0; xx <= x1; xx++)
        for (int yy = y0; yy <= y1; yy++)
            if ((unsigned)xx < (unsigned)f3s.rows && f3s.ylo <= yy && yy <= f3s.yhi)
                put(f3s.frame + ((f3s.rows - 1 - xx) * 0x100 + yy));
}

/* ---- the 5x7 font (0x2620) ---- */
static int glyph_row(int ch)
{
    if (ch < 0x3a) {
        if (ch < 0x30) return ch == 0x2d ? 37 : ch == 0x2e ? 36 : 38;
        return ch - 0x16;
    }
    if (ch < 0x5b) return ch < 0x41 ? 38 : ch - 0x41;
    return (unsigned char)(ch - 0x61) > 0x19 ? 38 : ch - 0x61;
}

int f3_text_width(int px, int nchars) { return nchars > 0 ? (nchars * 6 - 1) * px * 0x14000 / f3s.rows : 0; }

int f3_text(int x, int y, int px, const char *s)
{
    const int S = f3s.S, Y0 = (y >> 4) * S >> 20;
    unsigned X = (unsigned)(((x >> 4) * S) >> 20);
    if (!*s) return 0;
    int n = 0;
    for (; s[n]; n++, X += (unsigned)px * 6) {
        if (!f3s.frame) continue;
        const uint8_t *g = HIM_FONT[glyph_row((signed char)s[n])];
        for (int r = 0; r < 7; r++) {
            const int yr = Y0 + r * px;
            unsigned cx = X;
            for (int c = 0; c < 5; c++, cx += (unsigned)px) {
                if (!(g[r] & (0x10 >> c)) || px <= 0) continue;
                for (int i = 0; i < px; i++)
                    for (int yy = yr; yy < yr + px; yy++)
                        if (cx + (unsigned)i < (unsigned)f3s.rows && f3s.ylo <= yy && yy <= f3s.yhi)
                            put(f3s.frame + ((f3s.rows - 1 - (int)(cx + (unsigned)i)) * 0x100 + yy));
            }
        }
    }
    return (n * 6 - 1) * px * 0x14000 / f3s.rows;
}

/* ---- still to port exactly ---- */
/* ---- rectangle outline (0x2AB0): top left to right, right edge down, bottom right to left, left edge up; thick
 * pixels grown inward; with off != 0 a dash counter over the steps (mod on + off) draws the steps below on ---- */
static inline void rput(int x, int y)
{
    if ((unsigned)x < (unsigned)f3s.rows && f3s.ylo <= y && y <= f3s.yhi) put(f3s.frame + ((f3s.rows - 1 - x) * 0x100 + y));
}
void f3_rect(int x0, int y0, int x1, int y1, int on, int off, int thick)
{
    if (!f3s.frame) return;
    const int S = f3s.S;
    const int X1 = (x1 >> 4) * S >> 20, X0 = (x0 >> 4) * S >> 20, Y0 = (y0 >> 4) * S >> 20, Y1 = (y1 >> 4) * S >> 20;
    const int per = on + off;
    int k = 0;
#define DRAW() ((off == 0 || k < on) && thick > 0)
#define NEXT() do { k++; if (per <= k) k = 0; } while (0)
    if (X1 < X0) { if (Y1 < Y0) return; }
    else {
        for (int x = X0; x <= X1; x++) { if (DRAW()) for (int t = 0; t < thick; t++) rput(x, Y0 + t); NEXT(); }
        if (Y1 < Y0) goto bottom;
    }
    for (int y = Y0; y <= Y1; y++) { if (DRAW()) for (int t = 0; t < thick; t++) rput(X1 - t, y); NEXT(); }
    if (X1 < X0) goto left;
bottom:
    {
        int n = X1 - X0 + 1;
        if (X1 - 1 < X0 - 1) n = 1;
        for (int i = 0, x = X1; i < n; i++, x--) { if (DRAW()) for (int t = 0; t < thick; t++) rput(x, Y1 - t); NEXT(); }
    }
    if (Y1 < Y0) return;
left:
    for (int y = Y1; y >= Y0; y--) { if (DRAW()) for (int t = 0; t < thick; t++) rput(X0 + t, y); NEXT(); }
#undef DRAW
#undef NEXT
}
/* ---- an anti-aliased vertical run (0x1298) in one column from a to b (Q8 px), ends by their coverage, with the
 * ellipse ramp; the run's inside in the full colour (max-blended below alpha 256) ---- */
static void span(uint16_t *col, int a, int b)
{
    int n1 = (b - 1) >> 8;
    const int n0 = a >> 8;
    if (!(f3s.ylo <= n1 && n0 <= f3s.yhi)) return;
    if (n0 == n1) {
        const uint16_t c = f3s.eramp[b - a < 0x108 ? (b - a) >> 3 : 32];
        if (c) col[n0] = f3i_max(col[n0], c);
        return;
    }
    if (f3s.ylo <= n0) { const uint16_t c = f3s.eramp[((n0 + 1) * 0x100 - a) >> 3]; if (c) col[n0] = f3i_max(col[n0], c); }
    if (n1 <= f3s.yhi) { const uint16_t c = f3s.eramp[(b + n1 * -0x100) >> 3]; if (c) col[n1] = f3i_max(col[n1], c); }
    int i0 = imax(f3s.ylo, n0 + 1);
    n1 = imin(f3s.yhi, n1 - 1);
    if (f3s.alpha < 0x100) { for (int i = i0; i <= n1; i++) col[i] = f3i_max(col[i], f3s.eramp[32]); }
    else for (int i = i0; i <= n1; i++) col[i] = f3s.eramp[32];
}

/* ---- ellipse outline (0x3A74): per column, the upper and lower arcs as runs joining the neighbours' heights ---- */
void f3_ellipse(int cx, int cy, int rx, int ry, int thick, const int *clip)
{
    if (!f3s.frame || rx <= 0 || ry < 0) return;
    const int S = f3s.S, rows = f3s.rows;
    int xlo = 0, xhi = rows - 1, ylo = -0x100000, yhi = 0x100000;
    if (clip) {
        xlo = (clip[0] >> 4) * S >> 20; xhi = (clip[2] >> 4) * S >> 20;
        ylo = (clip[1] >> 4) * S >> 12; yhi = (clip[3] >> 4) * S >> 12;
    }
    const int a2 = (rx >> 4) * S, RX = a2 >> 12;
    if (a2 <= 0x3ffff) return;
    const int CX = (cx >> 4) * S >> 12;
    int c0 = ((CX - RX) >> 8) - 1;
    if (c0 < -1) c0 = -1;
    int c1 = ((CX + RX) >> 8) + 1;
    if (c1 > rows) c1 = rows;
    const int n = c1 - c0;
    if (!(n < 0x191 && c0 <= c1)) return;
    if (!f3s.esqrt[256])
        for (int k = 0; k <= 256; k++) f3s.esqrt[k] = (uint16_t)f3i_isqrt((unsigned)k * 0x400000u);
    const int step = 0x800000 / RX;
    int t = (((c0 * 0x100 + 0x80) - CX) * 0x80 / RX) * 0x100;
    int *h = f3s.bcol[0];
    const int ry14 = (ry >> 4) * S >> 14;
    for (int j = 0; j <= n; j++, t += step) {
        const int at = t < 0 ? -t : t;
        if (at < 0x8000) {
            const unsigned q = (unsigned)(0x8000 - (t * t >> 15)), i = q >> 7, i2 = i > 0xff ? 0xff : i;
            h[j] = (int)(((((unsigned)f3s.esqrt[i2 + 1] - (unsigned)f3s.esqrt[i]) * (q & 0x7f) >> 7) + f3s.esqrt[i]) * (unsigned)ry14 >> 13);
        } else h[j] = 0;
    }
    for (int i = 0, v = 0; i <= 32; i++, v += f3s.alpha * 8) {
        const int l = v >> 8;
        f3s.eramp[i] = i < 3 ? 0 : (uint16_t)((uint16_t)((f3s.G * l >> 8) << 5) | (uint16_t)((f3s.R * l >> 8) << 11) | (uint16_t)((unsigned)(l * f3s.B) >> 8));
    }
    const int half = thick >> 1;
    if (n <= 1) return;
    const int CY = (cy >> 4) * S >> 12;
    for (int x = c0 + 1, j = 0; x != c1; x++, j++) {
        if (!((unsigned)x < (unsigned)rows && xlo <= x && x <= xhi)) continue;
        const int h0 = h[j], h1 = h[j + 1], h2 = h[j + 2];
        if (!(h0 || h1 || h2)) continue;
        const int m12 = (h1 + h2) >> 1, m01 = (h0 + h1) >> 1;
        const int lo = imin(h1, imin(m12, m01)), hi = imax(imax(m01, m12), h1);
        const int A = (CY - hi) - half, D = CY + hi + half;
        int Bt = (CY - lo) + half, Cb = (CY + lo) - half;
        if (Cb <= Bt) { Cb = D; Bt = D; }
        uint16_t *col = f3s.frame + (rows - 1 - x) * 0x100;
        const int top0 = imax(A, ylo), e = imin(D, yhi);
        if (top0 < imin(Bt, yhi)) span(col, top0, imin(Bt, yhi));
        if (imax(Cb, ylo) < e) span(col, imax(Cb, ylo), e);
    }
}
/* ---- the scope band (0x368C): per column the lowest lo and the highest hi of the samples in it; each edge a run
 * through the midpoints with its neighbours, 0.75 px wider each way, both merged into one run when they come within
 * 1.75 px; the run's ends by coverage (band ramp, zero below step 4), its inside in the full colour (written) ---- */
static void bspan(uint16_t *col, int a, int b)
{
    const int n1 = (b - 1) >> 8, n0 = a >> 8;
    if (n1 < f3s.ylo || f3s.yhi < n0) return;
    if (n0 == n1) {
        int i = (b - a) >> 3;
        i = i > 0x20 ? 0x20 : i;
        if (f3s.bramp[i]) col[n0] = f3s.bramp[i];
        return;
    }
    if (f3s.ylo <= n0) { const uint16_t c = f3s.bramp[((n0 + 1) * 0x100 - a) >> 3]; if (c) col[n0] = c; }
    if (n1 <= f3s.yhi) { const uint16_t c = f3s.bramp[(b - n1 * 0x100) >> 3]; if (c) col[n1] = c; }
    const int i0 = imax(n0 + 1, f3s.ylo), i1 = imin(n1 - 1, f3s.yhi);
    for (int i = i0; i <= i1; i++) col[i] = f3s.bramp[32];
}
void f3_band(const short *lo, const short *hi, int n, int x, int y, int w, int h)
{
    if (!f3s.frame || n < 2) return;
    const int S = f3s.S;
    const int X0 = (x >> 4) * S >> 20, X1 = ((x + w) >> 4) * S >> 20;
    const int Yc = ((y >> 4) * S >> 20) * 0x100 + 0x80, H = (h >> 4) * S >> 12;
    for (int i = 0, v = 0; i <= 32; i++, v += f3s.alpha * 8) {
        const int l = v >> 8;
        f3s.bramp[i] = i < 4 ? 0 : (uint16_t)((uint16_t)((f3s.G * l >> 8) << 5) | (uint16_t)((f3s.R * l >> 8) << 11) | (uint16_t)((unsigned)(l * f3s.B) >> 8));
    }
    int cols, ncol, inc = n * 0x10000;
    if (X0 < X1) { cols = imin(X1 - X0, 399); ncol = cols + 1; inc = inc / ncol; }
    else { cols = 0; ncol = 1; }
    int *A = f3s.bcol[0], *B = f3s.bcol[1], acc = 0, s = 0;
    for (int c = 0; c < ncol; c++) {
        acc += inc;
        const int e = acc >> 16;
        int mn = 0x7fff, mx = -0x7fff;
        if (s < n) {
            int ie = e <= s ? s + 1 : e, cnt = ie - s, k = s;
            if (ie < s + 1) cnt = 1;
            do { mn = imin(lo[k], mn); mx = imax(mx, hi[k]); k++; cnt--; } while (cnt != 0 && n != k);
        }
        A[c] = Yc - (mn * H >> 15);
        B[c] = Yc - (mx * H >> 15);
        s = e;
    }
    B[ncol] = B[cols]; A[ncol] = A[cols];
    for (int c = 0; c < ncol; c++) {
        if (!((unsigned)(X0 + c) < (unsigned)f3s.rows)) continue;
        uint16_t *col = f3s.frame + (f3s.rows - 1 - X0 - c) * 0x100;
        const int p = c ? c - 1 : 0;
        const int T = B[c], tl = (T + B[p]) >> 1, tr = (T + B[c + 1]) >> 1;
        const int Bt = A[c], bl = (Bt + A[p]) >> 1, br = (Bt + A[c + 1]) >> 1;
        const int tmax = imax(imax(T, tr), tl);
        int s0 = imin(tl, imin(tr, T)) - 0xc0, s1 = tmax + 0xc0;
        const int s2 = imin(bl, imin(br, Bt)) - 0xc0, s3 = imax(imax(br, Bt), bl) + 0xc0;
        if (tmax + 0x1c0 < s2) { bspan(col, s0, s1); bspan(col, s2, s3); }
        else bspan(col, imin(s0, s2), imax(s1, s3));
    }
}
/* ---- wave (0x34E8): per panel column the sample interpolated, a run from the last column's height to this one,
 * written in ink x alpha ---- */
void f3_wave(const short *v, int n, int x, int y, int w, int h)
{
    if (!f3s.frame || n < 2) return;
    const int S = f3s.S, Yq = (y >> 4) * S, Hq = (h >> 4) * S;
    const uint16_t c = (uint16_t)(((f3s.R * f3s.alpha) >> 8) << 11 | ((f3s.G * f3s.alpha) >> 8) << 5 | (unsigned)(f3s.alpha * f3s.B) >> 8);
    const int X0 = (x >> 4) * S >> 20, X1 = ((x + w) >> 4) * S >> 20;
    int step = (n - 1) * 0x10000;
    if (X0 < X1) step = step / (X1 - X0);
    else if (X1 < X0) return;
    int pos = 0, prev = 0;
    for (int col = X0; col <= X1; col++, pos += step) {
        const int i = pos >> 16;
        int sv = v[i];
        if (i + 1 < n) sv += (int)((v[i + 1] - sv) * (pos >> 8 & 0xff)) >> 8;
        const int py = ((Yq >> 12) - (sv * (Hq >> 12) >> 15)) >> 8;
        int lo = py, hi = py;
        if (col != X0) { lo = imin(prev, py); hi = imax(prev, py); }
        hi += 1;
        if ((unsigned)col < (unsigned)f3s.rows) {
            lo = imax(lo, f3s.ylo); hi = imin(hi, f3s.yhi);
            uint16_t *p = f3s.frame + (f3s.rows - 1 - col) * 0x100;
            for (int yy = lo; yy <= hi; yy++) p[yy] = c;
        }
        prev = py;
    }
}
/* ---- sphere fill (0x1A10): every pixel of the sphere's disc whose front-surface point no other sphere hides is
 * set black, then its outline ---- */
void f3i_outline(int i);
void f3_sphere_fill(int i)
{
    if (!f3s.frame || i < 0 || f3s.nsph <= i) return;
    const int scale = f3s.scale, rows = f3s.rows, S = f3s.S;
    const int vcx = f3s.sph[i][0], vcy = f3s.sph[i][1], vcz = f3s.sph[i][2], r = f3s.sph[i][3];
    const int px = ((vcx * scale) >> 12) + f3s.cx, py = f3s.cy - ((vcy * scale) >> 12), rr = (r * scale) >> 12;
    const int xhi = ((rr + px) >> 8) * S >> 16, yhi = ((rr + py) >> 8) * S >> 16;
    int step = 0x140000 / rows;
    step = (step << 12) / scale;
    int y0 = ((py - rr) >> 8) * S >> 16;
    y0 = y0 < f3s.ylo ? f3s.ylo : y0;
    int x = ((px - rr) >> 8) * S >> 16;
    x = x < 0 ? 0 : x;
    const int vy0 = ((f3s.cy - ((y0 * 0x100 + 0x80) * 0x140 / rows)) * 0x1000) / scale;
    int vx = ((((x * 0x100 + 0x80) * 0x140 / rows) - f3s.cx) * 0x1000 / scale) * 16;
    if (x <= xhi && x < rows) {
        int rowoff = (rows - 1 - x) * 0x100;
        do {
            if (y0 <= yhi) {
                const int vxi = vx >> 4, dx = vxi - vcx;
                uint16_t *p = f3s.frame + rowoff + y0;
                int vyq = vy0 * 0x10;
                for (int y = y0; y <= yhi; y++, vyq -= step, p++) {
                    if (f3s.yhi < y) break;
                    const int vyi = vyq >> 4, dy = vyi - vcy, d2 = dy * dy + dx * dx;
                    if (d2 < r * r) {
                        const int pt[3] = { vxi, vyi, (int)f3i_isqrt((unsigned)(r * r - d2)) + vcz };
                        if (f3i_visible(pt, -1, i)) *p = 0;
                    }
                }
            }
            vx += step;
            x++;
            rowoff -= 0x100;
        } while (x <= xhi && rows != x);
    }
    f3i_outline(i);
}
