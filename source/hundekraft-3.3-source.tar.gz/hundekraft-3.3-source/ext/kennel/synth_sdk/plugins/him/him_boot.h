/* HIM's boot-done rebind rule (him_fw.c OP1_EV_BOOT_DONE), apart so the host test (test/boot_test.c) checks it.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HIM_BOOT_H
#define HIM_BOOT_H
#include <stdint.h>
/* Bind the receivers built before HIM registered only when the drum voice objects are the ones in the scratchpad: the
 * built play mode (0xFF801038) is drum (1). The factory builds drum objects at 0xFFB00000 + 72 * i, over the synth voice
 * objects (0xFFB00000 + 0x24 * v) that share the scratchpad; booted in synth mode, R246 kept the overwritten synth set
 * (Gin's 3.2.4 crash: RETX 0x2 in voicectl_start_voice). In synth mode R246 builds the drum set when the drum page is
 * entered, and kennel's bind_check (kn_drum_synth.c) binds HIM then. */
static inline int him_boot_rebind(uint32_t core_slot, const uint8_t selected[8], int32_t built_mode)
{
    return core_slot < 8 && selected[core_slot] && built_mode == 1;
}
#endif
