/* HIM's facet3d port: the library's state (the renderer keeps it in its zero fill) and the pixel helpers shared by
 * him_f3.c (camera, rasteriser, lines, 3D) and him_f3_fill.c (fills, dots, text, rectangles, ellipses, bands, waves).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HIM_F3_INT_H
#define HIM_F3_INT_H
#include <stdint.h>
#include "him_f3.h"

typedef struct {
    int M[9], scale, cx, cy;          /* view matrix (Q12), scale (Q12), page centre (Q8) */
    unsigned colour;                  /* the colour as passed (f3_begin, f3_ink) */
    int gap;                          /* the dark-gap pass switch */
    int mode, alpha;                  /* ink mode 0 lighten, 1 blend, 2 glow; alpha 0..256 */
    int R, G, B;                      /* the ink's r5, g6, b5 */
    uint16_t *frame;                  /* 0: no pixel path (no F3_RGB colour or no frame) */
    int rows, ylo, yhi, S;            /* panel long side, the window's first / last column, rows * 65536 / 320 */
    uint16_t ramp0[33];               /* mode 0's coverage ramp; [32] is also the ink as RGB565 */
    uint16_t ramp2[33];               /* glow ramp (f3_ink with bit 16) */
    uint16_t slen[257], scos[257];    /* slope tables: 256 sqrt(1 + (i/256)^2), 65536 / slen */
    int sph[8][4], nsph;              /* occluding spheres (view space) */
    int seg[320][4], nseg, phase, open;   /* pending page segments, dash phase, open path */
    int drawn, hidden;
    int pts[256][3];                  /* line / tick scratch (view points) */
    int cpts[256][3];                 /* circle scratch (model points) */
    int spts[96][3];                  /* sphere outline */
    uint16_t eramp[33];               /* ellipse span ramp */
    uint16_t esqrt[257];              /* ellipse sqrt table */
    uint16_t bramp[33];               /* band span ramp */
    int bcol[2][402];                 /* band / wave columns */
} f3_state;
extern f3_state f3s;

void f3i_sincos(int a, int *s, int *c);
int f3i_visible(const int *p, int near, int skip);
void f3i_view(const int *p, int *out);
void f3i_plot(unsigned x, int y, int cov, int erase);
void f3i_raster(int x0, int y0, int x1, int y1, int width, int erase, unsigned ends);
void f3i_flush(int width, int gapw, int on, int off);
unsigned f3i_isqrt(unsigned n);

static inline int imin(int a, int b) { return a < b ? a : b; }
static inline int imax(int a, int b) { return a > b ? a : b; }
/* per-channel max of an RGB565 pixel and a colour (the renderer's glow) */
static inline uint16_t f3i_max(uint16_t p, uint16_t c)
{
    const uint16_t g = (c & 0x7E0) > (p & 0x7E0) ? c & 0x7E0 : p & 0x7E0;
    const uint16_t r = (c & 0xF800) > (p & 0xF800) ? c & 0xF800 : p & 0xF800;
    const uint16_t b = (c & 0x1F) > (p & 0x1F) ? c & 0x1F : p & 0x1F;
    return (uint16_t)(g | r | b);
}
/* mode 1's blend of the ink into a pixel by a (1..255) */
static inline uint16_t f3i_blend(uint16_t p, int a)
{
    const int r = p >> 11, g = (p >> 5) & 63, b = p & 31;
    return (uint16_t)(((r + ((f3s.R - r) * a >> 8)) << 11) | ((g + ((f3s.G - g) * a >> 8)) << 5) | (b + ((f3s.B - b) * a >> 8)));
}

#endif
