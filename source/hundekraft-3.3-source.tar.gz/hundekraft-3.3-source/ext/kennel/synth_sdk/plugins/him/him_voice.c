/* HIM's drum voice: the original drum engine's synthesis (ported with the author's permission per the owner,
 * 2026-11-09). Line for line with him-data/him-voice-model.py (the model of the original 0x0000..0x11EA); check.py proves
 * the two bit-exact. Integers only; the two divides are redone only when the key's numbers, the pitch or choke change
 * (him_vcache), none per sample. The sample loops are him_k_noise / him_k_body / him_k_drive: C here (the host's, and
 * the reference with HIM_KERN_C), Blackfin assembly in him_kern.S (test/kern_check.py proves the two equal).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "him_voice.h"
#include "him_data.h"
#include "him_asm.h"
#ifdef HIM_PROF
uint32_t him_prof[8];                        /* test/prof_guest.c: cycles per stage, summed */
static inline uint32_t pcyc(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
#define PT(i) do { const uint32_t _t = pcyc(); him_prof[i] += _t - pt0; pt0 = _t; } while (0)
#define PT0 uint32_t pt0 = pcyc()
#else
#define PT(i) ((void)0)
#define PT0 ((void)0)
#endif
#ifdef HIM_COV
uint32_t him_cov[12];                        /* test/kern_guest.c: which paths ran */
#define COV(i) (him_cov[i]++)
#else
#define COV(i) ((void)0)
#endif

static inline int32_t clampi(int32_t x, int32_t a, int32_t b) { return x < a ? a : x > b ? b : x; }
static inline int32_t s16(int32_t x) { return (int16_t)x; }

uint32_t him_exp2q(int32_t x)
{
    const int32_t o = x >> 12, i = (x >> 8) & 15, f = x & 0xff;
    const uint32_t v = (uint32_t)(((((int32_t)HIM_EXP[i + 1] - (int32_t)HIM_EXP[i]) * f) >> 8) + (int32_t)HIM_EXP[i]) * 2u;
    if (x >= 0) return o >= 15 ? 0xffffffffu : v << o;
    return o < -17 ? 0 : v >> -o;
}

int32_t him_log2q(uint32_t r)
{
    if (r == 0x10000) return 0;
    uint32_t u = r;
    int32_t e = -1;
    if (r < 0x10000) { while (u < 0x8000) { u <<= 1; e--; } }
    else { do { u >>= 1; e++; } while (u > 0xffff); }
    int32_t f = 0, bit = 0x800;
    for (int k = 0; k < 12; k++) {
        const uint32_t sq = u * u;
        if ((sq >> 15) > 0xffff) { u = sq >> 16; f |= bit; } else u = sq >> 15;
        bit >>= 1;
    }
    return e * 0x1000 + f;
}

void him_voice_init(him_voice *v, int index)
{
    for (int i = 0; i < 7; i++) v->ph[i] = 0;
    v->seed = (uint32_t)(index + 1) * 0x9E3779B9u;
    if (!v->seed) v->seed = 0x2545F491u;
    v->lp = v->bp = 0; v->env = v->nenv = 0; v->swp = 0; v->hold_n = v->hold_v = 0; v->choke = 1;
    v->ratio = 0x10000; v->logp = 0;
    v->c.ok = 0;
}

void him_voice_note(him_voice *v, int velocity)
{
    const uint32_t g = (uint32_t)(velocity >= 1 ? clampi(velocity, 1, 127) : 1) * 0x10200u;
    static const uint32_t ph[7] = { 0, 0, 0x2aaaaaaau, 0x55555554u, 0x7ffffffeu, 0xaaaaaaa8u, 0xd5555552u };
    for (int i = 0; i < 7; i++) v->ph[i] = ph[i];
    v->lp = v->bp = 0; v->env = v->nenv = g; v->swp = 0x10000; v->hold_n = v->hold_v = 0; v->choke = 0;
}

static inline uint32_t step_inc(uint32_t sw, int32_t samt, int32_t u, int32_t logp)
{
    const int32_t x = clampi(((int32_t)(sw >> 1) * samt >> 15) + u + logp, 0, 0x9287);
    return ((him_exp2q(x & 0xfff) * 0x5338u) >> 9) << (x >> 12);
}

#define KP_AT(f, o) _Static_assert(__builtin_offsetof(him_kp, f) == (o), "him_kern.S reads him_kp." #f " at " #o)
KP_AT(r, 0); KP_AT(m0, 24); KP_AT(mi, 28); KP_AT(nz0, 32); KP_AT(ni, 36); KP_AT(inc0, 40); KP_AT(dinc, 44); KP_AT(b0, 48);
KP_AT(bi, 52); KP_AT(flag, 56);
#define V_AT(f, o) _Static_assert(__builtin_offsetof(him_voice, f) == (o), "him_kern.S reads him_voice." #f " at " #o)
V_AT(ph, 0); V_AT(seed, 28); V_AT(lp, 32); V_AT(bp, 36); V_AT(hold_n, 52); V_AT(hold_v, 56); V_AT(c.fc, 72);
V_AT(c.cmix, 76); V_AT(c.G, 80); V_AT(c.colhi, 84); V_AT(c.g, 88); V_AT(c.dgs, 92); V_AT(c.douts, 96); V_AT(c.hold, 100);
V_AT(c.mask, 104);

static him_kp kp_s;                                 /* the block's values, one for all voices (audio thread only) */

/* the constants that depend only on the key's numbers, the pitch and choke (the divides are here) */
static void derive(him_voice *v, const int16_t *par)
{
    him_vcache *c = &v->c;
    for (int i = 0; i < 8; i++) c->par[i] = par[i];
    c->logp = v->logp; c->choke = v->choke; c->ok = 1; c->inc_ok = 0;
    const int32_t p0 = clampi(par[0], -0x5f00, 0x6100);
    const int32_t dec = par[1] > 0 ? par[1] : 0, swp = par[2] > 0 ? par[2] : 0, noi = par[3] > 0 ? par[3] : 0;
    const int32_t colraw = par[4], col = colraw > 0 ? colraw : 0, shpraw = par[5], shp = shpraw > 0 ? shpraw : 0;
    const int32_t drvraw = par[7], drv = drvraw > 0 ? drvraw : 0;

    const int32_t k = (int32_t)(((him_exp2q(0x60f2 - dec) >> 8) * 0x3b3du) >> 16);
    const int32_t nq = ((0x7fff - noi) * (0x7fff - noi)) >> 15;
    const int32_t rate = (int32_t)((uint32_t)(k << 15) / (uint32_t)(0x8000 - ((noi * 0x599a) >> 15)));   /* both >= 0 */
    const int32_t srate = rate * 4 > 0x1ee ? rate * 4 : 0x1ee;
    if (!v->choke) {
        c->f1 = him_exp2q(-rate);
        c->f2 = him_exp2q(-((((((nq * nq) >> 15) * 3) >> 3) + 0x1000) * k >> 12));
    } else c->f1 = c->f2 = 0x4000;
    c->f3 = him_exp2q(-srate);
    {                                               /* u = 2 x / 3 for x = p0 + 0x5f00 in 0 .. 0xc000, no divide:
                                                     * q = x / 3 = x 43691 >> 17 (exact there), and 2 x / 3 = 2 q + (r == 2) */
        const uint32_t x = (uint32_t)(p0 + 0x5f00), q = (x * 43691u) >> 17;
        c->u = (int32_t)(2 * q + ((x - 3 * q) >> 1));
    }
    c->samt = swp * 5 >> 3;
    const int32_t one_n2 = 0x7fff - ((noi * noi) >> 15);
    int32_t gain, body;
    if (shpraw <= 0x3fff) {
        const int32_t t = ((shp * 2) * (shp * 2)) >> 15;
        gain = ((t * 15) >> 7) + 0x100; body = 0x7fff; c->msc = -1;
    } else {
        const int32_t m = (shp - 0x4000) * 2;
        body = 0x7fff - m; c->msc = m * one_n2 >> 15; gain = 0x1000;
    }
    const int32_t ai = col >> 11;
    c->G = (((((int32_t)HIM_AMP[ai + 1] - HIM_AMP[ai]) * (col & 0x7ff)) >> 11) + HIM_AMP[ai]) * 2;
    c->b = one_n2 * body >> 15;
    c->q = 0x7fff - nq;
    const uint32_t ff = him_exp2q((col * 71) >> 7) * 700u;
    c->fc = ff > 0x3e80ffffu ? 16000 : (int32_t)(ff >> 16);
    c->cmix = colraw > 0x3fff ? col - 0x4000 : col;
    c->colhi = colraw > 0x3fff;
    c->g = s16(gain);
    c->dgs = s16(((((drv * drv) >> 15) * 15) >> 7) + 0x100);
    c->douts = s16(0x3ccd - ((drv * 0xc29) >> 15));
    if (drvraw <= 0x4ccd) { c->hold = 1; c->mask = -1; }
    else {
        const int32_t t = (((drv - 0x4ccd) * 5) >> 1) * 5;
        c->mask = (int32_t)(0xffffffffu << (t >> 14)); c->hold = (t >> 15) + 1;
    }
    c->crunch = !(c->hold == 1 && c->mask == -1);
}

void him_voice_render(him_voice *v, int16_t *out, const int16_t *par, uint32_t ratio)
{
    PT0;
    if (!ratio) ratio = 0x10000;
    if (ratio != v->ratio) { v->ratio = ratio; v->logp = him_log2q(ratio); }
    him_vcache *c = &v->c;
    him_kp *kp = &kp_s;
    if (!c->ok || c->logp != v->logp || c->choke != v->choke || c->par[0] != par[0] || c->par[1] != par[1] ||
        c->par[2] != par[2] || c->par[3] != par[3] || c->par[4] != par[4] || c->par[5] != par[5] ||
        c->par[6] != par[6] || c->par[7] != par[7])
        { derive(v, par); COV(0); }
    const uint32_t e0 = v->env >> 8, env1 = e0 * c->f1, n0 = v->nenv >> 8, nenv1 = n0 * c->f2, swp1 = v->swp * c->f3;
    const int hit = c->inc_ok && c->inc_swp == v->swp;
    const uint32_t inc0 = hit ? c->inc : step_inc(v->swp, c->samt, c->u, c->logp);
    if (hit) COV(1);
    const uint32_t inc1 = step_inc(swp1 >> 16, c->samt, c->u, c->logp);
    c->inc_swp = swp1 >> 16; c->inc = inc1; c->inc_ok = 1;
    const int32_t dinc = (int32_t)(inc1 - inc0) >> 6;
    int32_t m0 = 0, m1 = 0;
    if (c->msc >= 0) { m1 = (int32_t)(env1 >> 16) * c->msc >> 7; m0 = (int32_t)e0 * c->msc >> 7; }
    const int32_t b0 = (int32_t)e0 * c->b >> 7, b1 = (int32_t)(env1 >> 16) * c->b >> 7;
    const int32_t nz0 = (int32_t)n0 * c->q >> 7, nz1 = (int32_t)(nenv1 >> 16) * c->q >> 7;
    PT(0);

    const int hasm = (m0 | m1) > 0x3ff;
    const int hasn = hasm || (nz0 | nz1) > 0x3ff;
    if (hasn) {
        if (hasm) {
            const uint32_t base = inc0 >> 12;
            kp->r[0] = base * 0x1000u; kp->r[1] = base * 0x17b9u; kp->r[2] = base * 0x1cceu; kp->r[3] = base * 0x28bdu;
            kp->r[4] = base * 0x2a16u; kp->r[5] = base * 0x3e59u;
            kp->m0 = m0; kp->mi = (m1 - m0) >> 6;
        }
        kp->nz0 = nz0; kp->ni = (nz1 - nz0) >> 6; kp->flag = hasm;
        him_k_noise(v, out, kp);
        COV(hasm ? 2 : 3); COV(c->colhi ? 4 : 5);
    }
    PT(1);
    if ((b0 | b1) > 0x3ff) {
        kp->inc0 = (int32_t)inc0; kp->dinc = dinc; kp->b0 = b0; kp->bi = (b1 - b0) >> 6; kp->flag = hasn;
        him_k_body(v, out, kp);
        COV(hasn ? 6 : 7);
        v->ph[0] = v->ph[0] + 64u * inc0 + 0x7e0u * (uint32_t)dinc;
    } else if (!hasn) {
        for (int n = 64; n < 128; n++) out[n] = 0;
        COV(8);
    } else COV(11);
    PT(2);
    kp->flag = c->crunch;
    him_k_drive(v, out, kp);
    COV(c->crunch ? 9 : 10);
    PT(3);
    v->env = env1 >> 8; v->nenv = nenv1 >> 8; v->swp = swp1 >> 16;
}

/* the C sample loops: the original's, sample for sample, on out[64..127] */
#ifndef HIM_ASM_NOISE
void him_k_noise(him_voice *v, int16_t *out, const him_kp *kp)
{
    const him_vcache *c = &v->c;
    int16_t *o = out + 64;
    if (kp->flag) {                                      /* the metal first, into o[] (the filter's input) */
        uint32_t a0 = v->ph[1], a1 = v->ph[2], a2 = v->ph[3], a3 = v->ph[4], a4 = v->ph[5], a5 = v->ph[6];
        const uint32_t r0 = kp->r[0], r1 = kp->r[1], r2 = kp->r[2], r3 = kp->r[3], r4 = kp->r[4], r5 = kp->r[5];
        const int32_t mi = kp->mi;
        int32_t me = kp->m0;
        for (int n = 0; n < 64; n++) {
            a0 += r0; a1 += r1; a2 += r2; a3 += r3; a4 += r4; a5 += r5;
            const int32_t neg = (int32_t)((a0 >> 31) + (a1 >> 31) + (a2 >> 31) + (a3 >> 31) + (a4 >> 31) + (a5 >> 31));
            me += mi;
            o[n] = (int16_t)(((3 - neg) * s16(me >> 8)) >> 4);
        }
        v->ph[1] = a0; v->ph[2] = a1; v->ph[3] = a2; v->ph[4] = a3; v->ph[5] = a4; v->ph[6] = a5;
    } else
        for (int n = 0; n < 64; n++) o[n] = 0;
    int32_t ne = kp->nz0, lp = v->lp, bp = v->bp;
    const int32_t ni = kp->ni, fc = c->fc, cmix = c->cmix, G = c->G;
    uint32_t x = v->seed;
    if (!c->colhi)
        for (int n = 0; n < 64; n++) {
            x ^= x << 13; x ^= x >> 17; x ^= x << 5;
            ne += ni;
            const int32_t nz = (s16((int32_t)(x >> 16)) * s16(ne >> 8)) >> 17;
            lp += (fc * s16(bp)) >> 14;
            const int32_t hp = clampi(o[n] + nz - lp - bp, -0x7fff, 0x7fff);
            bp += (fc * hp) >> 14;
            const int32_t y = (s16(lp) * (0x4000 - cmix) + s16(bp) * cmix) >> 14;
            o[n] = (int16_t)clampi((s16(y) * G) >> 8, -0x7fff, 0x7fff);
        }
    else
        for (int n = 0; n < 64; n++) {
            x ^= x << 13; x ^= x >> 17; x ^= x << 5;
            ne += ni;
            const int32_t nz = (s16((int32_t)(x >> 16)) * s16(ne >> 8)) >> 17;
            lp += (fc * s16(bp)) >> 14;
            const int32_t hp = clampi(o[n] + nz - lp - bp, -0x7fff, 0x7fff);
            bp += (fc * hp) >> 14;
            const int32_t y = (s16(bp) * (0x4000 - cmix) + hp * cmix) >> 14;
            o[n] = (int16_t)clampi((s16(y) * G) >> 8, -0x7fff, 0x7fff);
        }
    v->seed = x; v->lp = lp; v->bp = bp;
}
#endif

#ifndef HIM_ASM_BODY
void him_k_body(him_voice *v, int16_t *out, const him_kp *kp)
{
    int16_t *o = out + 64;
    uint32_t ph = v->ph[0], ii = (uint32_t)kp->inc0;
    int32_t be = kp->b0;
    const int32_t bi = kp->bi, g = v->c.g, dinc = kp->dinc, add = kp->flag;
    for (int n = 0; n < 64; n++) {
        ph += ii; ii += (uint32_t)dinc;
        const int32_t xs = s16((int32_t)(ph >> 16));
        int32_t y = (xs * s16(0x7fff - (xs < 0 ? -xs : xs))) >> 13;
        y = clampi((s16(y) * g) >> 8, -0x7fff, 0x7fff);
        be += bi;
        const int32_t w = (y * s16(be >> 8)) >> 16;
        o[n] = (int16_t)clampi((add ? o[n] : 0) + w, -0x7fff, 0x7fff);
    }
}

#endif

#ifndef HIM_ASM_DRIVE
static inline __attribute__((always_inline)) void drive(him_voice *v, int16_t *out, const int crunch)
{
    const him_vcache *c = &v->c;
    const int16_t *o = out + 64;
    const int32_t dgs = c->dgs, douts = c->douts, hold = c->hold, mask = c->mask;
    int32_t hn = v->hold_n, hv = v->hold_v;
    for (int n = 0; n < 64; n++) {                  /* out[2n], out[2n + 1] <- o[n]: never ahead of the reads */
        const int32_t x = clampi((o[n] * dgs) >> 7, -0x7fff, 0x7fff);
        const int32_t c = x * s16((x * x) >> 15);
        int32_t y;
        if (!crunch) y = clampi(x + (x >> 1) - (c >> 16), -0x7fff, 0x7fff);
        else {
            if (--hn <= 0) { hv = clampi(x + (x >> 1) - (c >> 16), -0x7fff, 0x7fff) & mask; hn = hold; }
            y = hv;
        }
        out[2 * n] = out[2 * n + 1] = (int16_t)((s16(y) * douts) >> 15);
    }
    v->hold_n = hn; v->hold_v = hv;
}

void him_k_drive(him_voice *v, int16_t *out, const him_kp *kp)
{
    if (kp->flag) drive(v, out, 1);
    else drive(v, out, 0);
}
#endif
