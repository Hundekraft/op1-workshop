#!/usr/bin/env python3
"""HIM host checks (tier 1, `make -C synth_sdk/harness check`):
  - voice: him_voice.c against him-data/him-voice-model.py (the original engine's voice, integer model), bit-exact on every
    sample: the four kits' keys, random numbers (signed extremes too), choke, number changes mid-note, pitch ratios;
  - world: test/world_test.c (deterministic physics: throws, bounces, collisions, no solid without a played hit);
  - mesh: him_mesh.c against him-data/him-meshes.json (the nine sample solids) and him-mesh-model.py (all 65);
  - screen: test/screen_test.c frames inside x 0..320, y 0..146 (the original's window, an owner-approved exception to the OLED margin) and rendered as PNG previews;
    with the SSD1963 panel (raster 400 rows, matrix 0x4B3) nothing outside 376 x 188, and no box kept from a record frame;
  - gen_data.py --check (the generated headers and SVG match their sources).
Host model, not emulator or OLED proof.

    python3 synth_sdk/plugins/him/check.py [OUT]      (OUT: previews, default synth_sdk/harness/build/him-check)

Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import importlib.util
import json
import random
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SDK = HERE.parents[1]
CC = ['cc', '-O1', '-g', '-Wall', '-Wextra', '-Wno-unused-parameter', '-Wno-unused-function',
      '-fsanitize=address,undefined', '-fno-sanitize-recover=undefined', '-DOP1_HOST', f'-I{SDK}', f'-I{HERE}']


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def build(tmp, src, name, extra=()):
    exe = Path(tmp) / name
    subprocess.run([*CC, *extra, str(src), '-o', str(exe)], check=True)
    return exe


def voice_cases():
    gd = load('gen_data', HERE / 'gen_data.py')
    r = random.Random(0x5137)
    cases = []
    for _, _, kit in gd.kits():
        for key, par in enumerate(kit):
            cases.append((key % 12, 127, 60, 0x10000, -1, par, -1, par, -1, 0))
    for i in range(160):
        def rnd():
            return [r.randint(-32768, 32767) if r.random() < 0.15 else (r.randint(-24320, 24832) if j == 0 else r.randint(0, 32767))
                    for j in range(8)]
        p, q = rnd(), rnd()
        vel = r.choice([1, 2, 40, 64, 100, 127, 0, 200, -3])
        ratio = r.choice([0x10000, 0x10000, 0, 0x8000, 0x20000, 0x12345, 0x4000, 0x7ffff, 0x9000])
        rs = r.choice([-1, -1, 2, 6, 12, 25])           # struck again mid-decay, or made again (velocity 0: init)
        cases.append((r.randint(0, 11), vel, r.randint(8, 50), ratio, r.choice([-1, -1, 3, 10]), p,
                      r.choice([-1, -1, 5, 20]), q, rs, r.choice([127, 64, 1, 0])))
    for p0 in (-24320, 24832, -32768, 32767):            # pitch extremes, full sweep, metal and noise
        cases.append((0, 127, 30, 0x10000, -1, [p0, 0, 32767, 32767, 32767, 32767, 0, 32767], -1, [0] * 8, -1, 0))
        cases.append((5, 127, 30, 0x7ffff, -1, [p0, 32767, 32767, 0, 0, 0x4000, 0, 0x4cce], -1, [0] * 8, -1, 0))
    for key, par in enumerate(gd.kits()[0][2][:12]):     # default kit: choked, then struck again; re-struck twice
        cases.append((key, 127, 40, 0x10000, 4, par, -1, par, 9, 90))
        cases.append((key, 80, 40, 0x10000, -1, par, -1, par, 3, 127))
    return cases


def check_voice(tmp):
    model = load('him_voice_model', HERE / 'him-data/him-voice-model.py')
    exe = build(tmp, HERE / 'test/voice_vec.c', 'voice_vec')
    cases = voice_cases()
    text = ''.join(' '.join(map(str, (i, v, b, ra, ch, *p, cg, *q, rs, rv))) + '\n'
                   for i, v, b, ra, ch, p, cg, q, rs, rv in cases)
    got = subprocess.run([str(exe)], input=text, capture_output=True, text=True, check=True).stdout.splitlines()
    want = []
    for idx, vel, blocks, ratio, choke_at, p, chg, q, rs_at, rs_vel in cases:
        v = model.Voice(idx)
        v.note(vel)
        for b in range(blocks):
            par = q if 0 <= chg <= b else p
            if b == rs_at:
                if rs_vel:
                    v.note(rs_vel)
                else:
                    v = model.Voice(idx)
            if rs_at >= 0 and not rs_vel and b == rs_at + 1:
                v.note(100)
            if b == choke_at:
                v.choke = 1
            want.append(' '.join(map(str, v.render(par, ratio))))
            want.append(f'F {int(v.finished())}')
    samples = sum(c[2] for c in cases) * 128
    if got != want:
        bad = next(i for i, (a, b) in enumerate(zip(got + [''] * len(want), want)) if a != b)
        print(f'voice: FAIL at output line {bad} of {len(want)}:\n  C:     {got[bad][:200] if bad < len(got) else "-"}\n'
              f'  model: {want[bad][:200]}')
        return False
    print(f'voice: bit-exact with him-voice-model.py on {len(cases)} cases, {samples} samples')
    return True


def main():
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else SDK / 'harness/build/him-check'
    out.mkdir(parents=True, exist_ok=True)
    ok = subprocess.run([sys.executable, str(HERE / 'gen_data.py'), '--check']).returncode == 0
    with tempfile.TemporaryDirectory(prefix='him-check-') as tmp:
        for f in CHECKS:
            ok = f(tmp, out) and ok if f.__code__.co_argcount == 2 else f(tmp) and ok
    print('him check: ' + ('all passed' if ok else 'FAILED'))
    return 0 if ok else 1


def check_world(tmp):
    exe = build(tmp, HERE / 'test/world_test.c', 'world_test')
    r = subprocess.run([str(exe)], capture_output=True, text=True)
    print(r.stdout.strip())
    if r.returncode:
        print('world: FAIL\n' + r.stderr.strip()[-600:])
    return r.returncode == 0


def check_boot(tmp):
    """HIM's boot-done rebind only in drum mode (him_boot.h, test/boot_test.c) and him_fw.c uses that rule"""
    exe = build(tmp, HERE / 'test/boot_test.c', 'boot_test')
    r = subprocess.run([str(exe)], capture_output=True, text=True)
    src = (HERE / 'him_fw.c').read_text()
    used = 'him_boot_rebind(CORE_SLOT, selected, *(volatile int32_t *)0xFF801038)' in src
    print(r.stdout.strip() + ('' if used else '\nboot: FAIL, him_fw.c does not use him_boot_rebind on the built mode'))
    if r.returncode: print('boot: FAIL\n' + r.stderr.strip()[-600:])
    return r.returncode == 0 and used


def check_knob(tmp):
    """him_knob.h (the T1 turn: ticks end to end per number, choke steps) against a model of R246's knob rule"""
    exe = build(tmp, HERE / 'test/knob_test.c', 'knob_test')
    r = subprocess.run([str(exe)], capture_output=True, text=True)
    print(r.stdout.strip())
    if r.returncode:
        print('knob: FAIL\n' + r.stderr.strip()[-600:])
    return r.returncode == 0


def check_mesh(tmp):
    model = load('him_mesh_model', HERE / 'him-data/him-mesh-model.py')
    exe = build(tmp, HERE / 'test/mesh_dump.c', 'mesh_dump')
    got = [json.loads(l) for l in subprocess.run([str(exe)], capture_output=True, text=True, check=True).stdout.splitlines()]
    samples = json.load(open(HERE / 'him-data/him-meshes.json'))['meshes']
    bad = [s for s in range(65) if got[s] != model.build(max(0, (s << 9) - 0x100) if s else 0)]
    for key, m in samples.items():
        mine = got[m['shape_index'] if 'shape_index' in m else int(key)]
        for f in ('verts', 'faces', 'normals', 'edges'):
            if f in m and mine[f] != m[f]:
                bad.append(f'sample {key} {f}')
    if bad:
        print(f'mesh: FAIL, differs from the model at {bad[:8]}')
        return False
    print(f'mesh: all 65 shapes equal him-mesh-model.py, the {len(samples)} samples equal him-meshes.json')
    return True


def check_screen(tmp, out):
    sys.path.insert(0, str(HERE / 'test'))
    import numpy as np
    import fbpng
    exe = build(tmp, HERE / 'test/screen_test.c', 'screen_test')
    raw = Path(tmp) / 'raw'
    raw.mkdir()
    zero = Path(tmp) / 'zero.raw'
    zero.write_bytes(bytes(400 * 256 * 2))
    r = subprocess.run([str(exe), str(raw), str(zero)], capture_output=True, text=True)
    if r.returncode:
        print('screen: FAIL\n' + r.stderr.strip()[-600:])
        return False
    names = [json.loads(l)['name'] for l in r.stdout.splitlines() if l.strip()]
    worst = 0
    for n in names:
        rgb = fbpng.from_raw(np.fromfile(raw / (n + '.raw'), np.uint16))
        ys = np.nonzero(rgb.any(-1).any(1))[0]
        low = int(ys.max()) if len(ys) else 0
        worst = max(worst, low)
        if low > 182:          # the original's extents: the OP-1 window, page y 146 (the renderer's clip; owner-approved exception)
            print(f'screen: FAIL, {n} has ink at panel row {low} (page y {low / 1.25:.1f} > 146)')
            return False
        from PIL import Image
        Image.fromarray(rgb).resize((1200, 600), Image.NEAREST).save(out / (n + '.png'))
    print(f'screen: {len(names)} frames, ink down to panel row {worst} (page y {worst / 1.25:.1f} <= 146, the original\'s window); previews in '
          f'{out} (host model, not emulator proof)')
    return True


def check_oracle(tmp):
    """the facet3d port against the original (test/f3_oracle.py; SKIP without HIM_REF_IMAGE)"""
    r = subprocess.run([sys.executable, str(HERE / 'test/f3_oracle.py')], capture_output=True, text=True)
    lines = [l for l in r.stdout.splitlines() if not (l.startswith('  case') and ': 0 pixels' in l)]
    print('\n'.join(lines) or r.stderr[-400:])
    return r.returncode == 0


COST_DEFS = []         # e.g. ['HIM_KERN_C']: the C sample loops instead of him_kern.S (comparison runs)


def check_cost(tmp):
    sys.path.insert(0, str(SDK / 'harness'))
    import re
    import tier2 as T  # noqa: E402
    found = T.setup_env()
    emu = T.os.environ.get('BCORE_EMU_CYCLES') or T.find_up('build/bcore-cycles-bin/emu')
    if 'toolchain' not in found or not emu:
        print('cost: SKIP (needs the Blackfin toolchain and a bcore emu with --cycles)')
        return True
    t = T.tools(found['toolchain'])
    env = dict(T.os.environ, PATH=t['path'])
    work = Path(tmp)
    objs = []
    for src in [HERE / 'test/cost_guest.c', *([] if 'HIM_KERN_C' in COST_DEFS else [HERE / 'him_kern.S'])]:
        objs.append(str(work / (src.stem + '.o')))
        T.sh([t['gcc'], '-O2', '-mcpu=bf524', '-ffreestanding', '-fno-builtin', '-nostdlib', '-fno-common',
              '-fno-tree-loop-distribute-patterns', *[f'-D{d}' for d in COST_DEFS], f'-I{HERE}', f'-I{SDK}', '-c',
              str(src), '-o', objs[-1]], env=env)
    T.sh([t['as'], '-mcpu=bf524', str(SDK / 'harness/tier2/crt.S'), '-o', str(work / 'crt.o')])
    libgcc = T.sh([t['gcc'], '-mcpu=bf524', '-print-libgcc-file-name'], env=env).strip()
    elf = work / 'guest.elf'
    T.sh([t['ld'], '--no-warn-rwx-segments', '--defsym=T2_STAGE=0x02000000', '-T', str(SDK / 'harness/tier2/guest.ld'),
          str(work / 'crt.o'), *objs, libgcc, '-o', str(elf)])
    r = subprocess.run([str(emu), '--fastmem', '--count-packets', '--cycles', str(elf)], capture_output=True, text=True,
                       timeout=600)
    line = next((l for l in r.stdout.splitlines() if l.startswith('T2')), '')
    v = {k: int(x, 16) for k, x in re.findall(r'(\w+)=0x([0-9a-f]+)', line)}
    if 'heavy' not in v:
        print(f'cost: FAIL (no result, exit {r.returncode}): {r.stderr.strip()[-300:]}')
        return False
    blk = 580525
    print(f'cost (bcore packets, lower bound): twelve voices a block, heaviest {v["heavy"]} '
          f'({100 * v["heavy"] / blk:.1f} % of a block, mean {v["heavyavg"]}); default kit keys 0-11 {v["kit"]} '
          f'(mean {v["kitavg"]}); crunch {v["crunch"]}; the original declares 113165. One world step, full box '
          f'({v["debris"]} debris): {v["step"]} (x 240 a second = {v["step"] * 240 / 4e6:.2f} % of the CPU, main loop). '
          f'Page frame (GUI thread): idle (box and scope) {v["fidle"]}, busiest groove frame {v["fworst"]}, preview '
          f'{v["fprev"]} (at 30 frames a second: {v["fworst"] * 30 / 4e6:.1f} % of the CPU)')
    return True


CHECKS = [check_voice, check_world, check_boot, check_knob, check_mesh, check_screen, check_cost, check_oracle]

if __name__ == '__main__':
    sys.exit(main())
