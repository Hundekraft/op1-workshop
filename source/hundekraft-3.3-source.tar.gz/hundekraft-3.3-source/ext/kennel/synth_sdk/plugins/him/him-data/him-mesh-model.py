# Python model of the the original drum engine 0.1.9 solid builder (image 0x12a4..0x18c4), written from the disassembly for the
# kennel port (used with the author's permission, per the owner 2026-11-09). Run: python3 him-mesh-model.py out.json
import json, sys
def sdiv(a,b): q=abs(a)//abs(b); return q if (a<0)==(b<0) else -q
def isqrt(n):
    # the binary's bitwise integer square root (floor)
    import math; return math.isqrt(n) if n>0 else 0
def smooth(t): return (0x800 + ((t*t>>12)*(0x1800-t))*2)>>12   # 3t^2-2t^3, Q12
DU=(0,1,1,0); DV=(0,0,1,1)          # image 0x5070, 0x5060
CB=(-1,1,1,-1); CC=(-1,-1,1,1)      # image 0x5050, 0x5040
def build(shape_knob):
    s=(max(shape_knob,0)+0x100)>>9
    keys=[]; verts=[]; faces=[]
    def vid(key,v):
        if key in keys: return keys.index(key)
        keys.append(key); verts.append(v); return len(keys)-1
    if s<=32:
        b=smooth(s<<7)
        for a in range(3):
            ax1=(a+1)%3; ax2=(a+2)%3
            for side in (-3,3):
                for i in range(3):
                    for j in range(3):
                        f=[]
                        for k in range(4):
                            p=[0,0,0]; p[a]=side; p[ax1]=(DU[k]+i)*2-3; p[ax2]=(DV[k]+j)*2-3
                            g=[sdiv(x<<12,3) for x in p]
                            L=isqrt(sum(x*x for x in g))
                            n=[sdiv(x<<12,L) for x in g]
                            c=[(x*0xccd+0x800)>>12 for x in g]
                            v=[(((c[m]-n[m])*b+0x800)>>12)+n[m] for m in range(3)]
                            f.append(vid(tuple(p),v))
                        faces.append(f)
    else:
        b=smooth((s-32)<<7)
        k_in=(((-0x8cd*b)+0x800)>>12)+0xccd; k_out=(((-0xcd*b)+0x800)>>12)+0xccd
        for a in range(3):
            ax1=(a+1)%3; ax2=(a+2)%3
            for side in (-1,1):
                idx=[];flag=[]
                for k in range(4):
                    p=[0,0,0]; p[a]=side; p[ax1]=CB[k]; p[ax2]=CC[k]
                    out=p[0]*p[1]*p[2]>0; flag.append(out)
                    kk=k_out if out else k_in
                    idx.append(vid(tuple(p),[x*kk for x in p]))
                u=0 if flag[0] else 1
                faces.append([idx[u],idx[(u+1)&3],idx[(u+2)&3]])
                faces.append([idx[u],idx[(u+2)&3],idx[(u+3)&3]])
    # normals (Newell), orientation fix, Q12 unit normals
    normals=[]
    for f in faces:
        n=[0,0,0]; cs=[0,0,0]
        for i in range(len(f)):
            p=verts[f[i]]; q=verts[f[(i+1)%len(f)]]
            n[0]+=(p[1]-q[1])*(p[2]+q[2]); n[1]+=(p[2]-q[2])*(p[0]+q[0]); n[2]+=(p[0]-q[0])*(p[1]+q[1])
            for m in range(3): cs[m]+=p[m]
        n=[x>>12 for x in n]
        if (cs[0]>>2)*n[0]+(cs[1]>>2)*n[1]+(cs[2]>>2)*n[2]<0:
            f.reverse(); n=[-x for x in n]
        L=isqrt(sum(x*x for x in n))
        normals.append([sdiv(x<<12,L) if L else 0 for x in n])
    edges=[]
    for fi,f in enumerate(faces):
        for i in range(len(f)):
            a,bb=f[i],f[(i+1)%len(f)]
            hit=None
            for e in edges:
                if (e['a'],e['b']) in ((a,bb),(bb,a)): hit=e;break
            if hit:
                hit['f2']=fi; n1=normals[hit['f1']]; n2=normals[fi]
                dot=(n1[0]*n2[0]+n1[1]*n2[1]+n1[2]*n2[2])>>12
                w=(0xffb-dot)*0x100
                hit['w']=0 if w< -0xf2 else (sdiv(w,0xf3) if w<0xf3f3 else 0x100)
            elif len(edges)<0x6c:
                edges.append(dict(a=a,b=bb,f1=fi,f2=fi,w=0x100))
    return dict(shape_index=s,verts=verts,faces=faces,normals=normals,edges=[[e['a'],e['b'],e['f1'],e['f2'],e['w']] for e in edges])
if __name__=='__main__':
    out={}
    for s in (0,8,16,24,32,40,48,56,64):
        m=build(max(0,(s<<9)-0x100) if s else 0); out[str(s)]=m
        print(s,m['shape_index'],len(m['verts']),len(m['faces']),len(m['edges']),'visible edges',sum(1 for e in m['edges'] if e[4]>0))
    json.dump(out,open(sys.argv[1],'w') if len(sys.argv)>1 else sys.stdout)
