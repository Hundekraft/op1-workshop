/* HIM's 3D drawing: the original 3D renderer (0.2.5), ported with the author's permission (per the owner,
 * 2026-11-09) as exact integer code: the same API, maths, rasteriser, ink modes, dark-gap pass, fills, 5x7 font and
 * pixel output as the original (OP1-Emulator docs/ports/him-spec.md section 7). test/f3_oracle.py proves the port
 * pixel-identical with the original image on bcore. Units: model / view points as the caller's; page positions Q8
 * units of the 320 x 160 page; widths, dashes Q8 panel px; colours F3_RGB(0xRRGGBB) = 0x01000000 | rgb.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HIM_F3_H
#define HIM_F3_H
#include <stdint.h>

#define F3_RGB(rgb) (0x01000000u | (uint32_t)(rgb))
/* where f3_begin gets the frame: the RGB565 page pixels, stored turned (pixel (x, y) is
 * frame[256 * (rows - 1 - x) + y]), and the panel's long side in *rows (the original host's page-pixels call) */
extern uint16_t *(*f3_page_pixels)(int *rows);

void f3_begin(int yaw, int pitch, int scale, int cx, int cy, unsigned colour, int gap);
void f3_end(void);
void f3_rotation(int out[9], int a, int b, int c);
void f3_mul(int out[9], const int a[9], const int b[9]);
void f3_apply(int out[3], const int m[9], const int in[3], const int add[3]);
int f3_sphere(const int c[3], int r, int outline);
void f3_sphere_fill(int i);
void f3_line(const int (*p)[3], int n, int closed, int style, int dash, int near);
void f3_circle(const int m[9], const int c[3], int r, int n, int style, int dash, int near);
void f3_ring_ticks(const int m[9], const int c[3], int r, int n, int major_every, int len);
int f3_glyph(const int p[3], int kind);
int f3_project(const int p[3], int *x, int *y);
int f3_drawn(int *hidden);
void f3_ink(unsigned colour, int alpha_flags);
void f3_to_view(const int p[3], int out[3]);
void f3_to_page(const int v[3], int *x, int *y);
void f3_fill(const int (*xy)[2], int n);
void f3_seg(const int (*xy)[2], int n, int closed, int style, int on, int off);
void f3_dot(int x, int y, int size);
int f3_text(int x, int y, int px, const char *s);
int f3_text_width(int px, int nchars);
void f3_lines(const int (*seg)[4], int n, int style);
void f3_rect(int x0, int y0, int x1, int y1, int on, int off, int thick);
void f3_wave(const short *v, int n, int x, int y, int w, int h);
void f3_band(const short *lo, const short *hi, int n, int x, int y, int w, int h);
void f3_ellipse(int cx, int cy, int rx, int ry, int thick, const int *clip);
void f3_fill_alpha(const int (*xy)[2], int n, int alpha);
/* the renderer 0.2.6's additions (him_f3_trace.c; KHORUS's page): a 2D line at any width (Q8 panel px, 256 at least),
 * no dark gap; many traces (n points each over x0 .. x1, Q8 page units) a column at a time, each as wide as its width,
 * the brightest channel kept where they meet, the frame written and never read */
void f3_seg_width(const int (*xy)[2], int n, int closed, int width, int on, int off);
void f3_traces(const int *const *tr, int n, int x0, int x1, const unsigned *colour, const int *width, int count);

#endif
