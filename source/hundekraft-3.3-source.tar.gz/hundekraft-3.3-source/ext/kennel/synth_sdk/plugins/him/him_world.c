/* HIM's box: the original drum engine's physics (ported with the author's permission per the owner, 2026-11-09;
 * OP1-Emulator docs/ports/him-spec.md 5.1-5.2, 6.1-6.7, with the original's integer maths). Main loop and host only: divides are fine here (never the audio thread).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "him_world.h"
#include "him_data.h"
#include "him_voice.h"

static inline int32_t wabs(int32_t x) { return x < 0 ? -x : x; }
static inline int32_t wmin(int32_t a, int32_t b) { return a < b ? a : b; }
static inline int32_t wmax(int32_t a, int32_t b) { return a > b ? a : b; }
static inline int32_t wclamp(int32_t x, int32_t a, int32_t b) { return x < a ? a : x > b ? b : x; }
static inline int32_t wk(const int16_t *k, int i) { return k[i] > 0 ? k[i] : 0; }
static inline int32_t mv(int32_t v) { return (v * 0x1111) >> 20; }   /* v / 240 (the original's) */

void him_sincos(int32_t a, int32_t *s, int32_t *c)
{
    const int q = (a >> 10) & 3, i = a & 1023;
    const int32_t t = HIM_SIN[i], u = HIM_SIN[1024 - i];
    switch (q) {
    case 0: *s = t; *c = u; break;
    case 1: *s = u; *c = -t; break;
    case 2: *s = -t; *c = -u; break;
    default: *s = -u; *c = t; break;
    }
}

int32_t him_isqrt(uint32_t n)
{
    uint32_t r = 0, bit = 1u << 30;
    while (bit > n) bit >>= 2;
    while (bit) {
        if (n >= r + bit) { n -= r + bit; r = (r >> 1) + bit; } else r >>= 1;
        bit >>= 2;
    }
    return (int32_t)r;
}

static uint32_t rnd(him_world *w)
{
    uint32_t x = w->rng;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    return w->rng = x;
}

int32_t him_radius(const int16_t *knobs)
{
    const int32_t p0 = wclamp(knobs[0], -0x5f00, 0x6100);
    return (0x6100 - p0) / 24 + 0x385;
}

int32_t him_decay_ms(const int16_t *knobs) { return (int32_t)((him_exp2q(wk(knobs, 1)) * 15u) >> 16); }

int32_t him_lifetime(const int16_t *knobs)
{
    const int32_t n = wk(knobs, 3) >> 3;
    const int32_t t = (((0x1000 - n) * (0x1000 - n)) + 0x800) >> 12;
    const int32_t a = ((t * t + 0x800) >> 12) * 3 + 0x1000;
    const int32_t b = 0x1000000 / (0x1000 - ((n * 0xB33 + 0x800) >> 12));
    const int32_t ms = wclamp(him_decay_ms(knobs) * 0x1556 / wmin(a, b), 40, 4500);
    return ms * 240 / 1000;
}

void him_throw(him_body *b, const int16_t *knobs, int32_t x, int32_t z, int32_t angle)
{
    const int32_t r = him_radius(knobs);
    const int32_t h = wmin(((wk(knobs, 2) * 0x28CD) >> 15) + 0x400 + r, 0x3800 - r);
    int32_t s, c;
    him_sincos(angle, &s, &c);
    const int32_t v = (h - r) * 0xC800 / wmax(c, 0x800);
    b->vx = (s * v + 0x800) >> 12;
    b->vy = -((v * c + 0x800) >> 12);
    const int32_t d = wk(knobs, 1) >> 3;
    b->e = (((((((d * 0x266 + 0x800) >> 12) + 0xD9A) * d + 0x800) >> 12) * 0xE66 + 0x800) >> 12) + 0xA4;
    b->x = x; b->y = h; b->z = z; b->r = r;
    b->x0 = x; b->h0 = h; b->landed = 0; b->roll = b->roll_rate = 0;
    for (int i = 0; i < 8; i++) b->knobs[i] = knobs[i];
}

static void ring_add(him_world *w, const him_body *b, int32_t wy, int32_t vy)
{
    const int32_t a = wabs(vy);
    him_ring *g;
    if (w->n_rings < HIM_RINGS) g = &w->ring[w->n_rings++];
    else { g = &w->ring[0]; for (int i = 1; i < HIM_RINGS; i++) if (w->ring[i].age > g->age) g = &w->ring[i]; }
    g->x = b->x; g->wy = wy; g->z = b->z; g->r = b->r; g->age = 0;
    g->rmax = a < 0x14000 ? (((a / 20) * 0xCCD + 0x800) >> 12) + 0x666 : 0x1333;
}

static void spawn_debris(him_world *w, const him_body *b)
{
    int n = (wk(b->knobs, 3) * 15) >> 14;
    const int32_t hr = b->r / 2;
    while (n-- > 0 && w->n_debris < HIM_DEBRIS) {
        him_debris *d = &w->debris[w->n_debris++];
        d->x = b->land_x + (int32_t)((((rnd(w) >> 16) * (uint32_t)hr) * 2) >> 16) - hr;
        d->y = 0xCD; d->z = b->z;
        d->vx = (int32_t)(((rnd(w) >> 16) * 3) >> 3) - 0x3000;
        d->vy = (int32_t)(((rnd(w) >> 16) * 0x57FF) >> 16) + 0x1CCD;
        d->vz = (int32_t)(((rnd(w) >> 16) * 0x3800) >> 16) - 0x1C00;
        d->age = 0;
        d->life = (int32_t)(((rnd(w) >> 16) * 3) >> 11) + 0x78;
    }
}

void him_body_step(him_world *w, him_body *b)
{
    const int32_t r = b->r, e = b->e;
    b->vy -= 0x1BC;
    b->x += mv(b->vx); b->y += mv(b->vy);
    if (b->y < r) {
        b->y = r;
        if (b->vy < 0) {
            if (!b->landed) {
                b->landed = 1; b->land_x = b->x;
                if (w) spawn_debris(w, b);
            }
            if (w && b->vy < -0x3000) ring_add(w, b, 0, b->vy);
            b->vy = e * b->vy + 0x800 < -0x7FF000 ? -((e * b->vy + 0x800) >> 12) : 0;
            b->vx = (b->vx * 0xEB8 + 0x800) >> 12;
        }
        b->roll_rate = b->vx * -0x28C / r;
    }
    if (b->y + r > HIM_CEIL) {
        b->y = HIM_CEIL - r;
        if (b->vy > 0) {
            if (w && b->vy > 0x3000) ring_add(w, b, HIM_CEIL, b->vy);
            b->vy = -((b->vy * e + 0x800) >> 12);
        }
    }
    if (b->x < r - HIM_WALL) {
        b->x = r - HIM_WALL; b->vx = (wabs(b->vx) * e + 0x800) >> 12;
    }
    if (b->x > HIM_WALL - r) {
        b->x = HIM_WALL - r; b->vx = -((wabs(b->vx) * e + 0x800) >> 12);
    }
}

static void start_dying(him_body *b)
{
    if (b->dying) return;
    b->dying = 1; b->death_age = b->age; b->death_alpha = b->alpha;
    b->limit = wmin(b->limit, b->age + 36);
}

void him_world_init(him_world *w)
{
    uint8_t *p = (uint8_t *)w;
    for (unsigned i = 0; i < sizeof *w; i++) p[i] = 0;
    w->rng = 0x2545F491u;
}

void him_world_hit(him_world *w, const int16_t *knobs, int key)
{
    him_body *b = 0;
    for (int i = 0; i < HIM_BODIES && !b; i++) if (!w->body[i].active) b = &w->body[i];
    if (!b) { b = &w->body[0]; for (int i = 1; i < HIM_BODIES; i++) if (w->body[i].seq < b->seq) b = &w->body[i]; }
    const int group = him_group(knobs);
    const int32_t lane = HIM_LANE[rnd(w) >> 30];
    const int32_t angle = (int32_t)(rnd(w) >> 22) - 512;
    const int32_t yaw = (int32_t)(rnd(w) >> 20);
    for (int i = 0; i < 8; i++) b->knobs[i] = knobs[i];
    b->active = 0;                                   /* not a choke candidate of itself */
    him_throw(b, knobs, him_key_x(key), lane, angle);
    if (group)
        for (int i = 0; i < HIM_BODIES; i++) {
            him_body *o = &w->body[i];
            if (o == b || !o->active || o->group != group || o->key == key || o->choked) continue;
            o->choked = 1; start_dying(o);
            if (w->n_links < HIM_LINKS) {
                him_link *l = &w->link[w->n_links++];
                l->x0 = b->x0; l->h0 = b->h0; l->z0 = b->z; l->x = o->x; l->y = o->y; l->z = o->z; l->age = 0;
            }
        }
    b->active = 1; b->key = key; b->group = group; b->yaw = yaw; b->roll = 0; b->roll_rate = 0;
    b->spin = ((wk(knobs, 7) * 0xCBC) >> 15) + 0xC4;
    b->age = 0; b->limit = b->length = him_lifetime(knobs); b->alpha = 0x100; b->seq = ++w->counter;
    b->choked = 0; b->dying = 0; b->death_age = b->death_alpha = 0;
    int live = 0;
    for (int i = 0; i < HIM_BODIES; i++) live += w->body[i].active && !w->body[i].dying;
    while (live > 6) {
        him_body *o = 0;
        for (int i = 0; i < HIM_BODIES; i++) {
            him_body *c = &w->body[i];
            if (c->active && !c->dying && (!o || c->seq < o->seq)) o = c;
        }
        start_dying(o); live--;
    }
}

static void collide(him_world *w, him_body *a, him_body *b)
{
    const int32_t dx = b->x - a->x, dy = b->y - a->y, R = a->r + b->r;
    if (wabs(dx) >= R || wabs(dy) >= R) return;
    const int32_t d2 = dx * dx + dy * dy;
    if (d2 <= 0 || d2 >= R * R) return;
    const int32_t d = him_isqrt((uint32_t)d2), nx = dx * 4096 / d, ny = dy * 4096 / d, push = (R - d) / 2;
    const int32_t px = (nx * push + 0x800) >> 12, py = (ny * push + 0x800) >> 12;
    a->x -= px; a->y -= py; b->x += px; b->y += py;
    const int32_t vn = (((b->vx - a->vx) * nx + 0x800) >> 12) + (((b->vy - a->vy) * ny + 0x800) >> 12);
    if (vn < 0) {
        const int32_t J = -((((wmin(a->e, b->e) + 0x1000) * vn + 0x800) >> 12) / 2);
        const int32_t jx = (J * nx + 0x800) >> 12, jy = (J * ny + 0x800) >> 12;
        a->vx -= jx; a->vy -= jy; b->vx += jx; b->vy += jy;
        if (vn < -0x1000) {
            if (w->n_sparks < HIM_SPARKS) {
                him_spark *s = &w->spark[w->n_sparks++];
                s->x = a->x + ((nx * a->r + 0x800) >> 12); s->y = a->y + ((ny * a->r + 0x800) >> 12); s->z = a->z;
                s->nx = nx; s->ny = ny; s->age = 0;
            }
        }
    }
}

void him_world_step(him_world *w)
{
    w->steps++;
    for (int i = 0; i < HIM_BODIES; i++) {
        him_body *b = &w->body[i];
        if (!b->active) continue;
        b->age++;                                       /* the original (0x29CE): the age first, then the step */
        him_body_step(w, b);
        b->roll += (b->roll_rate * 0x1111) >> 20;       /* x / 240 rounded down, as the original (0x29E2) */
        b->yaw += (b->spin * 0x1111) >> 20;
        const int32_t rem = b->length - b->age;
        const int32_t T = 35 * b->length < 3000 ? 29 : 35 * b->length / 100;
        int32_t al = rem <= 0 ? 0 : rem < T ? rem * 256 / T : 256;
        if (b->dying) al = wmin(al, wmax(0, (b->death_age - b->age + 36) * b->death_alpha / 36));
        b->alpha = al;
        if (b->age >= b->limit) b->active = 0;
    }
    for (int i = 0; i < HIM_BODIES; i++)
        for (int j = i + 1; j < HIM_BODIES; j++) {
            him_body *a = &w->body[i], *b = &w->body[j];
            if (a->active && b->active && a->z == b->z) collide(w, a, b);
        }
    for (int i = 0; i < w->n_debris;) {
        him_debris *d = &w->debris[i];
        d->age++;
        d->vy -= 0xF4;
        d->x += mv(d->vx); d->y += mv(d->vy); d->z += mv(d->vz);
        if (d->y < 0) { d->y = 0; d->vy = -((d->vy < 0 ? d->vy + 3 : d->vy) >> 2); d->vx /= 2; d->vz /= 2; }
        if (d->y > HIM_CEIL) { d->y = HIM_CEIL; d->vy = -wabs(d->vy) / 4; }
        if (d->x < -HIM_WALL) { d->x = -HIM_WALL; d->vx = -2 * d->vx / 5; }
        if (d->x > HIM_WALL) { d->x = HIM_WALL; d->vx = -2 * d->vx / 5; }
        if (d->z < -HIM_DEPTH) { d->z = -HIM_DEPTH; d->vz = -2 * d->vz / 5; }
        if (d->z > HIM_DEPTH) { d->z = HIM_DEPTH; d->vz = -2 * d->vz / 5; }
        if (d->age > d->life) *d = w->debris[--w->n_debris]; else i++;
    }
    for (int i = 0; i < w->n_rings;) if (++w->ring[i].age >= 120) w->ring[i] = w->ring[--w->n_rings]; else i++;
    for (int i = 0; i < w->n_sparks;) if (++w->spark[i].age >= 72) w->spark[i] = w->spark[--w->n_sparks]; else i++;
    for (int i = 0; i < w->n_links;) if (++w->link[i].age >= 72) w->link[i] = w->link[--w->n_links]; else i++;
}

int him_world_advance(him_world *w, uint32_t cycles)
{
    if (cycles > 40000000u) cycles = 40000000u;
    w->acc += cycles;
    int n = 0;
    while (w->acc >= HIM_STEP_CYCLES && n < 24) { w->acc -= HIM_STEP_CYCLES; him_world_step(w); n++; }
    if (w->acc >= HIM_STEP_CYCLES) w->acc = 0;
    return n;
}

int him_world_busy(const him_world *w)
{
    for (int i = 0; i < HIM_BODIES; i++) if (w->body[i].active) return 1;
    return w->n_debris || w->n_rings || w->n_sparks || w->n_links;
}

int him_hit_drain(him_hit_ring *q, him_world *w, uint32_t now, uint32_t max_age)
{
    const uint32_t wr = q->w;
    if (wr - q->r > HIM_HITS) q->r = wr - HIM_HITS;
    int n = 0;
    while (q->r != wr) {
        const him_hit *h = &q->h[q->r & (HIM_HITS - 1)];
        if (now - h->stamp <= max_age) { him_world_hit(w, h->knobs, h->key); n++; }
        q->r++;
    }
    return n;
}
