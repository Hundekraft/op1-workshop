/* HIM's box: the original drum engine's physics (ported with the author's permission per the owner, 2026-11-09;
 * spec: OP1-Emulator docs/ports/him-spec.md sections 5 and 6). Pure integer code, no
 * firmware calls: the main loop steps it (him_fw.c), the page draws a copy (him_page.c), the host tests drive it.
 * Units: Q12 model units (4096 = 1 u), y up, floor y 0; velocities Q12 u per second; one step = 1/240 s.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HIM_WORLD_H
#define HIM_WORLD_H
#include <stdint.h>

#define HIM_BODIES   8
#define HIM_DEBRIS   97
#define HIM_RINGS    8
#define HIM_SPARKS   16
#define HIM_LINKS    4
#define HIM_CEIL     0x38CD          /* 3.55 u */
#define HIM_WALL     0x499A          /* +-4.60 u */
#define HIM_DEPTH    0x199A          /* +-1.60 u */
#define HIM_STEP_CYCLES 1666666u     /* 240 steps a second at 400 MHz */

typedef struct {
    int32_t active, key, group, landed, choked, dying;
    int16_t knobs[8];
    int32_t x, y, z, r, vx, vy, e;
    int32_t x0, h0, land_x, yaw, roll, roll_rate, spin;
    int32_t age, limit, length, death_age, death_alpha, alpha;
    int32_t bbox[4];                 /* projected bounding box (page Q8), written by the page's copy */
    uint32_t seq;
} him_body;
typedef struct { int32_t x, y, z, vx, vy, vz, age, life; } him_debris;
typedef struct { int32_t x, wy, z, r, rmax, age; } him_ring;
typedef struct { int32_t x, y, z, nx, ny, age; } him_spark;
typedef struct { int32_t x0, h0, z0, x, y, z, age; } him_link;

typedef struct {
    him_body body[HIM_BODIES];
    him_debris debris[HIM_DEBRIS];
    him_ring ring[HIM_RINGS];
    him_spark spark[HIM_SPARKS];
    him_link link[HIM_LINKS];
    int32_t n_debris, n_rings, n_sparks, n_links;
    uint32_t rng, counter;
    uint32_t steps;                  /* steps run since the start */
    uint32_t acc;                    /* cycles not yet stepped */
} him_world;

void him_world_init(him_world *w);
/* a played hit: throw the key's solid (the original's page hit handling, section 5.1) */
void him_world_hit(him_world *w, const int16_t *knobs, int key);
/* run fixed 240 Hz steps for `cycles` CPU cycles (capped at 0.1 s, 24 steps), as the original's page clock */
int him_world_advance(him_world *w, uint32_t cycles);
void him_world_step(him_world *w);
/* any solid, debris or effect still alive */
int him_world_busy(const him_world *w);

/* the original's throw (6.3) and one solid step (6.4); w = 0: no effects (the preview's dry run) */
void him_throw(him_body *b, const int16_t *knobs, int32_t x, int32_t z, int32_t angle);
void him_body_step(him_world *w, him_body *b);
int32_t him_radius(const int16_t *knobs);
int32_t him_decay_ms(const int16_t *knobs);
int32_t him_lifetime(const int16_t *knobs);     /* in steps */
void him_sincos(int32_t a, int32_t *s, int32_t *c); /* 4096 a turn, any; x 4096 */
int32_t him_isqrt(uint32_t n);
static inline int32_t him_key_x(int key) { return key * 0x5B4 - 0x419A; }

/* Hand-off between threads, lock-free single producer / single consumer (him_fw.c) */
typedef struct { int16_t knobs[8]; int32_t key; uint32_t stamp; } him_hit;
#define HIM_HITS 16
typedef struct { volatile uint32_t w; uint32_t r; him_hit h[HIM_HITS]; } him_hit_ring;
static inline void him_hit_push(him_hit_ring *q, const int16_t *knobs, int key, uint32_t stamp)
{
    him_hit *h = &q->h[q->w & (HIM_HITS - 1)];
    for (int i = 0; i < 8; i++) h->knobs[i] = knobs[i];
    h->key = key; h->stamp = stamp;
    q->w = q->w + 1;
}
/* drain into the world: more than 16 pending skips to the newest 16; older than max_age cycles is dropped */
int him_hit_drain(him_hit_ring *q, him_world *w, uint32_t now, uint32_t max_age);

#endif
