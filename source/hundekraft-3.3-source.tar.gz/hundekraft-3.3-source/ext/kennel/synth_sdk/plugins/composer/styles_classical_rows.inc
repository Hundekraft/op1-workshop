    /* classical group, 2026-11-09 (canon: the lead again an octave lower 4 bars later) */
    STYLE_P("canon", 66, 2, M_ION, 50, cn, "x.x.x.x.x.x.x.x.", ARP_UPDOWN, 74, 38, 62, 90, 85, 60, 95, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, "AABACA", 0, 4, CM_NO(CM_CHORDS), FIG_ARP, 0, 0),
    STYLE("baroque", 100, 9, M_HMIN, 50, bq, "xxxxxxxxxxxxxxxx", ARP_UPDOWN, 74, 33, 62, 70, 80, 60, 75, 0, 0, 0, 2, 20, 10, 0, 40, 0, 0, "AABBCA", 0),
    STYLE_P("classical", 120, 0, M_ION, 50, cl, "xxxxxxxxxxxxxxxx", ARP_ALBERTI, 76, 36, 62, 85, 70, 70, 80, 0, 0, 0, 1, 10, 20, 0, 10, 0, 0, "AABACA", 0, 0, 0, FIG_ALBERTI, 0, 0),
    STYLE_P("romantic", 72, 4, M_HMIN, 50, rm, "x.x.x.x.x.x.x.x.", ARP_UP, 74, 31, 60, 100, 95, 70, 100, 3, 0, 10, 4, 20, 20, 10, 15, 0, 1, "ABABCB", 0, 0, 0, FIG_TREMOLO, 0, 0),
    STYLE_P("chorale", 76, 7, M_ION, 50, cr, "x...x...x...x...", ARP_UP, 72, 36, 60, 95, 95, 80, 98, 0, 0, 0, 0, 0, 10, 0, 30, 0, 0, "AABA", 0, 0, CM_NO(CM_ARP), FIG_ARP, 0, 0),
