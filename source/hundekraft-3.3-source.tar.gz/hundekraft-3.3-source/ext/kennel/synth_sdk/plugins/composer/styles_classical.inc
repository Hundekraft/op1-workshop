/* composer styles, classical group (arrays), 2026-11-09. Progressions are the public-domain grounds and cadence
 * formulas the chord plugin also offers (Pachelbel's canon, passamezzo moderno, the circle of fifths, the lament, the
 * Neapolitan); the cells are style rules (rhythms), no melodies are copied.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */

/* canon: Pachelbel's ground (a chord each half bar, four bars round), the lead in quarters and 8ths, and the lead again
 * an octave lower four bars later (the style's canon field): a two-voice canon over the ground */
static const cm_chord cn1[] = {{0, Q_MAJ, 2}, {7, Q_MAJ, 2}, {9, Q_MIN, 2}, {4, Q_MIN, 2}, {5, Q_MAJ, 2}, {0, Q_MAJ, 2}, {5, Q_MAJ, 2}, {7, Q_MAJ, 2}, END};
static const cm_chord cn2[] = {{0, Q_MAJ, 2}, {7, Q_MAJ, 2}, {9, Q_MIN, 2}, {4, Q_MIN, 2}, {5, Q_MAJ, 2}, {0, Q_MAJ, 2}, {2, Q_MIN, 2}, {7, Q_MAJ, 2}, END};
static const cm_chord cn3[] = {{0, Q_MAJ, 2}, {5, Q_MAJ, 2}, {0, Q_MAJ, 2}, {7, Q_MAJ, 2}, {0, Q_MAJ, 2}, {5, Q_MAJ, 2}, {7, Q_MAJ, 2}, {0, Q_MAJ, 2}, END};
static const cm_chord *const cn_prog[] = {cn1, cn2, cn3};
static const uint8_t cn_form[] = {F_PERIOD, F_SENTENCE};
static const char *const cn_lead[] = {
    "x---x---x---x---" "x-x-x-x-x---x---",
    "x-x-x-x-x-x-x-x-" "x---x---x-------",
    "x---x-x-x---x---" "x-x-x---x-------"};
static const char *const cn_bass[] = {"x---x---x---x---", "x-------x-------"};
static const char *const cn_chords[] = {"x-------x-------", "x---x---x---x---"};

/* baroque: harmonic minor, a falling circle of fifths, the lament, suspensions before the cadence; 16th figures that
 * sequence, a walking 8th bass, continuo chords, broken-chord arps */
static const cm_chord bq1[] = {{0, Q_MIN, 4}, {5, Q_MIN, 4}, {10, Q_MAJ, 4}, {3, Q_MAJ, 4}, {8, Q_MAJ, 4}, {2, Q_DIM, 4}, {7, Q_MAJ, 4}, {0, Q_MIN, 4}, END};
static const cm_chord bq2[] = {{0, Q_MIN, 4}, {10, Q_MAJ, 4}, {8, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord bq3[] = {{0, Q_MIN, 4}, {5, Q_MIN, 4}, {7, Q_SUS4, 2}, {7, Q_MAJ, 2}, {0, Q_MIN, 4}, END};
static const cm_chord bq4[] = {{0, Q_MIN, 2}, {7, Q_DOM7, 2}, {0, Q_MIN, 2}, {5, Q_MIN, 2}, {2, Q_M7B5, 2}, {7, Q_DOM7, 2}, {0, Q_MIN, 4}, END};
static const cm_chord *const bq_prog[] = {bq1, bq2, bq3, bq4};
static const uint8_t bq_form[] = {F_SENTENCE, F_AAAB, F_PERIOD};
static const char *const bq_lead[] = {
    "x-xxx-xxx-xxx---" "xxxxx-x-x---x---",
    "xxxxxxxxxxxxx---" "x-x-xxxxx---x---",
    "x---xxxxx---xxxx" "x-x-x-x-x-------"};
static const char *const bq_bass[] = {"x-x-x-x-x-x-x-x-", "x-xxx-x-x-xxx-x-"};
static const char *const bq_chords[] = {"x--.x--.x--.x--.", "x-------x---x---"};

/* classical: four-bar phrases that answer each other (a half close on V, then the full close), Alberti bass in the arp,
 * light chords on the beat */
static const cm_chord cl1[] = {{0, Q_MAJ, 4}, {5, Q_MAJ, 4}, {7, Q_MAJ, 4}, {0, Q_MAJ, 4}, END};
static const cm_chord cl2[] = {{0, Q_MAJ, 4}, {9, Q_MIN, 4}, {2, Q_MIN, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord cl3[] = {{0, Q_MAJ, 4}, {2, Q_MIN, 4}, {0, Q_MAJ, 2}, {7, Q_MAJ, 2}, {7, Q_MAJ, 4}, END};
static const cm_chord cl4[] = {{0, Q_MAJ, 4}, {4, Q_MIN, 4}, {5, Q_MAJ, 2}, {7, Q_DOM7, 2}, {0, Q_MAJ, 4}, END};
static const cm_chord *const cl_prog[] = {cl1, cl2, cl3, cl4};
static const uint8_t cl_form[] = {F_PERIOD, F_SENTENCE};
static const char *const cl_lead[] = {
    "x---x-x-x---x---" "x-x-x-x-x-------",
    "x-xxx-x-x---x---" "x---x---x-------",
    "x.x.x.x.x---x---" "x-x-x-x-x---...."};
static const char *const cl_bass[] = {"x---x---x---x---", "x-------x-------", "x---x---x-x-x---", "x-x-x-x-x-x-x-x-", "x--x--x-x---x---"};
static const char *const cl_chords[] = {"x---x---x---x---", ".x-.x-.x.x-.x-.."};

/* romantic: harmonic minor with the Neapolitan, diminished sevenths and ninths, long lead notes and wide leaps (the
 * held notes are the rubato), broad arps with the colour tone */
static const cm_chord rm1[] = {{0, Q_MIN, 4}, {5, Q_MIN6, 4}, {1, Q_MAJ, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord rm2[] = {{8, Q_MAJ7, 4}, {2, Q_M7B5, 4}, {7, Q_DOM9, 4}, {0, Q_MIN9, 4}, END};
static const cm_chord rm3[] = {{0, Q_MIN, 4}, {11, Q_DIM7, 4}, {0, Q_MIN, 2}, {3, Q_MAJ, 2}, {7, Q_DOM7, 4}, END};
static const cm_chord rm4[] = {{3, Q_MAJ, 4}, {8, Q_MAJ, 4}, {1, Q_MAJ, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord *const rm_prog[] = {rm1, rm2, rm3, rm4};
static const uint8_t rm_form[] = {F_SENTENCE, F_AABA, F_PERIOD};
static const char *const rm_lead[] = {
    "x-----x-x-------" "x---x-x-x-------",
    "x-------x--x-x--" "x-------x-------",
    "x---x-------x-x-" "x---------------"};
static const char *const rm_bass[] = {"x-------x-------", "x---x-------x---"};
static const char *const rm_chords[] = {"x-------x-------", "x-----x-x-------"};

/* chorale: a chord each half bar (the cadence chord a whole bar), the lead in quarters by step, the bass in quarters, block chords */
static const cm_chord cr1[] = {{0, Q_MAJ, 2}, {5, Q_MAJ, 2}, {0, Q_MAJ, 2}, {7, Q_MAJ, 2}, {9, Q_MIN, 2}, {2, Q_MIN, 2}, {7, Q_MAJ, 4}, END};
static const cm_chord cr2[] = {{0, Q_MAJ, 2}, {4, Q_MIN, 2}, {9, Q_MIN, 2}, {5, Q_MAJ, 2}, {2, Q_MIN, 2}, {7, Q_SUS4, 2}, {7, Q_MAJ, 4}, END};
static const cm_chord cr3[] = {{9, Q_MIN, 2}, {4, Q_MIN, 2}, {5, Q_MAJ, 2}, {0, Q_MAJ, 2}, {2, Q_MIN, 2}, {7, Q_MAJ, 2}, {0, Q_MAJ, 4}, END};
static const cm_chord *const cr_prog[] = {cr1, cr2, cr3};
static const uint8_t cr_form[] = {F_PERIOD, F_AABA};
static const char *const cr_lead[] = {
    "x---x---x---x---" "x---x---x-------",
    "x---x---x---x-x-" "x---x---x-------",
    "x-------x---x---" "x---x---x-------"};
static const char *const cr_bass[] = {"x---x---x---x---", "x---x---x-x-x---"};
static const char *const cr_chords[] = {"x---x---x---x---", "x-------x---x---"};
