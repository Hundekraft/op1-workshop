/* composer styles, screen group (arrays) */

/* cinematic: Aeolian, i-VI-III-VII and bVI-bVII-i, ostinato arps, big long chords */
static const cm_chord ci1[] = {{0, Q_MIN, 4}, {8, Q_MAJ, 4}, {3, Q_MAJ, 4}, {10, Q_MAJ, 4}, END};
static const cm_chord ci2[] = {{8, Q_MAJ, 4}, {10, Q_MAJ, 4}, {0, Q_MIN, 8}, END};
static const cm_chord ci3[] = {{0, Q_MIN, 8}, {10, Q_MAJ, 4}, {8, Q_MAJ, 4}, END};
static const cm_chord ci4[] = {{0, Q_MIN, 4}, {5, Q_MIN, 4}, {8, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord ci5[] = {{0, Q_MIN, 4}, {3, Q_MAJ, 4}, {8, Q_MAJ, 4}, {10, Q_MAJ, 4}, END};
static const cm_chord *const ci_prog[] = {ci1, ci2, ci3, ci4, ci5};
static const uint8_t ci_form[] = {F_SENTENCE, F_PERIOD, F_AAAB};
static const char *const ci_lead[] = {
    "x---" "--x-" "x---" "x---" "----" "x---" "----" "....",
    "x---" "--x-" "x---" "----" "x-x-" "x---" "----" "....",
    "x-x-" "x---" "x---" "x---" "x---" "----" "----" "....",
    "x---" "x---" "x---" "--x-" "x---" "----" "----" "...."};
static const char *const ci_bass[] = {"x.x." "x.x." "x.x." "x.x.", "x---" "----" "----" "----", "x-x-" "x-x-" "x-x-" "x-xx",
                                      "x..x" "..x." "x..x" "..x."};
static const char *const ci_chords[] = {"x---" "----" "----" "----", "x---" "----" "x---" "----"};

/* chiptune: bright Ionian, fast up-arps, square leads in 8ths and 16ths, octave-jumping bass */
static const cm_chord ch1[] = {{0, Q_MAJ, 4}, {7, Q_MAJ, 4}, {9, Q_MIN, 4}, {5, Q_MAJ, 4}, END};
static const cm_chord ch2[] = {{0, Q_MAJ, 4}, {10, Q_MAJ, 4}, {5, Q_MAJ, 4}, {0, Q_MAJ, 4}, END};
static const cm_chord ch3[] = {{5, Q_MAJ, 4}, {7, Q_MAJ, 4}, {4, Q_MIN, 4}, {9, Q_MIN, 4}, END};
static const cm_chord ch4[] = {{0, Q_MAJ, 4}, {9, Q_MIN, 4}, {2, Q_MIN, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord ch5[] = {{0, Q_MAJ, 2}, {5, Q_MAJ, 2}, {7, Q_MAJ, 2}, {5, Q_MAJ, 2}, {0, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord *const ch_prog[] = {ch1, ch2, ch3, ch4, ch5};
static const uint8_t ch_form[] = {F_AAAB, F_PERIOD, F_SENTENCE};
static const char *const ch_lead[] = {
    "x-xx" "xx-x" "x-xx" "x---" "x-xx" "xx-x" "x---" "....",
    "xxx." "xxx." "xx-x" "x---" "xxx." "x-x-" "x---" "....",
    "x-x-" "x-x-" "xxxx" "x---" "x-x-" "xxx-" "x---" "x...",
    "xxxx" "x-x-" "xxxx" "x-.." "xxxx" "x-x-" "x---" "...."};
static const char *const ch_bass[] = {"xXxX" "xXxX" "xXxX" "xXxX", "x.Xx" ".XxX" "x.Xx" ".XxX", "xxXx" "xxXx" "xxXx" "xxXX"};
static const char *const ch_chords[] = {"x--x" "--x-" "x--x" "--x-", "x---" "x---" "x---" "x---"};

/* darksynth: Phrygian / harmonic minor, 16th bass, menacing */
static const cm_chord ds1[] = {{0, Q_MIN, 8}, {1, Q_MAJ, 4}, {0, Q_MIN, 4}, END};
static const cm_chord ds2[] = {{0, Q_MIN, 4}, {8, Q_MAJ, 4}, {10, Q_MAJ, 4}, {0, Q_MIN, 4}, END};
static const cm_chord ds3[] = {{0, Q_MIN, 4}, {5, Q_MIN, 4}, {8, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord ds4[] = {{0, Q_MIN, 4}, {1, Q_MAJ, 4}, {3, Q_MAJ, 4}, {1, Q_MAJ, 4}, END};
static const cm_chord ds5[] = {{0, Q_MIN, 8}, {6, Q_DIM, 4}, {1, Q_MAJ, 4}, END};
static const cm_chord *const ds_prog[] = {ds1, ds2, ds3, ds4, ds5};
static const uint8_t ds_form[] = {F_AAAB, F_LOOP, F_SENTENCE};
static const char *const ds_lead[] = {
    "x-x-" "x---" "x-x-" "--x-" "x-x-" "x---" "x---" "....",
    "x..x" "..x." "x---" "...." "x..x" "..x." "xx--" "x...",
    "x-xx" "-x-x" "x---" "x-.." "x-xx" "-x-x" "x---" "...."};
static const char *const ds_bass[] = {"xxxx" "xxxx" "xxxx" "xxxx", "xxXx" "xxXx" "xxXx" "xxXx", "x.xx" "x.xx" "x.xx" "xxXx"};
static const char *const ds_chords[] = {"x---" "----" "x---" "----", "x-.x" "-.x-" "x-.x" "-.x."};

/* vaporwave: slowed city-pop, maj7/maj9/min9, lazy swing */
static const cm_chord vw1[] = {{0, Q_MAJ7, 4}, {5, Q_MAJ9, 4}, {4, Q_MIN7, 4}, {9, Q_MIN9, 4}, END};
static const cm_chord vw2[] = {{2, Q_MIN9, 4}, {7, Q_DOM13, 4}, {0, Q_MAJ9, 8}, END};
static const cm_chord vw3[] = {{5, Q_MAJ7, 4}, {4, Q_MIN7, 4}, {2, Q_MIN9, 4}, {7, Q_DOM9, 4}, END};
static const cm_chord vw4[] = {{0, Q_MAJ6, 4}, {9, Q_MIN9, 4}, {2, Q_MIN9, 4}, {7, Q_7SUS, 4}, END};
static const cm_chord vw5[] = {{0, Q_MAJ9, 8}, {5, Q_MAJ7, 4}, {4, Q_MIN7, 2}, {9, Q_MIN7, 2}, END};
static const cm_chord *const vw_prog[] = {vw1, vw2, vw3, vw4, vw5};
static const uint8_t vw_form[] = {F_PERIOD, F_AABA, F_LOOP};
static const char *const vw_lead[] = {
    "x--." "..x-" "x-.." "...." "x--." "..x." "x---" "....",
    "..x." "x.x-" "--.." ".x.." "..x." "x.x-" "----" "....",
    "x.x." "x--." "..x-" "--.." "x.x." "x---" "----" "....",
    "x---" "--.x" "--x-" "...." "x-.." "x-x-" "x---" "...."};
static const char *const vw_bass[] = {"x--." "..x." "x-.." ".x..", "x--x" "--x." "x--." "..x-", "x--." "...." "x-.x" "-..."};
static const char *const vw_chords[] = {"x---" "-..." "..x-" "-...", "x---" "----" "..x-" "----", "x-.." "x-.." "x-.." "x-.x"};

/* film noir: minor, m7b5, dim7, mMaj7, smoky ballad */
static const cm_chord fn1[] = {{0, Q_MIN7, 4}, {2, Q_M7B5, 4}, {7, Q_7S9, 4}, {0, Q_MMAJ7, 4}, END};
static const cm_chord fn2[] = {{0, Q_MMAJ7, 4}, {0, Q_MIN7, 4}, {0, Q_MIN6, 4}, {8, Q_MAJ7, 4}, END};
static const cm_chord fn3[] = {{0, Q_MIN7, 4}, {11, Q_DIM7, 4}, {2, Q_M7B5, 4}, {7, Q_7S9, 4}, END};
static const cm_chord fn4[] = {{3, Q_MAJ7, 4}, {8, Q_MAJ7, 4}, {2, Q_M7B5, 4}, {7, Q_7S9, 4}, END};
static const cm_chord fn5[] = {{0, Q_MIN9, 8}, {5, Q_MIN7, 4}, {7, Q_7S9, 4}, END};
static const cm_chord *const fn_prog[] = {fn1, fn2, fn3, fn4, fn5};
static const uint8_t fn_form[] = {F_PERIOD, F_AABA, F_SENTENCE};
static const char *const fn_lead[] = {
    "x-x-" "x---" "x-.." "...." "x--." "..x-" "x---" "....",
    "..x-" "x-x." "x--x" "--.." "..x-" "x---" "----" "....",
    "x.x-" "--x." "x--." "x---" "x---" "--x-" "x---" "...."};
static const char *const fn_bass[] = {"x--." "..x-" "x--." "..x.", "x---" "x--." "x---" "x-.x", "x--." "x-.." "x--x" "-..."};
static const char *const fn_chords[] = {"x---" "----" "..x-" "----", "x--." "..x-" "----" "...."};
