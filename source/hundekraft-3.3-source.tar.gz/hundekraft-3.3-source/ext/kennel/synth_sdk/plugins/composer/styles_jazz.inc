/* composer styles, jazz group (arrays): bossa nova, ballad, blues, gospel, funk, folk */

/* bossa nova: major, ii-V turnarounds, Ipanema-style chromatic shifts, bass root-fifth */
static const cm_chord bn1[] = {{0, Q_MAJ7, 8}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, {4, Q_MIN7, 4}, {9, Q_7S9, 4}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord bn2[] = {{5, Q_MAJ7, 8}, {7, Q_DOM7, 8}, {7, Q_MIN7, 8}, {6, Q_DOM7, 8}, END};
static const cm_chord bn3[] = {{9, Q_MIN7, 4}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, {0, Q_MAJ7, 4}, {5, Q_MAJ7, 8}, {11, Q_M7B5, 4}, {4, Q_DOM7, 4}, END};
static const cm_chord bn4[] = {{0, Q_MAJ6, 8}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, {4, Q_MIN7, 4}, {9, Q_DOM7, 4}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord *const bn_prog[] = {bn1, bn2, bn3, bn4};
static const uint8_t bn_form[] = {F_AABA, F_PERIOD, F_SENTENCE};
static const char *const bn_lead[] = {
    "x.x." "x-x-" "x--x" "--x-" "x---" "x-.x" "--x-" "....",
    "x--x" "--x-" "x--x" "--x-" "x---" "...." "..x-" "x...",
    "x.xx" "-x-x" "-x--" "x-.." "x--x" "-x--" "x---" "...."};
static const char *const bn_bass[] = {"x..x" "..x." "x..x" "..x.", "x..." "x.x." "x..." "x.x.", "x..x" "...x" "x..." "x.x."};
static const char *const bn_chords[] = {"x..x" "...." "..x." "....", "..x." "x..." "..x." "...."};

/* ballad: jazz ballad, rich chords, ii-V-I, m7b5 to dom7 in minor */
static const cm_chord jb1[] = {{2, Q_MIN9, 4}, {7, Q_DOM13, 4}, {0, Q_MAJ9, 8}, {9, Q_MIN9, 4}, {2, Q_MIN9, 4}, {7, Q_DOM13, 4}, {0, Q_MAJ9, 4}, END};
static const cm_chord jb2[] = {{0, Q_MAJ7, 8}, {2, Q_MIN9, 4}, {7, Q_DOM13, 4}, {4, Q_MIN7, 4}, {9, Q_7S9, 4}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord jb3[] = {{2, Q_M7B5, 4}, {7, Q_7S9, 4}, {0, Q_MIN9, 8}, {5, Q_MIN7, 4}, {10, Q_DOM9, 4}, {3, Q_MAJ9, 4}, {9, Q_M7B5, 4}, END};
static const cm_chord jb4[] = {{0, Q_MAJ9, 8}, {5, Q_MAJ9, 4}, {4, Q_MIN7, 4}, {9, Q_MIN9, 4}, {2, Q_MIN9, 4}, {7, Q_DOM13, 4}, {0, Q_MAJ6, 4}, END};
static const cm_chord *const jb_prog[] = {jb1, jb2, jb3, jb4};
static const uint8_t jb_form[] = {F_AABA, F_PERIOD, F_SENTENCE};
static const char *const jb_lead[] = {
    "x---" "--x-" "x---" "x---" "x-x-" "----" "...." "....",
    "x.x-" "--x-" "--x-" "x---" "x---" "--.." "...." "x---",
    "x-x-" "x---" "--x-" "...." "x---" "x-x-" "----" "...."};
static const char *const jb_bass[] = {"x---" "--x-" "x---" "-.x.", "x--." "x--." "x--." "x-x.", "x---" "...." "x--x" "--x."};
static const char *const jb_chords[] = {"x---" "--x-" "----" "....", "x---" "----" "..x-" "----"};

/* blues: 12 bars squeezed into 8, dominant 7ths, shuffle */
static const cm_chord bl1[] = {{0, Q_DOM7, 8}, {5, Q_DOM7, 4}, {0, Q_DOM7, 4}, {7, Q_DOM7, 4}, {5, Q_DOM7, 4}, {0, Q_DOM7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord bl2[] = {{0, Q_DOM7, 4}, {5, Q_DOM7, 4}, {0, Q_DOM7, 8}, {5, Q_DOM7, 8}, {0, Q_DOM7, 4}, {7, Q_DOM9, 4}, END};
static const cm_chord bl3[] = {{0, Q_DOM9, 8}, {5, Q_DOM9, 4}, {5, Q_DIM7, 4}, {0, Q_DOM7, 4}, {9, Q_DOM7, 4}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord bl4[] = {{0, Q_DOM7, 8}, {5, Q_DOM7, 4}, {5, Q_DOM7, 4}, {0, Q_DOM7, 4}, {7, Q_DOM7, 4}, {5, Q_DOM7, 4}, {7, Q_7S9, 4}, END};
static const cm_chord *const bl_prog[] = {bl1, bl2, bl3, bl4};
static const uint8_t bl_form[] = {F_AABA, F_PERIOD, F_SENTENCE};
static const char *const bl_lead[] = {
    "x--x" "x-x-" "x---" "...." "x--x" "x-x-" "--x-" "....",
    "x.x-" "x--x" "--x-" "...." "x-x-" "--x-" "x---" "....",
    "x---" "..xx" "-x--" "x..." "x--x" "-x--" "x---" "...."};
static const char *const bl_bass[] = {"x--x" "x--x" "x--x" "x--x", "x--." "x--x" "x--." "x--x", "x--x" "x--." "x--x" "x-x."};
static const char *const bl_chords[] = {"x--." "...." "x--." "....", "..x-" "...." "..x-" "...."};

/* gospel: major, IV-iv-I, passing diminished, dom13, heavy swing */
static const cm_chord gs1[] = {{0, Q_MAJ, 4}, {5, Q_MAJ, 4}, {5, Q_MIN, 4}, {0, Q_MAJ, 4}, {9, Q_MIN7, 4}, {2, Q_MIN7, 4}, {7, Q_DOM13, 8}, END};
static const cm_chord gs2[] = {{0, Q_MAJ, 8}, {5, Q_MAJ, 4}, {6, Q_DIM7, 4}, {0, Q_MAJ, 4}, {9, Q_MIN7, 4}, {2, Q_MIN7, 2}, {7, Q_DOM13, 2}, {0, Q_MAJ, 4}, END};
static const cm_chord gs3[] = {{0, Q_MAJ6, 4}, {4, Q_MIN7, 4}, {5, Q_MAJ, 4}, {5, Q_MIN6, 4}, {0, Q_MAJ, 4}, {7, Q_DOM13, 4}, {0, Q_MAJ, 8}, END};
static const cm_chord gs4[] = {{5, Q_MAJ9, 4}, {4, Q_MIN7, 4}, {9, Q_DOM7, 4}, {2, Q_MIN7, 4}, {7, Q_DOM13, 4}, {1, Q_DIM7, 4}, {0, Q_MAJ, 8}, END};
static const cm_chord *const gs_prog[] = {gs1, gs2, gs3, gs4};
static const uint8_t gs_form[] = {F_AABA, F_SENTENCE, F_PERIOD};
static const char *const gs_lead[] = {
    "x--x" "-x--" "x-x-" "--.." "x--x" "-x--" "x---" "....",
    "x.x." "x--x" "--x-" "x-.." "x.x." "x-x-" "x---" "....",
    "x-x-" "x--x" "-x--" "...." "x-x-" "x--x" "--x-" "...."};
static const char *const gs_bass[] = {"x--x" "--x-" "x--x" "--x-", "x--." "x--x" "x--." "x-x.", "x-.x" "--x." "x-.x" "--x-"};
static const char *const gs_chords[] = {"x--." "...x" "x---" "....", "x-.." "...x" "-.x." "...."};

/* funk: vamps on dom9/min7/7s9, syncopated 16th bass, choppy stabs */
static const cm_chord fk1[] = {{0, Q_DOM9, 16}, {0, Q_DOM9, 8}, {5, Q_DOM9, 8}, END};
static const cm_chord fk2[] = {{0, Q_MIN7, 8}, {5, Q_DOM9, 8}, {0, Q_MIN7, 8}, {5, Q_DOM9, 8}, END};
static const cm_chord fk3[] = {{0, Q_7S9, 16}, {10, Q_DOM9, 8}, {0, Q_7S9, 8}, END};
static const cm_chord fk4[] = {{0, Q_MIN9, 8}, {10, Q_DOM9, 8}, {8, Q_MAJ7, 8}, {7, Q_DOM7, 8}, END};
static const cm_chord *const fk_prog[] = {fk1, fk2, fk3, fk4};
static const uint8_t fk_form[] = {F_LOOP, F_AAAB, F_PERIOD};
static const char *const fk_lead[] = {
    "x.xx" ".x.x" "x..." "x.x." "x.xx" ".x.x" "..x." "....",
    "x.x." "xx.x" "..x." "x..." "x.x." "xx.x" "x..." "....",
    "x..x" "..x." "x.x." "..xx" "x..x" "..x." "x..." "...."};
static const char *const fk_bass[] = {"x..x" "..x." "x.xx" "..x.", "x.x." "x..x" "..x." "xx.x", "x..x" "x.x." "..x." "x.xx"};
static const char *const fk_chords[] = {"..x." "...x" "...." ".x..", "x..x" "...." "..x." "....", "...x" "...." "...x" "x..."};

/* folk: major/minor triads, I-IV-V-vi, strummed, singable */
static const cm_chord fo1[] = {{0, Q_MAJ, 8}, {5, Q_MAJ, 4}, {0, Q_MAJ, 4}, {7, Q_MAJ, 4}, {5, Q_MAJ, 4}, {0, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord fo2[] = {{0, Q_MAJ, 4}, {9, Q_MIN, 4}, {5, Q_MAJ, 4}, {7, Q_MAJ, 4}, {0, Q_MAJ, 4}, {9, Q_MIN, 4}, {5, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord fo3[] = {{0, Q_MAJ, 8}, {5, Q_MAJ, 4}, {7, Q_MAJ, 4}, {9, Q_MIN, 4}, {4, Q_MIN, 4}, {5, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord fo4[] = {{9, Q_MIN, 4}, {5, Q_MAJ, 4}, {0, Q_MAJ, 4}, {7, Q_MAJ, 4}, {9, Q_MIN, 4}, {2, Q_MIN, 4}, {7, Q_MAJ, 8}, END};
static const cm_chord *const fo_prog[] = {fo1, fo2, fo3, fo4};
static const uint8_t fo_form[] = {F_PERIOD, F_AABA, F_SENTENCE};
static const char *const fo_lead[] = {
    "x-x-" "x-x-" "x---" "x-.." "x-x-" "x-x-" "x---" "....",
    "x--x" "-x-x" "x---" "..x-" "x-x-" "x---" "x---" "....",
    "x-x-" "xx-x" "x---" "...." "x-x-" "x-xx" "x---" "...."};
static const char *const fo_bass[] = {"x..." "x..." "x..." "x.x.", "x..." "..x." "x..." "..x.", "x.x." "x.x." "x.x." "x.x."};
static const char *const fo_chords[] = {"x..." "x.x." "x..." "x...", "x..." "x..." "x.x." "...."};
