    /* urban */
    STYLE_P("boom bap", 90, 9, M_DOR, 60, bp, "x..x..x.x..x..x.", ARP_UP, 70, 29, 60, 70, 75, 50, 85, 3, 1, 20, 1, 10, 25, 15, 25, 15, 0, "AABA", 0, 0, CM_NO(CM_ARP), FIG_ARP, 0, 0),
    STYLE("trap", 140, 6, M_PHR, 50, tp, "x.x.x.x.x.x.x.x.", ARP_UP, 74, 30, 62, 85, 130, 50, 100, 1, 0, 0, 1, 10, 0, 0, 10, 0, 0, "AABABB", 0),
    STYLE("neo-soul", 76, 3, M_DOR, 62, ns, "x..x..x.x..x..x.", ARP_ALBERTI, 70, 31, 60, 80, 85, 60, 90, 4, 1, 35, 2, 15, 20, 20, 35, 10, 1, "AABABCB", 0),
    STYLE("afrobeats", 108, 7, M_MIX, 54, ab, "x..x..x.x..x..x.", ARP_UP, 74, 31, 62, 80, 60, 55, 75, 2, 0, 30, 2, 15, 25, 5, 20, 5, 0, "AABABCBB", 0),
    STYLE("amapiano", 112, 2, M_DOR, 52, ap, "xxxxxxxxxxxxxxxx", ARP_PUMP, 72, 31, 60, 75, 80, 40, 70, 4, 1, 15, 2, 20, 20, 10, 15, 25, 0, "AABABCBB", CM_DROP | CM_BREAK),
    STYLE("reggaeton", 95, 9, M_AEO, 50, rg, "x..x..x.x..x..x.", ARP_UP, 72, 31, 62, 80, 70, 55, 65, 1, 0, 20, 2, 15, 20, 0, 10, 10, 0, "AABABB", 0),
