/* composer styles, club group (arrays) */

/* liquid drum & bass: Aeolian, 9ths and maj7s, rolling sub, floating lead */
static const cm_chord db1[] = {{0, Q_MIN9, 4}, {8, Q_MAJ9, 4}, {3, Q_MAJ7, 4}, {10, Q_ADD9, 4}, END};
static const cm_chord db2[] = {{0, Q_MIN7, 4}, {5, Q_MIN7, 4}, {10, Q_DOM9, 4}, {3, Q_MAJ9, 4}, END};
static const cm_chord db3[] = {{8, Q_MAJ9, 4}, {10, Q_ADD9, 4}, {0, Q_MIN9, 8}, END};
static const cm_chord db4[] = {{0, Q_MIN11, 8}, {8, Q_MAJ7, 4}, {10, Q_DOM7, 4}, END};
static const cm_chord *const db_prog[] = {db1, db2, db3, db4};
static const uint8_t db_form[] = {F_PERIOD, F_AABA, F_SENTENCE};
static const char *const db_lead[] = {
    "x---" "..x-" "--x-" "...." "x-.x" "x--x" "----" "....",
    "x--." "..x-" "--x." "x---" "x--." "..x-" "----" "--..",
    "x.x." "x---" "..x-" "----" "x-.x" "----" "x---" "...."};
static const char *const db_bass[] = {"x...""..x.""x..x""....", "x..x""....""x.x.""..x.", "x...""..xx""..x.""...x"};
static const char *const db_chords[] = {"x---""--..""..x-""----", "..x-""--..""x---""...."};

/* UK garage / 2-step: Aeolian, 9ths, skippy stabs, wobbly sub */
static const cm_chord ga1[] = {{0, Q_MIN9, 4}, {8, Q_MAJ7, 4}, {5, Q_MIN9, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord ga2[] = {{0, Q_MIN7, 4}, {3, Q_MAJ9, 4}, {8, Q_MAJ7, 4}, {10, Q_DOM9, 4}, END};
static const cm_chord ga3[] = {{5, Q_MIN9, 4}, {0, Q_MIN9, 4}, {3, Q_MAJ7, 4}, {10, Q_DOM9, 4}, END};
static const cm_chord ga4[] = {{0, Q_MIN9, 8}, {3, Q_MAJ9, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord *const ga_prog[] = {ga1, ga2, ga3, ga4};
static const uint8_t ga_form[] = {F_AABA, F_PERIOD, F_AAAB};
static const char *const ga_lead[] = {
    "x.x-" "..x." "-x.." "x---" "x.x-" "..x." "-x--" "....",
    "x.x." "x-.x" "--x." "...." "x.x." "x-.x" "x---" "--..",
    "x..x" "..x." "x-.." "x.x-" "x..x" "..x." "x---" "...."};
static const char *const ga_bass[] = {"x...""..x.""...x""..x.", "x..x""....""x...""..xx", "x...""..x.""..x.""...."};
static const char *const ga_chords[] = {"..x.""...x""..x.""...x", "x..x""..x.""...x""....", "..x-""..x.""...x""x..."};

/* acid house: Phrygian one-chord vamps, 303 sixteenths with accents and slides */
static const cm_chord ac1[] = {{0, Q_MIN7, 16}, END};
static const cm_chord ac2[] = {{0, Q_MIN7, 8}, {1, Q_MAJ7, 8}, END};
static const cm_chord ac3[] = {{0, Q_MIN, 4}, {10, Q_MAJ, 4}, {8, Q_MAJ, 4}, {10, Q_MAJ, 4}, END};
static const cm_chord ac4[] = {{0, Q_MIN7, 8}, {5, Q_MIN7, 4}, {3, Q_MAJ7, 4}, END};
static const cm_chord *const ac_prog[] = {ac1, ac2, ac3, ac4};
static const uint8_t ac_form[] = {F_LOOP, F_AAAB, F_AABA};
static const char *const ac_lead[] = {
    "xoxx" "ox-x" "xo.x" "x-.." "xoxx" "ox-x" "Xx.o" "x...",
    "x-xo" "x.xx" "-xox" "x-.." "x-xo" "x.xx" "-xo." "....",
    "Xoox" "-xo." "xxox" "ox.." "Xoox" "-xo." "x-x." "...."};
static const char *const ac_bass[] = {"xoxx""ox-x""xoXx""ox.x", "x.xo""xx.x""-xox""x.xo", "XoxX""oxox""xXox""x.xo"};
static const char *const ac_chords[] = {"x...""..x.""....""..x.", "...x""....""x...""...."};

/* dub techno: Dorian, minor 9/11 stabs with long gates, sparse bass */
static const cm_chord dt1[] = {{0, Q_MIN9, 16}, END};
static const cm_chord dt2[] = {{0, Q_MIN11, 8}, {5, Q_MIN9, 8}, END};
static const cm_chord dt3[] = {{0, Q_MIN9, 8}, {3, Q_MAJ7, 8}, END};
static const cm_chord dt4[] = {{0, Q_MIN7, 8}, {10, Q_MAJ7, 4}, {7, Q_MIN7, 4}, END};
static const cm_chord *const dt_prog[] = {dt1, dt2, dt3, dt4};
static const uint8_t dt_form[] = {F_LOOP, F_PERIOD, F_AAAB};
static const char *const dt_lead[] = {
    "x---" "..x-" "----" "...." "...." "...." "x---" "....",
    "x---" "...." "...." "..x." "...." "x---" "----" "....",
    "x---" "x-.." "...." "...." "..x-" "...." "...." "...."};
static const char *const dt_bass[] = {"x...""....""....""....", "x...""....""..x.""....", "x...""....""...x""....", "x.x.""....""x...""....", "x...""..x.""....""..x."};
static const char *const dt_chords[] = {"..x.""....""..x.""....", "...x""....""..x.""....", "..x.""....""....""...x"};

/* breakbeat: Dorian, funky i - IV7 shapes, bass chasing the break */
static const cm_chord bb1[] = {{0, Q_MIN7, 8}, {5, Q_DOM9, 8}, END};
static const cm_chord bb2[] = {{0, Q_MIN9, 4}, {3, Q_MAJ7, 4}, {5, Q_DOM9, 4}, {7, Q_MIN7, 4}, END};
static const cm_chord bb3[] = {{0, Q_MIN7, 8}, {10, Q_DOM7, 4}, {8, Q_MAJ7, 4}, END};
static const cm_chord bb4[] = {{0, Q_MIN11, 8}, {7, Q_MIN7, 4}, {5, Q_DOM7, 4}, END};
static const cm_chord *const bb_prog[] = {bb1, bb2, bb3, bb4};
static const uint8_t bb_form[] = {F_AABA, F_SENTENCE, F_PERIOD};
static const char *const bb_lead[] = {
    "x.x." "x--x" "..x-" "x..." "x.x." "x--x" "x---" "....",
    "x.xx" "-.x." "x-.x" "...." "x.xx" "-.x." "x--." "....",
    "x--x" "..x." ".x-." "x.x." "x--x" "..x." "x---" "...."};
static const char *const bb_bass[] = {"x..x""..x.""..x.""x.x.", "x.x.""..x.""x..x""....", "x..x""...x""x...""..xx"};
static const char *const bb_chords[] = {"x..x""..x.""...x""x...", "..x.""x..x""....""..x."};

/* nu-disco: Ionian, ii V I, dom7/min7 and octave-jumping bass, string-like pads */
static const cm_chord nd1[] = {{2, Q_MIN7, 4}, {7, Q_DOM7, 4}, {0, Q_MAJ7, 4}, {5, Q_MAJ7, 4}, END};
static const cm_chord nd2[] = {{0, Q_MAJ7, 4}, {9, Q_MIN7, 4}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord nd3[] = {{9, Q_MIN9, 4}, {2, Q_DOM9, 4}, {7, Q_DOM7, 4}, {0, Q_MAJ9, 4}, END};
static const cm_chord nd4[] = {{5, Q_MAJ7, 4}, {4, Q_MIN7, 4}, {9, Q_MIN7, 4}, {2, Q_DOM7, 4}, END};
static const cm_chord *const nd_prog[] = {nd1, nd2, nd3, nd4};
static const uint8_t nd_form[] = {F_PERIOD, F_AABA, F_SENTENCE};
static const char *const nd_lead[] = {
    "x.x." "xx-." "x-x." "x---" "x.x." "xx-." "x---" "...." ,
    "x.xx" "-x.x" "x---" "...." "x.xx" "-x.x" "x-x." "x...",
    "x-x-" "x-.x" "-.x." "x-.." "x-x-" "x-.x" "x---" "...."};
static const char *const nd_bass[] = {"x.xX""x.xX""x.xX""x.xX", ".xxX"".xxX"".xxX"".xxX", "x.xx""x.xx""x.xx""x.xX"};
static const char *const nd_chords[] = {"x-..""..x-""....""..x.", "x---""x---""x---""x.x."};
