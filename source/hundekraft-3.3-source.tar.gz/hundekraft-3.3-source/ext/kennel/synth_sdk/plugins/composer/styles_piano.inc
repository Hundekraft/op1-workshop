/* composer styles, piano group (arrays), 2026-11-14: ragtime, boogie-woogie, nocturne, impressionist, neo-classical,
 * montuno; styles for a piano (LUDWIG) whose left hand is the arp role's figure (stride, boogie, broken chord,
 * montuno). Progressions are common-practice formulas and style rules; no melodies are copied.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */

/* ragtime: a march in major with secondary dominants (I VI7 II7 V7), the diminished passing chord; the right hand in
 * syncopated 16ths (16th 8th 16th), the stride left hand in the arp role, a tuba bass on 1 and 3 */
static const cm_chord rt1[] = {{0, Q_MAJ, 4}, {9, Q_DOM7, 4}, {2, Q_DOM7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord rt2[] = {{0, Q_MAJ, 4}, {4, Q_DOM7, 4}, {9, Q_MIN, 4}, {2, Q_DOM7, 2}, {7, Q_DOM7, 2}, END};
static const cm_chord rt3[] = {{5, Q_MAJ, 4}, {6, Q_DIM7, 4}, {0, Q_MAJ, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord rt4[] = {{0, Q_MAJ, 4}, {7, Q_DOM7, 4}, {7, Q_DOM7, 4}, {0, Q_MAJ, 4}, END};
static const cm_chord *const rt_prog[] = {rt1, rt2, rt3, rt4};
static const uint8_t rt_form[] = {F_PERIOD, F_SENTENCE, F_AABA};
static const char *const rt_lead[] = {
    "xx-x" "xx-x" "x-x-" "x..." "xx-x" "xx-x" "x---" "....",
    "x-xx" "-xx-" "x-x-" "x-x." "x-xx" "-xx-" "x---" "....",
    ".xx-" "xx-x" "-x-x" "x..." ".xx-" "xx-x" "x---" "x..."};
static const char *const rt_bass[] = {"x---" "...." "x---" "....", "x---" "...." "x---" "x..."};
static const char *const rt_chords[] = {"....x---....x---"};

/* boogie-woogie: dominant sevenths, twelve bars squeezed into eight (as blues); the rolling dotted-8th left hand
 * (1 3 5 6 b7 6 5 3) in the arp role, right-hand riffs and off-beat stabs */
static const cm_chord bw1[] = {{0, Q_DOM7, 8}, {5, Q_DOM7, 8}, {0, Q_DOM7, 8}, {7, Q_DOM7, 4}, {5, Q_DOM7, 4}, END};
static const cm_chord bw2[] = {{0, Q_DOM7, 4}, {5, Q_DOM7, 4}, {0, Q_DOM7, 8}, {5, Q_DOM7, 8}, {7, Q_DOM7, 4}, {0, Q_DOM7, 4}, END};
static const cm_chord bw3[] = {{0, Q_DOM7, 16}, {5, Q_DOM7, 8}, {7, Q_DOM7, 4}, {0, Q_DOM7, 4}, END};
static const cm_chord bw4[] = {{0, Q_DOM7, 8}, {5, Q_DOM7, 4}, {5, Q_DIM7, 4}, {0, Q_DOM7, 4}, {7, Q_DOM7, 4}, {0, Q_DOM7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord *const bw_prog[] = {bw1, bw2, bw3, bw4};
static const uint8_t bw_form[] = {F_AAAB, F_PERIOD, F_SENTENCE};
static const char *const bw_lead[] = {
    "x.xx" "x.x." "x---" "...." "x.xx" "x.x." "x-x-" "....",
    "..xx" "x.xx" "x---" "...." "..xx" "x.xx" "x---" "x...",
    "x..x" "x..x" "x..x" "x---" "x..x" "x..x" "x---" "...."};
static const char *const bw_bass[] = {"x..xx..xx..xx..x"};
static const char *const bw_chords[] = {"..x...x...x...x.", "x--...x-..x-...."};

/* nocturne: major with the borrowed bVI and minor iv, changes often anticipated; a slow singing lead with long notes
 * and turns, the wide broken-chord left hand (pedalled) in the arp role, a held bass */
static const cm_chord nc1[] = {{0, Q_MAJ, 4}, {9, Q_MIN7, 4}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord nc2[] = {{0, Q_MAJ7, 4}, {4, Q_MIN, 4}, {5, Q_MAJ, 4}, {5, Q_MIN6, 4}, END};
static const cm_chord nc3[] = {{5, Q_MAJ7, 4}, {7, Q_DOM9, 4}, {4, Q_MIN7, 4}, {9, Q_MIN, 4}, END};
static const cm_chord nc4[] = {{0, Q_MAJ, 8}, {8, Q_MAJ, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord *const nc_prog[] = {nc1, nc2, nc3, nc4};
static const uint8_t nc_form[] = {F_PERIOD, F_AABA, F_SENTENCE};
static const char *const nc_lead[] = {
    "x-----x-x--xx---" "x-----------....",
    "x-------x-x-x-x-" "x---x---x-------",
    "..x-x---x-----x-" "x-------x---...."};
static const char *const nc_bass[] = {"x---------------", "x-------x-------"};
static const char *const nc_chords[] = {"x-------x-------"};

/* impressionist: Lydian, parallel ninths and sevenths (planing), whole-tone augmented chords, colour tones left
 * unresolved; a floating lead, broken chords in the arp role */
static const cm_chord im1[] = {{0, Q_MAJ9, 4}, {2, Q_MAJ9, 4}, {4, Q_MIN9, 4}, {2, Q_MAJ9, 4}, END};
static const cm_chord im2[] = {{0, Q_MAJ7, 8}, {10, Q_MAJ7, 4}, {8, Q_MAJ7, 4}, END};
static const cm_chord im3[] = {{0, Q_9S5, 4}, {2, Q_9S5, 4}, {0, Q_AUG, 8}, END};
static const cm_chord im4[] = {{0, Q_SUS2, 4}, {2, Q_SUS2, 4}, {4, Q_MIN7, 4}, {7, Q_SUS2, 4}, END};
static const cm_chord im5[] = {{9, Q_MIN9, 4}, {7, Q_MAJ9, 4}, {0, Q_MAJ9, 8}, END};
static const cm_chord *const im_prog[] = {im1, im2, im3, im4, im5};
static const uint8_t im_form[] = {F_PERIOD, F_AABA};
static const char *const im_lead[] = {
    "x-------x---x---" "x-----------....",
    "..x-x-------x---" "x-x-x-------....",
    "x---x-x-x-------" "x-------x-------"};
static const char *const im_bass[] = {"x---------------", "x-------x-------"};
static const char *const im_chords[] = {"x-------x-------", "x-----x-x-------"};

/* neo-classical: minor, four chords that loop (i VI III VII), a repeating broken-chord ostinato in the arp role, a
 * simple lead in quarters and halves, soft held chords; the build is the sections' (B fuller, C thinner) */
static const cm_chord ne1[] = {{0, Q_MIN, 4}, {8, Q_MAJ, 4}, {3, Q_MAJ, 4}, {10, Q_MAJ, 4}, END};
static const cm_chord ne2[] = {{0, Q_MIN, 4}, {5, Q_MIN, 4}, {8, Q_MAJ, 4}, {7, Q_MIN, 4}, END};
static const cm_chord ne3[] = {{8, Q_MAJ, 4}, {3, Q_MAJ, 4}, {10, Q_MAJ, 4}, {0, Q_MIN, 4}, END};
static const cm_chord ne4[] = {{0, Q_MIN, 8}, {8, Q_MAJ7, 8}, END};
static const cm_chord *const ne_prog[] = {ne1, ne2, ne3, ne4};
static const uint8_t ne_form[] = {F_AAAB, F_PERIOD, F_LOOP};
static const char *const ne_lead[] = {
    "x---x---x---x---" "x-------x-------",
    "x---x---x-x-x---" "x-----------....",
    "x-------x---x---" "x---x---x-------"};
static const char *const ne_bass[] = {"x-------x-------", "x---------------"};
static const char *const ne_chords[] = {"x---------------", "x-------x-------"};

/* montuno: salsa in major, I IV V IV and ii V I over a two-bar clave loop; the syncopated octave figure in the arp
 * role, the anticipated tumbao bass (the and of 2 and beat 4), a sonero lead */
static const cm_chord mo1[] = {{0, Q_MAJ, 4}, {5, Q_MAJ, 4}, {7, Q_DOM7, 4}, {5, Q_MAJ, 4}, END};
static const cm_chord mo2[] = {{0, Q_MAJ, 2}, {5, Q_MAJ, 2}, {7, Q_DOM7, 2}, {5, Q_MAJ, 2}, END};
static const cm_chord mo3[] = {{2, Q_MIN7, 4}, {7, Q_DOM7, 4}, {0, Q_MAJ, 8}, END};
static const cm_chord mo4[] = {{0, Q_MAJ, 4}, {9, Q_MIN, 4}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord *const mo_prog[] = {mo1, mo2, mo3, mo4};
static const uint8_t mo_form[] = {F_AAAB, F_PERIOD, F_SENTENCE};
static const char *const mo_lead[] = {
    "x.x." ".x.x" "..x-" "...." "x.x." ".x.x" "x---" "....",
    "..x." "x.x." "x-.." "...." "..x." "x.x." "x---" "--..",
    "x--x" "--x." "x.x." "...." "x--x" "--x." "x---" "...."};
static const char *const mo_bass[] = {"......x-....x---", "x.....x-....x---"};
static const char *const mo_chords[] = {"x..x..x...x..x.."};
