/* composer styles, jazz group (STYLE rows, appended in order) */
    STYLE("bossa nova", 130, 0, M_ION, 50, bn, "x..x..x...x..x..", ARP_ALBERTI, 72, 31, 62, 80, 75, 50, 70, 3, 1, 40, 2, 20, 45, 10, 20, 5, 0, "AABA", 0),
    STYLE("ballad", 68, 3, M_ION, 58, jb, "x...x...x...x...", ARP_UP, 74, 29, 60, 100, 85, 60, 95, 4, 1, 15, 1, 10, 20, 15, 45, 5, 0, "AABA", 0),
    STYLE_P("blues", 96, 9, M_MIX, 66, bl, "x..x..x..x..x..x", ARP_PUMP, 72, 31, 62, 70, 80, 50, 65, 1, 1, 20, 2, 15, 20, 10, 50, 10, 0, "AABAB", 0, 0, CM_NO(CM_ARP), FIG_ARP, 0, 0),
    STYLE("gospel", 80, 7, M_ION, 62, gs, "x.xx.xx.x.xx.xx.", ARP_UPDOWN, 72, 31, 62, 85, 75, 55, 80, 3, 1, 40, 2, 25, 20, 15, 35, 10, 0, "AABABCB", 0),
    STYLE("funk", 104, 4, M_DOR, 56, fk, "x.x.xx.x.x.xx.x.", ARP_PUMP, 70, 33, 64, 55, 55, 40, 40, 3, 1, 35, 2, 20, 10, 20, 10, 25, 0, "AABAABCB", CM_BREAK),
    STYLE("folk", 100, 7, M_ION, 50, fo, "x.x.x.x.x.x.x.x.", ARP_ALBERTI, 74, 31, 60, 90, 85, 70, 75, 1, 0, 10, 1, 20, 40, 0, 20, 0, 0, "AABABCBB", 0),
