/* composer styles, urban group (arrays) */

/* boom bap: Dorian, dusty jazz-sample 7ths, swung 16ths */
static const cm_chord bp1[] = {{0, Q_MIN9, 4}, {5, Q_DOM9, 4}, {3, Q_MAJ7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord bp2[] = {{0, Q_MIN7, 8}, {3, Q_MAJ7, 4}, {2, Q_M7B5, 2}, {7, Q_DOM7, 2}, END};
static const cm_chord bp3[] = {{5, Q_MAJ7, 4}, {4, Q_MIN7, 4}, {2, Q_MIN7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord bp4[] = {{0, Q_MIN7, 4}, {8, Q_MAJ7, 4}, {7, Q_DOM7, 4}, {0, Q_MIN9, 4}, END};
static const cm_chord *const bp_prog[] = {bp1, bp2, bp3, bp4};
static const uint8_t bp_form[] = {F_LOOP, F_AABA, F_PERIOD};
static const char *const bp_lead[] = {
    "x--." "..x-" "x-.." "...." "x--." "..x." "x---" "....",
    "..x." "x.x-" "--.." ".x.." "..x." "x.x-" "----" "....",
    "x.x." "x--." "..x-" "...." "x.x." "x---" "x---" "...."};
static const char *const bp_bass[] = {"x..." "..x." "...x" "....", "x.o." "..x." "x..." ".o..", "x..x" "...." "x.x." "...."};
static const char *const bp_chords[] = {"x--." "..x-" "...." "....", "x---" "-..x" "--.." "...."};

/* trap: Phrygian, plain minor triads, sparse 808 with long slides */
static const cm_chord tp1[] = {{0, Q_MIN, 8}, {1, Q_MAJ, 8}, END};
static const cm_chord tp2[] = {{0, Q_MIN, 4}, {8, Q_MAJ, 4}, {7, Q_MAJ, 4}, {1, Q_MAJ, 4}, END};
static const cm_chord tp3[] = {{0, Q_MIN, 8}, {10, Q_MAJ, 4}, {1, Q_MAJ, 4}, END};
static const cm_chord tp4[] = {{0, Q_MIN, 4}, {5, Q_MIN, 4}, {8, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord *const tp_prog[] = {tp1, tp2, tp3, tp4};
static const uint8_t tp_form[] = {F_LOOP, F_AAAB, F_PERIOD};
static const char *const tp_lead[] = {
    "x---...." "x-.x...." "x---...." "..x-....",
    "x.....x-" "----...." "x.....x-" "x---....",
    "..x---.." "x-x-...." "..x---.." "x---...."};
static const char *const tp_bass[] = {"x---" "----" "----" "..x-", "x---" "-..x" "----" "----", "x---" "----" "x---" "-.x-"};
static const char *const tp_chords[] = {"x---" "----" "----" "----", "x---" "----" "..x-" "----"};

/* neo-soul: Dorian, min9/dom13/maj9, laid-back swing */
static const cm_chord ns1[] = {{0, Q_MIN9, 8}, {5, Q_DOM9, 8}, END};
static const cm_chord ns2[] = {{0, Q_MIN11, 4}, {3, Q_MAJ9, 4}, {5, Q_DOM13, 4}, {7, Q_MIN7, 4}, END};
static const cm_chord ns3[] = {{8, Q_MAJ9, 4}, {7, Q_7S9, 4}, {0, Q_MIN9, 8}, END};
static const cm_chord ns4[] = {{2, Q_M7B5, 4}, {7, Q_7S9, 4}, {0, Q_MIN9, 4}, {5, Q_DOM13, 4}, END};
static const cm_chord *const ns_prog[] = {ns1, ns2, ns3, ns4};
static const uint8_t ns_form[] = {F_PERIOD, F_AABA, F_LOOP};
static const char *const ns_lead[] = {
    "x--..x--x--.......x---x.x---....",
    "..x.x--x---...x...x.x--xx---....",
    "x.-x--..x-.x--..x.-x--..x---...."};
static const char *const ns_bass[] = {"x--." "..x-" "-.x." "..o.", "x-.x" "--.." "x--." ".x-.", "x..." "x-.x" "-..." ".x.."};
static const char *const ns_chords[] = {"x--." "-x--" "..x-" "-...", "x-.." "-.x-" "x-.." ".x--"};

/* afrobeats: Mixolydian, 3-3-2 patterns, bright major */
static const cm_chord ab1[] = {{0, Q_MAJ, 4}, {7, Q_MAJ, 4}, {9, Q_MIN, 4}, {5, Q_MAJ, 4}, END};
static const cm_chord ab2[] = {{9, Q_MIN7, 4}, {5, Q_MAJ7, 4}, {0, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord ab3[] = {{0, Q_ADD9, 4}, {10, Q_MAJ, 4}, {5, Q_MAJ, 8}, END};
static const cm_chord ab4[] = {{5, Q_MAJ, 4}, {0, Q_MAJ, 4}, {9, Q_MIN7, 4}, {7, Q_DOM7, 4}, END};
static const cm_chord *const ab_prog[] = {ab1, ab2, ab3, ab4};
static const uint8_t ab_form[] = {F_AABA, F_PERIOD, F_SENTENCE};
static const char *const ab_lead[] = {
    "x..x..x.x..x....x..x..x.x.x-....",
    "..x.x..x..x-..x...x.x..xx---....",
    "x.x.x..x.x-.....x.x.x..x-x--...."};
static const char *const ab_bass[] = {"x..x" "..x." "x..x" "..x.", "x..x" "..x." "x..." "x.x.", "x.xx" "..x." "x..x" "..x."};
static const char *const ab_chords[] = {"x..x" "..x." "...." "....", "..x." "x..x" "...." "...."};

/* amapiano: Dorian, log-drum bass, jazzy min9 chords */
static const cm_chord ap1[] = {{0, Q_MIN9, 4}, {5, Q_DOM9, 4}, {3, Q_MAJ9, 4}, {7, Q_MIN7, 4}, END};
static const cm_chord ap2[] = {{0, Q_MIN9, 8}, {8, Q_MAJ9, 4}, {7, Q_DOM9, 4}, END};
static const cm_chord ap3[] = {{0, Q_MIN11, 4}, {10, Q_DOM9, 4}, {8, Q_MAJ9, 4}, {7, Q_DOM9, 4}, END};
static const cm_chord ap4[] = {{0, Q_MIN9, 4}, {3, Q_MAJ9, 4}, {5, Q_MIN7, 4}, {7, Q_7SUS, 4}, END};
static const cm_chord *const ap_prog[] = {ap1, ap2, ap3, ap4};
static const uint8_t ap_form[] = {F_LOOP, F_AAAB, F_PERIOD};
static const char *const ap_lead[] = {
    "x.x-.x..x--.....x.x-.x..x---....",
    "..x.x-.x..x-......x.x-.xx---....",
    "x--x--.x-.x.....x--x--.xx---...."};
static const char *const ap_bass[] = {"x..x" "..x." ".x.." "x.o.", "x..." "x.ox" "..x." "..xo", "x.x." ".x.." "x..x" "...x"};
static const char *const ap_chords[] = {"..x." "...x" "..x." "....", "x..." "..x-" "...x" "-..."};

/* reggaeton: Aeolian minor, dembow 3+3+2 in bass and chords */
static const cm_chord rg1[] = {{0, Q_MIN, 4}, {8, Q_MAJ, 4}, {10, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord rg2[] = {{0, Q_MIN, 4}, {10, Q_MAJ, 4}, {8, Q_MAJ, 4}, {10, Q_MAJ, 4}, END};
static const cm_chord rg3[] = {{0, Q_MIN, 4}, {5, Q_MIN, 4}, {7, Q_MAJ, 4}, {0, Q_MIN, 4}, END};
static const cm_chord rg4[] = {{0, Q_MIN, 8}, {8, Q_MAJ, 4}, {7, Q_MAJ, 4}, END};
static const cm_chord *const rg_prog[] = {rg1, rg2, rg3, rg4};
static const uint8_t rg_form[] = {F_AAAB, F_LOOP, F_PERIOD};
static const char *const rg_lead[] = {
    "x..x..x.x..x..x.x..x..x.x---....",
    "x.x.x..x-.x.....x.x.x..xx---....",
    "..x.x..x..x.x--...x.x..x..x-...."};
static const char *const rg_bass[] = {"x..x" "..x." "x..x" "..x.", "x..x" "..x." "x..x" "..xx", "x..x" "...x" "x..x" "..x."};
static const char *const rg_chords[] = {"x..x" "..x." "...." "....", "x..x" "..x." "x..." "...."};
