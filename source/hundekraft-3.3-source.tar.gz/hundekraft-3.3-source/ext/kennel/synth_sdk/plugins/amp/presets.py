#!/usr/bin/env python3
"""Amp: sound presets as OP-1 patch files (the pack had none before 2026-11-15).
    python3 synth_sdk/plugins/amp/presets.py [OUT_DIR]     -> OUT_DIR/*.aif (default: presets/ next to this script)

Saved type "amp"; knobs[4] = 0x5300 (a loadable input engine without an order, found by saved name, ORDERS.md).
Knobs (amp_dsp.h): blue VOLUME (0 mutes, 16384 unity, 32767 about +6 dB), green COMP, white TONE (16384 neutral
tilt), red DRIVE (0 clean; the voice's stack and cabinet fade in over the first quarter); word 5 the VOICE (blue
page 2, five steps: CLEAN CRUNCH LEAD BASS FUZZ; 0 reads as CRUNCH, so the step centres are written). Words 6 and 7
are unused. Amp plays the live input, not the keys: the envelope and LFO do nothing (T2 is the tuner, T4 is off),
so the ADSR is neutral and no LFO is set; FX on T3 work as usual.
Level: VOLUME is set per preset so the production DSP (host, 44.1 kHz blocks as on the unit) on a plucked-string
input peaking at -12 dBFS (held E3, a melody, a strummed C chord, a low E2) has the default patch's max momentary
loudness (run/presets-12-2026-11-15/a in the root project). Driven presets compress, so at a hotter or quieter input
they sit closer to or further from the clean ones than at -12 dBFS; native check open.
Every value stays inside the factory presets' ranges (root tools/op1r_presets.py): outside them the firmware
imports the file as a plain sample.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json
import math
import struct
import sys
from pathlib import Path

SELECTOR = 0x5300
VOICES = ["clean", "crunch", "lead", "bass", "fuzz"]
ADSR = (64, 9000, 32767, 3000)
RANGE_FX = {
    "delay": [(3392, 11200), (4969, 32767), (0, 16384), (1332, 32767)],
    "spring": [(1344, 16448), (9920, 16448), (0, 16384), (2047, 26120)],
    "phone": [(8286, 20480), (3072, 3968), (1536, 7776), (7168, 17408)],
}


def step_word(i, n):
    """the middle of step i of a knob read as n steps (amp_voice_index: (word * n) >> 15)"""
    return ((2 * i + 1) * 32768) // (2 * n)


def pct(p):
    return round(p * 32767 / 100)


def tone_word(t):
    """TONE -100 (warm) .. 0 (neutral) .. +100 (bright)"""
    return 16384 + round(t * 16383 / 100)


# name, voice, VOLUME word (level-matched, see the docstring), COMP %, TONE -100..100, DRIVE %, FX
PRESETS = [
    ("clean combo", "clean", 10701, 20,  10,  30, ("spring", [8000, 12000, 8000, 12000])),
    #   a clean amp and speaker with a little room
    ("jazz box",    "clean", 18048, 30, -45,  18, None),
    #   warm and round, for chords and walking lines
    ("funk squash", "clean", 16384, 100,  45,  12, None),
    #   heavy compression and a bright edge for tight rhythm
    ("crunch",      "crunch",  5564, 10,   0,  50, None),
    #   edge of break-up: dig in for grit, back off for clean
    ("blues drive", "crunch",  3273, 25, -15,  75, ("spring", [12000, 14000, 6000, 12000])),
    #   a warm pushed amp with a spring
    ("lead",        "lead",  2280, 30,  20,  70, ("delay", [9000, 16000, 8000, 12000])),
    #   singing sustain with an echo behind it
    ("high gain",   "lead",  1570, 15,   5, 100, None),
    #   full lead drive, tight and dry
    ("bass amp",    "bass", 16940, 80, -20,  25, None),
    #   round bass with the peaks held in
    ("bass grit",   "bass",  4471, 35,  15,  80, None),
    #   driven bass that cuts through
    ("fuzz",        "fuzz",  2937,  0, -10,  70, None),
    #   a thick fuzz box, warm side
    ("vocal mic",   "clean", 15665, 100,  25,   0, ("spring", [16448, 15000, 2000, 10239])),
    #   for singing into the mic: even level, presence, reverb
    ("lofi radio",  "crunch",  7160, 20,  60,  35, ("phone", [10536, 3968, 7776, 17408])),
    #   a small cracked speaker on the far side of a room
]

def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def aifc(meta):
    comm = struct.pack(">hIh", 1, 0, 16) + ieee_extended(44100) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    js = json.dumps(meta, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + chunk(b"APPL", b"op-1" + js)
            + chunk(b"SSND", struct.pack(">II", 0, 0)))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


def check(name, what, values, ranges):
    for i, (v, (lo, hi)) in enumerate(zip(values, ranges)):
        if not lo <= v <= hi:
            raise ValueError(f"{name}: {what}[{i}] = {v} is outside {lo}..{hi}")


def knobs(p):
    name, voice, vol, comp, tone, drive = p[:6]
    return [vol, pct(comp), tone_word(tone), pct(drive), SELECTOR, step_word(VOICES.index(voice), len(VOICES)), 0, 0]


def meta(p):
    name, fx = p[0], p[6]
    k = knobs(p)
    check(name, "knobs", k, [(0, 32767)] * 8)
    if fx:
        check(name, "fx " + fx[0], fx[1], RANGE_FX[fx[0]])
    return {
        "adsr": list(ADSR) + [2048, 5568, 4000, 4000],
        "fx_active": fx is not None,
        "fx_params": (fx or ("delay", [8000] * 4))[1] + [0, 0, 0, 0],
        "fx_type": (fx or ("delay", None))[0],
        "knobs": k,
        "lfo_active": False,
        "lfo_params": [16000, 0, 0, 16000, 0, 0, 0, 0],
        "lfo_type": "tremolo",
        "name": name,
        "octave": 0,
        "synth_version": 2,
        "type": "amp",
    }


def main():
    if len(sys.argv) > 2:
        sys.exit(__doc__)
    out = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parent / "presets"
    out.mkdir(parents=True, exist_ok=True)
    names = [p[0] for p in PRESETS]
    assert len(set(names)) == len(names) and all(len(n) <= 14 for n in names)
    for p in PRESETS:
        (out / (p[0] + ".aif")).write_bytes(aifc(meta(p)))
    print(f"{len(PRESETS)} presets in {out}")


if __name__ == "__main__":
    main()
