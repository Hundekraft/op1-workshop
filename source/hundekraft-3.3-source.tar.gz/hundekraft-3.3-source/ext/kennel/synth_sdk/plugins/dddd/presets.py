#!/usr/bin/env python3
"""dddd sound presets as OP-1 patch files: python3 synth_sdk/plugins/dddd/presets.py [OUT_DIR] -> OUT_DIR/*.aif
(default: presets/ next to this script)

An OP-1 synth patch is an AIFC file (16-bit mono, 44.1 kHz, 'sowt') with an APPL chunk holding "op-1" + JSON and an
empty SSND chunk (the firmware renders its own preview when it syncs). Saved sounds find the engine by its type name
("type": "dddd", docs/preset-identity.md); knobs[4] holds 0x5300 (OP1_ENGINE_MAGIC alone), as EVA's and VAPORA's.
Every value stays inside the ranges the factory presets use: values outside them make the firmware import the file
as a plain sample (tools/op1r_presets.py, where these ranges were measured).
LFO off on all of them: the random hands already move the sound, and blue is a stepped source selector.
Levels: set against the plugin.json default on the host (dry engine at 88.2 kHz, decimated; OP1-Emulator
run/presets-12-2026-11-15), to be re-measured natively.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
Knob words: blue SOURCE (noise 0, crackle 10923, chaos 21845, metal 32767, blended between), green FEEDBACK (past ~80 %
it screams), white DESTROY (fold to 10922, clip to 21844, crush above), red HANDS (stutter above 26000); page-2 words
5 FILTER (LP 0, BP 16384, HP 32767), 6 SPREAD, 7 RATE CRUSH (0 = full rate .. 1/32). No level trim: the engine's own
limiter sets the level, so dense, bright settings are loudest; pitch is heard through chaos, metal and the feedback
loop (a tap per held key).
"""
import json
import math
import struct
import sys
from pathlib import Path

RANGE_ADSR = [(64, 16320), (64, 16320), (0, 32767), (64, 16320)]
RANGE_FX = {
    "delay": [(3392, 11200), (4969, 32767), (0, 16384), (1332, 32767)],
    "spring": [(1344, 16448), (9920, 16448), (0, 16384), (2047, 26120)],
}
SELECTOR = 0x5300                 # OP1_ENGINE_MAGIC: no fixed number (see above)

# name, knobs (SOURCE, FEEDBACK, DESTROY, HANDS), words 5..7 (FILTER, SPREAD, RATE CRUSH), ADSR, FX, octave
# Release words (2026-11-15): R246 reads the release word inverted (rate table 0x7F - (v >> 7), audio-graph.md): HIGH
# release = SHORT. To -60 dB: 4800 = 2.9 s, 6000 = 2.1 s, 10400 = 0.9 s, 13500 = 0.4 s, 15000 = 0.2 s. Pads and drones
# sit at 3600..8000, leads and keys at 7000..13500, basses, plucks, stabs and organs at 13500..16320.
PRESETS = [
    ("noise wall", [0, 27000, 26000, 10000], [0, 0, 0], [64, 3000, 32767, 6500], None, 0),
    ("metal drone", [32767, 18000, 21800, 2000], [8000, 0, 0], [5000, 8000, 32767, 7000], None, 0),
    ("grit bass", [28000, 12000, 21800, 3000], [6000, 0, 8000], [64, 7000, 32767, 13500], None, -1),
    ("crackle", [10923, 12000, 20000, 6000], [16384, 0, 0], [64, 3000, 32767, 9800], None, 0),
    ("noise pluck", [0, 26000, 21800, 0], [6000, 0, 0], [64, 8000, 0, 13500],
     ("delay", [7000, 12000, 5000, 9000]), 0),
    ("bit rot", [0, 12000, 30000, 3000], [0, 0, 16000], [64, 3000, 32767, 9800], None, 0),
    ("stutter", [26000, 20000, 26000, 27500], [14000, 0, 0], [64, 3000, 32767, 9800], None, 0),
    ("wind", [0, 0, 12000, 14000], [16384, 0, 0], [8500, 9000, 30000, 6300], None, 0),
    ("screamer", [32767, 32767, 16000, 0], [32767, 0, 0], [64, 3000, 32767, 9800], None, 0),
    ("burst hit", [3000, 10000, 24000, 4000], [20000, 0, 0], [64, 8600, 0, 13500], None, 0),
    ("comb pad", [0, 23000, 12000, 6000], [0, 20000, 0], [7500, 9000, 30000, 6300],
     ("spring", [14000, 13000, 3000, 9000]), 0),
    ("robot buzz", [32767, 8000, 21800, 0], [0, 0, 9000], [64, 6000, 32767, 11300], None, 1),
]

def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def aifc(meta):
    comm = struct.pack(">hIh", 1, 0, 16) + ieee_extended(44100) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    js = json.dumps(meta, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + chunk(b"APPL", b"op-1" + js)
            + chunk(b"SSND", struct.pack(">II", 0, 0)))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


def check(name, what, values, ranges):
    for i, (v, (lo, hi)) in enumerate(zip(values, ranges)):
        if not lo <= v <= hi:
            raise ValueError(f"{name}: {what}[{i}] = {v} is outside {lo}..{hi}")


def meta(name, knobs, words, adsr, fx, octave):
    check(name, "knobs", list(knobs) + list(words), [(0, 32767)] * 7)
    check(name, "adsr", adsr, RANGE_ADSR)
    if fx:
        check(name, "fx " + fx[0], fx[1], RANGE_FX[fx[0]])
    assert -2 <= octave <= 2 and len(name) <= 14 and name == name.lower(), name
    return {
        "adsr": list(adsr) + [2048, 5568, 4000, 4000],
        "fx_active": fx is not None,
        "fx_params": (fx or ("delay", [8000] * 4))[1] + [0, 0, 0, 0],
        "fx_type": (fx or ("delay", None))[0],
        "knobs": list(knobs) + [SELECTOR] + list(words),
        "lfo_active": False,
        "lfo_params": [16000, 0, 0, 16000, 0, 0, 0, 0],
        "lfo_type": "tremolo",
        "name": name,
        "octave": octave,
        "synth_version": 2,
        "type": "dddd",
    }


def main():
    if len(sys.argv) > 2:
        sys.exit(__doc__)
    out = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parent / "presets"
    out.mkdir(parents=True, exist_ok=True)
    assert len({p[0] for p in PRESETS}) == len(PRESETS)
    for p in PRESETS:
        (out / (p[0] + ".aif")).write_bytes(aifc(meta(*p)))
    print(f"{len(PRESETS)} presets in {out}")


if __name__ == "__main__":
    main()
