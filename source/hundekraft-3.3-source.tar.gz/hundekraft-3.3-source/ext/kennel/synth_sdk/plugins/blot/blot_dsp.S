/* BLOT's oscillator pass on the Blackfin: pass 1 of blot's bl_loop (blot.c / blot_dsp.S), unchanged, bit for bit the C
 * bl_osc in blot.c (which host builds and -DBLOT_C_REF use); then (kennel) bl_ladder, the Open303 ladder pass, bit for
 * bit blot.c's C bl_ladder (below).
 *
 * void bl_osc(bl_blk *b)    b: 0 p, 20 inc, 24 out, 32 wave, 44 rinv, 48 sh, 84 w
 * per sample p += inc[n]; out[n] = osc >> 1, osc = saw(p) (- saw(p + 2^31) wave >> 15 when wave != 0).
 *   saw(q) = clip((q ^ 2^31) >>> 16 + (e e >> 15) - (t t >> 15), +-32767), e = 32768 - frac(q), t = 32768 - frac(-q),
 *   frac(x) = min(min(x >> sh, 65535) rinv >> 14, 32767) (unsigned products: FU, the integer product).
 *   Fast path (w != 0): while q is >= w from a wrap (q + w >= 2 w unsigned; for square also q + 2^31: the test on
 *   (q + w) mod 2^31) both polyBLEP terms are 0 and the clip idle (blot.c): saw(q) = (q ^ 2^31) >>> 16, so osc >> 1 =
 *   (q ^ 2^31) >>> 17 for saw; saw(q + 2^31) = q >>> 16 (never -32768 there), s1 wave >> 15 as one truncating
 *   fractional product. Near a wrap the loop jumps out to the full saw(s) and back to its last instruction (the store).
 *   Fast loops: R0 p, R3 w, R4 2 w, R5 wave. Near a wrap and in the full loops: R7 {rinv : -sh}, R6 32767.
 * bl_osc: callee-saved R4..R7, P3..P5 are saved; no circular addressing (L0..L3 stay 0), no M registers. The fast loops leave
 * the hardware loop and come back to its last instruction near a wrap (the loop runs on, LC0 untouched).
 * Host builds assemble it empty.
 * Copyright (C) 2026 pcppcp. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifdef __bfin__
	.text

/* d = saw(q) (d != q), temps t1 t2 t3; R7 = {rinv : -sh}, R6 = 32767 */
.macro SAW d, q, t1, t2, t3
	\t3 = 65535 (Z);
	\t1 = LSHIFT \q BY R7.L;            /* q >> sh */
	CC = \t3 < \t1 (IU);
	IF CC \t1 = \t3;                    /* <= 65535 */
	\t1 = \t1\().L * R7.H (FU);         /* x rinv */
	\t1 >>= 14;
	\t1 = MIN(\t1, R6);                 /* frac(q) */
	\t2 = -\q;                          /* 2^32 - q */
	\t2 = LSHIFT \t2 BY R7.L;
	CC = \t3 < \t2 (IU);
	IF CC \t2 = \t3;
	\t2 = \t2\().L * R7.H (FU);
	\t2 >>= 14;
	\t2 = MIN(\t2, R6);                 /* frac(-q) */
	\t3 = 32768 (Z);
	\t1 = \t3 - \t1;                    /* e */
	\t2 = \t3 - \t2;                    /* t */
	\t1 = \t1\().L * \t1\().L (FU);
	\t1 >>= 15;
	\t2 = \t2\().L * \t2\().L (FU);
	\t2 >>= 15;
	\t1 = \t1 - \t2;
	\d = \q;
	BITTGL(\d, 31);
	\d >>>= 16;                         /* (q >> 16) - 32768 */
	\d = \d + \t1;
	\d = MIN(\d, R6);
	\t3 = -R6;
	\d = MAX(\d, \t3);                  /* +-32767 */
.endm

/* kennel 2026-11-06: d = saw(q) for q near a wrap (the fast path's test failed: q < w or q > 2^32 - w, w < 2^30):
 * only one polyBLEP term can be non-zero there. q < 2^31 (just after a wrap): + (e e >> 15), e = 32768 - frac(q); the
 * other term is 0 (frac(-q) is capped: -q > 2^32 - w >= w). q >= 2^31: - (t t >> 15), t = 32768 - frac(-q). Then the
 * clip. The same number as SAW for these q; |q| or |-q| < w < 2^30, so the 65535 cap is a signed MIN. CC = q < 0
 * throughout; temps t1 t2; R7 = {rinv : -sh}, R6 = 32767 */
.macro SAWN d, q, t1, t2
	\t1 = -\q;
	CC = \q < 0;
	IF !CC \t1 = \q;                   /* q, or 2^32 - q */
	\t2 = 65535 (Z);
	\t1 = LSHIFT \t1 BY R7.L;
	\t1 = MIN(\t1, \t2);
	\t1 = \t1\().L * R7.H (FU);
	\t1 >>= 14;
	\t1 = MIN(\t1, R6);                /* frac */
	\t2 = 32768 (Z);
	\t1 = \t2 - \t1;
	\t1 = \t1\().L * \t1\().L (FU);
	\t1 >>= 15;
	\t2 = -\t1;
	IF CC \t1 = \t2;                   /* + e e >> 15, or - t t >> 15 */
	\d = \q;
	BITTGL(\d, 31);
	\d >>>= 16;
	\d = \d + \t1;
	\d = MIN(\d, R6);
	\t2 = -R6;
	\d = MAX(\d, \t2);
.endm

	.align 4
	.global _bl_osc
	.type _bl_osc, STT_FUNC
_bl_osc:
	[--SP] = (R7:4, P5:3);
	P5 = R0;

	/* ---- pass 1: the oscillator into out[] ---- */
	R0 = [P5];                          /* p */
	P3 = [P5 + 20];                     /* inc */
	P4 = [P5 + 24];                     /* out */
	R7 = [P5 + 48];
	R7 = -R7;                           /* -sh */
	R1 = [P5 + 44];
	R7 = PACK(R1.L, R7.L);              /* {rinv : -sh} */
	R6 = 32767 (X);
	R5 = [P5 + 32];                     /* wave */
	R3 = [P5 + 84];                     /* w */
	R4 = R3 << 1;                       /* 2 w */
	P0 = 128;
	CC = R5 == 0;
	IF !CC JUMP .Lsq;
	CC = R3 == 0;
	IF CC JUMP .Lsaw_full;

	/* saw, fast */
	LSETUP (.Lsf_b, .Lsf_e) LC0 = P0;
.Lsf_b:
	R1 = [P3++];
	R0 = R0 + R1;                       /* p */
	R1 = R0 + R3;
	CC = R1 < R4 (IU);
	IF CC JUMP .Lsf_near;
	R1 = R0;
	BITTGL(R1, 31);
	R1 >>>= 17;                         /* osc >> 1 */
.Lsf_e:
	W[P4++] = R1;
	JUMP .Lend;
.Lsf_near:
	SAWN R1, R0, R2, R3
	R1 >>>= 1;
	R3 = [P5 + 84];
	R4 = R3 << 1;
	JUMP .Lsf_e;

	/* saw, full (high notes) */
.Lsaw_full:
	LSETUP (.Lsu_b, .Lsu_e) LC0 = P0;
.Lsu_b:
	R1 = [P3++];
	R0 = R0 + R1;
	SAW R1, R0, R2, R3, R4
	R1 >>>= 1;
.Lsu_e:
	W[P4++] = R1;
	JUMP .Lend;

.Lsq:
	CC = R3 == 0;
	IF CC JUMP .Lsq_full;

	/* square, fast */
	LSETUP (.Lqf_b, .Lqf_e) LC0 = P0;
.Lqf_b:
	R1 = [P3++];
	R0 = R0 + R1;
	R1 = R0 + R3;
	BITCLR(R1, 31);                     /* (q + w) mod 2^31: near either wrap */
	CC = R1 < R4 (IU);
	IF CC JUMP .Lqf_near;
	R1 = R0;
	BITTGL(R1, 31);
	R1 >>>= 16;                         /* saw(p) */
	R2 = R0 >>> 16;                     /* saw(p + 2^31) */
	R2.L = R2.L * R5.L (T);             /* x wave >> 15 */
	R2 = R2.L (X);
	R1 = R1 - R2;
	R1 >>>= 1;
.Lqf_e:
	W[P4++] = R1;
	JUMP .Lend;
.Lqf_near:                              /* kennel: only the saw near its wrap takes SAWN, the other the fast form */
	R1 = R0 + R3;
	CC = R1 < R4 (IU);
	IF !CC JUMP .Lqf_near2;
	SAWN R1, R0, R2, R3                 /* saw(p) */
	R2 = R0 >>> 16;                     /* saw(p + 2^31), away from its wrap */
	JUMP .Lqf_mix;
.Lqf_near2:
	R5 = R0;
	BITTGL(R5, 31);
	SAWN R2, R5, R1, R3                 /* saw(p + 2^31) */
	R1 = R0;
	BITTGL(R1, 31);
	R1 >>>= 16;                         /* saw(p), away from its wrap */
	R5 = [P5 + 32];                     /* wave */
.Lqf_mix:
	R2.L = R2.L * R5.L (T);             /* x wave >> 15 */
	R2 = R2.L (X);
	R1 = R1 - R2;
	R1 >>>= 1;
	R3 = [P5 + 84];
	R4 = R3 << 1;
	JUMP .Lqf_e;

	/* square, full (high notes) */
.Lsq_full:
	LSETUP (.Lqu_b, .Lqu_e) LC0 = P0;
.Lqu_b:
	R1 = [P3++];
	R0 = R0 + R1;
	SAW R1, R0, R2, R3, R4
	W[P4] = R1;
	R5 = R0;
	BITTGL(R5, 31);
	SAW R1, R5, R2, R3, R4
	R5 = [P5 + 32];
	R1 = R1.L * R5.L (IS);
	R1 >>>= 15;
	R2 = W[P4] (X);
	R1 = R2 - R1;
	R1 >>>= 1;
.Lqu_e:
	W[P4++] = R1;

.Lend:
	[P5] = R0;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _bl_osc, .-_bl_osc

/* ---- kennel: bl_ladder, blot.c's C ladder and output stage (the Open303 port) bit for bit, in place on out[].
 * void bl_ladder(bl_blk *b)   b: 4 y[4] (in / out), 24 out, 88 hp (in / out), 92 rec[16][3], 284 ring[7]
 * Per sample (C names): s4 = clip(y4 >> 5, 65535); o = (s4 kq >> 3) - hp; hp += mq16(o, 693);
 *   u = 32 out - 64 soft(clip(o >> 6, 32767)); y1 += mq16(u - y1 + y2, 2 b0); y2 += mq16(y1 - 2 y2 + y3, b0);
 *   y3 += mq16(y2 - 2 y3 + y4, b0); y4 += mq16(y3 - 2 y4, b0); v = clip(y4 >> 5, 32767);
 *   q = soft((v gg) >> 12); q = clip(q + (q >> 1), 32767); out = q gain >> 15.
 * mq16(d, c) = (d >> 16) c + ((d & 0xFFFF) c >> 16) for c < 2^16: A1 = d.L c (FU), A1 >>= 16, A1 += d.H c (M, IS)
 * (signed x unsigned), exact. clip(x >> n, 32767): the high half of x << (16 - n) saturated (= sat16(x >> n)), then
 * MAX with {-32767 : 10923} (the value in the high half). soft(): three truncating fractional products (x x >> 15
 * etc., no operand -32768). q + (q >> 1): a saturating 16-bit add; it can reach -32768 where the C clips to -32767,
 * and -32768 gain >> 15 = -32767 gain >> 15 = -gain for 0 < gain < 32768 (gain is 19661 .. 32767). s4 kq: 17 x 15
 * bits, one 32-bit multiply. Registers: R4..R7 y1..y4, R0..R3 temps (R3 = -65535 from the sample before), P4 out
 * (read, then written), P3 &hp, I0 / B0 / L0 the group's record (3 words), I1 / B1 / L1 ring[] (7 words), each
 * read in a circle once per sample; LC0 the 8 samples, LC1 the 16 groups. L0, L1 are 0 again on return. */
	.align 4
	.global _bl_ladder
	.type _bl_ladder, STT_FUNC
_bl_ladder:
	[--SP] = (R7:4, P5:3);
	P5 = R0;
	R4 = [P5 + 4];
	R5 = [P5 + 8];
	R6 = [P5 + 12];
	R7 = [P5 + 16];
	P4 = [P5 + 24];                     /* out */
	R0 = P5;
	R1 = 88;
	R1 = R0 + R1;
	P3 = R1;                            /* &hp */
	R1 = 142;
	R1 = R1 + R1;
	R1 = R0 + R1;
	I1 = R1;
	B1 = R1;                            /* ring */
	R1 = 28;
	L1 = R1;
	R1 = 92;
	R0 = R0 + R1;                       /* rec[0] */
	R1 = 12;
	L0 = R1;
	R3.H = 0xFFFF;
	R3.L = 1;                           /* -65535 */
	P1 = 16;
	P0 = 8;
	LSETUP (.Ll_ob, .Ll_oe) LC1 = P1;
.Ll_ob:
	I0 = R0;
	B0 = R0;
	LSETUP (.Ll_b, .Ll_e) LC0 = P0;
.Ll_b:
	R0 = R7 >>> 5 || R1 = [I1++] || R2 = [I0++];    /* 65535; kq */
	R0 = MIN(R0, R1);
	R0 = MAX(R0, R3);                               /* s4 */
	R0 *= R2;
	R0 = R0 >>> 3 || R2 = [P3] || R3 = [I1++];      /* hp; {gain : 693} */
	R0 = R0 - R2 (NS);                              /* o */
	A1 = R0.L * R3.L (FU);
	A1 = A1 >> 16;
	R1 = (A1 += R0.H * R3.L) (M, IS);
	R2 = R2 + R1 (NS) || R3 = [I1++] || NOP;        /* hp += mq16(o, 693); {-32767 : 10923} */
	R0 = R0 << 10 (S) || [P3] = R2 || R1 = [I1++];  /* sat16(o >> 6) in R0.H; 64 */
	R0 = MAX(R0, R3);
	R2.L = R0.H * R0.H (T);
	R2.L = R2.L * R0.H (T);
	R2.L = R2.L * R3.L (T);
	R0.L = R0.H - R2.L (NS) || R2 = W[P4] (X) || R3 = [I0++];   /* soft; out[n] (the oscillator); {2 b0 : b0} */
	R0 = R0.L * R1.L (IS);                          /* 64 soft */
	R2 = R2 << 5;
	R2 = R2 - R0 (NS);                              /* u = 32 out - 64 soft */
	R2 = R2 - R4 (NS);
	R1 = R2 + R5 (NS);
	A1 = R1.L * R3.H (FU);
	A1 = A1 >> 16;
	R1 = (A1 += R1.H * R3.H) (M, IS);
	R4 = R4 + R1 (NS);                              /* y1 */
	R1 = R4 + R6 (NS);
	R0 = R5 << 1;
	R1 = R1 - R0 (NS);
	A1 = R1.L * R3.L (FU);
	A1 = A1 >> 16;
	R1 = (A1 += R1.H * R3.L) (M, IS);
	R5 = R5 + R1 (NS);                              /* y2 */
	R1 = R5 + R7 (NS);
	R0 = R6 << 1;
	R1 = R1 - R0 (NS);
	A1 = R1.L * R3.L (FU);
	A1 = A1 >> 16;
	R1 = (A1 += R1.H * R3.L) (M, IS);
	R6 = R6 + R1 (NS);                              /* y3 */
	R0 = R7 << 1;
	R1 = R6 - R0 (NS);
	A1 = R1.L * R3.L (FU);
	A1 = A1 >> 16;
	R1 = (A1 += R1.H * R3.L) (M, IS) || R2 = [I1++] || NOP;   /* {-32767 : 10923} */
	R7 = R7 + R1 (NS) || R3 = [I0++] || NOP;        /* y4; gg */
	R0 = R7 << 11 (S);
	R0 = MAX(R0, R2);                               /* v = clip(y4 >> 5, 32767) in R0.H */
	R1 = (A1 = R0.H * R3.L) (M, IS);                /* v gg */
	R1 = R1 << 4 (S);
	R1 = MAX(R1, R2);                               /* clip(v gg >> 12, 32767) in R1.H */
	R0.L = R1.H * R1.H (T);
	R0.L = R0.L * R1.H (T);
	R0.L = R0.L * R2.L (T);
	R1.L = R1.H - R0.L (NS) || R3 = [I1++] || NOP;  /* q = soft(); {gain : 693} */
	R0.L = R1.L >>> 1;
	R1.L = R1.L + R0.L (S);                         /* q + (q >> 1), saturated */
	R0.L = R1.L * R3.H (T) || R3 = [I1++] || NOP;   /* x gain >> 15; -65535 for the next sample (read after use) */
.Ll_e:
	W[P4++] = R0;
	R0 = I0;                                        /* the record ring is back at its start: the next one follows */
	R1 = 12;
.Ll_oe:
	R0 = R0 + R1;
	[P5 + 4] = R4;
	[P5 + 8] = R5;
	[P5 + 12] = R6;
	[P5 + 16] = R7;
	R0 = 0;
	L0 = R0;
	L1 = R0;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _bl_ladder, .-_bl_ladder

/* ---- kennel: bl_groups, blot.c's C bl_groups bit for bit: per 8 samples the envelope, the cutoff o (Q12 octaves),
 * the coefficients interpolated from ac_kp / ac_b0 at o (1/8 octave steps), g and the make-up gain from mk[] at o,
 * into rec[16][3].
 * void bl_groups(bl_blk *b)   b: 92 rec, 312 env (in / out), 316 gk[12], 364 mk[10], 404 kp, 408 b0
 * All products are the C's 32-bit integer multiplies, all shifts arithmetic as the C's on int32; o < 0 reads the
 * tables where the C does (same addresses). Registers: R7 env, R6 o, R0..R5 temps, P0 ac_kp, P1 ac_b0, P2 mk, P3 the
 * group's rec row, P4 / P5 table pointers, I0 / B0 / L0 gk[] (12 words, read in a circle once per group); b waits in
 * M0. L0 is 0 again on return. */
	.align 4
	.global _bl_groups
	.type _bl_groups, STT_FUNC
_bl_groups:
	[--SP] = (R7:4, P5:3);
	P5 = R0;
	M0 = R0;
	R7 = [P5 + 312];                    /* env */
	P0 = [P5 + 404];                    /* ac_kp */
	P1 = [P5 + 408];                    /* ac_b0 */
	R1 = 92;
	R1 = R0 + R1;
	P3 = R1;                            /* rec[0] */
	R1 = 158;
	R1 = R1 + R1;
	R1 = R0 + R1;
	I0 = R1;
	B0 = R1;                            /* gk[] */
	R1 = 48;
	L0 = R1;
	R1 = 182;
	R1 = R1 + R1;
	R1 = R0 + R1;
	P2 = R1;                            /* mk[] */
	P4 = 16;
	LSETUP (.Lg_b, .Lg_e) LC0 = P4;
.Lg_b:
	R1 = R7 >>> 12 || R0 = [I0++] || NOP;           /* dstep >> 3 */
	R1 *= R0;
	R1 = R1 >>> 9 || R2 = [I0++] || NOP;            /* em */
	R7 = R7 - R1 (NS);                              /* env */
	R1 = R7 >>> 9 || R3 = [I0++] || NOP;            /* base */
	R1 *= R2;
	R1 = R1 >>> 15 || R2 = [I0++] || NOP;           /* the cap */
	R1 = R1 + R3 (NS) || R3 = [I0++] || NOP;        /* 511 */
	R6 = MIN(R1, R2);                               /* o */
	R2 = R6 >>> 9;                                  /* i */
	R3 = R6 & R3;                                   /* f */
	P4 = R2;
	P5 = P1 + (P4 << 1);
	P4 = P0 + (P4 << 1);
	R0 = W[P4++] (Z);
	R1 = W[P4] (Z);
	R4 = W[P5++] (Z);
	R5 = W[P5] (Z);
	R1 = R1 - R0 (NS);
	R1 *= R3;
	R1 = R1 >>> 9;
	R0 = R0 + R1 (NS) || R1 = [I0++] || NOP;        /* kp; r */
	R5 = R5 - R4 (NS);
	R5 *= R3;
	R5 = R5 >>> 9;
	R4 = R4 + R5 (NS);                              /* b0 */
	R5 = R4 << 17;
	R5 = R5 | R4;                                   /* {2 b0 : b0} */
	R3 = R0;
	R3 *= R1;
	R3 = R3 >>> 15 || [P3 + 4] = R5 || R2 = [I0++];   /* k = kp r >> 15; 15421 */
	R2 *= R0;
	R2 = R2 >>> 14 || [P3] = R3 || R0 = [I0++];     /* 4096 */
	R2 = R2 - R0 (NS);
	R2 *= R1;
	R2 = R2 >>> 15;
	R2 = R2 + R0 (NS) || R1 = [I0++] || NOP;        /* 32768 + r */
	R2 *= R1;
	R2 = R2 >>> 15 || R1 = [I0++] || NOP;           /* drive */
	R2 *= R1;
	R2 = R2 >>> 12 || R1 = [I0++] || NOP;           /* 65535 */
	R2 = MIN(R2, R1);                               /* g */
	R4 = 0;
	R0 = MAX(R6, R4);                               /* oc */
	R4 = R0 >>> 12;
	P4 = R4;
	P4 = P2 + (P4 << 2);
	R4 = [P4++];
	R5 = [P4];
	R5 = R5 - R4 (NS) || R3 = [I0++] || NOP;        /* 4095 */
	R0 = R0 & R3;
	R5 *= R0;
	R5 = R5 >>> 12;
	R4 = R4 + R5 (NS);                              /* the make-up gain */
	R2 *= R4;
	R2 = R2 >>> 12;
	R2 = MIN(R2, R1);
	[P3 + 8] = R2;
.Lg_e:
	P3 += 12;
	P5 = M0;
	[P5 + 312] = R7;
	R0 = 0;
	L0 = R0;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _bl_groups, .-_bl_groups
#endif
