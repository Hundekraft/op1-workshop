"""Twelve normal OP-1 blot presets. The engine has no internal program bank.
Words (blot.c): 0 blue cutoff (30 Hz .. 15 kHz), 1 green resonance, 2 white env mod (0 .. 5 octaves), 3 orange decay
(40 .. 640 ms), 4 0x5300, page 2: 5 waveform (saw .. square), 6 accent amount (0: a new sound's 61 %), 7 drive (x1 .. x3).
Accent is velocity 100 or more (the keys). A small accent word (1) keeps the louder sounds near the engine's level.
Host levels (2026-11-15, dry engine at R246 rate, no OP-1 envelope/FX/LFO): held note, melody and chord within
3.1 dB of the default sound, and notes an octave either side stay in the filter's passband.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later + OP-1 firmware permission.
"""
import json,math,struct,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def aifc(meta):
    comm = struct.pack(">hIh", 1, 0, 16) + ieee_extended(44100) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    js = json.dumps(meta, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + chunk(b"APPL", b"op-1" + js)
            + chunk(b"SSND", struct.pack(">II", 0, 0)))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


# Release words (2026-11-15): R246 reads the release word inverted (rate table 0x7F - (v >> 7), audio-graph.md): HIGH
# release = SHORT. To -60 dB: 4800 = 2.9 s, 6000 = 2.1 s, 10400 = 0.9 s, 13500 = 0.4 s, 15000 = 0.2 s. Pads and drones
# sit at 3600..8000, leads and keys at 7000..13500, basses, plucks, stabs and organs at 13500..16320.
PATCHES = [{'adsr': [64, 6000, 30000, 15400, 2048, 5568, 4000, 4000], 'fx_active': False, 'fx_params': [8000, 8000, 8000, 8000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [6500, 27000, 22000, 7000, 21248, 0, 0, 0], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'acid line', 'octave': -1, 'synth_version': 2, 'type': 'blot'}, {'adsr': [64, 5000, 26000, 15100, 2048, 5568, 4000, 4000], 'fx_active': False, 'fx_params': [8000, 8000, 8000, 8000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [8000, 9000, 12000, 14000, 21248, 32767, 1, 18176], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'rubber bass', 'octave': -1, 'synth_version': 2, 'type': 'blot'}, {'adsr': [64, 6000, 30000, 13500, 2048, 5568, 4000, 4000], 'fx_active': True, 'fx_params': [6000, 9000, 4000, 8000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [9000, 31000, 26000, 4000, 21248, 0, 1, 3000], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'screamer', 'octave': -1, 'synth_version': 2, 'type': 'blot'}, {'adsr': [150, 6000, 32767, 14500, 2048, 5568, 4000, 4000], 'fx_active': False, 'fx_params': [8000, 8000, 8000, 8000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [3500, 4000, 5000, 20000, 21248, 32767, 0, 32767], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'deep sub', 'octave': -2, 'synth_version': 2, 'type': 'blot'}, {'adsr': [64, 7000, 30000, 13300, 2048, 5568, 4000, 4000], 'fx_active': True, 'fx_params': [8000, 14000, 8000, 12000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [13000, 24000, 16000, 20000, 21248, 0, 1, 0], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'acid lead', 'octave': 0, 'synth_version': 2, 'type': 'blot'}, {'adsr': [6000, 10000, 30000, 7000, 2048, 5568, 4000, 4000], 'fx_active': True, 'fx_params': [14000, 13000, 3000, 9000, 0, 0, 0, 0], 'fx_type': 'spring', 'knobs': [17000, 12000, 0, 9000, 21248, 0, 1, 0], 'lfo_active': True, 'lfo_params': [1100, 700, 2000, 2000, 0, 0, 0, 0], 'lfo_type': 'value', 'name': 'wah pad', 'octave': 0, 'synth_version': 2, 'type': 'blot'}, {'adsr': [64, 4500, 0, 13500, 2048, 5568, 4000, 4000], 'fx_active': True, 'fx_params': [8000, 12000, 6000, 9000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [10000, 12000, 30000, 2000, 21248, 0, 0, 14400], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'pluck keys', 'octave': 0, 'synth_version': 2, 'type': 'blot'}, {'adsr': [64, 6000, 30000, 15300, 2048, 5568, 4000, 4000], 'fx_active': False, 'fx_params': [8000, 8000, 8000, 8000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [9000, 4000, 14000, 10000, 21248, 0, 1, 32767], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'fuzz bass', 'octave': -1, 'synth_version': 2, 'type': 'blot'}, {'adsr': [64, 2500, 0, 14300, 2048, 5568, 4000, 4000], 'fx_active': False, 'fx_params': [8000, 8000, 8000, 8000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [5000, 30000, 32767, 0, 21248, 0, 0, 22800], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'zap', 'octave': 0, 'synth_version': 2, 'type': 'blot'}, {'adsr': [64, 3500, 0, 13500, 2048, 5568, 4000, 4000], 'fx_active': True, 'fx_params': [9000, 18000, 9000, 14000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [9500, 16000, 14000, 10000, 21248, 0, 0, 13800], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'dub chord', 'octave': 0, 'synth_version': 2, 'type': 'blot'}, {'adsr': [64, 9000, 30000, 14800, 2048, 5568, 4000, 4000], 'fx_active': False, 'fx_params': [8000, 8000, 8000, 8000, 0, 0, 0, 0], 'fx_type': 'delay', 'knobs': [7000, 29000, 10000, 32767, 21248, 12000, 1, 0], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'talk bass', 'octave': -1, 'synth_version': 2, 'type': 'blot'}, {'adsr': [300, 8000, 28000, 12300, 2048, 5568, 4000, 4000], 'fx_active': True, 'fx_params': [12000, 14000, 3000, 9000, 0, 0, 0, 0], 'fx_type': 'spring', 'knobs': [16000, 22000, 4000, 26000, 21248, 0, 1, 0], 'lfo_active': False, 'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': 'glass lead', 'octave': 0, 'synth_version': 2, 'type': 'blot'}]

def main():
    out=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'presets'
    out.mkdir(parents=True,exist_ok=True)
    for meta in PATCHES:(out/(meta['name']+'.aif')).write_bytes(aifc(meta))
    print(f'{len(PATCHES)} normal blot presets in {out}; no internal programs')
if __name__=='__main__':main()
