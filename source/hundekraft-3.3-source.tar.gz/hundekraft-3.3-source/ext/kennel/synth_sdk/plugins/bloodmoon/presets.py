#!/usr/bin/env python3
"""BLOODMOON presets as OP-1 patch files: python3 synth_sdk/plugins/bloodmoon/presets.py [OUT_DIR] -> OUT_DIR/*.aif
(default: presets/ next to this script)

The first eight files in presets/ are the author's (Nola Drift), kept unchanged: each carries a rendered one-second
preview in its SSND chunk, which this script does not reproduce. It writes only the NEW presets below (empty SSND: the
firmware renders its own preview when it syncs) and, when the author's files are next to it, checks that its metadata
writer gives the same APPL chunk for them.
Knobs: BLOOD (harmonic richness), ECLIPSE (bell strike level and ring), HAUNTING (vibrato depth and wobble), MOONRISE
(vibrato speed); knobs[4..7] stay 0 as in the author's files. Saved sounds find the engine by its type name.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json
import math
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
IDLE_FX = [7168, 32767, 5520, 2616]      # the author's values for an FX that is off

# name, knobs (BLOOD, ECLIPSE, HAUNTING, MOONRISE), ADSR (attack, decay, sustain, release), FX or None, octave
AUTHOR = [
    ("blood rite", [32767, 26000, 16000, 12000], [64, 12352, 20000, 12000], ("delay", [7168, 16000, 10000, 13000]), 0),
    ("cathedral", [14000, 20000, 7000, 9000], [1088, 6592, 26000, 12000], ("delay", [8192, 20000, 9000, 14000]), 0),
    ("crypt drone", [30000, 0, 9000, 2500], [6000, 8000, 32767, 14976], None, -1),
    ("funeral bell", [9000, 32767, 2500, 4000], [64, 9000, 6000, 14000], ("delay", [10240, 24000, 12000, 16000]), 0),
    ("hollow saint", [0, 12000, 3500, 6000], [576, 6592, 24000, 9000], None, 0),
    ("moon tremor", [18000, 16000, 32767, 30000], [64, 6592, 30000, 6000], None, 0),
    ("sunken pipes", [26000, 4000, 13000, 1500], [2048, 6592, 32767, 14000], ("delay", [9216, 22000, 6000, 15000]), -1),
    ("witch choir", [20000, 9000, 22000, 7500], [3000, 6592, 28000, 12736], ("delay", [6144, 18000, 8000, 12000]), 0),
]
# Release words (2026-11-15): R246 reads the release word inverted (rate table 0x7F - (v >> 7), audio-graph.md): HIGH
# release = SHORT. To -60 dB: 4800 = 2.9 s, 6000 = 2.1 s, 10400 = 0.9 s, 13500 = 0.4 s, 15000 = 0.2 s. Pads and drones
# sit at 3600..8000, leads and keys at 7000..13500, basses, plucks, stabs and organs at 13500..16320. The author's eight
# above keep their words; only NEW was changed.
NEW = [
    ("banshee", [6000, 0, 24000, 21000], [64, 7000, 28000, 11800], ("delay", [8192, 15000, 7000, 11000]), 1),
    ("grave bass", [24000, 5000, 2500, 3000], [64, 5200, 26000, 13700], None, -1),
    ("organ stab", [22000, 9000, 0, 6000], [64, 3200, 0, 13500], ("delay", [6144, 14000, 6000, 10000]), 0),
    ("dusk swell", [12000, 14000, 9000, 5000], [11000, 9000, 30000, 3600], ("delay", [9216, 20000, 8000, 14000]), 0),
]


def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def meta(name, knobs, adsr, fx, octave):
    return {
        "adsr": list(adsr) + [2048, 64, 4000, 4000],
        "fx_active": fx is not None,
        "fx_params": (fx[1] if fx else IDLE_FX) + [0, 0, 0, 0],
        "fx_type": fx[0] if fx else "delay",
        "knobs": list(knobs) + [0, 0, 0, 0],
        "lfo_active": False,
        "lfo_params": [16000, 0, 0, 16000, 0, 0, 0, 0],
        "lfo_type": "tremolo",
        "name": name,
        "octave": octave,
        "synth_version": 2,
        "type": "bloodmoon",
    }


def appl(m):
    js = json.dumps(m, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    return chunk(b"APPL", b"op-1" + js)


def aifc(m):
    comm = struct.pack(">hIh", 1, 0, 16) + ieee_extended(44100) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + appl(m)
            + chunk(b"SSND", struct.pack(">II", 0, 0)))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


def main():
    if len(sys.argv) > 2:
        sys.exit(__doc__)
    out = Path(sys.argv[1]) if len(sys.argv) == 2 else HERE / "presets"
    out.mkdir(parents=True, exist_ok=True)
    for p in AUTHOR:                      # the author's files: only check the metadata chunk
        f = HERE / "presets" / (p[0] + ".aif")
        if f.exists() and appl(meta(*p)) not in f.read_bytes():
            sys.exit(f"{p[0]}: metadata differs from the author's file")
    for p in NEW:
        (out / (p[0] + ".aif")).write_bytes(aifc(meta(*p)))
    print(f"{len(NEW)} new presets in {out} ({len(AUTHOR)} author files unchanged)")


if __name__ == "__main__":
    main()
