/* JUNI's filter and chorus voicing, imported from FM-106 and Ultramaster KR-106 (see PROVENANCE.md).
 *
 * FM-106 (https://github.com/PatttF/fm-106, commit 48ca1b6): firmware/src/fm106_vcf.h (fm106_vcf_process: the
 * four-stage TPT ladder, the linear feedback predictor, the BA662 OTA saturation of the feedback difference, the
 * input ratios 0.065 / 0.142, the 1 / (1 + kG) solve, the k fade near Nyquist), firmware/src/fm106_tables.h
 * (FM106_RES_K, FM106_FB_SCALE, FM106_INV_FB_SCALE, FM106_PEAK_PULL, FM106_OTA_SAT below, unchanged) and
 * firmware/src/fm106_chorus.h (the chorus rates, depths, centre and the 0.863 : 1.257 dry : wet ratio).
 * FM-106's DSP is adapted from Ultramaster KR-106 (https://github.com/kayrockscreenprinting/ultramaster_kr106, commit
 * bc15cae; Source/DSP/KR106VCF.h, KR106Chorus.h).
 *   Copyright (C) 2026 PatttF (FM-106)
 *   Copyright (C) 2001, 2026 Karl LaRocca (Kayrock Screenprinting) and David Mansfield (Ultramaster KR-106)
 * Their authors gave the owner permission (2026-11-15, as the owner reported it) to use this code in kennel under
 * kennel's terms. Changes by Hundekraft (2026): fixed point for the Blackfin (no FPU), the cutoff from JUNI's
 * semitone law instead of the 106 DAC law and its measured G1 table, coefficients per 8-sample control step, the
 * Pade curve read from FM106_OTA_SAT (no divide), 1 / (1 + kG) from a table (gen_tables.py), the chorus mono, one tap
 * per voice, at half rate inside the voice.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifndef JUNI_106_H
#define JUNI_106_H

/* resonance fader 0..127 -> feedback k, Q12 (FM106_RES_K) */
static const uint16_t J106_RES_K[128] = {
    0, 150, 303, 457, 614, 772, 932, 1093, 1256, 1420, 1586, 1753, 1921, 2090, 2260, 2431,
    2602, 2775, 2948, 3121, 3295, 3469, 3643, 3818, 3992, 4167, 4341, 4516, 4690, 4864, 5037, 5210,
    5383, 5555, 5726, 5897, 6067, 6236, 6404, 6571, 6737, 6903, 7067, 7230, 7391, 7552, 7711, 7869,
    8025, 8180, 8333, 8485, 8635, 8783, 8930, 9075, 9218, 9360, 9500, 9637, 9773, 9907, 10039, 10169,
    10297, 10423, 10547, 10669, 10788, 10906, 11021, 11134, 11245, 11354, 11461, 11565, 11667, 11767, 11864, 11959,
    12052, 12143, 12231, 12317, 12401, 12482, 12561, 12638, 12712, 12784, 12858, 12937, 13020, 13107, 13199, 13295,
    13396, 13502, 13612, 13727, 13846, 13970, 14098, 14232, 14369, 14512, 14659, 14812, 14968, 15130, 15223, 15248,
    15272, 15293, 15313, 15523, 15741, 15957, 16173, 16387, 16599, 16811, 17021, 17229, 17436, 17642, 17847, 18050
};
static const uint16_t J106_FB_SCALE[128] = {
    5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161,
    5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161,
    5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161,
    5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161,
    5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5161, 5565, 5993, 6413, 6821, 7220,
    7610, 7993, 8362, 8723, 9076, 9416, 9748, 10072, 10382, 10685, 10996, 11327, 11676, 12041, 12428, 12831,
    13255, 13700, 14162, 14645, 15145, 15666, 16204, 16766, 17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203,
    17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203, 17203
};
static const uint16_t J106_INV_FB_SCALE[128] = {
    3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251,
    3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251,
    3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251,
    3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251,
    3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3251, 3015, 2799, 2616, 2460, 2324,
    2205, 2099, 2006, 1923, 1848, 1782, 1721, 1666, 1616, 1570, 1526, 1481, 1437, 1393, 1350, 1308,
    1266, 1225, 1185, 1146, 1108, 1071, 1035, 1001, 975, 975, 975, 975, 975, 975, 975, 975,
    975, 975, 975, 975, 975, 975, 975, 975, 975, 975, 975, 975, 975, 975, 975, 975
};
static const uint16_t J106_PEAK_PULL[128] = {
    4096, 4127, 4158, 4189, 4221, 4252, 4284, 4316, 4347, 4379, 4411, 4443, 4474, 4505, 4537, 4568,
    4599, 4630, 4660, 4690, 4720, 4750, 4779, 4809, 4837, 4851, 4845, 4838, 4831, 4824, 4818, 4811,
    4805, 4798, 4792, 4785, 4779, 4773, 4766, 4760, 4754, 4748, 4742, 4736, 4730, 4724, 4718, 4712,
    4706, 4701, 4695, 4689, 4684, 4678, 4672, 4667, 4661, 4656, 4651, 4645, 4640, 4635, 4630, 4624,
    4619, 4614, 4609, 4605, 4600, 4595, 4590, 4586, 4581, 4576, 4572, 4568, 4563, 4559, 4555, 4551,
    4547, 4543, 4539, 4535, 4532, 4528, 4524, 4521, 4518, 4514, 4511, 4508, 4504, 4500, 4496, 4491,
    4486, 4481, 4476, 4471, 4465, 4459, 4453, 4446, 4439, 4432, 4425, 4417, 4409, 4400, 4388, 4384,
    4380, 4377, 4374, 4342, 4311, 4281, 4254, 4229, 4205, 4184, 4164, 4147, 4131, 4117, 4105, 4096
};
/* FM106_OTA_SAT[257] (0..3 in 256 steps), mirrored to -3..3 (index 256 = 0), one more 32767 at the top (t = 65535 + 1) */
const int16_t j106_ota_sat[514] = {           /* global: juni_ladder.S reads it */
    -32767, -32767, -32767, -32767, -32767, -32767, -32767, -32767, -32767, -32767, -32766, -32766, -32766, -32766, -32766, -32765,
    -32765, -32764, -32764, -32763, -32763, -32762, -32761, -32760, -32759, -32758, -32757, -32756, -32754, -32753, -32751, -32749,
    -32748, -32746, -32743, -32741, -32739, -32736, -32733, -32730, -32727, -32724, -32720, -32717, -32713, -32708, -32704, -32699,
    -32695, -32689, -32684, -32678, -32672, -32666, -32660, -32653, -32646, -32638, -32631, -32623, -32614, -32605, -32596, -32586,
    -32576, -32566, -32555, -32544, -32532, -32520, -32508, -32495, -32481, -32467, -32452, -32437, -32422, -32406, -32389, -32371,
    -32353, -32335, -32316, -32296, -32275, -32254, -32232, -32210, -32186, -32162, -32137, -32112, -32085, -32058, -32030, -32001,
    -31971, -31941, -31909, -31877, -31843, -31809, -31773, -31737, -31699, -31661, -31621, -31580, -31538, -31495, -31451, -31406,
    -31359, -31311, -31262, -31212, -31160, -31107, -31053, -30997, -30939, -30881, -30820, -30759, -30695, -30631, -30564, -30496,
    -30426, -30355, -30282, -30207, -30131, -30052, -29972, -29890, -29806, -29720, -29632, -29542, -29451, -29357, -29261, -29163,
    -29062, -28960, -28855, -28749, -28639, -28528, -28414, -28298, -28180, -28059, -27935, -27809, -27681, -27550, -27416, -27280,
    -27141, -26999, -26855, -26708, -26558, -26405, -26250, -26091, -25930, -25766, -25599, -25428, -25255, -25079, -24900, -24717,
    -24532, -24343, -24152, -23957, -23759, -23557, -23353, -23145, -22934, -22719, -22502, -22281, -22057, -21829, -21598, -21364,
    -21126, -20885, -20641, -20393, -20142, -19887, -19630, -19368, -19104, -18836, -18565, -18290, -18012, -17731, -17447, -17159,
    -16868, -16574, -16277, -15976, -15673, -15366, -15056, -14744, -14428, -14109, -13787, -13463, -13135, -12805, -12472, -12137,
    -11799, -11458, -11114, -10769, -10421, -10070, -9717, -9362, -9005, -8646, -8285, -7922, -7557, -7190, -6822, -6452,
    -6081, -5708, -5333, -4958, -4581, -4203, -3824, -3445, -3064, -2683, -2301, -1918, -1535, -1152, -768, -384,
    0, 384, 768, 1152, 1535, 1918, 2301, 2683, 3064, 3445, 3824, 4203, 4581, 4958, 5333, 5708,
    6081, 6452, 6822, 7190, 7557, 7922, 8285, 8646, 9005, 9362, 9717, 10070, 10421, 10769, 11114, 11458,
    11799, 12137, 12472, 12805, 13135, 13463, 13787, 14109, 14428, 14744, 15056, 15366, 15673, 15976, 16277, 16574,
    16868, 17159, 17447, 17731, 18012, 18290, 18565, 18836, 19104, 19368, 19630, 19887, 20142, 20393, 20641, 20885,
    21126, 21364, 21598, 21829, 22057, 22281, 22502, 22719, 22934, 23145, 23353, 23557, 23759, 23957, 24152, 24343,
    24532, 24717, 24900, 25079, 25255, 25428, 25599, 25766, 25930, 26091, 26250, 26405, 26558, 26708, 26855, 26999,
    27141, 27280, 27416, 27550, 27681, 27809, 27935, 28059, 28180, 28298, 28414, 28528, 28639, 28749, 28855, 28960,
    29062, 29163, 29261, 29357, 29451, 29542, 29632, 29720, 29806, 29890, 29972, 30052, 30131, 30207, 30282, 30355,
    30426, 30496, 30564, 30631, 30695, 30759, 30820, 30881, 30939, 30997, 31053, 31107, 31160, 31212, 31262, 31311,
    31359, 31406, 31451, 31495, 31538, 31580, 31621, 31661, 31699, 31737, 31773, 31809, 31843, 31877, 31909, 31941,
    31971, 32001, 32030, 32058, 32085, 32112, 32137, 32162, 32186, 32210, 32232, 32254, 32275, 32296, 32316, 32335,
    32353, 32371, 32389, 32406, 32422, 32437, 32452, 32467, 32481, 32495, 32508, 32520, 32532, 32544, 32555, 32566,
    32576, 32586, 32596, 32605, 32614, 32623, 32631, 32638, 32646, 32653, 32660, 32666, 32672, 32678, 32684, 32689,
    32695, 32699, 32704, 32708, 32713, 32717, 32720, 32724, 32727, 32730, 32733, 32736, 32739, 32741, 32743, 32746,
    32748, 32749, 32751, 32753, 32754, 32756, 32757, 32758, 32759, 32760, 32761, 32762, 32763, 32763, 32764, 32764,
    32765, 32765, 32766, 32766, 32766, 32766, 32766, 32767, 32767, 32767, 32767, 32767, 32767, 32767, 32767, 32767,
    32767, 32767
};

/* The ladder's coefficients for one control step (Q15 unless named): G the TPT stage gain g / (1 + g); C0..C3 the
 * linear predictor of the feedback, (1 - G) G^3, (1 - G) G^2, (1 - G) G, (1 - G); IN the OTA's + input (0.065); F14 the OTA's input scale
 * (FB_SCALE / 3, Q14, so the table index comes out in Q8 of 256 steps over 0..3); DG the direct input path
 * 0.142 / (1 + kG); KO the resonance path k * INV_FB_SCALE / (1 + kG), Q13 */
typedef struct { int16_t in, f14, c0, c1, c2, c3, dg, ko, g, pad; } j106_k_t;   /* juni_ladder.S reads it as 5 words */

/* (e * c) >> 15 for a 32-bit e (|e| < 2^30) and 0 <= c < 2^15, rounded: two 16 x 16 products (control rate and the
 * chorus; the ladder's sample loop uses one product on e >> 3) */
static inline __attribute__((always_inline)) int32_t mq15(int32_t e, int32_t c)
{
    return (int32_t)(int16_t)(e >> 15) * (int16_t)c + (int32_t)(((uint32_t)(uint16_t)(e & 0x7FFF) * (uint16_t)c + 16384u) >> 15);
}

#define J106_IN 2130                            /* the OTA's + input: x * 0.065, Q15 */

/* The ladder through nc control steps of 8 samples: x in (1.0 = 2^16), y3 * 8 out (FM-106's makeup gain is 8.59).
 * It runs in 1.0 = 2^29: each product is a fractional multiply (a * b * 2, 1.31) of a value's high half (2^-13 of 1.0,
 * the resolution of the 16-bit ladder JUNI had before) and a 16-bit coefficient; the states keep 32 bits. Exactly:
 *   in   = x >> 3                                                         (16 bits: |x| < 2^18)
 *   diff = sat32(in IN 2 - sum (z_i >> 16) c_i 2)                         (the sum in 40 bits, as the MACs)
 *   t    = sat32(fr(diff >> 16, f14) << 3) >> 15                          (-65536..65535: Q16 of 3.0)
 *   sat  = T[t >> 8] + ((T[(t >> 8) + 1] - T[t >> 8]) (t & 255) >> 8)    (T = j106_ota_sat, centred)
 *   u    = sat32(sat32(in dg 2 + sat ko 2) << 1) >> 1                     (clamped to +-2.0)
 *   per stage: e = sat(u - z); d = fr(e >> 16, g); y = sat(z + d); z = sat(y + d); u = y
 *   x    = y3 >> 10
 * juni_ladder.S does exactly this on the Blackfin (kern_check.py); this C is the host build and its reference. */
static inline __attribute__((always_inline)) int32_t j106_sat32(int64_t v)
{ return v > 0x7FFFFFFF ? 0x7FFFFFFF : v < -0x7FFFFFFF - 1 ? -0x7FFFFFFF - 1 : (int32_t)v; }
static inline __attribute__((always_inline)) int32_t j106_fr(int32_t a, int32_t b)   /* a, b 16-bit; no -1 x -1 here */
{ return (int32_t)(int16_t)a * (int16_t)b * 2; }
static inline __attribute__((always_inline)) int32_t j106_adds(int32_t a, int32_t b) { return j106_sat32((int64_t)a + b); }
static inline __attribute__((always_inline)) int32_t j106_subs(int32_t a, int32_t b) { return j106_sat32((int64_t)a - b); }

/* one control step's ladder coefficients (RCP from juni_tables.h): g the stage gain (Q15), ri the resonance fader (0..127), fade KFADE (Q15) */
static inline void ladder_coef(j106_k_t *q, int32_t g, int32_t ri, int32_t fade)
{
    g = (g * J106_PEAK_PULL[ri]) >> 12;         /* the resonant peak lands on the cutoff */
    if (g > 26423) g = 26423;                   /* FM-106's top, 0.806 */
    const int32_t k = (J106_RES_K[ri] * fade) >> 15;                   /* Q12 */
    const int32_t g2 = (g * g) >> 15, g3 = (g2 * g) >> 15, g4 = (g2 * g2) >> 15, h = 32768 - g;
    const int32_t t = (k * g4) >> 15;                                  /* k G^4, Q12 */
    const int32_t ti = t >> 7 < 127 ? t >> 7 : 127, tf = t >> 7 < 127 ? t & 127 : 127;
    const int32_t inv = RCP[ti] + (((RCP[ti + 1] - RCP[ti]) * tf) >> 7);   /* 1 / (1 + k G^4), Q15 */
    q->g = (int16_t)g; q->in = J106_IN; q->pad = 0;
    q->c0 = (int16_t)((g3 * h) >> 15); q->c1 = (int16_t)((g2 * h) >> 15); q->c2 = (int16_t)((g * h) >> 15);
    q->c3 = (int16_t)(h > 32767 ? 32767 : h);
    q->f14 = (int16_t)((J106_FB_SCALE[ri] * 21845) >> 14);           /* x 4 / 3 */
    q->dg = (int16_t)((4653 * inv) >> 15);                             /* x 0.142 */
    q->ko = (int16_t)((((k * J106_INV_FB_SCALE[ri]) >> 12) * inv) >> 14);   /* Q13 */
}

#if defined(__bfin__) && !defined(JUNI_C_LOOP)
void j106_ladder_k(int32_t *z, int32_t *x, const j106_k_t *ks, int nc);
#define j106_ladder j106_ladder_k
#else
static void j106_ladder(int32_t *z, int32_t *x, const j106_k_t *ks, int nc)
{
    int32_t z0 = z[0], z1 = z[1], z2 = z[2], z3 = z[3];
    const int16_t *T = j106_ota_sat + 256;
    for (int c = 0; c < nc; c++) {
        const j106_k_t q = ks[c];
        for (int i = 0; i < 8; i++, x++) {
            const int32_t in = *x >> 3;
            const int64_t s = (int64_t)j106_fr(z0 >> 16, q.c0) + j106_fr(z1 >> 16, q.c1) + j106_fr(z2 >> 16, q.c2)
                            + j106_fr(z3 >> 16, q.c3);
            const int32_t diff = j106_sat32((int64_t)j106_fr(in, q.in) - s);
            const int32_t t = j106_sat32((int64_t)j106_fr(diff >> 16, q.f14) * 8) >> 15;
            const int32_t ti = t >> 8, a = T[ti];
            const int32_t sat = a + (((T[ti + 1] - a) * (t & 255)) >> 8);
            const int32_t u = j106_sat32((int64_t)j106_sat32((int64_t)j106_fr(in, q.dg) + j106_fr(sat, q.ko)) * 2) >> 1;
            int32_t d, y;
            d = j106_fr(j106_subs(u, z0) >> 16, q.g); y = j106_adds(z0, d); z0 = j106_adds(y, d);
            d = j106_fr(j106_subs(y, z1) >> 16, q.g); y = j106_adds(z1, d); z1 = j106_adds(y, d);
            d = j106_fr(j106_subs(y, z2) >> 16, q.g); y = j106_adds(z2, d); z2 = j106_adds(y, d);
            d = j106_fr(j106_subs(y, z3) >> 16, q.g); y = j106_adds(z3, d); z3 = j106_adds(y, d);
            *x = y >> 10;
        }
    }
    z[0] = z0; z[1] = z1; z[2] = z2; z[3] = z3;
}
#endif

/* the chorus (FM106 chorus figures at 44.1 kHz): centre 154 samples (3.5 ms); I 0.514 Hz +-81 samples, II 0.863 Hz
 * +-75 samples, I+II 9.75 Hz +-9 samples (the triangle rounded to 1.5 x - 0.5 x^3); dry 0.863, wet 1.257 */
#define J106_CHO_C   (154 * 256)                /* Q8 internal samples (44.1 kHz) */
#define J106_DEP_I   (81 * 256)
#define J106_DEP_II  (75 * 256)
#define J106_DEP_III (9 * 256)
#define J106_HZ_I    0.514
#define J106_HZ_II   0.863
#define J106_HZ_III  9.75
#define J106_DRY     21209                      /* 0.863, Q15 */
#define J106_WET     30892                      /* 1.257, Q15 */

#endif
