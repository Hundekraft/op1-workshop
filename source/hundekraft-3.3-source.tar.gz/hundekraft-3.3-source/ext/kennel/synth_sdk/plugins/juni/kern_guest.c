/* JUNI's Blackfin ladder kernel (juni_ladder.S) against its C (juni_106.h with JUNI_C_LOOP) on bcore (kern_check.py):
 * the same blocks through both, compared sample by sample and state by state. Coefficients come from ladder_coef over
 * random cutoffs (the whole table, MIDI 0..132), every resonance fader value and fade; inputs are full-scale DCO-like
 * waves, noise, silence and the extremes (|x| < 2^18); states start random, at the rails or at zero. Prints
 * "KERN ok blocks=N" or the first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdint.h>
#define JUNI_C_LOOP
#include "juni_tables.h"
#include "juni_106.h"
void j106_ladder_k(int32_t *z, int32_t *x, const j106_k_t *ks, int nc);
void t2_write(const char *, int);
uint32_t t2_r246_calls[2];
static unsigned blocks, bad;
static char line[128];
static int n;
static void put(const char *p) { while (*p) line[n++] = *p++; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = '0' + v % 10; while (v /= 10); put(b + i); }
static uint32_t rng = 777;
static uint32_t rnd(void) { rng = rng * 1664525u + 1013904223u; return rng; }

int main(void)
{
    int32_t za[4], zb[4], xa[64], xb[64];
    j106_k_t ks[8];
    for (unsigned s = 0; s < 4000 && !bad; s++) {
        const unsigned mode = s % 5;
        for (int c = 0; c < 8; c++) {
            const int32_t note = (int32_t)(rnd() % (CUT_MAX * 256));
            const int32_t ni = note >> 8, nf = note & 255;
            const int32_t ri = mode == 4 ? 127 : (int32_t)(rnd() % 128);
            ladder_coef(&ks[c], CUT_G[ni] + (((CUT_G[ni + 1] - CUT_G[ni]) * nf) >> 8), ri, KFADE[ni]);
        }
        if (s % 7 == 0) for (int i = 0; i < 4; i++) za[i] = (int32_t)rnd() >> (rnd() & 1 ? 1 : 2);
        else if (s % 7 == 1) for (int i = 0; i < 4; i++) za[i] = rnd() & 1 ? 0x7FFFFFFF : -0x7FFFFFFF - 1;
        else if (s % 7 == 2) for (int i = 0; i < 4; i++) za[i] = 0;
        uint32_t ph = rnd(), inc = rnd() >> (4 + rnd() % 8);
        for (int i = 0; i < 64; i++) {
            int32_t v;
            if (mode == 0) v = (int32_t)(ph >> 15) - 65536;                          /* a saw, +-1.0 */
            else if (mode == 1) v = (int32_t)rnd() >> 14;                              /* noise, +-2^17 */
            else if (mode == 2) v = 0;
            else if (mode == 3) v = rnd() & 1 ? (1 << 18) - 1 : -(1 << 18) + 1;        /* the extremes */
            else v = ((int32_t)(ph >> 15) - 65536) >> 4;                               /* quiet, resonance at the top */
            ph += inc;
            xa[i] = v;
        }
        for (int i = 0; i < 4; i++) zb[i] = za[i];
        for (int i = 0; i < 64; i++) xb[i] = xa[i];
        j106_ladder_k(za, xa, ks, 8);
        j106_ladder(zb, xb, ks, 8);
        blocks++;
        for (int i = 0; i < 64 && !bad; i++)
            if (xa[i] != xb[i]) { bad = 1; put("KERN differ x block="); num(blocks); put(" i="); num((uint32_t)i); put("\n"); }
        for (int i = 0; i < 4 && !bad; i++)
            if (za[i] != zb[i]) { bad = 1; put("KERN differ z block="); num(blocks); put(" i="); num((uint32_t)i); put("\n"); }
    }
    if (!bad) { put("KERN ok blocks="); num(blocks); put("\n"); }
    t2_write(line, n);
    return 0;
}
