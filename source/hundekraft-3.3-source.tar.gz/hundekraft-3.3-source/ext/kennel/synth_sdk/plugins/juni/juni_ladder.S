/* JUNI's ladder (juni_106.h j106_ladder: FM-106's TPT ladder with the OTA on the feedback) hand-scheduled for the
 * Blackfin, bit for bit with the C (the host build and kern_check.py's reference, JUNI_C_LOOP).
 *
 * void j106_ladder_k(int32_t *z, int32_t *x, const j106_k_t *ks, int nc): nc control steps of 8 samples of x in place;
 * z = the four states; ks = per step 5 words: in | f14, c0 | c1, c2 | c3, dg | ko, g | 0 (low | high half).
 * A1 takes in IN minus the predictor's four products (40 bits) and gives the OTA's input difference with saturation
 * (sat32); A0 takes in dg plus sat ko and gives u. Saturating adds and shifts are the C's j106_sat32 cases. 50 packets
 * a sample.
 * Registers: R4..R7 the states z0..z3; R0 in, then u; R1, R2 coefficient words; R3 work; I0 reads x, P0 writes
 * it; I1 walks a step's coefficients (rewound by M2 = 20 each sample, advanced by it each step); P2 = &T[256].
 * L0 and L1 saved and zeroed (R246 may leave them set); M1 is not touched (R246's PmSynth keeps its frame there).
 * Host builds assemble it empty.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifdef __bfin__
	.text
	.align 4
	.global _j106_ladder_k
	.type _j106_ladder_k, STT_FUNC
_j106_ladder_k:
	[--SP] = (R7:4, P5:3);
	P5 = R0;                                             /* z */
	P0 = R1;                                             /* x (writes) */
	I0 = R1;                                             /* x (reads) */
	I1 = R2;                                             /* ks */
	R3 = [SP + 40];                                      /* nc: the 4th argument, after 8 saved registers (32) + 12 */
	P4 = R3;
	R3 = L0;
	[--SP] = R3;
	R3 = L1;
	[--SP] = R3;
	R3 = 0;
	L0 = R3;
	L1 = R3;
	R3 = 20;
	M2 = R3;
	P2.L = _j106_ota_sat + 512;
	P2.H = _j106_ota_sat + 512;
	R4 = [P5];
	R5 = [P5 + 4];
	R6 = [P5 + 8];
	R7 = [P5 + 12];
	P3 = 8;
	R0 = [I0++];
	LSETUP (.Lc_b, .Lc_e) LC1 = P4;
.Lc_b:
	LSETUP (.Ls_b, .Ls_e) LC0 = P3;
.Ls_b:
	R0 = R0 >>> 3 (S) || R1 = [I1++];                    /* in; in | f14 */
	A1 = R0.L * R1.L || R2 = [I1++];                     /* in IN; c0 | c1 */
	A1 -= R4.H * R2.L;                                   /* - c0 z0 */
	A1 -= R5.H * R2.H || R2 = [I1++];                    /* - c1 z1; c2 | c3 */
	A1 -= R6.H * R2.L;                                   /* - c2 z2 */
	R3 = (A1 -= R7.H * R2.H) || R2 = [I1++];             /* diff = sat32(in IN - S); dg | ko */
	R3 = R3.H * R1.H;                                    /* fr(diff >> 16, f14) */
	A0 = R0.L * R2.L;                                    /* in dg */
	R3 = R3 << 3 (S);
	R3 >>>= 15;                                          /* t */
	R1 = R3 >>> 8;
	P1 = R1;
	R3 = R3.B (Z);                                       /* t & 255 */
	P1 = P2 + (P1 << 1);
	R1 = W [P1] (X);                                     /* a */
	R0 = W [P1 + 2] (X);                                 /* b */
	R0 = R0 - R1;
	R0 = R0.L * R3.L (IS);
	R0 >>>= 8;
	R1 = R1 + R0;                                        /* sat */
	R0 = (A0 += R1.L * R2.H) || R1 = [I1++];             /* u = sat32(in dg + sat ko); g */
	R0 = R0 << 1 (S);
	R0 >>>= 1;                                           /* u, within +-2.0 */
	I1 -= M2;
	R2 = R0 - R4 (S);                                    /* stage 0: e */
	R2 = R2.H * R1.L;                                    /* d */
	R3 = R4 + R2 (S);                                    /* y0 */
	R4 = R3 + R2 (S);                                    /* z0 */
	R2 = R3 - R5 (S);
	R2 = R2.H * R1.L;
	R3 = R5 + R2 (S);
	R5 = R3 + R2 (S);
	R2 = R3 - R6 (S);
	R2 = R2.H * R1.L;
	R3 = R6 + R2 (S);
	R6 = R3 + R2 (S);
	R2 = R3 - R7 (S);
	R2 = R2.H * R1.L;
	R3 = R7 + R2 (S);
	R7 = R3 + R2 (S);
	R3 >>>= 10;                                          /* y3 >> 10 */
.Ls_e:
	MNOP || [P0++] = R3 || R0 = [I0++];                  /* x; the next x */
.Lc_e:
	I1 += M2;
	[P5] = R4;
	[P5 + 4] = R5;
	[P5 + 8] = R6;
	[P5 + 12] = R7;
	R3 = [SP++];
	L1 = R3;
	R3 = [SP++];
	L0 = R3;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _j106_ladder_k, .-_j106_ladder_k
#endif
