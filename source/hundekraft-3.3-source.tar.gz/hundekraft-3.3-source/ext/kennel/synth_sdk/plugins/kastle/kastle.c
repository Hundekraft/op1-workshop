/* KASTLE: displayname808's castle 1.0 as a kennel synth plugin (kastle.knl), matched to displayname808's castle 1.0
 * with castle 1.1's feedback, 25 ratio sets and log anti-repeat (binary sha256 0e699069...bde204)
 * (GPL-3.0 as the owner reported it, 2026-11-10; binary sha256 88214a82...07cd; PROVENANCE.md, OP1-Emulator
 * docs/ports/kastle-spec.md). This file is kennel's glue: the engine's callbacks and the screen.
 *
 * A note fades in over 2 s; with drone mode on (the orange push, word 7 bit 7, off for a new sound) it keeps sounding
 * after the key goes up, up to three keys held together make a chord, and the next note crossfades to a new drone.
 * Blue fm operator mix, green coarse ratio set, white feedback, orange saturation. Shift + blue the algorithm (8 steps,
 * word 5), Shift + green pitch modulation (word 6), Shift + white noise / drop-outs / mild reducer (word 7 bits 0..6),
 * Shift + orange ring modulator (word 7 bits 8..14), each 0..99 in castle's steps of 3 (the core's op1_engine_shift).
 * White push: the castle log; orange push: drone mode. T2 is castle's help page, as in castle 1.0 (t2_page; the
 * knobs do nothing there, t2_swallow; Shift shows R246's play-mode page). The engine shapes its own level
 * (own_envelope), so R246's envelope does not run for its sounds and velocity is ignored.
 *
 * In place of castle's host services: the six voices' state, set up on first use, leased into the L1 pool's synth
 * partition with the buffers and the sine after it (op1_l1_claim_state, home ka_voices; else all of it in SDRAM), as
 * castle's host keeps its voices in fast memory; castle's block callback as the core's voice-sum block (sum_block: ring
 * modulator, mild reducer, the block count); a new block whenever a voice at or below the last rendered index renders
 * (R246 renders in index order), when castle's words are made (kastle_castle_words).
 * The lease's rules (op1_l1.h): note_on and render claim first and reach the voices only through what the claim
 * returned, for that call; note_off and finished read and write only ka_keys (SDRAM, outside the state), the screen
 * neither.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "op1_plugin.h"
#include "kastle_voice.h"
#include "kastle_page.h"
#include "kastle_help.h"
#include "kastle_log.h"
#include "../../hk/eng_push.h"

static volatile uint8_t ready[OP1_VOICES];                 /* a byte each: note_on runs on the key thread */
static int last_voice = OP1_VOICES;
static unsigned seen_blocks = ~0u;                         /* ka_blocks at the last block's first voice */
static int16_t cw[8];                                      /* castle's words, this block */

/* where this call works: the voices in the L1 pool (the buffers and the sine KA_STATE_AT after them; fresh: the sine
 * copied in), or ka_voices when there is no pool or another engine still holds it (*fast = 0: SDRAM buffers) */
static struct ka_voice *claim(void **fast)
{
#ifndef OP1_HOST
    _Static_assert(KA_STATE_BYTES % 4 == 0 && KA_L1_BYTES <= 8192, "the voices, then the buffers and the sine, in OP1_L1_SYNTH");
    int fresh;
    uint8_t *l = op1_l1_claim_state(OP1_L1_SYNTH, ka_voices, KA_STATE_BYTES, KA_L1_BYTES, &fresh);
    if (l) {
        if (fresh) ka_sine_fill(l + KA_STATE_AT);
        *fast = l + KA_STATE_AT;
        return (struct ka_voice *)(void *)l;
    }
#endif
    *fast = 0;
    return ka_voices;
}

static struct ka_voice *voices(void *self, void **fast)   /* this call's voices, the voice set up on first use */
{
    struct ka_voice *const vs = claim(fast);
    const int v = op1_voice_index(self);
    if (!ready[v]) { ka_voice_init(vs, v); ready[v] = 1; }
    return vs;
}

static void kastle_note_on(void *self, const int16_t *params)
{
    void *fast;
    struct ka_voice *const vs = voices(self, &fast);
    ka_drone = kastle_drone_of(params);
    ka_note_on(vs, op1_voice_index(self));
}

static void kastle_render(void *self, int16_t *out, const int16_t *params)
{
    void *fast;
    struct ka_voice *const vs = voices(self, &fast);
    const int vi = op1_voice_index(self);
    if (vi <= last_voice) {                                   /* a new block (R246 renders in index order) */
        if (ka_blocks == seen_blocks)                         /* the core ran no sum block since the last one */
            ka_block_begin();
        seen_blocks = ka_blocks;
        kastle_castle_words(params, cw);
        ka_drone = kastle_drone_of(params);
    }
    last_voice = vi;
    ka_fast(fast, 0);
    ka_render(vs, vi, out, cw, (const uint32_t *)OP1_PITCH_INC);
}

/* note_off (VoiceCtl's thread) and finished: ka_keys only, never the leased voices. A voice not yet set up has no key
 * down (ka_keys starts zero) and is finished, as castle's freshly made voice is. */
static void kastle_note_off(void *self)
{
    ka_release(op1_voice_index(self));
}

static int kastle_finished(void *self)
{
    const int v = op1_voice_index(self);
    return ready[v] ? ka_finished(v) : 1;
}

/* castle's block callback: its voice-sum stage once a block on the summed voices (the core's sum block, 64 samples at
 * 44.1 kHz before the synth FX). It also counts castle's blocks. Castle never resets the stage, so fresh is unused. */
static void kastle_block(int16_t *bus, int fresh)
{
    (void)fresh;
    ka_sum_block(bus);
}

static const op1_screen_t SCREEN_kastle_help;

/* own envelope (finished), voice-sum block (block) and its own T2 page (t2): the 28-byte op1_engine_ext_t */
const op1_engine_ext_t ENGINE_kastle = {
    { kastle_note_on, kastle_render, kastle_note_off, { OP1_PRESS_NONE, OP1_PRESS_NONE, OP1_PRESS_PAGE, OP1_PRESS_PAGE } },
    kastle_finished,
    kastle_block,
    &SCREEN_kastle_help,
};

/* ---- the screen (GUI thread) ----
 * castle's T1 page (kastle_page.c), its village and log (kastle_log.c) and the log window (kastle_help.c),
 * driven as castle's host drives them: the page each frame with castle's eight words (the four live knobs, the
 * algorithm, ring and noise words as castle keeps them), its clock, drone mode, the output's peak, the noise in six
 * steps and the pitch modulation; the village's main pass on its own clock; castle's key and Shift-turn events.
 * Pushes: white the log window (castle's white push), orange drone mode (castle's orange push, in the sound's word 7);
 * blue and green do nothing. Castle's help is the T2 page (SCREEN_kastle_help, below), as in castle 1.0.
 * Neither page touches the voices (leased state): they read the slot's words, ka_peak and the page's own state. */
static uint8_t loaded, log_open, started, seen;
static int seen_slot = -1;
static int16_t seen_engine, seen_w7;
static int seen_noise;
static int32_t village_ms;                                   /* the village's clock (castle's main pass, 0x2800400) */

static void kastle_load_once(void)
{
    if (!loaded) {                                           /* castle's module entry (0x2800694): once */
        loaded = 1;
        kastle_page_init();
#ifndef OP1_HOST
        uint32_t c;
        __asm__ volatile ("%0 = CYCLES;" : "=d"(c));
        kl_init(c);                                          /* castle seeds its village from CYCLES */
#else
        kl_init(12345);
#endif
        kastle_page_reset();                                 /* castle's engine init for voice 0 (0x28095a8) */
    }
}

static void kastle_screen_init(void *scr)
{
    (void)scr;
    kastle_load_once();
    op1_engine_shift(&ENGINE_kastle.voice, 0, 8);            /* Shift + blue: the algorithm, 8 steps (word 5) */
    op1_engine_shift(&ENGINE_kastle.voice, 1, KA_STEPS3);    /* Shift + green: pitch modulation (word 6) */
    op1_engine_shift(&ENGINE_kastle.voice, 2, KA_STEPS3);    /* Shift + white: noise / mild reducer (word 7 bits 0..6) */
    op1_engine_shift(&ENGINE_kastle.voice, 3, KA_STEPS3);    /* Shift + orange: ring modulator (word 7 bits 8..14) */
}

/* A push's wobble: a page-2 turn of word 7 made while the page flag was set. The core adds delta / 4 to the whole word,
 * 256 an encoder event, so it lands in the ring field (bits 8..14) a few steps. Put back only that field, only when it
 * moved 1..4 steps: a word-7 write the screen has not seen yet (a sound loaded in the same frame, Shift + white,
 * the native probe's poke) is kept (2026-11-13: v1 put the whole word back and lost it) */
static void kastle_unwobble(int16_t *w)
{
    const int d = ((w[7] >> 8) & 127) - ((seen_w7 >> 8) & 127);
    if (d && d >= -4 && d <= 4) w[7] = (int16_t)((w[7] & ~0x7F00) | (seen_w7 & 0x7F00));
}

static void kastle_screen_update(void *scr, int dt)
{
    const int slot = OP1_SCREEN_SLOT & 7;
    int16_t *w = (int16_t *)op1_synth_knobs(slot);
    const int sound = slot != seen_slot || w[4] != seen_engine;
    /* the pushes: each knob's page flag toggles; cleared at once, and a page-2 word a turn changed while it was set is
     * put back (white's and orange's word 7: castle's Shift values) */
    op1_eng_page[0] = 0;
    op1_eng_page[1] = 0;
    if (op1_eng_page[2]) {                                    /* white: the castle log (castle's key 0x3d) */
        op1_eng_page[2] = 0;
        if (seen && !sound) { const int16_t b = w[7]; kastle_unwobble(w); if (w[7] != b) ENG_PUSH_SET_KNOBS(slot, w); }
        log_open = (uint8_t)!log_open;
        if (log_open) kl_event(0);
    }
    if (op1_eng_page[3]) {                                    /* orange: drone mode on / off (castle's key 0x3e) */
        op1_eng_page[3] = 0;
        if (seen && !sound) kastle_unwobble(w);
        w[7] = (int16_t)(w[7] ^ KA_DRONE_ON);
        ENG_PUSH_SET_KNOBS(slot, w);
        kl_event(kastle_drone_of(w) ? 1 : 2);
    }
    const int noise = kastle_noise(w);
    if (sound) kastle_page_reset();                           /* castle re-runs its engine init for a new sound */
    else if (seen && noise != seen_noise) kl_event(3);        /* Shift + white turned (castle's page_turn, 0x2800460) */
    seen_slot = slot;
    seen_engine = w[4];
    seen_w7 = w[7];
    seen_noise = noise;
    seen = 1;
    int closed;
    const unsigned ms = kastle_page_clock(started ? (dt < 0 ? 0 : dt) : -1, &closed);
    if (closed) log_open = 0;                                 /* castle closes its log after a pause */
    if (started && dt > 0) village_ms += dt;
    started = 1;
    kl_step(village_ms);
    int16_t cw[8];                                            /* castle's words: the live knobs, castle's Shift values */
    op1_synth_knobs_live(slot, cw);
    cw[4] = 0;
    cw[5] = (int16_t)((kastle_algo(w) * 0x7FFF + 3) / 7);
    cw[6] = (int16_t)kastle_q99(kastle_ring(w));
    cw[7] = (int16_t)kastle_q99(kastle_noise(w));
    const int pmod = kastle_q99(kastle_pmod(w));
    const int noise5 = (cw[7] * 5 + 0x3fff) / 0x7fff;
    op1_screen_draw_cached(scr, dt, 0);                       /* kastle.svg is empty: the page is all pixels */
    /* the core's frame skip sees no pixel this page writes: feed it what the picture depends on (op1_plugin.h) */
    op1_screen_hash(scr, ms);
    op1_screen_hash(scr, (uint32_t)village_ms);
    for (int i = 0; i < 8; i++) op1_screen_hash(scr, (uint16_t)cw[i]);
    op1_screen_hash(scr, (uint32_t)(kastle_drone_of(w) | log_open << 1 | noise5 << 2 | pmod << 8));
    op1_screen_hash(scr, (uint32_t)ka_peak);
#ifndef OP1_HOST
    const uint32_t *r = op1_raster();
    uint16_t *fb = (uint16_t *)(uintptr_t)r[0];
    const int rows = op1_panel_rows(r);                       /* not r[3]: 400 on the SSD1963 panel too (op1_plugin.h) */
#else
    extern uint16_t host_frame565[400 * 256];                 /* the screen harness's pixel layer (and the tests') */
    uint16_t *fb = host_frame565;
    const int rows = op1_panel_rows_of(host_screen_scale, 400);
    for (int i = 0; i < 400 * 256; ++i) fb[i] = 0;            /* as the core clears the raster */
#endif
    if (!kastle_page_draw(fb, rows, cw, ms, kastle_drone_of(w), ka_peak, noise5, pmod)) return;
    if (log_open) kl_window();
}

const op1_screen_t SCREEN_kastle = { kastle_screen_init, kastle_screen_update };

/* ---- castle's help, the T2 page (GUI thread; the core shows it on T2 while a kastle sound is the current synth
 * slot, and swallows the encoders and pushes there) ----
 * castle 1.0's T2 page (0x2810bac, kastle_help.c): the whole frame, the help title, ten rows and the credit line. */
static void kastle_help_init(void *scr)
{
    (void)scr;
    kastle_load_once();
}

static void kastle_help_update(void *scr, int dt)
{
    op1_screen_draw(scr, dt);                                 /* the page's SVG is empty: the help is all pixels */
    op1_screen_hash(scr, 0x6b68656cu);                        /* for the frame skip: the help's pixels (fixed) */
#ifndef OP1_HOST
    const uint32_t *r = op1_raster();
    uint16_t *fb = (uint16_t *)(uintptr_t)r[0];
    const int rows = op1_panel_rows(r);
#else
    extern uint16_t host_frame565[400 * 256];
    uint16_t *fb = host_frame565;
    const int rows = op1_panel_rows_of(host_screen_scale, 400);
    for (int i = 0; i < 400 * 256; ++i) fb[i] = 0;            /* as the core clears the raster */
#endif
    kl_help(fb, rows);
}

static const op1_screen_t SCREEN_kastle_help = { kastle_help_init, kastle_help_update };
