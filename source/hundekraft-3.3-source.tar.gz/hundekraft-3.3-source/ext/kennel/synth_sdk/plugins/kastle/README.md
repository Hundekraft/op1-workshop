# kastle

kastle is displayname808's castle: a four-operator FM drone with a small castle and its village on the page.

It is rebuilt 1:1 from castle 1.0's compiled plugin (GPL-3.0, as the owner reported it; PROVENANCE.md). Three things
come from castle 1.1 (sha256 0e699069...bde204): less feedback, 25 ratio sets on green, and a log that repeats itself
less (below). Run against castle's own code, the voice matches 1.1 sample for sample, the log's phrase picker matches
1.1, and the page, the rest of the log and the help match 1.0 pixel for pixel. The few places where kastle differs on
purpose are listed below. Every routine's address and law is in OP1-Emulator's
`docs/ports/kastle-spec.md`.

- **Play a key:** the sound fades in over 2 seconds.
- **Orange push:** drone mode on or off. A new sound starts with it off.
  - Off, a note sounds while its key is down and fades over 3 seconds after you let go.
  - On, the note keeps sounding after you let go. Up to three keys held together make one chord. The next note
    crossfades to a new drone, and the same key again carries the sounding drone on.
- **White push:** opens and closes the castle log.
- **T2:** castle's help page, as in castle 1.0. The encoders do nothing there. Shift on T2 still shows the OP-1's
  play mode page.

| Encoder | Turn | Shift + turn |
|---|---|---|
| blue | fm operator mix (operators 2, 3 and 4 come in one after another) | algorithm, 1 to 8 |
| green | coarse ratio set (25 sets) | pitch modulation, 0 to 99 |
| white | feedback (operator 4) | drop-outs, noise, clicks; at the top, a mild sample-rate reducer |
| orange | saturation | ring modulator |

Shift + turns step 3 a detent through 0 to 99, as castle's do. kastle shapes its own level, so the OP-1's envelope
does nothing for its sounds, and velocity is ignored. It needs a core with own-envelope engines and Shift + turn for
engines (2026-11-10, with step counts for white and orange from 2026-11-11), voice-sum blocks (2026-11-11), an
engine's own T2 page with the encoders taken (2026-11-11) and the frame skip's `op1_screen_hash` (2026-11). An older core refuses the file.

## Presets

`presets.py` writes 12 sounds into `presets/` (castle has no program bank): a harmonic hall drone, a low moat bass,
bells, a glass choir, a gritty engine, an old radio with drop-outs, ring-modulated bells, a fifth drone, a storm, warbly
keys, a crushed hymn and deep space. Three of them start in drone mode (word 7 bit 7). The OP-1 envelope does nothing
here, so only the knobs, octave and FX (spring, delay, phone) differ.

## The algorithms

Operator 4 is always fed back. `a > b` means a modulates b.

| Algorithm | Layout | Carriers |
|---|---|---|
| 1 | 4 > 3 > 2 > 1 | 1 |
| 2 | (3 + 4) > 2 > 1 | 1 |
| 3 | 3 > 2 > 1, 4 > 1 | 1 |
| 4 | 4 > 3 > 1, 2 > 1 | 1 |
| 5 | 2 > 1, 4 > 3 | 1 and 3 |
| 6 | 4 > 1, 2 and 3 | 1, 2 and 3 |
| 7 | 4 > 3 | 1, 2 and 3 |
| 8 | none | all four (4 also into the sum) |

An octave-down sine sits under operator 1 at about a quarter of its level.

## The page and the log

The page is castle's isometric island, with the algorithm top left, the smiley top right, the ratios bottom left and
the death toll bottom right. Blue brings rain and streams, green the leaves, white the lightning, and orange the fire. Villagers go
about their chores, horses graze, birds circle, and people fall.

The log follows a village of 151 people, twelve on stage at a time, through 1,500-odd lines of talk, fire, offerings and
deaths. Its text comes from OP1-Emulator's `docs/ports/kastle-log-text.txt`, which the owner edits: run
`python3 make_text.py` here afterwards, and it rewrites `kastle_text.h`. It refuses a character outside castle's font
(a-z, 0-9, space and `:.,?!-'+/`), a line too long for the window, or an unknown placeholder.

## What comes from castle 1.1

- **Feedback** is 30 % weaker: white at the top gives 0.42 where 1.0 gave 0.60. Saved sounds with white turned up
  sound a little different.
- **Green has 25 ratio sets.** The five new ones are 0.5/1.5/2.5/3.5, 1/5/9/11, 1/1.59/2.3/2.92, 1/1.73/3.46/5.2 and
  1/2.14/3.53/5.24, slotted in among the old twenty as castle 1.1 orders them. Castle 1.1 keeps 1.0's twenty steps for
  an older sound until green lands where both agree; kastle always uses the 25 (the owner's choice), so most saved green
  positions pick a different set than before. The ratios bottom left show the set that plays. The log's "ratios up" and
  "ratios down" remarks still count 1.0's twenty steps, as castle 1.1's do.
- **The log repeats itself less.** Each phrase it picks is stamped with a pick counter, and the log passes over a phrase
  picked in the last 600 picks while an unused one is left. That costs 3 KB of RAM.

Not taken from 1.1: its kingdom (kings, elections, revolts and their phrases), the statistics page and its help row,
the new log line kinds and dimming the screen when idle.

## What kennel changed from castle

- **Castle's voice-sum stage** (the ring modulator, the mild reducer and the output peak) runs once a block on the
  44.1 kHz mix, as in castle, in the core's voice-sum block: after R246's decimator and its 35 Hz high-pass, before the
  synth FX. Until 2026-11-11 it ran in each voice at 88.2 kHz (at most -37 dB off castle's mix).
- **The controls live in the sound's words** (words 5, 6 and 7, drone mode in word 7 bit 7). Castle keeps drone mode
  and pitch modulation in its own engine data. Every value castle can reach is reachable.
- **A block** is counted in the sum block, as castle counts it. If the core ever runs no sum block between two
  blocks of voices, the first voice counts it.
- **The help's credit line** reads "Kastle - Hundekraft edition" (the owner's choice; castle's font has no capitals, so it
  draws in lower case). Castle's own line named the host firmware. displayname808 is the original author of castle, and
  kastle stays under castle's GPL-3.0 (PROVENANCE.md).
- **The log's text is the owner's.** The window title reads "kastle log", and the phrase that named the host firmware
  is left out.
- **The log window breaks lines at a word.** Castle splits a word when a long line has no space where it wants to
  break. With the current text that never happens, and `make_text.py` refuses a line that couldn't break at a word.
- **Memory:** the log window and most of the page's dot lists are worked out from their tables each frame instead of
  being kept, and the text is compressed the way castle compresses it. The file loads in 170 KB (166 KB before castle 1.1's
  picker), where castle 1.0 used 259 KB. The price is GUI time: the page takes about three quarters longer a frame.
- **Fast memory:** castle's host keeps its voices in fast memory, and so does kastle. The six voices (1,128 bytes)
  start the L1 pool's synth partition, with the output and modulator buffers and the sine after them: 6,796 of its
  8,192 bytes. When another engine takes the partition, the core copies the voices out, and back in on return. With
  the pool off, or another engine still holding it, everything runs from SDRAM and the samples don't change. A key-up
  and the "finished" test read only a small SDRAM copy (key down, drone id, level above zero, taken over), never the
  leased voices.
- **The page:**
  - the village steps only while the screen is shown;
  - the host's late-frame shedding and castle's fallback page for unknown frame sizes are not ported;
  - the colours are kennel's four encoder colours;
  - the page sine is the textbook one, which stands in for the host's.

## Checks

- **`test/orc.py`** runs castle's own code from its binary on bcore next to kastle's, with the same inputs. The binary
  is read at test time from `KASTLE_REF_IMAGE` and never stored. Results:
  - **Voice** (`-D OURS`, castle 1.1, its 25-set switch on): 300 scenarios, 55,800 blocks x 6 voices, 0 samples differ.
    They cover every algorithm, cross-fades, takeovers, chords, feedback, saturation, noise and drop-outs. Green on both
    sides of each of its 24 steps and at its ends (76 values, all 25 sets reached) and white over its range (20 values),
    with algorithms 1 and 8: 0 differ.
  - **Phrase picker:** `--guest test/pick_guest_orc.c --src kastle_log.c -D KL_TEST`, castle 1.1: 30,000 picker calls
    on random states and 144,000 picks through castle's pick routine (small categories running out, the counter
    wrapping three times), 0 differences in the phrase, the random word, the counter, the stamps and the used bits.
  - **Page:** `--guest test/page_guest_orc.c`, castle 1.0, every scenario 0 pixels differ. The guest switches the ratio
    readout back to 1.0's twenty steps (`KP_RATIO_LAW_10`); with `--src kastle_log.c` it needs `-D KL_FIRST_PASS=1`.
  - **Log:** `--guest test/log_guest_orc.c -D KL_FIRST_PASS=1`, castle 1.0, 0 state and pixel differences.
    `KL_FIRST_PASS=1` runs only the picker's second pass, which is 1.0's picker. The page and log checks run with
    castle's exact text, which `test/castle_text.py` decodes from the 1.0 binary.
  - **Voice-sum stage:** castle's block callback and kastle's sum block on the same mix after every block of those
    scenarios, with ring and reducer words over their whole range and every eighth block full-scale noise with the
    rails: 55,800 blocks, 0 samples and 0 page peaks differ; six more runs at the ends of ring and noise, 0 differ.
- **`kern_check.py`** (make check) holds `kastle_op.S` to the C on bcore.
- **`kastle_test.c`** (make check) covers, in R246 units:
  - the fades, the drone, the chord and the takeover;
  - drone mode off, and `finished`;
  - 440 and 220 Hz;
  - every algorithm with every Shift word at its ends, and the output clamp;
  - the screen with its pushes.

## CPU

Declared cost (plugin.json `cost`, bcore packets): 18,453 a voice and 3,791 a start, the sum block's share included.
Six voices at the worst (knob sweeps, random knobs) are 54.7 % of the slot model (60.5 % while the sum stage ran in
every voice); a default chord about 21 %. On `test/orc.py`'s six voices at the heaviest settings (ring and reducer on,
blue jumping) kastle takes 111.7K packets a block against castle's 109.3K (+2 %; it was 123.7K, +13 %). Moving the
voices into L1 (2026-11-11) took that setting's modelled cold block (bcore memmodel, no write-allocate) from 139.1K
to 136.0K cycles with the same code. Castle, voices in fast memory, measures 137.6K there. Packets rose 0.2 %. Castle's
design is over the model, so kastle is listed in `slot_budget_over.txt` (the owner's choice: 1:1). Not yet measured
on the unit.
