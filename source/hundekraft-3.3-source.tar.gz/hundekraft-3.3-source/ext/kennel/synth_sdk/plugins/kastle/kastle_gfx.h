/* kastle's drawing primitives (kastle_gfx.c), shared by the page (kastle_page.c) and the log (kastle_log.c): castle
 * 1.0's own, rebuilt from its binary (matched to displayname808's castle 1.0, GPL-3.0 as the owner reported it,
 * 2026-11-10; binary sha256 88214a82...07cd). Addresses are castle's, its image relocated at 0x02800000.
 *
 * Castle's coordinates: x runs along the raster's rows (0 .. kg_xn - 1), y along a row (0 .. kg_yn - 1); pixel (x, y)
 * is kg_fb[kg_at(x, y)] = kg_fb[(kg_rows - 1 - x) * 256 + y], RGB565. GUI thread only, integers only.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef KASTLE_GFX_H
#define KASTLE_GFX_H
#include <stdint.h>

/* the frame (castle's 0x283e574 .. 0x283e588, set from its host's page pixels each frame) */
extern uint16_t *kg_fb;                    /* 0x283e588: the raster */
extern int kg_rows;                        /* 0x283e584: its rows (320, 376 or 400) */
extern int kg_xn;                          /* 0x283e580: x limit (= kg_rows) */
extern int kg_yn;                          /* 0x283e57c: y limit (kg_rows / 2) */
extern int kg_cx;                          /* 0x283e578: the scene's centre x (kg_rows / 2) */
extern int kg_cy;                          /* 0x283e574: the scene's centre y (kg_rows / 2 * 147 / 320) */
/* castle's main draw (0x28095b8) sets these from page_pixels; 0 (nothing set) for a rows value castle refuses */
int kg_frame(uint16_t *fb, int rows);
static inline int kg_at(int x, int y) { return (kg_rows - 1 - x) * 256 + y; }

/* the font (0x28310b0: 128 characters, four columns of seven bits, bit 0 the top) and the icons (0x2830f48: twenty,
 * nine columns of nine bits), built once by kg_init (castle's 0x28091e8, its first part) */
extern uint8_t kg_font[128][4];
extern uint16_t kg_icons[20][9];
void kg_init(void);

/* 0x2806f04: a colour 0xRRGGBB scaled by level / 256 (each channel clipped to 255) as RGB565 */
uint16_t kg_rgb(uint32_t rgb, int level);
/* 0x2807810: clear x0..x1, y0..y1 (inclusive, clipped to the frame) to black */
void kg_clear(int x0, int y0, int x1, int y1);
/* 0x2807924: the raster offsets (kg_fb indexes) of up to n characters of s at (x, y), 5 px a character; at most max;
 * returns the count, or -1 when max is reached */
int kg_text_dots(int *out, int max, int x, int y, const char *s, int n);
/* 0x28079cc's layout (its arrays are the log's): line s + 5 (n1 characters) at (x, y) into out (0x400 offsets); when
 * s[split + 5] is set, the rest (from s + 5 + split, n2 characters) at (x, y + 11) after it. Returns the count or -1. */
int kg_line_dots(int *out, const char *s, int n1, int split, int x, int y, int n2);
/* 0x2807b8c: up to n characters of s at (x, y) in colour c; a character wholly inside the frame is drawn with its
 * blank pixels cleared, one at an edge only where it sets pixels */
void kg_text(int x, int y, const char *s, int n, uint16_t c);
/* 0x2807d0c: digit d (0..9) at (x, y), 4 x 7, set pixels only */
void kg_digit(int x, int y, int d, uint16_t c);

/* the dotted lines' list (0x282fd44 count, 0x282fd48 offsets, room for 0x481): castle's log frame */
#define KG_DOTS 0x481
extern int kg_ndots;
extern int kg_dots[KG_DOTS];
/* a start below 0 moves up to 0 or 1, keeping its parity; the end is clipped to the frame; at most 0x480 in all */
void kg_dots_x(int x0, int x1, int y);    /* 0x2807a74: every other pixel x0..x1 at y (nothing for y outside) */
void kg_dots_y(int x, int y0, int y1);    /* 0x2807b0c: every other pixel y0..y1 at x */

#endif
