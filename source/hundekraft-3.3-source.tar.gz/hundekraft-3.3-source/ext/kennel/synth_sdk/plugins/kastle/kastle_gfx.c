/* kastle's drawing primitives: castle 1.0's own, rebuilt from its binary (kastle_gfx.h; matched to displayname808's
 * castle 1.0, GPL-3.0 as the owner reported it, 2026-11-10; binary sha256 88214a82...07cd). The glyphs are castle's
 * (kastle_page_data.h, make_page.py). GUI thread only, integers only, no library.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "kastle_gfx.h"
#define KP_WANT_FONT
#include "kastle_page_data.h"

uint16_t *kg_fb;
int kg_rows, kg_xn, kg_yn, kg_cx, kg_cy;
uint8_t kg_font[128][4];
uint16_t kg_icons[20][9];
int kg_ndots;
int kg_dots[KG_DOTS];

int kg_frame(uint16_t *fb, int rows)                       /* 0x28095b8's start */
{
    if (!fb || (rows != 320 && rows != 376 && rows != 400)) return 0;
    kg_fb = fb;
    kg_rows = kg_xn = rows;
    kg_cx = kg_yn = rows >> 1;
    kg_cy = kg_cx * 0x93 / 0x140;
    return 1;
}

void kg_init(void)                                         /* 0x28091e8: the font and the icons */
{
    for (int c = 0; c < 128; ++c) {
        const uint8_t *g = KP_GLYPH_PUNCT;                 /* anything not listed: the first, a space */
        if (c >= 'a' && c <= 'z') g = KP_GLYPH_LOWER + (c - 'a') * 7;
        else if (c >= '0' && c <= '9') g = KP_GLYPH_DIGIT + (c - '0') * 7;
        else
            for (int i = 0; KP_PUNCT[i]; ++i)
                if (KP_PUNCT[i] == c) { g = KP_GLYPH_PUNCT + i * 7; break; }
        for (int k = 0; k < 4; ++k) {                      /* column k: bit 3 - k of the seven rows */
            unsigned b = 0;
            for (int j = 0; j < 7; ++j) b |= (unsigned)((g[j] >> (3 - k)) & 1) << j;
            kg_font[c][k] = (uint8_t)b;
        }
    }
    for (int n = 0; n < 20; ++n)
        for (int k = 0; k < 9; ++k) {
            unsigned b = 0;
            for (int j = 0; j < 9; ++j) b |= (unsigned)((KP_ICON_ROWS[n * 9 + j] >> (8 - k)) & 1) << j;
            kg_icons[n][k] = (uint16_t)b;
        }
}

uint16_t kg_rgb(uint32_t rgb, int level)                   /* 0x2806f04 */
{
    int r = (int)((rgb >> 16) & 255) * level >> 8, g = (int)((rgb >> 8) & 255) * level >> 8, b = (int)(rgb & 255) * level >> 8;
    if (r > 255) r = 255;
    if (g > 255) g = 255;
    if (b > 255) b = 255;
    return (uint16_t)((r >> 3) << 11 | (g >> 2) << 5 | b >> 3);
}

void kg_clear(int x0, int y0, int x1, int y1)              /* 0x2807810 */
{
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 >= kg_xn) x1 = kg_xn - 1;
    if (y1 >= kg_yn) y1 = kg_yn - 1;
    for (int x = x0; x <= x1; ++x) {
        uint16_t *p = kg_fb + kg_at(x, 0);
        for (int y = y0; y <= y1; ++y) p[y] = 0;
    }
}

int kg_text_dots(int *out, int max, int x, int y, const char *s, int n)   /* 0x2807924 */
{
    int k = 0, base = (kg_rows - 1 - x) * 256 + y;
    for (; *s && n > 0; ++s, --n, base -= 0x500) {
        const uint8_t *g = kg_font[*s & 0x7f];
        for (int c = 0; c < 4; ++c)
            for (unsigned b = g[c], o = (unsigned)(base - c * 0x100); b; b >>= 1, ++o)
                if (b & 1) {
                    if (k == max) return -1;
                    out[k++] = (int)o;
                }
    }
    return k;
}

int kg_line_dots(int *out, const char *s, int n1, int split, int x, int y, int n2)   /* 0x28079cc */
{
    const int a = kg_text_dots(out, 0x400, x, y, s + 5, n1);
    if (a < 0 || !s[split + 5]) return a;
    const int b = kg_text_dots(out + a, 0x400 - a, x, y + 11, s + 5 + split, n2);
    return b < 0 ? -1 : a + b;
}

void kg_text(int x, int y, const char *s, int n, uint16_t c)   /* 0x2807b8c */
{
    const int ylow = y + 6 >= kg_yn;
    for (; *s && n > 0; ++s, --n, x += 5) {
        const uint8_t *g = kg_font[*s & 0x7f];
        if (x < 0 || x + 3 >= kg_xn || y < 0 || ylow) {
            for (int k = 0; k < 4; ++k)
                for (int b = 0; b < 7; ++b)
                    if ((g[k] >> b & 1) && (unsigned)(x + k) < (unsigned)kg_xn && (unsigned)(y + b) < (unsigned)kg_yn)
                        kg_fb[kg_at(x + k, y + b)] = c;
        } else {
            for (int k = 0; k < 4; ++k) {
                uint16_t *p = kg_fb + kg_at(x + k, y);
                for (int b = 0; b < 7; ++b) p[b] = (g[k] >> b & 1) ? c : 0;
            }
        }
    }
}

void kg_digit(int x, int y, int d, uint16_t c)             /* 0x2807d0c */
{
    const uint8_t *g = KP_GLYPH_DIGIT + d * 7;
    for (int j = 0; j < 7; ++j)
        for (int k = 0; k < 4; ++k)
            if ((g[j] >> (3 - k) & 1) && (unsigned)(x + k) < (unsigned)kg_xn && (unsigned)(y + j) < (unsigned)kg_yn)
                kg_fb[kg_at(x + k, y + j)] = c;
}

static int dots_start(int v) { return v < 0 ? v + 2 + (~v & ~1) : v; }   /* castle's: up to 0 or 1, same parity */

void kg_dots_x(int x0, int x1, int y)                      /* 0x2807a74 */
{
    if (y < 0 || y >= kg_yn) return;
    x0 = dots_start(x0);
    if (x1 >= kg_xn) x1 = kg_xn - 1;
    for (int o = (kg_rows - 1 - x0) * 256 + y; x0 <= x1 && kg_ndots < KG_DOTS - 1; x0 += 2, o -= 0x200)
        kg_dots[kg_ndots++] = o;
}

void kg_dots_y(int x, int y0, int y1)                      /* 0x2807b0c */
{
    y0 = dots_start(y0);
    if (y1 >= kg_yn) y1 = kg_yn - 1;
    for (const int base = (kg_rows - 1 - x) * 256; y0 <= y1 && kg_ndots < KG_DOTS - 1; y0 += 2)
        kg_dots[kg_ndots++] = base + y0;
}
