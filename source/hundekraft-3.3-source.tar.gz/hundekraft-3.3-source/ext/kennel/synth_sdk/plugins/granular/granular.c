/* Granular engine over the slot's sampler recording.
 *
 * Workflow on the OP-1: pick "sampler" on a synth slot, record (mic/line/radio as usual),
 * then switch the same slot to "granular". The recording is read live from the sampler buffer
 * (and reloaded from synth_<slot>.raw at boot thanks to the uses_sample hook).
 *
 *   knob 0 (blue)  : position   - where in the recording grains start (0 .. recorded length)
 *   knob 1 (green) : grain size - ~10 ms .. ~370 ms
 *   knob 2 (white) : spray      - random start jitter around position (0 .. ~1.5 s)
 *   knob 3 (orange): density    - grains per grain-length, 0.5x .. 4x overlap
 *   white press    : sample browser (core, screens/sbrowse.c): the sampler presets, as sampler+
 *   red press      : page 2 = sample gain (params[7]: 1..32767 = 0..4x linear, 8192 = 1x; 0 = 1x, the
 *                    default of existing patches)
 *   blue press     : page 2 = PITCH, -24 .. +24 semitones (params[5]: 0 = none, the default of existing patches;
 *                    else 8192 + 256 a semitone, the core's page-2 editor starts an unset word at 8192)
 *   green press    : page 2 = SHAPE, six steps: hann, gauss, tukey, tri, pluck, swell (params[6]; 0 = hann)
 *   keyboard       : pitch (C4 plays the recording at original speed); random +-detune per grain
 *                    when spray is up
 *
 * Up to 4 overlapping grains per voice, linear interpolation, 22.10 fixed-point sample positions. Each grain is
 * centred on the position (its window's middle there) and kept inside the recording, and keeps the shape it started
 * with. Hann = sin^2 from the firmware sine table (granular_dsp.S gr_grain); the other shapes are tables
 * (window_tables.h, grain_loop.S).
 *
 * Pitch, shape, the grain centring and the screen follow displayname808's Granular 0.10.0 as op1r-src 6f1e147 ported
 * it (original engine: pcppcp); its freeze, clock sync and Shift pages are not taken (PROVENANCE.md).
 */
#include "op1_plugin.h"
#include "window_tables.h"

#define MAX_GRAINS   4
#define FRAC         10                        /* position fraction bits */
#define INC_C4       25480370u                 /* phase inc of 261.63 Hz @44.1 kHz (2^32 = 1 cyc/sample): the recording's rate. OP1_PITCH_INC
                                                * counts 88.2 kHz steps, so rate = inc / (INC_C4 >> FRAC) is 0.5 source samples per output
                                                * sample at C4 = original speed. Right as it is (rate note 2026-11-03): do not touch. */
/* Grain size in OUTPUT samples (88.2 kHz, OP1_VOICE_RATE): 10 ms .. 373 ms. Until 2026-11-03 this counted 441 + 16000 as
 * if the output were 44.1 kHz, which made grains 5 .. 186 ms and twice as dense on the unit. */
#define GR_SIZE(k)   (OP1_VOICE_RATE / 100 + (int32_t)(((uint32_t)(k) * 32000u) >> 15))

typedef struct {
    uint32_t pos;       /* 22.10 sample position */
    uint32_t rate;      /* 22.10 per sample */
    uint32_t wph;       /* window phase, 0..2^31 = half sine cycle */
    uint32_t winc;      /* window phase increment (0 = inactive) */
    uint32_t sh;        /* shape (0 hann .. 5 swell), kept for the grain's life (after the four words the kernels read) */
} grain_t;
#define GR_SHAPES 6
static inline int shape_of(int32_t k) { return k <= 0 ? 0 : k >= 32767 ? GR_SHAPES - 1 : (int)(((uint32_t)k * GR_SHAPES) >> 15); }
/* the PITCH word in semitones: 0 (every older sound) none; else 8192 + 256 a semitone, rounded, -24 .. +24 */
static inline int pitch_st(int32_t w)
{
    if (w <= 0) return 0;
    const int32_t d = w - 8192;
    const int st = d < 0 ? -(int)((uint32_t)(-d + 128) >> 8) : (int)((uint32_t)(d + 128) >> 8);
    return st < -24 ? -24 : st > 24 ? 24 : st;
}

typedef struct {
    grain_t  g[MAX_GRAINS];
    int32_t  next;      /* samples until next grain spawn */
    int32_t  len;       /* usable recording length (samples) */
    uint32_t rng;
    volatile uint32_t blocks;   /* render calls: the screen shows a voice's grains only while it renders */
} gvoice_t;

static gvoice_t gv[OP1_VOICES];

static inline uint32_t rnd(gvoice_t *v) { v->rng = v->rng * 1664525u + 1013904223u; return v->rng; }

/* recorded length = end of the last peak bucket above a small threshold */
/* note_on runs it in the audio callback, once per started voice: a short recording left ~1,900 empty buckets to step
 * through (~7.6k packets per voice, ~45k for a chord). Four buckets per step while they are all zero, then bucket by
 * bucket as before: the same result (bursts 2026-10-27). */
#if defined(__bfin__) && !defined(GR_C_LOOP)
/* granular_dsp.S: whole groups of 16 buckets from the top, all <= 96 (grp = the lowest bucket of the top group,
 * word-aligned; groups >= 1): how many, ~11 packets per group */
int32_t gr_peak_skip(const int16_t *grp, int32_t groups);
#endif
static int32_t recorded_length(const uint8_t *sb)
{
    const int16_t *pk = op1_sample_peaks(sb);
    int i = OP1_PEAK_BUCKETS - 1;
    if (!((uintptr_t)pk & 3)) {                           /* the buffer's peaks are word-aligned (sb + 4) */
#if defined(__bfin__) && !defined(GR_C_LOOP)
        /* the same answer (the top bucket above 96) in groups of 16: buckets alone down to a group's top, the
         * groups that hold nothing above 96 skipped at once, then bucket by bucket as below */
        while (i >= 0 && ((i + 1) & 15)) { if (pk[i] > 96) goto found; i--; }
        if (i >= 15) i -= 16 * gr_peak_skip(pk + i - 15, (i + 1) >> 4);
#else
        while (i >= 0 && (i & 3) != 3) { if (pk[i] > 96) goto found; i--; }
        const uint32_t *w = (const uint32_t *)(const void *)pk;
        while (i >= 3 && !(w[(i - 3) >> 1] | w[(i - 1) >> 1])) i -= 4;
#endif
    }
    for (; i >= 0; i--)
        if (pk[i] > 96) goto found;
    return 0;
found:
    {
        int32_t l = (i + 1) * 256;
        return l > OP1_SAMPLE_MAX ? OP1_SAMPLE_MAX : l;
    }
}

static void gr_note_on(void *self, const int16_t *params)
{
    gvoice_t *v = &gv[op1_voice_index(self)];
    const uint8_t *sb = op1_sample_buffer(op1_current_slot());
    (void)params;
    for (int i = 0; i < MAX_GRAINS; i++) v->g[i].winc = 0;
    v->next = 0;
    v->len = sb ? recorded_length(sb) : 0;
    v->rng ^= (uint32_t)self * 2654435761u + 12345u;
}

static void spawn(gvoice_t *v, const int16_t *params, uint32_t rate, uint32_t winc, int32_t size, int sh)
{
    int i;
    for (i = 0; i < MAX_GRAINS; i++) if (!v->g[i].winc) break;
    if (i == MAX_GRAINS) return;                      /* all busy: skip this grain */
    grain_t *g = &v->g[i];

    int32_t len   = v->len;
    int32_t start = (int32_t)(((uint64_t)(uint16_t)params[0] * (uint32_t)len) >> 15);   /* 64-bit: no wrap */
    /* centred (0.10.0): the grain reads span source samples, so it starts half of them before the position and the
     * window's middle lands on it (a 32-bit product a grain; 64 bits only for a step of 64 source samples or more) */
    const uint32_t span32 = rate < 65536u ? ((uint32_t)size * rate) >> FRAC   /* size < 2^16: the 32-bit product */
                                          : (uint32_t)(((uint64_t)(uint32_t)size * rate) >> FRAC < (uint32_t)len
                                                       ? ((uint64_t)(uint32_t)size * rate) >> FRAC : (uint32_t)len);
    const int32_t span = span32 > (uint32_t)len ? len : (int32_t)span32;
    start -= span >> 1;
    int32_t spray = (int32_t)(((uint32_t)params[2] * 66150u) >> 15);   /* up to 1.5 s */
    if (spray) start += (int32_t)(rnd(v) % (uint32_t)(2 * spray + 1)) - spray;
    /* kept inside the recording, whole: near either end the grain moves in rather than being cut off before its
     * window ends */
    if (start > len - 2 - span) start = len - 2 - span;
    if (start < 0) start = 0;

    /* a little random detune (+-~1%) proportional to spray */
    uint32_t r = rate;
    if (params[2] > 4096) {
        int32_t dt = (int32_t)(rnd(v) >> 22) - 512;                     /* -512..511 */
        r = (uint32_t)((int32_t)rate + ((int32_t)(rate >> 10) * dt * (params[2] >> 8) >> 12));
    }
    g->pos  = (uint32_t)start << FRAC;
    g->rate = r;
    g->wph  = 0;
    g->winc = winc;                                   /* window spans `size` output samples */
    g->sh   = (uint32_t)sh;
}

/* ---- the sample loop, grain by grain ----
 * The C's per-sample loop (spawn test, then each live grain in turn) as passes: the block splits at the samples where a
 * grain spawns; over each piece every live grain adds its own samples to acc[] (a 32-bit sum, so the order of the
 * grains does not change it), as many as it sounds there: gr_count finds where it ends (its window wraps past half a
 * sine cycle, or its index reaches len - 1), so a grain ends at the same sample as before and its slot is free for the
 * same spawn. Then out[] from acc[] (zeroed for the next call). On the Blackfin gr_grain and gr_out are in
 * granular_dsp.S (the same arithmetic, scheduled by hand); host builds and GR_C_LOOP keep these C loops. */
static int32_t gacc_w[1 + OP1_BLOCK];                 /* voices render one after another: one sum for all; */
#define gacc (gacc_w + 1)                             /* gr_grain writes back the word in front of its piece unchanged */

#if defined(__bfin__) && !defined(GR_C_LOOP)
void gr_grain(int32_t *acc, const int16_t *data, grain_t *g, int32_t cnt);
void gr_out(int16_t *out, int32_t *acc, int32_t gain, int32_t sg);
/* grain_loop.S (op1r-src 6f1e147): a table-shape grain, the C gr_grain_tab's numbers; acc has a word before it */
struct gk { uint32_t pos, rate, wph, winc; const int16_t *data; const int16_t *win; int32_t *acc; int32_t n; };
void grain_loop_asm(struct gk *k);
static void gr_grain_tab(int32_t *acc, const int16_t *data, grain_t *g, int32_t cnt, const int16_t *win)
{
    struct gk k = { g->pos, g->rate, g->wph, g->winc, data, win, acc, cnt };
    grain_loop_asm(&k);
    g->pos = k.pos; g->wph = k.wph;
}
#else
/* a table-shape grain (gauss .. swell): as gr_grain with the window from the table, index wph >> 20 (2048 steps) */
static void gr_grain_tab(int32_t *acc, const int16_t *data, grain_t *g, int32_t cnt, const int16_t *win)
{
    uint32_t pos = g->pos, wph = g->wph;
    const uint32_t rate = g->rate, winc = g->winc;
    for (int32_t k = 0; k < cnt; k++) {
        uint32_t idx = pos >> FRAC;
        int32_t a = data[idx], b = data[idx + 1];
        int32_t s = a + (((b - a) * (int32_t)(pos & ((1 << FRAC) - 1))) >> FRAC);
        acc[k] += (s * win[wph >> 20]) >> 15;
        pos += rate;
        wph += winc;
    }
    g->pos = pos;
    g->wph = wph;
}

/* cnt samples of grain g into acc[0..cnt): pos and wph advance, winc is left to the caller */
static void gr_grain(int32_t *acc, const int16_t *data, grain_t *g, int32_t cnt)
{
    const int16_t *sine = OP1_SINE_TABLE;
    uint32_t pos = g->pos, wph = g->wph;
    const uint32_t rate = g->rate, winc = g->winc;
    for (int32_t k = 0; k < cnt; k++) {
        uint32_t idx = pos >> FRAC;
        int32_t a = data[idx], b = data[idx + 1];
        int32_t s = a + (((b - a) * (int32_t)(pos & ((1 << FRAC) - 1))) >> FRAC);
        int32_t w = sine[((int32_t)wph >> 19) + 4096];                    /* sin(pi*t), 0..32767 */
        w = (w * w) >> 15;                                                /* sin^2 = Hann */
        acc[k] += (s * w) >> 15;
        pos += rate;
        wph += winc;
    }
    g->pos = pos;
    g->wph = wph;
}
static void gr_out(int16_t *out, int32_t *acc, int32_t gain, int32_t sg)
{
    for (int n = 0; n < OP1_BLOCK; n++) {
        out[n] = op1_sat16((((acc[n] * gain) >> 15) * sg) >> 13);     /* |x| < 2^16, sg < 2^15: 32 bit */
        acc[n] = 0;
    }
}
#endif

/* how many of k = 0 .. seg - 1 have base + k step < limit (they do up to some k, then not; no sum wraps here) */
static int32_t gr_count(uint32_t base, uint32_t step, uint32_t limit, int32_t seg)
{
    if (base + (uint32_t)(seg - 1) * step < limit) return seg;
    int32_t lo = 0, hi = seg - 1;                     /* k = hi fails; find the first k that does */
    while (lo < hi) {
        int32_t mid = (lo + hi) >> 1;
        if (base + (uint32_t)mid * step < limit) lo = mid + 1; else hi = mid;
    }
    return lo;
}

/* the live grains over samples n0 .. n1 - 1 (n1 > n0): a grain ends where the C loop ended it */
static void gr_piece(gvoice_t *v, const int16_t *data, int32_t len, int32_t n0, int32_t n1)
{
    const int32_t seg = n1 - n0;
    const uint32_t lim = (uint32_t)(len - 1) << FRAC;  /* idx >= len - 1 <=> pos >= lim (len >= 256) */
    for (int i = 0; i < MAX_GRAINS; i++) {
        grain_t *g = &v->g[i];
        if (!g->winc) continue;
        int32_t c = gr_count(g->pos, g->rate, lim, seg);                 /* samples whose index is in range */
        int32_t w = gr_count(g->wph, g->winc, 0x80000000u, seg);         /* samples inside the window */
        if (w < c) c = w;
        if (c) {
            if (g->sh) gr_grain_tab(gacc + n0, data, g, c, gr_window[g->sh - 1]);
            else gr_grain(gacc + n0, data, g, c);
        }
        if (g->wph >= 0x80000000u || c < seg) g->winc = 0;               /* finished, or its index ran out */
    }
}

/* the overlap gain for ovl8 = 9 .. 35 (4 + (word >> 10) <= 35): the C's (32767 * 8) / ovl8 + 6000, at most 32767 */
#define GR_OG(o) ((32767 * 8) / (o) + 6000 > 32767 ? 32767 : (32767 * 8) / (o) + 6000)
static const int16_t gr_ovl_gain[27] = {
    GR_OG(9), GR_OG(10), GR_OG(11), GR_OG(12), GR_OG(13), GR_OG(14), GR_OG(15), GR_OG(16), GR_OG(17), GR_OG(18),
    GR_OG(19), GR_OG(20), GR_OG(21), GR_OG(22), GR_OG(23), GR_OG(24), GR_OG(25), GR_OG(26), GR_OG(27), GR_OG(28),
    GR_OG(29), GR_OG(30), GR_OG(31), GR_OG(32), GR_OG(33), GR_OG(34), GR_OG(35) };

static void gr_render_body(void *self, int16_t *out, const int16_t *params);
/* granular_dsp.S zeroes L0..L3 (linear DAG addressing); the caller's values come back on return, as mbira.c does */
static void gr_render(void *self, int16_t *out, const int16_t *params)
{
#if defined(__bfin__) && !defined(GR_C_LOOP)
    uint32_t l0, l1, l2, l3;
    __asm__ volatile("%0 = L0;\n\t%1 = L1;\n\t%2 = L2;\n\t%3 = L3;" : "=d"(l0), "=d"(l1), "=d"(l2), "=d"(l3));
    gr_render_body(self, out, params);
    __asm__ volatile("L0 = %0;\n\tL1 = %1;\n\tL2 = %2;\n\tL3 = %3;" : : "d"(l0), "d"(l1), "d"(l2), "d"(l3));
#else
    gr_render_body(self, out, params);
#endif
}

static void gr_render_body(void *self, int16_t *out, const int16_t *params)
{
    gvoice_t *v = &gv[op1_voice_index(self)];
    const uint8_t *sb = op1_sample_buffer(op1_current_slot());
    v->blocks++;

    if (!sb || v->len < 256) {                        /* nothing recorded yet */
        if (sb) v->len = recorded_length(sb);
        for (int n = 0; n < OP1_BLOCK; n++) out[n] = 0;
        return;
    }
    const int16_t *data = op1_sample_data(sb);
    int32_t len = v->len;

    /* playback rate from the keyboard pitch (constant over the block) */
    uint32_t rate = (uint32_t)OP1_PITCH_INC[0] / (INC_C4 >> FRAC);
    const int st = pitch_st(params[5]);                                    /* PITCH page: times 2^(st/12) */
    if (st) rate = (uint32_t)(((uint64_t)rate * gr_semi_q16[st + 24]) >> 16);
    if (rate < 16) rate = 16;
    const int sh = shape_of(params[6]);                                    /* SHAPE page: new grains */

    int32_t size = GR_SIZE(params[1]);                                     /* 10 ms .. 373 ms of output samples */
    /* density: spawn interval = size / overlap, overlap 0.5 .. 4 */
    int32_t ovl8 = 4 + (params[3] >> 10);                                  /* overlap * 8: 4..35 */
    int32_t interval = 0;                             /* (size * 8) / ovl8, at least 64 (0.73 ms): worked out at the block's first spawn */
    uint32_t winc = 0;                                /* 0x80000000 / size, the same */
    /* gain compensation for overlapping grains: min(32767, (32767 * 8) / ovl8 + 6000), from a table */
    int32_t gain = ovl8 <= 8 ? 32767 : gr_ovl_gain[ovl8 - 9];
    gain = (gain * op1_voice_vel_gain(self)) >> 15;                         /* note velocity */
    int32_t sg = params[7] > 0 ? params[7] : 8192;                         /* sample gain, Q13 */
    sg = (sg * 9741) >> 13;                                                 /* +1.5 dB (level pass 2026-10-29) */
    if (sg > 32767) sg = 32767;                                             /* the knob's own 4x stays the ceiling */

    /* the C loop decremented next at every sample and spawned when it reached 0 (then next = interval): from sample s
     * on, the spawn is at s + max(next - 1, 0) */
    int32_t next = v->next, n = 0, s = 0;
    for (;;) {
        int32_t at = s + (next > 1 ? next - 1 : 0);
        if (at >= OP1_BLOCK) {
            if (n < OP1_BLOCK) gr_piece(v, data, len, n, OP1_BLOCK);
            next -= OP1_BLOCK - s;
            break;
        }
        if (at > n) gr_piece(v, data, len, n, at);
        if (!interval) {
            interval = (size * 8) / ovl8;
            if (interval < 64) interval = 64;
            winc = 0x80000000u / (uint32_t)size;
        }
        spawn(v, params, rate, winc, size, sh);
        next = interval;
        n = at;
        s = at + 1;
    }
    v->next = next;
    gr_out(out, gacc, gain, sg);
}

const op1_engine_t ENGINE_granular = { gr_note_on, gr_render, 0,
                                       { OP1_PRESS_PAGE, OP1_PRESS_PAGE_STEPS(GR_SHAPES), OP1_PRESS_BROWSE, OP1_PRESS_PAGE } };

/* ======================= screen (GUI thread) =======================
 * displayname808's Granular 0.10.0 page as op1r-src 6f1e147 has it ("brighter"), on kennel's services. granular.svg
 * is empty; everything is drawn here each frame:
 *   - y 9..19: the recording as a bar of columns (a column every 4 px, as tall as the sound there; white), the
 *     position as a blue play-head arrow sliding along it;
 *   - four dotted waves (y 47, 65, 83, 101), one an encoder, each moving with what its knob does; they drift while a
 *     note plays and lie still in silence:
 *       blue  position: slides as the position moves, shorter with PITCH up; the live grains ride it as white marks,
 *             as tall as their window is now
 *       green size: a row of the grain shape, each as long as a grain (hann bumps, pluck spikes, swell ramps)
 *       white spray: the dots scattered as far as the spray reaches, sliding to new places
 *       red   density: the dots as close as the grains overlap; on the gain page its height is the sample gain
 *   - a label (y 112) and a value (y 126) per knob in the stock font: pos / size / spray / dens, or on page 2 pitch
 *     ("+7st") / shape ("pluck") / gain ("1.0x").
 * Kennel: no Shift view (the pages are the encoder pushes), no freeze or sync marks, the play head always blue, the
 * labels always shown (op1r's fade is off there too), grain marks placed with 32-bit sums. */
#include "op1_synth.h"                    /* stock-font text (firmware calls, no imports) */
#define U(v)    ((v) * 256)                /* units x 256; a raster point is units x 1024 */
#define SIN_N   256
#define WAVE_Y0 47
#define WAVE_DY 18
#define AMP     3
#define COL_X0  16
#define COL_DX  80
#define BAR_N   80
#define BAR_Y   14
#define BAR_H   5
#define JIT_T   184                       /* the spray's dots take a new place every 184 audio blocks */
#define C_POS   0x4D9EFF
#define C_SIZE  0x00ED95
#define C_WHITE 0xFFFFFF
#define C_GRAIN 0xFF3A5D
static const int TXT4[4] = { C_POS, C_SIZE, C_WHITE, C_GRAIN };
static const char *const SHAPE_NAME[GR_SHAPES] = { "hann", "gauss", "tukey", "tri", "pluck", "swell" };
static int16_t sin_t[SIN_N];             /* sin(2 pi i / 256) x 4096 */
static uint32_t gt_obj[8][OP1_TEXT_SIZE / 4];
static char gt_shown[8][12];
static uint8_t gt_made;

static void gr_screen_init(void *scr)
{
    (void)scr;
    for (int i = 0; i < SIN_N; i++) sin_t[i] = (int16_t)(OP1_SINE_TABLE[i * (8192 / SIN_N)] >> 3);
}

static void line(int x0, int y0, int x1, int y1, int w, int c)    /* units x 256, width units x 256 */
{
    const uint8_t rgba[4] = { (uint8_t)(c >> 16), (uint8_t)(c >> 8), (uint8_t)c, 255 };
    op1_pt a = { x0 * 4, y0 * 4 }, b = { x1 * 4, y1 * 4 };
    op1_raster_line(op1_raster(), &a, &b, w * 4, rgba);
}
static void dot(int x, int y, int c) { line(x - 0xC0, y, x + 0xC0, y, 0x180, c); }   /* 1.5 x 1.5 units */

static char *num(char *p, int32_t v, int dec)                    /* v in 1/10^dec: 125, 2 -> "1.25" */
{
    char t[12]; int n = 0;
    do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v || n <= dec);
    while (n) { *p++ = t[--n]; if (n == dec && dec) *p++ = '.'; }
    return p;
}
static char *cat(char *p, const char *s) { while (*s) *p++ = *s++; return p; }
static void ms_text(char *s, int32_t samples)                     /* 44.1 kHz samples: "120ms", "1.25s" */
{
    const int32_t ms = (samples * 10 + 220) / 441;
    char *p = ms < 1000 ? cat(num(s, ms, 0), "ms") : cat(num(s, ms / 10, 2), "s");
    *p = 0;
}
static void page_text(int i, int x, int y, int c, const char *s)  /* stock font, size 12; rebuilt when it changes */
{
    static const int32_t ident[9] = { 1024, 0, 0, 0, 1024, 0, 0, 0, 1024 };
    if (!gt_made) {
        for (int j = 0; j < 8; j++) {
            const uint8_t rgba[4] = { (uint8_t)(TXT4[j & 3] >> 16), (uint8_t)(TXT4[j & 3] >> 8), (uint8_t)TXT4[j & 3], 255 };
            op1_text_ctor(gt_obj[j], (COL_X0 + COL_DX * (j & 3)) * 1024, j < 4 ? 112 : 126, 12, rgba);
            gt_shown[j][0] = 0;
        }
        gt_made = 1;
    }
    (void)x; (void)y; (void)c;
    int same = 1, j = 0;
    for (; s[j] || gt_shown[i][j]; j++) if (s[j] != gt_shown[i][j]) { same = 0; break; }
    if (!same) { op1_text_set(gt_obj[i], s); for (j = 0; j < 11 && s[j]; j++) gt_shown[i][j] = s[j]; gt_shown[i][j] = 0; }
    op1_text_draw(gt_obj[i], op1_raster(), ident);
}

/* a wave's y (units x 256): ph in 1/65536 of a cycle, amp units x 256; linear between the table's steps */
static int wave_at(int y0, uint32_t ph, int amp)
{
    const int i = (int)(ph >> 8) & (SIN_N - 1), f = (int)(ph & 255);
    const int sn = sin_t[i] + (((sin_t[(i + 1) & (SIN_N - 1)] - sin_t[i]) * f) >> 8);
    return U(y0) + amp * sn / 4096;
}
/* the shape's value (Q15) at t (1/65536 of the grain); hann as the engine's sin^2; a change crossfades */
static int shape_prev, shape_now, shape_mix = 256;
static int win_of(int sh, uint32_t t)
{
    t &= 0xFFFF;
    if (!sh) { const int32_t w = OP1_SINE_TABLE[t >> 4]; return (w * w) >> 15; }   /* sin(pi t)^2 */
    return gr_window[sh - 1][t >> 5];
}
static int win_at(uint32_t t)
{
    const int a = win_of(shape_now, t);
    if (shape_mix >= 256) return a;
    const int b = win_of(shape_prev, t);
    return b + (((a - b) * shape_mix) >> 8);
}
/* the spray's jitter at a dot: two random sets, one every JIT_T blocks, the dot sliding from one to the next */
static int jitter(int dot_i, uint32_t group, int sub, int reach)
{
    if (!reach) return 0;
    uint32_t a = 0x2545F491u + group * 2654435761u + (uint32_t)dot_i * 40503u, b = a + 2654435761u;
    a = a * 1664525u + 1013904223u; a ^= a >> 13; a *= 0x5bd1e995u; a ^= a >> 15;
    b = b * 1664525u + 1013904223u; b ^= b >> 13; b *= 0x5bd1e995u; b ^= b >> 15;
    const int32_t fa = (int32_t)(a >> 16) - 32768, fb = (int32_t)(b >> 16) - 32768;
    const int32_t f = fa + (fb - fa) * sub / JIT_T;
    return (int)((f * reach) >> 15);
}
/* 2^(st/12) in Q16 for st in 1/256 of a semitone (the smoothed pitch), between the table's semitones */
static uint32_t ratio_q16(int st8)
{
    int i = (st8 + 24 * 256) >> 8, f = (st8 + 24 * 256) & 255;
    if (i < 0) { i = 0; f = 0; }
    if (i >= 48) { i = 48; f = 0; }
    const uint32_t a = gr_semi_q16[i], b = gr_semi_q16[i + (i < 48)];
    return a + (uint32_t)(((int32_t)(b - a) * f) >> 8);
}
static inline void follow(int32_t *v, int32_t target, int first) { *v = first ? target : *v + ((target - *v) >> 2); }
/* sample -> x (units x 256) on 2 .. 318, 32-bit */
static int x_of(int32_t sample, int32_t len)
{
    if (len <= 0 || sample <= 0) return U(2);
    if (sample > len) sample = len;
    while (len > 0xFFFFF) { len >>= 1; sample >>= 1; }
    return U(2) + (int)(((uint32_t)((sample << 11) / len) * 316u) >> 3);
}

static void gr_screen_update(void *scr, int dt_ms)
{
    const int slot = OP1_SCREEN_SLOT & 7;
    int16_t k[8];
    op1_synth_knobs_live(slot, k);                                      /* the LFOs in, as the stock screens */
    for (int i = 4; i < 8; i++) k[i] = op1_synth_knobs(slot)[i];
    const int pg0 = op1_eng_page[0], pg1 = op1_eng_page[1], pg3 = op1_eng_page[3];
    op1_screen_draw(scr, dt_ms);
    const uint8_t *sb = op1_sample_buffer(slot);
    const int32_t len = sb ? recorded_length(sb) : 0;
    const int32_t pos = (int32_t)(((uint64_t)(uint16_t)k[0] * (uint32_t)len) >> 15);
    const int32_t size = GR_SIZE(k[1]) >> 1;                            /* 44.1 kHz samples (the C4 source time) */
    const int32_t spray = (int32_t)(((uint32_t)k[2] * 66150u) >> 15);
    const int32_t ovl8 = 4 + (k[3] >> 10);
    const int32_t gq = k[7] > 0 ? k[7] : 8192;

    /* a note playing: a voice rendered since the last frame; time = the voices' audio blocks since then */
    static uint32_t seen[OP1_VOICES], last_t;
    int live[OP1_VOICES], any = 0;
    uint32_t tn = 0;
    for (int vi = 0; vi < OP1_VOICES; vi++) {
        const uint32_t b = gv[vi].blocks;
        live[vi] = b != seen[vi]; seen[vi] = b; any |= live[vi];
        if (b > tn) tn = b;
    }
    uint32_t dt = tn - last_t;
    last_t = tn;
    if (dt > 200) dt = 200;

    /* the smoothed values (x 16), the pitch in 1/256 semitone, the red wave's height: a step for each 23 blocks */
    const int nst = (int)((dt + 11) / 23) < 1 ? 1 : (int)((dt + 11) / 23) > 8 ? 8 : (int)((dt + 11) / 23);
    static int32_t s0, s1, s2, s3, st8, amp4;
    static int first = 1;
    for (int n = 0; n < nst; n++) {
        follow(&s0, (int32_t)(uint16_t)k[0] * 16, first);
        follow(&s1, (int32_t)k[1] * 16, first);
        follow(&s2, (int32_t)k[2] * 16, first);
        follow(&s3, (int32_t)k[3] * 16, first);
        follow(&st8, pitch_st(k[5]) * 256, first);
        follow(&amp4, pg3 ? (int32_t)(U(1) + gq * U(5) / 32767) : U(AMP), first);
        first = 0;
    }
    const int shp = shape_of(k[6]);
    if (shp != shape_now) { shape_prev = shape_now; shape_now = shp; shape_mix = 0; }
    else if (shape_mix < 256) shape_mix += 32 * nst;
    const uint32_t ratio = ratio_q16(st8);
    static int32_t vel;
    static uint32_t drift;                                               /* 1/65536 of a cycle */
    const int32_t vt = any ? (int32_t)((33u * ratio) >> 16) : 0;
    for (int n = 0; n < nst; n++) vel += (vt - vel) >> 3;
    drift += (uint32_t)vel * dt;

    /* the recording bar and the play head */
    if (len >= 256) {
        const int16_t *pk = op1_sample_peaks(sb);
        const int nb = (len + 255) >> 8;
        int16_t col[BAR_N];
        int top = 1;
        for (int c = 0; c < BAR_N; c++) {
            int m = 0;
            for (int j = c * nb / BAR_N, b = (c + 1) * nb / BAR_N; j <= b && j < nb; j++) if (pk[j] > m) m = pk[j];
            col[c] = (int16_t)m; if (m > top) top = m;
        }
        const int xp = U(2) + (int)(((int64_t)s0 * U(316)) >> 19);
        int xa = (xp + 128) >> 8;
        if (xa > 319 - (BAR_H + 1)) xa = 319 - (BAR_H + 1);
        for (int c = 0, x = 2; c < BAR_N; c++, x += 4) {
            if (x >= xa - 1 && x <= xa + BAR_H + 2) continue;
            const int h = col[c] * BAR_H / top;
            if (h < 1) dot(U(x), U(BAR_Y), C_WHITE);
            else line(U(x), U(BAR_Y - h), U(x), U(BAR_Y + h), 0x200, C_WHITE);
        }
        for (int j = 0; j <= BAR_H + 1; j++) {                          /* the arrow: columns of 13, 11 .. 1 px */
            const int hh = BAR_H + 1 - j;
            if (hh > 0) line(U(xa + j), U(BAR_Y - hh), U(xa + j), U(BAR_Y + hh), 0x140, C_POS);
            else dot(U(xa + j), U(BAR_Y), C_POS);
        }
    }

    /* blue: position, with the live grains on it */
    const int yb = WAVE_Y0;
    const uint32_t pb = (uint32_t)(((uint64_t)(uint32_t)s0 * 4 * 65536) >> 19);
    const uint32_t bper8 = (56u << 24) / ratio, bstep = (1u << 24) / bper8;
    for (int x = 2; x < 320; x += 4) dot(U(x), wave_at(yb, pb + drift + (uint32_t)x * bstep, U(AMP)), C_POS);
    if (len >= 256)
        for (int vi = 0; vi < OP1_VOICES; vi++) {
            if (!live[vi]) continue;
            for (int i = 0; i < MAX_GRAINS; i++) {
                const grain_t *g = &gv[vi].g[i];
                if (!g->winc) continue;
                const int x8 = x_of((int32_t)(g->pos >> FRAC), len);
                const int h = U(1) + ((win_at(g->wph >> 15) * U(AMP + 3)) >> 15);
                const int y = wave_at(yb, pb + drift + (uint32_t)(((uint32_t)x8 >> 8) * bstep), U(AMP));
                line(x8, y - h, x8, y + h, 0x180, C_WHITE);
            }
        }
    /* green: grain size, a row of the grain shape */
    const uint32_t gper8 = U(24) + (uint32_t)(((int64_t)s1 * 176) >> 11);
    const uint32_t gstep = (1u << 24) / gper8;
    for (int x = 2; x < 320; x += 4)
        dot(U(x), U(yb + WAVE_DY) + U(AMP) - ((win_at(drift + (uint32_t)x * gstep) * U(2 * AMP)) >> 15), C_SIZE);
    /* white: spray */
    static uint32_t jclk;
    jclk += dt * (uint32_t)(256 + ((s2 * 3) >> 11));
    const int reach = (int)(((int64_t)s2 * U(7)) >> 19);
    for (int x = 2, n = 0; x < 320; x += 4, n++)
        dot(U(x), wave_at(yb + 2 * WAVE_DY, drift * 2 + (uint32_t)x * (65536 / 56), U(AMP))
                  + jitter(n, jclk / (JIT_T * 256), (int)(jclk % (JIT_T * 256) / 256), reach), C_WHITE);
    /* red: density (the gain on its page) */
    const int ovq = 64 + (int)(s3 >> 10);
    const int step = U(8) - (ovq - 64) * U(6) / (31 * 16);
    for (int x = U(2); x < U(320); x += step)
        dot(x, wave_at(yb + 3 * WAVE_DY, drift + 32768u + (uint32_t)(((uint32_t)x * (65536 / 56)) >> 8), (int)amp4), C_GRAIN);

    /* labels and values */
    static const char *const LAB1[4] = { "pos", "size", "spray", "dens" };
    static const char *const LAB2[4] = { "pitch", "shape", "spray", "gain" };
    char val[4][12];
    if (pg0) {                                                           /* "+7st", "0st", "-12st" */
        const int st = pitch_st(k[5]);
        char *p = val[0];
        if (st > 0) *p++ = '+';
        if (st < 0) *p++ = '-';
        *cat(num(p, st < 0 ? -st : st, 0), "st") = 0;
    } else *cat(num(val[0], (pos + 220) / 441, 2), "s") = 0;
    if (pg1) *cat(val[1], SHAPE_NAME[shp]) = 0;
    else ms_text(val[1], size);
    ms_text(val[2], spray);
    if (pg3) *cat(num(val[3], gq * 10 / 8192, 1), "x") = 0;
    else *cat(num(val[3], ovl8 * 10 / 8, 1), "x") = 0;
    const int pgk[4] = { pg0, pg1, 0, pg3 };
    for (int i = 0; i < 4; i++) {
        page_text(i, COL_X0 + COL_DX * i, 112, TXT4[i], pgk[i] ? LAB2[i] : LAB1[i]);
        page_text(4 + i, COL_X0 + COL_DX * i, 126, TXT4[i], val[i]);
    }
}

const op1_screen_t SCREEN_granular = { gr_screen_init, gr_screen_update };
