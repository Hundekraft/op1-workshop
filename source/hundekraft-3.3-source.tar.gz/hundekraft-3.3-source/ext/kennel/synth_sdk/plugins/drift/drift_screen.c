/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* DRIFT's screen (GUI thread): Terrain, the owner's approved concept A (host prototype terrain.py, 2026-11-13). The
 * sound's future as a landscape: the note that owns the land draws the near ridge (its wave table now) and the far
 * ridges (the same note further into its life, decoded by the engine's net through drift_view_table), stacked in
 * perspective with hidden lines. Back to front:
 *   sun      a white disc (drift.svg's "sun" node, moved by transform): height = filter cutoff; it sets into the sea
 *            in silence, sunk behind the skyline by black strips drawn before the ridges
 *   sub      a navy copy of the near ridge at half the frequency (sub level)
 *   ridges   green near ridge (64 segments), 6 far ridges of 16 segments (4 of 14 while op1_gfx_heavy)
 *   beacons  pink dots for the three patches nearest the knob position, on the ridge that matches the distance
 *   arc      red arc over the sun (resonance), clipped by the skyline
 *   rain     lavender rain rising from the sea for 0.7 s after a note on (comb feedback; damping shortens it)
 *   spray    a few lavender dots between the near ridges (noise level and colour)
 *   sparks   + (FM 1) or x (FM 2) over up to three crests of the near ridge
 *   wake     dots of the last 2.4 s of knob movement, in the colour of the knob that moved most
 *   gliders  one chevron per voice over its pitch, dropping in on note on, climbing away on release (gliders and the
 *            wake pass behind the sun)
 *   ticks    four short ticks along the top edge in the encoder colours, x = knob value
 * Owner of the land: the newest note, unless it is more than a fifth below the held owner. The camera pans gently
 * toward the owner's pitch. In silence the sea calms, and after 1.2 s three ridges drift slowly sideways.
 * Inputs: op1_synth_knobs_live (LFO included) and drift_view.h; nothing else of the engine. Integers only; the
 * state is static (a few KB of plugin memory, no TE heap). About 200 live lines a frame while playing, 90 idle.
 * Line ends are flat on R246, so dots are short lines as long as they are wide. */
#include "op1_plugin.h"
#include "drift_view.h"
#include "drift_screen_tables.h"

/* ---- palette (stock) ---- */
static const uint8_t C_BLUE[4] = { 0x69, 0x8E, 0xFF, 0xFF }, C_GREEN[4] = { 0x00, 0xED, 0x95, 0xFF };
static const uint8_t C_WHITE[4] = { 0xFF, 0xFF, 0xFF, 0xFF }, C_RED[4] = { 0xFF, 0x3A, 0x5D, 0xFF };
static const uint8_t C_LAV[4] = { 0xDE, 0xD7, 0xFF, 0xFF }, C_NAVY[4] = { 0x38, 0x35, 0x72, 0xFF };
static const uint8_t C_G3[4] = { 0x7C, 0x79, 0x90, 0xFF }, C_PERI[4] = { 0xAE, 0xB1, 0xDC, 0xFF };
static const uint8_t C_PINK[4] = { 0xFF, 0x90, 0xA7, 0xFF }, C_BLACK[4] = { 0x00, 0x00, 0x00, 0xFF };
static const uint8_t *const C_KNOB[4] = { C_BLUE, C_GREEN, C_WHITE, C_RED };

/* ---- layout, screen units Q10 (320 x 160) ---- */
#define U(v)      ((int32_t)((v) * 1024))
#define X0        3584                    /* 3.5 */
#define XW        320512                  /* 313: the ridges span 3.5 .. 316.5 */
#define XC        163840                  /* 160 */
#define CS        5008                    /* skyline column step (XW / 64) */
#define NCOL      64
#define Y_NEAR    U(104)
#define A_NEAR    U(15)
#define Y_SUB     U(126)
#define A_SUB     U(6)
#define YVAN      33938                   /* vanishing line: the far ridge's baseline lands on y 56 */
#define SUN_R     U(8)
#define NSTRIP    16                      /* the black strips that cut the sun along the ridge */
#define TAB_N     64
#define BIG       0x1FFFFFFF
#define Q15       32768

static uint32_t s_lines, s_decodes;       /* this frame: live lines, table decodes */
static int32_t s_scale = 1280;            /* panel pixels per unit, Q10 */
#ifdef OP1_HOST                           /* host tests: lines per part, and the reduced set on demand */
enum { DC_MASK, DC_SUB, DC_NEAR, DC_RIDGES, DC_BEACON, DC_ARC, DC_RAIN, DC_SPRAY, DC_SPARKS, DC_WAKE, DC_GLIDER, DC_TICKS, DC_N };
uint32_t drift_screen_cat[DC_N];
int drift_host_heavy;
static int s_cat;
#define CAT(c) (s_cat = DC_##c)
#define DS_HEAVY() (drift_host_heavy != 0)
#else
#define CAT(c) ((void)0)
#define DS_HEAVY() (op1_gfx_heavy() != 0)
#endif

#ifdef OP1_HOST
uint8_t drift_screen_line_cat[4096];                                  /* each line's part, in drawing order */
#endif
static void ln(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, const uint8_t *c)
{
    const op1_pt a = { x0, y0 }, b = { x1, y1 };
    op1_raster_line(r, &a, &b, w, c);
#ifdef OP1_HOST
    if (s_lines < 4096) drift_screen_line_cat[s_lines] = (uint8_t)s_cat;
    drift_screen_cat[s_cat]++;
#endif
    s_lines++;
}
static void dot(void *r, int32_t x, int32_t y, int32_t w, const uint8_t *c)   /* w px Q10: a square w wide */
{
    const int32_t h = (w << 9) / s_scale;                                        /* half of w in units, Q10 */
    ln(r, x - h, y, x + h, y, w, c);
}

static inline int32_t clampi(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }
static inline int32_t absi(int32_t v) { return v < 0 ? -v : v; }
static inline int32_t mulq(int32_t a, int32_t q15) { return (int32_t)(((int64_t)a * q15) >> 15); }
static inline int32_t sinq(uint32_t t16) { return OP1_SINE_TABLE[(t16 >> 3) & 8191]; }   /* turns Q16 -> Q15 */
static inline int32_t cosq(uint32_t t16) { return sinq(t16 + 16384); }
static int32_t ease_a(int dt, int tau_ms) { return (int32_t)(((int64_t)dt << 15) / (tau_ms + dt)); }   /* 1 - e^-x */
static void ease(int32_t *v, int32_t target, int32_t a, int32_t snap)
{
    *v += mulq(target - *v, a);
    if (absi(target - *v) < snap) *v = target;
}
static uint32_t isqrt(uint32_t x)
{
    uint32_t r = 0, b = 1u << 30;
    while (b > x) b >>= 2;
    while (b) { if (x >= r + b) { x -= r + b; r = (r >> 1) + b; } else r >>= 1; b >>= 2; }
    return r;
}
static int32_t lut65(const uint16_t *t, int32_t x15)                 /* x Q15 0..32768 over 65 points */
{
    x15 = clampi(x15, 0, Q15);
    const int i = x15 >> 9;
    if (i >= 64) return t[64];
    return t[i] + (((t[i + 1] - t[i]) * (x15 & 511)) >> 9);
}
static int32_t log2_q16(uint32_t x)                                  /* x Q16 > 0 -> log2(x) Q16 */
{
    const int n = 31 - __builtin_clz(x);
    const uint32_t m = n >= 16 ? x >> (n - 16) : x << (16 - n);       /* 1.f, Q16 */
    const uint32_t f = m & 0xFFFF, i = f >> 11, fr = f & 2047;
    return (n - 16) * 65536 + (int32_t)(ds_log2_t[i] + (((ds_log2_t[i + 1] - ds_log2_t[i]) * fr) >> 11));
}
static uint32_t exp2_q16(int32_t y)                                   /* 2^(y / 65536), Q16; y <= 0 here */
{
    const int32_t n = y >> 16;
    const uint32_t f = (uint32_t)y & 0xFFFF, i = f >> 11, fr = f & 2047;
    const uint32_t m = ds_exp2_t[i] + (((ds_exp2_t[i + 1] - ds_exp2_t[i]) * fr) >> 11);
    return n >= 0 ? m << n : n > -31 ? m >> -n : 0;
}
static int32_t powq15(int32_t b15, int32_t e16)                       /* b^e, b Q15 0..1, e Q16 >= 0 */
{
    if (b15 <= 0) return 0;
    if (b15 >= Q15) return Q15;
    const int32_t l = log2_q16((uint32_t)b15 << 1);
    return (int32_t)(exp2_q16((int32_t)(((int64_t)l * e16) >> 16)) >> 1);
}

/* ---- view snapshot and owner ---- */
typedef struct { uint32_t serial, age; int16_t pitch, vel; uint8_t note, vi, released, ok; int16_t prm[DRIFT_VIEW_NPRM]; } snap_t;
static snap_t s_vs[DRIFT_VIEW_VOICES];                                /* live voices this frame (ok = 1) */
static uint32_t s_vtick[DRIFT_VIEW_VOICES];
static uint16_t s_vstill[DRIFT_VIEW_VOICES];                          /* ms since the voice's tick last moved */
static uint8_t s_vmoved[DRIFT_VIEW_VOICES];                          /* frames running the tick moved (0..2) */
static snap_t s_cur = { 0, DS_AGE_CAP, 1638, 3277, 60, 0, 1, 1, { 2048 } };   /* the land's note (C4 at rest) */
static uint32_t s_own_serial;
static int s_has_owner;

static void read_voices(int dt)
{
    drift_view_sync();                                              /* the engine copies its voices' state in */
    for (int i = 0; i < DRIFT_VIEW_VOICES; i++) {
        const volatile drift_view_voice_t *v = &drift_view.v[i];
        const uint32_t t = v->tick;
        if (t != s_vtick[i]) { s_vtick[i] = t; s_vstill[i] = 0; if (s_vmoved[i] < 2) s_vmoved[i]++; }
        else if (s_vstill[i] < 60000) s_vstill[i] = (uint16_t)(s_vstill[i] + dt);
        if (s_vstill[i] >= 90) s_vmoved[i] = 0;             /* gone; it must tick on two frames running to return */
        snap_t *s = &s_vs[i];
        s->ok = (uint8_t)(v->active && v->serial && s_vmoved[i] >= 2);
        if (!s->ok) continue;
        s->serial = v->serial; s->age = v->age; s->pitch = v->pitch_q12; s->vel = v->vel_q12;
        s->note = v->note; s->vi = (uint8_t)i; s->released = v->released;
        for (int j = 0; j < DRIFT_VIEW_NPRM; j++) s->prm[j] = v->prm[j];
    }
}
/* the newest note, except that a note more than a fifth below the held owner does not take the land over */
static const snap_t *pick_owner(void)
{
    const snap_t *own = 0, *nv = 0;
    for (int i = 0; i < DRIFT_VIEW_VOICES; i++) {
        const snap_t *s = &s_vs[i];
        if (!s->ok) continue;
        if (s_has_owner && s->serial == s_own_serial) own = s;
        if (!nv || s->serial > nv->serial) nv = s;
    }
    if (!nv) { s_has_owner = 0; return 0; }
    if (!own || own->released || (nv != own && nv->note + 7 >= own->note)) own = nv;
    s_has_owner = 1; s_own_serial = own->serial;
    return own;
}

/* ---- state ---- */
static void *s_sun;
static uint32_t s_t;                                                  /* screen clock, ms */
static int32_t s_idle_t = 100000, s_calm = 14746, s_cam = 0x7FFFFFFF, s_sun_y = 0x7FFFFFFF;
static uint32_t s_drift24, s_swell16;
enum { P_CUT, P_RES, P_FM1, P_FM2, P_NOI, P_NCO, P_CFB, P_CDA, P_DRV, P_SUB, NPAR };
static int32_t s_par[NPAR] = { 16384 };
static int16_t s_near[TAB_N], s_near_dec[TAB_N];
static int16_t s_near_kn[4] = { -1 };
static uint32_t s_near_age = 0xFFFFFFFF, s_near_serial = 0xFFFFFFFF;
static int s_near_ok;
#define NSLOT 8
static struct { int8_t k; uint8_t ok, dok; uint32_t serial; int16_t u; int16_t kn[4]; int16_t c[TAB_N], d[TAB_N]; } s_sl[NSLOT];
static int16_t s_hist[52][4];                                        /* knobs every 50 ms, newest first */
static int s_hist_n;
static int32_t s_hist_acc;
#define NGL 12
static struct { uint8_t used, vi, seen; uint32_t serial, t0; int32_t x, rel_t, lift; int16_t vel; } s_gl[NGL];
static int32_t s_rest_x = XC;

/* ---- perspective (u: ridges ahead, Q8) ---- */
static int s_nvis = 6;
static int32_t r_of(int32_t u8) { return (int32_t)((1 << 27) / (4096 + ((8602 / s_nvis) * u8 >> 8))); }
static int32_t ybase(int32_t u8) { return YVAN + mulq(Y_NEAR - YVAN, r_of(u8)); }

/* ---- polylines and the skyline ---- */
#define MAXP 65
typedef struct { int n; int32_t x[MAXP], y[MAXP]; } poly_t;
static int32_t s_sky[NCOL + 1];
static int32_t poly_at(const poly_t *p, int32_t x)
{
    int i = (int)(((int64_t)(x - p->x[0]) * p->n) / (p->x[p->n] - p->x[0]));
    i = clampi(i, 0, p->n - 1);
    const int32_t xa = p->x[i], xb = p->x[i + 1];
    return p->y[i] + (int32_t)(((int64_t)(p->y[i + 1] - p->y[i]) * (x - xa)) / (xb - xa));
}
static int32_t sky_at(int32_t x)
{
    const int32_t d = x - X0;
    if (d <= 0) return s_sky[0];
    int c = d / CS;
    if (c >= NCOL) return s_sky[NCOL];
    const int32_t a = s_sky[c], b = s_sky[c + 1];
    return a + (int32_t)(((int64_t)(b - a) * (d - c * CS)) / CS);
}
static void sky_take(const poly_t *p)
{
    for (int c = 0; c <= NCOL; c++) { const int32_t y = poly_at(p, X0 + c * CS); if (y < s_sky[c]) s_sky[c] = y; }
}
/* draw where the polyline is above the skyline (0.6 units of grace); the visible pieces of one segment merge */
static void clip_draw(void *r, const poly_t *p, int32_t w, const uint8_t *col)
{
    for (int i = 0; i < p->n; i++) {
        const int32_t xa = p->x[i], xb = p->x[i + 1], ya = p->y[i], yb = p->y[i + 1];
        if (xb <= xa) continue;
        int32_t bx[16]; int nb = 0;
        bx[nb++] = xa;
        for (int c = (xa - X0) / CS + 1; c <= NCOL && nb < 15; c++) {
            const int32_t x = X0 + c * CS;
            if (x >= xb) break;
            if (x > xa) bx[nb++] = x;
        }
        bx[nb++] = xb;
        int32_t by[16], h[16];
        for (int j = 0; j < nb; j++) {
            by[j] = ya + (int32_t)(((int64_t)(yb - ya) * (bx[j] - xa)) / (xb - xa));
            h[j] = by[j] - sky_at(bx[j]) + 614;
        }
        int open = 0; int32_t pax = 0, pay = 0, pbx = 0, pby = 0;
        for (int j = 0; j + 1 < nb; j++) {
            const int32_t h0 = h[j], h1 = h[j + 1];
            int32_t lo, hi;
            if (h0 <= 0 && h1 <= 0) { lo = 0; hi = Q15; }
            else if (h0 > 0 && h1 > 0) {
                if (open) { if (pax != pbx || pay != pby) ln(r, pax, pay, pbx, pby, w, col); open = 0; }
                continue;
            } else {
                const int32_t f = (int32_t)(((int64_t)h0 << 15) / (h0 - h1));
                if (h0 <= 0) { lo = 0; hi = f; } else { lo = f; hi = Q15; }
            }
            const int32_t dx = bx[j + 1] - bx[j], dy = by[j + 1] - by[j];
            const int32_t ax = bx[j] + mulq(dx, lo), ay = by[j] + mulq(dy, lo);
            const int32_t ex = bx[j] + mulq(dx, hi), ey = by[j] + mulq(dy, hi);
            if (open && lo == 0) { pbx = ex; pby = ey; }
            else {
                if (open && (pax != pbx || pay != pby)) ln(r, pax, pay, pbx, pby, w, col);
                pax = ax; pay = ay; pbx = ex; pby = ey; open = 1;
            }
            if (hi < Q15) { if (pax != pbx || pay != pby) ln(r, pax, pay, pbx, pby, w, col); open = 0; }
        }
        if (open && (pax != pbx || pay != pby)) ln(r, pax, pay, pbx, pby, w, col);
    }
}
static void plain(void *r, const poly_t *p, int32_t w, const uint8_t *col)
{
    for (int i = 0; i < p->n; i++) ln(r, p->x[i], p->y[i], p->x[i + 1], p->y[i + 1], w, col);
}

static int32_t tab_at(const int16_t *t, uint32_t ph16)
{
    const int i = (int)(ph16 >> 10) & (TAB_N - 1);
    return t[i] + (((t[(i + 1) & (TAB_N - 1)] - t[i]) * (int32_t)(ph16 & 1023)) >> 10);
}
/* a ridge's points: u8 = 0 the near ridge; amp Q15 multiplies its height (calm, swell) */
static void ridge(poly_t *p, const int16_t *t, int32_t u8, int nseg, int32_t ampm, int32_t periods)
{
    const int32_t rr = u8 ? r_of(u8) : Q15, xs = u8 ? lut65(ds_pow035, rr) : Q15;
    const int32_t base = u8 ? ybase(u8) : Y_NEAR, amp = mulq(u8 ? mulq(A_NEAR, lut65(ds_pow07, rr)) : A_NEAR, ampm);
    /* phase (turns, Q24) = (x - XC + cam r) / XW x periods / xs + 1/4 + drift r */
    const int64_t k40 = ((int64_t)periods << 40) * Q15 / ((int64_t)XW * xs);   /* turns per Q10 unit, Q40 */
    const int64_t x0 = X0 - XC + mulq(s_cam, rr);
    const int64_t ph = ((x0 * k40) >> 16) + (1 << 22) + (((int64_t)s_drift24 * rr) >> 15);   /* Q24 */
    p->n = nseg;
    for (int i = 0; i <= nseg; i++) {
        const int32_t x = X0 + (int32_t)((int64_t)XW * i / nseg);
        const int64_t phi = ph + ((((int64_t)(x - X0)) * k40) >> 16);
        p->x[i] = x;
        p->y[i] = base - mulq(amp, tab_at(t, (uint32_t)(phi >> 8)));
    }
}

/* the engine's table, Q15, with the screen's drive fold (drive acts after the table in the engine) */
static int decode(const snap_t *s, uint32_t age, const int16_t *kn, int16_t *out)
{
    s_decodes++;
    return drift_view_table(s->pitch, s->vel, age, kn, out, TAB_N);
}
static void fold(int16_t *t, int32_t drive)
{
    if (drive <= 655) return;                                         /* 0.02 */
    const int32_t g = Q15 + mulq(72090, drive);                       /* 1 + 2.2 drive, Q15 */
    for (int i = 0; i < TAB_N; i++) {
        /* 0.9 sin(pi/2 g t / 0.9): angle in turns = g t / 3.6 */
        const int32_t a = (int32_t)(((int64_t)mulq(t[i], g) * 9102) >> 15);    /* turns, Q15 (x 1 / 3.6) */
        t[i] = (int16_t)mulq(29491, sinq((uint32_t)(a << 1)));
    }
}
static int knobs_moved(const int16_t *a, const int16_t *b)
{
    for (int j = 0; j < 4; j++) if (absi(a[j] - b[j]) > 64) return 1;  /* 1/512 */
    return 0;
}
static int32_t z_of(int j, int32_t k15)                             /* the engine's lt_zof */
{
    const int16_t *t = ds_z_of_knob[j];
    if (k15 <= 0) return t[0];
    if (k15 >= 32767) return t[64];
    const int i = k15 >> 9;
    return t[i] + (((t[i + 1] - t[i]) * (k15 & 511)) >> 9);
}
static const int32_t CVEC[4] = { 4096, -4096, 2253, -2253 };       /* knob deltas -> sideways, Q12 */
static int32_t cdot(const int16_t *a, const int16_t *b, int32_t off) /* sum (a - b - off) cvec, Q15 */
{
    int32_t s = 0;
    for (int j = 0; j < 4; j++) s += ((a[j] - (b ? b[j] : 0) - off) * CVEC[j]) >> 12;
    return s;
}

static void ds_init(void *scr) { s_sun = op1_find_node(scr, "sun"); }

/* the sun this frame, which gliders pass behind: shown, and the lowest y of it the ridges leave visible */
static int s_sun_vis;
static int32_t s_sun_low;
static uint64_t isqrt64(uint64_t x)
{
    uint64_t r = 0, b = (uint64_t)1 << 62;
    while (b > x) b >>= 2;
    while (b) { if (x >= r + b) { x -= r + b; r = (r >> 1) + b; } else r >>= 1; b >>= 2; }
    return r;
}
/* a line, less the part over the sun's disc (its radius grown by half the line's width and a pixel's antialiasing) */
static void ln_behind_sun(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, const uint8_t *c)
{
    if (!s_sun_vis) { ln(r, x0, y0, x1, y1, w, c); return; }
    const int64_t R = (SUN_R + (int32_t)(((int64_t)(w + 1024) << 9) / s_scale)) >> 4;   /* units Q6 */
    const int64_t fx = (x0 - XC) >> 4, fy = (y0 - s_sun_y) >> 4, dx = (x1 - x0) >> 4, dy = (y1 - y0) >> 4;
    const int64_t a = dx * dx + dy * dy, b = fx * dx + fy * dy, cc = fx * fx + fy * fy - R * R;   /* |f + t d|^2 = R^2 */
    const int64_t disc = b * b - a * cc;
    if (!a || disc <= 0) { ln(r, x0, y0, x1, y1, w, c); return; }
    const int64_t sq = (int64_t)isqrt64((uint64_t)disc);
    int64_t t0 = ((-b - sq) << 15) / a, t1 = ((-b + sq) << 15) / a;             /* inside for t0 < t < t1, Q15 */
    {   /* only where the disc shows: above the lowest point of its cut (grown as the radius is) */
        const int32_t yl = s_sun_low + (int32_t)(((int64_t)(w + 1024) << 9) / s_scale);
        if (y1 != y0) {
            const int64_t tc = ((int64_t)(yl - y0) << 15) / (y1 - y0);
            if (y1 > y0) { if (tc < t1) t1 = tc; } else if (tc > t0) t0 = tc;
        } else if (y0 >= yl) t1 = t0;
    }
    if (t1 <= t0 || t1 <= 0 || t0 >= Q15) { ln(r, x0, y0, x1, y1, w, c); return; }
    const int32_t ddx = x1 - x0, ddy = y1 - y0;
    if (t0 > 0) ln(r, x0, y0, x0 + mulq(ddx, (int32_t)t0), y0 + mulq(ddy, (int32_t)t0), w, c);
    if (t1 < Q15) ln(r, x0 + mulq(ddx, (int32_t)t1), y0 + mulq(ddy, (int32_t)t1), x1, y1, w, c);
}
static void glider(void *r, int32_t x, int32_t y, int32_t sc, const uint8_t *c)
{
    const int32_t w = mulq(2048, sc > 18022 ? sc : 18022);
    ln_behind_sun(r, x - mulq(U(5), sc), y + mulq(U(2), sc), x, y - mulq(U(2.6), sc), w, c);
    ln_behind_sun(r, x, y - mulq(U(2.6), sc), x + mulq(U(5), sc), y + mulq(U(2), sc), w, c);
}

static void ds_update(void *scr, int dt)
{
    void *r = op1_raster();
    s_lines = 0; s_decodes = 0;
#ifdef OP1_HOST
    for (int i = 0; i < DC_N; i++) drift_screen_cat[i] = 0;
#endif
    dt = clampi(dt, 1, 200);
    s_t += (uint32_t)dt;
#ifdef OP1_HOST
    s_scale = host_screen_scale;
#else
    s_scale = op1_panel_rows(r) * 1024 / 320;
#endif
    const int heavy = DS_HEAVY();
    s_nvis = heavy ? 4 : 6;
    const int nseg = heavy ? 14 : 16;
    int16_t kn[4];
    op1_synth_knobs_live(OP1_SCREEN_SLOT & 7, kn);
    for (int j = 0; j < 4; j++) kn[j] = (int16_t)clampi(kn[j], 0, 32767);

    /* knob history (wake) */
    s_hist_acc += dt;
    if (!s_hist_n) { for (int j = 0; j < 4; j++) s_hist[0][j] = kn[j]; s_hist_n = 1; s_hist_acc = 0; }
    while (s_hist_acc >= 50) {
        s_hist_acc -= 50;
        for (int i = 51; i > 0; i--) for (int j = 0; j < 4; j++) s_hist[i][j] = s_hist[i - 1][j];
        for (int j = 0; j < 4; j++) s_hist[0][j] = kn[j];
        if (s_hist_n < 52) s_hist_n++;
    }

    read_voices(dt);
    const snap_t *nv = pick_owner();
    int any = 0;
    for (int i = 0; i < DRIFT_VIEW_VOICES; i++) any |= s_vs[i].ok;
    if (nv) { s_cur = *nv; s_idle_t = 0; } else if (s_idle_t < 100000) s_idle_t += dt;
    const snap_t *cur = &s_cur;
    const uint32_t age = cur->age < DS_AGE_CAP ? cur->age : DS_AGE_CAP;

    /* the block's settings, eased */
    {
        int32_t tg[NPAR] = { 0 };
        if (nv) {
            const int16_t *m = nv->prm;
#define SQ(x) ((int32_t)isqrt((uint32_t)clampi((x), 0, 4096) << 12) << 3)
            tg[P_CUT] = clampi(m[DV_CUT], 0, 4096) << 3; tg[P_RES] = clampi(m[DV_RES], 0, 4096) << 3;
            tg[P_FM1] = SQ(m[DV_FMA]); tg[P_FM2] = SQ(m[DV_FMB]); tg[P_NOI] = SQ(m[DV_NOI]);
            tg[P_NCO] = clampi(m[DV_NCO], 0, 4096) << 3; tg[P_CFB] = clampi(m[DV_CFB], 0, 4096) << 3;
            tg[P_CDA] = clampi(m[DV_CDA], 0, 4096) << 3; tg[P_DRV] = SQ(m[DV_DRV]); tg[P_SUB] = SQ(m[DV_SUB]);
#undef SQ
        } else tg[P_CUT] = s_par[P_CUT];
        const int32_t a = ease_a(dt, 50);
        for (int j = 0; j < NPAR; j++) ease(&s_par[j], clampi(tg[j], 0, Q15), a, 66);
    }
    const int32_t *P = s_par;
    ease(&s_calm, any ? Q15 : 14746, ease_a(dt, any ? 80 : 300), 164);

    /* near ridge: the owner's table now (decoded again only when the note ages or a knob moves) */
    if (!s_near_ok || cur->serial != s_near_serial || (age != s_near_age && s_near_age < DS_AGE_CAP) || knobs_moved(kn, s_near_kn)) {
        if (decode(cur, age, kn, s_near_dec)) {
            fold(s_near_dec, P[P_DRV]);
            s_near_age = age; s_near_serial = cur->serial;
            for (int j = 0; j < 4; j++) s_near_kn[j] = kn[j];
        }
    }
    if (!s_near_ok || !nv) { for (int i = 0; i < TAB_N; i++) s_near[i] = s_near_dec[i]; s_near_ok = 1; }
    else { const int32_t a = ease_a(dt, 25); for (int i = 0; i < TAB_N; i++) s_near[i] = (int16_t)(s_near[i] + mulq(s_near_dec[i] - s_near[i], a)); }

    /* camera: a slow pan toward the owner's pitch, 1 unit a semitone, 16 at most */
    {
        const int32_t ct = clampi(cur->pitch * 15 - 25805, -U(16), U(16));
        if (s_cam == 0x7FFFFFFF) s_cam = ct;
        ease(&s_cam, ct, ease_a(dt, 300), 10);
    }
    const int idle = !nv && s_idle_t > 1200;
    if (idle) s_drift24 += (uint32_t)dt * 587;                       /* 0.035 turns a second */
    s_swell16 += (uint32_t)dt * 7209 / 1000;                          /* 0.11 Hz */

    /* far ridges: the owner's future, pinned to times since note on, sliding toward the viewer */
    const int32_t s8 = (int32_t)(age >> 4) >= 128 ? ds_s_of_age[128]
        : ds_s_of_age[age >> 4] + (((ds_s_of_age[(age >> 4) + 1] - ds_s_of_age[age >> 4]) * (int32_t)(age & 15)) >> 4);
    const int k0 = (s8 >> 8) + 1;
    {   /* the land changed hands: the old tables morph into the new keys instead of snapping */
        int old[NSLOT], no = 0;
        for (int i = 0; i < NSLOT; i++) if (s_sl[i].dok && s_sl[i].serial != cur->serial) old[no++] = i;
        if (no) {
            for (int a = 1; a < no; a++) for (int b = a; b > 0 && s_sl[old[b]].u < s_sl[old[b - 1]].u; b--) {
                const int t = old[b]; old[b] = old[b - 1]; old[b - 1] = t;
            }
            static int16_t keep[NSLOT][TAB_N];
            for (int i = 0; i < no; i++) for (int j = 0; j < TAB_N; j++) keep[i][j] = s_sl[old[i]].d[j];
            for (int i = 0; i < NSLOT; i++) s_sl[i].dok = s_sl[i].ok = 0;
            int n = 0;
            for (int k = k0; k <= k0 + s_nvis && n < NSLOT; k++) {
                const int32_t u = k * 256 - s8;
                if (u <= 13 || u > s_nvis * 256) continue;
                s_sl[n].k = (int8_t)k; s_sl[n].serial = cur->serial; s_sl[n].dok = 1;
                for (int j = 0; j < TAB_N; j++) s_sl[n].d[j] = keep[n < no ? n : no - 1][j];
                n++;
            }
        }
    }
    int sl_of[NSLOT], nr = 0;
    int32_t ru[NSLOT];
    {
        int budget = 8;
        uint8_t live[NSLOT] = { 0 };
        for (int i = 0; i < NSLOT; i++) {                             /* free the slots whose ridge has gone */
            const int32_t u = s_sl[i].k * 256 - s8;
            if (s_sl[i].serial != cur->serial || s_sl[i].k < k0 || u <= 13 || u > s_nvis * 256) s_sl[i].ok = s_sl[i].dok = 0;
        }
        for (int k = k0; k <= k0 + s_nvis; k++) {
            const int32_t u = k * 256 - s8;
            if (u <= 13 || u > s_nvis * 256) continue;
            const int kk = k < DS_KMAX ? k : DS_KMAX - 1;
            int sl = -1;
            for (int i = 0; i < NSLOT; i++) if (s_sl[i].dok && s_sl[i].serial == cur->serial && s_sl[i].k == k) sl = i;
            if (sl < 0) for (int i = 0; i < NSLOT; i++) if (!s_sl[i].dok && !live[i]) { sl = i; break; }
            if (sl < 0) continue;
            live[sl] = 1;
            if (s_sl[sl].serial != cur->serial || s_sl[sl].k != k) { s_sl[sl].ok = 0; s_sl[sl].dok = 0; }
            s_sl[sl].k = (int8_t)k; s_sl[sl].serial = cur->serial; s_sl[sl].u = (int16_t)u;
            if (!s_sl[sl].ok || (budget > 0 && knobs_moved(kn, s_sl[sl].kn))) {   /* at most 8 a frame for knob moves */
                if (decode(cur, ds_ridge_age[kk], kn, s_sl[sl].c)) {
                    s_sl[sl].ok = 1;
                    for (int j = 0; j < 4; j++) s_sl[sl].kn[j] = kn[j];
                }
                budget--;
            }
            if (!s_sl[sl].ok) { if (!s_sl[sl].dok) continue; }
            else if (!s_sl[sl].dok) { for (int j = 0; j < TAB_N; j++) s_sl[sl].d[j] = s_sl[sl].c[j]; s_sl[sl].dok = 1; }
            else {
                const int32_t a = ease_a(dt, 60);
                for (int j = 0; j < TAB_N; j++) s_sl[sl].d[j] = (int16_t)(s_sl[sl].d[j] + mulq(s_sl[sl].c[j] - s_sl[sl].d[j], a));
            }
            sl_of[nr] = sl; ru[nr] = u; nr++;
        }
        for (int i = 0; i < NSLOT; i++) if (!live[i]) s_sl[i].ok = s_sl[i].dok = 0;
    }
    if (idle && nr) {                                                 /* idle: every other ridge from the front, three */
        int n = 0;
        for (int i = 0; i < nr && n < 3; i += 2) { sl_of[n] = sl_of[i]; ru[n] = ru[i]; n++; }
        nr = n;
    }

    /* geometry */
    static poly_t near, far[NSLOT], sub;
    ridge(&near, s_near, 0, idle ? 32 : 64, s_calm, 2);
    for (int i = 0; i < nr; i++) {
        int32_t am = s_calm;
        if (idle) am = mulq(am, Q15 + mulq(3932, sinq(s_swell16 + (uint32_t)ru[i] * 53)));
        ridge(&far[i], s_sl[sl_of[i]].d, ru[i], idle ? 14 : nseg, am, 2);
    }
    const int32_t y_far = ybase(s_nvis * 256) + 1024;

    /* sun: height = cutoff; sets halfway into the sea in silence */
    {
        const int32_t tg = nv ? y_far + U(2) - mulq(y_far + U(2) - U(22), P[P_CUT]) : y_far - 1024;
        if (s_sun_y == 0x7FFFFFFF) s_sun_y = tg;
        ease(&s_sun_y, tg, ease_a(dt, nv ? 60 : 320), 51);
    }
    const int sun_on = s_sun_y - SUN_R < y_far;
    if (s_sun) {
        const int32_t m[9] = { 1024, 0, 0, 0, 1024, 0, XC, s_sun_y, 1024 };
        op1_node_set_transform(s_sun, m);
        op1_node_set_visible(s_sun, sun_on);
    }
    s_sun_vis = sun_on;
    op1_screen_draw(scr, dt);

    /* the final skyline first: the black strips that sink the sun go before the ridges */
    for (int c = 0; c <= NCOL; c++) s_sky[c] = BIG;
    sky_take(&near);
    for (int i = 0; i < nr; i++) sky_take(&far[i]);
    CAT(MASK);
    if (sun_on) {   /* the cut follows the ridge line: narrow strips, each from the topmost ridge at its centre down (the
                     * ridge's stroke, drawn later, covers the join); a pixel and more of overlap, so no seam lets the
                     * disc through */
        const int32_t xa = XC - SUN_R - 512, sw = (2 * SUN_R + 1024) / NSTRIP, bot = s_sun_y + SUN_R + 512;
        const int32_t w = (int32_t)(((int64_t)sw * s_scale) >> 10) + 1331;    /* px: the strip's width + 1.3 px */
        s_sun_low = s_sun_y - SUN_R;
        for (int i = 0; i < NSTRIP; i++) {
            const int32_t x = xa + i * sw + sw / 2;
            int32_t top = poly_at(&near, x);
            for (int k = 0; k < nr; k++) { const int32_t y = poly_at(&far[k], x); if (y < top) top = y; }
            if (top < s_sun_y - SUN_R - 512) top = s_sun_y - SUN_R - 512;
            if (top < bot) ln(r, x, top, x, bot, w, C_BLACK);
            if (top > s_sun_low) s_sun_low = top < bot ? top : bot;
        }
    }

    /* sub */
    CAT(SUB);
    if ((P[P_SUB] > 1638 && !heavy) || P[P_SUB] > 8192) {
        sub.n = 16;
        for (int i = 0; i <= 16; i++) {
            const int32_t x = X0 + XW * i / 16;
            const uint32_t ph = (uint32_t)((((int64_t)(x - XC + s_cam)) << 16) / XW) + 16384;
            sub.x[i] = x; sub.y[i] = Y_SUB - mulq(mulq(A_SUB, s_calm), tab_at(s_near, ph));
        }
        plain(r, &sub, 1229 + mulq(1638, P[P_SUB]), C_NAVY);
    }

    /* near ridge and the far ridges, front to back, hidden lines */
    for (int c = 0; c <= NCOL; c++) s_sky[c] = BIG;
    CAT(NEAR);
    clip_draw(r, &near, 2458, C_GREEN);
    sky_take(&near);
    /* beacons: the three patches nearest the knob position, on the ridge matching their distance */
    int32_t bx[3], by[3]; int nb = 0;
    int bridge[3] = { -1, -1, -1 };
    int32_t bxs[3];
    {
        int32_t z[4], best[3] = { BIG, BIG, BIG }; int bi[3] = { -1, -1, -1 };
        for (int j = 0; j < 4; j++) z[j] = z_of(j, kn[j]);
        for (int a = 0; a < DS_NANCH; a++) {
            uint32_t s2 = 0;
            for (int j = 0; j < 4; j++) { const int32_t d = (ds_anch_z[a][j] - z[j]) >> 2; s2 += (uint32_t)(d * d); }
            const int32_t d = (int32_t)isqrt(s2) << 2;               /* Q12 */
            for (int q = 0; q < 3; q++) if (d < best[q]) {
                for (int m = 2; m > q; m--) { best[m] = best[m - 1]; bi[m] = bi[m - 1]; }
                best[q] = d; bi[q] = a; break;
            }
        }
        for (int q = 0; q < 3 && nr; q++) {
            if (bi[q] < 0 || best[q] >= 9011) continue;               /* 2.2 */
            int32_t ua = 358 + (best[q] >> 3);                        /* 1.4 + 2 d */
            if (ua > s_nvis * 256 - 51) ua = s_nvis * 256 - 51;
            int g = 0;
            for (int i = 1; i < nr; i++) if (absi(ru[i] - ua) < absi(ru[g] - ua)) g = i;
            bridge[q] = g;
            bxs[q] = XC + mulq(U(150), clampi(cdot(ds_anch_k[bi[q]], kn, 0), -Q15, Q15));
        }
    }
    for (int i = 0; i < nr; i++) {
        const int32_t rr = r_of(ru[i]), u = ru[i];
        const uint8_t *col;
        if (!heavy) col = u < 333 ? C_NAVY : u < 666 ? C_G3 : u < s_nvis * 256 - 230 ? C_PERI : C_LAV;
        else col = u < 256 ? C_NAVY : u < 512 ? C_G3 : u < 794 ? C_PERI : C_LAV;
        for (int q = 0; q < 3; q++) if (bridge[q] == i) {
            const int32_t ay = poly_at(&far[i], bxs[q]);
            if (ay - 512 <= sky_at(bxs[q])) { bx[nb] = bxs[q]; by[nb] = ay - U(1.6); nb++; }
        }
        CAT(RIDGES);
        clip_draw(r, &far[i], 922 + mulq(1126, rr), col);
        sky_take(&far[i]);
    }
    CAT(BEACON);
    for (int q = 0; q < nb; q++) dot(r, bx[q], by[q], 3686, C_PINK);

    /* resonance: the red arc over the sun, clipped by the skyline */
    CAT(ARC);
    if (P[P_RES] > 1311 && sun_on) {
        static poly_t arc;
        const int32_t hw = SUN_R + U(7) - mulq(U(4), P[P_RES]), hh = SUN_R + U(3) + mulq(U(22), P[P_RES]);
        arc.n = 14;
        for (int i = 0; i <= 14; i++) {
            const uint32_t a = (uint32_t)(i * 32768 / 14);
            arc.x[i] = XC + mulq(hw, cosq(a));
            arc.y[i] = s_sun_y - mulq(hh, sinq(a));
            if (arc.y[i] < U(4)) arc.y[i] = U(4);
        }
        /* x runs right to left: draw it reversed so poly segments go left to right */
        static poly_t ra;
        ra.n = 14;
        for (int i = 0; i <= 14; i++) { ra.x[i] = arc.x[14 - i]; ra.y[i] = arc.y[14 - i]; }
        clip_draw(r, &ra, 1843, C_RED);
    }

    /* comb: rain rising from the sea, one shower per note on */
    const int32_t rain_ms = (int32_t)((cur->age < 100000 ? cur->age : 100000) * 1486 >> 10);
    CAT(RAIN);
    if (P[P_CFB] > 2621 && !heavy && nv && rain_ms < 700) {
        static const int32_t RX[8] = { 24064, 70187, 97689, 143993, 189934, 217438, 263921, 309678 };
        for (int i = 0; i < 8; i++) {
            int32_t base = sky_at(RX[i]);
            if (y_far < base) base = y_far;
            base -= U(1.5);
            const int32_t ph = clampi(rain_ms * Q15 / 700 + 2621 * (i % 3), 0, Q15);
            const int32_t e16 = 65536 + (int32_t)(((int64_t)3 * P[P_CDA]) << 1);   /* 1 + 3 damp, Q16 */
            const int32_t L = mulq(U(5) + mulq(U(24), P[P_CFB]), powq15(Q15 - ph, e16));
            if (L < U(0.8)) continue;
            const int32_t rise = mulq(mulq(U(12), ph), P[P_CFB]);
            ln(r, RX[i], base - rise, RX[i], base - rise - L, 1024, C_LAV);
        }
    }

    /* noise: spray between the near ridges, re-scattered ten times a second */
    CAT(SPRAY);
    if (P[P_NOI] > 1966 && !heavy) {
        uint32_t rng = (s_t / 100) * 2654435761u + 1;
        const int32_t col = P[P_NCO];
        const int nd = (int)((mulq(P[P_NOI], 3 * Q15 + 5 * col) + 16384) >> 15);
        const int32_t ya = ybase(230), L = U(0.3) + mulq(U(1), Q15 - col), w = 1331 + mulq(819, Q15 - col);
        for (int i = 0; i < nd; i++) {
            rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
            const int32_t x = X0 + U(4) + (int32_t)((rng >> 8) % (uint32_t)(XW - U(8)));
            const int32_t yb = poly_at(&near, x) - U(2);
            rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
            if (yb <= ya) continue;
            const int32_t y = ya + (int32_t)((rng >> 8) % (uint32_t)(yb - ya));
            ln(r, x - L / 2, y, x + L / 2, y, w, C_LAV);
        }
    }

    /* FM: sparks on the near ridge's crests (+ FM 1, x FM 2) */
    {
        const int32_t fm = P[P_FM1] > P[P_FM2] ? P[P_FM1] : P[P_FM2];
        CAT(SPARKS);
        if (fm > 2621 && nv) {
            int ci[3] = { -1, -1, -1 };
            for (int i = 2; i < near.n - 1; i++) {
                const int32_t y = near.y[i];
                if (!(y < near.y[i - 1] && y <= near.y[i + 1] && y < Y_NEAR - U(3))) continue;
                for (int q = 0; q < 3; q++) if (ci[q] < 0 || y < near.y[ci[q]]) {
                    for (int m = 2; m > q; m--) ci[m] = ci[m - 1];
                    ci[q] = i; break;
                }
            }
            const int32_t sz = U(1) + mulq(U(3.5), fm);
            for (int q = 0; q < 3; q++) {
                if (ci[q] < 0) continue;
                const int32_t cx = near.x[ci[q]], cy = near.y[ci[q]] - U(3.8);
                if (P[P_FM2] >= P[P_FM1]) {
                    const int32_t s2 = mulq(sz, 22938);
                    ln(r, cx - s2, cy - s2, cx + s2, cy + s2, 1024, C_WHITE);
                    ln(r, cx - s2, cy + s2, cx + s2, cy - s2, 1024, C_WHITE);
                } else {
                    ln(r, cx - sz, cy, cx + sz, cy, 1024, C_LAV);
                    ln(r, cx, cy - sz, cx, cy + sz, 1024, C_LAV);
                }
            }
        }
    }

    /* knob wake: the last 2.4 s of knob movement as dots receding into the distance */
    {
        const int nd = heavy ? 6 : 12;
        CAT(WAKE);
        int16_t ka[4], kb[4];
        for (int j = 1; j <= nd; j++) {
            const int32_t a0 = (j - 1) * 2400 / nd, a1 = j * 2400 / nd;
            if (a1 / 50 + 1 >= s_hist_n) break;
            for (int q = 0; q < 2; q++) {                             /* the knobs (q ? a1 : a0) ms ago */
                const int32_t am = (q ? a1 : a0) - s_hist_acc;          /* age relative to the newest entry */
                int16_t *o = q ? kb : ka;
                for (int m = 0; m < 4; m++) {
                    if (am <= 0) { o[m] = s_hist[0][m]; continue; }
                    const int32_t i = am / 50, f = am % 50, va = s_hist[i][m], vb = s_hist[i + 1 < 52 ? i + 1 : 51][m];
                    o[m] = (int16_t)(va + (vb - va) * f / 50);
                }
            }
            int32_t mx = 0; int mk = 0;
            for (int m = 0; m < 4; m++) { const int32_t d = absi(ka[m] - kb[m]); if (d > mx) { mx = d; mk = m; } }
            if (mx < 131 || mx > 1966) continue;
            const int32_t u = 90 + (int32_t)((int64_t)a1 * (s_nvis * 256 - 154) / 2400);
            const int32_t rr = r_of(u);
            const int32_t x = XC + mulq(U(140), clampi(cdot(kb, 0, 16384), -34406, 34406));
            const int32_t y = ybase(u) - U(3.5) - mulq(U(4), rr);
            const int32_t w = 1229 + mulq(1638, rr), h = (w << 9) / s_scale;
            ln_behind_sun(r, x - h, y, x + h, y, w, C_KNOB[mk]);          /* a dot, behind the sun */
        }
    }

    /* gliders: one per voice over its pitch */
    CAT(GLIDER);
    for (int g = 0; g < NGL; g++) s_gl[g].seen = 0;
    for (int i = 0; i < DRIFT_VIEW_VOICES; i++) {
        const snap_t *s = &s_vs[i];
        if (!s->ok) continue;
        int g = -1;
        for (int q = 0; q < NGL; q++) if (s_gl[q].used && s_gl[q].vi == i && s_gl[q].serial == s->serial) g = q;
        const int32_t x = clampi(U(24) + (s->note - 36) * 5530, U(14), U(306));
        if (g < 0) {
            for (int q = 0; q < NGL; q++) if (!s_gl[q].used) { g = q; break; }
            if (g < 0) continue;
            int32_t lift = 0;
            for (int l = 0; l < 3; l++) {                                /* a neighbour sits a step higher */
                const int32_t cand = l * U(7);
                int used = 0;
                for (int q = 0; q < NGL; q++)
                    if (s_gl[q].used && s_gl[q].rel_t < 0 && s_gl[q].lift == cand && absi(s_gl[q].x - x) < U(11.5)) used = 1;
                if (!used) { lift = cand; break; }
            }
            s_gl[g].used = 1; s_gl[g].vi = (uint8_t)i; s_gl[g].serial = s->serial; s_gl[g].x = x; s_gl[g].t0 = s_t;
            s_gl[g].rel_t = -1; s_gl[g].lift = lift; s_gl[g].vel = s->vel;
        }
        s_gl[g].seen = 1;
        if (s->released && s_gl[g].rel_t < 0) s_gl[g].rel_t = (int32_t)s_t;
    }
    int ngl = 0;
    for (int g = 0; g < NGL; g++) {
        if (!s_gl[g].used) continue;
        if (!s_gl[g].seen && s_gl[g].rel_t < 0) s_gl[g].rel_t = (int32_t)s_t;   /* stolen or ended: leave now */
        const int32_t age_ms = (int32_t)(s_t - s_gl[g].t0);
        int32_t x = s_gl[g].x;
        const int32_t hover = poly_at(&near, x) - (U(8) + s_gl[g].vel);   /* 8 + 4 v units: v Q12 x 4 = Q10 */
        int32_t y = hover, sc = Q15;
        int plumb = age_ms >= 220;
        const uint8_t *col = C_BLUE;
        if (age_ms < 220) {                                           /* drop in, overshoot once */
            const int32_t p = age_ms * Q15 / 220 - Q15;               /* p - 1, Q15 */
            const int32_t p2 = mulq(p, p), p3 = mulq(p2, p);
            const int32_t e = Q15 + mulq(104858, p3) + mulq(72090, p2);
            const int32_t y0 = hover - U(26) > U(6) ? hover - U(26) : U(6);
            y = y0 + mulq(hover - y0, e);
        }
        if (s_gl[g].rel_t >= 0) {
            const int32_t ra = (int32_t)s_t - s_gl[g].rel_t;
            if (ra > 400) { s_gl[g].used = 0; s_rest_x = x; continue; }
            const int32_t p = ra * Q15 / 400, e = mulq(mulq(p, p), 3 * Q15 - 2 * p);
            y += mulq(y_far - U(14) - y, e);
            x += mulq(mulq(XC - x, 6554), e);
            sc = Q15 - mulq(19661, e);
            plumb = 0;
            col = p < 16384 ? C_BLUE : C_G3;
        }
        y -= s_gl[g].lift;
        if (y < U(6.5)) y = U(6.5);
        glider(r, x, y, sc, col);
        ngl++;
        if (plumb) {
            const int32_t yb = poly_at(&near, x) - U(1.2), yt = y + mulq(U(2.2), sc);
            if (yb - yt > U(1)) ln_behind_sun(r, x, yt, x, yb, 819, C_WHITE);
        }
    }
    if (!ngl && s_idle_t > 600) {                                      /* resting glider in silence */
        const int32_t x = s_rest_x, y = poly_at(&near, x) - U(4);
        ln_behind_sun(r, x - U(5.5), y + U(0.6), x, y - U(1.6), 2048, C_PERI);
        ln_behind_sun(r, x, y - U(1.6), x + U(5.5), y + U(0.6), 2048, C_PERI);
    }

    /* knob ticks along the top edge, in the encoder colours */
    CAT(TICKS);
    for (int j = 0; j < 4; j++) {
        const int32_t x = U(8) + mulq(U(304), kn[j]);
        ln(r, x, U(4.6), x, U(10) - j * 1024, 2253, C_KNOB[j]);
    }
}

#ifdef OP1_HOST
uint32_t drift_screen_lines(void) { return s_lines; }
int drift_screen_sun(int32_t *y, int32_t *low) { *y = s_sun_y; *low = s_sun_low; return s_sun_vis; }
uint32_t drift_screen_decodes(void) { return s_decodes; }
#endif

const op1_screen_t SCREEN_drift = { ds_init, ds_update };
