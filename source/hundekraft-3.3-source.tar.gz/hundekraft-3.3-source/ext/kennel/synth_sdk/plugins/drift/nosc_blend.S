/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* nosc_blend_asm(c, basis, tab): tab[i] = sat16((sum_b c[b] * basis[b][i]) >> 12), i = 0..127, b = 0..15.
 * Two samples a pass: one 32-bit load (basis[b][i], [i+1]) and one 16-bit load (c[b]) a cycle, dual MAC into
 * A0 / A1 (40 bits, no overflow at 16 terms), arithmetic shift, saturating extract. Same result as nosc_core.h's C
 * with a 64-bit accumulator. basis rows and tab 4-byte aligned; NB = 16, TL = 128 fixed. */
.text
.global _nosc_blend_asm
.align 4
_nosc_blend_asm:
    [--SP] = (R7:4, P5:3);
    P0 = R1;                    /* basis column pair */
    P2 = R2;                    /* tab */
    P1 = 64;                    /* pairs */
    P3 = 15;                    /* NB - 1 */
    M1 = 256;                   /* TL x 2: next basis row */
    LSETUP(o_s, o_e) LC1 = P1;
o_s: I0 = R0;
    I1 = P0;
    A1 = A0 = 0 || R5 = [I1 ++ M1] || R4.L = W[I0++];
    LSETUP(i_s, i_s) LC0 = P3;
i_s: A1 += R4.L * R5.H, A0 += R4.L * R5.L (IS) || R5 = [I1 ++ M1] || R4.L = W[I0++];
    A1 += R4.L * R5.H, A0 += R4.L * R5.L (IS);
    A0 = A0 >>> 12;
    A1 = A1 >>> 12;
    R6.H = A1, R6.L = A0 (IS);
    P0 += 4;
o_e: [P2++] = R6;
    (R7:4, P5:3) = [SP++];
    RTS;
