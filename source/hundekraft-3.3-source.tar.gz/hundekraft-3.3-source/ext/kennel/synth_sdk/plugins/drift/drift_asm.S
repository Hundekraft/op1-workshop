/* drift's Blackfin kernels: the engine's three asm files, unchanged, and the output level pass lt_gain_s, assembled
 * only for the Blackfin (host builds of the plugin use the C specs in nosc2_kern.h, nosc2_core.h and drift.c).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#if defined(__bfin__)
#include "nosc2_kern.S"
#include "nosc_blend.S"
#include "mv16.S"

/* lt_gain_s(buf, h): buf[i] = sat16(2 x ((buf[i] x h) >> 15)) (floor, then doubled: +6 dB, owner 2026-11-14), 128
 * int16, buf 4-byte aligned, 0 <= h <= 32767 (h is a 1.15 operand; drift.c caps the velocity x preset trim there):
 * a vector 1.15 multiply (truncated) and a saturating vector add, one pair of samples per two cycles; drift.c's C
 * loop is the spec */
.text
.global _lt_gain_s
.align 4
_lt_gain_s:
    I0 = R0;
    I1 = R0;
    P0 = 62;
    R0 = [I0++];
    R2.H = R0.H * R1.L, R2.L = R0.L * R1.L (T) || R0 = [I0++];
    R3 = R2 +|+ R2 (S);
    LSETUP(lg_s, lg_e) LC0 = P0;
lg_s: R2.H = R0.H * R1.L, R2.L = R0.L * R1.L (T) || R0 = [I0++] || [I1++] = R3;
lg_e: R3 = R2 +|+ R2 (S);
    R2.H = R0.H * R1.L, R2.L = R0.L * R1.L (T) || [I1++] = R3;
    R3 = R2 +|+ R2 (S);
    [I1++] = R3;
    RTS;
#endif
