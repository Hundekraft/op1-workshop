/* knob_law_render: one DRIFT note per input line, for knob_law.py (host only, not in the plugin).
 *
 *   cc -O2 -Wno-unused-function -I. knob_law_render.c -lm -o knob_law_render
 *   knob_law_render MIDI < z.txt > windows.raw
 *
 * Each stdin line is four z values (Q12). The note (velocity 0.8, a fresh voice and a fresh envelope head at that z,
 * the knobs held) is rendered through the engine (nosc2_core.h, the C kernels) the way drift_exact_test drives it, and
 * three windows of 2048 samples (int16, the voice's 88.2 kHz output) are written to stdout: from 12 ms, 145 ms and
 * 435 ms after the note's start (blocks 8, 100 and 300).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <nosc2_weights.h>

static struct nosc2_l1 l1_mem;
static struct nosc2_envnet env;
static struct nosc2_voice v;

int main(int argc, char **argv)
{
    const int m = argc > 1 ? atoi(argv[1]) : 48;
    const int at[3] = { 8, 100, 300 };
    l1_mem = nosc2_l1_init;
    const uint32_t inc = (uint32_t)llround(440.0 * pow(2.0, (m - 69) / 12.0) / 88200.0 * 4294967296.0);
    int z0, z1, z2, z3;
    static int16_t out[BLK], win[3][2048];
    while (scanf("%d %d %d %d", &z0, &z1, &z2, &z3) == 4) {
        int16_t z[4] = { (int16_t)z0, (int16_t)z1, (int16_t)z2, (int16_t)z3 };
        memset(&v, 0, sizeof v);
        memset(&env, 0, sizeof env);
        nosc2_env_fill(&nosc2_far_init, &env, z);
        nosc2_note_on(&v, inc, (int16_t)lround((m - 36) / 60.0 * 4096), 3277);
        struct nosc2_voice *pv[1] = { &v };
        for (int b = 0; b < at[2] + 16; b++) {
            nosc2_env_step(&nosc2_far_init, &env, z, pv, 1);
            for (int j = 0; j < 4; j++) v.in[3 + j] = z[j];
            nosc2_render(&l1_mem, &env, &v, out);
            for (int w = 0; w < 3; w++)
                if (b >= at[w] && b < at[w] + 16) memcpy(&win[w][(b - at[w]) * BLK], out, sizeof out);
        }
        fwrite(win, sizeof win, 1, stdout);
    }
    return 0;
}
