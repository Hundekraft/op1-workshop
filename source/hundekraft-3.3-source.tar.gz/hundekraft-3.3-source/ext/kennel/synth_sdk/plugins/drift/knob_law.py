#!/usr/bin/env python3
"""DRIFT's knob law: knob -> z per knob, in steps of equal timbre change -> knob_law.json (read by gen_tables.py,
gen_screen_tables.py and presets.py). Host only; needs numpy and a C compiler.

    python3 knob_law.py WORKDIR            (renders about 99,000 notes, under a minute; WORKDIR keeps it)
    python3 knob_law.py WORKDIR --reuse    (the law again from WORKDIR/dist.npz, e.g. after changing BLEND)

Measurement: for each knob j, z_j runs over NZ points from -2.576 to 2.576 (Phi^-1(0.005) .. Phi^-1(0.995), the old
law's ends) while the other three are held at each of HOLD^3 combinations; each point is one note (knob_law_render.c:
the engine's C path, velocity 0.8, at C3 and C5). The timbre of a note is its log spectrum in 21 bands (1/3 octave
apart but at least 2 bins, 60 Hz .. 20 kHz; Hann, 2048 samples at 88.2 kHz) in three windows (12, 145 and 435 ms
after the start: attack, body, held), each band in dB (floored FLOOR = 60 dB below the window's loudest band)
relative to the window's mean (the spectral envelope: brightness, formants, noise filling the gaps between partials)
plus the window's mean level at half weight. The distance between neighbouring points is
the RMS dB difference of those vectors, averaged over the held combinations and both notes.
The law: k_arc(z) = arc length of that distance curve from the bottom end, over its total (so a knob step moves the
sound about the same amount everywhere), blended with the old law: k(z) = (1 - BLEND) k_arc(z) + BLEND k_old(z),
k_old = (Phi(z) - 0.005) / 0.99. Both ends stay where they were, and the map is strictly monotone. The JSON holds it
at 65 knob points per knob (Q12), interpolated as drift.c's lt_zof does (zof_q12 below is its copy).
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import itertools, json, os, subprocess, sys
from pathlib import Path
from statistics import NormalDist

import numpy as np

HERE = Path(__file__).resolve().parent
ZE = NormalDist().inv_cdf(0.995)                  # 2.5758: the ends, as before
NZ = int(os.environ.get('KL_NZ', 193))                                         # points along a knob
HOLD = (-1.6, -0.5, 0.5, 1.6)                     # the other knobs' z
NOTES = (48, 72)                                  # C3, C5
BLEND = 0.25                                      # share of the old law (see README: keeps the centre from going coarse)
FS = 88200.0
NW, WN = 3, 2048
FLOOR = float(os.environ.get('KL_FLOOR', 60))   # dB below the window's loudest band


def bands():
    f = np.fft.rfftfreq(WN, 1 / FS)
    edges = [60.0]                                # thirds of an octave, at least 2 bins wide, up to 20 kHz
    while edges[-1] < 20000:
        edges.append(max(edges[-1] * 2 ** (1 / 3), edges[-1] + 2 * FS / WN))
    return [(f >= lo) & (f < hi) for lo, hi in zip(edges[:-1], edges[1:])]


def features(raw, masks):
    x = raw.reshape(-1, NW, WN).astype(np.float64) / 32768
    s = np.abs(np.fft.rfft(x * np.hanning(WN), axis=2)) ** 2
    e = np.stack([s[:, :, m].mean(axis=2) for m in masks], axis=2)
    db = 10 * np.log10(e + 1e-10)                                  # floor -100 dB
    db = np.maximum(db, db.max(axis=2, keepdims=True) - FLOOR)     # bands far below the loudest: inaudible, held at
    lvl = db.mean(axis=2, keepdims=True)
    return np.concatenate([db - lvl, 0.5 * lvl], axis=2).reshape(len(x), -1)


def measure(work):
    exe = work / 'knob_law_render'
    subprocess.run(['cc', '-O2', '-Wno-unused-function', f'-I{HERE}', str(HERE / 'knob_law_render.c'), '-lm', '-o',
                    str(exe)], check=True)
    zs = np.linspace(-ZE, ZE, NZ)
    masks = bands()
    d = np.zeros((4, NZ - 1))
    for j in range(4):
        rows = []
        for hold in itertools.product(HOLD, repeat=3):
            for z in zs:
                v = list(hold); v.insert(j, z)
                rows.append(' '.join(str(int(round(4096 * x))) for x in v))
        txt = '\n'.join(rows) + '\n'
        acc = 0
        for m in NOTES:
            raw = np.frombuffer(subprocess.run([str(exe), str(m)], input=txt.encode(), capture_output=True,
                                               check=True).stdout, dtype='<i2')
            f = features(raw, masks).reshape(len(HOLD) ** 3, NZ, -1)
            acc = acc + np.sqrt(((f[:, 1:] - f[:, :-1]) ** 2).mean(axis=2)).mean(axis=0)
        d[j] = acc / len(NOTES)
        print(f'knob {j}: mean step {d[j].mean():.2f} dB, centre/tails {d[j][np.abs(zs[:-1] + zs[1:]) / 2 < 1.5].mean():.2f}'
              f' / {d[j][np.abs(zs[:-1] + zs[1:]) / 2 >= 1.5].mean():.2f}', flush=True)
    np.savez(work / 'dist.npz', zs=zs, d=d)
    return zs, d


def law(zs, d, blend=BLEND, n=65):
    """knob (n points, i / (n - 1)) -> z, per knob"""
    nd = NormalDist()
    k_old = np.array([(nd.cdf(z) - 0.005) / 0.99 for z in zs])
    out = []
    for j in range(4):
        dj = np.convolve(np.pad(d[j], 1, mode='edge'), [0.25, 0.5, 0.25], mode='valid')   # light smoothing
        s = np.concatenate([[0], np.cumsum(dj)]); k = (1 - blend) * s / s[-1] + blend * k_old
        k[0], k[-1] = 0.0, 1.0
        out.append(np.interp(np.arange(n) / (n - 1), k, zs))
    return np.array(out)


def zof_q12(t, k):
    """drift.c lt_zof on one knob's 65-point table t (Q12): knob word k (0..32767) -> z, Q12"""
    k = min(32767, max(0, k))
    if k == 32767:
        return t[64]
    i, f = k >> 9, k & 511
    return t[i] + (((t[i + 1] - t[i]) * f) >> 9)


def word_of(t, z):
    """the knob word whose z (through zof_q12) is nearest to z (Q12); the lower word on a tie"""
    lo, hi = 0, 32767                                    # zof_q12 is monotone: bisect, then look around
    while lo < hi:
        m = (lo + hi) // 2
        if zof_q12(t, m) < z: lo = m + 1
        else: hi = m
    return min(range(max(0, lo - 2), min(32767, lo + 2) + 1), key=lambda w: (abs(zof_q12(t, w) - z), w))


def regions(zfun):
    """the share of a knob's travel (4096 even steps) in |z| < 0.75, 0.75 .. 1.5 and > 1.5"""
    z = np.abs(np.array([zfun(k) for k in range(0, 32768, 8)]) / 4096)
    return [float(np.mean(z < 0.75)), float(np.mean((z >= 0.75) & (z <= 1.5))), float(np.mean(z > 1.5))]


def main():
    work = Path(sys.argv[1]); work.mkdir(parents=True, exist_ok=True)
    if '--reuse' in sys.argv:
        r = np.load(work / 'dist.npz'); zs, d = r['zs'], r['d']
    else:
        zs, d = measure(work)
    q = [[int(round(4096 * x)) for x in z] for z in law(zs, d)]
    nd = NormalDist()
    r_old = regions(lambda k: 4096 * nd.inv_cdf(0.005 + 0.99 * k / 32768))
    r_new = [regions(lambda k, t=t: zof_q12(t, k)) for t in q]
    s = [np.concatenate([[0], np.cumsum(x)]) for x in d]          # timbre change per 1 % of the knob, dB
    for j in range(4):
        per = lambda zf: np.diff(np.interp(np.array([zf(k) for k in np.linspace(0, 32767, 101).astype(int)]) / 4096, zs, s[j]))
        po = per(lambda k: 4096 * nd.inv_cdf(0.005 + 0.99 * k / 32768)); pn = per(lambda k: zof_q12(q[j], k))
        print(f'knob {j}: centre / mid / tails {" / ".join(f"{100 * x:.1f}" for x in r_old)} % -> '
              f'{" / ".join(f"{100 * x:.1f}" for x in r_new[j])} %; dB per 1 % {po.min():.2f} .. {po.max():.2f} -> '
              f'{pn.min():.2f} .. {pn.max():.2f}')
    (HERE / 'knob_law.json').write_text(json.dumps({
        'about': 'knob_law.py: knob k = i / 64 -> z (Q12), one row per knob (drift.c lt_zof interpolates 9 bits); '
                 'equal timbre steps blended with the old law',
        'blend': BLEND, 'regions': 'share of the travel in |z| < 0.75, 0.75 .. 1.5, > 1.5',
        'regions_old': [round(x, 4) for x in r_old], 'regions_new': [[round(x, 4) for x in r] for r in r_new],
        'zq12': q}) + '\n')


if __name__ == '__main__':
    main()
