/* drift_view.h: what DRIFT's engine publishes for its Terrain screen (drift_screen.c), and the two functions the
 * engine provides for it. This header is the whole interface between the two: the screen reads nothing else of the
 * engine. README.md in this folder says the same in prose.
 *
 * Threads. The audio thread writes drift_view at a note's start, at note_off and once a block (the knobs); the
 * GUI thread fills the per-block fields itself by calling drift_view_sync() (the engine's, read only on its voices)
 * before it reads, so the audio path pays nothing per voice and block (publishing there cost up to 0.8 points of
 * the slot in the cold-cache model, 2026-11-14). No locks: a torn read (one field old, one new) shows as one odd
 * frame at worst, which is fine on screen.
 *
 * What the engine does (drift_view.c; all integers, no division):
 *   note start (audio thread): drift_view.serial += 1; then for voice v: serial = drift_view.serial, vel_q12,
 *                       age = 0, released = 0, active = 1.
 *   note_off(voice v):  released = 1.
 *   once a block:       knobs[] = the four knob values the block used.
 *   drift_view_sync() (GUI thread): for each voice played: tick = age = the voice's own block count since note on
 *                       (nosc2_voice.age: it moves while R246 renders the voice and stops when it ends), pitch_q12,
 *                       vel_q12, note (from the pitch), prm[] = the voice's DSP settings (nosc2_voice.prm, as they
 *                       are after its last block). level stays 0. active is not cleared: R246 stops calling render
 *                       when its envelope ends, so the screen treats a voice whose tick stops advancing as gone.
 *
 * Knobs. The screen draws from op1_synth_knobs_live(OP1_SCREEN_SLOT & 7), the values the stock screens show (LFO
 * included), so the ticks also move in silence. drift_view.knobs is what the engine rendered with; the screen does
 * not read it (it is there to check that the land and the sound agree).
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef DRIFT_VIEW_H
#define DRIFT_VIEW_H
#include <stdint.h>

#define DRIFT_VIEW_VOICES 6
/* prm[] index = the engine's own parameter order (nosc2_core.h enum), each Q12 0..4096 as the engine keeps it.
 * The square-law coded levels (FMA, FMB, UNI, NOI, DRV, SYN, SUB) are published squared, as prm holds them; the
 * screen takes their square root. */
enum { DV_CUT, DV_RES, DV_FMA, DV_FMB, DV_UNI, DV_DET, DV_NOI, DV_NCO, DV_DRV, DV_SYN, DV_SUB, DV_BLP, DV_CFB, DV_CDA,
       DV_LVL, DRIFT_VIEW_NPRM };

typedef struct {
    uint32_t serial;            /* drift_view.serial at this voice's last note on; 0 = never played */
    uint32_t tick;              /* the voice's block count (drift_view_sync): moves while it renders (liveness) */
    uint32_t age;               /* blocks since note on (the net's time input counts these) */
    int16_t pitch_q12;          /* the net's in[0]: (MIDI - 36) / 60 x 4096 */
    int16_t vel_q12;            /* the net's in[1]: velocity 0..4096 */
    int16_t level;              /* optional: the voice's output level 0..32767 (0: not kept); not drawn yet */
    int16_t prm[DRIFT_VIEW_NPRM];   /* this block's DSP settings, Q12 (see the enum) */
    uint8_t note;               /* MIDI note 0..127 */
    uint8_t active;             /* 1 from note on until the engine knows the voice ended */
    uint8_t released;           /* 1 after note off */
    uint8_t pad;
} drift_view_voice_t;

typedef struct {
    uint32_t serial;            /* counts note ons (all voices): the newest note has the highest serial */
    int16_t knobs[4];           /* the knob values the last block rendered with, Q15 0..32767 (LFO included) */
    drift_view_voice_t v[DRIFT_VIEW_VOICES];
} drift_view_t;

/* Defined by the engine (one instance, in plugin memory). */
extern volatile drift_view_t drift_view;

/* Defined by the engine, called by the screen on the GUI thread once a frame before it reads drift_view: copies the
 * per-block fields from the engine's voices (above). */
void drift_view_sync(void);

/* Defined by the engine, called by the screen on the GUI thread: the wave table the net gives for one note.
 *   pitch_q12, vel_q12   as the voice's in[0], in[1]
 *   age                  blocks since note on (the engine maps it to the net's time input as for a voice, capped)
 *   knobs                four knob values, Q15 0..32767 (the engine converts them to z as its render does)
 *   out, n               n samples of one period, out[i] at phase i / n (n is 64 here: every second sample of the
 *                        engine's 128-sample table), Q15 scale (the engine's int16 table values as they are)
 * Returns 1 when out was written, 0 when it could not decode (the screen then keeps its previous table).
 * Rules: GUI thread, so it must not touch the L1 lease or any voice or audio-thread scratch; its own stack or
 * static scratch only (const weights are fine wherever they live). The screen calls it at most 9 times a frame
 * (8 far ridges + the near one), usually 0-4. */
int drift_view_table(int16_t pitch_q12, int16_t vel_q12, uint32_t age, const int16_t knobs[4], int16_t *out, int n);

#endif
