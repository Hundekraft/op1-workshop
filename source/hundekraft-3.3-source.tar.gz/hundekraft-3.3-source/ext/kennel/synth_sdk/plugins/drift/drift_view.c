/* drift_view.c: DRIFT's engine side of its screen's interface (drift_view.h). drift.c calls in here at a note's start,
 * at each block's start (the knobs) and after each voice's block; note_off is here too (the view's only use of it:
 * R246's ADSR is the sound's). All the view's data and code live in this file, listed after drift.c and drift_asm.S in
 * plugin.json, so that drift.c's data keeps the layout the CPU pass measured (the engine's cost moves by points with
 * its data's cache placement).
 *   - the audio thread writes only at a note's start (serial, velocity, active, released), at note_off (released) and
 *     once a block (the knobs): a few stores, their cache lines read first so the stores hit. A per-voice, per-block
 *     publish cost up to 0.8 points of the slot in the cold model (2026-11-14), so the GUI thread copies the rest:
 *   - drift_view_sync (GUI thread, once a frame, read only on the voices): tick, age, pitch, velocity, settings and
 *     note from each played voice. tick is the voice's block count (nosc2_voice.age): it moves while R246 renders the
 *     voice and stops when it ends, which is all the screen asks of it;
 *   - drift_view_table: the net's table for one note, run on the GUI thread from the const weights (nosc2_l1_init, in
 *     SDRAM; never the L1 lease, a voice or the audio thread's scratch) into this file's own static scratch (the screen
 *     is its only caller), with the voices' kernels (n2k_layer_s, nosc_blend_asm: no static state).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "op1_plugin.h"
#if defined(__bfin__)
void nosc_blend_asm(const int16_t *, const int16_t *, int16_t *);
#define NOSC_BLEND nosc_blend_asm
#define N2K_ASM
#endif
#define NEH 32                                                 /* as nosc2_weights.h */
#include "nosc2_core.h"
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-const-variable"
#include "drift_tables.h"
#pragma GCC diagnostic pop
#include "drift_view.h"

extern const struct nosc2_l1 nosc2_l1_init;                    /* nosc2_weights.h, in drift.c */
const struct nosc2_voice *lt_voice(int i);                     /* drift.c: voice i, read only */
typedef char dv_voices[DRIFT_VIEW_VOICES == OP1_VOICES ? 1 : -1];
typedef char dv_prm[DRIFT_VIEW_NPRM == NP ? 1 : -1];

volatile drift_view_t drift_view;

static inline void dv_touch(const volatile void *p, uint32_t n)   /* read one word of each line (as n2_touch16) */
{
    uintptr_t a = (uintptr_t)p & ~(uintptr_t)31, e = (uintptr_t)p + n;
    for (; a < e; a += 32) (void)*(const volatile int32_t *)a;
}
void lt_view_start(int vi)                                     /* audio thread, at the note's start */
{
    volatile drift_view_voice_t *d = &drift_view.v[vi];
    dv_touch(d, sizeof *d);
    const uint32_t s = drift_view.serial + 1;
    drift_view.serial = s;
    d->serial = s; d->age = 0; d->released = 0; d->active = 1;
    d->vel_q12 = lt_voice(vi)->in[1];
}
void lt_view_knobs(const int16_t *params)                      /* audio thread, once a block */
{
    dv_touch(drift_view.knobs, sizeof drift_view.knobs);
    for (int j = 0; j < 4; j++) drift_view.knobs[j] = params[j];
}
void drift_view_sync(void)                                     /* GUI thread, once a frame */
{
    for (int i = 0; i < OP1_VOICES; i++) {
        volatile drift_view_voice_t *d = &drift_view.v[i];
        if (!d->serial) continue;                              /* never played */
        const volatile struct nosc2_voice *v = lt_voice(i);
        const uint32_t a = v->age;
        d->tick = a; d->age = a;
        d->pitch_q12 = v->in[0];
        d->vel_q12 = v->in[1];
        for (int j = 0; j < NP; j++) d->prm[j] = v->prm[j];
        const int32_t m = 36 + ((d->pitch_q12 * 60 + 2048) >> 12);   /* (MIDI - 36) / 60 x 4096 -> MIDI, rounded */
        d->note = (uint8_t)(m < 0 ? 0 : m > 127 ? 127 : m);
    }
}
void lt_note_off(void *self)
{
    const int vi = op1_voice_index(self);
    if (vi >= 0 && vi < OP1_VOICES) drift_view.v[vi].released = 1;   /* a note on and off inside one block shows as
                                                                      * held until the voice ends: on screen only */
}

static int16_t dv_zof(int j, int32_t k)                        /* knob j's word -> z, Q12: drift.c's lt_zof */
{
    const int16_t *t = lt_zk[j];
    if (k <= 0) return t[0];
    if (k >= 32767) return t[64];
    int32_t i = k >> 9, f = k & 511;
    return (int16_t)(t[i] + (((t[i + 1] - t[i]) * f) >> 9));
}
/* age: the voice's v->age when it rendered that table (the view's age is one more after the block) */
int drift_view_table(int16_t pitch_q12, int16_t vel_q12, uint32_t age, const int16_t knobs[4], int16_t *out, int n)
{
    static int16_t in[NI] __attribute__((aligned(4))), h1[NH] __attribute__((aligned(4))), h2[NH] __attribute__((aligned(4)));
    static int16_t c[NB] __attribute__((aligned(4))), tab[TL] __attribute__((aligned(4)));
    int step = 0;                                              /* TL / n for n a power of two (no division) */
    for (int k = 1; k <= TL; k <<= 1) if (k * n == TL) step = k;
    if (!step) return 0;
    const struct nosc2_l1 *W = &nosc2_l1_init;
    const uint32_t ti = age < 64 ? age : 64 + ((age - 64) >> 3);
    in[0] = pitch_q12; in[1] = vel_q12; in[2] = nosc2_tau[ti < NTAU2 ? ti : NTAU2 - 1];
    for (int j = 0; j < 4; j++) in[3 + j] = dv_zof(j, knobs[j]);
    in[7] = 0;
    { struct n2k_layer a = { W->w1, W->b1, in, h1, NH, NI, 1 }; N2K_layer(&a); }
    { struct n2k_layer a = { W->w2, W->b2, h1, h2, NH, NH, 1 }; N2K_layer(&a); }
    { struct n2k_layer a = { W->w3, W->b3, h2, c, NB, NH, 0 }; N2K_layer(&a); }
    NOSC_BLEND(c, &W->basis[0][0], tab);
    for (int i = 0; i < n; i++) out[i] = tab[i * step];
    return 1;
}
