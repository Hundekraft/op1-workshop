/* drift_view_stub.h: the script calls of drift_view_stub.c (host tests only).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef DRIFT_VIEW_STUB_H
#define DRIFT_VIEW_STUB_H
#include <stdint.h>
void dvs_knobs(const int16_t k[4]);                  /* the knob values the next blocks render with */
void dvs_note_on(int voice, int note, int vel127);
void dvs_note_off(int voice);
void dvs_end(int voice);                             /* the voice's envelope ended: no more render calls */
void dvs_blocks(int n);                              /* render n blocks of every sounding voice */
#endif
