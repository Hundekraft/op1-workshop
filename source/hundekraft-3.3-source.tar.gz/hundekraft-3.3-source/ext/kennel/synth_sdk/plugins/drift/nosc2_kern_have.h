/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* kernels that nosc2_kern.S provides */
#define N2K_HAVE_lvl
#define N2K_HAVE_dc
#define N2K_HAVE_osc
#define N2K_HAVE_svf
#define N2K_HAVE_comb
#define N2K_HAVE_sn
#define N2K_HAVE_drv
#define N2K_HAVE_fm
#define N2K_HAVE_dcl
#define N2K_HAVE_layer
