/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* nosc2 kernels for Blackfin, bit-exact with the C specs in nosc2_kern.h. R0 = the argument struct. */
.text

/* n2k_lvl_s: out[i] = sat16((buf[i] * ((r += d) >> 7)) >> 11). buf 0, out 4, r 8, d 12 */
.global _n2k_lvl_s
.align 4
_n2k_lvl_s:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P0 = [P5 + 0];
    P1 = [P5 + 4];
    R1 = [P5 + 8];
    R2 = [P5 + 12];
    P2 = 128;
    LSETUP(lv_s, lv_e) LC0 = P2;
lv_s: R1 = R1 + R2;
    R3 = R1 >>> 7;
    R0 = W[P0++] (X);
    A0 = R0.L * R3.L (IS);
    A0 = A0 >>> 11;
    R0.L = A0 (IS);
lv_e: W[P1++] = R0;
    [P5 + 8] = R1;
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_dc_s: y = buf[i]; z += y - (z >> 9); buf[i] = sat16(y - (z >> 9)). buf 0, z 4 */
.global _n2k_dc_s
.align 4
_n2k_dc_s:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P0 = [P5 + 0];
    R1 = [P5 + 4];
    P2 = 128;
    LSETUP(dc_s, dc_e) LC0 = P2;
dc_s: R0 = W[P0] (X);
    R2 = R1 >>> 9;
    R1 = R1 + R0;
    R1 = R1 - R2;
    R3 = R1 >>> 9;
    R0 = R0 - R3;
    A0 = R0;
    R0.L = A0 (IS);
dc_e: W[P0++] = R0;
    [P5 + 4] = R1;
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_osc_s: see n2k_osc_c. tn 0, to 4, fm 8, buf 12, ph 16, inc 20, dinc 24, r 28, d 32, flags 36.
 * Registers in the loop: R1 ph, R6 inc, R3 (xw : 32767 - xw), P0 to, P1 tn, P2 buf, P3 fm, P5 the struct;
 * dinc in I0, the xw step (256 : -256) in I1, r in I2, d in I3. One loop serves every flag: the flag tests are
 * in the loop but cheap next to the reads. */
.align 4
_n2k_osc_g:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P1 = [P5 + 0];
    P0 = [P5 + 4];
    P3 = [P5 + 8];
    P2 = [P5 + 12];
    R1 = [P5 + 16];
    R6 = [P5 + 20];
    R0 = [P5 + 24]; I0 = R0;
    R0 = [P5 + 28]; I2 = R0;
    R0 = [P5 + 32]; I3 = R0;
    R0.L = -256; R0.H = 256; I1 = R0;          /* step for (xw : 32767 - xw): H += 256, L -= 256 */
    R3.L = 32512; R3.H = 255;                  /* i = 0: xw = 255 */
    R7 = [P5 + 36];
    [--SP] = R7;                               /* flags at [SP] */
    P4 = 128;
    LSETUP(os_s, os_e) LC0 = P4;
os_s: R0 = I0;
    R6 = R6 + R0;                              /* inc += dinc */
    R2 = R1;                                   /* rd = ph */
    R7 = [SP];
    CC = BITTST(R7, 1);
    IF !CC JUMP os_nosync;
    R0 = I2; R4 = I3; R0 = R0 + R4; I2 = R0;   /* r += d: the ratio, Q12 */
    R2 = R1 >> 16;
    R2 *= R0;
    R2 <<= 4;                                  /* rd = ((ph >> 16) x (4096 + 3 (r >> 7))) << 4 */
os_nosync:
    CC = BITTST(R7, 2);
    IF !CC JUMP os_nofm;
    R0 = W[P3] (X);
    R0 <<= 17;
    R2 = R2 + R0;
os_nofm:
    P3 += 2;
    R0 = R2 >> 25;                             /* k */
    R4 = R2 << 7;
    R4 = R4 >> 17;                             /* f */
    R5.L = 0x7fff;
    R5.L = R5.L - R4.L (NS);                   /* g = 32767 - f */
    R5 = PACK(R4.L, R5.L);                     /* f : g */
    P4 = R0;
    P4 = P4 << 1;
    [--SP] = P5;
    P5 = P4;
    P4 = P0 + P5;
    P5 = P1 + P5;
    R4 = W[P4] (X);                            /* to[k] */
    R0 = W[P5] (X);                            /* tn[k] */
    R4 = PACK(R0.L, R4.L);
    R2 = W[P4 + 2] (X);                        /* to[k+1] */
    R0 = W[P5 + 2] (X);                        /* tn[k+1] */
    R0 = PACK(R0.L, R2.L);
    P5 = [SP++];
    A0 = R4.L * R5.L, A1 = R4.H * R5.L (IS);
    A0 += R0.L * R5.H, A1 += R0.H * R5.H (IS);
    A0 = A0 >>> 15;
    A1 = A1 >>> 15;
    R4.H = A1, R4.L = A0 (IS);                 /* sn : so */
    A0 = R4.L * R3.L, A1 = R4.H * R3.H (IS);
    A0 += A1;
    R0 = I1;
    R3 = R3 +|+ R0;                            /* next xw */
    CC = BITTST(R7, 3);
    IF CC JUMP os_w;
    A0 = A0 >>> 17;                            /* s >> 2 */
    JUMP os_y;
os_w: A0 = A0 >>> 15;                          /* s */
    R0.L = A0 (IS);
    R4 = I2; R5 = I3; R4 = R4 + R5; I2 = R4;   /* r += d */
    R4 >>>= 7;
    A0 = R0.L * R4.L (IS);
    A0 = A0 >>> 14;
os_y:
    CC = BITTST(R7, 0);
    IF !CC JUMP os_wr;
    R0 = W[P2] (X);
    A1 = R0;
    A0 += A1;
os_wr:
    R0.L = A0 (IS);
    W[P2++] = R0;
os_e: R1 = R1 + R6;                            /* ph += inc */
    SP += 4;
    [P5 + 16] = R1;
    [P5 + 20] = R6;
    R0 = I2; [P5 + 28] = R0;
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_osc_s: dispatch. flags 0 (main: write, no sync, no FM, no weight) and 9 (unison: accumulate, weight) have
 * branch-free loops; everything else goes to the generic loop. */
.global _n2k_osc_s
.align 4
_n2k_osc_s:
    P0 = R0;
    R1 = [P0 + 36];
    CC = R1 == 0;
    IF CC JUMP _n2k_osc_f0;
    R2 = 4;
    CC = R1 == R2;
    IF CC JUMP _n2k_osc_f4;
    R2 = 2;
    CC = R1 == R2;
    IF CC JUMP _n2k_osc_f2;
    R2 = 6;
    CC = R1 == R2;
    IF CC JUMP _n2k_osc_f6;
    R2 = 9;
    CC = R1 == R2;
    IF CC JUMP _n2k_osc_f9;
    JUMP _n2k_osc_g;

/* flags 0. R1 ph, R6 inc, R7 dinc, R2 32767, R3 (xw : 32767 - xw), I1 xw step, P0 to, P1 tn, P2 buf, P5 struct */
.align 4
_n2k_osc_f0:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P1 = [P5 + 0];
    P0 = [P5 + 4];
    P2 = [P5 + 12];
    R1 = [P5 + 16];
    R6 = [P5 + 20];
    R7 = [P5 + 24];
    R0.L = -256; R0.H = 256; I1 = R0;
    R3.L = 32512; R3.H = 255;
    R2 = 32767;
    P4 = 128;
    LSETUP(f0_s, f0_e) LC0 = P4;
f0_s: R6 = R6 + R7;
    R0 = R1 >> 25;
    R4 = R1 << 7;
    R4 = R4 >> 17;                             /* f */
    R5 = R2 - R4;
    R5 = PACK(R4.L, R5.L);                     /* f : g */
    P4 = R0;
    P4 = P4 << 1;
    P3 = P1 + P4;
    P4 = P0 + P4;
    R4 = W[P4] (X);
    A0 = R4.L * R5.L (IS) || R4 = W[P4 + 2] (X);
    A0 += R4.L * R5.H (IS) || R4 = W[P3] (X);
    A1 = R4.L * R5.L (IS) || R4 = W[P3 + 2] (X);
    A1 += R4.L * R5.H (IS);
    A0 = A0 >>> 15;
    A1 = A1 >>> 15;
    R4.H = A1, R4.L = A0 (IS);                 /* sn : so */
    A0 = R4.L * R3.L, A1 = R4.H * R3.H (IS);
    A0 += A1;
    A0 = A0 >>> 17;
    R0.L = A0 (IS);
    W[P2++] = R0;
    R0 = I1;
    R3 = R3 +|+ R0;
f0_e: R1 = R1 + R6;
    [P5 + 16] = R1;
    [P5 + 20] = R6;
    (R7:4, P5:3) = [SP++];
    RTS;

/* flags 4 (FM offsets in P3). R1 ph, R6 inc, R7 dinc, R2 32767, R3 (xw : 32767 - xw), I1 xw step, P0 to, P1 tn, P2 buf, P5 struct */
.align 4
_n2k_osc_f4:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P1 = [P5 + 0];
    P0 = [P5 + 4];
    P2 = [P5 + 12];
    R0 = [P5 + 8]; I2 = R0;
    R1 = [P5 + 16];
    R6 = [P5 + 20];
    R7 = [P5 + 24];
    R0.L = -256; R0.H = 256; I1 = R0;
    R3.L = 32512; R3.H = 255;
    R2 = 32767;
    P4 = 128;
    LSETUP(f4_s, f4_e) LC0 = P4;
f4_s: R6 = R6 + R7;
    P4 = I2;
    R0 = W[P4++] (X);
    I2 = P4;
    R0 <<= 17;
    R5 = R1 + R0;                              /* rd = ph + fm << 17 */
    R0 = R5 >> 25;
    R4 = R5 << 7;
    R4 = R4 >> 17;                             /* f */
    R5 = R2 - R4;
    R5 = PACK(R4.L, R5.L);                     /* f : g */
    P4 = R0;
    P4 = P4 << 1;
    P3 = P1 + P4;
    P4 = P0 + P4;
    R4 = W[P4] (X);
    A0 = R4.L * R5.L (IS) || R4 = W[P4 + 2] (X);
    A0 += R4.L * R5.H (IS) || R4 = W[P3] (X);
    A1 = R4.L * R5.L (IS) || R4 = W[P3 + 2] (X);
    A1 += R4.L * R5.H (IS);
    A0 = A0 >>> 15;
    A1 = A1 >>> 15;
    R4.H = A1, R4.L = A0 (IS);                 /* sn : so */
    A0 = R4.L * R3.L, A1 = R4.H * R3.H (IS);
    A0 += A1;
    A0 = A0 >>> 17;
    R0.L = A0 (IS);
    W[P2++] = R0;
    R0 = I1;
    R3 = R3 +|+ R0;
f4_e: R1 = R1 + R6;
    [P5 + 16] = R1;
    [P5 + 20] = R6;
    (R7:4, P5:3) = [SP++];
    RTS;

/* flags 2 (sync). R1 ph, R6 inc, R7 dinc, R2 32767, R3 (xw : 32767 - xw), I1 xw step, P0 to, P1 tn, P2 buf, P5 struct */
.align 4
_n2k_osc_f2:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P1 = [P5 + 0];
    P0 = [P5 + 4];
    P2 = [P5 + 12];
    R1 = [P5 + 16];
    R6 = [P5 + 20];
    R7 = [P5 + 24];
    R0 = [P5 + 28]; I2 = R0;
    R0 = [P5 + 32]; I3 = R0;
    R0.L = -256; R0.H = 256; I1 = R0;
    R3.L = 32512; R3.H = 255;
    R2 = 32767;
    P4 = 128;
    LSETUP(f2_s, f2_e) LC0 = P4;
f2_s: R6 = R6 + R7;
    R0 = I2; R4 = I3; R0 = R0 + R4; I2 = R0;   /* ratio += step */
    R5 = R1 >> 16;
    R5 *= R0;
    R5 <<= 4;                                  /* rd */
    R0 = R5 >> 25;
    R4 = R5 << 7;
    R4 = R4 >> 17;                             /* f */
    R5 = R2 - R4;
    R5 = PACK(R4.L, R5.L);                     /* f : g */
    P4 = R0;
    P4 = P4 << 1;
    P3 = P1 + P4;
    P4 = P0 + P4;
    R4 = W[P4] (X);
    A0 = R4.L * R5.L (IS) || R4 = W[P4 + 2] (X);
    A0 += R4.L * R5.H (IS) || R4 = W[P3] (X);
    A1 = R4.L * R5.L (IS) || R4 = W[P3 + 2] (X);
    A1 += R4.L * R5.H (IS);
    A0 = A0 >>> 15;
    A1 = A1 >>> 15;
    R4.H = A1, R4.L = A0 (IS);                 /* sn : so */
    A0 = R4.L * R3.L, A1 = R4.H * R3.H (IS);
    A0 += A1;
    A0 = A0 >>> 17;
    R0.L = A0 (IS);
    W[P2++] = R0;
    R0 = I1;
    R3 = R3 +|+ R0;
f2_e: R1 = R1 + R6;
    [P5 + 16] = R1;
    [P5 + 20] = R6;
    R0 = I2; [P5 + 28] = R0;
    (R7:4, P5:3) = [SP++];
    RTS;

/* flags 6 (sync + FM). R1 ph, R6 inc, R7 dinc, R2 32767, R3 (xw : 32767 - xw), I1 xw step, P0 to, P1 tn, P2 buf, P5 struct */
.align 4
_n2k_osc_f6:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P1 = [P5 + 0];
    P0 = [P5 + 4];
    P2 = [P5 + 12];
    R1 = [P5 + 16];
    R6 = [P5 + 20];
    R7 = [P5 + 24];
    R0 = [P5 + 28]; I2 = R0;
    R0 = [P5 + 32]; I3 = R0;
    R0 = [P5 + 8]; I0 = R0;
    R0.L = -256; R0.H = 256; I1 = R0;
    R3.L = 32512; R3.H = 255;
    R2 = 32767;
    P4 = 128;
    LSETUP(f6_s, f6_e) LC0 = P4;
f6_s: R6 = R6 + R7;
    R0 = I2; R4 = I3; R0 = R0 + R4; I2 = R0;   /* ratio += step */
    R5 = R1 >> 16;
    R5 *= R0;
    R5 <<= 4;                                  /* rd */
    P4 = I0;
    R0 = W[P4++] (X);
    I0 = P4;
    R0 <<= 17;
    R5 = R5 + R0;
    R0 = R5 >> 25;
    R4 = R5 << 7;
    R4 = R4 >> 17;                             /* f */
    R5 = R2 - R4;
    R5 = PACK(R4.L, R5.L);                     /* f : g */
    P4 = R0;
    P4 = P4 << 1;
    P3 = P1 + P4;
    P4 = P0 + P4;
    R4 = W[P4] (X);
    A0 = R4.L * R5.L (IS) || R4 = W[P4 + 2] (X);
    A0 += R4.L * R5.H (IS) || R4 = W[P3] (X);
    A1 = R4.L * R5.L (IS) || R4 = W[P3 + 2] (X);
    A1 += R4.L * R5.H (IS);
    A0 = A0 >>> 15;
    A1 = A1 >>> 15;
    R4.H = A1, R4.L = A0 (IS);                 /* sn : so */
    A0 = R4.L * R3.L, A1 = R4.H * R3.H (IS);
    A0 += A1;
    A0 = A0 >>> 17;
    R0.L = A0 (IS);
    W[P2++] = R0;
    R0 = I1;
    R3 = R3 +|+ R0;
f6_e: R1 = R1 + R6;
    [P5 + 16] = R1;
    [P5 + 20] = R6;
    R0 = I2; [P5 + 28] = R0;
    (R7:4, P5:3) = [SP++];
    RTS;

/* flags 9: as 0, plus r += d; y = (s x (r >> 7)) >> 14; buf = sat16(buf + y). r in I2, d in I3 */
.align 4
_n2k_osc_f9:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P1 = [P5 + 0];
    P0 = [P5 + 4];
    P2 = [P5 + 12];
    R1 = [P5 + 16];
    R6 = [P5 + 20];
    R7 = [P5 + 24];
    R0 = [P5 + 28]; I2 = R0;
    R0 = [P5 + 32]; I3 = R0;
    R0.L = -256; R0.H = 256; I1 = R0;
    R3.L = 32512; R3.H = 255;
    R2 = 32767;
    P4 = 128;
    LSETUP(f9_s, f9_e) LC0 = P4;
f9_s: R6 = R6 + R7;
    R0 = R1 >> 25;
    R4 = R1 << 7;
    R4 = R4 >> 17;
    R5 = R2 - R4;
    R5 = PACK(R4.L, R5.L);
    P4 = R0;
    P4 = P4 << 1;
    P3 = P1 + P4;
    P4 = P0 + P4;
    R4 = W[P4] (X);
    A0 = R4.L * R5.L (IS) || R4 = W[P4 + 2] (X);
    A0 += R4.L * R5.H (IS) || R4 = W[P3] (X);
    A1 = R4.L * R5.L (IS) || R4 = W[P3 + 2] (X);
    A1 += R4.L * R5.H (IS);
    A0 = A0 >>> 15;
    A1 = A1 >>> 15;
    R4.H = A1, R4.L = A0 (IS);
    A0 = R4.L * R3.L, A1 = R4.H * R3.H (IS);
    A0 += A1;
    A0 = A0 >>> 15;
    R0.L = A0 (IS);                            /* s */
    R4 = I2; R5 = I3; R4 = R4 + R5; I2 = R4;   /* r += d */
    R4 >>>= 7;
    A0 = R0.L * R4.L (IS);
    A0 = A0 >>> 14;                            /* y */
    R0 = W[P2] (X);
    A1 = R0;
    A0 += A1;
    R0.L = A0 (IS);
    W[P2++] = R0;
    R0 = I1;
    R3 = R3 +|+ R0;
f9_e: R1 = R1 + R6;
    [P5 + 16] = R1;
    [P5 + 20] = R6;
    R0 = I2; [P5 + 28] = R0;
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_svf_s: see n2k_svf_c. buf 0, s1 4, s2 8, c1 12, c2 16, c3 20, d1 24, d2 28, d3 32.
 * c1..c3 in I0..I2, d1..d3 in M0..M2 (I += M is a 32-bit add with L = 0); R1 s1, R2 s2, R3 (1 : 16384) */
.global _n2k_svf_s
.align 4
_n2k_svf_s:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P0 = [P5 + 0];
    R1 = [P5 + 4];
    R2 = [P5 + 8];
    L0 = 0; L1 = 0; L2 = 0;
    R0 = [P5 + 12]; I0 = R0;
    R0 = [P5 + 16]; I1 = R0;
    R0 = [P5 + 20]; I2 = R0;
    R0 = [P5 + 24]; M0 = R0;
    R0 = [P5 + 28]; M1 = R0;
    R0 = [P5 + 32]; M2 = R0;
    R3.L = 16384; R3.H = 1;
    P2 = 128;
    LSETUP(sv_s, sv_e) LC0 = P2;
sv_s: I0 += M0;
    I1 += M1;
    I2 += M2;
    R4 = I0;
    R5 = I1;
    R6 = PACK(R5.H, R4.H);                     /* a2 : a1, the accumulators' high halves */
    R5 = I2;                                   /* a3 in R5.H */
    R0 = W[P0] (X);
    R0.L = R0.L - R2.L (S);                    /* v3 = sat16(buf - s2) */
    R4 = PACK(R0.L, R1.L);                     /* v3 : s1 */
    A0 = R6.L * R4.L, A1 = R6.H * R4.L (IS);   /* a1 s1, a2 s1 */
    A1 += R3.L * R3.H, A0 += R3.L * R3.H (IS); /* + 16384 */
    A0 += R6.H * R4.H (IS);                    /* + a2 v3 */
    A1 += R5.H * R4.H (IS);                    /* + a3 v3 */
    A0 = A0 >>> 15;
    A1 = A1 >>> 15;
    R0 = A0;                                   /* v1 */
    R7 = A1;
    R4 = R7 + R2;                              /* v2 */
    R0 = R0 + R0;
    R0 = R0 - R1;
    R1 = R0 << 16 (S);
    R1 >>>= 16;
    R0 = R4 + R4;
    R0 = R0 - R2;
    R2 = R0 << 16 (S);
    R2 >>>= 16;
    R4 = R4 << 16 (S);
    R4 >>>= 16;
sv_e: W[P0++] = R4;
    [P5 + 4] = R1;
    [P5 + 8] = R2;
    R0 = I0; [P5 + 12] = R0;
    R0 = I1; [P5 + 16] = R0;
    R0 = I2; [P5 + 20] = R0;
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_comb_s: see n2k_comb_c (four taps). buf 0, line 4, w 8, L8 12, k0 16, k1 20, k2 24, k3 28, cin 32.
 * c0 = line[w - Lc - 1] is a fixed distance behind the write position: I0 = I1 - M0, both circular. */
.global _n2k_comb_s
.align 4
_n2k_comb_s:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P0 = [P5 + 0];
    R0 = [P5 + 4];
    B0 = R0; B1 = R0;
    R1 = 4096; L0 = R1; L1 = R1;
    R1 = [P5 + 8];
    R2 = R1 << 1;
    R0 = R0 + R2; I1 = R0;
    R2 = [P5 + 12];
    R3 = 255;
    R4 = R2 + R3;
    R4 >>= 8;                                  /* Lc */
    R4 += 1;
    R4 <<= 1;
    M0 = R4;
    R0 = [P5 + 16]; R4 = [P5 + 20]; R5 = PACK(R4.L, R0.L);   /* k1 : k0 */
    R0 = [P5 + 24]; R4 = [P5 + 28]; R6 = PACK(R4.L, R0.L);   /* k3 : k2 */
    R7 = [P5 + 32];                                          /* cin */
    P2 = 128;
    LSETUP(cb_s, cb_e) LC0 = P2;
cb_s: I0 = I1;
    I0 -= M0;
    R0.L = W[I0++];
    R0.H = W[I0++];
    R1.L = W[I0++];
    R1.H = W[I0++];
    A0 = R0.L * R5.L, A1 = R0.H * R5.H (IS) || R2 = W[P0] (X);
    A0 += R1.L * R6.L, A1 += R1.H * R6.H (IS);
    A0 += R2.L * R7.L (IS);
    A0 += A1;
    A0 = A0 >>> 12;
    R0.L = A0 (IS);
    W[P0++] = R0;
cb_e: W[I1++] = R0.L;
    R0 = I1;
    R1 = B1;
    R0 = R0 - R1;
    R0 >>= 1;
    [P5 + 8] = R0;
    L0 = 0; L1 = 0;
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_sn_s: sub then noise, each its own pass (the spec saturates after each). buf 0, phs 4, inc 8, dinc 12, rs 16,
 * ds 20, rng 24, nlp 28, nco 32, rn 36, dn 40, flags 44 */
.global _n2k_sn_s
.align 4
_n2k_sn_s:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    R0 = [P5 + 44];
    CC = BITTST(R0, 0);
    IF !CC JUMP sn_nosub;
    P0 = [P5 + 0];
    R1 = [P5 + 4];
    R2 = [P5 + 8];
    R4 = [P5 + 12];
    R3 = [P5 + 16];
    R5 = [P5 + 20];
    P2 = 128;
    LSETUP(su_s, su_e) LC0 = P2;
su_s: R2 = R2 + R4;                            /* inc += dinc */
    R3 = R3 + R5;                              /* rs += ds */
    R0 = R3 >>> 7;
    R6 = -R0;
    CC = R1 < 0;
    IF !CC R0 = R6;
    R6 = W[P0] (X);
    R0 = R0 + R6;
    R0 = R0 << 16 (S);
    R0 >>>= 16;
    W[P0++] = R0;
    R6 = R2 >> 1;
su_e: R1 = R1 + R6;
    [P5 + 4] = R1;
    [P5 + 8] = R2;
    [P5 + 16] = R3;
    JUMP sn_noise;
sn_nosub:                                      /* the phase still advances (closed form as the spec's loop) */
    R1 = [P5 + 4];
    R2 = [P5 + 8];
    R4 = [P5 + 12];
    P2 = 128;
    LSETUP(sp_s, sp_e) LC0 = P2;
sp_s: R2 = R2 + R4;
    R6 = R2 >> 1;
sp_e: R1 = R1 + R6;
    [P5 + 4] = R1;
    [P5 + 8] = R2;
sn_noise:
    R0 = [P5 + 44];
    CC = BITTST(R0, 1);
    IF !CC JUMP sn_done;
    P0 = [P5 + 0];
    R4 = [P5 + 24];                            /* rng */
    R5 = [P5 + 28];                            /* nlp */
    R7 = [P5 + 32];                            /* nco */
    R6 = [P5 + 36];                            /* rn */
    R1 = [P5 + 40];                            /* dn */
    P2 = 128;
    LSETUP(nz_s, nz_e) LC0 = P2;
nz_s: R0 = R4 << 13;
    R4 = R4 ^ R0;
    R0 = R4 >> 17;
    R4 = R4 ^ R0;
    R0 = R4 << 5;
    R4 = R4 ^ R0;
    R0 = R4 >>> 16;                            /* w */
    A0 = R7.L * R0.L (IS);
    A0 -= R7.L * R5.L (IS);
    A0 = A0 >>> 12;
    R2 = A0;
    R5 = R5 + R2;                              /* nlp */
    R6 = R6 + R1;
    R3 = R6 >>> 7;
    A0 = R5.L * R3.L (IS);
    A0 = A0 >>> 14;
    R2 = W[P0] (X);
    A1 = R2;
    A0 += A1;
    R0.L = A0 (IS);
nz_e: W[P0++] = R0;
    [P5 + 24] = R4;
    [P5 + 28] = R5;
    [P5 + 36] = R6;
sn_done:
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_drv_s: see n2k_drv_c. buf 0, tanh 4, rg 8, dg 12, rm 16, dm 20 */
.global _n2k_drv_s
.align 4
_n2k_drv_s:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P0 = [P5 + 0];
    P1 = [P5 + 4];
    R1 = [P5 + 8];
    R2 = [P5 + 12];
    R3 = [P5 + 16];
    R4 = [P5 + 20];
    R5.L = 0xFFFF; R5.H = 0x0001;              /* 131071 */
    R6.L = 0x0000; R6.H = 0xFFFE;              /* -131072 */
    P2 = 128;
    LSETUP(dr_s, dr_e) LC0 = P2;
dr_s: R1 = R1 + R2;
    R3 = R3 + R4;
    R7 = R1 >>> 7;
    R0 = W[P0] (X);
    A0 = R0.L * R7.L (IS);
    A0 = A0 >>> 6;
    R0 = A0;
    R0 = MIN(R0, R5);
    R0 = MAX(R0, R6);
    R0 = R0 - R6;                              /* u + 131072 */
    R7 = R0.B (Z);                             /* tf */
    R0 >>= 8;                                  /* ti */
    P2 = R0;
    P2 = P1 + (P2 << 1);
    R0 = 256;
    R0 = R0 - R7;
    R7 = PACK(R7.L, R0.L);                     /* tf : 256 - tf */
    R0 = W[P2] (X);
    A0 = R0.L * R7.L (IS) || R0 = W[P2 + 2] (X);
    A0 += R0.L * R7.H (IS);
    A0 = A0 >>> 8;
    R0 = A0;                                   /* t */
    R7 = R3 >>> 7;
    A0 = R0.L * R7.L (IS);
    A0 = A0 >>> 14;
    R0.L = A0 (IS);
dr_e: W[P0++] = R0;
    [P5 + 8] = R1;
    [P5 + 16] = R3;
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_fm_s: see n2k_fm_c. out 0, sin 4, pha 8, phb 12, inc 16, dinc 20, inc35 24, dinc35 28, dep 32, step 36.
 * R1 pa, R2 pb, R3 inc, R7 inc35, R5 (db : da), R6 (sb : sa), I0 dinc, I1 dinc35 */
.global _n2k_fm_s
.align 4
_n2k_fm_s:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P0 = [P5 + 0];
    P1 = [P5 + 4];
    R1 = [P5 + 8];
    R2 = [P5 + 12];
    R3 = [P5 + 16];
    R0 = [P5 + 20]; I0 = R0;
    R7 = [P5 + 24];
    R0 = [P5 + 28]; I1 = R0;
    R5 = [P5 + 32];
    R6 = [P5 + 36];
    P2 = 128;
    LSETUP(fm_s, fm_e) LC0 = P2;
fm_s: R0 = I0;
    R3 = R3 + R0;
    R0 = I1;
    R7 = R7 + R0;
    R0 = R1 >> 22;
    R4 = R2 >> 22;
    P2 = R0;
    P3 = R4;
    R5 = R5 +|+ R6;
    R1 = R1 + R3;
    P2 = P1 + (P2 << 1);
    P3 = P1 + (P3 << 1);
    R2 = R2 + R7;
    R0 = W[P2] (X);
    R4 = W[P3] (X);
    R0 = PACK(R4.L, R0.L);
    A0 = R0.L * R5.L, A1 = R0.H * R5.H (IS);
    A0 += A1;
    A0 = A0 >>> 15;
    R0.L = A0 (IS);
fm_e: W[P0++] = R0;
    [P5 + 8] = R1;
    [P5 + 12] = R2;
    [P5 + 16] = R3;
    [P5 + 24] = R7;
    [P5 + 32] = R5;
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_dcl_s: n2k_dc then n2k_lvl in one loop. buf 0, out 4, z 8, r 12, d 16 */
.global _n2k_dcl_s
.align 4
_n2k_dcl_s:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    P0 = [P5 + 0];
    P1 = [P5 + 4];
    R1 = [P5 + 8];
    R5 = [P5 + 12];
    R6 = [P5 + 16];
    P2 = 128;
    LSETUP(dl_s, dl_e) LC0 = P2;
dl_s: R0 = W[P0++] (X);
    R2 = R1 >>> 9;
    R1 = R1 + R0;
    R1 = R1 - R2;
    R3 = R1 >>> 9;
    R0 = R0 - R3;
    R0 = R0 << 16 (S);
    R0 >>>= 16;                                /* y2 */
    R5 = R5 + R6;
    R3 = R5 >>> 7;
    A0 = R0.L * R3.L (IS);
    A0 = A0 >>> 11;
    R0.L = A0 (IS);
dl_e: W[P1++] = R0;
    [P5 + 8] = R1;
    [P5 + 12] = R5;
    (R7:4, P5:3) = [SP++];
    RTS;

/* n2k_layer_s: y[r] = sat16(relu?(((sum_c w[r][c] x[c]) >> 12) + b[r])), int16, cols even >= 4; the 40-bit sums
 * saturate to 32 bits where the C spec would wrap (the export checks the sums stay inside 31 bits).
 * w 0, b 4, x 8, y 12, rows 16, cols 20, relu 24 */
.global _n2k_layer_s
.align 4
_n2k_layer_s:
    [--SP] = (R7:4, P5:3);
    P5 = R0;
    R0 = [P5 + 0]; I1 = R0;
    P3 = [P5 + 4];
    R1 = [P5 + 8];
    P4 = [P5 + 12];
    P0 = [P5 + 16];
    R7 = [P5 + 20];
    R6 = [P5 + 24];
    R7 >>= 1;
    R7 += -1;
    P1 = R7;
    R3 = 0;
    LSETUP(ly_s, ly_e) LC1 = P0;
ly_s: I0 = R1;
    A1 = A0 = 0 || R4 = [I0++] || R5 = [I1++];
    LSETUP(lz_s, lz_s) LC0 = P1;
lz_s: A1 += R4.H * R5.H, A0 += R4.L * R5.L (IS) || R4 = [I0++] || R5 = [I1++];
    A1 += R4.H * R5.H, A0 += R4.L * R5.L (IS);
    R0 = (A0 += A1);
    R0 >>>= 12;
    R2 = W[P3++] (X);
    R0 = R0 + R2;
    CC = R6 == 0;
    R2 = MAX(R0, R3);
    IF !CC R0 = R2;
    R0 = R0 << 16 (S);
    R0 >>>= 16;
ly_e: W[P4++] = R0;
    (R7:4, P5:3) = [SP++];
    RTS;
