/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* mv16_asm(w, x, o, rows, cols): o[r] = sum w[r][c]*x[c], int16, cols even >= 4, dual MAC + dual DAG loads */
.text
.global _mv16_asm
.align 4
_mv16_asm:
    [--SP] = (R7:4, P5:3);
    R3 = [SP + 40];             /* rows (28 saved + 12) */
    R7 = [SP + 44];             /* cols */
    P5 = R3;
    P4 = R2;
    I1 = R0;
    R6 = R7 >> 1;
    R6 += -1;
    P1 = R6;
    LSETUP(ro_s, ro_e) LC1 = P5;
ro_s: I0 = R1;
    A1 = A0 = 0 || R4 = [I0++] || R5 = [I1++];
    LSETUP(in_s, in_s) LC0 = P1;
in_s: A1 += R4.H * R5.H, A0 += R4.L * R5.L (IS) || R4 = [I0++] || R5 = [I1++];
    A1 += R4.H * R5.H, A0 += R4.L * R5.L (IS);
    R0 = (A0 += A1);
ro_e: [P4++] = R0;
    (R7:4, P5:3) = [SP++];
    RTS;
