/* drift_view_stub.c: a stand-in for DRIFT's engine side of drift_view.h, for host tests and goldens only (never in
 * a plugin build: it uses doubles). It fills drift_view as the engine would, from a script of note ons, note offs,
 * knob values and blocks (drift_screen_test.c drives it), and draws tables from a made-up formula instead of the
 * net: saw-like harmonics, brighter with knob 1 and early in the note, hollower with knob 2, a bump with knob 4.
 * The DSP settings are made up from the knobs too. Shapes and settings are not the engine's: they only give the
 * screen something to draw. The real engine replaces this file (README.md).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef OP1_HOST
#error "drift_view_stub.c is for host tests only"
#endif
#include <math.h>
#include "drift_view.h"
#include "drift_view_stub.h"

volatile drift_view_t drift_view;
static int16_t st_knobs[4] = { 16384, 16384, 16384, 16384 };
static uint8_t st_ended[DRIFT_VIEW_VOICES];

static double k01(int16_t k) { return k < 0 ? 0 : k / 32767.0; }
static int16_t q12(double x) { return (int16_t)lrint((x < 0 ? 0 : x > 1 ? 1 : x) * 4096); }

int drift_view_table(int16_t pitch_q12, int16_t vel_q12, uint32_t age, const int16_t knobs[4], int16_t *out, int n)
{
    const double k0 = k01(knobs[0]), k1 = k01(knobs[1]), k3 = k01(knobs[3]);
    const double t = (age > 2047 ? 2047 : age) / 689.0, p = pitch_q12 / 4096.0, v = vel_q12 / 4096.0;
    const double bright = (0.15 + 0.7 * k0) * (0.55 + 0.45 * exp(-t / 0.5)) * (1.0 - 0.3 * p) * (0.7 + 0.3 * v);
    double buf[128], mx = 1e-9;
    for (int i = 0; i < n; i++) {
        const double ph = 2 * M_PI * i / n;
        double s = 0;
        for (int h = 1; h <= 9; h++) {
            double a = pow(bright, h - 1) / h;
            if (!(h & 1)) a *= 1.0 - 0.9 * k1;                                   /* hollow: odd harmonics */
            a *= 1.0 + 2.5 * k3 * exp(-(h - 4) * (h - 4) / 2.0);                 /* a formant bump */
            s += a * sin(h * ph);
        }
        buf[i] = s;
        if (fabs(s) > mx) mx = fabs(s);
    }
    for (int i = 0; i < n; i++) out[i] = (int16_t)lrint(buf[i] / mx * 0.9 * 32767);
    return 1;
}

static void st_prm(volatile drift_view_voice_t *v)
{
    const double k0 = k01(st_knobs[0]), k1 = k01(st_knobs[1]), k2 = k01(st_knobs[2]), k3 = k01(st_knobs[3]);
    const double t = v->age / 689.0;
    v->prm[DV_CUT] = q12((0.3 + 0.6 * k0) * (0.6 + 0.4 * exp(-t / 0.4)));
    v->prm[DV_RES] = q12(0.8 * k1);
    v->prm[DV_FMA] = q12(pow(0.7 * k3 * (1 - k1), 2));
    v->prm[DV_FMB] = q12(pow(0.8 * k3 * k1, 2));
    v->prm[DV_NOI] = q12(pow(0.8 * k2, 2));
    v->prm[DV_NCO] = q12(k1);
    v->prm[DV_CFB] = q12(0.7 * k2);
    v->prm[DV_CDA] = q12(1 - k1);
    v->prm[DV_DRV] = q12(pow(0.4 * k0, 2));
    v->prm[DV_SUB] = q12(pow(0.9 * (1 - k1), 2));
    v->prm[DV_LVL] = 2048;
    /* the engine's module budget (nosc2_core.h n2_guard): modules below the gate are off, and the largest ones that
     * fit 140 cost units stay on (cut 41, FM 49, noise 33, drive 39, sub 18, comb 66): a voice has two or three */
    static const int idx[6][2] = { { DV_CUT, DV_RES }, { DV_FMA, DV_FMB }, { DV_NOI, DV_NOI }, { DV_DRV, DV_DRV },
                                   { DV_SUB, DV_SUB }, { DV_CFB, DV_CFB } };
    static const int cost[6] = { 41, 49, 33, 39, 18, 66 };
    int amt[6], on[6] = { 0 }, left = 140;
    for (int m = 0; m < 6; m++) {
        amt[m] = v->prm[idx[m][0]] > v->prm[idx[m][1]] ? v->prm[idx[m][0]] : v->prm[idx[m][1]];
        if (m == 0) amt[m] = 4096 - amt[m];                       /* the filter: the more it closes, the more it does */
    }
    for (;;) {
        int best = -1;
        for (int m = 0; m < 6; m++) if (!on[m] && amt[m] >= 64 && cost[m] <= left && (best < 0 || amt[m] > amt[best])) best = m;
        if (best < 0) break;
        on[best] = 1; left -= cost[best];
    }
    for (int m = 1; m < 6; m++) if (!on[m]) v->prm[idx[m][0]] = v->prm[idx[m][1]] = 0;
    if (!on[0]) { v->prm[DV_CUT] = 4096; v->prm[DV_RES] = 0; }
}

void dvs_knobs(const int16_t k[4])
{
    for (int j = 0; j < 4; j++) st_knobs[j] = k[j];
}
void dvs_note_on(int vi, int note, int vel127)
{
    volatile drift_view_voice_t *v = &drift_view.v[vi];
    drift_view.serial++;
    v->serial = drift_view.serial;
    v->note = (uint8_t)note;
    v->pitch_q12 = (int16_t)((note - 36) * 4096 / 60);
    v->vel_q12 = (int16_t)(vel127 * 4096 / 127);
    v->age = 0; v->released = 0; v->active = 1;
    st_ended[vi] = 0;
}
void drift_view_sync(void) {}                       /* the stub fills drift_view as it goes */
void dvs_note_off(int vi) { drift_view.v[vi].released = 1; }
void dvs_end(int vi) { st_ended[vi] = 1; }            /* R246's envelope ended: render stops (active stays 1) */
void dvs_blocks(int n)
{
    for (int b = 0; b < n; b++) {
        for (int i = 0; i < DRIFT_VIEW_VOICES; i++) {
            volatile drift_view_voice_t *v = &drift_view.v[i];
            if (!v->active || st_ended[i]) continue;
            v->tick++;
            st_prm(v);
            v->age++;
        }
        for (int j = 0; j < 4; j++) drift_view.knobs[j] = st_knobs[j];
    }
}
