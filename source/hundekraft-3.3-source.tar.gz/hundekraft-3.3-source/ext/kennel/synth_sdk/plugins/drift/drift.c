/* DRIFT: a neural oscillator. A small net turns pitch, velocity, the note's age and four latent
 * knobs into a 128-sample wave table and 15 synth settings every block; a per-sample DSP voice (sync, FM, unison,
 * sub, noise, drive, filter, comb) plays them. The engine is nosc2_core.h with the model in nosc2_weights.h and the
 * Blackfin kernels in nosc2_kern.S, nosc_blend.S, mv16.S (drift_asm.S), the reference's (the design: OP1-Emulator
 * docs/neural-osc-2026-11-13.md) with three cache-line touches added to the core and, owner 2026-11-14, one envelope-timing
 * change (each voice's module load kept live every block, the head's tick waits at most one block in a row, two
 * voices take a new commit a block): only the blocks the envelope commits land on differ. This file is the glue:
 *   - the four knobs (render's params: R246 hands the words over after the LFO) -> z, Q12, through lt_zk (one
 *     65-point table a knob, knob_law.py: steps of equal timbre change, ends at -/+2.576 as before); one set for all voices;
 *   - once a block, before the first voice renders: note starts, then the shared envelope head's slice
 *     (nosc2_env_step), as the reference harness (render4.c) orders them; nosc2_env_fill once at the first block;
 *   - pitch: in[0] = (MIDI - 36) / 60 in Q12 from log2 of the voice's OP1_PITCH_INC (88.2 kHz steps), per block;
 *     velocity -> in[1] and a level of 1/4 .. 1 at full scale (the reference's stand-in mix + 6 dB, owner 2026-11-14;
 *     saturated; lt_gain_s on the Blackfin, the C loop
 *     is its spec);
 *   - L1: the net's weights and the table scratch (8,100 B) in OP1_L1_SYNTH, claimed on every render; fresh -> copied
 *     in. Without the partition a sounding voice holds its last table and settings for the block (the weights from
 *     SDRAM cost more than the slot has); a note that starts then decodes once from lt_home, an SDRAM copy.
 *   - the screen's view (drift_view.c, drift_view.h): one call at each note start and one at the block's start (the
 *     knobs); nothing per voice and block: the GUI thread copies the voices' state itself (drift_view_sync, through
 *     lt_voice). The view's data and code live in drift_view.c, so this file's data layout (which the cache cost
 *     depends on) is the CPU pass's. The screen is drift_screen.c.
 * R246's ADSR shapes the level.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "op1_plugin.h"
#if defined(__bfin__)
void mv16_asm(const int16_t *, const int16_t *, int32_t *, int, int);
void nosc_blend_asm(const int16_t *, const int16_t *, int16_t *);
#define NOSC_MV mv16_asm
#define NOSC_BLEND nosc_blend_asm
#define N2K_ASM
#define LT_GAIN_ASM
void lt_gain_s(int16_t *, int32_t);
#endif
#include "nosc2_weights.h"
#include "drift_tables.h"

typedef char lt_l1_fits[sizeof(struct nosc2_l1) <= 8192 ? 1 : -1];

static struct nosc2_voice lt_v[OP1_VOICES] __attribute__((aligned(32)));   /* keep the engine's layout and alignment */
static struct nosc2_envnet lt_env;
static struct nosc2_l1 lt_home __attribute__((aligned(32)));   /* the SDRAM copy (no partition, host builds) */
static uint8_t lt_home_ok, lt_env_ok, lt_on[OP1_VOICES], lt_seen[OP1_VOICES];
static volatile uint8_t lt_req[OP1_VOICES];                    /* note_on (any thread) counts; render starts the note */
static uint32_t lt_blk, lt_vblk[OP1_VOICES];
static int8_t lt_last = 127;
static int16_t lt_z[4];
void lt_view_start(int vi);                                    /* drift_view.c: the screen's view */
void lt_view_knobs(const int16_t *params);
void lt_note_off(void *self);

#define LT_W_BYTES ((uint32_t)((const char *)&nosc2_l1_init.tmp - (const char *)&nosc2_l1_init))   /* the weights */
static void lt_copy(struct nosc2_l1 *d)
{
    const uint32_t *s = (const uint32_t *)(const void *)&nosc2_l1_init;
    uint32_t *o = (uint32_t *)(void *)d;
    for (uint32_t i = 0; i < LT_W_BYTES / 4; i++) o[i] = s[i];
}
static struct nosc2_l1 *lt_home_get(void)
{
    if (!lt_home_ok) { lt_copy(&lt_home); lt_home_ok = 1; }
    return &lt_home;
}
/* this render's weights: the L1 partition, or 0 (hold) */
static struct nosc2_l1 *lt_l1(void)
{
#if defined(__bfin__)
    int fresh = 0;
    struct nosc2_l1 *l = (struct nosc2_l1 *)op1_l1_claim(OP1_L1_SYNTH, lt_v, sizeof(struct nosc2_l1), &fresh);
    if (l && fresh) lt_copy(l);
    return l;
#else
    return lt_home_get();                       /* host builds: no pool, the SDRAM copy every block */
#endif
}

/* knob j's word 0..32767 -> z, Q12: knob_law.json's 65 points (steps of equal timbre change), 9 bits interpolated */
static int16_t lt_zof(int j, int32_t k)
{
    const int16_t *t = lt_zk[j];
    if (k <= 0) return t[0];
    if (k >= 32767) return t[64];
    int32_t i = k >> 9, f = k & 511;
    return (int16_t)(t[i] + (((t[i + 1] - t[i]) * f) >> 9));
}
/* phase increment (88.2 kHz) -> (MIDI - 36) / 60, Q12 */
static int16_t lt_pitch(uint32_t inc)
{
    if (!inc) return 0;
    int32_t e = 31;
    if (!(inc >> 16)) { inc <<= 16; e -= 16; }
    if (!(inc >> 24)) { inc <<= 8; e -= 8; }
    if (!(inc >> 28)) { inc <<= 4; e -= 4; }
    if (!(inc >> 30)) { inc <<= 2; e -= 2; }
    if (!(inc >> 31)) { inc <<= 1; e -= 1; }
    int32_t i = (int32_t)((inc >> 25) & 63), f = (int32_t)((inc >> 17) & 255);
    int32_t d = e * 4096 + lt_log2[i] + (((lt_log2[i + 1] - lt_log2[i]) * f) >> 8) - LT_C12;   /* Q12 octaves from A4 */
    if (d > 27000) d = 27000; else if (d < -27000) d = -27000;
    return (int16_t)((d * 52429 + 590558003 + 131072) >> 18);   /* (69 + 12 d - 36) / 60 x 4096: d / 5 + 2252.8 */
}
static int16_t lt_vel(int vi)
{
    int32_t v = OP1_VOICE_VEL[vi] >> 8;
    return (int16_t)(v > 0 && v <= 127 ? (v * 33026) >> 10 : 4096);   /* 127 -> 4096 */
}
static void lt_start(int vi)
{
    lt_seen[vi] = lt_req[vi];
    nosc2_note_on(&lt_v[vi], 0, 0, lt_vel(vi));  /* inc and pitch are set when the voice renders (OP1_PITCH_INC) */
    lt_on[vi] = 1; lt_vblk[vi] = lt_blk;
    lt_view_start(vi);
}

static void lt_note_on(void *self, const int16_t *params)
{
    (void)params;
    int vi = op1_voice_index(self);
    if (vi >= 0 && vi < OP1_VOICES) lt_req[vi]++;
}

static void lt_render(void *self, int16_t *out, const int16_t *params)
{
    const int vi = op1_voice_index(self);
    if (vi < 0 || vi >= OP1_VOICES) { for (int i = 0; i < OP1_BLOCK; i++) out[i] = 0; return; }
    if (vi <= lt_last) {                         /* R246 renders the voices in order: a new block */
        lt_blk++;
        for (int j = 0; j < 4; j++) lt_z[j] = lt_zof(j, params[j]);
        if (!lt_env_ok) { nosc2_env_fill(&nosc2_far_init, &lt_env, lt_z); lt_env_ok = 1; }
        for (int i = 0; i < OP1_VOICES; i++) if (lt_req[i] != lt_seen[i]) lt_start(i);
        struct nosc2_voice *pv[OP1_VOICES]; int np = 0;
        for (int i = 0; i < OP1_VOICES; i++) if (lt_on[i] && lt_vblk[i] + 1 >= lt_blk) pv[np++] = &lt_v[i];
        nosc2_env_step(&nosc2_far_init, &lt_env, lt_z, pv, np);
        lt_view_knobs(params);                     /* the screen's view: the knobs this block */
    }
    lt_last = (int8_t)vi;
    if (lt_req[vi] != lt_seen[vi] || !lt_on[vi]) lt_start(vi);   /* a note_on after this block's start */
    lt_vblk[vi] = lt_blk;
    struct nosc2_voice *v = &lt_v[vi];
    const uint32_t inc = (uint32_t)OP1_PITCH_INC[OP1_BLOCK - 1];
    v->inc = inc;
    if (!v->age) v->incp = inc;
    v->in[0] = lt_pitch(inc);
    for (int j = 0; j < 4; j++) v->in[3 + j] = lt_z[j];
    struct nosc2_l1 *L = lt_l1();
    if (!L && !v->age) L = lt_home_get();
    nosc2_render(L, &lt_env, v, out);
    int32_t h = ((4096 + v->in[1] * 3) * op1_preset_trim(params)) >> 13;   /* velocity: 1/4 .. 1 at full scale (Q15 x 2:
                                                  * the reference mix's half scale +6 dB, owner 2026-11-14) times the preset
                                                  * trim (word 7, Q13; 0 = 1x); at 1x h <= 16384, so one voice never exceeds
                                                  * int16; capped at 32767 (about 2x at full velocity), the asm's 1.15 range */
    if (h > 32767) h = 32767;
#ifdef LT_GAIN_ASM
    if (!((uintptr_t)out & 3)) { lt_gain_s(out, h); return; }   /* (x h) >> 15, then x 2, saturated */
#endif
    for (int i = 0; i < OP1_BLOCK; i++) {
        int32_t y = ((out[i] * h) >> 15) * 2;
        out[i] = (int16_t)(y > 32767 ? 32767 : y < -32768 ? -32768 : y);
    }
}

const op1_engine_t ENGINE_drift = { lt_note_on, lt_render, lt_note_off, { OP1_PRESS_NONE, OP1_PRESS_NONE, OP1_PRESS_NONE, OP1_PRESS_NONE } };

/* the screen's view (drift_view.c drift_view_sync, GUI thread) reads the voices through this, read only */
const struct nosc2_voice *lt_voice(int i) { return &lt_v[i]; }
