/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* Neural oscillator v2: the latent net (as nosc_core.h) plus a per-sample DSP voice. Host and Blackfin bit-exact:
 * integer only, every overflow bounded or saturated explicitly. 88.2 kHz, 128-sample blocks (R246 units).
 *
 * Per block the net gives a 128-sample table (16 basis waves) and NP params (Q12, 0..4096), all ramped across the
 * block from the previous block's values (the table crossfades):
 *   CUT  filter cutoff, 20 Hz x 2^(10 x) (<= 18 kHz)     RES  resonance (k = 2 - 1.75 x, peak gain <= 4)
 *   FMA  FM depth, modulator at 1 x pitch (<= 2 pi)      FMB  FM depth, modulator at 3.5 x pitch
 *   UNI  second (detuned) oscillator level               DET  its detune, 0..25 cents
 *   NOI  noise level                                     NCO  noise colour (1-pole, dark .. white)
 *   DRV  drive into tanh, gain 1..8 with makeup          SYN  hard sync ratio 1..4
 *   SUB  square sub-octave level                         BLP  pitch offset 0..+24 semitones
 *   CFB  comb feedback 0..0.97 (tuned to the pitch)      CDA  comb damping
 *   LVL  level trim 0.25..4 (log)
 * Chain: osc (sync, FM, crossfaded table) + unison + sub + noise -> drive -> TPT SVF low-pass -> comb -> level. */
#include <stdint.h>
#include "nosc2_tables.h"
#include "nosc2_kern.h"

#define NI 8
#define NH 32
#define NB 16
#define TL 128
#define BLK 128
#define NP 15
enum { CUT, RES, FMA, FMB, UNI, DET, NOI, NCO, DRV, SYN, SUB, BLP, CFB, CDA, LVL };
/* the net's parameter outputs: envelopes for the fast-moving settings, levels square-law coded (x -> x^2) */
enum { E_CUT0, E_CUT1, E_CUTT, E_RES, E_FMA0, E_FMA1, E_FMAT, E_FMB0, E_FMB1, E_FMBT, E_UNI, E_DET, E_NOI0, E_NOI1, E_NOIT,
       E_NCO, E_DRV, E_SYN0, E_SYN1, E_SYNT, E_SUB, E_BLP, E_BLPT, E_CFB, E_CDA, E_LVL, NE };
#define NTAU2 320                                   /* blocks 0..63 one a step, then 8 a step: 64 + 256 */
#define COMB_N 2048

struct nosc2_l1 {                                   /* the L1 lease: as v1 */
    int16_t w1[NH * NI], w2[NH * NH], w3[NB * NH];
    int16_t b1[NH], b2[NH], b3[NB];
    int16_t basis[NB][TL];
    int16_t tmp[TL + 2] __attribute__((aligned(4)));   /* this block's new table, for the voice being rendered (the
                                                          oscillators read it from L1; it goes to the voice after) */
};
#define NEI 8                                       /* envelope head input: the knobs z0..z3, 0 x 4 */
#ifndef NEH
#define NEH 32                                      /* its hidden width */
#endif
/* envelope head (train_env4.py): the knobs -> coefficients. Each dynamic setting (cutoff, FM, noise, sync and blip
 * envelopes) is a quadratic in u = 2p - 1, w = 2v - 1 (6 terms); the static ones are a single value. */
#define N2_NDYN 17
#define N2_NSTA 9
#define NFO (N2_NDYN * 6 + N2_NSTA)
struct nosc2_far {                                  /* SDRAM */
    int16_t ew1[NEH * NEI], ew2[NEH * NEH], ew3[NFO * NEH];
    int16_t eb1[NEH], eb2[NEH], eb3[NFO];
} __attribute__((aligned(4)));                      /* n2k_layer_s reads the weights 32 bits at a time: without this the
                                                       object sits wherever the rodata before it ends (rc11: 2 mod 4
                                                       after lt_zk, a misaligned load, CEC double fault) */
_Static_assert(_Alignof(struct nosc2_far) >= 4 && _Alignof(struct nosc2_l1) >= 4, "n2k_layer_s: 32-bit weight loads");
/* the head is shared by all voices (one knob set). It runs a few hundred multiplies a block (nosc2_env_tick, a
 * fixed budget whatever the voice count) and commits its coefficients when a run completes; each voice sums its
 * terms at note on and at each commit. */
#ifndef N2_NSL
#define N2_NSL 8                                    /* blocks per run */
#endif
struct nosc2_envnet {
    int16_t c[NFO];                                 /* the committed coefficients */
    int16_t ein[NEI] __attribute__((aligned(4)));   /* this run's inputs */
    int16_t e1[NEH] __attribute__((aligned(4))), e2[NEH] __attribute__((aligned(4))), eo[NFO];
    uint32_t gen;                                   /* counts commits */
    uint16_t lay, row;                              /* where the run is: layer 0..2, row */
    uint16_t wait;                                  /* blocks the tick has waited in a row (nosc2_env_step) */
    uint16_t adopt;                                 /* sounding voices that may still take a new commit this block */
};

struct nosc2_voice {                                /* the fields every block uses first, packed into whole cache lines */
    uint32_t ph, ph2, pha, phb, phs, inc, incp, age, rng;
    int32_t a1p, a2p, a3p, ic1, ic2, nlp, cd, dcz;
    int32_t wp1, wp2;                              /* previous block's oscillator mix weights */
    uint32_t cw;                                    /* comb write position */
    uint32_t cfill;                                 /* comb samples written since note on */
    uint32_t fmdep, synr, ramped;                   /* where the FM depth and sync ramps actually ended (bit 0 FM, 1 sync, 2 filter) */
    uint32_t egen;                                  /* the envelope generation the settings came from */
    int32_t load;                                   /* guard cost of the modules the last block left on (every block) */
    const int16_t *tn;                              /* this block's table (L1 scratch, or tab itself when holding) */
    int16_t in[NI];
    int16_t prm[NP], prmp[NP];
    int16_t env[NE];                                /* the envelope settings */
    int16_t tab[TL + 2] __attribute__((aligned(32)));       /* the previous block's table (+2: 4-byte rows, the wrap sample) */
    int16_t comb[COMB_N] __attribute__((aligned(32)));
} __attribute__((aligned(32)));
extern const int16_t nosc2_tau[NTAU2];

static inline int16_t n2_sat16(int32_t a) { return (int16_t)(a > 32767 ? 32767 : a < -32768 ? -32768 : a); }
static inline int32_t n2_clamp(int32_t a, int32_t m) { return a > m ? m : a < -m ? -m : a; }
static inline int32_t n2_lut65(const int32_t *t, int32_t x)     /* x Q12 0..4096 over 65 points, interpolated */
{
    int32_t i = x >> 6, f = x & 63;
    if (i >= 64) return t[64];
    return t[i] + (((t[i + 1] - t[i]) * f) >> 6);
}
static void n2_svf_coef(int32_t cut, int32_t res, int32_t *a1, int32_t *a2, int32_t *a3)
{
    int32_t i = cut >> 4, f = cut & 15;
    int32_t g = i >= 256 ? n2_g[256] : n2_g[i] + (((n2_g[i + 1] - n2_g[i]) * f) >> 4);   /* Q16 */
    int32_t k = 131072 - res * 28;                                  /* 2 - 1.75 res, Q16: 1.75 x 65536 / 4096 = 28 */
    int32_t den = 65536 + (((g >> 4) * ((g + k) >> 4)) >> 8);       /* Q16 */
    *a1 = (int32_t)((1 << 28) / den);                               /* Q12 */
    *a2 = (int32_t)(((int64_t)g * *a1) >> 16);
    *a3 = (int32_t)(((int64_t)g * *a2) >> 16);
}
static void n2_mixw(int32_t uni, int32_t *w1, int32_t *w2)
{
    *w1 = (4096 * 4096) / (4096 + uni);
    *w2 = (uni * 4096) / (4096 + uni);
}

/* tests and target renders: set this block's table (the previous one becomes the crossfade source) */
static void nosc2_push_tab(struct nosc2_voice *v, const int16_t *t)
{
    static int16_t pt[TL + 2] __attribute__((aligned(4)));   /* host libraries: one voice */
    for (int i = 0; i < TL; i++) pt[i] = t[i];
    pt[TL] = t[0]; v->tn = pt;
}
static void nosc2_note_on(struct nosc2_voice *v, uint32_t inc, int16_t pitch_q12, int16_t vel_q12)
{
    v->inc = v->incp = inc; v->age = 0;
    v->ph = 0; v->ph2 = 0x40000000u; v->pha = 0; v->phb = 0; v->phs = 0;
    v->in[0] = pitch_q12; v->in[1] = vel_q12; v->in[2] = 0;
    v->ic1 = v->ic2 = v->nlp = v->cd = v->dcz = 0;
    if (!v->rng) v->rng = 0x9E3779B9u;
    v->cfill = 0;                                    /* the comb line is zeroed lazily, as it is read */
    v->ramped = 0;
    v->age = 0;
}

/* the DSP voice: tab / prm are this block's (the net's, or a target's); out = the voice alone */
/* the DSP voice: kernels from nosc2_kern.h (C spec) or nosc2_kern.S (N2K_ASM), each skipped when its module is off
 * at both ends of the block; out is the working buffer (Q13) until the level pass writes Q15 into it. */
#ifdef N2_PROF
uint32_t n2_pt[14], n2_last;
#define N2_T(n) do { uint32_t c_; __asm__ volatile ("%0 = CYCLES;" : "=d"(c_)); n2_pt[n] += c_ - n2_last; n2_last = c_; } while (0)
#endif
#ifndef N2_T
#define N2_T(n) ((void)0)
#endif
#ifndef N2_MASK
#define N2_MASK 0xffff
#endif
#ifdef N2K_ASM
#include "nosc2_kern_have.h"
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_osc)
void n2k_osc_s(struct n2k_osc *);
#define N2K_osc(a) n2k_osc_s(a)
#else
#define N2K_osc(a) n2k_osc_c(a)
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_fm)
void n2k_fm_s(struct n2k_fm *);
#define N2K_fm(a) n2k_fm_s(a)
#else
#define N2K_fm(a) n2k_fm_c(a)
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_sn)
void n2k_sn_s(struct n2k_sn *);
#define N2K_sn(a) n2k_sn_s(a)
#else
#define N2K_sn(a) n2k_sn_c(a)
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_drv)
void n2k_drv_s(struct n2k_drv *);
#define N2K_drv(a) n2k_drv_s(a)
#else
#define N2K_drv(a) n2k_drv_c(a)
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_svf)
void n2k_svf_s(struct n2k_svf *);
#define N2K_svf(a) n2k_svf_s(a)
#else
#define N2K_svf(a) n2k_svf_c(a)
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_dc)
void n2k_dc_s(struct n2k_dc *);
#define N2K_dc(a) n2k_dc_s(a)
#else
#define N2K_dc(a) n2k_dc_c(a)
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_comb)
void n2k_comb_s(struct n2k_comb *);
#define N2K_comb(a) n2k_comb_s(a)
#else
#define N2K_comb(a) n2k_comb_c(a)
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_layer)
void n2k_layer_s(struct n2k_layer *);
#define N2K_layer(a) n2k_layer_s(a)
#else
#define N2K_layer(a) n2k_layer_c(a)
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_dcl)
void n2k_dcl_s(struct n2k_dcl *);
#define N2K_dcl(a) n2k_dcl_s(a)
#else
#define N2K_dcl(a) n2k_dcl_c(a)
#endif
#if defined(N2K_ASM) && defined(N2K_HAVE_lvl)
void n2k_lvl_s(struct n2k_lvl *);
#define N2K_lvl(a) n2k_lvl_s(a)
#else
#define N2K_lvl(a) n2k_lvl_c(a)
#endif
/* read one word of each 32-byte line of [p, p + n int16): SDRAM lines are cached on reads only, so a run of stores to
 * lines not in the cache would each go to the bus; touched first, they hit */
static inline void n2_touch16(const int16_t *p, uint32_t n)
{
    if (!n) return;
    uintptr_t a = (uintptr_t)p & ~(uintptr_t)31, e = (uintptr_t)(p + n);
    for (; a < e; a += 32) (void)*(const volatile int32_t *)a;
}
static void n2_zero16(int16_t *p, uint32_t n)          /* zero n int16, 32-bit stores where aligned */
{
    n2_touch16(p, n);
    if (n && ((uintptr_t)p & 2)) { *p++ = 0; n--; }
    uint32_t *q = (uint32_t *)p;
    for (uint32_t j = 0; j < n >> 1; j++) q[j] = 0;
    if (n & 1) p[n - 1] = 0;
}
static void n2_svf_q15(int32_t cut, int32_t res, int32_t *a1, int32_t *a2, int32_t *a3)
{
    int32_t i = cut >> 4, f = cut & 15;
    int32_t g = i >= 256 ? n2_g[256] : n2_g[i] + (((n2_g[i + 1] - n2_g[i]) * f) >> 4);   /* Q16 */
    int32_t k = 131072 - res * 28;
    uint32_t den = 65536u + (uint32_t)((((g >> 4) * ((g + k) >> 4)) >> 8));
    int32_t q = (int32_t)(0x80000000u / den); if (q > 32767) q = 32767;
    *a1 = q; *a2 = (g * q) >> 16; *a3 = (g * *a2) >> 16;
}
static uint32_t n2_inc_of(uint32_t inc, int32_t blp) { return (uint32_t)(((uint64_t)inc * (uint32_t)n2_lut65(n2_blip, blp)) >> 12); }
static uint32_t n2_inc2_of(uint32_t inc, int32_t det) { return inc + (uint32_t)(((uint64_t)inc * ((uint32_t)n2_lut65(n2_detune, det) - (1u << 24))) >> 24); }
static int32_t n2_gain_of(int32_t lvl, int32_t uni) { return (n2_lut65(n2_level, lvl) * ((4096 * 4096) / (4096 + uni))) >> 12; }
/* envelopes -> this block's parameters. seg = s1 + (s0 - s1) E, E = exp(-t / tau) = 2^-(age x rate(tau));
 * square-law levels: value x (Q12, may be negative = off) -> max(x, 0)^2 >> 12. Integer only, no per-voice state. */
static int32_t n2_decay(int32_t tx, uint32_t age)                     /* Q15 */
{
    uint32_t r = (uint32_t)n2_lut65(n2_rate, tx < 0 ? 0 : tx > 4096 ? 4096 : tx);
    if (age > 16383) age = 16383;
    uint32_t u = age * r;                                               /* Q16 */
    uint32_t n = u >> 16;
    if (n >= 15) return 0;
    return n2_lut65(n2_exp2n, (int32_t)((u & 0xffff) >> 4)) >> n;
}
static inline int32_t n2_seg(int32_t s0, int32_t s1, int32_t e15) { return s1 + (((s0 - s1) * e15) >> 15); }
static inline int32_t n2_sq(int32_t x) { if (x <= 0) return 0; if (x > 4096) x = 4096; return (x * x) >> 12; }
static inline int16_t n2_c12(int32_t x) { return (int16_t)(x < 0 ? 0 : x > 4096 ? 4096 : x); }
static void n2_env_eval(struct nosc2_voice *v)
{
    const int16_t *e = v->env; int16_t *p = v->prm; uint32_t a = v->age;
    p[CUT] = n2_c12(n2_seg(e[E_CUT0], e[E_CUT1], n2_decay(e[E_CUTT], a)));
    p[RES] = n2_c12(e[E_RES]);
    p[FMA] = (int16_t)n2_sq(n2_seg(e[E_FMA0], e[E_FMA1], n2_decay(e[E_FMAT], a)));
    p[FMB] = (int16_t)n2_sq(n2_seg(e[E_FMB0], e[E_FMB1], n2_decay(e[E_FMBT], a)));
    p[UNI] = (int16_t)n2_sq(e[E_UNI]);
    p[DET] = n2_c12(e[E_DET]);
    p[NOI] = (int16_t)n2_sq(n2_seg(e[E_NOI0], e[E_NOI1], n2_decay(e[E_NOIT], a)));
    p[NCO] = n2_c12(e[E_NCO]);
    p[DRV] = (int16_t)n2_sq(e[E_DRV]);
    p[SYN] = (int16_t)n2_sq(n2_seg(e[E_SYN0], e[E_SYN1], n2_decay(e[E_SYNT], a)));
    p[SUB] = (int16_t)n2_sq(e[E_SUB]);
    p[BLP] = (int16_t)n2_sq(n2_seg(e[E_BLP], -1024, n2_decay(e[E_BLPT] > 2458 ? 2458 : e[E_BLPT], a)));   /* towards OFF, tau <= 0.2 s: ends at 0 */
    {   /* comb: ring time coded log: x -> feedback 1 - 2^(-7 x) (1 .. 128 periods), P = feedback / 0.97 */
        int32_t x = e[E_CFB] < 0 ? 0 : e[E_CFB] > 4096 ? 4096 : e[E_CFB];
        uint32_t u = (uint32_t)x * 7;                                   /* Q12 */
        int32_t g = n2_lut65(n2_exp2n, (int32_t)(u & 4095)) >> (u >> 12); /* 2^-(7 x), Q15 */
        int32_t fb = 32767 - g;                                         /* Q15 */
        int32_t pc = (fb * 4223) >> 15;                                 /* / 0.97 in Q12: 4096 / 0.97 = 4223 */
        p[CFB] = (int16_t)(pc > 4096 ? 4096 : pc);
    }
    p[CDA] = n2_c12(e[E_CDA]);
    p[LVL] = n2_c12(e[E_LVL]);
}
/* module budget. Every module whose amount is below N2_GATE is off (its parameters zeroed). The modules active this
 * block are those on in the previous block (Q, still fading) or wanted now (P); their cost must stay within
 * N2_BUDGET. Newcomers are admitted largest first while they fit; a newcomer that does not fit but is larger than
 * the smallest running module fades that one out (P = 0) so it can enter in a later block. On the first block there
 * is no fade: the largest modules that fit are kept. Costs are per voice in units of 100 cycles (bcore, cold). */
enum { M_CUT, M_FM, M_UNI, M_NOI, M_DRV, M_SYN, M_SUB, M_CFB, NMOD };
#ifndef N2_GATE
#define N2_GATE 64
#endif
#ifndef N2_BUDGET
#define N2_BUDGET 140                                /* 134 + the filter's 6: every trained combination still fits */
#endif
static const int16_t n2_mcost[NMOD] = { 41, 49, 53, 33, 39, 11, 18, 66 };   /* comb 66: its zero-fill after note on */   /* bcore 2026-11-13, tuned asm kernels */
static const uint8_t n2_mp[NMOD][2] = { {CUT, RES}, {FMA, FMB}, {UNI, UNI}, {NOI, NOI}, {DRV, DRV}, {SYN, SYN}, {SUB, SUB}, {CFB, CFB} };
static inline int32_t n2_amount(const int16_t *p, int m)
{
    int32_t a = m == M_CUT ? 4096 - p[CUT] : p[n2_mp[m][0]], b = p[n2_mp[m][1]];
    return a > b ? a : b;
}
static inline void n2_mod_off(int16_t *p, int m)
{
    if (m == M_CUT) { p[CUT] = 4096; p[RES] = 0; } else { p[n2_mp[m][0]] = 0; p[n2_mp[m][1]] = 0; }
}
static void n2_guard(struct nosc2_voice *v, int first)
{
    int16_t *P = v->prm; const int16_t *Q = v->prmp;
    if (P[BLP] < N2_GATE) P[BLP] = 0;                                   /* no pitch offset below the gate */
    int32_t ap[NMOD], cost = 0, nc = 0; uint8_t run[NMOD], cand[NMOD];
    for (int m = 0; m < NMOD; m++) {
        ap[m] = n2_amount(P, m);
        if (ap[m] < N2_GATE) { if (ap[m]) n2_mod_off(P, m); ap[m] = 0; }
        run[m] = !first && n2_amount(Q, m) != 0;
        if (run[m]) cost += n2_mcost[m];
        else if (ap[m]) {                                                  /* newcomer: insert, largest first */
            int j = nc++;
            while (j > 0 && ap[cand[j - 1]] < ap[m]) { cand[j] = cand[j - 1]; j--; }
            cand[j] = (uint8_t)m;
        }
    }
    int faded = 0;
    for (int i = 0; i < nc; i++) {
        int m = cand[i];
        if (cost + n2_mcost[m] <= N2_BUDGET) { run[m] = 1; cost += n2_mcost[m]; continue; }
        if (!faded) {                                                      /* fade the smallest runner if smaller */
            int low = -1;
            for (int k = 0; k < NMOD; k++) if (run[k] && ap[k] && (low < 0 || ap[k] < ap[low])) low = k;
            if (low >= 0 && ap[low] < ap[m]) { n2_mod_off(P, low); ap[low] = 0; }
            faded = 1;
        }
        n2_mod_off(P, m);                                                  /* the newcomer waits */
    }
}
static void nosc2_dsp(struct nosc2_voice *v, int first, int16_t *out, int hold)
{
    const int16_t *P = v->prm;
    n2_guard(v, first);
    {   /* live load (owner 2026-11-14): the modules this block leaves on, which the next block runs at least; every
         * block, so nosc2_env_step's tick deferral sees the voices' current settings, not their note-on ones */
        int32_t ld = 0; for (int m = 0; m < NMOD; m++) if (n2_amount(P, m)) ld += n2_mcost[m];
        v->load = ld;
    }
    const uint32_t inc1 = n2_inc_of(v->inc, P[BLP]);
    const uint32_t inc2 = n2_inc2_of(inc1, P[DET]);
    int32_t a1, a2, a3; n2_svf_q15(P[CUT], P[RES], &a1, &a2, &a3);
    /* the first block starts every ramp at its end value; the crossfade's old table is the new one (no copy) */
    if (hold) v->tn = v->tab;
    const int16_t *tabp = (first || hold) ? v->tn : v->tab;   /* hold: the same table again, no crossfade */
    if (first) {
        for (int j = 0; j < NP; j++) v->prmp[j] = v->prm[j];
        v->a1p = a1; v->a2p = a2; v->a3p = a3; v->incp = inc1; v->wp2 = (int32_t)inc2;
    }
    const int16_t *Q = v->prmp;
#define ON(j) (((N2_MASK >> (j)) & 1) && (Q[j] | P[j]))
    const int32_t dinc = ((int32_t)(inc1 - v->incp)) >> 7;
    N2_T(0);
    int fm = ON(FMA) || ON(FMB);
    static int16_t fmo[BLK];
    if (fm) {
        n2_touch16(fmo, BLK);
        uint32_t dep = (v->ramped & 1) ? v->fmdep : ((uint32_t)(Q[FMB] << 2) << 16) | (uint32_t)(Q[FMA] << 2);
        int32_t da0 = (int16_t)dep, db0 = (int16_t)(dep >> 16);
        uint32_t stp = ((uint32_t)(uint16_t)(((P[FMB] << 2) - db0 + 64) >> 7) << 16) | (uint16_t)(((P[FMA] << 2) - da0 + 64) >> 7);
        struct n2k_fm a = { fmo, n2_sin, v->pha, v->phb, v->incp, dinc, v->incp * 3 + (v->incp >> 1), dinc * 3 + (dinc >> 1), dep, stp };
        N2K_fm(&a); v->pha = a.pha; v->phb = a.phb; v->fmdep = a.dep; v->ramped |= 1;
    } else { uint32_t s = v->incp * BLK + (uint32_t)dinc * (BLK * (BLK + 1) / 2); v->pha += s; v->phb += s * 3 + (s >> 1); v->ramped &= ~1u; }
    {
        int32_t s0 = (v->ramped & 2) ? (int32_t)v->synr : 4096 + 3 * Q[SYN];
        struct n2k_osc a = { v->tn, tabp, fmo, out, v->ph, v->incp, dinc, s0, (4096 + 3 * P[SYN] - s0 + 64) >> 7,
                             (ON(SYN) ? N2K_SYNC : 0) | (fm ? N2K_FM : 0) };
        N2K_osc(&a); v->ph = a.ph;
        if (ON(SYN)) { v->synr = (uint32_t)a.r; v->ramped |= 2; } else v->ramped &= ~2u;
    }
    N2_T(1);
    if (ON(UNI)) {
        struct n2k_osc a = { v->tn, tabp, fmo, out, v->ph2, (uint32_t)v->wp2, ((int32_t)(inc2 - (uint32_t)v->wp2)) >> 7,
                             Q[UNI] << 7, P[UNI] - Q[UNI], N2K_ACC | N2K_W };
        N2K_osc(&a); v->ph2 = a.ph;
    } else v->ph2 += (uint32_t)v->wp2 * BLK + (uint32_t)(((int32_t)(inc2 - (uint32_t)v->wp2)) >> 7) * (BLK * (BLK + 1) / 2);
    if (v->tn != v->tab) {                           /* the new table becomes the voice's (the next block's old one) */
        n2_touch16(v->tab, TL + 2);                  /* a low note reads only a line or two of it */
        const uint32_t *s_ = (const uint32_t *)v->tn; uint32_t *d_ = (uint32_t *)v->tab;
        for (int i = 0; i < (TL + 2) / 2; i++) d_[i] = s_[i];
    }
    N2_T(2);
    {
        int fl = (ON(SUB) ? 1 : 0) | (ON(NOI) ? 2 : 0);
        struct n2k_sn a = { out, v->phs, v->incp, dinc, Q[SUB] << 7, P[SUB] - Q[SUB], v->rng, v->nlp, 40 + ((P[NCO] * 4056) >> 12),
                            Q[NOI] << 7, P[NOI] - Q[NOI], fl };
        if (!v->rng) a.rng = 0x9E3779B9u;
        if (fl) { N2K_sn(&a); v->phs = a.phs; v->rng = a.rng; v->nlp = a.nlp; }
        else v->phs += (v->incp * BLK + (uint32_t)dinc * (BLK * (BLK + 1) / 2)) >> 1;
    }
    N2_T(3);
    if (ON(DRV)) {
        int32_t g0 = n2_lut65(n2_dgain, Q[DRV]) >> 4, g1 = n2_lut65(n2_dgain, P[DRV]) >> 4;
        int32_t m0 = n2_lut65(n2_dmake, Q[DRV]), m1 = n2_lut65(n2_dmake, P[DRV]);
        struct n2k_drv a = { out, n2_tanh, g0 << 7, g1 - g0, m0 << 7, m1 - m0 };
        N2K_drv(&a);
    }
    N2_T(4);
    if (((N2_MASK >> CUT) & 1) && !(Q[CUT] >= 4096 && P[CUT] >= 4096 && !Q[RES] && !P[RES])) {
        struct n2k_svf a = { out, v->ic1, v->ic2, v->a1p * 65536, v->a2p * 65536, v->a3p * 65536, (a1 - v->a1p) * 512, (a2 - v->a2p) * 512, (a3 - v->a3p) * 512 };
        N2K_svf(&a); v->ic1 = a.s1; v->ic2 = a.s2;                       /* the ramps end exactly on a1..a3 */
    } else v->ic1 = v->ic2 = 0;
    N2_T(5);
    const int comb = ON(CFB);
    if (comb) { struct n2k_dc a = { out, v->dcz }; N2K_dc(&a); v->dcz = a.z; }
    N2_T(6);
    if (comb) {
        const int32_t cfb = (P[CFB] * 3973) >> 12, dd = ((4096 - P[CDA]) * 2048) >> 12;
        uint32_t d = inc1 >> 8, L8 = d ? 0xFFFFFFFFu / d : 0;
        if (L8 < 3 << 8) L8 = 3 << 8;
        if (L8 > ((COMB_N - 4) << 8)) L8 = (COMB_N - 4) << 8;
        uint32_t Lc = (L8 + 255) >> 8;
        if (v->cfill <= Lc + 1) {                    /* zero what this block reads that this note has not written: */
            uint32_t n = Lc + 1 - v->cfill;          /* ages Lc + 1 down to cfill + 1, a run of n samples */
            if (n > BLK + 3) n = BLK + 3;
            uint32_t i0 = (v->cw - (Lc + 1)) & (COMB_N - 1);
            uint32_t n1 = COMB_N - i0 < n ? COMB_N - i0 : n;
            n2_zero16(v->comb + i0, n1);
            n2_zero16(v->comb, n - n1);
        }
        {   /* the block's writes: cw .. cw + BLK - 1, wrapping */
            uint32_t w0 = v->cw & (COMB_N - 1), n1 = COMB_N - w0 < BLK ? COMB_N - w0 : BLK;
            n2_touch16(v->comb + w0, n1); n2_touch16(v->comb, BLK - n1);
        }
        struct n2k_comb a = { out, v->comb, v->cw, L8, 0, 0, 0, 0, 4096 - ((cfb * 4014) >> 12) };
        n2k_comb_taps(&a, dd >> 1, 4096 - dd, cfb);
        N2K_comb(&a); v->cw = a.w;
        if (v->cfill < COMB_N) v->cfill += BLK;
    }
    N2_T(7);
    {
        int32_t g0 = n2_gain_of(Q[LVL], Q[UNI]), g1 = n2_gain_of(P[LVL], P[UNI]);
        if (comb) { struct n2k_lvl a = { out, out, g0 << 7, g1 - g0 }; N2K_lvl(&a); }
        else { struct n2k_dcl a = { out, out, v->dcz, g0 << 7, g1 - g0 }; N2K_dcl(&a); v->dcz = a.z; }
    }
    N2_T(8);
    v->a1p = a1; v->a2p = a2; v->a3p = a3;
    v->incp = inc1; v->wp2 = (int32_t)inc2;
    for (int j = 0; j < NP; j++) v->prmp[j] = v->prm[j];
    N2_T(9);
}
#ifndef NOSC_MV
static void nosc_mv_c(const int16_t *w, const int16_t *x, int32_t *o, int rows, int cols)
{
    for (int r = 0; r < rows; r++) { int32_t a = 0; for (int c = 0; c < cols; c++) a += w[r * cols + c] * x[c]; o[r] = a; }
}
#define NOSC_MV nosc_mv_c
#endif
#ifndef NOSC_BLEND
static void nosc_blend_c(const int16_t *c, const int16_t *basis, int16_t *tab)
{
    for (int i = 0; i < TL; i++) {
        int64_t a = 0;
        for (int b = 0; b < NB; b++) a += (int32_t)c[b] * basis[b * TL + i];
        a >>= 12;
        tab[i] = (int16_t)(a > 32767 ? 32767 : a < -32768 ? -32768 : a);
    }
}
#define NOSC_BLEND nosc_blend_c
#endif
static void n2_finish(const int32_t *acc, const int16_t *b, int16_t *y, int rows, int relu)
{
    for (int r = 0; r < rows; r++) {
        int32_t a = (acc[r] + ((int32_t)b[r] << 12)) >> 12;
        if (relu && a < 0) a = 0;
        y[r] = n2_sat16(a);
    }
}
/* one block: the net (table + params from pitch, velocity, time, knobs) then the DSP voice */
/* L == 0: no L1 lease this block (another engine holds it, or the pool is off). The net's weights would come from
 * SDRAM, which costs more than the slot has, so the voice holds its last table and parameters for the block. */
#ifdef N2_ENVCYC
uint32_t n2_envcyc, n2_envruns;
#endif
/* part of one run of the envelope head: about 1 / N2_NSL of its multiplies, whole rows; z = the knobs (Q12) */
#define N2_RUNMAC (NEH * NEI + NEH * NEH + NFO * NEH)
static void nosc2_env_tick(const struct nosc2_far *F, struct nosc2_envnet *G, const int16_t *z)
{
#ifdef N2_ENVCYC
    uint32_t ec0; __asm__ volatile ("%0 = CYCLES;" : "=d"(ec0)); n2_envruns++;
#endif
    int32_t budget = (N2_RUNMAC + N2_NSL - 1) / N2_NSL;
    if (G->lay == 0 && G->row == 0) {
        for (int j = 0; j < 4; j++) G->ein[j] = z[j];
        G->ein[4] = G->ein[5] = G->ein[6] = G->ein[7] = 0;
    }
    while (budget > 0) {
        const int rows = G->lay == 2 ? NFO : NEH, cols = G->lay == 0 ? NEI : NEH;
        int n = (budget + cols - 1) / cols; if (n > rows - G->row) n = rows - G->row;
        const int r0 = G->row;
        n2_touch16((G->lay == 0 ? G->e1 : G->lay == 1 ? G->e2 : G->eo) + r0, (uint32_t)n);
        if (G->lay == 0) { struct n2k_layer a = { F->ew1 + r0 * NEI, F->eb1 + r0, G->ein, G->e1 + r0, n, NEI, 1 }; N2K_layer(&a); }
        else if (G->lay == 1) { struct n2k_layer a = { F->ew2 + r0 * NEH, F->eb2 + r0, G->e1, G->e2 + r0, n, NEH, 1 }; N2K_layer(&a); }
        else { struct n2k_layer a = { F->ew3 + r0 * NEH, F->eb3 + r0, G->e2, G->eo + r0, n, NEH, 0 }; N2K_layer(&a); }
        budget -= n * cols; G->row += n;
        if (G->row == rows) {
            G->row = 0;
            if (++G->lay == 3) {
                G->lay = 0;
                n2_touch16(G->c, NFO);
                for (int j = 0; j < NFO; j++) G->c[j] = G->eo[j];
                G->gen++;
                break;
            }
        }
    }
#ifdef N2_ENVCYC
    { uint32_t ec1; __asm__ volatile ("%0 = CYCLES;" : "=d"(ec1)); n2_envcyc += ec1 - ec0; }
#endif
}
/* a whole run at once (start-up, or a preset load) */
static void nosc2_env_fill(const struct nosc2_far *F, struct nosc2_envnet *G, const int16_t *z)
{
    G->lay = 0; G->row = 0;
    uint32_t g = G->gen;
    while (G->gen == g) nosc2_env_tick(F, G, z);
}
/* the voice's settings from the committed coefficients, at note on and after each commit */
static const uint8_t n2_dyn[N2_NDYN] = { E_CUT0, E_CUT1, E_CUTT, E_FMA0, E_FMA1, E_FMAT, E_FMB0, E_FMB1, E_FMBT, E_NOI0, E_NOI1, E_NOIT,
                                          E_SYN0, E_SYN1, E_SYNT, E_BLP, E_BLPT };
static const uint8_t n2_sta[N2_NSTA] = { E_RES, E_UNI, E_DET, E_NCO, E_DRV, E_SUB, E_CFB, E_CDA, E_LVL };
#ifndef N2_ADOPT
#define N2_ADOPT 2                                   /* sounding voices that take a commit in one block (the rest follow
                                                      * in the next blocks: the module changes it brings are spread) */
#endif
static void n2_env_interp(struct nosc2_envnet *G, struct nosc2_voice *v)
{
    if (v->age) {
        if (v->egen == G->gen || !G->adopt) return;
        G->adopt--;
    }
    v->egen = G->gen;
    n2_touch16(v->env, NE);
    const int32_t p = v->in[0] < 0 ? 0 : v->in[0] > 4096 ? 4096 : v->in[0], q = v->in[1] < 0 ? 0 : v->in[1] > 4096 ? 4096 : v->in[1];
    const int32_t u = 2 * p - 4096, w = 2 * q - 4096;                   /* Q12, -1 .. 1 */
    const int32_t f1 = u, f2 = w, f3 = (u * w) >> 12, f4 = (u * u) >> 12, f5 = (w * w) >> 12;
    const int16_t *c = G->c;
    for (int k = 0; k < N2_NDYN; k++, c += 6)
        v->env[n2_dyn[k]] = n2_sat16((c[0] * 4096 + c[1] * f1 + c[2] * f2 + c[3] * f3 + c[4] * f4 + c[5] * f5 + 2048) >> 12);
    for (int k = 0; k < N2_NSTA; k++) v->env[n2_sta[k]] = c[k];
}
/* the engine's per-block step for the envelope head: its part runs only when the voices' running modules (each
 * voice's load: the guard's costs of the modules its last block left on, kept live every block) leave room for it;
 * in the heaviest blocks it waits, but never more than N2_WAIT_MAX blocks in a row (the tables still follow the
 * knobs at once). vs: the sounding voices. */
#ifndef N2_TICK_LOAD
#define N2_TICK_LOAD (6 * N2_BUDGET - N2_BUDGET)
#endif
#ifndef N2_WAIT_MAX
#define N2_WAIT_MAX 1                                /* the tick waits at most this many blocks in a row: a run of
                                                      * N2_NSL slices commits within N2_NSL x (N2_WAIT_MAX + 1) blocks */
#endif
static int nosc2_env_step(const struct nosc2_far *F, struct nosc2_envnet *G, const int16_t *z, struct nosc2_voice *const *vs, int n)
{
    int32_t load = 0;
    for (int i = 0; i < n; i++) {
        load += vs[i]->age ? vs[i]->load : N2_BUDGET;                    /* a new note: its modules are not known yet */
    }
    G->adopt = N2_ADOPT;
    if (load > N2_TICK_LOAD && G->wait < N2_WAIT_MAX) { G->wait++; return 0; }
    G->wait = 0;
    nosc2_env_tick(F, G, z);
    return 1;
}
static void nosc2_render(const struct nosc2_l1 *L, struct nosc2_envnet *G, struct nosc2_voice *v, int16_t *out)
{
    if (!L && v->age) { nosc2_dsp(v, 0, out, 1); v->age++; return; }
    int32_t acc[NH];
    int16_t h1[NH] __attribute__((aligned(4))), h2[NH] __attribute__((aligned(4))), c[NB], pr[NE];
    N2_T(10);
    uint32_t ti = v->age < 64 ? v->age : 64 + ((v->age - 64) >> 3);
    v->in[2] = nosc2_tau[ti < NTAU2 ? ti : NTAU2 - 1];
    { struct n2k_layer a = { L->w1, L->b1, v->in, h1, NH, NI, 1 }; N2K_layer(&a); }
    { struct n2k_layer a = { L->w2, L->b2, h1, h2, NH, NH, 1 }; N2K_layer(&a); }
    { struct n2k_layer a = { L->w3, L->b3, h2, c, NB, NH, 0 }; N2K_layer(&a); }
    N2_T(13);
    (void)acc;
    n2_env_interp(G, v);
    (void)pr;
    n2_env_eval(v);
#ifdef N2_PRM_HOOK
    N2_PRM_HOOK(v);
#endif
    N2_T(11);
    int16_t *tmp = (int16_t *)L->tmp;                /* the lease is the plugin's: its scratch is writable */
    NOSC_BLEND(c, &L->basis[0][0], tmp);
    tmp[TL] = tmp[0]; v->tn = tmp;
    N2_T(12);
    nosc2_dsp(v, v->age == 0, out, 0);
    v->age++;
}
