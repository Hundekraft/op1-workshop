/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
/* nosc2 per-sample kernels: the C here is the spec, written in the arithmetic the Blackfin has natively (16 x 16
 * multiplies into 32/40-bit sums, arithmetic shifts, saturating 16-bit results), so nosc2_kern.S matches it bit for
 * bit. All buffers are int16 in "Q13" (full scale / 4: +-4 x headroom). Argument structs: every field 4 bytes, the
 * asm reads them by offset (listed). */
#include <stdint.h>
#ifndef N2K_BLK
#define N2K_BLK 128
#endif
static inline int16_t n2k_sat(int32_t a) { return (int16_t)(a > 32767 ? 32767 : a < -32768 ? -32768 : a); }

/* oscillator read: crossfaded (old -> new table over the block), linear-interpolated, optional sync / FM offsets /
 * weight, write or accumulate. Offsets: tn 0, to 4, fm 8, buf 12, ph 16, inc 20, dinc 24, r 28, d 32, flags 36 */
#define N2K_ACC 1
#define N2K_SYNC 2
#define N2K_FM 4
#define N2K_W 8
struct n2k_osc { const int16_t *tn, *to, *fm; int16_t *buf; uint32_t ph, inc; int32_t dinc, r, d, flags; };
static void n2k_osc_c(struct n2k_osc *a)
{
    uint32_t ph = a->ph, inc = a->inc; int32_t r = a->r;
    const int fl = a->flags;
    for (int i = 0; i < N2K_BLK; i++) {
        inc += (uint32_t)a->dinc;
        uint32_t rd = ph;
        if (fl & N2K_SYNC) { r += a->d; rd = ((ph >> 16) * (uint32_t)r) << 4; }   /* r: ratio Q12 */
        if (fl & N2K_FM) rd += (uint32_t)(int32_t)a->fm[i] << 17;
        uint32_t k = rd >> 25; int32_t f = (rd >> 10) & 0x7fff, g = 32767 - f;
        int32_t so = (a->to[k] * g + a->to[k + 1] * f) >> 15;
        int32_t sn = (a->tn[k] * g + a->tn[k + 1] * f) >> 15;
        int32_t xw = ((i + 1) << 8) - 1;
        int32_t s = (so * (32767 - xw) + sn * xw) >> 15;
        int32_t y;
        if (fl & N2K_W) { r += a->d; y = (s * (r >> 7)) >> 14; } else y = s >> 2;
        a->buf[i] = (fl & N2K_ACC) ? n2k_sat(a->buf[i] + y) : (int16_t)y;
        ph += inc;
    }
    a->ph = ph; a->inc = inc; a->r = r;
}

/* FM offsets: two sine modulators (1 x and 3.5 x the pitch). Depths Q14 (Q12 << 2) as two int16 ramped by int16
 * steps (wrapping adds, as the asm's vector add); out = offset / 2^17 of a cycle. The 3.5 x phase has its own step
 * inc35 (ramped by dinc35). Offsets: out 0, sin 4, pha 8, phb 12, inc 16, dinc 20, inc35 24, dinc35 28,
 * dep 32 (b << 16 | a), step 36 (sb << 16 | sa) */
struct n2k_fm { int16_t *out; const int16_t *sin; uint32_t pha, phb, inc; int32_t dinc; uint32_t inc35; int32_t dinc35; uint32_t dep, step; };
static void n2k_fm_c(struct n2k_fm *a)
{
    uint32_t pa = a->pha, pb = a->phb, inc = a->inc, i35 = a->inc35;
    int16_t da = (int16_t)a->dep, db = (int16_t)(a->dep >> 16);
    const int16_t sa = (int16_t)a->step, sb = (int16_t)(a->step >> 16);
    for (int i = 0; i < N2K_BLK; i++) {
        inc += (uint32_t)a->dinc; i35 += (uint32_t)a->dinc35;
        da = (int16_t)(da + sa); db = (int16_t)(db + sb);
        int32_t m = (a->sin[pa >> 22] * da + a->sin[pb >> 22] * db) >> 15;
        a->out[i] = n2k_sat(m);
        pa += inc; pb += i35;
    }
    a->pha = pa; a->phb = pb; a->inc = inc; a->inc35 = i35;
    a->dep = ((uint32_t)(uint16_t)db << 16) | (uint16_t)da;
}

/* sub (square an octave down) and noise (xorshift, one-pole colour), added. Offsets: buf 0, phs 4, inc 8, dinc 12,
 * rs 16, ds 20, rng 24, nlp 28, nco 32, rn 36, dn 40, flags 44 (1 sub, 2 noise) */
struct n2k_sn { int16_t *buf; uint32_t phs, inc; int32_t dinc, rs, ds; uint32_t rng; int32_t nlp, nco, rn, dn, flags; };
static void n2k_sn_c(struct n2k_sn *a)
{
    uint32_t phs = a->phs, inc = a->inc, rng = a->rng; int32_t rs = a->rs, rn = a->rn, nlp = a->nlp;
    for (int i = 0; i < N2K_BLK; i++) {
        inc += (uint32_t)a->dinc;
        int32_t x = a->buf[i];
        if (a->flags & 1) { rs += a->ds; x = n2k_sat(x + ((phs & 0x80000000u) ? (rs >> 7) : -(rs >> 7))); }
        if (a->flags & 2) {
            rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
            nlp += (a->nco * (int16_t)(rng >> 16) - a->nco * nlp) >> 12;
            rn += a->dn; x += (nlp * (rn >> 7)) >> 14;
        }
        a->buf[i] = n2k_sat(x);
        phs += inc >> 1;
    }
    a->phs = phs; a->inc = inc; a->rng = rng; a->rs = rs; a->rn = rn; a->nlp = nlp;
}

/* drive: u = x x gain (Q13 in, clamp to the table's +-4), tanh table (1025, Q15, step 1/128) interpolated, makeup.
 * Offsets: buf 0, tanh 4, rg 8, dg 12, rm 16, dm 20 (gain Q12 >> 4 = Q8, makeup Q12, both << 7 ramps) */
struct n2k_drv { int16_t *buf; const int16_t *tanh; int32_t rg, dg, rm, dm; };
static void n2k_drv_c(struct n2k_drv *a)
{
    int32_t rg = a->rg, rm = a->rm;
    for (int i = 0; i < N2K_BLK; i++) {
        rg += a->dg; rm += a->dm;
        int32_t u = (a->buf[i] * (rg >> 7)) >> 6;                      /* Q13 x Q8 -> Q15 */
        u = u > 131071 ? 131071 : u < -131072 ? -131072 : u;
        int32_t ti = (u + 131072) >> 8, tf = (u + 131072) & 255;
        int32_t t = (a->tanh[ti] * (256 - tf) + a->tanh[ti + 1] * tf) >> 8;
        a->buf[i] = n2k_sat((t * (rm >> 7)) >> 14);                    /* Q15 x Q12 >> 14 -> Q13 */
    }
    a->rg = rg; a->rm = rm;
}

/* TPT state-variable low-pass in Q13 with Q15 coefficients, each ramped exactly across the block in a 32-bit
 * accumulator (c = Q15 << 16, + d a sample, d = (end - start) << 9), so a coefficient is c's high half (c >> 16) and
 * ends on its target.
 * Offsets: buf 0, s1 4, s2 8, c1 12, c2 16, c3 20, d1 24, d2 28, d3 32 */
struct n2k_svf { int16_t *buf; int32_t s1, s2, c1, c2, c3, d1, d2, d3; };
static void n2k_svf_c(struct n2k_svf *a)
{
    int32_t s1 = a->s1, s2 = a->s2, c1 = a->c1, c2 = a->c2, c3 = a->c3;
    for (int i = 0; i < N2K_BLK; i++) {
        c1 += a->d1; c2 += a->d2; c3 += a->d3;
        int32_t a1 = c1 >> 16, a2 = c2 >> 16, a3 = c3 >> 16;
        int32_t v3 = n2k_sat(a->buf[i] - s2);
        int32_t v1 = (a1 * s1 + a2 * v3 + 16384) >> 15;
        int32_t v2 = s2 + ((a2 * s1 + a3 * v3 + 16384) >> 15);
        s1 = n2k_sat(2 * v1 - s1); s2 = n2k_sat(2 * v2 - s2);
        a->buf[i] = n2k_sat(v2);
    }
    a->s1 = s1; a->s2 = s2; a->c1 = c1; a->c2 = c2; a->c3 = c3;
}

/* DC blocker (one pole at ~27 Hz), in place. Offsets: buf 0, z 4 */
struct n2k_dc { int16_t *buf; int32_t z; };
static void n2k_dc_c(struct n2k_dc *a)
{
    int32_t z = a->z;
    for (int i = 0; i < N2K_BLK; i++) { int32_t y = a->buf[i]; z += y - (z >> 9); a->buf[i] = n2k_sat(y - (z >> 9)); }
    a->z = z;
}

/* comb tuned to the pitch: line (Q13, 2048, circular). Per block the damping filter [dh, dc, dh], the fractional
 * read and the feedback gain fold into four taps k0..k3 (Q12) on line[ix - 1 .. ix + 2]:
 * y = sat16((buf cin + k0 c0 + k1 c1 + k2 c2 + k3 c3) >> 12). Offsets: buf 0, line 4, w 8, L8 12, k0 16, k1 20,
 * k2 24, k3 28, cin 32 */
#define N2K_COMB 2048
struct n2k_comb { int16_t *buf; int16_t *line; uint32_t w, L8; int32_t k0, k1, k2, k3, cin; };
static void n2k_comb_taps(struct n2k_comb *a, int32_t dh, int32_t dc, int32_t cfb)
{
    uint32_t Lc = (a->L8 + 255) >> 8; int32_t fr = (int32_t)((Lc << 8) - a->L8), gr = 256 - fr;
    a->k0 = (((dh * gr) >> 8) * cfb) >> 12;                    /* each (Q12 x Q8) >> 8 <= 4096, x cfb (Q12) >> 12 */
    a->k1 = (((dc * gr + dh * fr) >> 8) * cfb) >> 12;
    a->k2 = (((dh * gr + dc * fr) >> 8) * cfb) >> 12;
    a->k3 = (((dh * fr) >> 8) * cfb) >> 12;
}
static void n2k_comb_c(struct n2k_comb *a)
{
    const uint32_t M = N2K_COMB - 1; uint32_t w = a->w; int16_t *cb = a->line;
    for (int i = 0; i < N2K_BLK; i++) {
        uint32_t ix = (((w << 8) - a->L8) >> 8) & M;
        int32_t s = a->buf[i] * a->cin + a->k0 * cb[(ix - 1) & M] + a->k1 * cb[ix] + a->k2 * cb[(ix + 1) & M] + a->k3 * cb[(ix + 2) & M];
        int16_t y = n2k_sat(s >> 12);
        cb[w] = y; a->buf[i] = y; w = (w + 1) & M;
    }
    a->w = w;
}

/* level: out = buf x gain (Q12, ramped) >> 9 (Q13 -> Q15 with -6 dB headroom: x 4 / 2 = >> 11 + 2). Offsets:
 * buf 0, out 4, r 8, d 12 */
struct n2k_lvl { const int16_t *buf; int16_t *out; int32_t r, d; };
static void n2k_lvl_c(struct n2k_lvl *a)
{
    int32_t r = a->r;
    for (int i = 0; i < N2K_BLK; i++) { r += a->d; a->out[i] = n2k_sat((a->buf[i] * (r >> 7)) >> 11); }
    a->r = r;
}

/* DC blocker and level in one pass (when the comb is off they are adjacent): same result as n2k_dc then n2k_lvl.
 * Offsets: buf 0, out 4, z 8, r 12, d 16 */
struct n2k_dcl { const int16_t *buf; int16_t *out; int32_t z, r, d; };
static void n2k_dcl_c(struct n2k_dcl *a)
{
    int32_t z = a->z, r = a->r;
    for (int i = 0; i < N2K_BLK; i++) {
        int32_t y = a->buf[i]; z += y - (z >> 9);
        int32_t y2 = n2k_sat(y - (z >> 9));
        r += a->d; a->out[i] = n2k_sat((y2 * (r >> 7)) >> 11);
    }
    a->z = z; a->r = r;
}

/* one net layer: y = sat16(relu?((W x >> 12) + b)); W rows x cols, cols even >= 4. Offsets: w 0, b 4, x 8, y 12,
 * rows 16, cols 20, relu 24 */
struct n2k_layer { const int16_t *w, *b, *x; int16_t *y; int32_t rows, cols, relu; };
static void n2k_layer_c(struct n2k_layer *a)
{
    for (int r = 0; r < a->rows; r++) {
        int32_t s = 0;
        for (int c = 0; c < a->cols; c++) s += a->w[r * a->cols + c] * a->x[c];
        int32_t y = (s >> 12) + a->b[r];
        if (a->relu && y < 0) y = 0;
        a->y[r] = n2k_sat(y);
    }
}
