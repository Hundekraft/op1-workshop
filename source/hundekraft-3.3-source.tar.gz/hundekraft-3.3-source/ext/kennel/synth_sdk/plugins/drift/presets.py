#!/usr/bin/env python3
"""drift's 27 presets (written to presets/ next to this file, or the folder given): the model's anchor patches.

    python3 presets.py [out_dir]

Each preset's four knobs are its anchor's latent position (anchors.json "z"): per knob the word whose z through
drift.c's lt_zof (knob_law.json, knob_law.py's zof_q12) is nearest to the z the preset had under the rc10 law
(Phi^-1(0.005 + 0.99 k) through a 257-point table, at the word nearest the anchor's z; |z| > 2.576 clipped to the end
of the knob), so every preset keeps its sound (drift_test checks it). OLD_* go once the presets are tuned again. Word 4 is 0x5300 (the sound finds the engine by its saved name, "drift"); words 5 and 6 are 0 (no page 2); word 7 is
the hidden level trim (op1_preset_trim, Q13, 0 = 1x): TRIM below, in dB (owner 2026-11-14, from the volume pass's
loudness measurements), the others 0.
T2 (adsr) is the amp: words picked by hand from the anchor's training envelope (ENV, seconds), a coarse map, to be
tuned by ear. No LFO, no FX.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json, math, struct, sys
from pathlib import Path
from statistics import NormalDist

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from knob_law import word_of  # noqa: E402

LAW = json.loads((HERE / 'knob_law.json').read_text())['zq12']
SEL = 0x5300
# the anchors' training envelopes (attack, decay, sustain, release; seconds and level), in anchors.json's order
ENV = {
    'pluck saw': (0.002, 0.6, 0.3, 0.25), 'ep tine': (0.002, 1.5, 0.5, 0.35), 'organ': (0.004, 0.1, 1.0, 0.06),
    'clav': (0.001, 0.4, 0.35, 0.08), 'harp': (0.001, 2.5, 0.0, 0.6), 'marimba': (0.001, 0.8, 0.0, 0.3),
    'swell pad': (0.35, 1.0, 0.9, 1.0), 'pwm strings': (0.25, 1.0, 0.9, 0.8), 'glass pad': (0.4, 1.0, 0.9, 1.2),
    'choir': (0.3, 1.0, 0.9, 0.9), 'sync lead': (0.003, 0.5, 0.8, 0.2), 'square lead': (0.004, 0.4, 0.8, 0.15),
    'acid': (0.002, 0.3, 0.6, 0.1), 'brass': (0.03, 0.6, 0.8, 0.2), 'fm growl': (0.005, 0.5, 0.8, 0.2),
    'reso bass': (0.002, 0.4, 0.5, 0.12), 'sub bass': (0.004, 0.5, 0.8, 0.1), 'fm bass': (0.002, 0.5, 0.6, 0.1),
    'pluck bass': (0.001, 0.8, 0.0, 0.2), 'tom drop': (0.001, 0.5, 0.0, 0.2), 'tubular bell': (0.001, 3.0, 0.0, 1.5),
    'metal': (0.001, 3.0, 0.0, 1.5), 'kalimba': (0.001, 1.2, 0.0, 0.4), 'violin': (0.06, 1.0, 0.9, 0.3),
    'flute': (0.05, 1.0, 0.9, 0.25), 'clarinet': (0.04, 1.0, 0.9, 0.2), 'trumpet': (0.03, 1.0, 0.85, 0.2),
}
# the level trims (dB) -> word 7 = round(8192 x 10^(dB / 20)); presets not listed keep 0 (1x)
TRIM = {
    'pluck saw': 6.0, 'ep tine': 5.0, 'clav': 4.5, 'harp': 4.5, 'marimba': 6.0, 'square lead': 1.0, 'acid': 2.5,
    'brass': 0.5, 'fm growl': 0.5, 'reso bass': 5.5, 'sub bass': 2.5, 'fm bass': 4.5, 'pluck bass': 4.5,
    'tom drop': 6.0, 'tubular bell': 1.0, 'kalimba': 6.0,
}


def trim(name):
    return int(round(8192 * 10 ** (TRIM[name] / 20))) if name in TRIM else 0


def step(x, edges, words):
    for e, w in zip(edges, words):
        if x < e:
            return w
    return words[-1]


# R246 reads the release word inverted (rate table 0x7F - (v >> 7), audio-graph.md): HIGH release = SHORT. Release to
# -60 dB, measured on JUNI (word, seconds); release_word() interpolates log(seconds) between them, past the ends on the
# end slopes, and clamps to the factory range.
RELEASE_S = [(4800, 2.9), (6000, 2.1), (10400, 0.9), (13500, 0.4), (15000, 0.2)]


def release_word(t):
    p = RELEASE_S
    a, b = (p[0], p[1]) if t >= p[0][1] else (p[-2], p[-1]) if t <= p[-1][1] else \
        next((a, b) for a, b in zip(p, p[1:]) if b[1] <= t <= a[1])
    w = a[0] + (math.log(t) - math.log(a[1])) * (b[0] - a[0]) / (math.log(b[1]) - math.log(a[1]))
    return max(64, min(16320, int(round(w / 100.0)) * 100))


PADS = {'swell pad', 'pwm strings', 'glass pad', 'choir'}   # long role: release at least 1.4 s (word 8000 or lower)


def adsr(env, pad=False):
    a, d, s, r = env
    return [step(a, (0.01, 0.1, 0.3), (64, 1500, 6000, 9000)),
            step(d, (0.2, 0.7, 1.6), (3000, 6000, 9000, 12000)),
            min(32000, int(round(s * 32767))),
            min(release_word(r), 8000) if pad else release_word(r)]


ND = NormalDist()
OLD_ZINV = [int(round(ND.inv_cdf(0.005 + 0.99 * min(i * 128, 32768) / 32768) * 4096)) for i in range(257)]


def old_z(z):
    """z (Q12) under the rc10 law at the word it gave z"""
    k = int(round(min(1.0, max(0.0, (ND.cdf(z) - 0.005) / 0.99)) * 32767))
    i, f = k >> 7, k & 127
    return OLD_ZINV[i] + (((OLD_ZINV[i + 1] - OLD_ZINV[i]) * f) >> 7)


def knob(j, z):
    return word_of(LAW[j], old_z(z))


def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def aifc(meta):
    comm = struct.pack(">hIh", 1, 0, 16) + ieee_extended(44100) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    js = json.dumps(meta, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + chunk(b"APPL", b"op-1" + js)
            + chunk(b"SSND", struct.pack(">II", 0, 0)))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


def sounds():
    """(name, knobs[4], adsr[4], clipped) in anchors.json's order"""
    z = json.loads((HERE / 'anchors.json').read_text())['z']
    for name, zs in z.items():
        assert len(name) <= 15 and name == name.lower(), name
        yield name, [knob(j, x) for j, x in enumerate(zs)], adsr(ENV[name], name in PADS), [i for i, x in enumerate(zs) if abs(x) > 2.5758]


def main():
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / 'presets'
    out.mkdir(parents=True, exist_ok=True)
    n = 0
    for name, k, env, clip in sounds():
        meta = {'adsr': [*env, 2048, 5568, 4000, 4000], 'fx_active': False, 'fx_params': [8000, 8000, 8000, 8000, 0, 0, 0, 0],
                'fx_type': 'delay', 'knobs': [*k, SEL, 0, 0, trim(name)], 'lfo_active': False,
                'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': name, 'octave': 0,
                'synth_version': 2, 'type': 'drift'}
        (out / (name + '.aif')).write_bytes(aifc(meta))
        print(f'{name:13s} {k} adsr {env}' + (f' trim {trim(name)}' if trim(name) else '') + (f'  clipped knob {clip}' if clip else ''))
        n += 1
    print(f'{n} DRIFT presets in {out}')


if __name__ == '__main__':
    main()
