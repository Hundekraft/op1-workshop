#!/usr/bin/env python3
"""Compare source/raster boundaries after undoing the deliberate translation.
The configured 1.6px ink permits up to 0.8px boundary growth, plus contour
simplification; retain the source-art continuity bar of 99% within one pixel.
"""
import json,sys
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import binary_erosion,distance_transform_edt,shift
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[1]/'harness'));import oprender
source=Path(sys.argv[1]);a=np.asarray(Image.open(source).convert('RGB')).astype(float)
render=oprender.render({'svg':str(HERE/'c64arp.svg')},scale=1774/320,stock=False).array().astype(float)
# Undo the configured four-pixel screen translation for shape comparison.
render=shift(render,(4*1774/320,0,0),order=0,mode='constant')
palette=np.array([[243,244,245],[87,142,241],[1,240,188],[246,85,100]],float)
def masks(x):
 d=palette/np.linalg.norm(palette,axis=1)[:,None];u=x/np.maximum(np.linalg.norm(x,axis=2)[:,:,None],1)
 labels=np.argmax(np.einsum('...c,kc->...k',u,d),axis=2)
 return [(labels==i)&(np.einsum('...c,c->...',x,col)/sum(col*col)>.5) for i,col in enumerate(palette)]
report={}
for color,ref,test in zip(palette,masks(a),masks(render)):
 r=ref^binary_erosion(ref);t=test^binary_erosion(test)
 dt=distance_transform_edt(~r)[t]*320/1774;dr=distance_transform_edt(~t)[r]*320/1774
 def stats(v):return {'samples':len(v),'p95':float(np.percentile(v,95)),'within_1':float(np.mean(v<=1)),'within_half':float(np.mean(v<=.5))}
 report[str(color.tolist())]={'placement':stats(dt),'missing':stats(dr)}
# The bar is on the ink's shape, all colours together (2026-11-14): gen_svg.py gives each of the art's pale lines one
# colour along its length where the art's pixels flip between white and blue, so per-colour numbers are reported but
# measure that choice, not the trace.
ref=np.any(masks(a),axis=0);test=np.any(masks(render),axis=0)
r=ref^binary_erosion(ref);t=test^binary_erosion(test)
report['ink']={'placement':stats(distance_transform_edt(~r)[t]*320/1774),'missing':stats(distance_transform_edt(~t)[r]*320/1774)}
print(json.dumps(report,indent=2))
assert all(s['p95']<1.0 and s['within_1']>=.99 for s in report['ink'].values())
