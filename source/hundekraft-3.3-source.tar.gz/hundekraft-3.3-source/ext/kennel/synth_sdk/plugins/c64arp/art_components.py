#!/usr/bin/env python3
"""Line continuity check (owner 2026-11-14: "still weird gaps"): every connected piece of the art's white and blue
ink must come out as exactly one connected piece of the screen's white and blue strokes.

    python3 art_components.py [ART.png] [SVG]

The art's line mask is gen_svg.py's own (white+blue as one mask, LINE_INK, green/red and their edge left out). Each
art piece's centre-line pixels are looked up in the render of the SVG's white/blue strokes only (green/red fills
would join pieces that the strokes leave apart), at native size (400 x 200) and at 4x. A piece whose centre line
lands on more than one render piece is broken; one that lands on none is missing, and a run of its centre line
with no stroke ink under it (GAP_PX or longer) is a gap. Prints the failures with their
place in screen units and returns them.
"""
import re
import sys
from pathlib import Path

import numpy as np
from PIL import Image
from scipy import ndimage as nd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / 'harness'))
sys.path.insert(0, str(HERE.parents[1] / 'display'))
sys.path.insert(0, str(HERE))
import oprender   # noqa: E402
import gen_svg    # noqa: E402
from art_trace import thin   # noqa: E402

U = 1774 / 320
GAP_PX = 6        # art centre-line pixels (about 1 screen unit) with no stroke under them = a gap
REACH = 1.0       # v8 (2026-11-14, owner: lines on the 376 x 188 panels' pixel grid): 1.0, was 0.6. Snapping moves
                  # lines by up to half a pixel, the 21 x 12 px key grid drifts up to about 1.1 units from the fitted
                  # keys at the arm ends, and a few lines move 1-2 px to leave a black pixel between neighbours.
                  # v4 (2026-11-14): screen units beyond the render pixel's own neighbours that still count as "under"
                  # the stroke. The v4 lines are hand geometry, regularized onto the angle set and an exact key grid,
                  # so a line may sit up to about 1.5 units (half the width + this) from the art's wobbly centre line
                  # by design; a missing or broken line is further off than that.
LINE_COLOURS = ('#f3f4f5', '#578ef1')
# v4 deliberate differences (screen-unit boxes x0, y0, x1, y1): gaps whose centre falls inside are not failures.
EXEMPT = [
    (22.5, 68.5, 24.8, 70.0),     # the first chip leg is as long as the others (the art's is about 1.5 longer)
]

# v8 deliberate moves (screen-unit boxes): the art's centre line here lies within one render pixel of a neighbour the
# grid now keeps a black pixel clear of, so it is left out of the piece count (gaps are still checked).
MOVED = [
    (160.0, 68.0, 201.0, 93.0),   # the right arm's back edge, 2 px up from the art, clear of the last keys' tops
]


def find_art():
    for d in [HERE, *HERE.parents]:
        p = d / 'docs/design/c64/c64arp-art.png'
        if p.exists():
            return p
    return None


def art_pieces(art):
    a = np.asarray(Image.open(art).convert('RGB')).astype(float)
    m = gen_svg.line_mask(a, gen_svg.ink_labels(a))
    lab, n = nd.label(m, np.ones((3, 3)))
    return lab, n, thin(m)


def strokes_only(svg_text):
    keep = [e for e in re.findall(r'<(?:path|circle|line|polyline)[^>]*/>', svg_text)
            if any(f'stroke="{c}"' in e for c in LINE_COLOURS)]
    return '<svg xmlns="http://www.w3.org/2000/svg" width="320" height="160" viewBox="0 0 320 160">' + ''.join(keep) + '</svg>'


def inner_diamond(mask, s):
    ys, xs = np.nonzero(mask)
    cx, cy = xs.mean() / s, ys.mean() / s
    return np.ptp(xs) / s < 2 * gen_svg.KEY_IW + 2 and any(
        abs(cx - k[0]) < 1 and abs(cy - k[1] - gen_svg.KEY_IDY) < 1
        for k in (gen_svg.key_centre(n) for n, c in gen_svg.KEYS if c == 'blue'))


def chip_mark(mask, s):
    """v8: the chip's small ring is its own stroke, a clear black pixel off the chip's edges (the art joins it)."""
    ys, xs = np.nonzero(mask)
    (cx, cy), (rx, ry) = gen_svg.CHIP_MARK
    return len(xs) and abs(xs.mean() / s - cx) < 1 and abs(ys.mean() / s - cy) < 1 and np.ptp(xs) / s < 2 * rx + 2


def check(art=None, svg=None, scales=(1.25, 4)):
    art = art or find_art()
    svg = Path(svg or HERE / 'c64arp.svg')
    lab, n, sk = art_pieces(art)
    tmp = HERE / '.components_strokes.svg'
    tmp.write_text(strokes_only(svg.read_text()))
    failures = []
    try:
        for s in scales:
            img = oprender.render({'svg': str(tmp)}, scale=s, stock=False).array()
            rl, rn = nd.label(img.max(2) > 60, np.ones((3, 3)))
            ys, xs = np.nonzero(sk)
            # art pixel centre -> screen units (the screen is lifted 4) -> render pixel
            rx = np.clip(((xs + .5) / U * s).astype(int), 0, img.shape[1] - 1)
            ry = np.clip((((ys + .5) / U - 4) * s).astype(int), 0, img.shape[0] - 1)
            hit = nd.maximum_filter(rl, size=3 + 2 * int(round(REACH * s)))[ry, rx]   # for gaps
            hit3 = nd.maximum_filter(rl, size=3)[ry, rx]   # for the piece count
            ux, uy = (xs + .5) / U, (ys + .5) / U - 4
            moved = np.zeros(len(xs), bool)
            for x0, y0, x1, y1 in MOVED:
                moved |= (ux >= x0) & (ux <= x1) & (uy >= y0) & (uy <= y1)
            for k in range(1, n + 1):
                sel = lab[ys, xs] == k
                if not sel.any():
                    continue
                cnt = sel & ~moved
                got = set(int(v) for v in np.unique(hit3[cnt if cnt.any() else sel]) if v)
                # gaps: centre-line runs of this piece that land on no stroke ink (beyond the 3x3 tolerance)
                miss = np.zeros(sk.shape, bool)
                miss[ys[sel & (hit == 0)], xs[sel & (hit == 0)]] = True
                gl, gn = nd.label(nd.binary_dilation(miss, iterations=2))
                for g in nd.find_objects(gl):
                    run = miss[g].sum()
                    gy, gx = np.nonzero(miss[g])
                    cx, cy = (gx.mean() + g[1].start) / U, (gy.mean() + g[0].start) / U - 4
                    if run >= GAP_PX and not any(x0 <= cx <= x1 and y0 <= cy <= y1 for x0, y0, x1, y1 in EXEMPT):
                        failures.append({'scale': s, 'piece': k, 'render_pieces': 'gap', 'at': (
                            round((gx.mean() + g[1].start) / U, 1), round((gy.mean() + g[0].start) / U - 4, 1)),
                            'box': (round(g[1].start / U, 1), round(g[0].start / U - 4, 1), round(g[1].stop / U, 1),
                                    round(g[0].stop / U - 4, 1)), 'pixels': int(run)})
                # v4: a blue key's inner diamond is its own stroke (the art joins two of them to the key outline with
                # a shading line); it doesn't count as a break of the piece
                if len(got) > 1:
                    got = {g for g in got if not inner_diamond(rl == g, s) and not chip_mark(rl == g, s)} or got
                if len(got) != 1:
                    x, y = xs[sel].mean() / U, ys[sel].mean() / U - 4
                    failures.append({'scale': s, 'piece': k, 'render_pieces': len(got), 'at': (round(x, 1), round(y, 1)),
                                     'box': (round(xs[sel].min() / U, 1), round(ys[sel].min() / U - 4, 1),
                                             round(xs[sel].max() / U, 1), round(ys[sel].max() / U - 4, 1))})
    finally:
        tmp.unlink(missing_ok=True)
    return n, failures


if __name__ == '__main__':
    n, f = check(*(sys.argv[1:3]))
    for x in f:
        print(f"scale {x['scale']}: art piece {x['piece']} at {x['at']} (box {x['box']}) -> {x['render_pieces']} render pieces {x.get('pixels', '')}")
    print(f'c64arp line continuity: {n} art pieces, {len(f)} failures')
    sys.exit(1 if f else 0)
