#!/usr/bin/env python3
"""Focused c64arp logic/text tests; actual loading/audio/restart are separate gates."""
from pathlib import Path
import subprocess,sys,tempfile
sys.path.insert(0,str(Path(__file__).resolve().parent))
P=Path(__file__).resolve().parent;SDK=P.parents[1]
with tempfile.TemporaryDirectory(prefix='c64arp-check-') as tmp:
    out=Path(tmp);flags=['cc','-O1','-g','-fsanitize=address,undefined','-fno-sanitize-recover=undefined']
    subprocess.run(flags+[str(P/'arp.c'),str(P/'arp_test.c'),'-o',str(out/'logic')],check=True)
    subprocess.run([str(out/'logic')],check=True)
    subprocess.run(flags+['-DOP1_HOST','-DFX=FX_dummy','-DSCREEN=SCREEN_c64arp','-I'+str(SDK),str(P/'geometry_test.c'),str(P/'c64arp.c'),str(P/'arp.c'),'-lm','-o',str(out/'geometry')],check=True)
    subprocess.run([str(out/'geometry')],check=True)
# Line continuity (2026-11-14): every white/blue piece of the art is one connected stroke piece, no gaps.
import art_components
art=art_components.find_art()
if art is None:print('c64arp line continuity: SKIP (docs/design/c64/c64arp-art.png not found)')
else:
    n,fails=art_components.check(art)
    for x in fails:print('c64arp line continuity FAIL:',x)
    print(f'c64arp line continuity: {n} art pieces, {len(fails)} failures');assert not fails
# Geometry (v4, 2026-11-14): every straight run of the hand-placed lines lies on the drawing's angle set, each run is
# one segment between two emitted vertices (so it deviates 0 from straight), arcs keep their radius, ink stays inside
# the release's bounds, the committed SVG strokes are exactly the generator's, and gen_svg.py reproduces the SVG.
import math,re
import gen_svg as G
S=G.strokes()
def r2(p):return (round(p[0]+0,2)+0.0,round(p[1]+0,2)+0.0)
bad=[];used={};runs=0;short=0
for s in S:
    if s.circle:continue
    Q=[r2(p) for p in s.pts]
    for i,a in s.runs:
        p,q=Q[i],Q[(i+1)%len(Q)]
        if math.hypot(q[0]-p[0],q[1]-p[1])<.05:short+=1;continue
        ang=math.degrees(math.atan2(-(q[1]-p[1]),q[0]-p[0]))%180
        dev,near=min((abs((ang-A+90)%180-90),A) for A in G.ANGLES)
        runs+=1;used[near]=used.get(near,0)+1
        if a is not None:a=math.degrees(G.rad(a))%180   # v8: the nominal 30/150 runs are the 4:7 iso angle
        if dev>.5 or (a is not None and abs((ang-a+90)%180-90)>.5):bad.append(f'{s.name}: run {p}->{q} at {ang:.2f} deg')
    for i,j,c,r in s.arcs:
        rx,ry=(r,r) if not isinstance(r,tuple) else r
        for p in s.pts[i:j+1]:
            if abs(math.hypot((p[0]-c[0])/rx,(p[1]-c[1])/ry)-1)>1e-6:bad.append(f'{s.name}: arc point {p} off its radius')
for s in S:
    w=s.width/2
    xs,ys=([s.circle[0][0]-s.circle[1],s.circle[0][0]+s.circle[1]],[s.circle[0][1]-s.circle[1],s.circle[0][1]+s.circle[1]]) if s.circle else zip(*s.pts)
    if min(xs)-w<4 or max(xs)+w>208.25 or min(ys)-w<22 or max(ys)+w>124.8:bad.append(f'{s.name}: ink outside x 4..208.25, y 22..124.8')
svg=(P/'c64arp.svg').read_text()
emitted=[e for e in re.findall(r'<(?:path|circle)[^>]*/>',svg) if re.search(r'stroke="#(?:f3f4f5|578ef1|01f0bc|f65564)"',e)]
if len(emitted)!=len(S):bad.append(f'{len(emitted)} stroked elements in c64arp.svg, generator has {len(S)}')
else:
    from svgart import rounded
    for s,e in zip(S,emitted):
        if s.circle:continue
        got=[(float(a),float(b)) for a,b in re.findall(r'(-?[\d.]+) (-?[\d.]+)',re.search(r' d="([^"]+)"',e).group(1))]
        if got!=[(float(x),float(y)) for x,y in rounded(s.pts,s.closed)]:bad.append(f'{s.name}: SVG vertices differ from the generator')
# Alike shapes (v5, owner 2026-11-14: "shapes that should be alike (blue/green chips) are not"): every key (blue, green
# and red), every note cube, every pad of one size and every foot is an exact translation of one model. Compared on the
# emitted (2-decimal) vertices: each instance's vertices minus its first vertex must equal the model's. A key is its
# body, front edge, pad, top and inner diamond together (so their places relative to each other match too); its top
# and inner diamond share the key's colour, its body and front are white, its pad blue. A foot is compared below its
# arms' tops (the arms end on the board edge, which runs at 30 deg under two of them). One width for every line.
from svgart import rounded
def rel(pts,closed):
    q=rounded(pts,closed);x0,y0=q[0];return [(round(x-x0,2),round(y-y0,2)) for x,y in q]
alike=[]
def same(name,insts):
    ref=insts[0][1]
    for nm,r in insts[1:]:
        if r!=ref:bad.append(f'{name}: {nm} is not an exact translation of {insts[0][0]}')
    alike.append(f'{len(insts)} {name}')
by={s.name:s for s in S};keys=[]
for n,col in G.KEYS:
    parts=[by[f'key {n} {p}'] for p in ('body','front','pad','top','inner')]
    x0,y0=rounded(parts[0].pts)[0];r=[]
    for st in parts:r+=[(round(x-x0,2),round(y-y0,2)) for x,y in rounded(st.pts,st.closed)]+[None]
    keys.append((f'key {n} ({col})',r))
    cols=[st.colour for st in parts]
    if cols!=[G.WHITE,G.WHITE,G.BLUE,G.COLOURS[col],G.COLOURS[col]]:bad.append(f'key {n}: colours {cols}')
same('keys (body, front, pad, top, inner)',keys)
same('note cubes',[(f'cube {q[0]:.0f}',sum((rel(by[f'cube {q[0]:.0f} {p}'].pts,p=='outline')+[None] for p in ('outline','inner','edge')),[])) for q in G.CUBES])
pads={}
for st in S:
    if st.ellipse and st.name!='chip mark':pads.setdefault(st.ellipse[1],[]).append((st.name,rel(st.pts,True)))
for r,insts in sorted(pads.items()):same(f'pads {r[0]} x {r[1]}',insts)
same('feet',[(st.name,rel(st.pts[1:-1],False)) for st in S if hasattr(st,'foot')])
for st in S:
    if hasattr(st,'foot') and (abs(st.pts[0][0]-st.pts[1][0])>1e-9 or abs(st.pts[-1][0]-st.pts[-2][0])>1e-9):bad.append(f'{st.name}: arms not vertical')
widths=sorted({st.width for st in S})
if widths!=[G.W_LINE]:bad.append(f'line widths {widths}, expected one ({G.W_LINE})')
print('c64arp alike shapes: '+', '.join(alike)+f' (each an exact translation of its model); line widths {widths}')
if art is None:print('c64arp geometry: reproduce check SKIP (art not found)')
else:
  with tempfile.TemporaryDirectory(prefix='c64arp-gen-') as tmp:
    subprocess.run([sys.executable,str(P/'gen_svg.py'),str(art),str(Path(tmp)/'c64arp.svg')],check=True,stdout=subprocess.DEVNULL)
    if (Path(tmp)/'c64arp.svg').read_bytes()!=(P/'c64arp.svg').read_bytes():bad.append('gen_svg.py does not reproduce c64arp.svg')
for b in bad:print('c64arp geometry FAIL:',b)
print(f'c64arp geometry: {len(S)} strokes, {runs} straight runs (deviation 0: one segment each; {short} under 0.05 skipped), angles used {dict(sorted(used.items()))}, {len(bad)} failures')
assert not bad
