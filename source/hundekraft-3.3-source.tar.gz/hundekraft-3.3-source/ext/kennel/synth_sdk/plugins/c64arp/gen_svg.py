#!/usr/bin/env python3
"""2026-11-14 v8 (owner: snap to the pixel grid of the owner's 376 x 188 panels): one-pixel lines (0.85) with every
vertical and horizontal on pixel centres at R246's 1.1748 scale, iso lines at 4:7 (29.74 deg) through pixel centres,
models and spacings in whole pixels (see DEV_S below); a black pixel between neighbouring lines where the grid allows.
v5 (owner: "its too chunky, and shapes that should be alike (blue/green chips) are not"): one line
width, 0.9 since v7 (the art's lines measure 0.67..0.77; clamped up for the OLED); every key is one model translated (body,
front, pad, top and inner diamond; the green and red tops are strokes now, not traced fills), and so are the cubes,
the pads of each size (iso ellipses, three sizes) and the feet; check.py checks those translations exactly. The
dashes are strokes; the rows, the back line between the keys, the trace bends (2.0) and the chip legs follow the art
as measured at 20x (run/c64arp-clean-2026-11-14/v5 in the full project). 115 elements (112 strokes, 3 fills), 773
vertices, 20.8 KB. v4 (owner: "all lines should be contiguous and same color", "chip can be white, not partially blue",
"lines should be clear, not weird bumps etc like now"): the white and blue lines are hand-placed geometry, not a
trace (strokes() and the tables below): straight runs on the drawing's angles (0/30/90/150) from fitted points, bends
(radius 3 on the board edges, 1 on the traces), parallel lines as exact offsets, one key, pad, foot and cube model each, the chip on the angle set,
one colour and width per line. Green and red (key tops, note icons, dashes) stay filled outlines as below. 114
elements (91 strokes, 17 of them circles, 23 fills), 640 vertices, 17.6 KB. check.py checks the angles, the arcs,
the bounds and that this file reproduces c64arp.svg. Earlier (v2, traced centre lines): one colour per line by pixel
majority; 152 elements, 1,074 vertices, 27.7 KB. v1 of the same day, kept for green/red:
2026-11-14 cleanup (owner: "a lot of weird errors"): the art's pale light-blue lines flipped between white and
blue pixel by pixel and traced into dashed debris along the board edges, specks and pinholes. coherent() gives each
line one colour, isolated flecks go, fill_pinholes() closes trace pockets, pieces() keeps every outline at 256 vertices
or fewer, and STEP=0 drops svg_lite's bridges. 261 -> 126 paths, 6,171 -> 2,652 vertices; shape vs art as before or
better (art_check.py, all colours together). Earlier notes:
Output passes through display/compact_svg.py (equivalent explicit M/L paths, per-shape
paint) and then display/svg_lite.py (2026-11-01, TE heap): contours of one colour bridged
into one path (axis-aligned walked-back steps of at most 1 unit, at most 256 vertices) and simplified
within LITE_TOL (0.15) units. Same colours, holes, draw order and the 4px lift.
Contour original art with the screen placement and line-weight constraints:
move all artwork up 4 screen px; normalize thin ink to the measured 1.6 px SID
bottom-lead weight, preserving broad fills, holes/gaps and the source palette.
Native text is unchanged. Minimum-width processing is deterministic and bounded.
"""
import hashlib,json,math,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'display'))
from svgart import rounded,shape
from compact_svg import compact_svg
from svg_lite import lighten
STEP=0  # no bridges (2026-11-14): after the cleanup bridging saved 6 of 122 paths, and its walked-back steps leave faint native traces
LITE_TOL=0.15  # svg-lite: contour points within this many units of their neighbours' chord are dropped
from lineweight import minimum_width
import cv2
import numpy as np
from scipy import ndimage as nd
from PIL import Image
HERE=Path(__file__).resolve().parent
PALETTE=np.array([[243,244,245],[87,142,241],[1,240,188],[246,85,100]],float)
SOURCE=HERE.parents[3]/'docs/design/c64/c64arp-art.png'
UNIT=1774/320  # source pixels per screen unit
FRAGMENT=3.0   # screen units^2: a smaller piece of one colour touching other ink is part of that ink's line
FRINGE=2.5     # source px: a piece at most twice this wide is a line's fringe whatever its length (pale lines: a
               # light-blue core flips to white, its edge stays blue, one or two pixels wide along the whole line)
TOUCH=.25      # ... when at least this share of the pixels around it are the other colour's ink
SPECK=.3       # screen units^2: a smaller piece with no ink around it is an antialiasing fleck
PATH_VERTICES=256  # most vertices in one filled outline (R246 drew 314 in the shipped screen; a 1,446-vertex fill hung it)
OVERLAP=3      # source px each half of a cut shape reaches past the cut
PINHOLE=.3     # screen units^2: a smaller hole (no other colour inside) is left by the trace, not a gap in the art
def coherent(ink):
    """One colour per line (2026-11-14 cleanup). The art's pale lines (light blue, between the white and the blue
    direction) flip colour pixel by pixel; traced as they are, each colour gets a trail of specks that the 1.6 px
    weight then grows into the dashed debris the owner saw along the board edges. Each small piece of a colour
    that touches other ink takes the colour it touches most (smallest first, until nothing changes); tiny isolated
    flecks go. Lines keep their place and width; only their colour is made consistent along them."""
    L=ink.copy();n={'relabelled':0,'specks':0};S=np.ones((3,3))
    while True:
        cands=[]
        for i in range(len(PALETTE)):
            lab,count=nd.label(L==i,S)
            if count:
                sizes=np.bincount(lab.ravel())
                for k,box in enumerate(nd.find_objects(lab),1):
                    if sizes[k]<FRAGMENT*UNIT*UNIT or nd.distance_transform_edt(np.pad(lab[box]==k,1)).max()<=FRINGE:
                        cands.append((sizes[k],i,k,box,lab))
        changed=0;done=np.zeros(L.shape,bool)
        for size,i,k,box,lab in sorted(cands,key=lambda c:(c[0],c[1],c[3][0].start,c[3][1].start)):
            sl=(slice(max(box[0].start-2,0),box[0].stop+2),slice(max(box[1].start-2,0),box[1].stop+2))
            comp=lab[sl]==k
            if (done[sl]&comp).any():continue
            ring=nd.binary_dilation(comp,S)&~comp;near=L[sl][ring];other=near[(near>=0)&(near!=i)]
            if other.size and other.size>=TOUCH*ring.sum():
                L[sl][comp]=np.bincount(other).argmax();n['relabelled']+=1
            elif not (near>=0).any() and size<SPECK*UNIT*UNIT:
                L[sl][comp]=-1;n['specks']+=1
            else:continue
            done[sl]|=comp;changed+=1
        if not changed:return L,n
def fill_pinholes(mask,others,n):
    """Holes under PINHOLE units^2 with no other colour's ink in them: closed pockets the trace and the line weight
    leave, each of which would cost a black cut-out path."""
    holes,count=nd.label(nd.binary_fill_holes(mask)&~mask)
    if not count:return mask
    sizes=np.bincount(holes.ravel());busy=np.bincount(holes.ravel(),others.ravel(),minlength=count+1)
    small=(sizes<PINHOLE*UNIT*UNIT)&(busy==0);small[0]=False
    n['pinholes']=n.get('pinholes',0)+int(small.sum())
    return mask|small[holes]
def rings(mask,i):
    """-> [(screen points, depth)] of one mask: outer contours (depth 0) and their black holes (odd depth)."""
    contours,hierarchy=cv2.findContours(np.repeat(np.repeat(mask,2,axis=0),2,axis=1),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    found=[]
    def emit(index,depth):
        contour=contours[index]
        # Preserve thin white wires; simplify other contour noise more strongly.
        epsilon=(.12 if i==0 else .2)*1774/160
        points=cv2.approxPolyDP(contour,epsilon,True).reshape(-1,2)
        if abs(cv2.contourArea(points)-cv2.contourArea(contour))>max(1,cv2.contourArea(contour)*.05):
            points=cv2.approxPolyDP(contour,.8,True).reshape(-1,2)
        if len(points)<3:
            x,y,w,h=cv2.boundingRect(contour)
            points=np.array([[x-.5,y-.5],[x+w-.5,y-.5],[x+w-.5,y+h-.5],[x-.5,y+h-.5]])
        xy=rounded([((x+.5)*160/1774,(y+.5)*80/887-4) for x,y in points],True)
        if len(xy)>=3:found.append((xy,depth))
        child=hierarchy[0,index,2]
        while child!=-1:
            emit(child,depth+1);child=hierarchy[0,child,0]
    if hierarchy is not None:
        for index,h in enumerate(hierarchy[0]):
            if h[3]==-1:emit(index,0)
    return found
def pieces(mask,i):
    """Rings of one colour, as lists. A shape whose outline would pass PATH_VERTICES is cut across its longer side into
    two halves that overlap by OVERLAP source px (same colour, so no seam; each half covers only the shape's own ink,
    so neither fills the other's holes). Cut shapes go first and the rest after, as one set, so a shape standing in
    another's hole still draws after that hole's black cut-out. Since the 2026-11-14 cleanup the blue board traces
    are one shape of 431 vertices."""
    found=rings(mask,i)
    if max((len(xy) for xy,d in found if d==0),default=0)<=PATH_VERTICES:return [found]
    lab,count=nd.label(mask>0,np.ones((3,3)));out=[];rest=mask.copy()
    for k,box in enumerate(nd.find_objects(lab),1):
        part=np.where(lab==k,mask,0).astype(mask.dtype)
        if max((len(xy) for xy,d in rings(part[box],i) if d==0),default=0)<=PATH_VERTICES:continue
        rest[lab==k]=0
        h,w=box[0].stop-box[0].start,box[1].stop-box[1].start
        axis=1 if w>=h else 0;cut=(box[axis].start+box[axis].stop)//2;idx=np.indices(mask.shape)[axis]
        for half in (idx<cut+OVERLAP,idx>=cut-OVERLAP):out+=pieces(np.where(half,part,0).astype(mask.dtype),i)
    return out+[rings(rest,i)]
LINE_INK=125    # brightest channel above this = line ink (the art's line cores are 140..255); line_mask() and
                # art_components.py use it to find the art's white and blue lines
# ---- v4 (2026-11-14): the white and blue lines as hand-placed geometry -------------------------------------------
# Owner: "all lines should be contiguous and same color", "chip can be white, not partially blue", "lines should be
# clear, not weird bumps etc like now". Nothing white or blue is traced any more. Every line below is a straight run
# on one of the drawing's angles (ANGLES; measured from the art: its long runs lie at 29.2..31.1 deg and 0/90),
# defined by its angle and one point, with the point fitted to the art's centre-line pixels over the whole run
# (run/c64arp-clean-2026-11-14/v4/fit*.py in the full project). Vertices are where two runs meet; bends get one radius
# (BEND), drawn as M/L polylines within SAG units of the true arc. Parallel lines are offsets of one line (SPACE).
# Keys, pads, feet and note cubes are one model each, placed from the tables. All coordinates are screen units with
# the owner's 4 px lift already in (art y / UNIT - 4); they are emitted as they are.
# v8 (owner 2026-11-14): snapped to the pixel grid of the owner's panels (376 x 188, OP1EMU_PANEL=b and c2). R246's
# screen matrix there is s = 0x4B3/1024 = 1.1748 with the row origin 375.9375 (display.md "Panel variants"), so in
# screen orientation a unit point (x, y) lands on pixel coordinate (s x + 1/16, s y) (fitted to the rc11 panel-b
# capture of the release art: best at dx 0.06..0.12, dy 0); c2 shows the same frame 2 px higher (whole pixels; its
# DMA starts 2 columns in), so the grid holds there too. Every line is one pixel wide (0.85 units); every vertical
# runs through pixel-column centres and every horizontal through pixel-row centres; models and their spacings are
# whole pixels, so copies render pixel for pixel alike. The iso lines run at 4:7 (29.74 deg, was 30): they repeat
# every 7 px, pass through a pixel centre every 7th column, and parallels a whole number of pixels apart render alike.
# The default 400 x 200 panel (1.25) is not on this grid and renders softer (accepted).
DEV_S,DEV_X0=1203/1024,1/16
TH=math.degrees(math.atan2(4,7))   # the iso angle: 29.74 deg
def gx(i):return (i+.5-DEV_X0)/DEV_S   # unit x of pixel column i's centre
def gy(j):return (j+.5)/DEV_S          # unit y of pixel row j's centre
def npx(n):return n/DEV_S              # n pixels in units
def sx(x):return gx(math.floor(DEV_S*x+DEV_X0))   # x moved to its pixel column's centre
def sy(y):return gy(math.floor(DEV_S*y))
def sxy(p):return (sx(p[0]),sy(p[1]))
def sdiag(l):
    """An iso run moved (by under half a pixel, vertically) so that it passes through a pixel centre at a column
    centre: then it does so every 7th column, and its antialiasing pattern is the same as every other iso run's."""
    a,p=l;X=math.floor(DEV_S*p[0]+DEV_X0)+.5;x=(X-DEV_X0)/DEV_S;y=at_x(l,x)[1]*DEV_S
    return (a,(x,(round((y-.5)*7)/7+.5)/DEV_S))
def down(l,n):
    """A run moved n whole pixels down (negative: up), so it stays on the grid."""
    a,p=l;return (a,(p[0],p[1]+npx(n)))
ANGLES=(0,TH,90,180-TH)
W_LINE=W_THIN=0.85   # v8: one device pixel (1/1.1748 = 0.851 units); was 0.9     # v7 (owner 2026-11-14): 0.9, up from the v5/v6 0.8, so the verticals render white (v5 "too chunky": one width for every line). The art's lines measure
                        # 0.67..0.77 units across every kind (integrated cross-section / peak
                        # v5/widths.py); 0.8 is the art's 0.7 clamped up for the OLED (see W_NOTE in check.py)
SAG=.03         # arc polylines stay within this of the true arc
BEND=3.0        # bend radius of the board edges and traces
WHITE,BLUE=0,1
T30=4/7   # v8: the iso slope (was tan 30)
def rad(a):
    """Radians of a nominal angle: 30, 150, 210 and 330 are the 4:7 iso directions (v8)."""
    a%=360;return math.radians({30:TH,150:180-TH,210:180+TH,330:360-TH}.get(a,a))
def unit(a):
    r=rad(a);return (math.cos(r),-math.sin(r))   # screen direction of angle a (y down)
def meet(l1,l2):
    """Point where two runs (angle, point) meet."""
    (a1,p1),(a2,p2)=l1,l2;d1,d2=unit(a1),unit(a2);det=-d1[0]*d2[1]+d1[1]*d2[0]
    rx,ry=p2[0]-p1[0],p2[1]-p1[1];s=(-rx*d2[1]+ry*d2[0])/det
    return (p1[0]+s*d1[0],p1[1]+s*d1[1])
def onto(l,q):
    a,p=l;d=unit(a);s=(q[0]-p[0])*d[0]+(q[1]-p[1])*d[1];return (p[0]+s*d[0],p[1]+s*d[1])
def at_x(l,x):
    a,p=l;d=unit(a);return (x,p[1]+(x-p[0])*d[1]/d[0])
def shift(l,d):
    """The run moved d units along its normal, down (or right, for a vertical): a parallel line."""
    a,p=l;n=(math.sin(rad(a)),math.cos(rad(a)))
    if n[1]<-1e-9 or (abs(n[1])<1e-9 and n[0]<0):n=(-n[0],-n[1])
    return (a,(p[0]+d*n[0],p[1]+d*n[1]))
def arc_pts(c,r,t0,t1):
    """Points on a circle from angle t0 to t1 (radians, screen: x=c+r cos t, y=c+r sin t), at most SAG off the arc."""
    step=2*math.acos(max(-1,1-SAG/r));n=max(1,math.ceil(abs(t1-t0)/step))
    return [(c[0]+r*math.cos(t0+(t1-t0)*k/n),c[1]+r*math.sin(t0+(t1-t0)*k/n)) for k in range(n+1)]
class Stroke:
    """One SVG element: points (or a circle), colour, width; the straight runs and arcs it is made of (check.py
    checks them: every run on ANGLES, every arc point on its radius)."""
    def __init__(s,name,colour,width=W_LINE,closed=False):
        s.name,s.colour,s.width,s.closed=name,colour,width,closed;s.pts=[];s.runs=[];s.arcs=[];s.circle=None;s.ellipse=None
    def line(s,p,a=None):
        if s.pts and a is not None:s.runs.append((len(s.pts)-1,a))
        s.pts.append(p);return s
    def arc(s,c,r,t0,t1):
        q=arc_pts(c,r,t0,t1);i=len(s.pts)
        if s.pts and math.hypot(s.pts[-1][0]-q[0][0],s.pts[-1][1]-q[0][1])<1e-6:q=q[1:];i-=1
        s.pts+=q;s.arcs.append((i,len(s.pts)-1,c,r));return s
def polyline(name,colour,start,runs,end,width=W_LINE,bend=BEND,closed=False):
    """A stroke along runs [(angle, point), ...] from start to end (each projected onto its run); every vertex where
    two runs meet is rounded with radius bend (0 = sharp)."""
    if closed:
        V=[meet(runs[i-1],runs[i]) for i in range(len(runs))]
    else:
        V=[onto(runs[0],start)]+[meet(runs[i],runs[i+1]) for i in range(len(runs)-1)]+[onto(runs[-1],end)]
    A=[a for a,_ in runs];s=Stroke(name,colour,width,closed)
    n=len(V);idx=range(n) if closed else range(1,n-1)
    corner={}
    for i in idx:
        p0,p,p1=V[i-1],V[i],V[(i+1)%n]
        u=(p[0]-p0[0],p[1]-p0[1]);w=(p1[0]-p[0],p1[1]-p[1]);lu,lw=math.hypot(*u),math.hypot(*w)
        u=(u[0]/lu,u[1]/lu);w=(w[0]/lw,w[1]/lw);cos=max(-1,min(1,u[0]*w[0]+u[1]*w[1]));phi=math.acos(cos)
        if bend<=0 or phi<1e-6:corner[i]=None;continue
        tl=bend*math.tan(phi/2);cr=u[0]*w[1]-u[1]*w[0];nrm=(-u[1],u[0]) if cr>0 else (u[1],-u[0])
        t1=(p[0]-u[0]*tl,p[1]-u[1]*tl);t2=(p[0]+w[0]*tl,p[1]+w[1]*tl);c=(t1[0]+nrm[0]*bend,t1[1]+nrm[1]*bend)
        a0=math.atan2(t1[1]-c[1],t1[0]-c[0]);a1=math.atan2(t2[1]-c[1],t2[0]-c[0])
        if cr>0 and a1<a0:a1+=2*math.pi
        if cr<0 and a1>a0:a1-=2*math.pi
        corner[i]=(c,a0,a1)
    for i in range(n):
        a_prev=A[(i-1)%len(A)] if (closed or i>0) else None
        if i in corner and corner[i]:
            c,a0,a1=corner[i];s.line(arc_pts(c,bend,a0,a1)[0],a_prev);s.arc(c,bend,a0,a1)
        else:s.line(V[i],a_prev)
    if closed:s.runs.append((len(s.pts)-1,A[-1]))
    return s
def path(name,colour,pts,width=W_LINE,closed=False):
    """Straight runs through given vertices (each run's angle checked against ANGLES)."""
    s=Stroke(name,colour,width,closed)
    for p in pts:s.line(p,0 if s.pts else None)
    s.runs=[(i,None) for i in range(len(pts)-1)]+([(len(pts)-1,None)] if closed else [])
    return s
# Board: the top face's front edge (left end arc, then F, H, G, J), the bottom edge (the same runs moved down SPACE
# units, then the right end and the back edge) and the long bottom trace (moved up SPACE): three parallel lines,
# evenly spaced. Fitted run points (skeleton medians over each whole run):
SPACE=npx(4)*math.cos(math.radians(TH))   # v8: 4 px apart vertically (was 2.8 units across); units between the parallel board lines (art: 3.1 on the slopes, 2.35 and 3.06 on the flat)
# The flat runs sit on pixel rows (v6, owner: "grey line on bottom, it should be white"): a 0.8 line is one full pixel
# row only when its centre is within about 0.1 px of a row centre, and that must hold at both 1.25 (panel a/c) and 1.175
# (panel b). The flat top edge y=106.0 and the bottom edge y=106.0+FLAT_BOTTOM=109.3 are the nearest such rows to the
# fitted 106.3/109.1 (art: 2.35 and 3.06 apart on the flat); the trace stays at 103.5 (full at 1.25 already, 0.85 at 1.175).
FLAT_BOTTOM,FLAT_TRACE=npx(4),npx(4)   # v8: whole pixels (were 3.3, 2.5)
#  # flat bottom edge below, long trace above the flat top edge
F_RUN=down(sdiag((150,(35.89,87.68))),F_DOWN:=1);H_RUN=(0,(115.0,sy(106.0)));G_RUN=sdiag((150,(169.43,111.13)));J_RUN=down(sdiag((30,(193.55,109.58))),J_DOWN:=1)
RIGHT_END=(90,(sx(206.99),99.5));BACK_RIGHT=down(sdiag((150,(184.02,81.96))),-2)   # v8: 2 px up, a black pixel clear of the last keys' tops   # back edge: fitted (v4 moved it 0.49 up-right for
# black between it and the last keys' tops at width 1.6; at 0.8 the fitted line has room)
LEFT_X,LEFT_R=sx(5.23),npx(5)   # v8: on a column centre, 5 px (was 4.2)
#  # left end: one arc of this radius, leftmost at LEFT_X, tangent to F (art: round, no flat)
LEFT_OPEN=260         # screen angle (deg) where the left arc starts open, behind the chip's first leg
FRONT_END_X=203.3        # the top face's front edge stops here (the art leaves it open short of the right end)
BOTTOM_START_X=7.1       # the bottom edge starts open under the left arc
BACK_RIGHT_X=163.3       # the right arm's back edge starts here, beside the green key
LONG_VIA,LONG_PAD_X=sx(70.06),sx(179.53)   # long trace: from the via (x on the trace) to the pad (x on the trace)
# Feet: (centre x, bottom y, board run they hang from); one foot model: FOOT_W wide, half-ellipse bottom FOOT_RY deep
FEET=[(sx(12.25),sy(83.2)+npx(F_DOWN),'F'),(sx(71.9),sy(113.3),'H'),(None,sy(124.0),'GJ'),(sx(199.2),sy(114.2)+npx(J_DOWN),'J')]   # art bottoms 83.0, 113.3, 124.0, 113.3 (the last
# moved down: the bottom edge there is 3.23 below the top edge instead of the art's 3.1, and an arm can't run upwards)
FOOT_W,FOOT_RY=npx(8),npx(3)   # v8: whole pixels (were 7.2, 2.4)
# Keys: one model on an exact iso grid: centre of the top face = KEY_APEX + n * KEY_PITCH along 30 deg (left arm,
# n<0) or 150 deg (right arm, n>0). Fitted: centres within 0.33 of the grid. Top face half-width KEY_HW at 30 deg
# (art 28.8 deg), body height KEY_H; inner diamond KEY_IW, KEY_IDY. Colour of the top: the art's (blue, or the green
# and red fills, which stay as they are); the body (verticals and the lower V) is white on every key.
KEY_APEX,KEY_STEP=sxy((115.05,50.30)),(21,12)   # v8: the next key 21 px across and 12 down (4:7; was 20.965 units at 30 deg)
KEY_HW,KEY_H,KEY_IW,KEY_IDY=npx(13),npx(8+4/7),npx(6),0   # v8 (were 10.7, 7.5, 6.9, -0.1): verticals 26 px apart;
# the body's bottom vertex 16 px below the top centre (a pixel centre); the inner diamond 4 px inside the top one (parallel iso
# lines need 3.5 px or more between centres for a black pixel in every column)
KEYS=[(-3,'blue'),(-2,'green'),(-1,'blue'),(0,'red'),(1,'blue'),(2,'green'),(3,'blue'),(4,'blue')]
# Pads (v5): iso ellipses (rx, ry) of three sizes, fitted to the art's ring centre lines (run/.../v5/pads.py): key
# pads 2.2..2.5 x 1.5..1.65 (ring fit and front-column profile), the two mid pads (the last key's and the long trace's) 1.85..1.93 x 1.21..1.32, the
# vias 1.22..1.66 x 0.81..1.09. One model per size, PAD_N vertices.
KEY_PAD,MID_PAD,VIA_PAD=(npx(3),npx(2)),(npx(2),npx(1)),(npx(2),npx(1))   # v8: whole pixels (were (2.35, 1.6), (1.9, 1.25), (1.5, .97)); mid and via pads are one size now
PAD_DY=npx(20)   # v8 (was 15.65): the rows through the pads run 4 px below the bodies' bottom edges
#  # key pad centre below the key's top centre (art 14.6..16.0, mean 15.5; front-column profile 15.65)
PAD_N=16
COLOURS={'blue':1,'green':2,'red':3}
# Note cubes: one iso cube model at the inner top corner Q; CUBE_A, CUBE_B: widths of the left and right faces,
# CUBE_H the height. The art's cubes lean at 21..27 deg; drawn on 30/150 like the rest.
CUBES=[sxy(q) for q in [(75.3,42.5),(113.3,28.9),(156.7,48.4)]]
CUBE_A,CUBE_B,CUBE_H=npx(4),npx(8),npx(11)   # v8: whole pixels (were 3.2, 7.0, 9.0)
def r2(p):return (round(p[0],2),round(p[1],2))
def key_centre(n):
    """Rounded to 0.01, so every key's emitted vertices are its model's plus the same 2-decimal offset (exact copies)."""
    s=-1 if n<0 else 1;n=abs(n);return r2((KEY_APEX[0]+s*n*npx(KEY_STEP[0]),KEY_APEX[1]+n*npx(KEY_STEP[1])))
def key_points(n):
    cx,cy=key_centre(n);hh=KEY_HW*T30
    L,T,R,B=(cx-KEY_HW,cy),(cx,cy-hh),(cx+KEY_HW,cy),(cx,cy+hh)
    return dict(L=L,T=T,R=R,B=B,L2=(L[0],L[1]+KEY_H),R2=(R[0],R[1]+KEY_H),B2=(B[0],B[1]+KEY_H),pad=(cx,cy+PAD_DY))
def ell_pt(c,r,a):
    """The point of ellipse (c, (rx, ry)) in direction a (degrees) from its centre."""
    d=unit(a);t=1/math.sqrt((d[0]/r[0])**2+(d[1]/r[1])**2);return (c[0]+t*d[0],c[1]+t*d[1])
def to_ellipse(p,a,c,r):
    """Where the run from p along angle a first meets ellipse (c, (rx, ry))."""
    d=unit(a);fx,fy=(p[0]-c[0])/r[0],(p[1]-c[1])/r[1];dx,dy=d[0]/r[0],d[1]/r[1]
    A=dx*dx+dy*dy;b=fx*dx+fy*dy;q=fx*fx+fy*fy-1;disc=b*b-A*q
    assert disc>=0,f'run from {p} at {a} misses the pad at {c}'
    s=(-b-math.sqrt(disc))/A;return (p[0]+s*d[0],p[1]+s*d[1])
def ellipse(name,colour,c,r,n=PAD_N,width=W_LINE):
    """A pad: n vertices on an axis-aligned ellipse, the first at angle 0; the centre rounded to 0.01 (exact copies)."""
    c=r2(c);s=Stroke(name,colour,width,True)
    s.pts=[(c[0]+r[0]*math.cos(2*math.pi*k/n),c[1]+r[1]*math.sin(2*math.pi*k/n)) for k in range(n)]
    s.arcs.append((0,n-1,c,r));s.ellipse=(c,r);return s
def board():
    out=[]
    F,H,G,J=F_RUN,H_RUN,G_RUN,J_RUN
    # top face front edge: the left arc into F, then H, G, J
    nF=(math.sin(rad(150)),math.cos(rad(150)));cF=nF[0]*F[1][0]+nF[1]*F[1][1]
    cx=LEFT_X+LEFT_R;c=(cx,(cF+LEFT_R-nF[0]*cx)/nF[1])
    q=onto(F,c);s=Stroke('board top edge',WHITE);s.arc(c,LEFT_R,math.radians(LEFT_OPEN),math.atan2(q[1]-c[1],q[0]-c[0]))
    rest=polyline('',WHITE,s.pts[-1],[F,H,G,J],at_x(J,FRONT_END_X))
    off=len(s.pts)-1;s.runs+=[(i+off,a) for i,a in rest.runs];s.arcs+=[(i+off,j+off,cc,r) for i,j,cc,r in rest.arcs];s.pts+=rest.pts[1:]
    out.append(s)
    # bottom edge: F H G J moved down SPACE, the right end, the right arm's back edge
    F2,H2,G2,J2=(shift(l,SPACE) for l in (F,H,G,J));H2=shift(H,FLAT_BOTTOM)
    out.append(polyline('board bottom edge',WHITE,at_x(F2,BOTTOM_START_X),[F2,H2,G2,J2,RIGHT_END,BACK_RIGHT],at_x(BACK_RIGHT,BACK_RIGHT_X)))
    # long trace: H and G moved up SPACE, from the via to the pad
    H3,G3=shift(H,-FLAT_TRACE),shift(G,-SPACE)
    via=r2(at_x(H3,LONG_VIA));pad=r2(sxy(at_x(G3,LONG_PAD_X)))
    out.append(polyline('long trace',BLUE,ell_pt(via,VIA_PAD,0),[H3,G3],ell_pt(pad,MID_PAD,150)))
    rings=[ellipse('long trace via',BLUE,via,VIA_PAD),ellipse('long trace pad',BLUE,pad,MID_PAD)];edges=out;out=[]
    # feet: two verticals from the bottom edge down, a half-ellipse at the bottom
    runs={'F':F2,'H':H2,'J':J2}
    for cx,bottom,on in FEET:
        if on=='GJ':cx=sx(meet(G2,J2)[0])
        cx,bottom=round(cx,2),round(bottom,2)   # 2-decimal centre and bottom: the U below the arms is an exact copy of the model
        rx=FOOT_W/2;l,r=cx-rx,cx+rx
        def top(x):
            if on=='GJ':return at_x(G2 if x<cx else J2,x)[1]
            return at_x(runs[on],x)[1]
        f=Stroke(f'foot {cx:.0f}',BLUE);f.foot=(cx,bottom);f.line((l,top(l)));f.line((l,bottom-FOOT_RY),90)
        k=len(f.pts)-1;q=[(cx-rx*math.cos(t),bottom-FOOT_RY+FOOT_RY*math.sin(t)) for t in [math.pi*i/16 for i in range(17)]]
        assert bottom-FOOT_RY>=max(top(l),top(r)),f'foot {cx}: arm would run upwards'
        f.pts+=q[1:];f.arcs.append((k,len(f.pts)-1,(cx,bottom-FOOT_RY),(rx,FOOT_RY)));f.line((r,top(r)),90)
        out.append(f)
    return out,edges,rings   # feet go first: the board edge they hang from draws over their ends
def keys():
    """v5 (owner 2026-11-14: "shapes that should be alike (blue/green chips) are not"; "I meant green/blue"): every key
    is the same five elements, translated only: the body (L L' B' R' R, white), the front edge (B B', white), the pad
    (blue), the top diamond and the inner diamond (strokes in the key's colour: blue, green or red; the green and red
    tops are no longer traced fills). The rows (the arm lines from a key's body corner to the next key's pad) are
    separate white lines, as the art draws them (v5, measured at 20x): on the left arm each row runs on from a key's R'
    along its bottom edge to the next key's pad (and the apex pad's right row mirrors that, to key 1's L'); further
    down the right arm the rows run from pad to pad through the pad centres,
    about 1.6 below the bodies' bottom edges (v4 had them through L', hidden by the 1.6 width). The front edge runs on
    from B' to its pad."""
    out=[];rows=[];pads=[];tops=[]
    for n,col in KEYS:
        k=key_points(n);c=COLOURS[col];cx,cy=key_centre(n);iy=cy+KEY_IDY;ih=KEY_IW*T30
        out.append(path(f'key {n} body',WHITE,[k['L'],k['L2'],k['B2'],k['R2'],k['R']]))
        out.append(path(f'key {n} front',WHITE,[k['B'],(k['pad'][0],k['pad'][1]-KEY_PAD[1])]))
        pads.append(ellipse(f'key {n} pad',BLUE,k['pad'],KEY_PAD))
        tops.append(path(f'key {n} top',c,[k['L'],k['T'],k['R'],k['B']],closed=True))
        tops.append(path(f'key {n} inner',c,[(cx-KEY_IW,iy),(cx,iy-ih),(cx+KEY_IW,iy),(cx,iy+ih)],closed=True))
    first,last=KEYS[0][0],KEYS[-1][0];P=lambda n:key_points(n)['pad']
    for n,_ in KEYS:
        # v8: on the grid a key's R2 and the next key's B2 lie on one 4:7 line, 1 px above that key's pad: the row ends there
        if n<0:rows.append(path(f'row {n}',WHITE,[key_points(n)['R2'],key_points(n+1)['B2']]))
        if n==1:rows.append(path(f'row {n}',WHITE,[key_points(0)['B2'],key_points(n)['L2']]))   # the apex: the mirror of row -1
        if n>1:rows.append(path(f'row {n}',WHITE,[ell_pt(P(n-1),KEY_PAD,330),ell_pt(P(n),KEY_PAD,150)]))
    # the arm ends: the first key's bottom edge runs on from L' to the small pad by the fan; from the last key's pad a
    # row runs along 30 deg to the mid pad by the right end
    k=key_points(first);rows.append(path(f'row {first} end',WHITE,[to_ellipse(k['L2'],150,end_pad(first),VIA_PAD),k['L2']]))
    rows.append(path(f'row {last} end',WHITE,[ell_pt(P(last),KEY_PAD,30),to_ellipse(P(last),30,END_PAD_RIGHT,MID_PAD)]))
    return rows+out+pads+tops
def end_pad(n):
    """The small pads the end keys' rows run on to (art centres)."""
    return END_PAD_LEFT if n<0 else END_PAD_RIGHT
# Traces by the chip. The fan: seven parallel runs at 150 deg, FAN_STEP apart (art: 2.3..3.3, fitted 2.77; the fifth
# runs exactly through its leg's foot), each from a chip leg's foot (a vertical first) or open, bending
# with TRACE_BEND into verticals and 30 deg runs that end on small pads. Fitted points and pad centres from the art.
TRACE_BEND=2.0   # v5: the art's trace bends measure about 2 (v4 1.0; the 1.6 width hid the difference)
FAN_STEP=2.77
END_PAD_LEFT=sxy((41.66+npx(1),85.12))   # v8: 1 px right, clear of pad 37   # the via the first key's row runs to (art centre)
END_PAD_RIGHT=sxy((202.03,98.95))   # the last key's: a mid pad at the art's centre; its row runs to the ring
# The line behind the keys (v5): one V through the apex, y = 115.0 - x tan 30 on the left arm and x tan 30 - 17.9 on
# the right (fitted to its visible pieces in the art), seen in the gaps between the keys: from a key's top
# edge (left arm) or vertical (right arm) to the next key's vertical or top edge, and from the last key to its pad.
# (v4 had two of these pieces; the 1.6 lines covered the rest.)
BACK_V=sdiag((30,(100.0,115.0-100*math.tan(math.radians(30))))),sdiag((150,(160.0,160*math.tan(math.radians(30))-17.9)))
PADS={k:sxy(v) for k,v in {'32':(32.57,77.48),'37':(37.53,83.14),'57':(56.59,60.87)}.items()}
BACK_LEFT=[sdiag((150,(54.45,54.33))),(90,(sx(62.5),0)),sdiag((150,(67.97,63.79)))]   # board back edge from the chip, with a step
BACK_LEFT_X=(47.5,73.3)
BACK_STUB=down(sdiag((150,(73.72,64.3))),-1),(71.7,75.0)   # a short piece of back edge above it, by the green key
FAN_STEP_PX=4   # v8: the fan runs 4 px apart vertically (FAN_STEP 2.77 units across before)
def fan_run(j):
    x,y=leg_foot(3)   # the fifth run passes exactly through the fourth front leg's foot (on the grid: see CHIP_A)
    return (150,(x,y-(j-4)*npx(FAN_STEP_PX)))   # later runs higher
def leg_foot(k):
    (A2,D2,C2)=CHIP_DROP;x=CHIP_LEGS[1][k][0];return (x,D2[1]+(x-D2[0])*(C2[1]-D2[1])/(C2[0]-D2[0])+LEG_L)
def traces():
    out=[];R=TRACE_BEND;up=lambda p,a:ell_pt(p,VIA_PAD,a)
    def KEY3_LT(x):   # v8: fans 4 and 5 end on the first key's top edge (a T joint, as the art joins them)
        k=key_points(KEYS[0][0]);return meet((90,(sx(x),0)),(30,k['L']))
    pad41=end_pad(KEYS[0][0]);pad59=r2(sxy(at_x(fan_run(6),sx(59.04))))
    V=lambda x:(90,(sx(x),0))
    fan=[('fan 1',(CHIP_LEGS[1][0][0]+LEG_W/2,None),[fan_run(0),(30,PADS['32'])],up(PADS['32'],30)),   # from the first front leg's side (v5; was open at 26.4, joined by the 1.6 width)
         ('fan 2',leg_foot(1),[V(leg_foot(1)[0]),fan_run(1),V(43.92),(30,PADS['37'])],up(PADS['37'],30)),
         ('fan 3',leg_foot(2),[V(leg_foot(2)[0]),fan_run(2),V(48.61),(30,pad41)],up(pad41,30)),
         ('fan 4',(34.6,None),[fan_run(3),V(53.12)],KEY3_LT(53.12)),
         ('fan 5',leg_foot(3),[fan_run(4),V(56.73)],KEY3_LT(56.73)),
         ('fan 6',leg_foot(4),[V(leg_foot(4)[0]),fan_run(5)],(66.6,None)),
         ('fan 7',leg_foot(5),[V(leg_foot(5)[0]),fan_run(6)],up(pad59,150))]
    for name,s,runs,e in fan:
        if s[1] is None:s=at_x(runs[0],s[0])
        if e[1] is None:e=at_x(runs[-1],e[0])
        out.append(polyline(name,BLUE,s,runs,e,bend=1.0 if name=='fan 1' else R))   # fan 1's hook back to its pad (a 120 deg turn) is tight in the art
    stub=(30,PADS['57']);out.append(polyline('pad 57 stub',BLUE,up(PADS['57'],210),[stub],meet(stub,fan_run(6))))
    out.append(polyline('back edge left',BLUE,at_x(BACK_LEFT[0],BACK_LEFT_X[0]),BACK_LEFT,at_x(BACK_LEFT[-1],BACK_LEFT_X[1]),bend=R))
    l,(x0,x1)=BACK_STUB;out.append(polyline('back edge piece',BLUE,at_x(l,x0),[l],at_x(l,x1)))
    pads=[ellipse(f'pad {nm}',BLUE,p,VIA_PAD) for nm,p in [('32',PADS['32']),('37',PADS['37']),('41',pad41),('57',PADS['57']),('59',pad59)]]
    pads.append(ellipse('pad 202',BLUE,END_PAD_RIGHT,MID_PAD))
    # the line behind the keys, between them
    BL,BR=BACK_V
    for n,_ in KEYS[:-1]:
        k,k2=key_points(n),key_points(n+1)
        if n<0:a_,b_=meet(BL,(150,k['T'])),at_x(BL,k2['L'][0])
        else:a_,b_=at_x(BR,k['R'][0]),meet(BR,(30,k2['L']))
        out.append(polyline(f'back {n}',BLUE,a_,[BL if n<0 else BR],b_))
    k=key_points(KEYS[-1][0]);a_=at_x(BR,k['R'][0])
    out.append(polyline(f'back {KEYS[-1][0]}',BLUE,a_,[BR],to_ellipse(a_,330,END_PAD_RIGHT,MID_PAD)))
    return out,pads
def cubes():
    out=[]
    for qx,qy in [r2(q) for q in CUBES]:   # 2-decimal corners: the three cubes are exact copies
        Q=(qx,qy);L=(qx-CUBE_A,qy-CUBE_A*T30);R=(qx+CUBE_B,qy-CUBE_B*T30);K=(L[0]+CUBE_B,L[1]-CUBE_B*T30)
        dn=lambda p:(p[0],p[1]+CUBE_H)
        out.append(path(f'cube {qx:.0f} outline',BLUE,[L,K,R,dn(R),dn(Q),dn(L)],closed=True))
        out.append(path(f'cube {qx:.0f} inner',BLUE,[L,Q,R]))
        out.append(path(f'cube {qx:.0f} edge',BLUE,[Q,dn(Q)]))
    return out
# Dashes from the note cubes down to the green and red keys (v5): vertical strokes in the key's colour at the art's x,
# from the art's dash ends (ink extents of each dash, measured in run/.../v5) shortened by half the width for the round
# caps. The traced dash fills are dropped (without_key_tops).
DASHES=[('green',sx(77.53),[(52.71,55.23),(55.77,56.67),(57.58,60.46),(61.36,63.89)]),
        ('red',sx(115.23),[(38.89,40.51),(41.59,43.58)]),
        ('green',sx(157.87),[(58.62,60.79),(61.87,64.40),(65.30,67.64)])]
def dashes():
    """v8: each dash's ink ends on pixel-row edges (rounded), so a dash is whole pixels and the gaps whole black rows."""
    h=W_LINE/2;e=lambda y:round(y*DEV_S)/DEV_S;out=[]
    for col,x,ys in DASHES:
        n=COLOURS[col] and min((abs(key_centre(n)[0]-x),n) for n,c in KEYS if c==col)[1]   # the key the dashes run down to
        cx,cy=key_centre(n);top=cy-(KEY_HW-abs(x-cx))*T30   # its top edge under the dashes
        for i,(y0,y1) in enumerate(ys):
            y1=min(e(y1),math.floor((top-W_LINE/2)*DEV_S-1.5)/DEV_S)   # the last ends a clear pixel above the key's top
            out.append(path(f'dash {x:.0f} {i}',COLOURS[col],[(x,e(y0)+h),(x,max(y1-h,e(y0)+h+.01))]))
    return out
def chip():
    return [path(f'chip {i}',WHITE,list(g),W_THIN,cl) for i,(g,cl) in enumerate(chip_lines())]+[ellipse('chip mark',WHITE,*CHIP_MARK,n=12)]
def strokes():
    """Draw order: a line that ends on another (a T joint) goes first, so the line it meets draws over its end:
    feet, board edges, traces, key bodies, rings and pads, key tops, cubes, chip."""
    feet,edges,rings=board();lines,pads=traces();k=keys()
    tops=[s for s in k if s.name.endswith((' top',' inner'))];kpads=[s for s in k if s.ellipse]
    bodies=[s for s in k if s not in tops and s not in kpads]
    return feet+edges+lines+bodies+kpads+rings+pads+tops+cubes()+dashes()+chip()

# The chip (owner 2026-11-14: "chip can be white, not partially blue"; legs evenly spaced, same length) is drawn
# from its measured corners instead of the trace: traced lines inside CHIP are dropped (lines crossing its edge keep
# the part outside, which SNAP then joins to the legs). Screen units, lifted. Top face A B C D, bottom corners
# A' D' C' straight below A D C; legs hang LEG_L below the bottom edges, LEG_W wide, at even spacing.
# v4: the chip on the angle set too (its short sides were 24 deg): top face from fitted runs, long sides at 30 deg,
# short sides at 150 deg (through the art's side midpoints), faces CHIP_HC deep. Legs as before (U shapes LEG_W wide,
# LEG_L below the bottom edges), the front ones moved to the art's positions.
# v8: the chip on the pixel grid. Corner A on a pixel centre (the art's A, 10.4 55.7); the long sides 30 px across
# (4:7, 17 1/7 px up; was about 24.5 units), the short sides 11 px across (6 2/7 px down; was 9.7 units), faces 6 px
# deep (was 5.5 units). Legs: U shapes 2 px wide and 5 px long, 5 px apart: two on the left face (3 and 8 px in) and
# six on the front face (3 px in, then every 5 px). Every leg vertical is on a column centre and every leg foot on the
# 4:7 grid of A, so the fan runs through them stay on the grid.
CHIP_A=sxy((10.4,55.7))
def _chip_at(p,dx):return (p[0]+npx(dx),p[1]-npx(dx)*4/7)
_D=(CHIP_A[0]+npx(11),CHIP_A[1]+npx(11)*4/7)
CHIP_TOP=[CHIP_A,_chip_at(CHIP_A,30),_chip_at(_D,30),_D]   # A B C D
CHIP_HC=npx(6)
CHIP_DROP=tuple((p[0],p[1]+CHIP_HC) for p in (CHIP_TOP[0],CHIP_TOP[3],CHIP_TOP[2]))   # A', D', C'
CHIP_LEGS=[(CHIP_A[0]+npx(3),),(CHIP_A[0]+npx(8),)],[(_D[0]+npx(3+5*k),) for k in range(6)]
CHIP_MARK=sxy((20.07,57.79)),(1.05,.55)   # the small ring on the chip's top face (art: 1.08 x 0.55)
LEG_L,LEG_W=npx(5),npx(2)   # v8: whole pixels (were 4.2, 1.7)
def chip_lines():
    """-> [(points, closed)]: top face, three vertical edges, two bottom edges, eight U-shaped legs."""
    A,B,C,D=CHIP_TOP;A2,D2,C2=CHIP_DROP
    out=[(CHIP_TOP,True),([A,A2,D2,C2,C],False),([D,D2],False)]
    for (p0,p1),xs in zip(((A2,D2),(D2,C2)),CHIP_LEGS):
        def y(x):return p0[1]+(x-p0[0])*(p1[1]-p0[1])/(p1[0]-p0[0])
        for (x,) in xs:
            l,r=x-LEG_W/2,x+LEG_W/2
            out.append(([(l,y(l)),(l,y(l)+LEG_L),(r,y(r)+LEG_L),(r,y(r))],False))
    return out
def ink_labels(a,report=False):
    """Each pixel's colour index (-1 = no ink): chromatic direction with a half-strength boundary, then coherent()."""
    direction=PALETTE/np.linalg.norm(PALETTE,axis=1)[:,None]
    unit=a/np.maximum(np.linalg.norm(a,axis=2)[:,:,None],1)
    labels=np.argmax(np.einsum('...c,kc->...k',unit,direction),axis=2)
    ink=np.full(labels.shape,-1)
    for i,col in enumerate(PALETTE):
        ink[(labels==i)&(np.einsum('...c,c->...',a,col)/sum(col*col)>.5)]=i
    ink,cleaned=coherent(ink)
    return (ink,cleaned) if report else ink
def line_mask(a,ink):
    """White and blue line ink as one mask: bright enough to be a line core, green/red and their edge left out."""
    m=a.max(2)>LINE_INK
    m&=~nd.binary_dilation((ink==2)|(ink==3),iterations=2)
    lab,n=nd.label(m,np.ones((3,3)));sizes=np.bincount(lab.ravel());return m&(sizes[lab]>=40)
FILL_W=0.9   # v5: the note icons and dashes (the green and red fills) widened to at least this, as the lines (was 1.6)
KEY_TOP_MARGIN=1.6   # units around a green/red key's top and body whose green/red ink is dropped (v5: those tops are strokes)
def without_key_tops(ink):
    """v5: the green and red keys and the dashes are drawn as strokes; their traced fills go (the note icons stay)."""
    m=np.zeros(ink.shape,np.uint8)
    for n,col in KEYS:
        if col=='blue':continue
        k=key_points(n);poly=np.array([[(x*UNIT),((y+4)*UNIT)] for x,y in (k['L'],k['T'],k['R'],k['R2'],k['B2'],k['L2'])],np.int32)
        cv2.fillPoly(m,[poly],1)
    for col,x,ys in DASHES:   # the dash columns, below their cube
        cv2.rectangle(m,(int((x-.6)*UNIT),int((ys[0][0]-.6+4)*UNIT)),(int((x+.6)*UNIT),int((ys[-1][1]+4)*UNIT)),1,-1)
    m=nd.binary_dilation(m,iterations=int(round(KEY_TOP_MARGIN*UNIT)))
    out=ink.copy();out[m&(ink>=2)]=-1;return out
# Caller supplies the root reference because kennel is a separate repository.
def hexcol(i):return '#'+''.join(f'{int(v):02x}' for v in PALETTE[i])
def emit(s):
    if s.circle:
        (cx,cy),r=s.circle  # (none since v5: pads are ellipse paths)
        return f'<circle cx="{cx:.2f}" cy="{cy:.2f}" r="{r:.2f}" fill="none" stroke="{hexcol(s.colour)}" stroke-width="{s.width:.2f}"/>'
    return shape(s.pts,hexcol(s.colour),s.width,s.closed)
def generate(source,output):
    a=np.asarray(Image.open(source).convert('RGB')).astype(float)
    if a.shape[:2]!=(887,1774):raise ValueError('expected exact generated 1774x887 canvas')
    ink,cleaned=ink_labels(a,True)
    ink=without_key_tops(ink)
    out=['<svg xmlns="http://www.w3.org/2000/svg" width="320" height="160" viewBox="0 0 320 160">']
    fills=[(i,pieces(fill_pinholes(minimum_width(ink==i,FILL_W),(ink>=0)&(ink!=i),cleaned).astype(np.uint8)*255,i)) for i in (2,3)]
    lines=strokes()
    out+=[emit(s) for s in lines]
    counts=[sum(s.colour==c for s in lines) for c in range(4)];vertex_counts=[]   # strokes white, blue, green, red
    for i,ps in fills:
        emitted=0
        for piece in ps:
            for xy,depth in piece:
                out.append(shape(xy,'none',0,True,hexcol(i) if depth%2==0 else '#010101'));emitted+=1;vertex_counts.append(len(xy))
        counts.append(emitted)
    assert sum(counts)<=445, 'native path budget exceeded'
    assert sum(vertex_counts)+sum(len(s.pts) for s in lines)<=7253, 'native vertex budget exceeded'
    out.append('</svg>');Path(output).write_text(lighten(compact_svg('\n'.join(out)+'\n'),tol=LITE_TOL,step=STEP,note='c64arp gen_svg.py, made lighter by display/svg_lite.py')[0])
    print(json.dumps({'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),'canvas':[1774,887],'mapping':320/1774,'palette':PALETTE.tolist(),'elements':{'strokes (white, blue, green, red)':counts[:4],'fills (green, red)':counts[4:],'total':sum(counts)},'cleanup':cleaned,'stroke_vertices':sum(len(s.pts) for s in lines),'fill_vertices':sum(vertex_counts)}))
if __name__=='__main__':generate(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else HERE/'c64arp.svg')
