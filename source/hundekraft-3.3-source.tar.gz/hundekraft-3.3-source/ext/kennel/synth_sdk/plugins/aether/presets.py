#!/usr/bin/env python3
"""Aether: sound presets as OP-1 patch files (the pack had none before 2026-11-15).
    python3 synth_sdk/plugins/aether/presets.py [OUT_DIR]     -> OUT_DIR/*.aif (default: presets/ next to this script)

Saved type "aether"; knobs[4] = 0x5300 + 10 (aether's order, ORDERS.md). Knobs (aether.c): blue range at full tilt
(1..24 semitones), green timbre (sine .. reedy), white shake vibrato, red volume tilt; page-2 words 5 dead zone
(0..10 degrees), 6 tilt for the full range (20..60 degrees), 7 vibrato rate (3..8 Hz). Words 5-7 read 0 as unset
(8192), so the lowest value written is 1. Aether has no hidden level trim (word 7 is the vibrato rate).
The OP-1 envelope (T2), FX and LFO shape most of the difference between sounds at rest; the tilt settings set how
each one plays. Level: host render (dry, flat OP-1) of a held C4, a melody and a C major triad, max momentary
loudness within 2 dB of the default patch (run/presets-12-2026-11-15/a in the root project); native check open.
Every value stays inside the factory presets' ranges (root tools/op1r_presets.py): outside them the firmware
imports the file as a plain sample.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json
import math
import struct
import sys
from pathlib import Path

SELECTOR = 0x5300 + 10
RANGE_ADSR = [(64, 16320), (64, 16320), (0, 32767), (64, 16320)]
RANGE_FX = {
    "delay": [(3392, 11200), (4969, 32767), (0, 16384), (1332, 32767)],
    "spring": [(1344, 16448), (9920, 16448), (0, 16384), (2047, 26120)],
    "phone": [(8286, 20480), (3072, 3968), (1536, 7776), (7168, 17408)],
    "nitro": [(64, 5952), (-31744, 23552), (0, 20643), (6976, 16448)],
    "cwo": [(0, 22527), (0, 29055), (0, 32767), (0, 32767)],
    "grid": [(1344, 12824), (1344, 13752), (13392, 28165), (6854, 32767)],
    "punch": [(5672, 11538), (0, 28315), (5952, 25088), (13569, 32767)],
}
RANGE_LFO = {"tremolo": [(2289, 29816), (-32767, 32767), (-18663, 32767), (0, 32767)]}


def range_word(st):
    """blue: 1 + word * 23 / 32768 semitones"""
    return min(32767, round((st - 1) * 32768 / 23))


def pct(p):
    return round(p * 32767 / 100)


def page(v, lo, hi):
    """a page-2 word for v in lo..hi (never 0: 0 reads as unset)"""
    return max(1, min(32767, round((v - lo) * 32767 / (hi - lo))))


# name, range st, timbre %, vibrato %, volume tilt %, dead zone deg, full tilt deg, vibrato Hz, ADSR, FX, LFO, octave
# Release words (2026-11-15): R246 reads the release word inverted (rate table 0x7F - (v >> 7), audio-graph.md): HIGH
# release = SHORT. To -60 dB: 4800 = 2.9 s, 6000 = 2.1 s, 10400 = 0.9 s, 13500 = 0.4 s, 15000 = 0.2 s. Pads and drones
# sit at 3600..8000, leads and keys at 7000..13500, basses, plucks, stabs and organs at 13500..16320.
PRESETS = [
    ("theremin",    12,   8, 60, 100, 2.5, 30, 5.5, (1800, 9000, 30000, 10300),
     ("spring", [12000, 14000, 6000, 12000]), None, 0),
    #   the classic: near sine, wide bends, shake for vibrato, tip right to fade
    ("ondes",        7,  30, 45,  80, 2.0, 35, 6.0, (900, 8000, 28000, 11300),
     ("delay", [9000, 16000, 8000, 12000]), None, 0),
    #   a rounder singing tone with a fifth of bend
    ("reed lead",    5,  75, 35,  60, 3.0, 30, 5.0, (200, 7000, 26000, 12800),
     ("delay", [6000, 18000, 9000, 9000]), None, 0),
    #   reedy, quick attack, a small bend for phrasing
    ("sub bass",     2,  45,  0,   0, 6.0, 40, 4.25, (64, 6000, 30000, 14800), None, None, -1),
    #   low and steady: wide dead zone, no volume tilt
    ("whistle",      3,   0, 80,  70, 2.0, 30, 7.0, (600, 8000, 28000, 12300),
     ("delay", [10000, 20000, 8000, 14000]), None, 1),
    #   pure sine up high, fast shake vibrato
    ("siren",       24,  65, 30, 100, 0.0, 20, 4.0, (400, 9000, 32767, 7000),
     ("cwo", [6000, 12000, 18000, 20000]), None, 0),
    #   two octaves of swoop on a short tilt
    ("cello bow",    2,  55, 70,  40, 3.0, 40, 5.0, (3500, 9000, 30000, 10300),
     ("spring", [8000, 12000, 8000, 12000]), None, 0),
    #   slow bowed swell with a warm vibrato
    ("glass pad",    1,  15, 20,  50, 5.0, 45, 3.5, (9000, 12000, 26000, 4300),
     ("spring", [16448, 15000, 2000, 10239]), ("tremolo", [2500, 5000, 2000, 2000]), 0),
    #   slow swell, long tail, gentle tremolo
    ("soft pluck",   2,  35,  0,  30, 5.0, 40, 4.25, (64, 4000, 0, 13500),
     ("delay", [9000, 22000, 12000, 20000]), None, 0),
    #   short plucked notes into a long echo
    ("still organ",  1, 100,  0,   0, 10.0, 60, 4.25, (64, 9000, 32767, 15100),
     ("punch", [6000, 8000, 12000, 18000]), None, 0),
    #   full reed, tilt barely matters: play it as keys
    ("radio ghost",  7,  40, 50, 100, 2.0, 25, 6.5, (1200, 9000, 28000, 8000),
     ("phone", [10536, 3968, 7776, 17408]), None, 0),
    #   a far-away voice through a small speaker
    ("growl bass",   5, 100, 20,  30, 3.0, 30, 5.0, (64, 7000, 26000, 13800),
     ("nitro", [1000, 3000, 14000, 9000]), None, -1),
    #   driven reed an octave down, bend for slides
]


def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def aifc(meta):
    comm = struct.pack(">hIh", 1, 0, 16) + ieee_extended(44100) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    js = json.dumps(meta, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + chunk(b"APPL", b"op-1" + js)
            + chunk(b"SSND", struct.pack(">II", 0, 0)))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


def check(name, what, values, ranges):
    for i, (v, (lo, hi)) in enumerate(zip(values, ranges)):
        if not lo <= v <= hi:
            raise ValueError(f"{name}: {what}[{i}] = {v} is outside {lo}..{hi}")


def knobs(p):
    name, st, tim, vib, vol, dead, full, hz = p[:8]
    return [range_word(st), pct(tim), pct(vib), pct(vol), SELECTOR,
            page(dead, 0, 10), page(full, 20, 60), page(hz, 3, 8)]


def meta(p):
    name, adsr, fx, lfo, octave = p[0], p[8], p[9], p[10], p[11]
    k = knobs(p)
    check(name, "knobs", k, [(0, 32767)] * 8)
    check(name, "adsr", list(adsr), RANGE_ADSR)
    if fx:
        check(name, "fx " + fx[0], fx[1], RANGE_FX[fx[0]])
    if lfo:
        check(name, "lfo " + lfo[0], lfo[1], RANGE_LFO[lfo[0]])
    if not -1 <= octave <= 2:
        raise ValueError(f"{name}: octave {octave}")
    return {
        "adsr": list(adsr) + [2048, 5568, 4000, 4000],
        "fx_active": fx is not None,
        "fx_params": (fx or ("delay", [8000] * 4))[1] + [0, 0, 0, 0],
        "fx_type": (fx or ("delay", None))[0],
        "knobs": k,
        "lfo_active": lfo is not None,
        "lfo_params": (lfo or ("tremolo", [16000, 0, 0, 16000]))[1] + [0, 0, 0, 0],
        "lfo_type": (lfo or ("tremolo", None))[0],
        "name": name,
        "octave": octave,
        "synth_version": 2,
        "type": "aether",
    }


def main():
    if len(sys.argv) > 2:
        sys.exit(__doc__)
    out = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parent / "presets"
    out.mkdir(parents=True, exist_ok=True)
    names = [p[0] for p in PRESETS]
    assert len(set(names)) == len(names) and all(len(n) <= 14 for n in names)
    for p in PRESETS:
        (out / (p[0] + ".aif")).write_bytes(aifc(meta(p)))
    print(f"{len(PRESETS)} presets in {out}")


if __name__ == "__main__":
    main()
