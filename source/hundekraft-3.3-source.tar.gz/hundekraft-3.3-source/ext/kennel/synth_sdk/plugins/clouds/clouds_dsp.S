/* Clouds' inner sample loops, hand-scheduled for the Blackfin: the same arithmetic as clouds_dsp.c's C loops (the
 * shipping build: CLOUDS_FAST_GRAINS, CLOUDS_BLOCK_MIX, CLOUDS_QUARTER_REVERB), bit for bit, in fewer packets.
 *
 * void cl_grain(int32_t *o, const int16_t *base, int32_t ph, int32_t inc, int32_t g0, int32_t dg, int m)
 *   one grain chunk that does not wrap the recording buffer (grain_overlap_add's CLOUDS_FAST_GRAINS loop), m >= 1:
 *   for j < m: r = base + (ph >> 16); s = r[0] + (((r[1] - r[0]) * ((ph & 65535) >> 1)) >> 15);
 *              o[j] += (s * gn) >> 15; gn += dg; ph += inc   (gn starts at g0)
 *   Needs every gn of the chunk within int16 (g0, g1 in 0 .. 23170 by construction, so the ramp stays there): the
 *   gains run as 16-bit pairs. s is the linear interpolation as one fractional sum r0 (32767 - f) + r1 f + r0, all
 *   products doubled, its truncated high half; (s * gn) >> 15 is the doubled product's high half. With (ph | inc) &
 *   65535 == 0 (pitch at a whole octave, the default) f stays 0 and s = r[0]: a pair of samples in 6 packets,
 *   else 20 (the four reads straight into the halves of two words through I0 / I1).
 *
 * Host builds assemble it empty: clouds_dsp.c keeps the C loops there (and as the reference, kern_check.py).
 * Clouds: Mutable Instruments Clouds (c) 2014 Emilie Gillet, MIT license; this port: see clouds_dsp.h.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifdef __bfin__
	.text

	.align 4
	.global _cl_grain
	.type _cl_grain, STT_FUNC
_cl_grain:
	[--SP] = (R7:4, P5:3);              /* 7 words: inc, g0, dg, m at SP + 28 + 12 .. */
	SP += -16;                          /* the fractional loop's words: inc, 0x7FFF7FFF, 0x00010001, dg pair */
	P5 = R1;                            /* base */
	P2 = R0;                            /* o */
	R6 = R2;                            /* ph */
	R5 = [SP + 56];                     /* inc */
	R3 = [SP + 60];                     /* g0 */
	R4 = [SP + 64];                     /* dg */
	R7 = [SP + 68];                     /* m */
	[SP] = R5;
	R0 = R3 + R4 (NS);
	R2 = R4 + R4 (NS);
	R4 = PACK(R0.L, R3.L);              /* gn pair: g0 + dg | g0 */
	R2 = PACK(R2.L, R2.L);              /* 2 dg | 2 dg (mod 2^16: the sums stay within int16) */
	[SP + 12] = R2;
	R3 = R7 >> 1;
	P4 = R3;                            /* pairs */
	R7 <<= 31;
	P3 = R7;                            /* odd m: nonzero */
	R3 = R5 | R6;
	R3 <<= 16;
	CC = R3 == 0;
	IF !CC JUMP .Lfrac;

	/* whole-sample steps: s = r[0], the read pointer steps 2 (inc >> 16) bytes */
	I0 = P2;                            /* o: reads */
	I1 = P2;                            /* o: writes */
	L0 = 0;
	L1 = 0;
	R5 = R2;                            /* dg pair */
	R0 = R6 >>> 16;
	R0 <<= 1;
	R1 = P5;
	R0 = R0 + R1;
	I2 = R0;
	L2 = 0;
	R0 = [SP];
	R0 >>>= 16;
	R0 <<= 1;
	M0 = R0;
	CC = P4 == 0;
	IF CC JUMP .Lint_tail;
	R0.L = W[I2];                       /* the first pair's samples (each pass reads the next pair's) */
	I2 += M0;
	R0.H = W[I2];
	I2 += M0;
	LSETUP(.Lint_a, .Lint_b) LC0 = P4;
.Lint_a:
	R3 = (A1 = R0.H * R4.H), R2 = (A0 = R0.L * R4.L) || R6 = [I0++] || NOP;
	R2 = R2 >>> 16 || R0.L = W[I2] || R7 = [I0++];
	R3 = R3 >>> 16 || I2 += M0 || NOP;
	R2 = R2 + R6 (NS) || R0.H = W[I2] || NOP;
	R3 = R3 + R7 (NS) || I2 += M0 || [I1++] = R2;
.Lint_b:
	R4 = R4 +|+ R5 || [I1++] = R3 || NOP;
	/* the tail sample is the one the last pass read into R0.L */
	CC = P3 == 0;
	IF CC JUMP .Lout;
	R2 = (A0 = R0.L * R4.L);
	R2 >>>= 16;
	R6 = [I0];
	R2 = R2 + R6 (NS);
	[I1] = R2;
	JUMP .Lout;
.Lint_tail:                             /* m = 1 */
	R0.L = W[I2];
	R2 = (A0 = R0.L * R4.L);
	R2 >>>= 16;
	R6 = [I0];
	R2 = R2 + R6 (NS);
	[I1] = R2;
	JUMP .Lout;

	/* fractional steps: r[0] and r[1] per sample, both samples' pairs read into the halves of R0 and R1 through
	 * I0 / I1 (address 2 ((ph >> 16) + base / 2)); the words cycle through I3 */
.Lfrac:
	I2 = P2;                            /* o: reads */
	P1 = P2;                            /* o: writes */
	L0 = 0;
	L1 = 0;
	L2 = 0;
	R0.L = 0x7FFF;
	R0.H = 0x7FFF;
	[SP + 4] = R0;
	R0 = 0x0001 (Z);
	R0.H = 0x0001;
	[SP + 8] = R0;
	R5 = P5;
	R5 >>= 1;                           /* base / 2 */
	I3 = SP;
	B3 = SP;
	R0 = 16 (Z);
	L3 = R0;
	CC = P4 == 0;
	IF CC JUMP .Lfrac_tail;
	LSETUP(.Lfrac_a, .Lfrac_b) LC0 = P4;
.Lfrac_a:
	R0 = R6 >>> 16 || R2 = [I3++] || NOP;                   /* inc */
	R0 = (R0 + R5) << 1;
	I0 = R0;
	R7 = R6 + R2 (NS);                  /* ph of the pair's second sample */
	R1 = R7 >>> 16;
	R1 = (R1 + R5) << 1;
	I1 = R1;
	R3 = PACK(R7.L, R6.L) || R0.L = W[I0++] || R0.H = W[I1++];       /* r0 pair */
	R6 = R7 + R2 (NS) || R1.L = W[I0] || R1.H = W[I1];               /* r1 pair */
	R3 = R3 >> 1 (V) || R2 = [I3++] || R7 = [I2++];                  /* f pair; 0x7FFF7FFF; o[j] */
	R2 = R2 -|- R3;                                                  /* 32767 - f pair */
	A1 = R0.H * R2.H, A0 = R0.L * R2.L || R2 = [I3++] || NOP;        /* 0x00010001 */
	A1 += R1.H * R3.H, A0 += R1.L * R3.L || R3 = [I2++] || NOP;      /* o[j + 1] */
	R1.H = (A1 += R0.H * R2.H), R1.L = (A0 += R0.L * R2.L) (T) || R2 = [I3++] || NOP;   /* s pair; dg pair */
	R1 = (A1 = R1.H * R4.H), R0 = (A0 = R1.L * R4.L);
	R0 = R0 >>> 16;
	R1 = R1 >>> 16;
	R0 = R0 + R7 (NS);
	R1 = R1 + R3 (NS) || [P1++] = R0 || NOP;
.Lfrac_b:
	R4 = R4 +|+ R2 || [P1++] = R1 || NOP;
.Lfrac_tail:
	L3 = 0;
	CC = P3 == 0;
	IF CC JUMP .Lout;
	R0 = R6 >>> 16;
	R0 = (R0 + R5) << 1;
	I0 = R0;
	R3 = R6 >> 1 (V);
	R0.L = W[I0++];
	R1.L = W[I0];
	R2 = [SP + 4];
	R2 = R2 -|- R3;
	A0 = R0.L * R2.L;
	A0 += R1.L * R3.L;
	R7 = [SP + 8];
	R2.L = (A0 += R0.L * R7.L) (T);
	R0 = (A0 = R2.L * R4.L);
	R0 >>>= 16;
	R2 = [I2];
	R0 = R0 + R2 (NS);
	[P1] = R0;
.Lout:
	SP += 16;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _cl_grain, .-_cl_grain

/* void cl_mix(int16_t *output, const int16_t *input, const int32_t *w, const cl_mix_t *a)
 *   a = { sl: cl_soft_limit + 2048, f, d, n }
 *   the dry / wet mix (clouds_process, CLOUDS_BLOCK_MIX): f = fi << 16 | fo, d = dfi << 16 | dfo (16-bit lanes; fi
 *   0 .. 39322, fo 0 .. 32767 over the block); for i < n: f += d;
 *   x = ((input * fo) >> 15) + mulq15(w, fi); output = clip16(soft_limit(x)), soft_limit as the C: the
 *   table at x clamped to -262144 .. 262143 (beyond that the C's ends clip the same). mulq15(w, fi) =
 *   2 (w >> 16) fi + ((w & 65535) fi >> 15); the table lookup's index and fraction from x << 13 (saturated). */
.macro MIX_FRONT                       /* after f += d and the loads of input (R0.L) and w (R1) */
	R2 = (A0 = R0.L * R7.L) (IS);       /* input * fo */
	R3 = (A1 = R1.H * R7.H) (M, IS);    /* (w >> 16) fi, doubled below */
	R0 = (A0 = R1.L * R7.H) (IU);       /* (w & 65535) fi */
	R2 = R2 >>> 15;
	R0 = R0 >> 15;
	R0 = R0 + R2 (NS);
	R3 = R3 << 1 (S);
	R0 = R0 + R3 (NS);                  /* x */
	R0 = R0 << 13 (S);                  /* x clamped to 19 bits, << 13 */
	R1 = R0 >>> 20;                     /* k - 2048 */
	P0 = R1;
	P0 = P5 + (P0 << 2);
	R4 = R0 << 12 || R6 = [P0] || R2 = [I3];        /* frac << 25; sl[k]; d */
.endm

	.align 4
	.global _cl_mix
	.type _cl_mix, STT_FUNC
_cl_mix:
	[--SP] = (R7:4, P5:5);
	I2 = R0;                            /* output */
	I0 = R1;                            /* input */
	I1 = R2;                            /* w */
	L0 = 0;
	L1 = 0;
	L2 = 0;
	L3 = 0;
	P0 = [SP + 32];                     /* a */
	P5 = [P0];
	R7 = [P0 + 4];
	I3 = P0;
	P1 = [P0 + 12];
	I3 += 4;
	I3 += 4;                            /* &a->d */
	R2 = [I3];
	/* sample 0's front half: x, the table index and fraction, sl[k] (and d for the next) */
	R7 = R7 +|+ R2 || R0.L = W[I0++] || R1 = [I1++];
	MIX_FRONT
	P1 += -1;
	CC = P1 == 0;
	IF CC JUMP .Lmix_last;
	LSETUP(.Lmix_a, .Lmix_b) LC0 = P1;
.Lmix_a:
	/* sample i's front half, sample i - 1's back half (y = sl[k] + ((sl[k + 1] - sl[k]) frac) >> 7, clip16) */
	R7 = R7 +|+ R2 || R5 = [P0 + 4] || R0.L = W[I0++];
	R5 = R5 - R6 (NS) || R1 = [I1++] || NOP;
	R2 = (A0 = R0.L * R7.L) (IS);
	R3 = (A1 = R1.H * R7.H) (M, IS);
	R5 = (A1 = R5.L * R4.H) (M, IS);
	R0 = (A0 = R1.L * R7.H) (IU);
	R5 = R5 >>> 16;
	R2 = R2 >>> 15;
	R6 = R6 + R5 (NS);
	R0 = R0 >> 15;
	R6 = R6 << 16 (S);
	R0 = R0 + R2 (NS) || W[I2++] = R6.H || NOP;
	R3 = R3 << 1 (S);
	R0 = R0 + R3 (NS);
	R0 = R0 << 13 (S);
	R1 = R0 >>> 20;
	P0 = R1;
	P0 = P5 + (P0 << 2);
.Lmix_b:
	R4 = R0 << 12 || R6 = [P0] || R2 = [I3];
.Lmix_last:
	R5 = [P0 + 4];
	R5 = R5 - R6 (NS);
	R5 = (A1 = R5.L * R4.H) (M, IS);
	R5 = R5 >>> 16;
	R6 = R6 + R5 (NS);
	R6 = R6 << 16 (S);
	W[I2++] = R6.H;
	(R7:4, P5:5) = [SP++];
	RTS;
	.size _cl_mix, .-_cl_mix

/* int32_t cl_norm(int32_t *out, int32_t g, int32_t gn, int n): play_granular's normalization, g and gn within 1 .. 65535
 *   for t < n: g += ((gn - g) * 328) >> 15; out[t] = mulq15(out[t], g); returns g. g stays within 0 .. 65535 (it
 *   steps toward gn and can end 1 short of it), so mulq15 = 2 (out >> 16) g + ((out & 65535) g >> 15), g unsigned. */
	.align 4
	.global _cl_norm
	.type _cl_norm, STT_FUNC
_cl_norm:
	[--SP] = (R7:4);
	I0 = R0;
	I1 = R0;
	L0 = 0;
	L1 = 0;
	P1 = [SP + 28];                     /* n */
	R7 = 328 (X);
	LSETUP(.Lnorm_a, .Lnorm_b) LC0 = P1;
.Lnorm_a:
	R3 = R2 - R1 (NS) || R0 = [I0++] || NOP;
	R3 *= R7;
	R3 >>>= 15;
	R1 = R1 + R3 (NS);
	R5 = (A1 = R0.H * R1.L) (M, IS);
	R4 = (A0 = R0.L * R1.L) (IU);
	R4 = R4 >> 15;
	R4 = R4 + R5 (NS);
	R4 = R4 + R5 (NS);
.Lnorm_b:
	[I1++] = R4;
	R0 = R1;
	(R7:4) = [SP++];
	RTS;
	.size _cl_norm, .-_cl_norm

/* void cl_diffuse(int32_t *io, int32_t *db, int32_t wp, int32_t amount, int n): the diffuser (four allpasses in one
 *   2048-word ring, clouds_dsp.c diffuser()), wp = the first sample's write position (the C's wp after its first
 *   decrement), amount 1 .. 32767. K58(a) = (a * 5) >> 3 as (4a + a) >>> 3; io += mulq15(amount, acc - io) =
 *   2 ((x >> 16) amount) + ((x & 65535) amount >> 15) with x = acc - io. The ring in four circular pointers: I0
 *   reads line 3's tail (wp + 1021) and writes line 0 (wp); Ik (k = 1..3) reads line k - 1's tail (wp + 125, 306,
 *   576) and, 2 words on, writes line k (wp + 127, 308, 578). The eight words of a sample are all different and none
 *   is the next sample's, so the order inside a sample is free. M0 = 8, M2 = -12, M3 = -4084 (saved and restored). */
	.align 4
	.global _cl_diffuse
	.type _cl_diffuse, STT_FUNC
_cl_diffuse:
	[--SP] = (R7:4, P5:5);
	R7 = M0;
	R6 = M2;
	R5 = M3;
	[--SP] = R7;
	[--SP] = R6;
	[--SP] = R5;                        /* 5 + 3 words: amount, n at SP + 32 + 12 .. */
	P0 = R0;                            /* io */
	R7 = [SP + 44];                     /* amount */
	P1 = [SP + 48];                     /* n */
	B0 = R1;
	B1 = R1;
	B2 = R1;
	B3 = R1;
	R3 = 8192 (Z);
	L0 = R3;
	L1 = R3;
	L2 = R3;
	L3 = R3;
	R3 = 2047 (Z);
	R0 = 1021 (X);
	R0 = R0 + R2 (NS);
	R0 = R0 & R3;
	R0 <<= 2;
	R0 = R0 + R1;
	I0 = R0;
	R0 = 125 (X);
	R0 = R0 + R2 (NS);
	R0 = R0 & R3;
	R0 <<= 2;
	R0 = R0 + R1;
	I1 = R0;
	R0 = 306 (X);
	R0 = R0 + R2 (NS);
	R0 = R0 & R3;
	R0 <<= 2;
	R0 = R0 + R1;
	I2 = R0;
	R0 = 576 (X);
	R0 = R0 + R2 (NS);
	R0 = R0 & R3;
	R0 <<= 2;
	R0 = R0 + R1;
	I3 = R0;
	M0 = 8 (X);
	M2 = -12 (X);
	R0 = -4084 (X);
	M3 = R0;
	LSETUP(.Ldif_a, .Ldif_b) LC0 = P1;
.Ldif_a:
	MNOP || R4 = [P0] || R3 = [I0 ++ M3];               /* io; line 3's tail */
	R1 = [I1 ++ M0];                                    /* line 0's tail */
	R2 = R1 << 2;
	R2 = R2 + R1 (NS);
	R2 = R2 >>> 3;
	R0 = R4 + R2 (NS);
	R2 = R0 << 2 || [I0--] = R0 || NOP;
	R2 = R2 + R0 (NS);
	R2 = -R2;
	R2 = R2 >>> 3;
	R0 = R2 + R1 (NS) || R1 = [I2 ++ M0] || NOP;        /* line 1's tail */
	R2 = R1 << 2;
	R2 = R2 + R1 (NS);
	R2 = R2 >>> 3;
	R0 = R0 + R2 (NS);
	R2 = R0 << 2 || [I1 ++ M2] = R0 || NOP;
	R2 = R2 + R0 (NS);
	R2 = -R2;
	R2 = R2 >>> 3;
	R0 = R2 + R1 (NS) || R1 = [I3 ++ M0] || NOP;        /* line 2's tail */
	R2 = R1 << 2;
	R2 = R2 + R1 (NS);
	R2 = R2 >>> 3;
	R0 = R0 + R2 (NS);
	R2 = R0 << 2 || [I2 ++ M2] = R0 || NOP;
	R2 = R2 + R0 (NS);
	R2 = -R2;
	R2 = R2 >>> 3;
	R0 = R2 + R1 (NS);
	R2 = R3 << 2;                                       /* line 3 */
	R2 = R2 + R3 (NS);
	R2 = R2 >>> 3;
	R0 = R0 + R2 (NS);
	R2 = R0 << 2 || [I3 ++ M2] = R0 || I0 -= M3;
	R2 = R2 + R0 (NS);
	R2 = -R2;
	R2 = R2 >>> 3;
	R0 = R2 + R3 (NS);
	R2 = R0 - R4 (NS);                                  /* x = acc - io */
	R5 = (A1 = R7.L * R2.L) (M, IS);
	R2 = (A0 = R2.H * R7.L) (IS);
	R5 = R5 >>> 15;
	R2 = R2 + R2 (NS);
	R2 = R2 + R5 (NS);
	R4 = R4 + R2 (NS);
.Ldif_b:
	[P0++] = R4;
	L0 = 0;
	L1 = 0;
	L2 = 0;
	L3 = 0;
	R5 = [SP++];
	R6 = [SP++];
	R7 = [SP++];
	M3 = R5;
	M2 = R6;
	M0 = R7;
	(R7:4, P5:5) = [SP++];
	RTS;
	.size _cl_diffuse, .-_cl_diffuse

/* void cl_reverb(cl_rev_t *a): reverb_quarter's loop for a->cnt (1 .. 16) passes without an LFO step, line by line
 *   a = { rb, wp0 (the first pass's write position, after its decrement), cnt, io (4 cnt words), i0, f0 (the smear
 *   read: QB0 + (off >> 16), off & 65535), i9, f9 (del2's), lp1, lp2, wo (updated), lp4, time, amount (0 .. 32767) }
 *   Every line reads words its own writes left at least 27 passes earlier (del1 852, del2 1159), except line 0, whose
 *   smear and allpass run in one pass in the C's order: so the block runs as nine passes over cnt, one line each,
 *   with the same results and the same buffer. Reads come from the mirrored ring directly, decrementing (a start
 *   index s < 32 moves to the upper copy, so no read leaves it); writes go to both copies through circular I
 *   registers (B = rb or rb + 8192, L = 8192).
 *   MQ(a, b) = floor(a b / 2^15) = 2 (a >> 16) b (fractional MAC) + (b (a & 65535)) >> 15 (mixed-mode MAC);
 *   VK(v, k) = (v k) >> 12; rv_enc(x) = sat16(trunc(x / 8)) as the high half of (x + ((x >>> 31) >> 29)) << 13 (S);
 *   qinterp = 8 v0 + floor((v1 - v0) f / 8192), (v1 f - v0 f) in A1. */

/* R0 = the read address for offset R0: rb + 2 s, s = (wp0 + R0) & 4095, + 4096 when s < 32 */
.macro RDADDR
	R1 = [P5 + 4];
	R0 = R0 + R1 (NS);
	R1 = 4095 (Z);
	R0 = R0 & R1;
	R1 = 32 (Z);
	CC = R0 < R1;
	IF !CC JUMP 1f;
	R1 = 4096 (Z);
	R0 = R0 + R1;
1:	R0 <<= 1;
	R1 = [P5];
	R0 = R0 + R1;
.endm
/* the two write pointers for offset R0: ilo in the lower copy, ihi in the upper (circular, 4096 words each) */
.macro WRSET ilo, ihi, blo, bhi, llo, lhi
	R1 = [P5 + 4];
	R0 = R0 + R1 (NS);
	R1 = 4095 (Z);
	R0 = R0 & R1;
	R0 <<= 1;
	R1 = [P5];
	\blo = R1;
	R0 = R0 + R1;
	\ilo = R0;
	R1 = 8192 (Z);
	\llo = R1;
	\lhi = R1;
	R0 = R0 + R1;
	\ihi = R0;
	R0 = [P5];
	R0 = R0 + R1;
	\bhi = R0;
.endm
/* R1.H = rv_enc(R2) */
.macro ENC
	R1 = R2 >>> 31;
	R1 = R1 >> 29;
	R1 = R1 + R2 (NS);
	R1 = R1 << 13 (S);
.endm
/* de = MQ(src, b) (de even, not R5; R5 clobbered; de may be src) */
.macro MQ de, src, b
	R5 = (A1 = \b * \src\().L) (M, IS);
	\de = (A0 = \src\().H * \b);
	R5 = R5 >>> 15;
	\de = \de + R5 (NS);
.endm
/* one allpass: R2 = acc in, R4 = acc out; v = [rd], acc += VK(v, k); write rv_enc(acc); acc = MQ(acc, mk) + 8 v */
.macro LINE rd, wlo, whi, k, mk
	R0 = W[\rd--] (X);
	R1 = (A1 = R0.L * \k) (IS);
	R1 = R1 >>> 12;
	R2 = R2 + R1 (NS);
	ENC
	R4 = (A0 = R2.H * \mk) || W[\wlo--] = R1.H || NOP;
	R5 = (A1 = \mk * R2.L) (M, IS) || W[\whi--] = R1.H || NOP;
	R5 = R5 >>> 15;
	R0 = R0 << 3;
	R4 = R4 + R5 (NS);
	R4 = R4 + R0 (NS);
.endm
/* a constant line pass over cnt: R2 from [P3++] (or as set), R4 to [P4++] */

	.align 4
	.global _cl_reverb
	.type _cl_reverb, STT_FUNC
_cl_reverb:
	[--SP] = (R7:4, P5:3);
	SP += -64;
	SP += -64;                          /* ap[16] at SP, x[16] at SP + 64 */
	P5 = R0;
	R7.L = 22938;                       /* kap */
	R7.H = -22938;
	L2 = 0;
	L3 = 0;
	P1 = [P5 + 8];                      /* cnt */

	/* pass 0: del2's interpolated read -> x. It reads up to 3..4 words below wp (4092 + 1 of 4096), which line 0
	 * writes 3..4 passes later: so it runs before pass A, as the C reads them before those writes */
	R0 = [P5 + 24];
	RDADDR
	R6 = [P5 + 28];                     /* f9 */
	P4 = SP;
	P4 += 32;
	P4 += 32;                           /* x */
	P1 = [P5 + 8];
	LSETUP(.Lrv0_a, .Lrv0_b) LC0 = P1;
	P1 = R0;
.Lrv0_a:
	R0 = W[P1 + 2] (X);
	R1 = W[P1--] (X);
	A1 = R0.L * R6.L (M, IS);
	A1 -= R1.L * R6.L (M, IS);
	A1 = A1 >>> 13;
	R5 = A1;
	R1 = R1 << 3;
	R0 = R5 + R1 (NS);
.Lrv0_b:
	[P4++] = R0;

	/* pass A: smear, input, line 0 -> ap */
	R0 = [P5 + 16];
	RDADDR
	P1 = R0;                            /* smear read */
	R0 = 27 (X);
	RDADDR
	P0 = R0;
	R0 = 25 (X);
	WRSET I0, I1, B0, B1, L0, L1
	R0 = 0 (X);
	WRSET I2, I3, B2, B3, L2, L3
	P2 = [P5 + 12];                     /* io */
	P3 = SP;                            /* ap */
	R6 = [P5 + 20];                     /* f0 */
	R6.H = 6554;                        /* gain */
	P4 = [P5 + 8];
	LSETUP(.Lrva_a, .Lrva_b) LC0 = P4;
.Lrva_a:
	R0 = W[P1 + 2] (X);
	R1 = W[P1--] (X);
	A1 = R0.L * R6.L (M, IS);
	A1 -= R1.L * R6.L (M, IS);
	A1 = A1 >>> 13;
	R5 = A1;
	R1 = R1 << 3;
	R2 = R5 + R1 (NS);                  /* smear */
	ENC
	MNOP || W[I0--] = R1.H || R0 = [P2++];
	MNOP || W[I1--] = R1.H || R1 = [P2++];
	R0 = R0 + R1 (NS) || R1 = [P2++] || NOP;
	R0 = R0 + R1 (NS) || R1 = [P2++] || NOP;
	R0 = R0 + R1 (NS);
	R0 = R0 >>> 1;
	MQ R2, R0, R6.H                     /* input * 0.2 */
	LINE P0, I2, I3, R7.L, R7.H
.Lrva_b:
	[P3++] = R4;

	/* passes B, C, D: lines 1..3 on ap */
.macro APASS qt, qb, k, mk
	R0 = \qt (X);
	RDADDR
	P0 = R0;
	R0 = \qb (X);
	WRSET I0, I1, B0, B1, L0, L1
	P3 = SP;
	P4 = SP;
	P2 = [P5 + 8];
	LSETUP(1f, 2f) LC0 = P2;
1:	R2 = [P3++];
	LINE P0, I0, I1, \k, \mk
2:	[P4++] = R4;
.endm
	APASS 69, 29, R7.L, R7.H
	APASS 130, 71, R7.L, R7.H
	APASS 231, 132, R7.L, R7.H

	/* pass E: del2 (x) * time + ap, lp1, line 4 -> x */
	R0 = 645 (X);
	RDADDR
	P0 = R0;
	R0 = 233 (X);
	WRSET I0, I1, B0, B1, L0, L1
	R6 = [P5 + 28];                     /* f9 */
	R0 = [P5 + 48];
	R6 = PACK(R0.L, R6.L);              /* time | f9 */
	R3 = [P5 + 32];                     /* lp1 */
	P3 = SP;
	P4 = SP;
	P4 += 32;
	P4 += 32;                           /* x */
	P1 = P4;
	P2 = [P5 + 8];
	LSETUP(.Lrve_a, .Lrve_b) LC0 = P2;
.Lrve_a:
	R0 = [P1++];                        /* del2 */
	MQ R2, R0, R6.H
	R0 = [P3++];
	R2 = R2 + R0 (NS);
	R0 = R2 - R3 (NS);
	R1 = [P5 + 44];                     /* lp4 */
	MQ R0, R0, R1.L
	R3 = R3 + R0 (NS);
	R2 = R3;
	LINE P0, I0, I1, R7.H, R7.L
.Lrve_b:
	[P4++] = R4;
	[P5 + 32] = R3;

	/* pass F: line 5 on x, del1 write, wet = 2 acc -> x */
	R0 = 1156 (X);
	RDADDR
	P0 = R0;
	R0 = 647 (X);
	WRSET I0, I1, B0, B1, L0, L1
	R0 = 1158 (X);
	WRSET I2, I3, B2, B3, L2, L3
	P3 = SP;
	P3 += 32;
	P3 += 32;
	P4 = P3;
	P2 = [P5 + 8];
	LSETUP(.Lrvf_a, .Lrvf_b) LC0 = P2;
.Lrvf_a:
	R2 = [P3++];
	LINE P0, I0, I1, R7.L, R7.H
	R2 = R4;
	ENC
	MNOP || W[I2--] = R1.H || NOP;
	R4 = R4 + R4 (NS) || W[I3--] = R1.H || NOP;
.Lrvf_b:
	[P4++] = R4;

	/* pass G: ap + VK(del1 tail, time), lp2, line 7 -> ap */
	R0 = 2010 (X);
	RDADDR
	P1 = R0;
	R0 = 2489 (X);
	RDADDR
	P0 = R0;
	R0 = 2012 (X);
	WRSET I0, I1, B0, B1, L0, L1
	R3 = [P5 + 36];                     /* lp2 */
	P3 = SP;
	P4 = SP;
	P2 = [P5 + 8];
	LSETUP(.Lrvg_a, .Lrvg_b) LC0 = P2;
.Lrvg_a:
	R0 = W[P1--] (X);
	R1 = (A1 = R0.L * R6.H) (IS);
	R1 = R1 >>> 12;
	R2 = [P3++];
	R2 = R2 + R1 (NS);
	R0 = R2 - R3 (NS);
	R1 = [P5 + 44];
	MQ R0, R0, R1.L
	R3 = R3 + R0 (NS);
	R2 = R3;
	LINE P0, I0, I1, R7.L, R7.H
.Lrvg_b:
	[P4++] = R4;
	[P5 + 36] = R3;

	/* pass H: line 8 on ap, del2 write */
	R0 = 2906 (X);
	RDADDR
	P0 = R0;
	R0 = 2491 (X);
	WRSET I0, I1, B0, B1, L0, L1
	R0 = 2908 (X);
	WRSET I2, I3, B2, B3, L2, L3
	P3 = SP;
	P2 = [P5 + 8];
	LSETUP(.Lrvh_a, .Lrvh_b) LC0 = P2;
.Lrvh_a:
	R2 = [P3++];
	LINE P0, I0, I1, R7.H, R7.L
	R2 = R4;
	ENC
	MNOP || W[I2--] = R1.H || NOP;
.Lrvh_b:
	MNOP || W[I3--] = R1.H || NOP;

	/* pass I: the wet signal back to the full rate, into io */
	P3 = SP;
	P3 += 32;
	P3 += 32;
	P2 = [P5 + 12];
	R3 = [P5 + 40];                     /* wo */
	R7 = [P5 + 52];                     /* amount */
	P1 = [P5 + 8];
	LSETUP(.Lrvi_a, .Lrvi_b) LC0 = P1;
.Lrvi_a:
	R2 = [P3++];                        /* wet */
	R0 = R2 - R3 (NS);
	R0 >>>= 2;                          /* dw */
	R4 = [P2];
	R1 = R3 + R0 (NS);
	R1 = R1 - R4 (NS);
	MQ R6, R1, R7.L
	R4 = R4 + R6 (NS);
	[P2++] = R4;
	R4 = [P2];
	R1 = R3 + R0 (NS);
	R1 = R1 + R0 (NS);
	R1 = R1 - R4 (NS);
	MQ R6, R1, R7.L
	R4 = R4 + R6 (NS);
	[P2++] = R4;
	R4 = [P2];
	R1 = R2 - R0 (NS);
	R1 = R1 - R4 (NS);
	MQ R6, R1, R7.L
	R4 = R4 + R6 (NS);
	[P2++] = R4;
	R4 = [P2];
	R1 = R2 - R4 (NS);
	MQ R6, R1, R7.L
	R4 = R4 + R6 (NS);
	[P2++] = R4;
.Lrvi_b:
	R3 = R2;
	[P5 + 40] = R3;

	L0 = 0;
	L1 = 0;
	L2 = 0;
	L3 = 0;
	SP += 32;
	SP += 32;
	SP += 32;
	SP += 32;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _cl_reverb, .-_cl_reverb

/* int cl_seed(uint32_t *st, int cnt, uint32_t thr, int32_t space, int det): play_granular's per-sample seeding tests
 *   while nothing else can seed (no trigger, not every sample): st = { rng, phasor }; for i < cnt: phasor += 256,
 *   rng = rng * 1664525 + 1013904223; a seed when rng < thr (unsigned) or, with det, phasor >= space (signed).
 *   Returns the seed's i (st holds that sample's state) or cnt (st after the cnt samples). i = cnt - LC0 inside the
 *   loop (LC0 counts the passes left, this one included). 5 packets per sample (8 with the phasor test). */
	.align 4
	.global _cl_seed
	.type _cl_seed, STT_FUNC
_cl_seed:
	[--SP] = (R7:4);
	P0 = R0;
	P1 = R1;
	R7 = [SP + 28];                     /* space */
	R0 = [SP + 32];                     /* det */
	R3 = [P0];                          /* rng */
	R4 = [P0 + 4];                      /* phasor */
	R5.L = 0x660D;
	R5.H = 0x0019;                      /* 1664525 */
	R6.L = 0xF35F;
	R6.H = 0x3C6E;                      /* 1013904223 */
	CC = R1 <= 0;
	IF CC JUMP .Lseed_end;
	CC = R0 == 0;
	R0 = 256 (Z);
	IF CC JUMP .Lseed_p;
	LSETUP(.Lseed_da, .Lseed_db) LC0 = P1;
.Lseed_da:
	R3 *= R5;
	R3 = R3 + R6 (NS);
	R4 = R4 + R0 (NS);
	CC = R3 < R2 (IU);
	IF CC JUMP .Lseed_hit;
	CC = R7 <= R4;
	IF CC JUMP .Lseed_hit;
.Lseed_db:
	NOP;                                /* (a loop does not end on a branch) */
	JUMP .Lseed_end;
.Lseed_p:                               /* no phasor test: the phasor steps after the generator's test */
	LSETUP(.Lseed_pa, .Lseed_pb) LC0 = P1;
.Lseed_pa:
	R3 *= R5;
	R3 = R3 + R6 (NS);
	CC = R3 < R2 (IU);
	IF CC JUMP .Lseed_hitp;
.Lseed_pb:
	R4 = R4 + R0 (NS);
.Lseed_end:
	[P0] = R3;
	[P0 + 4] = R4;
	R0 = R1;                            /* cnt: no seed */
	(R7:4) = [SP++];
	RTS;
.Lseed_hitp:
	R4 = R4 + R0 (NS);
.Lseed_hit:
	[P0] = R3;
	[P0 + 4] = R4;
	R0 = LC0;
	R0 = R1 - R0;
	R2 = 0;
	LC0 = R2;                           /* the loop left early: disarmed */
	(R7:4) = [SP++];
	RTS;
	.size _cl_seed, .-_cl_seed

/* void cl_rec(int16_t *dst, const int16_t *src, int n): buf_write_fade's plain write, dst[i] = clip16((src[i] * 32767)
 *   >> 15), as the truncated high half of the doubled product (src is int16, so the clip never acts); a pair per three
 *   packets. Reads up to two words past src[n - 1]. */
	.align 4
	.global _cl_rec
	.type _cl_rec, STT_FUNC
_cl_rec:
	I0 = R1;
	I1 = R0;
	L0 = 0;
	L1 = 0;
	R3.L = 0x7FFF;
	R3.H = 0x7FFF;
	R1 = R2 >> 1;
	P1 = R1;
	R2 <<= 31;
	R0.L = W[I0++];
	R0.H = W[I0++];
	CC = P1 == 0;
	IF CC JUMP .Lrec_odd;
	LSETUP(.Lrec_a, .Lrec_b) LC0 = P1;
.Lrec_a:
	R1.H = (A1 = R0.H * R3.H), R1.L = (A0 = R0.L * R3.L) (T) || R0.L = W[I0++] || NOP;
	MNOP || W[I1++] = R1.L || R0.H = W[I0++];
.Lrec_b:
	MNOP || W[I1++] = R1.H || NOP;
.Lrec_odd:
	CC = R2 == 0;
	IF CC JUMP .Lrec_end;
	R1.L = (A0 = R0.L * R3.L) (T);
	W[I1] = R1.L;
.Lrec_end:
	RTS;
	.size _cl_rec, .-_cl_rec
#endif
