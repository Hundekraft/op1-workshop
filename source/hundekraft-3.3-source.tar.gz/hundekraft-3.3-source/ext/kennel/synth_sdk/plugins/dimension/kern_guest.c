/* DIMENSION's Blackfin filter kernel (dimension_svf.S) against its C loop on bcore (kern_check.py): dimension.c built
 * twice, with the kernel and with DIMENSION_C_LOOP (the C loop, symbols renamed ref_*), driven with the same calls
 * and compared sample by sample. Scenarios: random knob words (negative ones and the extremes too: every morph
 * segment, cutoffs down to 30 Hz where the coefficients' shift is largest, every resonance), velocity words, notes
 * struck on random voices, voices rendered out of order or skipped, and pitch words steady, gliding and random over
 * the whole range; after each block the voice-sum block (the ensemble's taps, the dynamics) on the voices' pairs or
 * full-scale noise. Prints "KERN ok blocks=N" or the first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdint.h>
typedef struct {
    void (*note_on)(void *, const int16_t *);
    void (*render)(void *, int16_t *, const int16_t *);
    void (*note_off)(void *);
    uint8_t press[4];
    int (*finished)(void *);
    void (*block)(int16_t *, int);
} eng;
extern const eng ENGINE_dimension, ref_ENGINE_dimension;
void t2_write(const char *, int);
uint32_t t2_r246_calls[2];
volatile uint8_t op1_eng_page[4];
static int16_t quarter[2049];
const int16_t *op1_l1_sine_quarter(void) { return quarter; }
/* the screen's core calls: linked, never called here */
void op1_screen_draw_cached(void *scr, int dt, void *first_live) { (void)scr; (void)dt; (void)first_live; }
void op1_screen_hash(void *scr, uint32_t value) { (void)scr; (void)value; }
void op1_engine_shift(const void *e, int knob, int n) { (void)e; (void)knob; (void)n; }
int32_t sq_text(void *r, int32_t x, int32_t y, int32_t s, const char *t, int32_t w, const uint8_t *c)
{ (void)r; (void)y; (void)s; (void)t; (void)w; (void)c; return x; }
char *sq_num(char *p, uint32_t v, int digits) { (void)v; (void)digits; *p = 0; return p; }
char *sq_cat(char *p, const char *s) { (void)s; *p = 0; return p; }
static unsigned blocks, bad;
static char line[96];
static int n;
static void put(const char *p) { while (*p) line[n++] = *p++; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = '0' + v % 10; while (v /= 10); put(b + i); }
static uint32_t rng = 12345;
static uint32_t rnd(void) { rng = rng * 1664525u + 1013904223u; return rng; }
static void *voice(int v) { return (void *)(uintptr_t)(0xFFB00000u + 0x24u * (uint32_t)v); }
#define PITCH ((volatile uint32_t *)0xFF801950)
#define VEL ((volatile int16_t *)0xFF801064)
#define ENV ((volatile int16_t *)0xFF801D50)

static void fail(const char *what, unsigned i)
{
    bad = 1;
    put("KERN differ "); put(what); put(" block="); num(blocks); put(" i="); num(i); put("\n");
}

static int32_t acc[64];
static void render_both(int v, const int16_t *k)
{
    int16_t a[128], b[128];
    ENGINE_dimension.render(voice(v), a, k);
    ref_ENGINE_dimension.render(voice(v), b, k);
    blocks++;
    for (int i = 0; i < 128 && !bad; i++)
        if (a[i] != b[i]) fail("render", (unsigned)i);
    for (int i = 0; i < 64; i++) acc[i] += (a[2 * i] + a[2 * i + 1]) >> 1;
}
/* the voice-sum block (the ensemble's taps: dimension_ens.S) on the rendered voices' pairs, or now and then full-scale
 * noise, against the C */
static void block_both(int fresh)
{
    int16_t a[64], b[64];
    const int noise = (rnd() & 7) == 0;
    for (int i = 0; i < 64; i++) {
        int32_t x = noise ? (int16_t)(rnd() >> 16) : acc[i];
        x = x > 32767 ? 32767 : x < -32768 ? -32768 : x;
        a[i] = b[i] = (int16_t)x;
        acc[i] = 0;
    }
    ENGINE_dimension.block(a, fresh);
    ref_ENGINE_dimension.block(b, fresh);
    for (int i = 0; i < 64 && !bad; i++)
        if (a[i] != b[i]) fail("block", (unsigned)i);
}

static int16_t knob(void)
{
    uint32_t r = rnd() >> 16;
    switch (r & 7) {
    case 0: return 0;
    case 1: return 32767;
    case 2: return (int16_t)-(int32_t)(r >> 4);
    case 3: return (int16_t)(r >> 5);                                 /* low: cutoffs near 30 Hz */
    default: return (int16_t)(r >> 1);
    }
}

static uint32_t pitch_word(unsigned mode, uint32_t base, int i)
{
    switch (mode) {
    case 0: return base;
    case 1: return base + (base >> 10) * (uint32_t)(i & 127);
    case 2: return rnd();
    default: return rnd() >> (rnd() & 31);
    }
}

int main(void)
{
    for (int i = 0; i <= 2048; i++) {                                  /* sin(2 pi i / 8192) x 32767, by a rotation */
        static int32_t c = 1 << 30, s = 0;
        quarter[i] = (int16_t)((s + (1 << 14)) >> 15);
        const int32_t dc = (int32_t)(((int64_t)s * 823550) >> 30), ds = (int32_t)(((int64_t)c * 823550) >> 30);
        c -= dc; s += ds;
    }
    int16_t k[8] = { 19661, 16384, 24000, 4000, 0x5300, 0, 0, 0 };
    for (int i = 0; i < 128; i++) ENV[i] = 20000;
    for (unsigned s = 0; s < 200 && !bad; s++) {
        const unsigned mode = s % 4;
        uint32_t base = rnd() >> (2 + (rnd() % 10));
        for (int v = 0; v < 6; v++) VEL[v] = (int16_t)(s % 5 == 4 ? rnd() : (rnd() % 128) << 8);
        for (int j = 0; j < 4; j++) k[j] = knob();
        k[5] = (s & 1) ? knob() : 0; k[6] = knob();             /* page 2: the per-voice envelope coefficients */
        k[7] = (s & 3) == 3 ? knob() : 0;
        for (int v = 0; v < 6; v++) if (rnd() & 1) { ENGINE_dimension.note_on(voice(v), k); ref_ENGINE_dimension.note_on(voice(v), k); }
        for (unsigned r = 0; r < 24 && !bad; r++) {
            for (int i = 0; i < 128; i++) PITCH[i] = pitch_word(mode, base, i);
            if ((rnd() & 3) == 0) { const int j = (int)(rnd() & 3); k[j] = knob(); }
            if ((rnd() & 7) == 0) {
                const int v = (int)(rnd() % 6);
                ENGINE_dimension.note_on(voice(v), k);
                ref_ENGINE_dimension.note_on(voice(v), k);
            }
            if (s & 8) {
                for (int t = 0; t < 6 && !bad; t++) if (rnd() & 1) render_both((int)(rnd() % 6), k);
            } else
                for (int v = 0; v < 6 && !bad; v++) render_both(v, k);
            if (!bad) block_both(s % 37 == 0 && r == 0);
        }
    }
    if (!bad) { put("KERN ok blocks="); num(blocks); put("\n"); }
    t2_write(line, n);
    return 0;
}
