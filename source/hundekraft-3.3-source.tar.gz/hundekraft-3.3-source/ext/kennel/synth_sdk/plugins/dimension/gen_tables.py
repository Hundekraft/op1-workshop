#!/usr/bin/env python3
"""Generate dimension_tables.h: the fixed-point tables of the DIMENSION engine (dimension.c).

    python3 gen_tables.py        (writes dimension_tables.h next to this file; prints the pole table's check)

DM_POLE  11 octave rows x 17 resonance columns x (sA, kA, sB, kB), Q13 (8192 = 1.0): the two state-variable sections'
         pole scale and damping. Built from the model of docs/ports/dimension-spec.md 4.5 (OP1-Emulator): the open loop
         P(s) = (s + a)(s + 2a)^3, a = sqrt(0.35) (cutoff-normalised: s in units of 2 pi fc), resonance feedback
         R = 4 j / 16 through a one-pole high-pass at 100 Hz (h = 100 / fn, fn = 18000 * 2^-n Hz), closed loop
         Q(s) = P(s) (s + h) + R P(0) s. Its five roots less the real one nearest -h are paired into two 2-pole
         sections (a complex pair: s = |p|, k = -2 Re p / |p|; two reals: s = sqrt(p1 p2), k = -(p1 + p2) / s; four
         reals are sorted and paired neighbour with neighbour), A the one with the larger s. Rows 8..10 (fn <= 70 Hz)
         hold column 0 in every column, as the original's table does (no resonance below 70 Hz: spec 11, quirk 1).
DM_TAN   tan(pi fc / 88200) for fc = 18000 * 2^(-i / 16), Q31, i = 0..DM_TAN_N - 1: the warped cutoff the pole scales
         multiply (spec 11, quirk 2: s * tan(), kept), at 1/16 octave with linear interpolation (0.02 % at most).
DM_EXP2  2^(-i / 256), Q30, i = 0..256: the cutoff readout in Hz (screen) and the compressor's gain.
DM_RCP   2^31 / (32768 + 128 i), i = 0..256: the coefficients' 1 / (1 + p) without a division (linear interpolation,
         2e-6 at most).
The table is checked against the spec's check values (4.5); the largest difference is printed (the spec's own fit of
the original reproduces it to 0.52 LSB, so up to 1 LSB is expected) and more than 1 LSB stops the script.
Clean-room: written from the behavioural specification only. numpy at build time.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import math
import os
import sys

import numpy as np

A = math.sqrt(0.35)
FS = 88200.0                     # voice samples per second (128 a call, 689 calls/s)
F_TOP = 18000.0
ROWS, COLS = 11, 17
TAN_STEP = 16                    # table entries per octave
D_MAX = 32767 * 37802 / 2 ** 27  # 9.2288 octaves below 18 kHz at cutoff 0
TAN_N = int(math.ceil(D_MAX * TAN_STEP)) + 2

# spec 4.5 check values: (row, col) -> (sA, kA, sB, kB)
CHECK = {(0, 4): (15493, 15267, 6082, 6836), (0, 8): (16897, 15028, 6828, 3549), (0, 16): (18601, 14773, 8001, 428),
         (4, 8): (16997, 15029, 7046, 3775), (4, 16): (18707, 14777, 8173, 771), (7, 4): (16396, 15282, 7686, 8042),
         (7, 16): (19603, 14842, 9110, 3082)}
COL0 = (9693, 16384, 6854, 17378)


def sections(row, col):
    """(sA, kA, sB, kB) as floats for one table cell of the model"""
    h = 100.0 / (F_TOP * 2.0 ** -row)
    R = 4.0 * col / 16
    P = np.poly1d([1.0, A]) * np.poly1d([1.0, 2 * A]) ** 3
    Q = P * np.poly1d([1.0, h]) + np.poly1d([R * P(0.0), 0.0])
    roots = list(Q.roots)
    real = [r for r in roots if abs(r.imag) < 1e-9]
    drop = min(real, key=lambda r: abs(r.real + h))
    roots.remove(drop)
    reals = sorted([r.real for r in roots if abs(r.imag) < 1e-9], key=abs)
    cplx = [r for r in roots if r.imag > 1e-9]
    secs = []
    for p in cplx:
        m = abs(p)
        secs.append((m, -2 * p.real / m))
    for i in range(0, len(reals), 2):
        p1, p2 = reals[i], reals[i + 1]
        s = math.sqrt(p1 * p2)
        secs.append((s, -(p1 + p2) / s))
    assert len(secs) == 2, (row, col, roots)
    secs.sort(key=lambda t: -t[0])
    return secs[0] + secs[1]


def pole_table():
    t = [[None] * COLS for _ in range(ROWS)]
    for n in range(ROWS):
        for j in range(COLS):
            if n >= 8:
                t[n][j] = COL0
            else:
                t[n][j] = tuple(int(round(v * 8192)) for v in sections(n, j))
    return t


def check(t):
    worst, sq, cnt = 0, 0.0, 0
    for n in range(ROWS):
        if t[n][0] != COL0:
            raise SystemExit(f'row {n} column 0 {t[n][0]} != {COL0}')
    for (n, j), want in CHECK.items():
        exact = sections(n, j)
        for got, w, x in zip(t[n][j], want, exact):
            d = abs(x * 8192 - w)
            worst = max(worst, abs(got - w))
            sq += d * d
            cnt += 1
    rms = math.sqrt(sq / cnt)
    print(f'pole table vs spec 4.5 check values: max {worst} LSB (rounded), rms {rms:.2f} LSB (unrounded model)')
    if worst > 1:
        raise SystemExit('pole table: more than 1 LSB from the check values')
    return worst


def tan_table():
    out = []
    for i in range(TAN_N):
        fc = F_TOP * 2.0 ** (-i / TAN_STEP)
        out.append(int(round(math.tan(math.pi * fc / FS) * 2 ** 31)))
    return out


def main():
    t = pole_table()
    check(t)
    tan = tan_table()
    exp2 = [int(round(2.0 ** (-i / 256) * 2 ** 30)) for i in range(257)]
    rcp = [int(round(2 ** 31 / (32768 + 128 * i))) for i in range(257)]
    L = ['/* generated by gen_tables.py: do not edit. See gen_tables.py for what each table is.',
         ' * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */',
         '#ifndef DIMENSION_TABLES_H', '#define DIMENSION_TABLES_H', '#include <stdint.h>', '',
         f'#define DM_ROWS {ROWS}', f'#define DM_COLS {COLS}', f'#define DM_TAN_STEP {TAN_STEP}', f'#define DM_TAN_N {TAN_N}', '',
         '/* [row: octaves below 18 kHz][column: resonance / 2048][sA, kA, sB, kB], Q13 */',
         'static const int16_t DM_POLE[DM_ROWS][DM_COLS][4] = {']
    for n in range(ROWS):
        L.append('    { ' + ', '.join('{ %d, %d, %d, %d }' % c for c in t[n]) + ' },')
    L.append('};')
    L.append('')
    L.append('/* tan(pi * 18000 * 2^(-i / 16) / 88200), Q31 */')
    L.append('static const int32_t DM_TAN[DM_TAN_N] = {')
    for i in range(0, TAN_N, 8):
        L.append('    ' + ', '.join(str(v) for v in tan[i:i + 8]) + ',')
    L.append('};')
    L.append('')
    L.append('/* 2^(-i / 256), Q30 */')
    L.append('static const int32_t DM_EXP2[257] = {')
    for i in range(0, 257, 8):
        L.append('    ' + ', '.join(str(v) for v in exp2[i:i + 8]) + ',')
    L.append('};')
    L.append('')
    L.append('/* 2^31 / (32768 + 128 i) */')
    L.append('static const int32_t DM_RCP[257] = {')
    for i in range(0, 257, 8):
        L.append('    ' + ', '.join(str(v) for v in rcp[i:i + 8]) + ',')
    L.append('};')
    L += ['', '#endif', '']
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dimension_tables.h')
    with open(out, 'w') as fh:
        fh.write('\n'.join(L))
    print(out)


if __name__ == '__main__':
    main()
