/* DIMENSION's filter section, hand-scheduled for the Blackfin: dimension.c's dm_svf (the C stays for host builds and
 * as kern_check.py's reference, DIMENSION_C_LOOP), bit for bit.
 *
 * void dm_svf_k(int32_t *x, int32_t *st, const dm_sec_t *c): 128 samples of x in place through one TPT SVF low-pass
 * section, st = { s1, s2 }, c = { a2m | q2m << 16, -E | g4m << 16 }:
 *   t = floor((a2m (x - s2) - q2m s1) / 2^(16 + E))     v1 = s1 + 2 t      s1 += 4 t
 *   u = floor(g4m v1 / 2^(16 + E))                       v2 = s2 + 4 u      s2 += 8 u      x = v2
 * A 32 x 16 product is one dual MAC: MAC0 the mantissa times the high half (signed), MAC1 times the low half
 * (mixed mode (M): first operand signed, second unsigned, MAC1 only); A1 >>> 16 added to A0 is the exact
 * floor(m s / 2^16); the shift by E is an arithmetic one, so the floors compose. 15 packets a sample.
 * Registers: R0 s1, R1 s2, R2 / R3 work, R5 = a2m (L) | q2m (H), R6 = -E (L) | g4m (H); I0 reads x, P0 writes it
 * (L0 saved and zeroed: R246 may leave it set). M1 is not touched (R246's PmSynth keeps its frame there).
 * Host builds assemble it empty.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifdef __bfin__
	.text
	.align 4
	.global _dm_svf_k
	.type _dm_svf_k, STT_FUNC
_dm_svf_k:
	[--SP] = (R7:5);
	P0 = R0;
	I0 = R0;
	R3 = L0;
	[--SP] = R3;
	R3 = 0;
	L0 = R3;
	P1 = R1;
	P2 = R2;
	R0 = [P1];
	R1 = [P1 + 4];
	R5 = [P2];
	R6 = [P2 + 4];
	P2 = 128;
	R2 = [I0++];
	LSETUP (.Ls_b, .Ls_e) LC0 = P2;
.Ls_b:
	R2 = R2 - R1 (NS);                                   /* x - s2 */
	A1 = R5.L * R2.L (M), A0 = R5.L * R2.H (IS);         /* a2m (x - s2) */
	A1 -= R5.H * R0.L (M), A0 -= R5.H * R0.H (IS);       /* - q2m s1 */
	A1 = A1 >>> 16;
	R2 = (A0 += A1);
	R2 = ASHIFT R2 BY R6.L;                              /* t */
	R2 <<= 1;
	R3 = R0 + R2 (NS);                                   /* v1 */
	R0 = R3 + R2 (NS);                                   /* s1 + 4 t */
	A1 = R6.H * R3.L (M), A0 = R6.H * R3.H (IS);         /* g4m v1 */
	A1 = A1 >>> 16;
	R2 = (A0 += A1);
	R2 = ASHIFT R2 BY R6.L;                              /* u */
	R2 <<= 2;
	R3 = R1 + R2 (NS);                                   /* v2 */
.Ls_e:
	R1 = R3 + R2 (NS) || [P0++] = R3 || R2 = [I0++];     /* s2 + 8 u; x = v2; the next x */
	[P1] = R0;
	[P1 + 4] = R1;
	R3 = [SP++];
	L0 = R3;
	(R7:5) = [SP++];
	RTS;
	.size _dm_svf_k, .-_dm_svf_k
#endif
