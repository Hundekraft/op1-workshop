/* DIMENSION's screen (GUI thread), included by dimension.c.
 *
 * Page 1 is the original engine's T1 page (version 1.0.4), ported from its plugin code with the author's
 * permission (the owner, 2026-11-09; PROVENANCE.md): its art (dimension.svg = dimension-art.svg with ids on the list's
 * seven shapes), drawn by R246's renderer as the original's host does, and its own pixel drawing into the frame, integer for
 * integer: the list's bright copy pasted into the sliding window, the window's edges, the unison slider, the res bump
 * with its anti-aliased top, the labels and values in R246's Text (sizes, places, colours as the original), and the
 * scope's glowing traces (the glow tables and the line rasteriser of the original, port of image offsets 0x1688 and
 * 0x1350). What the original's host did for the page (page pixels, page keep / put, art draw / show / colour slots,
 * accent colours) is done here with the same effect: the frame is R246's raster, pixel (x, y) at
 * [256 (rows - 1 - x) + y]; the still part is kept as runs of its lit pixels and put back each frame; the accent
 * colours are the stock encoder colours (the original host's defaults: blue, green, lavender, the orange encoder's red).
 * The scope's preview voice is this engine's own (the clean-room DSP), so the traces follow ours, not the original's
 * samples; everything else is the original's drawing.
 *
 * The Shift page (ours; shown while Shift is held) uses the same primitives: the still layer with its top and bottom
 * rows cleared, the four labels and values in the same Text, and one note's filter sweep drawn with the scope's glow
 * rasteriser. Its four values are the engine's Shift layer (op1_engine_shift, registered in the screen's init): ENV,
 * DECAY, ACCENT and SLIDE in words 5, 6 and word 7's two fields (p2_block). */
#include "op1_synth.h"
#ifndef OP1_HOST
#define DS_SHIFT (*(volatile uint8_t *)0x01DD7F78)     /* Shift held (the core reads it there too) */
#else
extern uint8_t host_shift;
#define DS_SHIFT host_shift
#endif

/* ---- the frame ---- */
#ifndef OP1_HOST
#define DS_TEXT_NEW(m, x, y, s, c, a) (((void *(*)(void *, int32_t, int32_t, int32_t, const uint8_t *, int32_t))0x01A61904)((m), (x), (y), (s), (c), (a)))
#define DS_TEXT_SET(t, s) (((void (*)(void *, const char *))0x01A61AAC)((t), (s)))
#define DS_TEXT_DRAW(t) (((void (*)(void *, void *, const void *))0x01A6259C)((t), op1_raster(), (const void *)0x01B60FD8))
static int ds_live;                      /* the frame is shown (not a frame-skip record frame): op1_raster_live */
static uint16_t *ds_frame(int32_t *rows)
{
    const uint32_t *r = op1_raster();
    *rows = (int32_t)op1_panel_rows(r);  /* not r[3]: 400 on the SSD1963 panel too (op1_plugin.h) */
    ds_live = op1_raster_live(r);
    return (uint16_t *)(uintptr_t)r[0];
}
#else
/* host builds: a frame of our own (R246's raster is not there; screen_harness.c dumps it as a pixel layer); the text
 * goes to the harness's Text (its align at word 4, as screen_harness.c's text_obj) */
uint16_t host_frame565[400 * 256];
__attribute__((weak)) int32_t host_svg_tx, host_svg_k;   /* the art's x translation (units) and scale, Q10 (screen_harness.c) */
#define DS_TEXT_NEW(m, x, y, s, c, a) (host_text_ctor((m), (x), (y), (s), (c)), ((int32_t *)(m))[4] = (a), (void *)(m))
#define DS_TEXT_SET(t, s) host_text_set((t), (s))
#define DS_TEXT_DRAW(t) host_text_draw((t), 0, 0)
static int ds_live;
static uint16_t *ds_frame(int32_t *rows) { *rows = op1_panel_rows_of(host_screen_scale, 400); ds_live = op1_raster_live(0); return host_frame565; }
#endif

static uint16_t *ds_fb;                  /* the frame */
static int32_t ds_rows;                  /* its columns: 320, 376 or 400 (the units x rows / 320) */
/* The page keeps DS_DXP panel pixels clear at each end (2026-11-11): the original's art spans x 0..318.6 units (the
 * list's band and WAVEFORM at the left, RES and the plot's grey right edge at the right), and on the owner's 376-row
 * unit its first pixels were hard to see at the glass's edge (WAVEFORM's first ink at 2 px, the band's border at 0;
 * stock pages start at 5 px or more, kastle at 8). So the page is laid out for ds_L = rows - 2 DS_DXP (368, 392, 312)
 * and placed DS_DXP in: R246's art through a
 * scale + translation matrix (ds_art: ds_k, ds_tx), its Text made at the same place (ds_text), our own pixels laid out
 * for ds_L and written through PX. Down the short side the scale is the same, from the top. */
#define DS_DXP 4
static int32_t ds_L;                     /* the rows the page is laid out for: ds_rows - 2 DS_DXP */
static int32_t ds_k, ds_tx;              /* the art's scale ds_L / ds_rows and DS_DXP in units (Q10 both) */
#define DS_W (ds_rows - DS_DXP)          /* own pixels: x 0..DS_W - 1 (the frame's end, past the layout) */
#define PX(x, y) ds_fb[256 * (ds_rows - 1 - DS_DXP - (x)) + (y)]

static char *cat(char *p, const char *s) { while (*s) *p++ = *s++; *p = 0; return p; }
static char *num(char *p, uint32_t v)
{
    char b[10]; int n = 0;
    do { b[n++] = (char)('0' + v % 10); v /= 10; } while (v && n < 10);
    while (n) *p++ = b[--n];
    *p = 0;
    return p;
}

static const uint32_t ACC[4] = { 0x698EFF, 0x00ED95, 0xDED7FF, 0xFF3A5D };   /* the encoders: the stock colours */
static inline uint16_t rgb565(uint32_t c) { return (uint16_t)(((c >> 19) << 11) | ((c >> 5) & 0x7E0) | ((c >> 3) & 0x1F)); }
static inline uint32_t ds_scale(uint32_t c, uint32_t m, int sh)                 /* each channel x m >> sh */
{ return ((((c >> 16) & 255) * m >> sh) << 16) | ((((c >> 8) & 255) * m >> sh) << 8) | ((c & 255) * m >> sh); }

/* ---- R246's Text, as the original's text slots (image offset 0x1550): made once, recoloured and drawn each call ---- */
#define DS_SLOTS 40
static uint8_t ds_tmem[DS_SLOTS][OP1_TEXT_SIZE] __attribute__((aligned(4)));
static void *ds_tobj[DS_SLOTS];
static int32_t ds_tobj_tx[DS_SLOTS];     /* the ds_tx a slot was made with (the margin and scale are in its place) */
static void ds_text(int slot, int32_t x, int32_t y, int32_t size, int32_t align, uint32_t rgb, const char *s)
{
    if (!ds_tobj[slot] || ds_tobj_tx[slot] != ds_tx) {
        ds_tobj_tx[slot] = ds_tx;
        const uint8_t c[4] = { (uint8_t)(rgb >> 16), (uint8_t)(rgb >> 8), (uint8_t)rgb, 0xFF };
        ds_tobj[slot] = DS_TEXT_NEW(ds_tmem[slot], x * ds_k + ds_tx, (y * ds_k + 512) >> 10, size, c, align);
    }
    uint8_t *t = (uint8_t *)ds_tobj[slot];
#ifndef OP1_HOST
    t[0x6C] = (uint8_t)(rgb >> 16); t[0x6D] = (uint8_t)(rgb >> 8); t[0x6E] = (uint8_t)rgb; t[0x6F] = 0xFF;
#endif
    DS_TEXT_SET(t, s);
    DS_TEXT_DRAW(t);
}

/* ---- kept pixels (the host's page keep / put): the lit pixels of columns x0..x1, rows y0..y1 as runs {x, y, n, n pixels} ---- */
static int32_t ds_keep(uint16_t *out, int32_t cap, int32_t x0, int32_t x1, int32_t y0, int32_t y1)
{
    int32_t used = 0;
    for (int32_t x = x0; x <= x1; x++)
        for (int32_t y = y0; y <= y1;) {
            if (!PX(x, y)) { y++; continue; }
            int32_t n = 0;
            while (y + n <= y1 && PX(x, y + n)) n++;
            if (used + 3 + n > cap) return -1;
            out[used++] = (uint16_t)x; out[used++] = (uint16_t)y; out[used++] = (uint16_t)n;
            for (int32_t i = 0; i < n; i++) out[used++] = PX(x, y + i);
            y += n;
        }
    return used;
}
static void ds_put(const uint16_t *in, int32_t used)
{
    for (int32_t i = 0; i < used;) {
        const int32_t x = in[i], y = in[i + 1], n = in[i + 2];
        uint16_t *p = &PX(x, y);
        i += 3;
        for (int32_t k = 0; k < n; k++) p[k] = in[i + k];
        i += n;
    }
}

/* ---- the art: R246's renderer on dimension.svg, the list recoloured, groups shown or hidden (the host's art calls) ---- */
static void *ds_scr;
static void ds_art(uint32_t list_rgb, int groups)
{
    static const char *const G[3] = { "grid", "dash", "axis" };
    for (int i = 0; i < 3; i++) { void *n = op1_find_node(ds_scr, G[i]); if (n) op1_node_set_visible(n, groups); }
    for (int i = 0; i < 7; i++) {
        const char id[3] = { 'l', (char)('0' + i), 0 };
        uint8_t *c = op1_node_line_rgba(ds_scr, id);
        if (c) { c[0] = (uint8_t)(list_rgb >> 16); c[1] = (uint8_t)(list_rgb >> 8); c[2] = (uint8_t)list_rgb; c[3] = 0xFF; }
    }
#ifndef OP1_HOST
    /* screen_draw_base (0x01A3B4C8) with the margin's translation in place of its identity: Document::draw is the
     * forwarder to Group::draw (0x019EB818, this as the document), as kennel/kn_artcache.c checks before it calls it */
    uint8_t *doc = *(uint8_t **)ds_scr;
    const uint8_t *vt = doc ? *(uint8_t *const *)(doc + 0x54) : 0;
    if (vt && *(const uint32_t *)(vt + 0x14) == 0x01976560u && *(const int16_t *)(vt + 0x10) == 0) {
        const int32_t m[9] = { ds_k, 0, 0, 0, ds_k, 0, ds_tx, 0, 1024 };
        ((void (*)(void *, void *, const void *, void *))0x019EB818)(doc, doc, m, op1_raster());
        return;
    }
#else
    host_svg_tx = ds_tx; host_svg_k = ds_k;   /* (host: the harness draws the SVG layer with them) */
#endif
    op1_screen_draw(ds_scr, 0);
}
static void ds_clear(void) { for (int32_t i = 0; i < ds_rows * 256; i++) ds_fb[i] = 0; }

/* ---- the scope's glow (image offsets 0x1688 and 0x1350) ---- */
/* a glow table: [0] the reach (Q8 px), [1 + i] the colour at a distance 8 + 16 i (1/16 px), then 32 zeros: the line's
 * colour x a falloff from w + 128 down, and a core colour fading over rad, whichever channel is brighter */
static void ds_glow_lut(uint32_t *lut, uint32_t rgb, int32_t w, uint32_t core, int32_t k, int32_t rad)
{
    const int32_t r5 = w + 0x80, reach = r5 > rad ? r5 : rad;
    const uint32_t cr = (core >> 16) & 255, cg = (core >> 8) & 255, cb = core & 255;
    const uint32_t lr = (rgb >> 16) & 255, lg = (rgb >> 8) & 255, lb = rgb & 255;
    uint32_t *o = lut;
    *o++ = (uint32_t)reach;
    int32_t r4 = (rad - 8) * k;
    for (int32_t d = 8; d != 0x408; d += 16, r4 -= 16 * k) {
        int32_t a = r5 - d;
        a = a > 256 ? 256 : a < 0 ? 0 : a;
        uint32_t c1 = 0;
        if (!(rad <= d)) {
            const int32_t t = r4 / rad;
            c1 = ((uint32_t)((int32_t)(cg * (uint32_t)t) >> 8) << 8) | ((cb * (uint32_t)t) >> 8) | (((uint32_t)t * cr >> 8) << 16);
        }
        const uint32_t c0 = ((uint32_t)((int32_t)(lg * (uint32_t)a) >> 8) << 8) | ((lb * (uint32_t)a) >> 8) | (((uint32_t)a * lr >> 8) << 16);
        uint32_t m = 0;
        for (int s = 0; s != 24; s += 8) {
            uint32_t x = (c0 >> s) & 255, y = (c1 >> s) & 255;
            if (x < y) x = y;
            m |= x << s;
        }
        if (reach < d) *o++ = 0;
        else *o++ = ((m >> 19) << 11) | ((m >> 5) & 0x7E0) | ((m >> 3) & 0x1F);
    }
    for (int i = 0; i < 32; i++) lut[65 + i] = 0;
}

/* Blackfin's DIVS then 15 DIVQ (the original's slope division): the 16-bit quotient of a by b's low half */
static uint32_t ds_divq(uint32_t a, uint32_t b)
{
    const uint32_t dv = b & 0xFFFF;
    uint32_t r = a >> 16, aq = ((r ^ dv) >> 15) & 1;
    a = (((a << 1) | aq) & 0x1FFFF) | (r << 17);
    for (int i = 0; i < 15; i++) {
        const uint32_t af = a >> 16, r16 = (aq ? af + dv : af - dv) & 0xFFFF;
        aq = ((r16 ^ dv) >> 15) & 1;
        a = (((a << 1) | (aq ^ 1)) & 0x1FFFF) | (r16 << 17);
    }
    return a & 0xFFFF;
}

/* a glowing polyline through n points (x, y in Q8 px; closed: back to the first), each pixel the brighter (as a
 * number) of what is there and the table's colour at its distance from the line: port of image offset 0x1350 */
static void ds_glow(const int32_t *pts, int32_t n, int closed, const uint32_t *lut)
{
    const int32_t reach0 = (int32_t)lut[0];
    for (int32_t i = 1; i <= (closed ? n : n - 1); i++) {
        const int32_t *p = &pts[2 * (i - 1)], *q = &pts[2 * (closed ? i % n : i)];
        int32_t px = p[0], py = p[1], qx = q[0], qy = q[1];
        const int32_t adx = px < qx ? qx - px : px - qx, ady = py < qy ? qy - py : py - qy;
        const int ymaj = adx < ady;
        int32_t s0, m0, e0, me;                    /* start major / minor, end major / minor */
        if (ymaj) { if (py < qy) { s0 = py; m0 = px; e0 = qy; me = qx; } else { s0 = qy; m0 = qx; e0 = py; me = px; } }
        else { if (px <= qx) { s0 = px; m0 = py; e0 = qx; me = qy; } else { s0 = qx; m0 = qy; e0 = px; me = py; } }
        int32_t len = e0 - s0, dm = me - m0, slope, reach, perp;
        if (len == 0) { slope = 0; reach = reach0; perp = 0x100; }
        else {
            while (len > 0x7FFF) { len >>= 1; dm >>= 1; }
            const int32_t sq = (int32_t)ds_divq((uint32_t)((dm < 0 ? -dm : dm) << 9), (uint32_t)len);
            perp = 0x100 - ((sq * 75) >> 8);
            reach = ((((sq * 105 + sq) >> 8) * reach0) >> 8) + reach0;
            slope = dm < 0 ? -sq : sq;
        }
        const int32_t dstep = perp << 8;
        int32_t j = (s0 + 0x80) >> 8;
        const int32_t je = (e0 + 0x80) >> 8;
        int32_t mpos = ((((j << 8) - s0) * slope) >> 8) + m0;
        for (; j <= je; j++, mpos += slope) {
            const int32_t a = (0x80 - reach + mpos) >> 8, b = (reach - 0x80 + mpos) >> 8;
            int32_t dist = ((a << 8) + 0x80 - mpos) * perp;
            for (int32_t m = a; m <= b; m++, dist += dstep) {
                const int32_t x = ymaj ? m : j, y = ymaj ? j : m;
                if (x < 0 || x >= DS_W || y < 0 || y >= 256) continue;
                uint16_t *px16 = &PX(x, y);
                int32_t idx = (dist < 0 ? -dist : dist) >> 12;
                if (idx > 96) idx = 96;
                const uint32_t c = lut[1 + idx];
                if (*px16 < c) *px16 = (uint16_t)c;
            }
        }
    }
}

/* ---- the scope: the preview voice and its two traces (image offset 0x17C4) ---- */
static dm_core_t sp_core;
static int32_t sp_ready, sp_peak, sp_eased;
static int32_t sp_pts[2][256];                     /* the traces: lag 32, lag 24 (Q8 px pairs) */
static uint32_t sp_lut0[97], sp_lut1[97], sp_lutkey;

/* the colour: the blue encoder's lightened 35 %; the tables when it changes (the main trace, the dimmer lag trace) */
static void ds_scope_luts(void)
{
    uint32_t lc = 0;
    for (int sh = 0; sh != 24; sh += 8) { const uint32_t v = (ACC[0] >> sh) & 255; lc |= ((((255 - v) * 45 & 0x7FFFFFFF) >> 7) + v) << sh; }
    if ((ACC[0] | 0x1000000) != sp_lutkey) {
        ds_glow_lut(sp_lut0, lc, 0xE6, ACC[0], 0x50, 0x384);
        ds_glow_lut(sp_lut1, ds_scale(lc, 35, 6), 100, 0, 0, 0);
        sp_lutkey = ACC[0] | 0x1000000;
    }
}

static void ds_scope(const int16_t *k)
{
    dm_morph_t m;
    dm_coef_t c;
    int32_t y[OP1_BLOCK], a[OP1_BLOCK], s[OP1_BLOCK];
    if (!sp_ready) { sp_core.u = 0x40000000u; sp_core.rng = 0x2545F491u; sp_ready = 1; }
    dm_morph(k[0], &m);
    dm_coef(k[2], k[3], &c);
    dm_core(&sp_core, y, 1u << 25, &m, &c);
    for (int i = 0; i < OP1_BLOCK; i++) a[i] = clampi(y[i], -32768, 32767);
    for (int pass = 0; pass < 4; pass++) {
        for (int i = 0; i < OP1_BLOCK; i++)
            s[i] = a[(i - 2) & 127] + a[(i - 1) & 127] + a[i] + a[(i + 1) & 127] + a[(i + 2) & 127];
        for (int i = 0; i < OP1_BLOCK; i++) a[i] = (s[i] * 0x3333) >> 16;
    }
    int32_t pk = 0;
    for (int i = 0; i < OP1_BLOCK; i++) pk = maxi(pk, absi(a[i]));
    if (pk <= sp_peak) pk = sp_peak - (sp_peak >> 4);
    sp_peak = pk;
    const int32_t rows = ds_L;
    const int32_t g = ((rows * 0x380000) / 0xA000) * (0x6CCD00 / (pk < 0x4C0 ? 0x4C0 : pk)) >> 12;
    const int32_t cx = (rows * 0xA800) / 320, cy = (rows * 0x4A00) / 320, xl = (rows * 0x4000) / 320, xh = (rows * 0x12A00) / 320 - 0x400;
    const int32_t yl = (rows * 0x1100) / 320, yh = (rows * 0x8300) / 320 - 0x400;
    static const int lag[2] = { 32, 24 };
    for (int t = 0; t < 2; t++)
        for (int i = 0; i < 128; i++) {
            const int32_t xv = ((a[i] * g) >> 12) + cx, yv = cy - ((a[(i + lag[t]) & 127] * g) >> 12);
            int32_t x = xl + 0x400, yy = yl + 0x400;
            if (xl + 0x400 <= xv) x = xv < xh ? xv : xh;
            if (yl + 0x400 <= yv) yy = yv < yh ? yv : yh;
            int32_t *p = &sp_pts[t][2 * i];
            if (sp_eased) { x = ((x - p[0]) >> 2) + p[0]; yy = ((yy - p[1]) >> 2) + p[1]; }
            p[0] = x; p[1] = yy;
        }
    sp_eased = 1;
    ds_scope_luts();
    ds_glow(sp_pts[1], 128, 1, sp_lut1);
    ds_glow(sp_pts[0], 128, 1, sp_lut0);
}

/* ---- the cutoff in whole Hz as the original computes it (image offset 0x1060) ---- */
static uint32_t ds_hz(int32_t k)
{
    const uint32_t c = (uint32_t)clampi(k, 0, 0x7FFF);
    const uint32_t r0 = (0x7FFF - c) * 0x93AAu, n = r0 >> 27;
    const int32_t e = 0x1000 - (int32_t)((r0 << 5) >> 20);
    const uint32_t f = ((uint32_t)e << 4) & 0xFFFF;
    uint32_t v = ((((f * 5) << 9) - f) << 1) >> 16;
    v = ((v + 0x39E8) * f) >> 16;
    v = ((v + 0xB21A) * f) >> 16;
    v = (v + 0x10000) << (e >> 12);
    return (v * 18000u + (1u << (n + 16))) >> (n + 17);
}

/* ---- the page's still part (image offset 0x1C48's first half): the list's bright copy, then the art, the words ---- */
#define DS_KEEP_WORDS 0x6000
static uint16_t ds_still[DS_KEEP_WORDS];
static int32_t ds_still_used = -1, ds_still_rows;
static uint16_t ds_bright[80 * 152];                /* the list column's bright pixels, x * 152 + (y - y0) */
static int32_t ds_colw, ds_y0, ds_h;
static void ds_icon_words(uint32_t rgb)            /* image offset 0x1624 */
{
    ds_text(4, 27, 23, 8, 1, rgb, "noise");
    ds_text(5, 27, 118, 8, 1, rgb, "noise");
    ds_text(6, 46, 100, 6, 1, rgb, "sub");
}
static void ds_build_still(void)
{
    const int32_t rows = ds_L;
    const uint32_t a0 = ACC[0], r = a0 >> 16 & 255, g = a0 >> 8 & 255, b = a0 & 255;
    ds_clear();
    ds_colw = (rows * 64) / 320;
    ds_y0 = (rows * 17) / 320;
    ds_h = (rows * 131) / 320 - ds_y0 + 1;
    if (rows * 64 > 0x653F) ds_colw = 80;
    if (ds_h > 152) ds_h = 152;
    const uint16_t tint = (uint16_t)(((r * 9 >> 9) << 11) | ((((int32_t)(g * 0x24) >> 8) & 0xFC) << 3) | (b * 9 >> 9));
#ifndef OP1_HOST                                    /* (host: the art is not in the pixels, so no tint over it either) */
    for (int32_t x = 0; x < ds_colw; x++)
        for (int32_t y = ds_y0; y < ds_y0 + ds_h; y++) PX(x, y) = tint;
#else
    (void)tint;
#endif
    const uint32_t bright = ds_scale(a0, 0x37, 6);
    ds_art(bright, 0);
    ds_icon_words(bright);
    for (int32_t x = 0; x < ds_colw; x++)
        for (int32_t y = 0; y < ds_h; y++) ds_bright[x * 152 + y] = PX(x, ds_y0 + y);
    ds_clear();
    const uint32_t dimc = ds_scale(a0, 0x19, 6);
    ds_art(dimc, 1);
    ds_icon_words(dimc);
#ifdef OP1_HOST
    if (!(op1_eng_page[0] | op1_eng_page[1] | op1_eng_page[2] | op1_eng_page[3]))   /* (host: Text is not pixels) */
#endif
    {
    ds_text(0, 3, 5, 9, 0, ACC[0], "waveform");
    ds_text(1, 76, 5, 9, 0, ACC[1], "unison");
    ds_text(2, 167, 5, 9, 0, ds_scale(ACC[2], 75, 7), "filter freq");
    ds_text(3, 299, 5, 9, 0, ACC[3], "res");
    ds_text(7, 112, 135, 8, 1, 0x5B6770, "-1");
    ds_text(8, 168, 135, 8, 1, 0x5B6770, "0");
    ds_text(9, 224, 135, 8, 1, 0x5B6770, "1");
    }
    ds_still_used = ds_keep(ds_still, DS_KEEP_WORDS, 0, DS_W - 1, 0, ds_rows / 2 - 1);
    ds_still_rows = ds_rows;
}

/* ---- the moving parts (image offset 0x1C48's second half) ---- */
static void ds_window(int32_t k0)
{
    const int32_t rows = ds_L;
    const int32_t wt = (((((k0 < 0 ? 0 : k0) * 95) >> 7) + 0x1100) * rows / 320) >> 8, wb = (rows * 19) / 320 + wt;
    for (int32_t x = 0; x < ds_colw; x++)
        for (int32_t y = wt; y <= wb; y++)
            if (y >= ds_y0 && y < ds_y0 + ds_h) PX(x, y) = ds_bright[x * 152 + (y - ds_y0)];
    const uint16_t edge = rgb565(ds_scale(ACC[0], 25, 5));
    for (int32_t x = 0; x < ds_colw; x++) { PX(x, wt) = edge; PX(x, wb) = edge; }
    if (wt <= wb)
        for (int32_t y = wt; y <= wb; y++) { PX(0, y) = edge; PX(ds_colw - 1, y) = edge; }
}

static void ds_slider(int32_t k1)
{
    const int32_t rows = ds_L, x0 = (rows * 131) / 320, x1 = (rows * 159) / 320, yc = (rows * 9) / 320;
    const int32_t fill = ((x1 - x0) * (k1 < 0 ? 0 : k1)) / 0x7FFF + x0;
    const uint32_t a1 = ACC[1];
    if (x0 <= x1) { const uint16_t c = rgb565(ds_scale(a1, 5, 4)); for (int32_t x = x0; x <= x1; x++) PX(x, yc) = c; }
    if (x0 <= fill) { const uint16_t c = rgb565(ds_scale(a1, 45, 6)); for (int32_t x = x0; x <= fill; x++) PX(x, yc) = c; }
    const int32_t half = (rows * 3) / 320;
    const uint16_t c = rgb565(a1);
    for (int32_t y = yc - half; y <= yc + half; y++) PX(fill, y) = c;
}

static void ds_bump(int32_t k3)
{
    const int32_t rows = ds_L, x0 = (rows * 298) / 320, x1 = (rows * 316) / 320, base = (rows * 131) / 320;
    const int32_t hgt = (((k3 < 0 ? 0 : k3) * 0x66) / 0x7FFF + 6) * rows * 256 / 320;
    const int32_t half = (x1 - x0) / 2, xc = x0 + half, hd = half ? half : 1;
    const uint16_t c = rgb565(ACC[3]);
    const uint32_t cexp = (((uint32_t)c << 16) + c) & 0x07E0F81Fu;
    for (int32_t x = x0; x <= x1; x++) {
        const int32_t u = ((x - xc) * 256) / hd, q = 256 - ((u * u) >> 8), bb = (q * q) >> 8;
        const int32_t top = (base - 1) * 256 - ((bb * hgt) >> 8), yi = (top + 255) >> 8;
        if (yi <= base - 1) for (int32_t y = yi; y <= base - 1; y++) PX(x, y) = c;
        if (yi > 0) {
            uint16_t *p = &PX(x, yi - 1);
            const uint32_t al = (uint32_t)((yi << 8) - top) >> 3;
            uint32_t v = cexp * al;
            if (*p) v += (32 - al) * ((((uint32_t)*p << 16) + *p) & 0x07E0F81Fu);
            v = (v >> 5) & 0x07E0F81Fu;
            *p = (uint16_t)((v >> 16) | v);
        }
    }
}

/* ---- the Shift page (ours): one note's filter sweep in page 1's two-trace glow; page 1's label row, one value ---- */
#define SW_X0 70                                    /* the note starts here; 1 s = 100 units */
#define SW_N 45                                     /* points over 2.2 s: 5 units, 34.5 blocks, apart */
#define SL_YP 124                                   /* the slide: the previous note's height and the new one's (units) */
#define SL_YN 110
static uint32_t p2_lut3[97];
static int p2_lutok, s_act;                         /* s_act: the control turned last (0..3), whose value is shown */
static int32_t sw_y(int32_t off)                    /* Q8 px: y 104 units is the cutoff, 9 octaves reach y 22 */
{
    return (ds_L * (104 * 256 - (int32_t)(((int64_t)82 * 256 * clampi(off, 0, ENV_OCT + ACC_OCT)) / (ENV_OCT + ACC_OCT)))) / 320;
}
static int32_t sw_x(int32_t u256) { return (ds_L * u256) / 320; }   /* units Q8 -> px Q8 */
static void ds_ms(char *t, int32_t ms)              /* "263 ms", from a second on "1.2 s" */
{
    if (ms < 1000) { cat(num(t, (uint32_t)ms), " ms"); return; }
    const int32_t d = (ms + 50) / 100;
    char *p = num(t, (uint32_t)(d / 10));
    *p++ = '.';
    cat(num(p, (uint32_t)(d % 10)), " s");
}
static void ds_page2(const int16_t *w)
{
    const int32_t rows = ds_L;
    ds_scope_luts();
    if (!p2_lutok) {                                 /* the slide: the res encoder's colour in the scope's glow */
        uint32_t lc = 0;
        for (int sh = 0; sh != 24; sh += 8) { const uint32_t v = (ACC[3] >> sh) & 255; lc |= ((((255 - v) * 45) >> 7) + v) << sh; }
        ds_glow_lut(p2_lut3, lc, 0xE6, ACC[3], 0x50, 0x384);   /* the main trace's width and core */
        p2_lutok = 1;
    }
    for (int32_t x = 0; x < DS_W; x++) {             /* the still part's top and bottom rows go: the Shift page has its own words */
        for (int32_t y = 0; y < (rows * 16) / 320; y++) PX(x, y) = 0;
        for (int32_t y = (rows * 133) / 320; y < 256; y++) PX(x, y) = 0;
    }
    const int32_t w7 = w[7], sl = p2_slidew(w7);
    /* the words: page 1's labels in their places and colours; the pushed control's value where page 1 has the Hz */
    ds_text(14, 3, 5, 9, 0, ACC[0], "env");
    ds_text(15, 76, 5, 9, 0, ACC[1], "decay");
    ds_text(16, 167, 5, 9, 0, ds_scale(ACC[2], 75, 7), "accent");
    ds_text(17, 318, 5, 9, 2, ACC[3], "slide");     /* right-aligned where "res" ends: at 299 it runs off */
    char t[16];
    if (s_act == 0) cat(num(t, (uint32_t)((knob(w, 5) * 100 + 16383) / 32767)), "%");
    else if (s_act == 1) ds_ms(t, p2_decay_ms(w[6]));
    else if (s_act == 2) cat(num(t, (uint32_t)((p2_accent(w7) * 100 + 63) / 127)), "%");
    else if (sl) ds_ms(t, p2_slide_ms(sl));
    else cat(t, "off");
    ds_text(18, 272, 5, 9, 2, ACC[s_act], t);       /* right-aligned on the Hz value's right edge: clear of "slide"; in the control's colour */
    ds_text(30, SW_X0, 135, 8, 1, 0x5B6770, "0");
    ds_text(31, SW_X0 + 100, 135, 8, 1, 0x5B6770, "1s");
    ds_text(32, SW_X0 + 200, 135, 8, 1, 0x5B6770, "2s");
    /* the cutoff: dashed and dim as the art's dashed lines (5 units on, 2 off, two rows of #3A4148 at half) */
    {
        const uint16_t c = rgb565(0x181E21);
        const int32_t yc = (rows * 104) / 320 - 1;
        for (int32_t u = 66; u < 292; u += 7)
            for (int32_t x = (rows * u) / 320; x < (rows * (u + 5)) / 320; x++) { PX(x, yc) = c; PX(x, yc + 1) = c; }
    }
    /* the sweep: the envelope and the accent as the voices step them (per block), 5 units (34 blocks) a point */
    const int32_t env = (knob(w, 5) * ENV_OCT) >> 15, acc = (p2_accent(w7) * 32767) / 127;
    const int32_t xd = dm_exp2n(51937000, (knob(w, 6) * 1551) >> 15), xa = xd > 7791000 ? xd : 7791000;
    int32_t ev = 1 << 30, ea = 1 << 30, pe[2 * (SW_N + 2)], pa[2 * (SW_N + 2)];
    pe[0] = pa[0] = sw_x(SW_X0 << 8); pe[1] = pa[1] = sw_y(0);          /* the attack: straight up from the cutoff */
    for (int i = 0; i <= SW_N; i++) {
        const int32_t oe = mf(env << 15, ev) >> 14, oa = mf(((ACC_OCT * acc) >> 15) << 15, ea) >> 14;
        pe[2 * i + 2] = pa[2 * i + 2] = sw_x((SW_X0 + 5 * i) << 8);
        pe[2 * i + 3] = sw_y(oe);
        pa[2 * i + 3] = sw_y(oe + oa);
        for (int b = 0; b < 34; b++) { ev -= mf(ev, xd << 1); ea -= mf(ea, xa << 1); }
    }
    if (acc) ds_glow(pa, SW_N + 2, 0, sp_lut1);     /* the accent's overshoot: page 1's lag trace */
    ds_glow(pe, SW_N + 2, 0, sp_lut0);               /* the envelope: page 1's main trace */
    /* the slide: the pitch from the previous note to the new one as the voices glide it, on the same time axis;
     * off: a short step. Blocks run 689.06 a second, 100 units */
    int32_t sp[2 * 56], n = 0;
    const int32_t yp = sw_x(SL_YP << 8), yn = sw_x(SL_YN << 8);
    sp[n++] = sw_x(66 << 8); sp[n++] = yp;                               /* from the plot's left edge */
    sp[n++] = sw_x(SW_X0 << 8); sp[n++] = yp;
    if (!sl) { sp[n++] = sw_x(SW_X0 << 8); sp[n++] = yn; }
    else {
        const int32_t xs = dm_exp2n(155830000, ((sl - 1) * 1701) / 126);
        int32_t gq = 1 << 30, nb = 0;
        while (gq > (1 << 30) / 100 && nb < 1440) { gq -= mf(gq, xs << 1); nb++; }   /* to 1 %, or the plot's end */
        const int32_t k = nb / 50 + 1;
        gq = 1 << 30;
        for (int32_t b = 0; b < nb;) {
            for (int32_t j = 0; j < k && b < nb; j++, b++) gq -= mf(gq, xs << 1);
            sp[n++] = sw_x((SW_X0 << 8) + (b * 25600) / 689); sp[n++] = yn + (int32_t)(((int64_t)(yp - yn) * gq) >> 30);
        }
    }
    sp[n] = sp[n - 2] + sw_x(12 << 8); sp[n + 1] = sp[n - 1];
    if (sp[n] > sw_x(292 << 8)) sp[n] = sw_x(292 << 8);
    n += 2;
    ds_glow(sp, n / 2, 0, p2_lut3);
}

/* the value shown: the control whose word moved last while Shift is held (a turn; ENV 0, DECAY 1, ACCENT 2, SLIDE 3) */
static int32_t s_seen[4];
static int s_slot = -1, s_held;
static void shift_value(int slot, const int16_t *w)
{
    const int32_t now[4] = { knob(w, 5), knob(w, 6), p2_accent(w[7]), p2_slidew(w[7]) };
    if (slot != s_slot) { s_slot = slot; s_act = 0; s_held = 0; }
    if (!s_held) { s_held = 1; for (int i = 0; i < 4; i++) s_seen[i] = now[i]; }   /* a hold starts from what is there */
    for (int i = 0; i < 4; i++) {
        if (now[i] != s_seen[i]) s_act = i;
        s_seen[i] = now[i];
    }
}

static void dimension_screen_init(void *scr)
{
    ds_scr = scr;
    op1_engine_shift(&ENGINE_dimension.voice, 0, 1);          /* Shift + blue: ENV, fine (word 5) */
    op1_engine_shift(&ENGINE_dimension.voice, 1, 1);          /* Shift + green: DECAY, fine (word 6) */
    op1_engine_shift(&ENGINE_dimension.voice, 2, 1);          /* Shift + white: ACCENT 0..127 (word 7 bits 0..6) */
    op1_engine_shift(&ENGINE_dimension.voice, 3, 1);          /* Shift + orange: SLIDE 0..127 (word 7 bits 8..14) */
}

static void dimension_screen_update(void *scr, int dt)
{
    int16_t k[4];
    const int slot = OP1_SCREEN_SLOT & 7;
    (void)dt;
    ds_scr = scr;
    const int page2 = DS_SHIFT != 0;                 /* Shift held: the Shift layer's page */
    if (page2) shift_value(slot, op1_synth_knobs(slot)); else s_held = 0;
    op1_synth_knobs_live(slot, k);
    ds_fb = ds_frame(&ds_rows);
    if (!ds_fb || (ds_rows != 320 && ds_rows != 376 && ds_rows != 400)) { op1_screen_draw(scr, dt); return; }
    ds_L = ds_rows - 2 * DS_DXP;
    ds_k = (ds_L * 1024 + ds_rows / 2) / ds_rows;
    ds_tx = (DS_DXP * 320 * 1024 + ds_rows / 2) / ds_rows;
#ifdef OP1_HOST
    ds_still_used = -1;                              /* the host's art and Text are not pixels: draw them every frame */
#endif
    /* the still part is read back from the frame: never in a record frame, where R246 draws nothing (the art, the
     * labels) into an uncleared scratch buffer, so the kept still would lack them for good */
    if ((ds_still_used < 0 || ds_still_rows != ds_rows) && ds_live) ds_build_still();
    else if (ds_still_used >= 0 && ds_still_rows != ds_rows) ds_still_used = -1;
    if (ds_still_used >= 0) { ds_clear(); ds_put(ds_still, ds_still_used); }
    ds_window(k[0]);
    if (page2) ds_page2(op1_synth_knobs(slot));
    else {
        char t[16];
        ds_slider(k[1]);
        num(t, ds_hz(k[2]));
        ds_text(10, 250, 5, 9, 0, 0xDEDBFF, t);   /* the value's lavender as the original's frames show it (G 0xDB) */
    }
    ds_bump(k[3]);
    if (!page2) ds_scope(k);
    /* the core's frame skip sees none of the pixels written above: feed it what they depend on (op1_plugin.h). Page 1:
     * the four knobs and the scope's traces (they ease toward each new frame's points, so this also tells when they
     * settle); the Shift page: its eight words and the value shown. */
    op1_screen_hash(scr, (uint32_t)ds_rows << 3 | (uint32_t)s_act << 1 | (uint32_t)page2);
    for (int i = 0; i < 4; i++) op1_screen_hash(scr, (uint32_t)(uint16_t)k[i]);
    if (page2) {
        const int16_t *w = op1_synth_knobs(slot);
        for (int i = 0; i < 8; i++) op1_screen_hash(scr, (uint32_t)(uint16_t)w[i]);
    } else {
        for (int t = 0; t < 2; t++)
            for (int i = 0; i < 256; i++) op1_screen_hash(scr, (uint32_t)sp_pts[t][i]);
    }
}

const op1_screen_t SCREEN_dimension = { dimension_screen_init, dimension_screen_update };
