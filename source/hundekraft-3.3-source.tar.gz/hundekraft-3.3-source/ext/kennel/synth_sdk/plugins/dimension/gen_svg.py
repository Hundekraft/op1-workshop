#!/usr/bin/env python3
"""Writes dimension.svg from dimension-art.svg: the original engine's T1 art (used with the author's permission,
the owner 2026-11-09; PROVENANCE.md), kept as drawn: R246's renderer draws it as the original's host does (its curves
too). The one change: ids l0 .. l6 on the list's seven shapes, so the page can recolour them (the original's host
finds them by their colour, 0x2C4362); ids change nothing drawn. The art's ink spans y 17..131, inside the OLED's
bottom margin (y 3..138). Everything else on the page is drawn by dimension_screen.h (a port of the original's page).

    python3 gen_svg.py
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    src = open(os.path.join(HERE, 'dimension-art.svg')).read()
    head, sep, rest = src.partition('<g id="list">')
    assert sep, 'no list group'
    n = 0

    def tag(m):
        nonlocal n
        out = f'<{m.group(1)} id="l{n}"'
        n += 1
        return out
    rest = re.sub(r'<(path|polyline)(?= )', tag, rest)
    assert n == 7, n
    with open(os.path.join(HERE, 'dimension.svg'), 'w') as fh:
        fh.write(head + sep + rest)
    print(os.path.join(HERE, 'dimension.svg'))


if __name__ == '__main__':
    main()
