/* DIMENSION's oscillator pass and ensemble taps, hand-scheduled for the Blackfin: dimension.c's dm_osc_k, dm_tap_k and dm_tapg_k (the C
 * stays for host builds and as kern_check.py's reference, DIMENSION_C_LOOP), bit for bit.
 *
 * void dm_tap_k(int32_t *wet, const int16_t *t, int32_t n, int32_t d, int32_t sd, int32_t add): n pairs of one tap
 *   with one whole delay, t[j] the tap's sample for pair j: x = t[j] + (((t[j - 1] - t[j]) * ((d >> 1) & 32767)) >> 15),
 *   wet[j] = x (add 0) or wet[j] + x, d += sd. Once a block on the voices' sum (ens_bus).
 * void dm_tapg_k(int32_t *wet, const int16_t *now, int32_t d, int32_t sd, int32_t add): a tap whose whole delay moves
 *   within the block: 64 pairs, pair j read at now[j - (d >> 16)], otherwise as dm_tap_k.
 * void dm_osc_k(int32_t *x, uint32_t *rng, const int32_t *k): the saw (and the noise) of a block, k = { p0, step,
 *   as | an << 16 }: x[i] = as * ((phi >> 16) - 32768) + an * (rng >> 16 signed), the noise only with rng given.
 * L1 saved and zeroed (I1 reads; R246 may leave it set); M1 is not touched (R246's PmSynth keeps its frame there).
 * Host builds assemble it empty.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifdef __bfin__
	.text
	.align 4
	.global _dm_tap_k
	.type _dm_tap_k, STT_FUNC
_dm_tap_k:
	[--SP] = (R7:4);
	R4 = [SP + 28];                                      /* d */
	R5 = [SP + 32];                                      /* sd */
	R6 = [SP + 36];                                      /* add */
	CC = R2 <= 0;
	IF CC JUMP .Lt_done;
	P0 = R1;                                             /* t[j] */
	P1 = R0;                                             /* wet[j], written */
	I1 = R0;                                             /* wet[j], read */
	R3 = L1;
	[--SP] = R3;
	R3 = 0;
	L1 = R3;
	P2 = R2;
	R7 = 32767 (X);
	CC = R6 == 0;
	IF CC JUMP .Lt_set;
	LSETUP (.Lta_b, .Lta_e) LC0 = P2;
.Lta_b:
	R0 = W [P0 + -2] (X);                                /* t[j - 1] */
	R1 = W [P0++] (X);                                   /* t[j] */
	R3 = R4 >>> 1;
	R0 = R0 - R1 (NS) || R2 = [I1++];
	R3 = R3 & R7;
	R0 *= R3;
	R0 >>>= 15;
	R0 = R0 + R1 (NS);
	R2 = R2 + R0 (NS);
.Lta_e:
	R4 = R4 + R5 (NS) || [P1++] = R2;
	JUMP .Lt_out;
.Lt_set:
	LSETUP (.Lts_b, .Lts_e) LC0 = P2;
.Lts_b:
	R0 = W [P0 + -2] (X);
	R1 = W [P0++] (X);
	R3 = R4 >>> 1;
	R0 = R0 - R1 (NS);
	R3 = R3 & R7;
	R0 *= R3;
	R0 >>>= 15;
	R0 = R0 + R1 (NS);
.Lts_e:
	R4 = R4 + R5 (NS) || [P1++] = R0;
.Lt_out:
	R3 = [SP++];
	L1 = R3;
.Lt_done:
	(R7:4) = [SP++];
	RTS;
	.size _dm_tap_k, .-_dm_tap_k

	.align 4
	.global _dm_tapg_k
	.type _dm_tapg_k, STT_FUNC
/* R0 wet, R1 now, R2 d, [SP + 12] sd, [SP + 16] add: 64 pairs, pair j read at now + j - (d >> 16) */
_dm_tapg_k:
	[--SP] = (R7:4);
	R5 = [SP + 28];                                      /* sd */
	R6 = [SP + 32];                                      /* add */
	R4 = R2;                                             /* d */
	P0 = R1;                                             /* now + j */
	P1 = R0;                                             /* wet[j], written */
	I1 = R0;                                             /* wet[j], read */
	R3 = L1;
	[--SP] = R3;
	R3 = 0;
	L1 = R3;
	R7 = 32767 (X);
	P2 = 64;
	CC = R6 == 0;
	IF CC JUMP .Lg_set;
	LSETUP (.Lga_b, .Lga_e) LC0 = P2;
.Lga_b:
	R3 = R4 >>> 16;
	R3 = -R3;
	R3 <<= 1;
	P2 = R3;
	P2 = P0 + P2;                                        /* &now[j - d >> 16] */
	R0 = W [P2 + -2] (X);
	R1 = W [P2] (X);
	R3 = R4 >>> 1;
	R0 = R0 - R1 (NS) || R2 = [I1++];
	R3 = R3 & R7;
	R0 *= R3;
	R0 >>>= 15;
	R0 = R0 + R1 (NS);
	R2 = R2 + R0 (NS);
	P0 += 2;
.Lga_e:
	R4 = R4 + R5 (NS) || [P1++] = R2;
	JUMP .Lg_out;
.Lg_set:
	LSETUP (.Lgs_b, .Lgs_e) LC0 = P2;
.Lgs_b:
	R3 = R4 >>> 16;
	R3 = -R3;
	R3 <<= 1;
	P2 = R3;
	P2 = P0 + P2;
	R0 = W [P2 + -2] (X);
	R1 = W [P2] (X);
	R3 = R4 >>> 1;
	R0 = R0 - R1 (NS);
	R3 = R3 & R7;
	R0 *= R3;
	R0 >>>= 15;
	R0 = R0 + R1 (NS);
	P0 += 2;
.Lgs_e:
	R4 = R4 + R5 (NS) || [P1++] = R0;
.Lg_out:
	R3 = [SP++];
	L1 = R3;
	(R7:4) = [SP++];
	RTS;
	.size _dm_tapg_k, .-_dm_tapg_k

	.align 4
	.global _dm_osc_k
	.type _dm_osc_k, STT_FUNC
/* R0 x, R1 &rng (0: no noise), R2 k = { p0, step, as | an << 16 }. R3 = phi XOR 0x80000000, so R3.H is the saw's
 * (phi >> 16) - 32768; R4 step; R5 as (L) | an (H); R0 rng */
_dm_osc_k:
	[--SP] = (R7:4);
	P0 = R0;
	P1 = R1;
	P2 = R2;
	R3 = [P2];
	BITTGL (R3, 31);
	R4 = [P2 + 4];
	R5 = [P2 + 8];
	P2 = 128;
	CC = R1 == 0;
	IF CC JUMP .Lo_saw;
	R0 = [P1];
	LSETUP (.Lon_b, .Lon_e) LC0 = P2;
.Lon_b:
	R3 = R3 + R4 (NS);
	R1 = R0 << 13;
	R0 = R0 ^ R1;
	R1 = R0 >> 17;
	R0 = R0 ^ R1;
	R1 = R0 << 5;
	R0 = R0 ^ R1;
	A0 = R5.L * R3.H (IS);
	R2 = (A0 += R5.H * R0.H) (IS);
.Lon_e:
	[P0++] = R2;
	[P1] = R0;
	JUMP .Lo_out;
.Lo_saw:
	LSETUP (.Los_b, .Los_e) LC0 = P2;
.Los_b:
	R3 = R3 + R4 (NS);
	R2 = R5.L * R3.H (IS);
.Los_e:
	[P0++] = R2;
.Lo_out:
	(R7:4) = [SP++];
	RTS;
	.size _dm_osc_k, .-_dm_osc_k
#endif
