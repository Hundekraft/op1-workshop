/* DIMENSION: a six-voice subtractive synth (kennel synth plugin, dimension.knl).
 * DSP clean-room from a behavioural specification (OP1-Emulator docs/ports/dimension-spec.md) of another creator's
 * engine; no code from it.
 *
 * Per voice, 128 samples at 88.2 kHz a call (R246's voice rate):
 *   one band-limited oscillator (fixed-point polyBLEP) whose blue knob morphs through five crossfades:
 *   noise -> 10 % pulse -> pulse width up to square -> square to saw -> saw to saw + sub -> noise; a random detune
 *   per note (+-151 / 65536 of the pitch, about +-4 cents); a free-running phase;
 *   two cascaded TPT state-variable low-pass sections whose poles come from a table (dimension_tables.h, made by
 *   gen_tables.py from the spec's root-locus model), bilinear on (octaves below 18 kHz, resonance), refreshed per
 *   block when the smoothed cutoff or resonance moved; white = cutoff 30 .. 18,000 Hz, orange = resonance;
 *   then velocity. R246 applies the T2 envelope after render.
 * On the voices' sum, once a block (the core's voice-sum block: 64 samples at 44.1 kHz after R246's envelopes,
 * decimator and high-pass), as the original's bus: the ensemble (green, "unison"), a three-tap modulated delay; then
 * the bus compressor (+9 dB below -15.5 dBFS, 2.5:1 above) and the limiter (ceiling -1 dBFS).
 *
 * Integers only in the audio path; per-sample work is shifts, 16-bit products and 32 x 32 fractional products
 * (mf: one Blackfin MAC sequence, no libgcc); the divisions are per block.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "op1_plugin.h"
#include "dimension_tables.h"

/* (a * b) >> 31, saturating (Q31 x Q31) */
#ifdef __bfin__
static inline __attribute__((always_inline)) int32_t mf(int32_t a, int32_t b) { return __builtin_bfin_mult_fr1x32x32(a, b); }
#else
static inline int32_t mf(int32_t a, int32_t b) { return (int32_t)(((int64_t)a * b) >> 31); }
#endif

static inline int32_t clampi(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }
static inline int32_t maxi(int32_t a, int32_t b) { return a > b ? a : b; }
static inline int32_t absi(int32_t a) { return a < 0 ? -a : a; }
static inline int32_t knob(const int16_t *k, int i) { return k[i] < 0 ? 0 : k[i]; }
static inline int32_t bitlen(uint32_t x)
{
#ifdef __bfin__
    return x >> 31 ? 32 : 31 - (int32_t)__builtin_bfin_norm_fr1x32((int32_t)x);
#else
    return x ? 32 - __builtin_clz(x) : 0;
#endif
}

/* ---- the blue knob: amplitudes (units x 16-bit shapes) and the pulse ---- */
typedef struct {
    int32_t as, asub, ap, an;          /* saw, sub, pulse, noise amplitudes (units; 281 = full) */
    int32_t lo;                        /* the pulse's low level (zero DC) */
    uint32_t thr;                      /* the pulse is high from phi = thr: (1 - w) * 2^32 */
} dm_morph_t;

#define Q_NOISE 0x9CC4                 /* 1.2247, Q15 */
#define Q_PULSE 0xA666                 /* 1.3 */
#define Q_PSLOPE 0x5CAC                /* 0.724 */
#define Q_W0 0x0CCD                    /* 0.1 */
#define Q_WS 0x3333                    /* 0.4 */
#define Q_SQ 0x49BA                    /* 0.576 */
#define Q_SUBT 0x10A4                  /* 0.13 */
#define Q_087 0x6F5C                   /* 0.87 */

static void dm_morph(int32_t x, dm_morph_t *m)
{
    const int32_t x5 = 5 * x, seg = x5 >> 15, f = x5 & 32767;
    const int32_t t = (281 * f) >> 15, r = 281 - t;
    int32_t w = 16384;
    m->as = m->asub = m->ap = m->an = 0;
    switch (seg) {
    case 0:                                                         /* noise -> 10 % pulse */
        m->an = (Q_NOISE * r) >> 15;
        m->ap = (Q_PULSE * t) >> 15;
        w = Q_W0;
        break;
    case 1:                                                         /* the pulse width sweeps up to a square */
        m->ap = (281 * (Q_PULSE - ((Q_PSLOPE * f) >> 15))) >> 15;
        w = Q_W0 + ((Q_WS * f) >> 15);
        break;
    case 2:                                                         /* square -> saw */
        m->ap = (Q_SQ * r) >> 15;
        m->as = t;
        break;
    case 3: {                                                       /* saw -> saw + sub */
        const int32_t tilt = 32767 - ((Q_SUBT * f) >> 15);
        m->as = ((281 - (t >> 2)) * tilt) >> 15;
        m->asub = ((t >> 1) * tilt) >> 15;
        break;
    }
    default:                                                        /* saw + sub -> noise */
        m->an = (Q_NOISE * t) >> 15;
        m->as = (((Q_087 * 3) >> 2) * r) >> 15;
        m->asub = (Q_087 * (r >> 1)) >> 15;
        break;
    }
    m->lo = -(32767 * w) / (32768 - w);                             /* zero DC: w 0.1 -> -3641, 0.5 -> -32767 */
    m->thr = (uint32_t)(32768 - w) << 17;
}

/* ---- the filter: pole table + warped cutoff -> two TPT SVF sections ---- */
/* a section's coefficients as the sample loop takes them: three 16-bit mantissas over one shift E,
 * c = m / 2^(16 + E): w0 = a2m | q2m << 16 (a2 / 2 and q / 2, q = 1 - a1), w1 = -E | g4m << 16 (g / 4) */
typedef struct { int32_t w0, w1; } dm_sec_t;
typedef struct { dm_sec_t s[2]; } dm_coef_t;

/* the cutoff knob -> octaves below 18 kHz, Q27 (0 .. 9.2288 octaves) */
static inline int32_t dm_oct27(int32_t cut) { return (32767 - cut) * 37802; }

static void dm_section(int32_t s13, int32_t k13, int32_t t31, dm_sec_t *o)
{
    /* g = s * tan(pi fc / fs) (spec quirk 2: the scale after the tangent, kept), Q30 */
    const int32_t g = mf(t31, s13 << 16) << 1;
    /* q = 1 - a1 = p / (1 + p), p = g (g + k): p times a 16-bit reciprocal of 1 + p, so q keeps 2^-15 of its own
     * size at low cutoffs (where it is small) with one 32-bit division */
    const int32_t p28 = mf(g, (g >> 1) + (k13 << 16));             /* g (g + k), Q28 (<= 6.6) */
    const uint32_t den = (1u << 28) + (uint32_t)p28;               /* 1 + p, Q28 */
    const int32_t n = bitlen(den);                                 /* 29 .. 31 */
    const uint32_t m = den >> (n - 16), ri = (m - 32768) >> 7, rf = m & 127;   /* 2^15 .. 2^16 - 1 */
    const uint32_t r = (uint32_t)DM_RCP[ri] - ((((uint32_t)DM_RCP[ri] - (uint32_t)DM_RCP[ri + 1]) * rf) >> 7);   /* 2^31 / m */
    uint32_t q31 = (uint32_t)mf(p28, (int32_t)(r << 15)) << (32 - n);   /* p / (1 + p), Q31 */
    if (q31 > 0x7FFFFFFFu) q31 = 0x7FFFFFFFu;
    const int32_t a1 = (int32_t)(0x80000000u - q31);              /* Q31 */
    /* as fractions of 2^32, each under 1/2: q / 2 = (1 - a1) / 2, a2 / 2, g / 4 */
    const uint32_t cq = q31, ca = (uint32_t)mf(g, a1) << 1, cg = (uint32_t)g;
    uint32_t mx = cq > ca ? cq : ca;
    if (cg > mx) mx = cg;
    int32_t e = 31 - bitlen(mx);                                   /* the largest mantissa lands in 2^14 .. 2^15 */
    if (e > 15) e = 15;
    const int32_t sh = 16 - e;
    o->w0 = (int32_t)((ca >> sh) | ((cq >> sh) << 16));
    o->w1 = (int32_t)((uint32_t)(-e & 0xFFFF) | ((cg >> sh) << 16));
}

static void dm_coef(int32_t cut, int32_t res, dm_coef_t *c)
{
    const int32_t d = dm_oct27(cut);
    const int32_t n = d >> 27, fr = (d >> 12) & 32767;              /* octave row and its weight, Q15 */
    const int32_t jj = res << 4, j = jj >> 15, fj = jj & 32767;     /* resonance column and its weight */
    const int16_t *p00 = DM_POLE[n][j], *p01 = DM_POLE[n][j + 1], *p10 = DM_POLE[n + 1][j], *p11 = DM_POLE[n + 1][j + 1];
    int32_t v[4];
    for (int i = 0; i < 4; i++) {
        const int32_t a = p00[i] + (((p01[i] - p00[i]) * fj) >> 15);
        const int32_t b = p10[i] + (((p11[i] - p10[i]) * fj) >> 15);
        v[i] = a + (((b - a) * fr) >> 15);
    }
    /* tan(pi fc / 88200) at 1/16 octave, interpolated (Q31) */
    const int32_t ti = d >> 23, tf = (d >> 7) & 0xFFFF;
    const int32_t t31 = DM_TAN[ti] - mf(DM_TAN[ti] - DM_TAN[ti + 1], tf << 15);
    dm_section(v[0], v[1], t31, &c->s[0]);
    dm_section(v[2], v[3], t31, &c->s[1]);
}

/* the cutoff the white knob gives, in whole Hz (the screen's readout): 18000 * 2^-D */
static int32_t dm_hz(int32_t cut)
{
    const int32_t d = dm_oct27(cut), n = d >> 27, f8 = (d >> 19) & 255, ff = (d >> 3) & 0xFFFF;
    const int32_t e0 = DM_EXP2[f8], e = e0 - (int32_t)(((int64_t)(e0 - DM_EXP2[f8 + 1]) * ff) >> 16);   /* 2^-frac, Q30 */
    return (int32_t)(((int64_t)18000 * e + ((int64_t)1 << (29 + n))) >> (30 + n));
}

/* ---- the oscillator and the filter: one voice's 128 samples ---- */
typedef struct {
    uint32_t u;                        /* phase at half rate: phi = 2u, the sub is u's top bit */
    int32_t prev;                      /* the last oscillator sample, still open to a polyBLEP correction */
    int32_t s[4];                      /* section A s1, s2, section B s1, s2 */
    uint32_t rng;                      /* xorshift32: noise and the detune */
} dm_core_t;

#define BLEP_MIN 0x100000u             /* below this step (~20.5 Hz) no polyBLEP (harmless) */

/* the polyBLEP pair of a jump j at d (Q15: the fraction of a sample since the edge) */
static inline __attribute__((always_inline)) void blep(int32_t *prev, int32_t *cur, int32_t j, int32_t d)
{
    const int32_t jh = j >> 10, e = 32767 - d;
    *cur -= (jh * ((e * e) >> 15)) >> 6;              /* -(1 - d)^2 j / 2 */
    *prev += (jh * ((d * d) >> 15)) >> 6;             /* +d^2 j / 2 */
}

/* one SVF section over the block, in place (TPT low-pass: v1 = a1 s1 + a2 (v0 - s2), v2 = s2 + g v1, then
 * s1 = 2 v1 - s1, s2 = 2 v2 - s2), in the form the Blackfin kernel (dimension_svf.S, bit for bit) computes:
 *   t = floor((a2m (x - s2) - q2m s1) / 2^(16 + E))     v1 = s1 + 2 t      s1 += 4 t
 *   u = floor(g4m v1 / 2^(16 + E))                       v2 = s2 + 4 u      s2 += 8 u
 * Each mantissa product is one dual MAC (32 x 16), the coefficients keep 2^-15 relative precision at every cutoff */
#if defined(__bfin__) && !defined(DIMENSION_C_LOOP)
void dm_svf_k(int32_t *x, int32_t *st, const dm_sec_t *c);
#define dm_svf dm_svf_k
#else
static void dm_svf(int32_t *x, int32_t *st, const dm_sec_t *c)
{
    int32_t s1 = st[0], s2 = st[1];
    const int32_t am = (int16_t)(c->w0 & 0xFFFF), qm = c->w0 >> 16, e = -(int32_t)(int16_t)(c->w1 & 0xFFFF), gm = c->w1 >> 16;
    for (int i = 0; i < OP1_BLOCK; i++) {
        const int32_t t = (int32_t)(((int64_t)am * (x[i] - s2) - (int64_t)qm * s1) >> 16) >> e;
        const int32_t v1 = s1 + 2 * t;
        s1 = v1 + 2 * t;
        const int32_t u = (int32_t)(((int64_t)gm * v1) >> 16) >> e;
        const int32_t v2 = s2 + 4 * u;
        s2 = v2 + 4 * u;
        x[i] = v2;
    }
    st[0] = s1; st[1] = s2;
}
#endif

/* the first sample k >= s (k < 128: else 128) where the phase phi_k = p0 + (k + 1) step reaches t, i.e. (phi_k - t) mod
 * 2^32 < step: the phase before sample s is p0 + s step, and the crossing comes after ceil(r / step) more steps,
 * r = (t - that) mod 2^32 (0 meaning a whole cycle). One division per edge, none per sample. */
static inline int32_t next_edge(uint32_t p0, uint32_t step, uint32_t t, int32_t s)
{
    const uint32_t r1 = t - (p0 + (uint32_t)s * step) - 1u;          /* r - 1, r in 1 .. 2^32 */
    const uint32_t m = r1 / step;
    return m >= (uint32_t)(OP1_BLOCK - s) ? OP1_BLOCK : s + (int32_t)m;
}
/* the same edge's next one after sample e: crossings of one level are floor or ceil of 2^32 / step samples apart, so
 * it is e + per (per = floor((2^32 - 1) / step)) if that sample crosses, else the one after: no division */
static inline int32_t edge_after(uint32_t p0, uint32_t step, uint32_t t, int32_t e, int32_t per)
{
    const int32_t k = e + per;
    if (k >= OP1_BLOCK) return OP1_BLOCK;
    return (p0 + (uint32_t)(k + 1) * step) - t < step ? k : (k + 1 < OP1_BLOCK ? k + 1 : OP1_BLOCK);
}

/* the saw (and the noise) of a block: x[i] = as * ((phi >> 16) - 32768) + an * ((int32_t)rng >> 16), phi = p0 + (i + 1)
 * step, rng stepped (xorshift32 13, 17, 5) once a sample when there is noise (rng not 0); k = { p0, step, as | an << 16 }.
 * dimension_ens.S's dm_osc_k, bit for bit (there the saw is one 16-bit product of phi's top half XOR 0x8000) */
#if defined(__bfin__) && !defined(DIMENSION_C_LOOP)
void dm_osc_k(int32_t *x, uint32_t *rng, const int32_t *k);
#else
static void dm_osc_k(int32_t *x, uint32_t *rngp, const int32_t *k)
{
    uint32_t phi = (uint32_t)k[0];
    const uint32_t step = (uint32_t)k[1];
    const int32_t as = (int16_t)(k[2] & 0xFFFF), an = k[2] >> 16;
    if (rngp) {
        uint32_t rng = *rngp;
        for (int i = 0; i < OP1_BLOCK; i++) {
            phi += step;
            rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
            x[i] = as * ((int32_t)(phi >> 16) - 32768) + an * ((int32_t)rng >> 16);
        }
        *rngp = rng;
    } else
        for (int i = 0; i < OP1_BLOCK; i++) {
            phi += step;
            x[i] = as * ((int32_t)(phi >> 16) - 32768);
        }
}
#endif

/* the oscillator into x[0..127] (x[-1] is the previous block's last sample, still open to a correction: the output
 * runs one sample late), then the two filter sections, then the voice's level into y.
 * The saw (and the noise) per sample; the sub and the pulse are constant between edges, so they are added run by run,
 * edge to edge, and each edge gets its polyBLEP pair there. */
static int32_t dm_core(dm_core_t *v, int32_t *y, uint32_t step, const dm_morph_t *m, const dm_coef_t *c)
{
    int32_t xb[OP1_BLOCK + 1], *x = xb + 1;
    const uint32_t u0 = v->u, p0 = u0 << 1, half = step >> 1, thr = m->thr;
    const int32_t as = m->as, asub = m->asub, ap = m->ap, an = m->an, lo = m->lo;
    const int32_t plo = ap * lo, phi_ = ap * 32767, sh = asub * 32767, sl = asub * -32768;
    const int32_t jwrap = -65535 * as + ap * (lo - 32767), jrise = ap * (32767 - lo), jsub = asub * 65535;
    xb[0] = v->prev;
    /* the saw; white noise (the voice's xorshift32) when the morph has it (dm_osc_k: dimension_ens.S on the Blackfin) */
    {
        const int32_t k[3] = { (int32_t)p0, (int32_t)step, (as & 0xFFFF) | (an << 16) };
        dm_osc_k(x, an ? &v->rng : 0, k);
    }
    /* the sub and the pulse, run by run; the edges' corrections */
    const int on = step >= BLEP_MIN;
    const int32_t rcp = on ? (int32_t)((1u << 30) / (step >> 16)) : 0;   /* d = (x >> 16) * rcp >> 15 */
    const int pulse = ap != 0, sub = asub != 0;
    if (!pulse && !sub && !as) {                                   /* noise only */
        v->u = u0 + half * OP1_BLOCK;
        v->prev = x[OP1_BLOCK - 1];
        goto filter;
    }
    {
        int32_t k = 0;
        int32_t kw = next_edge(p0, step, 0, 0), kr = pulse ? next_edge(p0, step, thr, 0) : OP1_BLOCK;
        const int32_t per = (int32_t)(0xFFFFFFFFu / step) > OP1_BLOCK ? OP1_BLOCK : (int32_t)(0xFFFFFFFFu / step);
        uint32_t ph = p0 + step, uu = u0 + half;                    /* the phases at sample 0 */
        int32_t lvl = ((int32_t)uu < 0 ? sl : sh) + (ph < thr ? plo : phi_);
        for (;;) {
            const int32_t e = kw < kr ? kw : kr;
            for (; k < e; k++) x[k] += lvl;
            if (e >= OP1_BLOCK) break;
            ph = p0 + (uint32_t)(e + 1) * step;
            uu = u0 + (uint32_t)(e + 1) * half;
            lvl = ((int32_t)uu < 0 ? sl : sh) + (ph < thr ? plo : phi_);
            x[e] += lvl;
            if (e == kw) {                                         /* the wrap: saw and pulse drop, the sub flips */
                if (on) blep(&x[e - 1], &x[e], jwrap + ((int32_t)uu < 0 ? -jsub : jsub),
                             clampi((int32_t)(((ph >> 16) * (uint32_t)rcp) >> 15), 0, 32767));
                kw = edge_after(p0, step, 0, e, per);
            }
            if (e == kr) {                                         /* the pulse rises */
                const uint32_t pr = ph - thr;
                if (on) blep(&x[e - 1], &x[e], jrise, clampi((int32_t)(((pr >> 16) * (uint32_t)rcp) >> 15), 0, 32767));
                kr = edge_after(p0, step, thr, e, per);
            }
            k = e + 1;
        }
    }
    v->u = u0 + half * OP1_BLOCK;
    v->prev = x[OP1_BLOCK - 1];
filter:
    dm_svf(xb, v->s, &c->s[0]);                                    /* xb[0 .. 127]: one sample late */
    dm_svf(xb, v->s + 2, &c->s[1]);
    int32_t pk = 0;
    for (int i = 0; i < OP1_BLOCK; i++) {                          /* v2 / 2048 (no clip: the dynamics keep the ceiling) */
        const int32_t o = (xb[i] + 1024) >> 11;
        y[i] = o;
        pk = maxi(pk, absi(o));
    }
    return pk;
}

/* ---- per voice ---- */
#define LINE 512                       /* the ensemble's delay line, 44.1 kHz samples (11.6 ms), kept twice over */
typedef struct {
    dm_core_t core;
    int32_t det;                       /* detune, -151 .. 151 (/ 65536 of the pitch) */
    /* the Shift layer: the filter envelope, accent and slide */
    int32_t ev, ea;                    /* the envelope and the accent's sweep, Q30 (1 at the note's start) */
    int32_t af;                        /* the note's accent from its velocity, Q15 */
    int32_t cc, cr;                    /* the cutoff and resonance of this voice's own coefficients (-1: none) */
    dm_coef_t coef;
    int32_t gr;                        /* the slide: pitch ratio still to go, Q16 (65536 = there) */
    uint32_t src, cur;                 /* the step slid from; the step this voice played last */
    uint32_t seq;                      /* note-on order, for the newest held note */
    uint8_t held, fresh, pending;
    uint8_t ready;
} dm_voice_t;

static dm_voice_t vc[OP1_VOICES];
static uint32_t dm_seed = 0x2545F491u;
static int last_voice = OP1_VOICES;

static void voice_init(dm_voice_t *v)
{
    v->core.u = 0x40000000u;           /* phi = 0x80000000: saw at 0, sub high */
    v->core.prev = 0;
    v->core.s[0] = v->core.s[1] = v->core.s[2] = v->core.s[3] = 0;
    dm_seed += 0x9E3779B9u;
    v->core.rng = dm_seed | 1;
    v->det = 0;
    v->ev = v->ea = 0; v->af = 0; v->cc = v->cr = -1;
    v->gr = 65536; v->src = v->cur = 0; v->seq = 0; v->held = v->fresh = v->pending = 0;
    v->ready = 1;
}

/* ---- the instrument's state, advanced once per block by the first voice rendered in it ----
 * The waveform, cutoff and resonance knobs, smoothed a quarter of the way a block (the first block snaps), with the
 * morph and the filter coefficients made from them; the ensemble's amount, LFO and tap delays. One set for all
 * voices (the original smooths per voice; the same values once a knob rests). */
#define LFO_STEP 0x3910C0u             /* per 64 output samples: 0.6 Hz */
#define ENS_BASE (154 << 16)           /* the taps' centre delay, Q16 samples at 44.1 kHz (3.49 ms) */
static int32_t sm0 = -1, sm2 = -1, sm3 = -1;
static dm_morph_t ins_morph;
static dm_coef_t ins_coef;
static uint32_t ens_lfo;           /* the LFO */
static int32_t ens_a0, ens_a1 = -1;    /* the amount at the block's start / end (0 .. 32767); -1 = not yet */
static int32_t ens_d0[3], ens_d1[3];   /* each tap's delay at the block's start / end, Q16 samples */
/* a tap's block in two stretches of one whole delay each (the delay moves under half a sample a block: 79 samples at
 * 0.6 Hz, so its whole part changes at most once while the amount rests): pairs j[h] .. j[h + 1] - 1 read di[h]
 * back; the delay itself steps sd a pair (Q16), as in the plain path */
typedef struct { int32_t j[3], di[2], sd, gen; } ens_run_t;   /* gen: more than one change (the amount moves) */
static ens_run_t ens_run[3];
static int32_t ens_mix[OP1_BLOCK / 2]; /* per sample: the dry gain (Q15) | the wet gain (a, Q15) << 16 */

static void ens_runs(void)
{
    for (int k = 0; k < 3; k++) {
        ens_run_t *r = &ens_run[k];
        const int32_t d0 = ens_d0[k], sd = (ens_d1[k] - d0) >> 6, di = d0 >> 16;
        int32_t n = OP1_BLOCK / 2;                                 /* the pairs before the whole part changes */
        if (sd > 0) n = ((((di + 1) << 16) - d0) + sd - 1) / sd;
        else if (sd < 0) n = (d0 - (di << 16)) / -sd + 1;
        if (n > OP1_BLOCK / 2) n = OP1_BLOCK / 2;
        const int32_t d1 = d0 + sd * n;
        r->gen = (d0 + sd * (OP1_BLOCK / 2 - 1)) >> 16 != d1 >> 16 && n < OP1_BLOCK / 2;   /* a second change */
        if (sd > 16384 || sd < -16384) r->gen = 1;
        r->j[0] = 0; r->j[1] = n; r->j[2] = OP1_BLOCK / 2;
        r->di[0] = di; r->di[1] = d1 >> 16;
        r->sd = sd;
    }
}

static void ens_delays(int32_t a, int32_t *d)
{
    const int16_t *tab = op1_sin_tab();
    const int32_t depth = (a * 158) >> 8;                           /* 79 * a / 32767 samples, Q8 */
    for (int k = 0; k < 3; k++) {
        const uint32_t ph = ens_lfo + (uint32_t)k * 0x55555555u;
        const int32_t l = -op1_sin_q(tab, (int32_t)(ph >> 19) + 2048);   /* -cos, Q15 */
        d[k] = ENS_BASE + ((l * depth) >> 7);
    }
}

/* the Shift layer (op1_engine_shift; preset words 5, 6, 7; 0 = off, the original's sound): Shift + blue ENV (word 5),
 * Shift + green DECAY (word 6), Shift + white ACCENT (word 7 bits 0..6) and Shift + orange SLIDE (word 7 bits 8..14),
 * 0..127 each; bits 7 and 15 are the core's. A turn or the matrix LFO's shift rows move the words; the voices read them. */
#define ENV_OCT 21304                  /* ENV at full: the envelope opens the cutoff 6 octaves (3,550.6 knob units each) */
#define ACC_OCT 10652                  /* ACCENT at full: an accented note's sweep adds 3 octaves */
static int32_t p2_env, p2_acc;         /* ENV depth (knob units), ACCENT (Q15) */
static int32_t p2_xd, p2_xa, p2_xs;    /* per block: the envelope's and the accent's decay, the slide's step, Q30 */
static int p2_slide;                   /* SLIDE on */

/* x0 * 2^(-i / 256), Q30 in and out */
static int32_t dm_exp2n(int32_t x0, int32_t i)
{
    const int32_t n = i >> 8;
    return n > 30 ? 0 : mf(x0, DM_EXP2[i & 255] >> n) << 1;
}
static inline int32_t p2_accent(int32_t w7) { return w7 & 127; }
static inline int32_t p2_slidew(int32_t w7) { return (w7 >> 8) & 127; }
static inline int32_t p2_decay_ms(int32_t w6)   /* the screen's readout: 30 ms * 2^(w * 6.059 / 32767) */
{ return (int32_t)(((int64_t)30 << 30) / dm_exp2n(1 << 30, ((w6 < 0 ? 0 : w6) * 1551) >> 15)); }
static inline int32_t p2_slide_ms(int32_t sl) { return sl ? (int32_t)(((int64_t)10 << 30) / dm_exp2n(1 << 30, ((sl - 1) * 1701) / 126)) : 0; }

static void p2_block(const int16_t *k)
{
    const int32_t w5 = knob(k, 5), w6 = knob(k, 6), w7 = k[7];
    p2_env = (w5 * ENV_OCT) >> 15;
    p2_acc = (p2_accent(w7) * 32767) / 127;
    /* DECAY: 30 ms .. 2 s; per block the envelope loses x = Tb / tau (Tb = 1 / 689.06 s): 0.04837 * 2^-(w 6.059 / 32767) */
    p2_xd = dm_exp2n(51937000, (w6 * 1551) >> 15);
    p2_xa = p2_xd > 7791000 ? p2_xd : 7791000;                   /* the accent's sweep: 200 ms at most */
    const int32_t sl = p2_slidew(w7);                              /* SLIDE: 10 ms .. 1 s */
    p2_slide = sl > 0;
    p2_xs = sl ? dm_exp2n(155830000, ((sl - 1) * 1701) / 126) : 1 << 30;
}

static int dm_smooth(int32_t *y, int32_t x)
{
    const int32_t o = *y;
    *y = o < 0 ? x : o + ((x - o) >> 2);
    return *y != o;
}

/* the voices' part of a block (the first voice rendered in it): the Shift layer, the morph and the filter coefficients */
static uint32_t vblk;                  /* voice blocks rendered (the envelope coefficients' every other block) */
static int16_t ens_knob = -1;          /* green as the last voice block read it (the sum block's amount); -1: none */
static void block_shared(const int16_t *k)
{
    p2_block(k);
    if (dm_smooth(&sm0, knob(k, 0))) dm_morph(sm0, &ins_morph);
    const int c = dm_smooth(&sm2, knob(k, 2));
    if (dm_smooth(&sm3, knob(k, 3)) | c) dm_coef(sm2, sm3, &ins_coef);
    ens_knob = (int16_t)knob(k, 1);
    vblk++;
}

/* the ensemble's amount, LFO and tap delays, a block (spec 4.8, 4.10): the amount a quarter of the way to green (the
 * first block snaps), the LFO 0.6 Hz, each tap's delay at the block's start and end, the mix gains per sample */
static void ens_block(void)
{
    const int32_t x = ens_knob < 0 ? 0 : ens_knob;
    if (ens_a1 < 0) {                                              /* first block: snap */
        ens_a1 = x;
        ens_delays(x, ens_d1);
    }
    ens_a0 = ens_a1;
    for (int i = 0; i < 3; i++) ens_d0[i] = ens_d1[i];
    const int32_t dx = x - ens_a1;
    ens_a1 += dx >= 0 ? (dx + 3) >> 2 : -((-dx + 3) >> 2);         /* a quarter of the way, reaching it exactly */
    ens_lfo += LFO_STEP;
    ens_delays(ens_a1, ens_d1);
    ens_runs();
    static int32_t mix_flat = -1;      /* ens_mix holds this amount in every sample (-1: a ramp) */
    if (ens_a0 != ens_a1 || mix_flat != ens_a1) {
        int32_t a = ens_a0 << 6;
        const int32_t sa = ens_a1 - ens_a0;                         /* a: Q6 over the 64 samples */
        for (int j = 0; j < OP1_BLOCK / 2; j++, a += sa) {
            const int32_t am = a >> 6;
            ens_mix[j] = (32768 - (am >> 1)) | (am << 16);         /* dry 1 - a / 65536, wet a / 32768 */
        }
        mix_flat = ens_a0 == ens_a1 ? ens_a1 : -1;
    }
}

/* ---- the bus: the ensemble, the compressor and the limiter on the voices' sum (spec 4.10, 4.11) ----
 * dimension_block runs once a block on the 64 summed 44.1 kHz samples, in place. The block is written into the
 * 512-sample line first; the taps read at least 75 samples back (154 - 79), linearly interpolated, and the wet is
 * their sum / 4 through the one-pole low-pass; the mix ramps over the block. A tap whose whole delay moves within
 * the block reads one sample at a time (dm_tapg_k), else two stretches of one whole delay (dm_tap_k). */
static int16_t bus_line[2 * LINE];     /* bus_line[i + 512] = bus_line[i]: a tap reads below the block without a wrap */
static uint32_t bus_w;                 /* the write position: a multiple of 64 */
static int32_t bus_lp;                 /* the wet low-pass */
static int32_t cmp_env, cmp_g = 4096, lim_g = 8192;   /* the follower; the compressor's last gain (Q12); the limiter's (Q13) */

#if defined(__bfin__) && !defined(DIMENSION_C_LOOP)
void dm_tap_k(int32_t *wet, const int16_t *t, int32_t n, int32_t d, int32_t sd, int32_t add);
void dm_tapg_k(int32_t *wet, const int16_t *now, int32_t d, int32_t sd, int32_t add);
#else
/* one tap's stretch of samples with one whole delay: wet[j] (+)= t[j] + (t[j - 1] - t[j]) x frac, d (Q16) stepping sd;
 * dimension_ens.S's dm_tap_k, bit for bit */
static void dm_tap_k(int32_t *wet, const int16_t *t, int32_t n, int32_t d, int32_t sd, int32_t add)
{
    for (int j = 0; j < n; j++, d += sd) {
        const int32_t t0 = t[j], x = t0 + (((t[j - 1] - t0) * ((d >> 1) & 32767)) >> 15);
        wet[j] = add ? wet[j] + x : x;
    }
}
/* a tap whose whole delay moves within the block (the amount moving): the 64 samples, each read at now[j - (d >> 16)];
 * dimension_ens.S's dm_tapg_k, bit for bit */
static void dm_tapg_k(int32_t *wet, const int16_t *now, int32_t d, int32_t sd, int32_t add)
{
    for (int j = 0; j < OP1_BLOCK / 2; j++, d += sd) {
        const int16_t *t = now + j - (d >> 16);
        const int32_t t0 = t[0], x = t0 + (((t[-1] - t0) * ((d >> 1) & 32767)) >> 15);
        wet[j] = add ? wet[j] + x : x;
    }
}
#endif

static void ens_bus(int16_t *b)
{
    int16_t *ln = bus_line + bus_w, *now = ln + LINE;
    for (int j = 0; j < OP1_BLOCK / 2; j++) {                     /* the block into the line first */
        ln[j] = b[j]; now[j] = b[j];
    }
    bus_w = (bus_w + OP1_BLOCK / 2) & (LINE - 1);
    if (ens_a0 == 0 && ens_a1 == 0) { bus_lp = 0; return; }       /* bypass: the block unchanged, the wet reset */
    static int32_t wet[OP1_BLOCK / 2];
    for (int k = 0; k < 3; k++) {
        const ens_run_t *r = &ens_run[k];
        if (r->gen) {                                              /* the amount is moving: one sample at a time */
            dm_tapg_k(wet, now, ens_d0[k], (ens_d1[k] - ens_d0[k]) >> 6, k);
            continue;
        }
        for (int h = 0; h < 2; h++) {
            const int32_t j0 = r->j[h], n = r->j[h + 1] - j0;
            if (n > 0) dm_tap_k(wet + j0, now - r->di[h] + j0, n, ens_d0[k] + r->sd * j0, r->sd, k);
        }
    }
    int32_t lp = bus_lp;
    for (int j = 0; j < OP1_BLOCK / 2; j++) {
        lp = (24885 * (wet[j] >> 2) + 7883 * lp + 16384) >> 15;   /* the taps / 4, low-passed (rounded: no stuck -1) */
        const int32_t m = ens_mix[j];
        b[j] = (int16_t)clampi(((b[j] * (m & 0xFFFF)) >> 15) + ((lp * (m >> 16)) >> 15), -32768, 32767);
    }
    bus_lp = lp;
}

#define CMP_THR 4184                   /* log2 x 256 of the follower: a block peak of 5,504 (-15.5 dBFS) */
#define CMP_SLOPE 154                  /* / 256: 2.5:1 above */
#define CMP_MAKEUP 5772                /* / 2048: +9.0 dB */
#define LIM_CEIL 29206                 /* -1.0 dBFS */
#define CMP_CLAMP 131071               /* the compressor's output, 18 bits */

static void dyn_bus(int16_t *b)
{
    static int32_t x1[OP1_BLOCK / 2];
    int32_t p = 0;
    for (int j = 0; j < OP1_BLOCK / 2; j++) p = maxi(p, absi(b[j]));
    /* the compressor: a peak follower (instant up, down 1/128 a block: 186 ms), log2 x 256, 2.5:1 above the
     * threshold, +9 dB make-up */
    const int32_t e16 = p << 4;
    int32_t e = cmp_env;
    if (e16 > e) e = e16; else { e -= (e >> 7) + 1; if (e < 0) e = 0; }
    cmp_env = e;
    int32_t gr = 0;
    if (e > 0) {
        const int32_t ex = bitlen((uint32_t)e) - 1;
        const int32_t l = (ex << 8) + (int32_t)((((uint32_t)e << (31 - ex)) >> 23) & 255);
        if (l > CMP_THR) gr = ((l - CMP_THR) * CMP_SLOPE) >> 8;
    }
    int32_t gc = 0;                                                /* Q12 */
    if (gr < 15 * 256) {
        const int32_t g30 = DM_EXP2[gr & 255] >> (gr >> 8);
        gc = ((g30 >> 14) * CMP_MAKEUP) >> 15;                     /* g30 x 5772 / 2048, Q12 */
    }
    int32_t g0 = cmp_g;                                            /* lower: at once; higher: ramp over the block */
    cmp_g = gc;
    if (gc < g0) g0 = gc;
    int32_t p1 = 0, g = g0 << 6;
    const int32_t sg = gc - g0;
    for (int j = 0; j < OP1_BLOCK / 2; j++, g += sg) {
        const int32_t y = clampi((b[j] * (g >> 6)) >> 12, -CMP_CLAMP, CMP_CLAMP);
        x1[j] = y;
        p1 = maxi(p1, absi(y));
    }
    /* the limiter: recovers 1/128 a block, drops at once so the block's peak lands on the ceiling */
    int32_t gl = lim_g;
    gl += (8192 - gl + 127) >> 7;
    if (p1 > 0 && ((p1 * gl) >> 13) > LIM_CEIL) gl = (LIM_CEIL << 13) / p1;
    int32_t l0 = lim_g;
    lim_g = gl;
    if (gl < l0) l0 = gl;
    g = l0 << 6;
    const int32_t sl = gl - l0;
    for (int j = 0; j < OP1_BLOCK / 2; j++, g += sl)
        b[j] = (int16_t)clampi((x1[j] * (g >> 6)) >> 13, -32768, 32767);
}

/* the voice-sum block (op1_engine_sum_t): fresh (the sound newly in use): the line, the wet and the dynamics from rest */
static void dimension_block(int16_t *bus, int fresh)
{
    if (fresh) {
        for (int i = 0; i < 2 * LINE; i++) bus_line[i] = 0;
        bus_w = 0; bus_lp = 0;
        cmp_env = 0; cmp_g = 4096; lim_g = 8192;
        ens_a1 = -1;
    }
    ens_block();
    ens_bus(bus);
    dyn_bus(bus);
}

/* ---- the engine ---- */
static void dimension_render(void *self, int16_t *out, const int16_t *knobs)
{
    const int vi = op1_voice_index(self);
    dm_voice_t *v = &vc[vi];
    int32_t y[OP1_BLOCK];
    if (!v->ready) voice_init(v);
    if (vi <= last_voice) block_shared(knobs);
    last_voice = vi;

    uint32_t step = (uint32_t)OP1_PITCH_INC[0];
    if (step > 0x3FFFFFFFu) step = 0x3FFFFFFFu;
    if (v->fresh) {                    /* the firmware writes pitch and velocity around note_on */
        v->fresh = 0;
        const int32_t vel = OP1_VOICE_VEL[vi] >> 8;
        v->af = vel > 0 && vel <= 127 ? clampi((vel - 64) * 528, 0, 32767) : 32767;   /* 64 -> 0, 126 up -> full */
    }
    if (v->pending) {                  /* a slide: start from the held note's pitch */
        v->pending = 0;
        if (v->src && step) {
            /* src / step, Q16, through DM_RCP (step's 16-bit mantissa): no 64-bit division */
            const int32_t n = bitlen(step);
            const uint32_t m = n > 16 ? step >> (n - 16) : step << (16 - n), ri = (m - 32768) >> 7, rf = m & 127;
            const int32_t rc = (int32_t)((uint32_t)DM_RCP[ri] - ((((uint32_t)DM_RCP[ri] - (uint32_t)DM_RCP[ri + 1]) * rf) >> 7));
            const int32_t x = mf((int32_t)(v->src >> 1), rc << 15);   /* src / 2 x 2^31 / m / 2^16 */
            const int32_t sh = 18 - n;                                 /* r = x 2^(18 - n) */
            int32_t r = sh >= 0 ? (x > (0x7FFFFFFF >> sh) ? 0x7FFFFFFF : x << sh) : x >> -sh;
            v->gr = clampi(r, 4096, (16 << 16) - 1);                   /* +-4 octaves */
        }
    }
    if (v->gr != 65536) {
        const int32_t q = mf((int32_t)step, v->gr << 11);          /* step x gr / 2^20 */
        step = q > (0x3FFFFFFF >> 4) ? 0x3FFFFFFFu : (uint32_t)q << 4;
        v->gr -= mf((v->gr - 65536) * 1024, p2_xs << 1) >> 10;
        if (v->gr - 65536 < 8 && 65536 - v->gr < 8) v->gr = 65536;
    }
    v->cur = step;
    step = (step + (uint32_t)((int32_t)(step >> 16) * v->det)) & ~1u;
    if (step < 2) step = 2;                                        /* no pitch: the edge search divides by it */

    /* the filter envelope and the accent: this voice's own coefficients; with both off the instrument's */
    const dm_coef_t *co = &ins_coef;
    if (p2_env || p2_acc) {
        const int32_t av = (p2_acc * v->af) >> 15, ea15 = v->ea >> 15;
        const int32_t off = (mf(p2_env << 15, v->ev) + mf(((ACC_OCT * av) >> 15) << 15, v->ea)) >> 14;
        const int32_t cut = clampi(sm2 + off, 0, 32767);
        const int32_t boost = (av * ea15) >> 15;                   /* the accent's resonance: up to 60 % of the rest */
        const int32_t res = clampi(sm3 + ((((32767 - sm3) * boost) >> 15) * 19661 >> 15), 0, 32767);
        /* every other block, half the voices each block (689 / 2 updates a second); a note's first block at once */
        if ((cut != v->cc || res != v->cr) && (v->cc < 0 || ((vblk ^ (uint32_t)vi) & 1))) {
            v->cc = cut; v->cr = res; dm_coef(cut, res, &v->coef);
        }
        co = &v->coef;
    }
    v->ev -= mf(v->ev, p2_xd << 1);
    v->ea -= mf(v->ea, p2_xa << 1);

    dm_core(&v->core, y, step, &ins_morph, co);
    const int32_t vel = op1_voice_vel_gain(self);                  /* before the sum: the bus hears velocity */
    for (int i = 0; i < OP1_BLOCK; i++) out[i] = (int16_t)clampi((y[i] * vel) >> 15, -32768, 32767);
}

static void dimension_note_on(void *self, const int16_t *knobs)
{
    static uint32_t seq;
    dm_voice_t *v = &vc[op1_voice_index(self)];
    (void)knobs;
    if (!v->ready) voice_init(v);
    uint32_t r = v->core.rng;
    r ^= r << 13; r ^= r >> 17; r ^= r << 5;
    v->core.rng = r;
    v->det = (int32_t)((r >> 16) % 303) - 151;
    /* SLIDE: a note that starts while another is held glides from that note's pitch and carries its envelope on
     * (no retrigger, as a 303's slide); the newest held note leads */
    dm_voice_t *u = 0;
    for (int i = 0; i < OP1_VOICES; i++)
        if (vc[i].held && vc[i].cur && (!u || vc[i].seq - u->seq < 0x80000000u)) u = &vc[i];
    if (p2_slide && u) {
        v->src = u->cur; v->pending = 1;
        v->ev = u->ev; v->ea = u->ea; v->af = u->af;
        v->fresh = 0;
    } else {
        v->gr = 65536; v->pending = 0;
        v->ev = v->ea = 1 << 30;
        v->fresh = 1;
        v->cc = -1;                    /* the attack's coefficients at the first block */
    }
    v->held = 1;
    v->seq = ++seq;
}

static void dimension_note_off(void *self)
{
    vc[op1_voice_index(self)].held = 0;
}

const op1_engine_sum_t ENGINE_dimension = { { dimension_note_on, dimension_render, dimension_note_off,
                                            { OP1_PRESS_NONE, OP1_PRESS_NONE, OP1_PRESS_NONE, OP1_PRESS_NONE } },
                                          0, dimension_block };


#include "dimension_screen.h"
