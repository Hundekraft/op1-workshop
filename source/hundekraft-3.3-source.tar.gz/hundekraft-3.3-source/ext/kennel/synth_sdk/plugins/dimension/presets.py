#!/usr/bin/env python3
"""Twelve normal OP-1 presets for DIMENSION (written to presets/ next to this file, or the folder given).

    python3 presets.py [out_dir]

knobs: WAVEFORM, UNISON, FILTER FREQ, RES, the engine word (0x5300: the sound finds the engine by its saved name,
"dimension"), then the Shift layer: word 5 ENV (0 = off), word 6 DECAY (30 ms * 2^(w * 6.059 / 32767)), word 7
ACCENT (bits 0..6) and SLIDE (bits 8..14), 0..127 each (0: off; bits 7 and 15 are the core's; dimension.c p2_block).
WAVEFORM's anchors: 0 noise, 6554 10 % pulse, 6554..13107 the pulse width sweep, 13107 square, 19661 saw,
26214 saw + sub, 32767 noise. FILTER FREQ: 18000 * 2^(-(32767 - c) * 37802 / 2^27) Hz (24000: 3.25 kHz).
T2 (adsr) is the amp. Page 2's filter envelope is off in the first six (the original's sound: reso pluck is an amp
pluck through a resonant filter); acid bass shows it, with accent and slide.
dimension_test.c renders the same knob sets (keep its PRESETS table in step with SOUNDS).
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json, math, struct, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SEL = 0x5300


def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def aifc(meta):
    comm = struct.pack(">hIh", 1, 0, 16) + ieee_extended(44100) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    js = json.dumps(meta, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + chunk(b"APPL", b"op-1" + js)
            + chunk(b"SSND", struct.pack(">II", 0, 0)))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


def w7(accent, slide):
    return accent | slide << 8


# name, (WAVEFORM, UNISON, FILTER FREQ, RES), (ENV, DECAY, word 7), adsr (attack, decay, sustain, release)
# Release words (2026-11-15): R246 reads the release word inverted (rate table 0x7F - (v >> 7), audio-graph.md): HIGH
# release = SHORT. To -60 dB: 4800 = 2.9 s, 6000 = 2.1 s, 10400 = 0.9 s, 13500 = 0.4 s, 15000 = 0.2 s. Pads and drones
# sit at 3600..8000, leads and keys at 7000..13500, basses, plucks, stabs and organs at 13500..16320. Here each word
# is the release dimension_test.c's PRESETS simulates (r seconds, an exponential with time constant r / 4, so -60 dB at
# 1.73 r), through drift/presets.py's release_word(); noise pad and string ens held in the long band (8000 or lower).
SOUNDS = [
    ('dimension',     (19661, 16384, 24000,  4000), (    0,     0, 0),          ( 300,  8000, 26000,  10600)),
    ('saw bass',      (23500,     0, 17500,  7000), (    0,     0, 0),          (  64,  6000, 24000,  14400)),
    ('swept lead',    ( 9830, 12000, 22500, 10000), (    0,     0, 0),          ( 200,  8000, 28000,  12500)),
    ('noise pad',     (30200, 32767, 19500, 21000), (    0,     0, 0),          (9000, 12000, 26000, 4500)),
    ('reso pluck',    (16384,  6000, 15500, 30000), (    0,     0, 0),          (  64,  5500,     0,  13200)),
    ('hollow square', (13107, 26000, 25500,  2500), (    0,     0, 0),          (1500, 10000, 27000,  9700)),
    ('acid bass',     (19661,     0,  9500, 26000), (22000, 14000, w7(90, 25)), (  64,  9000, 26000,  16320)),
    # 2026-11-15 top-up to 12
    ('sub pounce',    (25500,     0, 15500,  9000), (14000, 10000, 0),          (  64,  5500, 22000,  15300)),
    ('string ens',    (10500, 32767, 23500,  2500), (    0,     0, 0),          (3500, 12000, 28000,  8000)),
    ('slide lead',    (19661,  9000, 24500,  9000), ( 8000, 20000, w7(45, 70)), (  64,  8000, 28000,  13800)),
    ('noise zap',     (    0,     0, 21000, 22000), (26000,  9000, 0),          (  64,  4500,     0,  15300)),
    ('env pluck',     (21500, 16000, 14500,  9000), (19000, 13000, 0),          (  64,  6000,     0,  13800)),
]


def metas():
    for name, k, p2, adsr in SOUNDS:
        yield {'adsr': [*adsr, 2048, 5568, 4000, 4000], 'fx_active': False, 'fx_params': [8000, 8000, 8000, 8000, 0, 0, 0, 0],
               'fx_type': 'delay', 'knobs': [*k, SEL, *p2], 'lfo_active': False,
               'lfo_params': [16000, 0, 0, 16000, 0, 0, 0, 0], 'lfo_type': 'tremolo', 'name': name, 'octave': 0,
               'synth_version': 2, 'type': 'dimension'}


def main():
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / 'presets'
    out.mkdir(parents=True, exist_ok=True)
    for meta in metas():
        (out / (meta['name'] + '.aif')).write_bytes(aifc(meta))
    print(f'{len(SOUNDS)} DIMENSION presets in {out}')


if __name__ == '__main__':
    main()
