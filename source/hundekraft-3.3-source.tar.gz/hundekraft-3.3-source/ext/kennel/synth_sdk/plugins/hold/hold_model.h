/* HOLD sequencer model: a step pattern written by holding keys while it runs (after the OP-1 Field's HOLD).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef HOLD_MODEL_H
#define HOLD_MODEL_H
#include <stdint.h>
#define HOLD_STEPS 32
#define HOLD_POLY 4                   /* notes a step; in MULTI the four tracks */
#define HOLD_TICKS 24                 /* 1/16 at 96 ticks per beat */
#define HOLD_WORDS (8 + HOLD_STEPS * (HOLD_POLY + 1))   /* saved text, versions 2 and 3: 168 numbers */
#define HOLD_STEPS_V1 16
#define HOLD_WORDS_V1 (8 + HOLD_STEPS_V1 * (HOLD_POLY + 1))   /* version 1 (before 32 steps and MULTI): 88 */
enum { HOLD_KIND_POLY, HOLD_KIND_MONO, HOLD_KIND_MULTI };
typedef struct {
    uint8_t length;                   /* 1..32 steps */
    uint8_t swing;                    /* 0..100: odd steps start later */
    uint8_t kind;                     /* HOLD_KIND_POLY: up to four notes a step; MONO: one (the last key pressed);
                                       * MULTI: four mono tracks, slot k is track k, a key writes the selected one.
                                       * MULTI synth notes keep the octave they were played at (absolute pitch);
                                       * POLY / MONO synth notes are at octave 0 and follow the octave arrows,
                                       * unless the octave lock is on (see abs) */
    uint8_t keep;                     /* pattern hold: 1 plays on with no key down, 0 only while a key is down */
    uint8_t split;                    /* break point, keyboard index 0..23: keys below it transpose; 0 = no split */
    int8_t transpose;                 /* -24..24 semitones, added to every step */
    uint8_t abs;                      /* synth: the notes are absolute pitches (MULTI, or POLY / MONO with the octave
                                       * lock on), so the octave arrows change only what is recorded next. Saved as
                                       * the header's last number (0 before; a MULTI row is absolute either way) */
    int8_t note[HOLD_STEPS][HOLD_POLY];   /* MIDI notes (synth POLY / MONO: at octave 0), -1 empty */
    uint8_t tie[HOLD_STEPS];          /* bit k: note k goes on from the step before (it was held across) */
    uint8_t upper[HOLD_STEPS];        /* drums, bit k: note k's pad is 12..23 (the pad is (note - 0x35) mod 12 plus 12
                                       * with this bit; the note keeps the pitch it was played at). Saved (version 3)
                                       * as the tie number's bits 4..7 */
} hold_config;
typedef struct {
    hold_config cfg;
    uint8_t step, cursor, started, changed, recording;
    uint8_t track;                    /* MULTI: the track keys write, 0..3 (not saved) */
    uint8_t octlock;                  /* the player's octave lock (one setting for every pattern, not saved here) */
    uint8_t halted;                   /* stopped (STOP, the blue push, after loading): a key or the blue push starts it */
    uint16_t elapsed;
    uint32_t held;                    /* pattern keys down (above the split) */
    int8_t low;                       /* transposing key down (below the split), -1 none */
    uint8_t last;                     /* last pattern key pressed */
    int8_t keynote[24];               /* note each pattern key plays */
    int16_t id[HOLD_POLY];            /* notes sounding: sequencer note ids, -1 none */
    int8_t pitch[HOLD_POLY];          /* their pitch before transposition (to match a tie) */
} hold_state;
void hold_init(hold_state *s);
void hold_clear(hold_state *s);                   /* erase every step */
void hold_erase(hold_state *s, int step);
void hold_erase_track(hold_state *s, int step, int k);   /* MULTI: one track's note at the step */
int hold_pad(const hold_config *c, int step, int k);     /* drums: the pad 0..23 of note k at the step, -1 none */
void hold_drum_pads(hold_state *s, int octave);   /* a drum part saved before version 3: each note's pad as it played
                                                   * then (at this drum octave), so it keeps playing the same pads */
void hold_release(hold_state *s);                 /* notes off, play state kept */
void hold_stop(hold_state *s);                    /* halt: notes off, back to step 0, keys forgotten */
void hold_quiet(hold_state *s);                   /* notes off and keys forgotten, play state kept (player stop / reset) */
void hold_play(hold_state *s, int on);            /* the blue push: start or halt */
void hold_key(hold_state *s, int mode, int key, int note, int down);   /* a pattern key also writes the current step
                                                                          * (note: as the kind stores it, see kind) */
void hold_set_kind(hold_state *s, int mode, int kind, int octave);   /* Shift + green; synth notes move between octave 0
                                                                      * and absolute by octave * 12 so they sound the same */
void hold_select(hold_state *s, int dir);         /* MULTI track down / up, wrapping 1..4 */
int hold_absolute(const hold_state *s, int mode); /* 1: the part's notes are absolute pitches (synth, cfg.abs) */
void hold_set_lock(hold_state *s, int mode, int on, int octave);   /* the octave lock: synth POLY / MONO notes go
                                                                    * absolute or back to octave 0 by octave * 12 */
void hold_tick(hold_state *s, int mode);          /* 96 per beat */
int hold_shift(const hold_state *s);              /* semitones: transpose + the low key's distance from the split */
int hold_empty(const hold_state *s);
int hold_serialize(const hold_state *s, int *v, int cap);
int hold_parse(hold_state *s, const int *v, int n);   /* -> the row's version (1..3), 0 refused */
/* supplied by the player (hold.c) or a test */
int hold_note_on(int mode, int note, int vel, int absolute, int pad);   /* absolute: a synth note with cfg.abs (no
                                                                         * live octave); pad: drums, the pad 0..23 */
void hold_note_off(int id);
#endif
