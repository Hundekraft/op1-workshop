/* HOLD sequencer model (hold_model.h). No libc, no division per tick; ticks come from the player (audio thread).
 *
 * The pattern has 1..32 steps of 1/16, each up to four notes. While it runs, the pattern keys held at a step's start
 * (or pressed during it) become that step's notes; a note still held from the step before is tied to it (it sounds
 * on, not again), so a key held over four steps is one long note. With no key down the pattern plays what it has.
 * Keys below the break point transpose the pattern while held. MULTI: the four note slots are four mono tracks; a key
 * writes only the selected track's slot (the others play on), and synth notes there are absolute pitches, so the
 * octave arrows move what is played next, not the pattern (hold_note_on's absolute flag). MONO plays only the first
 * slot, the one it shows (a MULTI or POLY pattern switched to MONO keeps its other slots, silent, for switching back).
 * The octave lock (one setting, hold.c) does the same for POLY and MONO: their notes go absolute (cfg.abs).
 * Drums: a note keeps the pitch it was played at and its pad (`upper`), so the drum octave arrows never change which
 * pad plays (as Euclid and Grids pass the pad).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "hold_model.h"

void hold_clear(hold_state *s)
{
    for (int i = 0; i < HOLD_STEPS; i++) hold_erase(s, i);
}
void hold_erase(hold_state *s, int step)
{
    if ((unsigned)step >= HOLD_STEPS) return;
    for (int k = 0; k < HOLD_POLY; k++) s->cfg.note[step][k] = -1;
    s->cfg.tie[step] = 0; s->cfg.upper[step] = 0;
    s->changed = 1;
}
void hold_erase_track(hold_state *s, int step, int k)
{
    if ((unsigned)step >= HOLD_STEPS || (unsigned)k >= HOLD_POLY) return;
    s->cfg.note[step][k] = -1;
    s->cfg.tie[step] &= (uint8_t)~(1u << k); s->cfg.upper[step] &= (uint8_t)~(1u << k);
    s->changed = 1;
}
static int mod12(int d) { while (d < 0) d += 12; while (d >= 12) d -= 12; return d; }   /* no division */
int hold_pad(const hold_config *c, int step, int k)
{
    if (c->note[step][k] < 0) return -1;
    return mod12(c->note[step][k] - 0x35) + ((c->upper[step] >> k) & 1 ? 12 : 0);
}
void hold_drum_pads(hold_state *s, int octave)
{
    hold_config *c = &s->cfg;
    for (int i = 0; i < HOLD_STEPS; i++) {
        c->upper[i] = 0;
        for (int k = 0; k < HOLD_POLY; k++) {
            if (c->note[i][k] < 0) continue;
            int pad = c->note[i][k] - 0x35 - 12 * octave;     /* what it played as before: its key at this octave */
            if (pad < 0 || pad > 23) pad = c->note[i][k] - 0x35;   /* not a pad there: as recorded at octave 0 */
            if (pad >= 12 && pad <= 23) c->upper[i] |= (uint8_t)(1u << k);
        }
    }
}
static int slots(const hold_config *c) { return c->kind == HOLD_KIND_MONO ? 1 : HOLD_POLY; }   /* slots that play */
void hold_init(hold_state *s)
{
    uint8_t *b = (uint8_t *)s;
    for (unsigned i = 0; i < sizeof *s; i++) b[i] = 0;
    s->cfg.length = 16; s->cfg.keep = 1;   /* a new pattern: 16 steps, as before 32 were possible */
    hold_clear(s);
    s->changed = 0; s->low = -1; s->halted = 1;
    for (int i = 0; i < 24; i++) s->keynote[i] = -1;
    for (int k = 0; k < HOLD_POLY; k++) { s->id[k] = -1; s->pitch[k] = -1; }
}
int hold_empty(const hold_state *s)                       /* any slot that plays: a MULTI track may hold the only notes */
{
    for (int i = 0; i < s->cfg.length; i++)
        for (int k = 0; k < slots(&s->cfg); k++) if (s->cfg.note[i][k] >= 0) return 0;
    return 1;
}
int hold_absolute(const hold_state *s, int mode) { return !mode && s->cfg.abs; }
void hold_select(hold_state *s, int dir)
{
    s->track = (uint8_t)((s->track + (dir < 0 ? HOLD_POLY - 1 : 1)) & (HOLD_POLY - 1));
}
/* synth notes go absolute (MULTI, or the octave lock on) or back to octave 0 by the live octave, so the pattern
 * sounds the same across the switch; a note pushed out of 0..127 is dropped. Drum notes are always absolute. */
static void sync_abs(hold_state *s, int mode, int octave)
{
    hold_config *c = &s->cfg;
    int want = !mode && (c->kind == HOLD_KIND_MULTI || s->octlock);
    if (mode || want == c->abs) { if (mode) c->abs = 0; return; }
    int d = (want ? 12 : -12) * octave;
    hold_release(s);
    for (int i = 0; i < HOLD_STEPS; i++)
        for (int k = 0; k < HOLD_POLY; k++) {
            int n = c->note[i][k];
            if (n < 0) continue;
            n += d;
            if (n < 0 || n > 127) { c->note[i][k] = -1; c->tie[i] &= (uint8_t)~(1u << k); }
            else c->note[i][k] = (int8_t)n;
        }
    for (int i = 0; i < 24; i++)
        if (s->keynote[i] >= 0) { int n = s->keynote[i] + d; s->keynote[i] = (int8_t)(n < 0 ? 0 : n > 127 ? 127 : n); }
    c->abs = (uint8_t)want;
    s->changed = 1;
}
void hold_set_kind(hold_state *s, int mode, int kind, int octave)
{
    hold_config *c = &s->cfg;
    if ((unsigned)kind > HOLD_KIND_MULTI || kind == c->kind) return;
    hold_release(s);
    c->kind = (uint8_t)kind;
    sync_abs(s, mode, octave);
    s->changed = 1;
}
void hold_set_lock(hold_state *s, int mode, int on, int octave)
{
    s->octlock = (uint8_t)(on != 0);
    sync_abs(s, mode, octave);
}
int hold_shift(const hold_state *s)
{
    return s->cfg.transpose + (s->low >= 0 && s->cfg.split ? s->low - s->cfg.split : 0);
}
void hold_release(hold_state *s)
{
    for (int k = 0; k < HOLD_POLY; k++) if (s->id[k] >= 0) { hold_note_off(s->id[k]); s->id[k] = -1; s->pitch[k] = -1; }
}
void hold_quiet(hold_state *s)
{
    hold_release(s);
    s->held = 0; s->low = -1; s->recording = 0;
    for (int i = 0; i < 24; i++) s->keynote[i] = -1;
}
void hold_stop(hold_state *s)
{
    hold_quiet(s);
    s->started = 0; s->step = 0; s->elapsed = 0; s->halted = 1;
}
void hold_play(hold_state *s, int on)
{
    if (on) s->halted = 0;
    else hold_stop(s);
}

/* the held pattern keys into step st (poly: lowest four; mono: the last pressed; multi: the last pressed, into the
 * selected track's slot only); tie: notes held since the step before stay tied to it */
static void write_step(hold_state *s, int mode, int st, int tie)
{
    hold_config *c = &s->cfg;
    int prev = st ? st - 1 : c->length - 1, n = 0;
    int8_t notes[HOLD_POLY], keys[HOLD_POLY];
    if (c->kind == HOLD_KIND_MULTI) {
        int k = s->track & (HOLD_POLY - 1);
        int key = (s->held >> s->last) & 1 ? s->last : -1;
        for (int i = 23; key < 0 && i >= 0; i--) if ((s->held >> i) & 1) key = i;
        int8_t v = key >= 0 ? s->keynote[key] : -1;
        c->note[st][k] = v;
        if (v >= 0 && tie && c->note[prev][k] == v && (!mode || (int)((c->upper[prev] >> k) & 1) == (key >= 12)))
            c->tie[st] |= (uint8_t)(1u << k);          /* (drums: the same pad too) */
        else c->tie[st] &= (uint8_t)~(1u << k);
        if (mode && key >= 12) c->upper[st] |= (uint8_t)(1u << k); else c->upper[st] &= (uint8_t)~(1u << k);
        s->changed = 1;
        return;
    }
    if (c->kind == HOLD_KIND_MONO) {
        int key = (s->held >> s->last) & 1 ? s->last : -1;
        for (int i = 23; key < 0 && i >= 0; i--) if ((s->held >> i) & 1) key = i;
        if (key >= 0 && s->keynote[key] >= 0) { keys[n] = (int8_t)key; notes[n++] = s->keynote[key]; }
    } else {
        for (int i = 0; i < 24 && n < HOLD_POLY; i++)
            if ((s->held >> i) & 1 && s->keynote[i] >= 0) { keys[n] = (int8_t)i; notes[n++] = s->keynote[i]; }
    }
    uint8_t t = 0, up = 0;
    for (int k = 0; k < HOLD_POLY; k++) {
        int8_t v = k < n ? notes[k] : -1;
        if (v >= 0 && mode && keys[k] >= 12) up |= (uint8_t)(1u << k);
        if (v >= 0 && tie)
            for (int j = 0; j < HOLD_POLY; j++) if (c->note[prev][j] == v) t |= (uint8_t)(1u << k);
        c->note[st][k] = v;
    }
    c->tie[st] = t; c->upper[st] = up;
    s->changed = 1;
}

/* make the sounding notes match step st: a note on in the step and tied (or `keep`: already sounding) goes on
 * sounding, the others go off, the step's other notes start. One voice per pitch: the core's note id is the MIDI
 * number, so two MULTI tracks on the same pitch share one note (a second key_down would leave a note no id ends) */
static void sync(hold_state *s, int mode, int st, int keep)
{
    const hold_config *c = &s->cfg;
    int sh = hold_shift(s), absolute = hold_absolute(s, mode), ns = slots(c);
    uint8_t used = 0;
    for (int k = 0; k < HOLD_POLY; k++) {
        if (s->id[k] < 0) continue;
        int stay = -1;
        for (int j = 0; j < ns; j++)
            if (c->note[st][j] >= 0 && c->note[st][j] + sh == s->pitch[k] && (keep || ((c->tie[st] >> j) & 1)) &&
                !((used >> j) & 1)) { stay = j; break; }
        if (stay >= 0) used |= (uint8_t)(1u << stay);
        else { hold_note_off(s->id[k]); s->id[k] = -1; s->pitch[k] = -1; }
    }
    for (int j = 0; j < ns; j++) {
        int p = c->note[st][j] + sh, on = 0;
        if (c->note[st][j] < 0 || ((used >> j) & 1) || p < 0 || p > 127) continue;
        for (int k = 0; k < HOLD_POLY; k++) on |= s->id[k] >= 0 && s->pitch[k] == p;
        if (on) continue;                                 /* that pitch sounds already (another track) */
        for (int k = 0; k < HOLD_POLY; k++) if (s->id[k] < 0) {
            /* POLY accents the first note; MULTI's tracks play alike */
            int vel = j && c->kind != HOLD_KIND_MULTI ? 96 : 112;
            s->id[k] = (int16_t)hold_note_on(mode, p, vel, absolute, mode ? hold_pad(c, st, j) : 0);
            s->pitch[k] = (int8_t)(s->id[k] >= 0 ? p : -1);
            break;
        }
    }
}

void hold_key(hold_state *s, int mode, int key, int note, int down)
{
    if ((unsigned)key >= 24) return;
    hold_config *c = &s->cfg;
    if (c->split && key < c->split) {                     /* below the break point: transpose while held */
        if (down) { s->low = (int8_t)key; s->halted = 0; } else if (s->low == key) s->low = -1;
        if (s->started) sync(s, mode, s->step, 0);
        return;
    }
    if (down) {
        int first = !s->held;
        s->halted = 0;
        s->held |= 1u << key; s->keynote[key] = (int8_t)(note < 0 ? 0 : note > 127 ? 127 : note); s->last = (uint8_t)key;
        if (s->started) { write_step(s, mode, s->step, !first && s->recording); s->recording = 1; sync(s, mode, s->step, 1); }
    } else {
        s->held &= ~(1u << key); s->keynote[key] = -1;
        if (!s->held) s->recording = 0;
    }
}

static int step_ticks(const hold_state *s)
{
    int sw = (s->cfg.swing * 103) >> 10;                  /* swing 100 -> 10 ticks of 24, no division */
    return HOLD_TICKS + ((s->step & 1) ? -sw : sw);
}

void hold_tick(hold_state *s, int mode)
{
    hold_config *c = &s->cfg;
    int run = !s->halted && (s->held || s->low >= 0 || (c->keep && !hold_empty(s)));
    if (!run) {
        if (s->started) { hold_release(s); s->started = 0; s->step = 0; s->elapsed = 0; s->recording = 0; }
        return;
    }
    if (s->started) {
        if (++s->elapsed < step_ticks(s)) return;
        s->elapsed = 0;
        s->step = (uint8_t)(s->step + 1 >= c->length ? 0 : s->step + 1);
    } else { s->started = 1; s->step = 0; s->elapsed = 0; }
    if (s->held) { write_step(s, mode, s->step, s->recording); s->recording = 1; }
    else s->recording = 0;
    sync(s, mode, s->step, 0);
}

int hold_serialize(const hold_state *s, int *v, int cap)
{
    const hold_config *c = &s->cfg;
    if (cap < HOLD_WORDS) return 0;
    int head[8] = { 3, c->length, c->swing, c->kind, c->keep, c->split, c->transpose + 24, c->abs };
    for (int i = 0; i < 8; i++) v[i] = head[i];
    int *p = v + 8;
    for (int i = 0; i < HOLD_STEPS; i++) {
        for (int k = 0; k < HOLD_POLY; k++) *p++ = c->note[i][k] + 1;
        *p++ = c->tie[i] | (c->upper[i] << 4);
    }
    return HOLD_WORDS;
}
/* version 1 (88 numbers: 16 steps, v[3] mono 0 / 1) loads as it was, steps 17..32 empty; version 2 (168: 32 steps,
 * v[3] the kind 0..2); version 3 (as 2, the tie number's bits 4..7 the drum pads' upper half). Before version 3 a
 * drum part has no pads saved: the caller sets them with hold_drum_pads */
int hold_parse(hold_state *s, const int *v, int n)
{
    int steps = n >= 1 && v[0] == 1 ? HOLD_STEPS_V1 : HOLD_STEPS, tmax = n >= 1 && v[0] == 3 ? 255 : 15;
    if (n < 8 + steps * (HOLD_POLY + 1) || v[0] < 1 || v[0] > 3 || v[1] < 1 || v[1] > steps || v[2] < 0 ||
        v[2] > 100 || (unsigned)v[3] > (v[0] == 1 ? 1u : 2u) || (unsigned)v[4] > 1 || v[5] < 0 || v[5] > 23 || v[6] < 0 ||
        v[6] > 48 || (unsigned)v[7] > 1) return 0;
    const int *p = v + 8;
    for (int i = 0; i < steps * (HOLD_POLY + 1); i++)
        if (p[i] < 0 || p[i] > ((i % (HOLD_POLY + 1)) == HOLD_POLY ? tmax : 128)) return 0;
    hold_stop(s);
    hold_config *c = &s->cfg;
    hold_clear(s);
    c->length = (uint8_t)v[1]; c->swing = (uint8_t)v[2]; c->kind = (uint8_t)v[3]; c->keep = (uint8_t)v[4];
    c->split = (uint8_t)v[5]; c->transpose = (int8_t)(v[6] - 24);
    c->abs = (uint8_t)(v[7] || c->kind == HOLD_KIND_MULTI);   /* a MULTI row saved before the lock: absolute too */
    for (int i = 0; i < steps; i++) {
        for (int k = 0; k < HOLD_POLY; k++) c->note[i][k] = (int8_t)(*p++ - 1);
        c->tie[i] = (uint8_t)(*p & 15); c->upper[i] = (uint8_t)(*p++ >> 4);
    }
    if (s->cursor >= c->length) s->cursor = 0;
    s->changed = 0;
    return v[0];
}
