/* dx: a voice player for DX7 voices. Ported 1:1 from another creator's plugin with the author's permission (per the owner,
 * 2026-11-14; PROVENANCE.md). Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE). */
/* The thin layer under dx_page.c: what the original's host gave its pages, with the same arguments. dx_gfx.c is it on
 * the OP-1 (R246's raster lines, text objects and pixels); the page oracle's guest (test/page_guest.c) logs each call on
 * both sides and compares. Places in drawing units (320 x 160, y down), stroke lines in units x 256 with widths x 256 in
 * panel pixels; colours by id (DX_C_*: negative an encoder's). The display thread, except the controls (KeyHandler). */
#ifndef DX_DRAW_H
#define DX_DRAW_H

#define DX_C_E1 (-10)                      /* the encoders' colours: blue, green, white, orange */
#define DX_C_E2 (-11)
#define DX_C_E3 (-12)
#define DX_C_E4 (-13)
#define DX_C_TEXT 14                       /* values, names: white */
#define DX_C_DIM 12                        /* labels: grey */
#define DX_C_BACK 1                        /* black */
#define DX_C_OFF 4                         /* unlit: dark grey */

void dxd_line(int x0, int y0, int x1, int y1, int colour);          /* a unit wide */
void dxd_stroke_line(int x0, int y0, int x1, int y1, int width, int colour);
void dxd_fill(int x0, int y0, int x1, int y1, int colour);          /* inclusive */
void dxd_frame(int x0, int y0, int x1, int y1, int colour);         /* its outline, one pixel */
void dxd_dot(int x, int y, int r, int filled, int colour);
void dxd_text(int slot, int x, int y, int size, int colour, const char *text);
int dxd_still(unsigned key);               /* 1: the still part is kept (same key); 0: draw it, then dxd_still_done */
void dxd_still_done(void);
void dxd_sincos(int turn4096, int *s, int *c);   /* x 4096 */

int dx_live(short par[8]);                 /* the current sound's knob words (5 the bank, 6 the voice) */
int dx_fn_held(void);
int dx_shift_held(void);
int dx_knob_set(int k, int v);             /* word 5 / 6 of the current sound, kept (KeyHandler) */

#endif
