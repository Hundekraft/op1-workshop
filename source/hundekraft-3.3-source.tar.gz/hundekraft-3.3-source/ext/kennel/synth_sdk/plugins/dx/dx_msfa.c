/* dx: a voice player for DX7 voices. Ported 1:1 from another creator's plugin with the author's permission (per the owner,
 * 2026-11-14; PROVENANCE.md). The FM follows Google's Music Synthesizer for Android (MSFA, Copyright 2012 Google Inc.,
 * Apache License 2.0; NOTICE). Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well. */
/* The FM: the tables' lookups, the operator envelope (MSFA env.cc), the voice (dx7note.cc), the LFO (lfo.cc), the
 * kernels' gain scaling and the patch packing (the kernels: dx_kern.c / dx_kasm.S). */
#include "dx.h"
#include "dx_tables.h"
#include "dx_kern.h"

static const short *sin_table_ptr = sin_table_src;

void sin_table_use(const short *p)       /* kennel: 0 (no L1 copy this block) goes back to the table itself */
{
    sin_table_ptr = p ? p : sin_table_src;
}

void sin_table_install(short *dst)
{
    int i;
    if (dst) {
        for (i = 0; i < 0x1000; i++)
            dst[i] = sin_table_src[i];
        sin_table_ptr = dst;
    }
}

/* ---------------------------------------------------------------- lookups */

int msfa_exp2_lookup(int x)
{
    int n = (x >> 24) - 6;
    const unsigned *p;
    unsigned d, r;
    if (n <= 0) {
        if (n >= -30) {
            p = (const unsigned *)((const char *)exp2_table + ((unsigned char)(x >> 16) << 2));
            d = (p[1] - p[0]) >> 7;
            r = ((d * (x & 0xffff)) >> 9) + p[0];
            return r >> -n;
        }
        return 0;
    }
    return 0x7fffffff;
}

int msfa_log2_lookup(int x)
{
    unsigned u = x, frac, y0, y1;
    int c, idx;
    if (x == 0)
        return -0x20000000;
    c = __builtin_clz(u);
    u <<= c;
    idx = (u >> 23) & 0xff;
    frac = (u << 9) >> 17;
    y0 = log2_table[idx];
    y1 = log2_table[idx + 1];
    return ((((y1 - y0) * frac) >> 15) + y0 + ((31 - c) << 24));
}

int msfa_freq_lookup(int x)
{
    unsigned u = x + 0x10924e69;
    int e = (int)u >> 24;
    unsigned y0, y1, r;
    int idx;
    if (u > 0x3dffffff)
        return 0;
    idx = (u >> 16) & 0xff;
    y0 = exp2_table[idx];
    y1 = exp2_table[idx + 1];
    r = ((((y1 - y0) >> 7) * (u & 0xffff)) >> 9) + y0;
    if (e <= 0x1d)
        return r >> (0x1e - e);
    return r << (e - 0x1e);
}

/* ---------------------------------------------------------------- the envelope */

void msfa_env_advance(struct env *e, int newix)
{
    int lv = e->levels[newix];
    int actual, qrate;
    if (lv > 19)
        actual = lv + 28;
    else
        actual = levellut[lv];
    actual = (actual >> 1 << 6) + e->outlevel - 4256;
    if (actual < 16)
        actual = 16;
    e->target = actual << 16;
    e->rising = e->level < e->target;
    qrate = (e->rates[newix] * 41) >> 6;
    qrate += e->rate_scaling;
    if (qrate > 63)
        qrate = 63;
    e->inc = (4 + (qrate & 3)) << (8 + (qrate >> 2));
}

/* ---------------------------------------------------------------- the voice */

/* kennel: n / 3 for 0 <= n < 65536 without libgcc's division (exact over the range; midinote 0..127 and its offsets
 * -116..110 stay far inside it) */
#define DIV3(n) ((int)(((unsigned)(n) * 0xaaabu) >> 17))

void msfa_note_init(struct voice *v, const unsigned char *patch_in, int midinote, int velocity)
{
    unsigned char patch[156];
    int mask, i, k, ratescale, vel;
    mask = patch_in[0x9b] & 0x3f;
    for (i = 0; i < 6; i++)
        for (k = 0; k < 21; k++) {
            int a = patch_in[i * 21 + k], m = patch_max_op[k];   /* kennel: ints, so MIN */
            patch[i * 21 + k] = a < m ? a : m;
        }
    for (k = 0; k < 29; k++) {
        int a = patch_in[0x7e + k], m = patch_max_global[k];
        patch[0x7e + k] = a < m ? a : m;
    }
    patch[0x9b] = mask;

    ratescale = DIV3(midinote) - 7;
    if (ratescale > 31)
        ratescale = 31;
    if (velocity > 127)
        velocity = 127;
    if (velocity < 0)
        velocity = 0;
    if (ratescale < 0)
        ratescale = 0;
    vel = velocity_data[velocity >> 1] - 239;

    for (i = 0; i < 6; i++) {
        const unsigned char *o = &patch[i * 21];
        struct env *e = &v->env[i];
        int outlevel, group, scale, curve, depth, offset, freq;
        for (k = 0; k < 4; k++) {
            e->rates[k] = o[k];
            e->levels[k] = o[k + 4];
        }
        outlevel = o[16] > 19 ? o[16] + 28 : levellut[o[16]];
        offset = midinote - o[8] - 17;
        if (offset < 0) {
            curve = o[11];
            depth = o[9];
            group = DIV3(-offset);
        } else {
            curve = o[12];
            depth = o[10];
            group = DIV3(offset);
        }
        if (curve == 0 || curve == 3)
            scale = (group * depth * 329) >> 12;
        else
            scale = (exp_scale_data[group > 32 ? 32 : group] * depth * 329) >> 15;
        if (curve < 2)
            scale = -scale;
        outlevel += scale;
        if (outlevel > 127)
            outlevel = 127;
        outlevel = (outlevel << 5) + ((((o[15] * vel) + 7) >> 3) << 4);
        if (outlevel < 0)
            outlevel = 0;
        e->level = 0;
        e->outlevel = outlevel;
        e->rate_scaling = (o[13] * ratescale) >> 3;
        e->down = 1;
        e->ix = 0;
        msfa_env_advance(e, 0);
        if (o[17] == 0)
            freq = coarse_log_table[o[18] & 0x1f] + fine_log_table[o[19]] + (o[20] - 7) * 0x313e;
        else {
            freq = (((o[18] & 3) * 100 + o[19]) * 0x440878) >> 3;   /* kennel: 0x440878 as the original (the C had 0x44878) */
            if (o[20] > 7)
                freq += (o[20] - 7) * 0x3491;
        }
        v->basepitch[i] = freq;
        v->fixmode[i] = o[17];
        v->ampmodsens[i] = o[14];
        v->op[i].phase = 0;
        v->op[i].gain_out = 0;
    }
    v->pe_rates[0] = patch[126];
    v->pe_rates[1] = patch[127];
    v->pe_rates[2] = patch[128];
    v->pe_rates[3] = patch[129];
    v->pe_levels[0] = patch[130];
    v->pe_levels[1] = patch[131];
    v->pe_levels[2] = patch[132];
    v->pe_levels[3] = patch[133];
    v->pe_level = pitchenv_level_table[patch[133]] << 19;
    v->pe_down = 1;
    v->pe_ix = 0;
    v->pe_target = pitchenv_level_table[patch[130]] << 19;
    v->pe_rising = pitchenv_level_table[patch[133]] < pitchenv_level_table[patch[130]];
    v->pe_inc = pitchenv_rate_table[patch[126]] * 1143;
    v->algorithm = patch[134];
    v->fb_shift = patch[135] ? 8 - patch[135] : 16;
    v->pitchmoddepth = (patch[139] * 165) >> 6;
    v->opmask = mask;
    v->pitchmodsens = pitchmodsens_table[patch[143]];
    v->ampmoddepth = patch[140];
    v->fb[1] = 0;
    v->fb[0] = 0;
}

int note_is_silent(const struct voice *v)
{
    int i;
    for (i = 0; i < 6; i++)
        if (v->env[i].ix <= 3 || v->op[i].gain_out > 0x45f)
            return 0;
    return 1;
}

void msfa_note_keyup(struct voice *v)
{
    struct env *e;
    struct env *end = v->env + 6;
    for (e = v->env; e != end; e++)
        if (e->down) {
            e->down = 0;
            e->ix = 3;
            msfa_env_advance(e, 3);
        }
    if (!v->pe_down)
        return;
    v->pe_down = 0;
    v->pe_ix = 3;
    v->pe_target = pitchenv_level_table[v->pe_levels[3]] << 19;
    v->pe_rising = v->pe_level < v->pe_target;
    v->pe_inc = pitchenv_rate_table[v->pe_rates[3]] * 1143;
}

/* The kernels as MSFA has them (generic loops); nothing in this build calls them. */
void fm_kernel_generic(const struct fm_args *a, int flags)
{
    int *out = a->out;
    int phase = a->phase, gain = a->gain, i;
    int noinput = !(flags & 2), noadd = !(flags & 1);
    for (i = 0; i < 64; i++) {
        unsigned ph;
        int y;
        gain += a->dgain;
        if (noinput)
            ph = phase;
        else
            ph = (a->in[i] << 18) + phase;
        y = (a->sin[ph >> 20] * (gain >> 16)) >> -a->shift;
        if (noadd)
            out[i] = y;
        else
            out[i] += y;
        phase += a->freq;
    }
}

void fm_kernel_fb_generic(struct fm_fb_args *a)
{
    int *out = a->out;
    int fb0 = a->fb0, fb1 = a->fb1, i, k, y = 0, ph;
    for (i = 0; i < 64; i++) {
        ph = (fb0 + fb1) << a->shift;
        for (k = 0; k < a->n; k++) {
            struct fm_fb_op *o = &a->op[k];
            unsigned idx = (o->phase + ph) >> 20;
            o->phase += o->freq;
            o->gain += o->dgain;
            y = (a->sin[idx] * (o->gain >> 16)) >> -o->shift;
            ph = y << 18;
        }
        fb0 = fb1;
        fb1 = y;
        out[i] = y;
    }
    a->fb0 = fb0;
    a->fb1 = fb1;
}

void msfa_note_compute(struct voice *v, int *buf, int base_pitch, int lfo_val, int lfo_delay, int *scratch)
{
    int pe_level = v->pe_level;
    int pitch_off, amd, i, fb_len, alg, has[3];
    struct fmop *op;
    struct env *e;
    const int *bp;

    if (v->pe_ix <= 2 || (v->pe_ix == 3 && !v->pe_down)) {
        int ix = v->pe_ix;
        if (v->pe_rising) {
            pe_level += v->pe_inc;
            if (pe_level < v->pe_target) {
                v->pe_level = pe_level;
                goto pdone;
            }
        } else {
            pe_level -= v->pe_inc;
            if (pe_level > v->pe_target) {
                v->pe_level = pe_level;
                goto pdone;
            }
        }
        pe_level = v->pe_target;
        v->pe_level = pe_level;
        v->pe_ix = ix + 1;
        if (ix != 3) {
            v->pe_target = pitchenv_level_table[v->pe_levels[ix + 1]] << 19;
            v->pe_rising = pe_level < v->pe_target;
            v->pe_inc = pitchenv_rate_table[v->pe_rates[ix + 1]] * 1143;
        }
    }
pdone:
    pitch_off = (((v->pitchmodsens * (lfo_val - 0x800000)) >> 16) * (int)((unsigned)(v->pitchmoddepth * lfo_delay) >> 16) >> 7) + pe_level;
    amd = ((((v->ampmoddepth * 0x296) >> 8) * (lfo_delay >> 8) >> 16) * (lfo_val >> 8)) >> 16;

    op = v->op;
    e = v->env;
    bp = v->basepitch;
    for (i = 0; i < 6; i++, op++, e++, bp++) {
        int level, gain, freq;
        op->gain_in = op->gain_out;
        level = e->level;
        if (e->ix <= 2 || (e->ix == 3 && !e->down)) {
            int ix = e->ix;
            if (e->rising) {
                int slope;
                if (level <= 0x06b3ffff) {
                    level = 0x06b40000;
                    slope = 10;
                } else
                    slope = ((17 << 24) - level) >> 24;
                level += slope * e->inc;
                if (level < e->target) {
                    e->level = level;
                    goto edone;
                }
            } else {
                level -= e->inc;
                if (level > e->target) {
                    e->level = level;
                    goto edone;
                }
            }
            level = e->target;
            e->level = level;
            e->ix = ix + 1;
            if (ix != 3)
                msfa_env_advance(e, ix + 1);
        }
    edone:
        if (v->ampmodsens[i])
            level -= ampmod_sens_table[v->ampmodsens[i]] * amd;
        if ((v->opmask >> i) & 1)
            gain = msfa_exp2_lookup(level - (7 << 25));
        else
            gain = 0;
        op->gain_out = gain;
        freq = *bp;
        if (v->fixmode[i] == 0)
            freq += base_pitch;
        op->freq = msfa_freq_lookup(freq + pitch_off);
    }

    alg = v->algorithm & 0x1f;
    has[0] = has[1] = has[2] = 0;
    fb_len = 0;
    if (alg == 3) {
        if (v->fb_shift <= 15)
            fb_len = 3;
    } else if (alg == 5) {
        if (v->fb_shift <= 15)
            fb_len = 2;
    }
    if (fb_len) {
        struct fm_fb_args a;
        int k;
        a.out = buf;
        a.n = fb_len;
        a.shift = 17 - v->fb_shift;
        a.fb0 = v->fb[0];
        a.fb1 = v->fb[1];
        a.sin = sin_table_ptr;
        for (k = 0; k < fb_len; k++) {
            int g1 = v->op[k].gain_in, g2 = v->op[k].gain_out;
            int d = (g2 - g1 + 0x20) >> 6;
            int mx = g1 > g2 ? g1 : g2, s, sh;
            if (mx <= 0x7fff) {
                sh = -0x19;
                s = 0x10;
            } else {
                int c = __builtin_clz(mx);
                s = c - 1;
                sh = -8 - c;
            }
            a.op[k].phase = v->op[k].phase;
            a.op[k].freq = v->op[k].freq;
            a.op[k].gain = g1 << s;
            a.op[k].dgain = d << s;
            a.op[k].shift = sh;
        }
        fm_op_compute_fb(&a);
        v->fb[0] = a.fb0;
        v->fb[1] = a.fb1;
        if (v->op[fb_len - 1].gain_in > 0x45f || v->op[fb_len - 1].gain_out > 0x45f)
            has[0] = 1;
    }
    for (i = 0; i < 6; i++) {
        int flags, outbus, inbus, add, g1, g2, ph;
        int *outptr;
        op = &v->op[i];
        ph = op->phase;
        if (i < fb_len) {
            op->phase = ph + (op->freq << 6);
            continue;
        }
        flags = algorithm_flags[alg][i];
        outbus = flags & 3;
        outptr = outbus == 0 ? buf : scratch + (outbus - 1) * 0x40;
        g1 = op->gain_in;
        g2 = op->gain_out;
        if (g1 > 0x45f || g2 > 0x45f) {
            add = has[outbus] ? (flags & 4) != 0 : 0;
            inbus = (flags >> 4) & 3;
            if (inbus != 0 && has[inbus])
                fm_op_compute_scaled(outptr, scratch + (inbus - 1) * 0x40, ph, op->freq, g1, g2, add + 2);
            else if ((flags & 0xc0) == 0xc0 && v->fb_shift <= 15) {
                struct fm_fb1_args f;
                int d = (g2 - g1 + 0x20) >> 6;
                int mx = g1 > g2 ? g1 : g2, s, sh;
                if (mx <= 0x7fff) {
                    sh = -0x19;
                    s = 0x10;
                } else {
                    int c = __builtin_clz(mx);
                    s = c - 1;
                    sh = -8 - c;
                }
                f.out = outptr;
                f.fb = v->fb;
                f.phase = ph;
                f.freq = op->freq;
                f.gain = g1 << s;       /* (short)(g >> (17 - c)) == (g << (c - 1)) >> 16: fm_op_compute's scaling */
                f.dgain = d << s;
                f.shift = sh;
                f.sin = sin_table_ptr;
                f.fs = 17 - v->fb_shift;
                fm_op_compute_fb1(&f, add);
            } else
                fm_op_compute_scaled(outptr, 0, ph, op->freq, g1, g2, add);
            has[outbus] = 1;
        } else if (!(flags & 4))
            has[outbus] = 0;
        op->phase += op->freq << 6;
    }
    if (!has[0])
        for (i = 0; i < 64; i++)
            buf[i] = 0;
}

/* ---------------------------------------------------------------- the LFO */

void msfa_lfo_reset(struct lfo *l, const unsigned char *patch)
{
    unsigned char speed = patch[0x89];
    unsigned char delay;
    unsigned sr;
    int a;
    if (speed == 0)
        l->delta = 0x622da;
    else {
        if (speed > 99)
            speed = 99;
        sr = (unsigned short)speed * (unsigned short)165;
        if (sr > 0x27ff) {
            sr >>= 6;
            l->delta = 0x8ece * ((((sr - 160) >> 4) + 11) * sr);
        } else {
            sr >>= 6;
            l->delta = 0x8ece * (sr * 11);
        }
    }
    delay = patch[0x8a];
    if (delay > 99)
        delay = 99;
    a = 99 - delay;
    if (a == 99) {
        l->delay_inc1 = -1;
        l->delay_inc2 = -1;
    } else {
        a = (16 + (a & 15)) << (1 + (a >> 4));
        l->delay_inc1 = a * 0x8ece;
        a &= 0xff80;
        if (a < 0x80)
            a = 0x80;
        l->delay_inc2 = a * 0x8ece;
    }
    l->wave = patch[0x8e] > 5 ? 5 : patch[0x8e];
    l->sync = patch[0x8d] != 0;
}

void msfa_lfo_keydown(struct lfo *l)
{
    if (l->sync)
        l->phase = 0x7fffffff;
    l->delay_state = 0;
}

int msfa_lfo_getsample(struct lfo *l)
{
    unsigned phase = l->phase + l->delta;
    l->phase = phase;
    switch (l->wave) {
    case 0:
        return ((phase >> 7) ^ ((int)phase >> 31)) & 0xffffff;
    case 1:
        return (phase >> 8) ^ 0x7fffff;
    case 2:
        return (phase >> 8) ^ 0x800000;
    case 3:
        return (~phase >> 7) & 0x1000000;
    case 4:
        return (sin_table_ptr[phase >> 20] + 0x8000) << 8;
    default:
        if (phase < (unsigned)l->delta)
            l->sh_rand = l->sh_rand * 179 + 17;
        return ((l->sh_rand ^ 0x80) + 1) << 16;
    }
}

int msfa_lfo_getdelay(struct lfo *l)
{
    unsigned d = l->delay_state + (l->delay_state < 0 ? l->delay_inc2 : l->delay_inc1);
    if ((unsigned)l->delay_inc1 <= d) {
        l->delay_state = d;
        if ((int)d < 0)
            return (d << 1) >> 8;
        return 0;
    }
    return 1 << 24;
}

/* ---------------------------------------------------------------- the kernels' scaling, and packing */

void fm_op_compute_scaled(int *out, const int *in, int phase, int freq, int gain1, int gain2, int flags)
{
    struct fm_args a;
    int mx = gain1 > gain2 ? gain1 : gain2;
    int d = (gain2 - gain1 + 0x20) >> 6;
    int s, sh;
    if (mx <= 0x7fff) {
        sh = -0x19;
        s = 0x10;
    } else {
        int c = __builtin_clz(mx);
        s = c - 1;
        sh = -8 - c;
    }
    a.out = out;
    a.in = in;
    a.phase = phase;
    a.freq = freq;
    a.gain = gain1 << s;
    a.dgain = d << s;
    a.shift = sh;
    a.sin = sin_table_ptr;
    fm_op_compute(&a, flags);
}

/* fm_op_compute, fm_op_compute_fb, fm_op_compute_fb1: dx_kern.c / dx_kasm.S */

/* A DX7 voice, 156 bytes unpacked <-> 128 bytes of the sysex bank. */
void patch_pack(const unsigned char *p, unsigned char *q)
{
    int i, k;
    for (i = 0; i < 6; i++) {
        const unsigned char *o = p + i * 21;
        unsigned char *d = q + i * 17;
        for (k = 0; k < 11; k++)
            d[k] = o[k];
        d[11] = ((o[12] << 2) & 12) | (o[11] & 3);
        d[12] = ((o[20] << 3) & 0x78) | (o[13] & 7);
        d[13] = ((o[15] << 2) & 0x1c) | (o[14] & 3);
        d[14] = o[16];
        d[15] = ((o[18] << 1) & 0x3e) | (o[17] & 1);
        d[16] = o[19];
    }
    for (k = 0; k < 9; k++)
        q[0x66 + k] = p[0x7e + k];
    q[0x6f] = ((p[0x88] << 3) & 8) | (p[0x87] & 7);
    q[0x70] = p[0x89];
    q[0x71] = p[0x8a];
    q[0x72] = p[0x8b];
    q[0x73] = p[0x8c];
    q[0x74] = ((p[0x8f] << 4) & 0x70) | ((p[0x8e] << 1) & 0xe) | (p[0x8d] & 1);
    for (k = 0; k < 11; k++)
        q[0x75 + k] = p[0x90 + k];
}

void patch_unpack(const unsigned char *q, unsigned char *p)
{
    int i, k;
    for (i = 0; i < 6; i++) {
        const unsigned char *d = q + i * 17;
        unsigned char *o = p + i * 21;
        for (k = 0; k < 11; k++)
            o[k] = d[k];
        o[11] = d[11] & 3;
        o[12] = (d[11] >> 2) & 3;
        o[13] = d[12] & 7;
        o[20] = d[12] >> 3;
        o[14] = d[13] & 3;
        o[15] = d[13] >> 2;
        o[16] = d[14];
        o[17] = d[15] & 1;
        o[18] = d[15] >> 1;
        o[19] = d[16];
    }
    for (k = 0; k < 9; k++)
        p[0x7e + k] = q[0x66 + k];
    p[0x87] = q[0x6f] & 7;
    p[0x88] = q[0x6f] >> 3;
    p[0x89] = q[0x70];
    p[0x8a] = q[0x71];
    p[0x8b] = q[0x72];
    p[0x8c] = q[0x73];
    p[0x8d] = q[0x74] & 1;
    p[0x8e] = (q[0x74] >> 1) & 7;
    p[0x8f] = q[0x74] >> 4;
    for (k = 0; k < 11; k++)
        p[0x90 + k] = q[0x75 + k];
    p[0x9b] = 0x3f;
}

void *memcpy_bytes(void *dst, const void *src, unsigned n)
{
    unsigned char *d = dst;
    const unsigned char *s = src;
    while (n--)
        *d++ = *s++;
    return dst;
}

void *memset_bytes(void *dst, int c, unsigned n)
{
    unsigned char *d = dst;
    while (n--)
        *d++ = c;
    return dst;
}
