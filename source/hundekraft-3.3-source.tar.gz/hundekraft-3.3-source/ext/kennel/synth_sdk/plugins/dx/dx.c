/* dx: a voice player for DX7 voices. Ported 1:1 from another creator's plugin with the author's permission (per the owner,
 * 2026-11-14; PROVENANCE.md). The FM follows Google's Music Synthesizer for Android (MSFA, Copyright 2012 Google Inc.,
 * Apache License 2.0; NOTICE). Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well. */
/* The engine (a voice's note, render and release), the kept sound (flags, name, amplitude envelope, an edited
 * patch) and the start; the FM is dx_msfa.c's, the host side dx_glue.c's. */
#include "dx.h"
#include "dx_voice.h"
#include "dx_kern.h"

#define STR_DX "dx"

/* ---------------------------------------------------------------- state */

struct voice *last_note_voice;
struct sound sound_data;
volatile unsigned dx_stats[3];             /* not read by the plugin (the tests may read them) */
static int fm_area[0x304 / 4];            /* the FM buffer (64 samples) and the scratch after it */
static int *const fm_buffer = fm_area;
static int *const fm_scratch = fm_area + 0x100 / 4;
static struct lfo lfo_state;
static int lfo_delay_value;
static unsigned char current_patch[156] __attribute__((aligned(4)));   /* copied as words in dx_start */
static struct sound sound_data_shadow;

static int last_note_index = -1;
static int lfo_sample = 0x800000;
int loaded_voice_bank = -1;
int loaded_voice_index = -1;

const unsigned char default_amp_env[8] = { 0, 0x32, 0x63, 0x63, 0x63, 0, 0, 0 };

/* ---------------------------------------------------------------- the voices */

void dx_voice_init(struct voice *v, int index)
{
    int i;
    v->first = 0;
    v->index = index;
    v->releasing = 0;
    v->stage = 5;
    v->last_out = 0;
    v->amp_gain = 0;
    for (i = 0; i < 6; i++) {
        v->op[i].gain_out = 0;
        v->op[i].gain_in = 0;
        v->env[i].level = 0;
        v->env[i].ix = 4;
    }
}

void dx_release(struct voice *v)
{
    v->releasing = 1;
}

int dx_finished(struct voice *v)
{
    int r = 0;
    if (v->releasing)
        r = v->stage == 5;
    return r;
}

int engine_key(int key, int pressed, int page)
{
    (void)pressed;
    if (page == 3)
        return key == 9;
    return 0;
}

void voice_get_patch(int bank, int index, unsigned char *patch)
{
    const unsigned char *src;
    int n;
    if (bank != 0) {
        src = bank_voice_ptr(bank, index);
        if (src) {
            patch_unpack(src, patch);
            return;
        }
        index = 0;
    } else {
        if (index < 0)
            index = 0;
        if (index > 7)
            index = 7;
    }
    src = factory_voices[index];
    for (n = 0; n < 156; n++)
        patch[n] = src[n];
}

void dx_block(void)
{
    lfo_sample = msfa_lfo_getsample(&lfo_state);
    lfo_delay_value = msfa_lfo_getdelay(&lfo_state);
}

void dx_render(struct voice *v, short *out, const short *par, const unsigned *pitch)
{
    const unsigned char *patch;
    const unsigned char *amp;
    int bank, vn, logf, old, gain, level, step, i;

    if (v->index == last_note_index)
        last_note_voice = v;
    sin_table_use(dx_sin_fast());          /* the L1 copy, or (0) the table itself */
    bank = par[5];
    vn = par[6];
    if (bank != loaded_voice_bank || vn != loaded_voice_index) {
        voice_get_patch(bank, vn, current_patch);
        if (!(sound_data.flags & 1))
            msfa_lfo_reset(&lfo_state, current_patch);
        loaded_voice_bank = bank;
        loaded_voice_index = vn;
    }
    patch = (sound_data.flags & 1) ? sound_data.patch : current_patch;
    amp = (sound_data.flags & 2) ? sound_data.amp : default_amp_env;

    logf = msfa_log2_lookup(*pitch) + (int)0xF06DB197 + (patch[0x90] - 24) * 0x155555;

    if (v->first) {
        int midi;
        v->first = 0;
        if (logf > 0x02E80732) {
            midi = (logf - 0x02FD5C87) / 0x155555;
            if (midi > 127)
                midi = 127;
        } else
            midi = 0;
        msfa_note_init(v, patch, midi, VOICE_VELOCITY(v->index) >> 8);
        v->hold = amp_hold_time_table[amp[5] % 100];
        if (amp[0] == 0) {
            v->stage = 1;
            v->amp_level = (amp[4] > 99 ? 0 : amp[4] - 99) * 0x295f3a;
            v->last_out = 0;
            v->amp_gain = msfa_exp2_lookup(v->amp_level);
        } else {
            v->stage = 0;
            v->amp_level = 0;
            v->last_out = 0;
            v->amp_gain = 0;
        }
    }
    if (v->releasing == 1) {
        v->releasing = 2;
        msfa_note_keyup(v);
    }
    old = v->amp_gain;
    if (v->releasing && v->stage <= 3) {
        level = v->amp_level;
        if (v->stage == 0) {
            if (level > 0)
                level = msfa_log2_lookup(level) - 0x18000000;
            else
                level = -0x10000000;
            v->amp_level = level;
        }
        v->stage = 4;
        goto release;
    }
    switch (v->stage) {
    case 0: {                              /* attack: the gain rises linearly to the peak */
        int peak = msfa_exp2_lookup(((amp[4] > 99 ? 99 : amp[4]) - 99) * 0x295f3a);
        level = v->amp_level + (((amp_attack_rate[amp[0] % 100] >> 10) * (peak >> 8)) >> 6);
        v->amp_level = level;
        if (peak > level)
            gain = level;
        else {
            v->amp_level = ((amp[4] > 99 ? 99 : amp[4]) - 99) * 0x295f3a;
            v->stage = 1;
            gain = peak;
        }
        break;
    }
    case 1: {                              /* hold */
        short h = v->hold;
        v->hold = h - 1;
        if (h <= 0)
            v->stage = 2;
        gain = msfa_exp2_lookup(v->amp_level);
        break;
    }
    case 2: {                              /* decay to the sustain level */
        int sus = ((amp[2] > 99 ? 99 : amp[2]) - 99) * 0x295f3a;
        level = v->amp_level - amp_decay_rate[amp[1] % 100];
        if (sus < level)
            v->amp_level = level;
        else {
            v->stage = 3;
            v->amp_level = sus;
            level = sus;
        }
        gain = msfa_exp2_lookup(level);
        break;
    }
    case 3:                                /* sustain */
        level = ((amp[2] > 99 ? 99 : amp[2]) - 99) * 0x295f3a;
        v->amp_level = level;
        gain = msfa_exp2_lookup(level);
        break;
    case 4:
        level = v->amp_level;
    release:
        level -= amp_decay_rate[amp[3] % 100];
        v->amp_level = level;
        if (level < (int)0xF0000001) {
            v->stage = 5;
            v->amp_gain = 0;
            if (old == 0)
                goto silent;
            gain = 0;
            goto render;
        }
        gain = msfa_exp2_lookup(level);
        break;
    default:
        v->amp_gain = 0;
        if (old == 0)
            goto silent;
        gain = 0;
        goto render;
    }
    v->amp_gain = gain;
    if ((old | gain) == 0) {
    silent:
        for (i = 0; i < 128; i++)
            out[i] = 0;
        v->last_out = 0;
        return;
    }
render:
    msfa_note_compute(v, fm_buffer, logf, lfo_sample, lfo_delay_value, fm_scratch);
    if (v->releasing && v->stage <= 4 && note_is_silent(v))
        v->stage = 5;
    step = (gain - old) >> 6;
    v->last_out = dx_out_block(out, fm_buffer, old, step, v->last_out);   /* dx_kasm.S */
}

void dx_note_on(struct voice *v)
{
    v->releasing = 0;
    v->first = 1;
    last_note_index = v->index;
    last_note_voice = v;
    msfa_lfo_keydown(&lfo_state);
}

/* ---------------------------------------------------------------- the kept sound */

/* The sound keeps its data (dx_data_get); when it changed under us (a load, a preset), take it and reload the patch. */
void dx_sync_data(void)
{
    struct sound *sh = &sound_data_shadow;
    const unsigned char *patch;
    unsigned char sf, df;
    int i;

    if (dx_data_get(sh, 0xb6) != 0xb6 || sh->kind != 1)
        sh->flags = 0;
    sf = sh->flags;
    df = sound_data.flags;
    for (i = 0; i < 0xb6; i++) {
        if (((unsigned char *)sh)[i] == ((unsigned char *)&sound_data)[i])
            continue;
        if (sf == 0) {
            if (df == 0)
                continue;
            patch = current_patch;
        } else
            patch = (sf & 1) ? sh->patch : current_patch;
        memcpy_bytes(&sound_data, sh, 0xb6);
        msfa_lfo_reset(&lfo_state, patch);
        return;
    }
}

static __attribute__((noinline)) void sound_data_get(struct sound *out)
{
    struct sound *p = memcpy_bytes(out, &sound_data, 0xb6);
    if (!(p->flags & 2)) {
        p->amp[0] = 0;
        p->amp[1] = 0x32;
        p->amp[2] = 0x63;
        p->amp[3] = 0x63;
        p->amp[4] = 0x63;
        p->amp[5] = 0;
        p->amp[6] = 0;
        p->amp[7] = 0;
    }
}

int voice_count_total(void)
{
    int n = 8, i;
    for (i = 0; i < bank_count(); i++)
        n += bank_voice_count(i);
    return n;
}

int voice_number_from_bank(int bank, int index)
{
    int n, i, b;
    if (bank == 0) {
        n = index > 7 ? 7 : index;
        return n < 0 ? 0 : n;
    }
    b = bank_index_of_id(bank);
    if (b < 0)
        return 0;
    n = 8;
    if (b != 0) {
        i = 0;
        do
            n += bank_voice_count(i++);
        while (i != b);
    }
    if (index < 0)
        return n;
    {
        int c = bank_voice_count(b) - 1;
        return n + (c < index ? c : index);
    }
}

void voice_number_to_bank(int number, int *bank, int *index)
{
    int i;
    if (number <= 7) {
        *bank = 0;
        *index = number < 0 ? 0 : number;
        return;
    }
    number -= 8;
    for (i = 0; i < bank_count(); i++) {
        if (bank_voice_count(i) > number) {
            *bank = bank_id(i);
            *index = number;
            return;
        }
        number -= bank_voice_count(i);
    }
    *bank = 0;
    *index = 7;
}

void current_patch_get(int bank, int index, unsigned char *patch)
{
    if (sound_data.flags & 1) {
        const unsigned char *src = sound_data.patch;
        int n;
        for (n = 0; n < 156; n++)
            patch[n] = src[n];
    } else
        voice_get_patch(bank, index, patch);
}

int sound_name_get(char *buf, int max)
{
    return dx_sound_name(buf, max);
}

int sound_name_differs(void)
{
    char n[24];
    const char *p, *d, *a;
    if (!(sound_data.flags & 3))
        return 0;
    dx_sound_name(n, 0x18);
    if (n[0] == 0)
        return 0;
    p = n;
    d = STR_DX;
    while (*p == *d) {
        if (!*p)
            return 0;
        p++;
        d++;
    }
    p = n;
    a = sound_data.name;
    while (*p == *a) {
        if (!*p)
            break;
        p++;
        a++;
    }
    return (unsigned char)(*p ^ *a) != 0;
}

static void sound_data_store(struct sound *s)
{
    if (sound_name_differs() || !(sound_data.flags & 3)) {
        char n[24] = { 0 };                /* kennel: zeroed (the original copied stack bytes after the name's end) */
        int i;
        dx_sound_name(n, 0x18);
        for (i = 0; i < 15; i++)
            s->name[i] = n[i];
        s->name[15] = 0;
    }
    s->kind = 1;
    dx_data_set(s, 0xb6);
    memcpy_bytes(&sound_data, s, 0xb6);
}

int sound_name_matches(void)
{
    if (!(sound_data.flags & 3))
        return 0;
    return sound_name_differs() == 0;
}

void patch_param_set(int bank, int index, int param, int value)
{
    struct sound s;
    sound_data_get(&s);
    if (!(s.flags & 1)) {
        voice_get_patch(bank, index, s.patch);
        s.flags |= 1;
    }
    if (param == 0x9b)
        s.patch[0x9b] = value & 0x3f;
    else if ((unsigned)param <= 0x9a)
        s.patch[param] = value;
    sound_data_store(&s);
    msfa_lfo_reset(&lfo_state, s.patch);
}

void amp_env_param_set(int param, int value)
{
    struct sound s;
    sound_data_get(&s);
    s.flags |= 2;
    value = value < 0 ? 0 : value > 99 ? 99 : value;
    s.amp[param & 7] = value;
    sound_data_store(&s);
}

void sound_data_reset(void)
{
    struct sound s;
    memcpy_bytes(&s, &sound_data, 0xb6);
    dx_data_set(0, 0);
    s.flags = 0;
    memcpy_bytes(&sound_data, &s, 0xb6);
    if (loaded_voice_bank < 0)
        return;
    msfa_lfo_reset(&lfo_state, current_patch);
}

int amp_peak_gain(int v)
{
    if (v < 0)
        v = 0;
    if (v > 99)
        v = 99;
    return (v - 99) * 0x295f3a;
}

int amp_hold_page_lookup(int v)
{
    if (v < 0)
        v = 0;
    if (v > 99)
        v = 99;
    return amp_hold_page_table[v];
}

void lfo_state_get(int *phase, int *delay)
{
    *phase = lfo_state.phase;
    *delay = lfo_delay_value;
}

/* ---------------------------------------------------------------- the start */

/* Once, before the first note (dx_glue.c): the first factory voice as the loaded patch, its LFO. */
void dx_start(void)
{
    int i;
    for (i = 0; i < 39; i++)
        ((int *)current_patch)[i] = ((const int *)factory_voices)[i];
    if (!(sound_data.flags & 1))
        msfa_lfo_reset(&lfo_state, current_patch);
    loaded_voice_bank = 0;
    loaded_voice_index = 0;
}
