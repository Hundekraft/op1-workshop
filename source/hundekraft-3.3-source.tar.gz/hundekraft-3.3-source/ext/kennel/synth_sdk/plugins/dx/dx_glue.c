/* dx: a voice player for DX7 voices. Ported 1:1 from another creator's plugin with the author's permission (per the owner,
 * 2026-11-14; PROVENANCE.md). The FM follows Google's Music Synthesizer for Android (MSFA, Copyright 2012 Google Inc.,
 * Apache License 2.0; NOTICE). Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well. */
/* The OP-1 side of dx: the kennel engine entry (six voices' state here, the 0x24-byte voice objects only name the
 * voice), the L1 sine table, the kept sound, the pages' host and hooks, and the bank folder's directory and file
 * calls (R246's yaffs). */
#include "op1_plugin.h"
#include "dx.h"
#include "dx_draw.h"
#include "op1_feature.h"

static struct voice voices[OP1_VOICES];
static volatile uint8_t ready[OP1_VOICES];           /* the voice was set up (the original's init) */
static volatile uint8_t started;

static struct voice *voice_of(void *self)
{
    const int i = op1_voice_index(self);
    struct voice *v = &voices[i];
    if (!ready[i]) { dx_voice_init(v, i); ready[i] = 1; }
    return v;
}

static void dx_k_note_on(void *self, const int16_t *params)
{
    (void)params;
    if (!started) { dx_start(); started = 1; }
    dx_note_on(voice_of(self));
}

static void dx_k_render(void *self, int16_t *out, const int16_t *params)
{
    dx_render(voice_of(self), out, params, (const unsigned *)OP1_PITCH_INC);
}

static void dx_k_note_off(void *self) { dx_release(voice_of(self)); }
static int dx_k_finished(void *self) { return dx_finished(voice_of(self)); }
static void dx_k_block(int16_t *bus, int fresh) { (void)bus; (void)fresh; dx_block(); }

/* the sine table (8 KB) in the synth's L1 partition while dx holds it */
#ifndef OP1_HOST
static const int sin_owner;
#endif
const short *dx_sin_fast(void)
{
#ifndef OP1_HOST
    int fresh;
    short *p = op1_l1_claim(OP1_L1_SYNTH, &sin_owner, 0x2000, &fresh);
    if (p && fresh) sin_table_install(p);
    return p;
#else
    return 0;
#endif
}

/* ---- the kept sound: the sound's data (op1_engine_data, 182 bytes) ---- */
static uint32_t owner;
static uint32_t owner_of(void) { if (!owner) owner = op1_engine_rec_owner("dx"); return owner; }
int dx_data_get(void *buf, int max) { return op1_engine_data(op1_current_slot(), owner_of(), buf, max); }
int dx_data_set(const void *buf, int n) { return op1_engine_data_store(op1_current_slot(), "dx", buf, n); }   /* input only */
/* The sound's name: kennel has no call for the name R246 keeps (a user preset's), so the engine's name: the pages
 * then always show the voice's name, "edited" once the sound keeps an edit (README: divergences). */
int dx_sound_name(char *buf, int max) { if (max > 2) { buf[0] = 'd'; buf[1] = 'x'; buf[2] = 0; } return 2; }

/* ---- the pages' host (dx_draw.h) ---- */
extern op1_engine_ext2_t ENGINE_dx;
int dx_live(short par[8])
{
    const int16_t *k = op1_synth_knobs(op1_current_slot());
    for (int i = 0; i < 8; i++) par[i] = k[i];
    return 0;
}
int dx_fn_held(void) { return op1_fn_held(); }
int dx_shift_held(void) { return op1_shift_held(); }
int dx_knob_set(int k, int v) { return op1_engine_word_set(&ENGINE_dx.ext.voice, k, v & 0x7FFF); }

/* ---- the bank folder: R246's yaffs (main loop) ---- */
#ifndef OP1_HOST
#define Y_OPEN     ((int (*)(const char *, int, int))0x01A997F4)
#define Y_CLOSE    ((int (*)(int))0x01A99908)
#define Y_READ     ((int (*)(int, void *, unsigned))0x01A99C90)
#define Y_OPENDIR  ((void *(*)(const char *))0x01A9B450)
#define Y_READDIR  ((const uint8_t *(*)(void *))0x01A9B648)     /* dirent: +0x0B the name */
#define Y_CLOSEDIR ((int (*)(void *))0x01A9B74C)
#endif
static char names[24][40];                           /* the .syx names first: no file I/O while the dir is open */
static int n_names, at_name;
void *dx_dir_open(const char *path)
{
    n_names = at_name = 0;
#ifndef OP1_HOST
    void *d = Y_OPENDIR(path);
    if (!d) return 0;
    const uint8_t *e;
    while ((e = Y_READDIR(d)) && n_names < 24) {
        const char *s = (const char *)e + 11;
        int i = 0;
        while (s[i] && i < 39) { names[n_names][i] = s[i]; i++; }
        if (s[i]) continue;                          /* too long for a bank name anyway */
        if (i < 5 || s[i - 4] != '.' || (s[i - 3] | 0x20) != 's' || (s[i - 2] | 0x20) != 'y' || (s[i - 1] | 0x20) != 'x')
            continue;                                /* .syx only (any case), before the 24 count: no file crowds banks out */
        names[n_names++][i] = 0;
    }
    Y_CLOSEDIR(d);
#else
    (void)path;
#endif
    return names;
}
const char *dx_dir_next(void *dir) { (void)dir; return at_name < n_names ? names[at_name++] : 0; }
void dx_dir_close(void *dir) { (void)dir; }
int dx_file_read(const char *path, void *buf, int max)
{
#ifndef OP1_HOST
    const int fd = Y_OPEN(path, 0, 0x100);
    if (fd < 0) return -1;
    const int n = Y_READ(fd, buf, (unsigned)max);
    Y_CLOSE(fd);
    return n;
#else
    (void)path; (void)buf; (void)max;
    return -1;
#endif
}

/* The page hooks (op1_plugin.h op1_engine_ext2_t): the original's turn(encoder, detents, page) and key(key, pressed,
 * page) on T1, its T2 page and its T4 page (same page numbers); the service keeps the sound's data in step (the
 * original's main pass) and reads the bank folder after boot and after disk mode. */
extern const op1_screen_t SCREEN_dx_t2, SCREEN_dx_t4;
static int32_t acc[4][4];                            /* part detents, per page and encoder */
static int dx_input(int page, int ev, int a, int b)
{
    if (ev == OP1_ENG_TURN)
        return engine_turn(a & 3, op1_eng_detents(&acc[page & 3][a & 3], b), page);
    if (ev == OP1_ENG_KEY)
        return engine_key(a, b, page);
    if (ev == OP1_ENG_PUSH)
        return engine_key(0x3B + (a & 3), b, page);  /* R246's push codes; the original takes none */
    return 0;
}
static void dx_service(int ev, int32_t arg)
{
    if (ev == OP1_EV_SERVICE)
        dx_sync_data();                              /* reads and compares; stores nothing */
    else if (ev == OP1_EV_BOOT_DONE || (ev == OP1_EV_DISK && arg == 0)) {
        bank_scan();
        loaded_voice_bank = -1;                      /* kennel: the next render loads its voice from the new list */
    }
}

op1_engine_ext2_t ENGINE_dx = {
    { { dx_k_note_on, dx_k_render, dx_k_note_off, { 0, 0, 0, 0 } }, dx_k_finished, dx_k_block, &SCREEN_dx_t2 },
    dx_input,
    &SCREEN_dx_t4,
    dx_service,
};
