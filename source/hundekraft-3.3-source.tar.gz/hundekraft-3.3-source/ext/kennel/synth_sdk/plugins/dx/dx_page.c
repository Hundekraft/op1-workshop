/* dx: a voice player for DX7 voices. Ported 1:1 from another creator's plugin with the author's permission (per the owner,
 * 2026-11-14; PROVENANCE.md). The FM follows Google's Music Synthesizer for Android (MSFA, Copyright 2012 Google Inc.,
 * Apache License 2.0; NOTICE). Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well. */
/* The pages (T1: voice, part, parameter, value; T2: the amplitude envelope; T4: the LFO) and their turns and keys,
 * 1:1 from the original: drawn through dx_draw.h's thin layer (dx_gfx.c on the OP-1, the page oracle's shims in
 * test/page_guest.c), a small stroke font; the turns edit through patch_param_set and amp_env_param_set (dx.c). */
#include "dx.h"
#include "dx_draw.h"
#include "dx_algo.h"
#include <stdarg.h>

#define C_E1 DX_C_E1
#define C_E2 DX_C_E2
#define C_E3 DX_C_E3
#define C_E4 DX_C_E4
#define C_DIM DX_C_DIM
#define C_TEXT DX_C_TEXT
#define C_OFF DX_C_OFF

/* The original's snprintf, for what the pages print: %i (with 0 and a width), %s, %%. */
static int dx_fmt(char *b, int n, const char *f, ...)
{
    va_list ap;
    int o = 0;
    va_start(ap, f);
    while (*f && o < n - 1) {
        int zero = 0, width = 0;
        if (*f != '%') {
            b[o++] = *f++;
            continue;
        }
        f++;
        if (*f == '0') {
            zero = 1;
            f++;
        }
        while (*f >= '1' && *f <= '9')
            width = width * 10 + *f++ - '0';
        if (*f == 'i' || *f == 'd') {
            int v = va_arg(ap, int), i = 0;
            unsigned u = v < 0 ? 0u - (unsigned)v : (unsigned)v;
            char t[12];
            if (v < 0 && o < n - 1)
                b[o++] = '-';
            do
                t[i++] = (char)('0' + u % 10);
            while ((u /= 10) && i < 11);
            while (i < width && i < 11)
                t[i++] = zero ? '0' : ' ';
            while (i && o < n - 1)
                b[o++] = t[--i];
        } else if (*f == 's') {
            const char *t = va_arg(ap, const char *);
            while (t && *t && o < n - 1)
                b[o++] = *t++;
        } else if (*f == '%')
            b[o++] = '%';
        if (*f)
            f++;
    }
    va_end(ap);
    if (n)
        b[o] = 0;
    return o;
}

static int t1_section;
static int t1_sel[8];
static int algo_x0;
static int algo_y0;
static int t1_bar;
static char t1_name[16];
static char t1_text1[16];
static char t1_text2[16];
static char t1_alg[12];
static unsigned char t1_patch[156];
static unsigned char turn_patch_t1[156];
static unsigned char turn_patch_t4[156];
static unsigned char hash_patch[156];
static int hash_extra[4];
static char texts[4][12];
static char title[16];
static unsigned char title_patch[156];
/* A parameter row: its label, the patch byte, its largest value, how it shows, its group. */
struct prow {
    const char *name;
    unsigned char param, max, fmt, group;
};

static const struct prow global_rows[4] = {
    { "algorithm", 0x86, 0x1f, 1, 0 },
    { "feedback", 0x87, 7, 0, 0 },
    { "osc key sync", 0x88, 1, 2, 0 },
    { "transpose", 0x90, 0x30, 8, 0 },
};
static const struct prow pe_rows[8] = {
    { "rate 1", 0x7e, 0x63, 10, 0 },
    { "rate 2", 0x7f, 0x63, 10, 0 },
    { "rate 3", 0x80, 0x63, 10, 0 },
    { "rate 4", 0x81, 0x63, 10, 0 },
    { "level 1", 0x82, 0x63, 11, 0 },
    { "level 2", 0x83, 0x63, 11, 0 },
    { "level 3", 0x84, 0x63, 11, 0 },
    { "level 4", 0x85, 0x63, 11, 0 },
};
static const struct prow op_rows[22] = {
    { "level", 0x10, 0x63, 0, 0 },
    { "mode", 0x11, 1, 5, 0 },
    { "coarse", 0x12, 0x1f, 6, 0 },
    { "fine", 0x13, 0x63, 6, 0 },
    { "detune", 0x14, 0x0e, 7, 0 },
    { "on", 0x9b, 1, 12, 0 },
    { "rate 1", 0, 0x63, 10, 1 },
    { "rate 2", 1, 0x63, 10, 1 },
    { "rate 3", 2, 0x63, 10, 1 },
    { "rate 4", 3, 0x63, 10, 1 },
    { "level 1", 4, 0x63, 11, 1 },
    { "level 2", 5, 0x63, 11, 1 },
    { "level 3", 6, 0x63, 11, 1 },
    { "level 4", 7, 0x63, 11, 1 },
    { "break point", 8, 0x63, 9, 2 },
    { "left depth", 9, 0x63, 0, 2 },
    { "right depth", 10, 0x63, 0, 2 },
    { "left curve", 11, 3, 4, 2 },
    { "right curve", 12, 3, 4, 2 },
    { "rate scale", 13, 7, 0, 2 },
    { "velocity", 15, 7, 0, 2 },
    { "amp mod", 14, 3, 0, 2 },
};
static const char *const part_names[8] = { "vce", "peg", "op1", "op2", "op3", "op4", "op5", "op6" };
static const char *const section_names[2] = { "voice", "pitch envelope" };
static const char *const group_names[3] = { "oscillator", "envelope", "scaling" };
static const char *const wave_names[6] = { "triangle", "saw down", "saw up", "square", "sine", "s/hold" };
static const char *const curve_names[4] = { "-lin", "-exp", "+exp", "+lin" };

static const char *const note_names[12] = { "c", "c#", "d", "d#", "e", "f", "f#", "g", "g#", "a", "a#", "b" };
static const unsigned char lfo_param_map[2][4] = { { 0x89, 0x8a, 0x8b, 0x8c }, { 0x8e, 0x8f, 0x8d, 0 } };
static const char *const hint_names[2][4] = {
    { "voice", "part", "param", "value" },
    { "voice", "part", "section", "x10" },
};
static const unsigned char seg_mask[10] = { 0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f };
static const unsigned char rate_segs[4] = { 0, 1, 2, 4 };
static const unsigned char level_dots[4] = { 1, 2, 3, 5 };
static const unsigned char levellut2[20] = {
    0, 5, 9, 13, 17, 20, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 42, 43, 45, 46
};
static const unsigned char amp_param_map[2][4] = { { 0, 1, 2, 3 }, { 4, 5, 0xff, 0xff } };
static const unsigned char amp_color_idx[5] = { 0, 1, 1, 2, 3 };
static const signed char sh_table[8] = { 0x28, (signed char)0xb0, 0x5a, (signed char)0xec, 0x3c, (signed char)0x9c, 0x0a, (signed char)0xce };
static const unsigned char lfo_max[3] = { 1, 5, 7 };

#include "dx_glyphs.h"

static const unsigned char *const letters[26] = {
    dat_0896c, dat_08958, dat_08950, dat_08940, dat_08934, dat_0892c, dat_08920, dat_08918, dat_08910, dat_08908,
    dat_08900, dat_088f8, dat_088ec, dat_088e4, dat_088d8, dat_088cc, dat_088c0, dat_088b4, dat_088a8, dat_088a0,
    dat_08898, dat_08890, dat_08884, dat_0887c, dat_08874, dat_0886c
};
static const unsigned char *const digits[10] = {
    dat_08860, dat_08858, dat_0884c, dat_08840, dat_08838, dat_088a8, dat_0882c, dat_08824, dat_08818, dat_0880c
};

static unsigned char t4_patch[156];
static int page_pos = -1;

/* ---------------------------------------------------------------- the stroke font */

int stroke_text_width(const char *s, int scale)
{
    int n = 0;
    if (*s == 0)
        return 0;
    do
        n++;
    while (*++s);
    return (n * 6 - 2) * scale;
}

void stroke_text_draw(int x, int y, int scale, int colour, const char *s)
{
    for (; *s; s++) {
        const unsigned char *g;
        int i, c = *s;
        if ((unsigned)(c - 0x61) <= 25) {
            g = letters[c - 0x61];
            goto table;
        }
        if ((unsigned)(c - 0x41) <= 25) {
            g = letters[c - 0x41];
            goto table;
        }
        if ((unsigned)(c - 0x30) <= 9) {
            g = digits[c - 0x30];
            goto table;
        }
        if (c <= 0x2f) {
            if (c > 0x22) {
                switch (c) {
                case '#':
                    g = dat_087e8;
                    goto draw;
                case '+':
                    g = dat_087f4;
                    goto draw;
                case '-':
                    g = dat_08808;
                    goto draw;
                case '.':
                    g = dat_08800;
                    goto draw;
                case '/':
                    g = dat_087fc;
                    goto draw;
                }
            }
            goto next;
        }
        if (c == '_') {
            g = dat_08804;
            goto draw;
        }
        goto next;
    table:
        if (g[0] == 0)
            goto next;
    draw:
        i = 0;
        do {
            int a = g[1 + 2 * i], b = g[2 + 2 * i];
            i++;
            dxd_line(x + (a >> 4) * scale, y + (a & 15) * scale, x + (b >> 4) * scale, y + (b & 15) * scale, colour);
        } while (i < g[0]);
    next:
        x += scale * 6;
    }
}

void stroke_text_draw_right(int x, int y, int scale, int colour, const char *s)
{
    stroke_text_draw(x - stroke_text_width(s, scale), y, scale, colour, s);
}

/* ---------------------------------------------------------------- small helpers of the pages */

/* The origin of an algorithm's drawing, from its widest column and its highest row. */
static void algo_origin(const unsigned char *a)
{
    int maxcol = 0, maxrow = 0, i;
    for (i = 0; i < 6; i++) {
        if (a[i] > maxcol)
            maxcol = a[i];
        if (a[i + 6] > maxrow)
            maxrow = a[i + 6];
    }
    algo_x0 = (126 - 11 * maxcol) / 2 + 6;
    algo_y0 = (54 - 19 * maxrow) / 2 + 56 + 19 * maxrow;
}

static void page_draw_voice_title(const char *label)
{
    short par[8];
    int differs, i, last, n;
    dx_live(par);
    stroke_text_draw(8, 8, 1, C_DIM, label);
    differs = sound_name_differs();
    if (differs)
        sound_name_get(title, 16);
    else {
        current_patch_get(par[5], par[6], title_patch);
        last = 0;
        n = 0;
        for (i = 0; i < 10; i++) {
            int c = (signed char)title_patch[0x91 + i];
            n++;
            if ((unsigned char)(c - 0x20) <= 0x5e) {
                title[i] = c;
                if (c != 0x20)
                    last = n;
            } else
                title[i] = 0x20;
        }
        title[last] = 0;
    }
    stroke_text_draw_right(0x13a, 8, 1, C_DIM, title);
    if (sound_name_matches())
        stroke_text_draw_right(0x132 - stroke_text_width(title, 1), 8, 1, C_E4, "edited");
}

/* What the T2 and T4 pages show, as a number: the part of the sound they read. */
static unsigned page_key(int which)
{
    short par[8];
    struct {
        int which, bank, index, differs, matches, fn;
    } k;
    unsigned h = 0x811c9dc5;
    int differs, i;
    dx_live(par);
    current_patch_get(par[5], par[6], hash_patch);
    differs = sound_name_differs();
    hash_extra[0] = 0;
    hash_extra[1] = 0;
    hash_extra[2] = 0;
    hash_extra[3] = 0;
    if (differs)
        sound_name_get((char *)hash_extra, 16);
    k.which = which;
    k.bank = par[5];
    k.index = par[6];
    k.differs = differs;
    k.matches = sound_name_matches();
    k.fn = dx_fn_held();
    for (i = 0; i < 0x9c; i++)
        h = (hash_patch[i] ^ h) * 0x01000193;
    for (i = 0; i < 0x18; i++)
        h = (((unsigned char *)&k)[i] ^ h) * 0x01000193;
    for (i = 0; i < 0x10; i++)
        h = (((unsigned char *)hash_extra)[i] ^ h) * 0x01000193;
    return h;
}

/* The LFO's wave at a phase (0-4095), -4096 to 4096. */
static int lfo_preview_sample(int wave, int phase)
{
    int p = phase & 0xfff, s, c;
    switch (wave) {
    case 0:
        if (!(phase & 0xc00))
            return p << 2;
        if (p > 0xbff)
            return (p - 0x1000) << 2;
        return (0x800 - p) << 2;
    case 1:
        return (0x800 - p) << 1;
    case 2:
        return (p - 0x800) << 1;
    case 3:
        return (phase & 0x800) ? -0x1000 : 0x1000;
    case 4:
        if (p > 0x800)
            p -= 0x1000;
        dxd_sincos(p, &s, &c);
        return s;
    default:
        return (sh_table[p >> 9] << 12) / 100;
    }
}

/* An envelope's graph: the x and y of its six points (rates and levels as the patch has them). */
static void env_geometry(const unsigned char *rates, const unsigned char *levels, int *xs, int *ys)
{
    int r[4], sum = 0, i, x;
    int v[6];
    for (i = 0; i < 4; i++) {
        unsigned char t = rates[i];
        if (t > 99)
            t = 99;
        r[i] = 0x68 - t;
        sum += r[i];
    }
    v[0] = levels[3];
    v[1] = levels[0];
    v[2] = levels[1];
    v[3] = levels[2];
    v[4] = levels[2];
    v[5] = levels[3];
    xs[0] = 0xa2;
    x = 0xa2 + 117 * r[0] / sum;
    xs[1] = x;
    x += 117 * r[1] / sum;
    xs[2] = x;
    x += 117 * r[2] / sum;
    xs[3] = x;
    xs[4] = x + 0x1d;
    xs[5] = 0x134;
    for (i = 0; i < 6; i++) {
        int t = v[i];
        if (t > 99)
            t = 99;
        ys[i] = 0x80 + t * 3 * 8 / -0x63;
    }
}

/* A seven-segment digit. */
static void seg_digit(int x, int y, int w, int digit, int colour)
{
    int mask = (unsigned)digit <= 9 ? seg_mask[digit] : 0;
    int xr = x + w, i;
    int s[7][4] = {
        { x + 2, y, xr - 2, y + 1 },
        { xr - 2, y + 2, xr, y + 6 },
        { xr - 2, y + 8, xr, y + 12 },
        { x + 2, y + 13, xr - 2, y + 14 },
        { x, y + 8, x + 2, y + 12 },
        { x, y + 2, x + 2, y + 6 },
        { x + 2, y + 6, xr - 2, y + 7 },
    };
    for (i = 0; i < 7; i++) {
        int c = C_OFF;
        if ((mask >> i) & 1)
            c = colour;
        dxd_fill(s[i][0], s[i][1], s[i][2], s[i][3], c);
    }
}

/* A parameter's box on the T2 and T4 pages: the label, a two-digit value (or a text), a second text. */
static void param_box(int idx, const char *label, int value, const char *t1, const char *t2)
{
    int x = 78 * idx + 8;
    stroke_text_draw(x, 0x68, 1, C_DIM, label);
    if (t1)
        stroke_text_draw(x, 0x76, 1, -10 - idx, t1);
    else if (value != -1) {
        seg_digit(x, 0x72, 9, (value / 10) % 10, -10 - idx);
        seg_digit(78 * idx + 0x15, 0x72, 9, value % 10, -10 - idx);
    }
    if (t2)
        stroke_text_draw(78 * idx + 0x26, 0x7a, 1, C_DIM, t2);
}

/* ---------------------------------------------------------------- T4: the LFO */

void engine_page_t4(void)
{
    short par[8];
    int fn, wave, still, i, stepped;
    int phase, delay, p, y, x;
    unsigned key;

    dx_live(par);
    current_patch_get(par[5], par[6], t4_patch);
    fn = dx_fn_held();
    wave = t4_patch[0x8e] <= 5 ? t4_patch[0x8e] : 5;
    key = page_key(4);
    still = dxd_still(key);
    if (!still) {
        int px = 0, py = 0, cx;
        page_draw_voice_title("lfo");
        stepped = (0x28 >> wave) & 1;
        cx = 0x1e00;
        for (i = 0; i <= 64; i++) {
            int v = lfo_preview_sample(wave, i << 6);
            int fy;
            v = (v * 15) << 9;
            if (v < 0)
                v += 0xfff;
            v >>= 12;
            fy = 0x3c00 - v;
            if (i != 0) {
                if (stepped) {
                    dxd_stroke_line(px, py, cx, py, 0x100, C_E4);
                    if (fy != py)
                        dxd_stroke_line(cx, py, cx, fy, 0x100, C_E4);
                } else
                    dxd_stroke_line(px, py, cx, fy, 0x100, C_E4);
            }
            px = cx;
            py = fy;
            cx += 0x438;
        }
        dxd_frame(0xa, 0x1e, 0x10, 0x5a, C_OFF);
        if (fn) {
            const char *name = wave_names[wave];
            stroke_text_draw(8, 0x68, 1, C_DIM, "wave");
            if (name)
                stroke_text_draw(8, 0x76, 1, C_E1, name);
            param_box(1, "pitch sens", t4_patch[0x8f] > 7 ? 7 : t4_patch[0x8f], 0, 0);
            stroke_text_draw(0xa4, 0x68, 1, C_DIM, "key sync");
            stroke_text_draw(0xa4, 0x76, 1, C_E3, t4_patch[0x8d] ? "on" : "off");
        } else {
            param_box(0, "speed", t4_patch[0x89], 0, 0);
            param_box(1, "delay", t4_patch[0x8a], 0, 0);
            param_box(2, "pitch", t4_patch[0x8b], 0, "depth");
            param_box(3, "amp", t4_patch[0x8c], 0, "depth");
        }
        stroke_text_draw_right(0x13a, 0x8c, 1, C_DIM, "fn held: wave, sens, sync");
        dxd_still_done();
    }
    lfo_state_get(&phase, &delay);
    p = lfo_preview_sample(wave, (unsigned)phase >> 20);
    y = 0x800 + 15 * p * 2;
    if (y < 0)
        y += 0xfff;
    y = 0x3c - (y >> 12);
    x = (((unsigned)phase >> 24) * 0x10e >> 8) + 0x1e;
    dxd_dot(x, y, 3, 1, C_TEXT);
    {
        int d = (delay >> 12) * 29 * 2;
        if (d > 0xfff)
            dxd_fill(0xc, 0x59 - (d >> 12), 0xe, 0x59, C_E2);
    }
}

/* ---------------------------------------------------------------- T2: the amplitude envelope */

void engine_page_t2(void)
{
    const unsigned char *amp = (sound_data.flags & 2) ? sound_data.amp : default_amp_env;
    int fn = dx_fn_held();
    int w[5], xs[6], ys[6], total, holdw, i, x, peaky, susy;
    unsigned h;
    int still;
    struct voice *v;

    w[0] = amp[0] + 8;
    holdw = 0;
    if (amp[5])
        holdw = (amp[5] >> 1) + 6;
    w[1] = holdw & 0xff;
    w[2] = amp[1] + 8;
    w[3] = 0;
    w[4] = amp[3] + 8;
    total = w[0] + holdw + w[2] + w[4];
    xs[0] = 14;
    x = 14;
    for (i = 0; i < 5; i++) {
        if (i == 3) {
            x += 0x32;
            xs[4] = x;
            continue;
        }
        x += w[i] * 242 / total;
        xs[i < 3 ? i + 1 : 5] = x;
    }
    xs[5] = 0x132;
    peaky = amp[4] * 62 / -0x63 + 92;
    susy = amp[2] * 62 / -0x63 + 92;
    ys[0] = 92;
    ys[1] = ys[2] = peaky;
    ys[3] = ys[4] = susy;
    ys[5] = 92;

    h = page_key(2);
    for (i = 0; i < 8; i++)
        h = (amp[i] ^ h) * 0x01000193;
    still = dxd_still(h);
    if (!still) {
        int notfn;
        int hold_ms;
        page_draw_voice_title("amp envelope");
        notfn = fn == 0;
        for (i = 0; i < 5; i++) {
            int c;
            if (notfn) {
                if (i == 1)
                    c = C_DIM;
                else
                    c = -0xa - amp_color_idx[i];
            } else
                c = i == 1 ? C_E2 : C_DIM;
            dxd_line(xs[i], ys[i], xs[i + 1], ys[i + 1], c);
            dxd_line(xs[i], ys[i] - 1, xs[i + 1], ys[i + 1] - 1, c);
        }
        if (fn) {
            dxd_dot(xs[1], peaky, 3, fn, C_E1);
            dxd_line(0xe, 0x5e, 0x132, 0x5e, C_OFF);
            dx_fmt(texts[0], 12, "-%idb", (99 - amp[4]) * 3 * 32 / 0x63);
            hold_ms = still;
            if (amp[5])
                hold_ms = amp_hold_page_lookup(amp[5]);
            dx_fmt(texts[1], 12, "%ims", hold_ms);
            param_box(0, "peak", amp[4], 0, texts[0]);
            param_box(1, "hold", amp[5], 0, texts[1]);
            stroke_text_draw_right(0x13a, 0x8c, 1, C_DIM, "fn: peak, hold");
        } else {
            dxd_dot(xs[1], peaky, 1, 0, C_DIM);
            dxd_line(0xe, 0x5e, 0x132, 0x5e, C_OFF);
            dx_fmt(texts[0], 12, "%ims", amp_hold_page_lookup(amp[0]));
            dx_fmt(texts[1], 12, "%ims", amp_hold_page_lookup(amp[1]));
            dx_fmt(texts[2], 12, "-%idb", (99 - amp[2]) * 3 * 32 / 0x63);
            dx_fmt(texts[3], 12, "%ims", amp_hold_page_lookup(amp[3]));
            param_box(0, "attack", amp[0], 0, texts[0]);
            param_box(1, "decay", amp[1], 0, texts[1]);
            param_box(2, "sustain", amp[2], 0, texts[2]);
            param_box(3, "release", amp[3], 0, texts[3]);
            stroke_text_draw_right(0x13a, 0x8c, 1, C_DIM, "fn held: peak, hold");
        }
        dxd_still_done();
    }

    /* the note's place on the curve */
    v = last_note_voice;
    if (v && VOICE_ACTIVE(v->index)) {
        int peakg = amp_peak_gain(amp[4]);
        int susg = amp_peak_gain(amp[2]);
        int stage = v->stage, s, prog, x0, y;
        if (stage > 4) {
            s = 4;
            prog = 0x100;
        } else {
            switch (stage) {
            case 0:
                prog = (v->amp_level >> 8) / ((msfa_exp2_lookup(peakg) >> 16) + 1);
                goto clamp;
            case 1:
                if (amp[5] == 0)
                    prog = 0x100;
                else {
                    int ms = amp_hold_page_lookup(amp[5]);
                    prog = 0x100 - ((v->hold << 8) / (ms * 100 / 0x91 + 1));
                    if (prog > 0x100)
                        prog = 0x100;
                    if (prog < 0)
                        prog = 0;
                    break;
                }
                break;
            case 2:
                prog = (peakg - v->amp_level) / (((peakg - susg) >> 8) + 1);
                goto clamp;
            case 3:
                prog = 0x80;
                break;
            default:
                prog = (susg - v->amp_level) / (((susg + 0x10000000) >> 8) + 1);
            clamp:
                if (prog > 0x100)
                    prog = 0x100;
                if (prog < 0)
                    prog = 0;
                break;
            }
            s = stage;
        }
        x0 = (xs[s + 1] - xs[s]) * prog / 256 + xs[s];
        y = (ys[s + 1] - ys[s]) * prog / 256 + ys[s];
        dxd_dot(x0, y, 3, 1, C_TEXT);
    }
}

/* ---------------------------------------------------------------- the turns */

int engine_turn(int encoder, int detents, int page)
{
    short par[8];
    int shift, nrows, sel, i, k;
    const struct prow *tbl;

    if (page == 1) {                       /* T2: its amplitude envelope */
        int idx, cur, step;
        const unsigned char *amp;
        idx = amp_param_map[dx_fn_held() != 0][encoder & 3];
        if (detents == 0 || idx == 0xff)
            return 1;
        amp = (sound_data.flags & 2) ? sound_data.amp : default_amp_env;
        cur = amp[idx];
        step = detents;
        if (dx_shift_held())
            step = detents * 10;
        amp_env_param_set(idx, cur + step);
        return 1;
    }
    if (page == 3) {                       /* T4: its LFO */
        int fn = dx_fn_held();
        int off, max, cur, step, v;
        if (detents == 0)
            return 1;
        off = lfo_param_map[fn != 0][encoder & 3];
        if (off == 0)
            return 1;
        dx_live(par);
        current_patch_get(par[5], par[6], turn_patch_t4);
        if ((unsigned char)(off - 0x8d) <= 2)
            max = lfo_max[off - 0x8d];
        else
            max = 99;
        cur = turn_patch_t4[off];
        step = detents;
        if (dx_shift_held())
            step = detents * 10;
        v = cur + step;
        if (v > max)
            v = max;
        if (v < 0)
            v = 0;
        patch_param_set(par[5], par[6], off, v);
        return 1;
    }
    if (page != 0)
        return 0;
    if (detents == 0)
        return 1;
    dx_live(par);
    if (t1_section == 0) {
        nrows = 4;
        tbl = global_rows;
    } else if (t1_section == 1) {
        nrows = 8;
        tbl = pe_rows;
    } else {
        nrows = 0x16;
        tbl = op_rows;
    }
    shift = dx_shift_held();
    if (encoder == 1) {                    /* green: the part */
        int v = t1_section + detents;
        if (v > 7)
            v = 7;
        if (v < 0)
            v = 0;
        t1_section = v;
        return 1;
    }
    if (encoder == 2) {                    /* white: the parameter, or with shift the next group */
        sel = t1_sel[t1_section];
        if (sel >= nrows)
            sel = nrows - 1;
        if (!shift) {
            sel += detents;
            if (sel < 0)
                sel = 0;
            else if (sel >= nrows)
                sel = nrows - 1;
        } else {
            int dir = detents <= 0 ? -1 : 1;
            int n = detents < 0 ? -detents : detents;
            for (k = n; k > 0; k--) {
                if (t1_section <= 1) {
                    sel += dir * 4;
                    if (sel < 0)
                        sel = 0;
                    else if (sel >= nrows)
                        sel = nrows - 1;
                } else if (dir > 0) {
                    if (sel < nrows - 1) {
                        int g = tbl[sel].group;
                        for (i = nrows - 1 - sel; i > 0; i--) {
                            if (tbl[sel].group != g)
                                break;
                            sel++;
                        }
                    }
                    if (sel >= nrows)
                        sel = nrows - 1;
                } else {
                    if (sel <= 0)
                        sel = 0;
                    else {
                        int g = tbl[sel].group;
                        for (i = sel; i > 0; i--) {
                            if (tbl[sel].group != g)
                                break;
                            sel--;
                        }
                        {
                            int gg = tbl[sel].group;
                            for (i = sel; i > 0; i--) {
                                if (tbl[sel - 1].group != gg)
                                    break;
                                sel--;
                            }
                        }
                    }
                    if (sel >= nrows)
                        sel = nrows - 1;
                }
            }
        }
        t1_sel[t1_section] = sel;
        return 1;
    }
    {
        int bank = par[5], index = par[6];
        if (encoder == 0) {                /* blue: the voice */
            int n = voice_number_from_bank(bank, index);
            int target = encoder;
            int b, ix;
            if (n + detents >= 0) {
                int total = voice_count_total();
                target = total <= n + detents ? total - 1 : n + detents;
            }
            voice_number_to_bank(target, &b, &ix);
            sound_data_reset();
            dx_knob_set(5, b);
            dx_knob_set(6, ix);
            return 1;
        }
        /* orange: the value */
        {
            const struct prow *row;
            int off, cur, v, step;
            sel = t1_sel[t1_section];
            if (sel >= nrows)
                sel = nrows - 1;
            row = &tbl[sel];
            current_patch_get(bank, index, turn_patch_t1);
            off = row->param;
            if (t1_section > 1)
                off += 21 * (7 - t1_section);
            if (row->fmt == 12)
                cur = (turn_patch_t1[0x9b] >> (7 - t1_section)) & 1;
            else
                cur = turn_patch_t1[off];
            step = shift ? detents * 10 : detents;
            v = cur + step;
            if (v < 0)
                v = 0;
            else if (v > row->max)
                v = row->max;
            if (row->fmt == 12) {
                int bit = 1 << (7 - t1_section);
                int m = turn_patch_t1[0x9b];
                patch_param_set(bank, index, 0x9b, v ? (bit | m) : (m & ~bit));
            } else
                patch_param_set(bank, index, off, v);
            return 1;
        }
    }
}


/* ---------------------------------------------------------------- T1: voice, part, parameter, value */

/* The value of the selected row as text: its text and a second one (a unit). */
static void value_text(const struct prow *row, int off, int v)
{
    t1_text2[0] = 0;
    switch (row->fmt) {
    default:
    case 0:
        dx_fmt(t1_text1, 0x10, "%i", v);
        break;
    case 1:
        dx_fmt(t1_text1, 0x10, "%i", v + 1);
        break;
    case 2:
        dx_fmt(t1_text1, 0x10, "%s", v ? "on" : "off");
        break;
    case 3:
        dx_fmt(t1_text1, 0x10, "%s", wave_names[v > 5 ? 5 : v]);
        break;
    case 4:
        dx_fmt(t1_text1, 0x10, "%s", curve_names[v & 3]);
        break;
    case 5:
        dx_fmt(t1_text1, 0x10, "%s", v ? "fixed" : "ratio");
        break;
    case 6: {                              /* the frequency: a ratio, or hertz when fixed */
        const unsigned char *o = &t1_patch[0x12 + 21 * (7 - t1_section)];
        int coarse = o[0], fine = o[1], mode = o[-1];
        if (mode == 0) {
            int base = coarse ? coarse * 100 : 50;
            int r = (fine + 100) * base / 100;
            dx_fmt(t1_text1, 0x10, "%i.%02i", r / 100, r % 100);
            dx_fmt(t1_text2, 0x10, "ratio");
        } else {
            int hz = ((msfa_exp2_lookup(fine * 0x8810e) >> 8) * 1000) >> 16;
            switch (coarse & 3) {
            case 0:
                dx_fmt(t1_text1, 0x10, "%i.%03i", hz / 1000, hz % 1000);
                break;
            case 1:
                dx_fmt(t1_text1, 0x10, "%i.%02i", hz / 100, hz % 100);
                break;
            case 2:
                dx_fmt(t1_text1, 0x10, "%i.%i", hz / 10, hz % 10);
                break;
            default:
                dx_fmt(t1_text1, 0x10, "%i", hz);
                break;
            }
            dx_fmt(t1_text2, 0x10, "hz");
        }
        break;
    }
    case 7:
        if (v <= 6)
            dx_fmt(t1_text1, 0x10, "-%i", 7 - v);
        else
            dx_fmt(t1_text1, 0x10, "+%i", v - 7);
        break;
    case 8:
    case 9: {                              /* a note: the transpose, the break point */
        int n = v + (row->fmt == 8 ? 0x24 : 0x15);
        dx_fmt(t1_text1, 0x10, "%s%i", note_names[n % 12], n / 12 - 2);
        break;
    }
    }
    (void)off;
}

void engine_page_t1(void)
{
    short par[8];
    int bank, index, nrows, sel, shift, differs, matches, i, sec, pos, poff, selop, k[10];
    const struct prow *tbl, *row;
    unsigned h;
    int fmt10;

    dx_live(par);
    bank = par[5];
    index = par[6];
    current_patch_get(bank, index, t1_patch);
    sec = t1_section;
    if (sec == 0) {
        nrows = 4;
        tbl = global_rows;
    } else if (sec == 1) {
        nrows = 8;
        tbl = pe_rows;
    } else {
        nrows = 0x16;
        tbl = op_rows;
    }
    sel = t1_sel[sec];
    if (sel >= nrows)
        sel = nrows - 1;
    row = &tbl[sel];
    shift = dx_shift_held();
    differs = sound_name_differs();
    matches = sound_name_matches();
    ((int *)t1_name)[0] = 0;
    ((int *)t1_name)[1] = 0;
    ((int *)t1_name)[2] = 0;
    ((int *)t1_name)[3] = 0;
    {
        int last = 0, n = 0;
        for (i = 0; i < 10; i++) {
            int c = (signed char)t1_patch[0x91 + i];
            n++;
            if ((unsigned char)(c - 0x41) <= 25) {
                t1_name[i] = c + 0x20;
                last = n;
            } else if ((unsigned char)(c - 0x20) <= 0x5e) {
                t1_name[i] = c;
                if (c != 0x20)
                    last = n;
            } else
                t1_name[i] = 0x20;
        }
        t1_name[last] = 0;
    }
    if (differs)
        sound_name_get(t1_name, 16);
    pos = sec << 16;
    if (page_pos >= 0) {
        int d = pos - page_pos;
        if ((unsigned)(d + 2) > 4)
            pos = d / 3 + page_pos;
    }
    page_pos = pos;
    fmt10 = (unsigned char)(row->fmt - 10);
    poff = sec == 1 ? 0x7e : 21 * (7 - sec);

    k[0] = 1;
    k[1] = bank;
    k[2] = index;
    k[3] = sec;
    k[4] = sel;
    k[5] = shift;
    k[6] = differs;
    k[7] = matches;
    k[8] = pos;
    k[9] = t1_bar;
    h = 0x811c9dc5;
    for (i = 0; i < 0x9c; i++)
        h = (t1_patch[i] ^ h) * 0x01000193;
    for (i = 0; i < 0x28; i++)
        h = (((unsigned char *)k)[i] ^ h) * 0x01000193;
    for (i = 0; i < 0x10; i++)
        h = ((unsigned char)t1_name[i] ^ h) * 0x01000193;

    if (!dxd_still(h)) {
        int alg, off, x, minx, maxx, segsel;
        const unsigned char *A, *p;
        int carriers, fmt, v, boff;
        const char *bn, *txt;

        dxd_frame(6, 3, 0x30, 0x17, C_DIM);
        {
            int tens = 0, ones = 0;
            if (!differs) {
                int n = (index + 1) % 100;
                tens = n / 10;
                ones = n % 10;
            }
            seg_digit(0xb, 6, 0xd, tens, C_E1);
            seg_digit(0x1d, 6, 0xd, ones, C_E1);
        }
        dxd_text(0, 0x38, 6, 0xf, C_TEXT, t1_name);
        bn = bank_name_of_id(bank);
        stroke_text_draw_right(0x13a, 0xa, 1, C_DIM, bn);
        if (matches)
            stroke_text_draw_right(0x132 - stroke_text_width(bn, 1), 0xa, 1, C_E4, "edited");
        off = (pos * 38) >> 16;
        dxd_fill(off + 6, 0x1c, off + 0x29, 0x28, C_E2);
        for (i = 0, x = 6; i < 8; i++, x += 0x26) {
            const char *lab = part_names[i];
            int w;
            if (sec != i)
                dxd_frame(x, 0x1c, x + 0x23, 0x28, C_OFF);
            w = stroke_text_width(lab, 1);
            stroke_text_draw(x + (0x24 - w) / 2, 0x1f, 1, sec == i ? DX_C_BACK : C_DIM, lab);
        }
        dxd_frame(6, 0x2e, 0x96, 0x84, C_OFF);
        alg = t1_patch[0x86] & 0x1f;
        dx_fmt(t1_alg, 0xc, "alg %i", alg + 1);
        stroke_text_draw_right(0x92, 0x31, 1, C_DIM, t1_alg);
        selop = (sec > 1 ? sec : 1) - 1;
        A = algorithm_draw[alg];
        algo_origin(A);
        carriers = A[0x1f];
        if (A[0xc]) {
            for (p = A + 0xd; p != A + 0xd + 2 * A[0xc]; p += 2) {
                int a = p[0], b = p[1];
                int xa = algo_x0 + 11 * A[a - 1] + 9;
                int ya = algo_y0 - 19 * A[6 + a - 1] + 14;
                int xb = algo_x0 + 11 * A[b - 1] + 9;
                int yb = algo_y0 - 19 * A[6 + b - 1];
                dxd_line(xa, ya, xb, yb, (selop == a || selop == b) ? C_E2 : C_DIM);
            }
        }
        if (A[0x1d]) {
            int from = A[0x1d], to = A[0x1e];
            int xf = algo_x0 + 11 * A[from - 1], xt = algo_x0 + 11 * A[to - 1];
            int xr = (xf > xt ? xf : xt) + 0x15;
            int yf = algo_y0 - 19 * A[6 + from - 1] + 7;
            int yt = algo_y0 - 19 * A[6 + to - 1];
            dxd_line(xf + 0x12, yf, xr, yf, C_E4);
            dxd_line(xr, yf, xr, yt - 3, C_E4);
            dxd_line(xr, yt - 3, xt + 9, yt - 3, C_E4);
            dxd_line(xt + 9, yt - 3, xt + 9, yt, C_E4);
        }
        minx = 0x3e8;
        maxx = -1;
        for (i = 1; i < 7; i++) {
            int xi = algo_x0 + 11 * A[i - 1];
            int yi = algo_y0 - 19 * A[6 + i - 1];
            int car = (1 << (i - 1)) & carriers;
            int en = (t1_patch[0x9b] >> (6 - i)) & 1;
            if (selop == i) {
                dxd_frame(xi, yi, xi + 0x12, yi + 0xe, C_E2);
                dxd_frame(xi - 1, yi - 1, xi + 0x13, yi + 0xf, C_E2);
            } else if (!en)
                dxd_frame(xi, yi, xi + 0x12, yi + 0xe, C_OFF);
            else
                dxd_frame(xi, yi, xi + 0x12, yi + 0xe, car ? C_TEXT : C_DIM);
            if (car) {
                dxd_line(xi + 9, yi + 0xe, xi + 9, algo_y0 + 0x11, C_DIM);
                if (xi + 9 < minx)
                    minx = xi + 9;
                if (xi + 8 >= maxx)
                    maxx = xi + 9;
            }
        }
        dxd_line(minx, algo_y0 + 0x11, maxx, algo_y0 + 0x11, C_DIM);
        dxd_frame(0x9c, 0x2e, 0x13a, 0x84, C_OFF);
        txt = sec <= 1 ? section_names[sec] : group_names[row->group];
        stroke_text_draw(0xa0, 0x31, 1, C_DIM, txt);
        dxd_text(0xc, 0xa0, 0x3b, 0xd, C_E3, row->name);
        fmt = row->fmt;
        boff = row->param + (sec > 1 ? 21 * (7 - sec) : 0);
        if (fmt == 12) {
            v = (t1_patch[0x9b] >> (7 - sec)) & 1;
            t1_text2[0] = 0;
            dx_fmt(t1_text1, 0x10, "%s", v ? "on" : "off");
        } else {
            v = t1_patch[boff];
            value_text(row, boff, v);
        }
        dxd_text(0xd, 0xa0, 0x4c, 0x18, C_E4, t1_text1);
        stroke_text_draw_right(0x136, 0x5c, 1, C_DIM, t1_text2);
        if (fmt10 <= 1) {                  /* an envelope row: its graph */
            int xs[6], ys[6], r, kk;
            const unsigned char *rates, *levels;
            if (sec == 1) {
                rates = t1_patch + 0x7e;
                levels = t1_patch + 0x82;
                segsel = sel;
            } else {
                rates = t1_patch + 21 * (7 - sec);
                levels = rates + 4;
                segsel = sel - 6;
            }
            env_geometry(rates, levels, xs, ys);
            for (r = 0; r < 5; r++) {
                int sl = (unsigned)segsel <= 3 && rate_segs[segsel] == r;
                if (sl) {
                    dxd_line(xs[r], ys[r], xs[r + 1], ys[r + 1], C_E4);
                    dxd_line(xs[r], ys[r] - 1, xs[r + 1], ys[r + 1] - 1, C_E4);
                } else if (r == 3) {
                    dxd_line(xs[3], ys[3], xs[4], ys[4], C_DIM);
                    r = 4;
                    if ((unsigned)segsel <= 3 && rate_segs[segsel] == 4) {
                        dxd_line(xs[4], ys[4], xs[5], ys[5], C_E4);
                        dxd_line(xs[4], ys[4] - 1, xs[5], ys[5] - 1, C_E4);
                    } else
                        dxd_line(xs[4], ys[4], xs[5], ys[5], C_TEXT);
                } else
                    dxd_line(xs[r], ys[r], xs[r + 1], ys[r + 1], C_TEXT);
            }
            for (kk = 4; kk < 8; kk++) {
                int idx = level_dots[kk - 4];
                int on = kk == segsel;
                dxd_dot(xs[idx], ys[idx], on ? 3 : 1, on, on ? C_E4 : C_DIM);
            }
        } else {
            int mx = row->max ? row->max : 1;
            int frac = (v << 16) / mx, d, lit;
            d = frac - t1_bar;
            if ((unsigned)(d + 2) > 4)
                frac = d / 3 + t1_bar;
            t1_bar = frac;
            lit = (0x8000 + frac * 20) >> 16;
            for (i = 0; i < 20; i++)
                dxd_fill(0xa2 + ((15 * i) >> 1), 0x72, 0xa7 + ((15 * i) >> 1), 0x7e, lit > i ? C_E4 : C_OFF);
        }
        {
            const char *const *hint = hint_names[shift != 0];
            for (i = 0, x = 0xc; x != 0x13c; i++, x += 0x4c) {
                dxd_dot(x, 0x8d, 3, 1, -0xa - i);
                stroke_text_draw(x + 8, 0x8a, 1, C_DIM, hint[i]);
            }
        }
        dxd_still_done();
    }

    /* what moves: the operators' levels and digits, a note's place on an envelope */
    {
        struct voice *v;
        const unsigned char *A = algorithm_draw[t1_patch[0x86] & 0x1f];
        int carriers = A[0x1f];
        selop = (sec > 1 ? sec : 1) - 1;
        algo_origin(A);
        for (i = 1; i < 7; i++) {
            int xi = algo_x0 + 11 * A[i - 1];
            int yi = algo_y0 - 19 * A[6 + i - 1];
            int en = (t1_patch[0x9b] >> (6 - i)) & 1;
            int c, mask;
            v = last_note_voice;
            if (v && VOICE_ACTIVE(v->index)) {
                int lev = *(short *)((char *)v + (6 - i) * 32 + 2) - 0x7e0, hh;
                if (lev > 0) {
                    hh = lev > 0x7ff ? 11 : (lev * 11) >> 11;
                    if (hh != 0)
                        dxd_fill(xi + 2, yi + 0xd - hh, xi + 0x10, yi + 0xc, ((1 << (i - 1)) & carriers) ? C_E1 : C_DIM);
                }
            }
            c = selop == i ? C_E2 : (en ? C_TEXT : C_OFF);
            mask = seg_mask[i];
            if (mask & 1)
                dxd_line(xi + 6, yi + 3, xi + 0xc, yi + 3, c);
            if (mask & 2)
                dxd_line(xi + 0xc, yi + 3, xi + 0xc, yi + 7, c);
            if (mask & 4)
                dxd_line(xi + 0xc, yi + 7, xi + 0xc, yi + 0xb, c);
            if (mask & 8)
                dxd_line(xi + 6, yi + 0xb, xi + 0xc, yi + 0xb, c);
            if (mask & 0x10)
                dxd_line(xi + 6, yi + 7, xi + 6, yi + 0xb, c);
            if (mask & 0x20)
                dxd_line(xi + 6, yi + 3, xi + 6, yi + 7, c);
            if (mask & 0x40)
                dxd_line(xi + 6, yi + 7, xi + 0xc, yi + 7, c);
        }
        if (fmt10 <= 1 && sec > 1) {
            v = last_note_voice;
            if (v && VOICE_ACTIVE(v->index)) {
                struct env *e = &v->env[7 - sec];
                int a, b, start, prog, lv, xs[6], ys[6];
                if (e->ix > 3) {
                    prog = 0x10000;
                    b = 5;
                    a = 4;
                } else if (e->ix == 3 && e->down) {
                    prog = 0x8000;
                    b = 4;
                    a = 3;
                } else {
                    int p3;
                    if (e->ix == 3) {
                        b = 5;
                        a = 4;
                        p3 = 2;
                    } else if (e->ix != 0) {
                        b = e->ix + 1;
                        a = e->ix;
                        p3 = e->ix - 1;
                    } else {
                        b = 1;
                        a = 0;
                        p3 = 3;
                    }
                    lv = e->levels[p3];
                    lv = lv <= 19 ? levellut2[lv] : lv + 28;
                    if (e->ix == 0)
                        start = 0;
                    else {
                        start = (lv >> 1 << 6) + e->outlevel - 4256;
                        if (start < 16)
                            start = 16;
                        start <<= 16;
                    }
                    prog = (e->target - start) >> 16;
                    if (prog == 0)
                        prog = 0x10000;
                    else {
                        prog = (e->level - start) / prog;
                        if (prog > 0x10000)
                            prog = 0x10000;
                        if (prog < 0)
                            prog = 0;
                    }
                }
                env_geometry(t1_patch + poff, t1_patch + poff + 4, xs, ys);
                dxd_dot(((xs[b] - xs[a]) * prog >> 16) + xs[a], ((ys[b] - ys[a]) * prog >> 16) + ys[a], 2, 1, C_E1);
            }
        }
    }
}
