/* dx: a voice player for DX7 voices. Ported 1:1 from another creator's plugin with the author's permission (per the owner,
 * 2026-11-14; PROVENANCE.md). The FM follows Google's Music Synthesizer for Android (MSFA, Copyright 2012 Google Inc.,
 * Apache License 2.0; NOTICE). Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well. */
/* The bank folder (DX_BANK_DIR): .syx files (32-voice dumps, single-voice dumps) and the list of banks they make.
 * The original read its own mod folder; the files come from dx_glue.c's directory and file calls. */
#include "dx.h"

static struct bank bank_store[16];          /* 66 KB: the banks (.bss) */
static int bank_count_var;
static unsigned char sysex_buffer[0x1009];
static char scan_path[48];
static char scan_name[14];
static unsigned char scan_patch[156];

static int lower(int c)
{
    if ((unsigned)(c - 0x41) <= 25)
        c += 0x20;
    return c;
}

/* The length of a name before its ".syx" (any case), or 0. */
static int syx_stem_length(const char *s)
{
    int n;
    const char *p;
    if (s[0] == 0)
        return 0;
    n = 0;
    p = s + 1;
    do
        n++;
    while (*p++ != 0);
    if (n <= 4)
        return 0;
    if (s[0] == '.')
        return 0;
    p = s + n - 1;
    if (p[-3] == '.') {
        if (lower(p[-2]) == 's' && lower(p[-1]) == 'y' && lower(p[0]) == 'x')
            return n - 4;
    }
    return 0;
}
static __attribute__((noinline)) int syx_check_bank32(int n)   /* noinline: the release keeps it whole (no .part split): a hypothesis */
{
    int sum, i;
    if (n != 0x1008 || sysex_buffer[0] != 0xf0)
        return 0;
    if (sysex_buffer[1] != 0x43 || sysex_buffer[2] > 0xf || sysex_buffer[3] != 9 || sysex_buffer[4] != 0x20
        || sysex_buffer[5] != 0 || sysex_buffer[0x1007] != 0xf7)
        return 0;
    sum = 0;
    for (i = 0; i < 0x1000; i++)
        sum += sysex_buffer[6 + i] & 0x7f;
    return (-sum & 0x7f) == sysex_buffer[0x1006];
}

static __attribute__((noinline)) int syx_check_voice1(int n)
{
    int sum, i;
    if (n != 0xa3 || sysex_buffer[0] != 0xf0)
        return 0;
    if (sysex_buffer[1] != 0x43 || sysex_buffer[2] > 0xf || sysex_buffer[3] != 0 || sysex_buffer[4] != 1
        || sysex_buffer[5] != 0x1b || sysex_buffer[0xa2] != 0xf7)
        return 0;
    sum = 0;
    for (i = 0; i < 0x9b; i++)
        sum += sysex_buffer[6 + i] & 0x7f;
    return (-sum & 0x7f) == sysex_buffer[0xa1];
}

/* Reads the folder: banks (sorted by name, up to 16). Kennel: no page art from the folder (t1/t2/t4.svg). */
void bank_scan(void)
{
    void *dir;
    const char *name;
    int n, i, j, stem, len, is32, id;
    unsigned h;
    struct bank *b;

    dir = dx_dir_open(DX_BANK_DIR);
    n = 0;
    if (dir) {
        while ((name = dx_dir_next(dir)) != 0) {
            if (n > 15)
                continue;
            stem = syx_stem_length(name);
            if (stem == 0 || stem > 13)
                continue;
            {                                  /* DX_BANK_DIR "/" name (the original: snprintf) */
                const char *p = DX_BANK_DIR;
                char *q = scan_path;
                while (*p)
                    *q++ = *p++;
                *q++ = '/';
                for (p = name; *p && q < scan_path + sizeof scan_path - 1; )
                    *q++ = *p++;
                *q = 0;
            }
            len = dx_file_read(scan_path, sysex_buffer, 0x1009);
            is32 = syx_check_bank32(len);
            if (!is32 && !syx_check_voice1(len))
                continue;
            for (i = 0; i < stem; i++)
                scan_name[i] = lower(name[i]);
            scan_name[stem] = 0;
            b = bank_store;
            j = n;
            while (j > 0) {
                const char *p = b[j - 1].name, *q = scan_name;
                while (*p == *q && *q)
                    p++, q++;
                if ((unsigned char)*p <= (unsigned char)*q)
                    break;
                b[j] = b[j - 1];
                j--;
            }
            b = &b[j];
            for (i = 0; i <= stem; i++)
                b->name[i] = scan_name[i];
            if (scan_name[0] == 0)
                id = 0x1ffc;
            else {
                h = 0x811c9dc5;
                for (i = 0; scan_name[i]; i++)
                    h = (scan_name[i] ^ h) * 0x01000193;
                id = (h >> 15 ^ h) & 0x7fff;
                if (id == 0)
                    id = 1;
            }
            b->id = id;
            if (is32) {
                b->count = 0x20;
                for (i = 0; i < 0x1000; i++)
                    ((unsigned char *)b->voices)[i] = sysex_buffer[6 + i];
            } else {
                b->count = 1;
                for (i = 0; i < 0x9b; i++)
                    scan_patch[i] = sysex_buffer[6 + i];
                scan_patch[0x9b] = 0x3f;
                patch_pack(scan_patch, b->voices[0]);
            }
            n++;
        }
        dx_dir_close(dir);
    }
    bank_count_var = n;
}

int bank_count(void)
{
    return bank_count_var;
}

int bank_id(int i)
{
    if (i >= 0 && i < bank_count_var)
        return bank_store[i].id;
    return 0;
}

int bank_voice_count(int i)
{
    if (i >= 0 && i < bank_count_var)
        return bank_store[i].count;
    return 0;
}

int bank_index_of_id(int id)
{
    int i;
    for (i = 0; i < bank_count_var; i++)
        if (bank_store[i].id == id)
            return i;
    return -1;
}

const char *bank_name_of_id(int id)
{
    int i;
    for (i = 0; i < bank_count_var; i++)
        if (id == bank_store[i].id)
            return bank_store[i].name;
    return "dx";
}

const unsigned char *bank_voice_ptr(int id, int voice)
{
    int i;
    for (i = 0; i < bank_count_var; i++)
        if (id == bank_store[i].id) {
            if (voice < 0 || bank_store[i].count <= voice)
                return 0;
            return bank_store[i].voices[voice];
        }
    return 0;
}

