/* dx: a voice player for DX7 voices. Ported 1:1 from another creator's plugin with the author's permission (per the owner,
 * 2026-11-14; PROVENANCE.md). Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE). */
/* dx_draw.h over R246 and the three screens (T1 the engine's screen, T2 and T4 its own pages). dx_page.c draws in the
 * original host's terms (320 x 160 drawing units); here:
 *   lines   op1_raster_line, one unit wide, through pixel centres (x + 0.5, y + 0.5); stroke lines in units x 256
 *   fills, frames  pixels written into the raster (panel pixels: unit x rows / 320), fed to op1_screen_hash
 *   dots    a filled dot a disc of pixels (radius r units), an open one a 16-sided ring of raster lines
 *   text    one R246 text object per slot (stock font), made at its first use, as matrix_gfx.c's; the original's size
 *           as it is: the original made the same R246 text object (0x01A61904, top at y, caps size high) at that size
 *   colours the encoders' (kennel's), 14 white, 12 grey, 4 dark grey, 1 black
 * Placement: the original's own (ink y 3..146, inside the y 2..146 the original was drawn for); DX_Y_LIFT moves every
 * y here, once, when the panel check asks for it (0: none).
 * The still part is drawn every frame (dxd_still answers 0), as matrix_gfx.c does: R246's frame skip drops the frames
 * that come out the same. Pixel identity with the original is impossible (its renderer belongs to the other
 * firmware); the calls are proven 1:1 by test/page_guest.c. */
#include "op1_plugin.h"
#include "../../op1_synth.h"
#include "dx.h"
#include "dx_draw.h"

#define DX_Y_LIFT 0

static void *rast;
static void *cur_scr;
static int rows = 400;
static uint16_t *fb;

static const uint8_t enc_col[4][3] = { { 77, 158, 255 }, { 0, 237, 149 }, { 255, 255, 255 }, { 255, 58, 93 } };
static uint32_t rgb_of(int c)
{
    if (c <= -10 && c >= -13)
        return (uint32_t)enc_col[-10 - c][0] << 16 | (uint32_t)enc_col[-10 - c][1] << 8 | enc_col[-10 - c][2];
    if (c == DX_C_TEXT) return 0xFFFFFF;
    if (c == DX_C_DIM) return 0x7C7990;
    if (c == DX_C_OFF) return 0x45434F;
    if (c == 2) return 0xFF3A5D;
    return 0;
}
static void rgba_of(int c, uint8_t o[4])
{
    const uint32_t v = rgb_of(c);
    o[0] = (uint8_t)(v >> 16); o[1] = (uint8_t)(v >> 8); o[2] = (uint8_t)v; o[3] = 255;
}
static uint16_t rgb565(int c)
{
    const uint32_t v = rgb_of(c);
    return (uint16_t)((v >> 8 & 0xF800) | (v >> 5 & 0x07E0) | (v >> 3 & 0x001F));
}

static void seg(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t w, int c)   /* Q10 units */
{
    uint8_t col[4];
    op1_pt a = { x0, y0 - OP1_Q10(DX_Y_LIFT) }, b = { x1, y1 - OP1_Q10(DX_Y_LIFT) };
    rgba_of(c, col);
    if (rast) op1_raster_line(rast, &a, &b, w, col);
}
static int32_t unit_w(void) { return rows * 1024 / 320; }   /* one unit in the raster line's width (1280 at 400) */

void dxd_line(int x0, int y0, int x1, int y1, int c)
{
    seg(OP1_Q10(x0) + 512, OP1_Q10(y0) + 512, OP1_Q10(x1) + 512, OP1_Q10(y1) + 512, unit_w(), c);
}
void dxd_stroke_line(int x0, int y0, int x1, int y1, int w, int c)
{
    seg(x0 * 4, y0 * 4, x1 * 4, y1 * 4, w * rows / 80, c);   /* width x 256 panel pixels -> as matrix_gfx.c at 400 */
}

/* panel pixels of a unit span [u0, u1] (inclusive) */
static void span(int u0, int u1, int lim, int *p0, int *p1)
{
    *p0 = u0 * rows / 320;
    *p1 = (u1 + 1) * rows / 320 - 1;
    if (*p1 < *p0) *p1 = *p0;
    if (*p0 < 0) *p0 = 0;
    if (*p1 > lim - 1) *p1 = lim - 1;
}
static void px_rect(int x0, int y0, int x1, int y1, int c)        /* panel pixels, inclusive */
{
    if (!fb) return;
    const uint16_t v = rgb565(c);
    for (int x = x0; x <= x1; x++) {
        uint16_t *col = fb + (rows - 1 - x) * 256;
        for (int y = y0; y <= y1; y++) col[y] = v;
    }
}
void dxd_fill(int x0, int y0, int x1, int y1, int c)
{
    int a, b, p, q;
    if (x1 < x0 || y1 < y0 || x1 < 0 || x0 >= 320 || y1 - DX_Y_LIFT < 0 || y0 - DX_Y_LIFT >= 160) return;
    span(x0, x1, rows, &a, &b);
    span(y0 - DX_Y_LIFT, y1 - DX_Y_LIFT, rows / 2, &p, &q);
    px_rect(a, p, b, q, c);
    op1_screen_hash(cur_scr, (uint32_t)(x0 << 20 ^ y0 << 10 ^ x1) ^ (uint32_t)(y1 << 16 ^ (c & 0xFF) << 8));
}
void dxd_frame(int x0, int y0, int x1, int y1, int c)
{
    int a, b, p, q;
    if (x1 < x0 || y1 < y0 || x1 < 0 || x0 >= 320 || y1 - DX_Y_LIFT < 0 || y0 - DX_Y_LIFT >= 160) return;
    span(x0, x1, rows, &a, &b);
    span(y0 - DX_Y_LIFT, y1 - DX_Y_LIFT, rows / 2, &p, &q);
    px_rect(a, p, b, p, c);
    px_rect(a, q, b, q, c);
    px_rect(a, p, a, q, c);
    px_rect(b, p, b, q, c);
    op1_screen_hash(cur_scr, (uint32_t)(x0 << 20 ^ y0 << 10 ^ x1) ^ (uint32_t)(y1 << 16 ^ (c & 0xFF) << 8) ^ 0x80000000u);
}
void dxd_dot(int x, int y, int r, int filled, int c)
{
    const int32_t cx = OP1_Q10(x) + 512, cy = OP1_Q10(y) + 512;
    if (r <= 0) r = 1;
    if (filled) {                                    /* a disc of pixels: r units around the pixel's centre */
        if (!fb) return;
        const int32_t pcx = (2 * x + 1) * rows / 2, pcy = (2 * (y - DX_Y_LIFT) + 1) * rows / 2;   /* x 320 */
        const int32_t pr = r * rows, lim = pr * pr;
        const uint16_t v = rgb565(c);
        for (int px = (pcx - pr) / 320 - 1; px <= (pcx + pr) / 320 + 1; px++) {
            if (px < 0 || px >= rows) continue;
            const int32_t dx = px * 320 + 160 - pcx;
            for (int py = (pcy - pr) / 320 - 1; py <= (pcy + pr) / 320 + 1; py++) {
                const int32_t dy = py * 320 + 160 - pcy;
                if (py >= 0 && py < rows / 2 && dx * dx + dy * dy <= lim) fb[(rows - 1 - px) * 256 + py] = v;
            }
        }
        op1_screen_hash(cur_scr, (uint32_t)(x << 20 ^ y << 8 ^ r) ^ (uint32_t)(c & 0xFF) << 24 ^ 0x40000000u);
        return;
    }
    static const int16_t ring[17][2] = {             /* cos, sin x 1024, 16 steps */
        { 1024, 0 }, { 946, 392 }, { 724, 724 }, { 392, 946 }, { 0, 1024 }, { -392, 946 }, { -724, 724 }, { -946, 392 },
        { -1024, 0 }, { -946, -392 }, { -724, -724 }, { -392, -946 }, { 0, -1024 }, { 392, -946 }, { 724, -724 },
        { 946, -392 }, { 1024, 0 } };
    for (int i = 0; i < 16; i++)
        seg(cx + ring[i][0] * r, cy + ring[i][1] * r, cx + ring[i + 1][0] * r, cy + ring[i + 1][1] * r, unit_w(), c);
}

/* ---- text: one R246 text object per slot (matrix_gfx.c's text_at) ---- */
#define T_N 16
typedef struct {
    uint32_t mem[OP1_TEXT_SIZE / 4];
    int32_t x, y, size;
    uint8_t made, rgba[4];
    char last[16];
} dx_txt;
static dx_txt txt[T_N];
static const int32_t ident[9] = { 1024, 0, 0, 0, 1024, 0, 0, 0, 1024 };
#ifdef OP1_HOST
#define TXT_CTOR(o, x, y, sz, c) host_text_ctor((o), (x), (y), (sz), (c))
#else
#define TXT_CTOR(o, x, y, sz, c) (((void *(*)(void *, int32_t, int32_t, int32_t, const uint8_t *, int32_t))0x01A61904)( \
                                  (o), (x), (y), (sz), (c), 0))
#endif
#define F32(o, off) (*(int32_t *)((uint8_t *)(o) + (off)))

void dxd_text(int slot, int x, int y, int size, int colour, const char *t)
{
    if (slot < 0 || slot >= T_N || !t || !rast) return;
    dx_txt *o = &txt[slot];
    uint8_t c[4];
    rgba_of(colour, c);
    const int32_t xq = OP1_Q10(x), yp = y - DX_Y_LIFT;
    int reset = 0, k = 0;
    if (!o->made) {
        TXT_CTOR(o->mem, xq, yp, size, c);
        o->made = 1; o->x = xq; o->y = yp; o->size = size;
        for (k = 0; k < 4; k++) o->rgba[k] = c[k];
        o->last[0] = 1; o->last[1] = 0;
    }
    if (o->x != xq || o->y != yp || o->rgba[0] != c[0] || o->rgba[1] != c[1] || o->rgba[2] != c[2]) {
#ifdef OP1_HOST
        TXT_CTOR(o->mem, xq, yp, o->size, c);
#else
        F32(o->mem, 0x58) += xq - o->x;              /* the ctor stored x and y less the display's offset */
        F32(o->mem, 0x5C) += yp - o->y;
        for (k = 0; k < 4; k++) ((uint8_t *)o->mem)[0x6C + k] = c[k];
#endif
        o->x = xq; o->y = yp;
        for (k = 0; k < 4; k++) o->rgba[k] = c[k];
        reset = 1;
    }
    k = 0;
    while (k < 15 && t[k] && t[k] == o->last[k]) k++;
    if (reset || t[k] != o->last[k]) {
        op1_text_set(o->mem, t);
        for (k = 0; k < 15 && (o->last[k] = t[k]) != 0; k++) ;
        o->last[15] = 0;
    }
    if (o->last[0]) op1_text_draw(o->mem, rast, ident);
}

int dxd_still(unsigned key) { (void)key; return 0; }
void dxd_still_done(void) { }

/* the original's sincos (x 4096, a in 1/4096 of a turn) from R246's sine table (8192 a turn, x 32767) */
void dxd_sincos(int t, int *s, int *c)
{
    const int16_t *tab = OP1_SINE_TABLE;
    if (s) *s = (tab[(t * 2) & 8191] + 4) >> 3;
    if (c) *c = (tab[(t * 2 + 2048) & 8191] + 4) >> 3;
}

/* ---- the screens ---- */
static void frame_begin(void *scr, int dt)
{
    op1_screen_draw(scr, dt);                        /* an empty SVG: the cleared frame */
#ifndef OP1_HOST
    const uint32_t *r = op1_raster();
    rast = (void *)r;
    fb = (uint16_t *)(uintptr_t)r[0];
    rows = op1_panel_rows(r);
#else
    extern uint16_t host_frame565[400 * 256];
    rast = op1_raster();
    fb = host_frame565;
    rows = op1_panel_rows_of(host_screen_scale, 400);
#endif
    cur_scr = scr;
}
static void scr_init(void *scr) { (void)scr; }
static void t1_update(void *scr, int dt) { frame_begin(scr, dt); engine_page_t1(); }
static void t2_update(void *scr, int dt) { frame_begin(scr, dt); engine_page_t2(); }
static void t4_update(void *scr, int dt) { frame_begin(scr, dt); engine_page_t4(); }
const op1_screen_t SCREEN_dx = { scr_init, t1_update };
const op1_screen_t SCREEN_dx_t2 = { scr_init, t2_update };
const op1_screen_t SCREEN_dx_t4 = { scr_init, t4_update };
