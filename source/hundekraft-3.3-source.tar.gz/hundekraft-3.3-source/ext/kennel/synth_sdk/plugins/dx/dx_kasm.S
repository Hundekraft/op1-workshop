/* dx: the FM kernels for the Blackfin (dx_kern.h), bit for bit dx_kern.c's C (test/kern_check.py), software
 * pipelined: a sample's table address is made while the sample before it multiplies. A sine sample times the gain's
 * high half is R.L * R.H (IS), (short)(gain >> 16) exactly; the shift by a->shift (-9 .. -25) is ASHIFT BY R.L.
 * Sums wrap (NS) as the C's 32-bit ones do. Only R, P, I0..I2 (L0..L2 set to 0 first, as GIN's FIR does) and the loop registers.
 * fm_op_compute reads in[64] (one past the input; the voice's scratch has that word), as the original does.
 * Host builds assemble it empty. The FM follows Google's Music Synthesizer for Android (MSFA, Copyright 2012 Google
 * Inc., Apache License 2.0; NOTICE). Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1
 * firmware permission (see LICENSE and NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well. */
#include "dx_kern.h"
#ifdef DX_KERN_ASM
	.text

/* fm_op_compute(const struct fm_args *a = R0, int flags = R1): out 0, in 4, phase 8, freq 12, gain 16, dgain 20,
 * shift 24, sin 28. R0 phase, R1 freq, R2 gain, R6 dgain, R7 shift, P5 sin, P1 out (stores), I1 out (loads), I0 in.
 * 7 / 8 / 9 / 10 packets a sample (plain / add / input / input and add). */
	.align 4
	.global _fm_op_compute
	.type _fm_op_compute, STT_FUNC
_fm_op_compute:
	[--SP] = (R7:4, P5:3);
	P0 = R0;
	R5 = R1;
	R3 = 0;
	L0 = R3;
	L1 = R3;
	R3 = [P0 + 4];
	I0 = R3;
	P1 = [P0 + 0];
	R0 = [P0 + 8];
	R1 = [P0 + 12];
	R2 = [P0 + 16];
	R6 = [P0 + 20];
	R7 = [P0 + 24];
	P5 = [P0 + 28];
	R3 = P1;
	I1 = R3;
	P4 = 64;
	CC = BITTST (R5, 1);
	IF CC JUMP .Lin;
	/* no input: P2 = sample 0's address, P3 = sample 1's index, R0 = sample 2's phase */
	R3 = R0 >> 20;
	P3 = R3;
	R0 = R0 + R1 (NS);
	R3 = R0 >> 20;
	P2 = P5 + (P3 << 1);
	P3 = R3;
	R0 = R0 + R1 (NS);
	CC = BITTST (R5, 0);
	IF CC JUMP .Ladd;
	LSETUP (.L1s, .L1e) LC0 = P4;
.L1s:	R2 = R2 + R6 (NS) || R4 = W [P2] (X) || NOP;
	R3 = R0 >> 20;
	P2 = P5 + (P3 << 1);
	R4 = R4.L * R2.H (IS);
	P3 = R3;
	R4 = ASHIFT R4 BY R7.L;
.L1e:	R0 = R0 + R1 (NS) || [P1++] = R4 || NOP;
	(R7:4, P5:3) = [SP++];
	RTS;
.Ladd:
	LSETUP (.L2s, .L2e) LC0 = P4;
.L2s:	R2 = R2 + R6 (NS) || R4 = W [P2] (X) || R5 = [I1++];
	R3 = R0 >> 20;
	P2 = P5 + (P3 << 1);
	R4 = R4.L * R2.H (IS);
	P3 = R3;
	R4 = ASHIFT R4 BY R7.L;
	R4 = R4 + R5 (NS);
.L2e:	R0 = R0 + R1 (NS) || [P1++] = R4 || NOP;
	(R7:4, P5:3) = [SP++];
	RTS;
.Lin:	/* input: P2 = sample 0's address, R0 = sample 1's phase */
	R3 = [I0++];
	R3 <<= 18;
	R3 = R3 + R0;
	R3 >>= 20;
	P3 = R3;
	R0 = R0 + R1 (NS);
	P2 = P5 + (P3 << 1);
	CC = BITTST (R5, 0);
	IF CC JUMP .Linadd;
	LSETUP (.L3s, .L3e) LC0 = P4;
.L3s:	R2 = R2 + R6 (NS) || R4 = W [P2] (X) || R3 = [I0++];
	R3 = R3 << 18;
	R3 = R3 + R0 (NS);
	R4 = R4.L * R2.H (IS);
	R3 = R3 >> 20;
	P3 = R3;
	R4 = ASHIFT R4 BY R7.L;
	P2 = P5 + (P3 << 1);
.L3e:	R0 = R0 + R1 (NS) || [P1++] = R4 || NOP;
	(R7:4, P5:3) = [SP++];
	RTS;
.Linadd:
	LSETUP (.L4s, .L4e) LC0 = P4;
.L4s:	R2 = R2 + R6 (NS) || R4 = W [P2] (X) || R3 = [I0++];
	R3 = R3 << 18;
	R3 = R3 + R0 (NS);
	R4 = R4.L * R2.H (IS) || R5 = [I1++];
	R3 = R3 >> 20;
	P3 = R3;
	R4 = ASHIFT R4 BY R7.L;
	R4 = R4 + R5 (NS);
	P2 = P5 + (P3 << 1);
.L4e:	R0 = R0 + R1 (NS) || [P1++] = R4 || NOP;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _fm_op_compute, .-_fm_op_compute

/* fm_op_compute_fb1(struct fm_fb1_args *a = R0, int add = R1): out 0, fb 4, phase 8, freq 12, gain 16, dgain 20,
 * shift 24, sin 28, fs 32. R0 phase, R2 gain, R3 / R4 the last two outputs (each sample overwrites the older one, so
 * the body is two samples), R5 fs, R6 dgain, R7 shift, R1 the sum, then freq, then the output; I2 at a->freq.
 * 10 / 11 packets a sample. */
.macro FB1 yn, end
	R1 = R3 + R4 (NS);
	R1 = LSHIFT R1 BY R5.L;
	R1 = R1 + R0 (NS);
	R1 = R1 >> 20;
	P2 = R1;
	P2 = P5 + (P2 << 1);
	R2 = R2 + R6 (NS) || \yn = W [P2] (X) || R1 = [I2];
	\yn = \yn\().L * R2.H (IS);
	\yn = ASHIFT \yn BY R7.L;
.ifnb \end
\end:
.endif
	R0 = R0 + R1 (NS) || [P1++] = \yn || NOP;
.endm
.macro FB1ADD yn, end
	R1 = R3 + R4 (NS);
	R1 = LSHIFT R1 BY R5.L;
	R1 = R1 + R0 (NS);
	R1 = R1 >> 20;
	P2 = R1;
	P2 = P5 + (P2 << 1);
	R2 = R2 + R6 (NS) || \yn = W [P2] (X) || R1 = [I2];
	\yn = \yn\().L * R2.H (IS);
	R0 = R0 + R1 (NS) || R1 = [I1++];
	\yn = ASHIFT \yn BY R7.L;
	R1 = R1 + \yn (NS);
.ifnb \end
\end:
.endif
	[P1++] = R1;
.endm
	.align 4
	.global _fm_op_compute_fb1
	.type _fm_op_compute_fb1, STT_FUNC
_fm_op_compute_fb1:
	[--SP] = (R7:4, P5:3);
	P0 = R0;
	R3 = 0;
	L1 = R3;
	L2 = R3;
	P1 = [P0 + 0];
	P3 = [P0 + 4];
	R0 = [P0 + 8];
	R2 = [P0 + 16];
	R6 = [P0 + 20];
	R7 = [P0 + 24];
	P5 = [P0 + 28];
	R5 = [P0 + 32];
	R3 = [P3 + 0];
	R4 = [P3 + 4];
	P2 = P0;
	P2 += 12;
	I2 = P2;
	P2 = P1;
	I1 = P2;
	P4 = 32;
	CC = R1 == 0;
	IF !CC JUMP .Lfbadd;
	LSETUP (.L5s, .L5e) LC0 = P4;
.L5s:	FB1 R3
	FB1 R4, .L5e
	JUMP.S .Lfbend;
.Lfbadd:
	LSETUP (.L6s, .L6e) LC0 = P4;
.L6s:	FB1ADD R3
	FB1ADD R4, .L6e
.Lfbend:
	[P3 + 0] = R3;
	[P3 + 4] = R4;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _fm_op_compute_fb1, .-_fm_op_compute_fb1

/* fm_op_compute_fb(struct fm_fb_args *a = R0): out 0, n 4, shift 8, fb0 16, fb1 20, sin 24, op[k] at 28 + 20 k
 * (phase, freq, gain, dgain, shift). The operators' state stays in a->op (loaded and stored as the loop goes), R5 / R6
 * fb0 / fb1, R7 the phase offset (the sum, then the operator before's output << 18). 12 packets an operator. */
	.align 4
	.global _fm_op_compute_fb
	.type _fm_op_compute_fb, STT_FUNC
_fm_op_compute_fb:
	[--SP] = (R7:4, P5:3);
	P0 = R0;
	P1 = [P0 + 0];
	P3 = [P0 + 4];
	R4 = [P0 + 8];
	R5 = [P0 + 16];
	R6 = [P0 + 20];
	P5 = [P0 + 24];
	P4 = 64;
	LSETUP (.L7s, .L7e) LC1 = P4;
.L7s:	R7 = R5 + R6 (NS);
	R7 = LSHIFT R7 BY R4.L;
	P4 = P0;
	LSETUP (.L8s, .L8e) LC0 = P3;
.L8s:	R0 = [P4 + 28];
	R3 = R0 + R7 (NS) || R1 = [P4 + 32];
	R3 = R3 >> 20 || R2 = [P4 + 36];
	P2 = R3;
	R0 = R0 + R1 (NS) || R1 = [P4 + 40];
	R2 = R2 + R1 (NS) || [P4 + 28] = R0;
	P2 = P5 + (P2 << 1);
	R0 = W [P2] (X);
	R0 = R0.L * R2.H (IS) || R1 = [P4 + 44];
	R0 = ASHIFT R0 BY R1.L || [P4 + 36] = R2;
	R7 = R0 << 18;
.L8e:	P4 += 20;
	R5 = R6;
	R6 = R0;
.L7e:	[P1++] = R0;
	[P0 + 16] = R5;
	[P0 + 20] = R6;
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _fm_op_compute_fb, .-_fm_op_compute_fb

/* dx_out_block(short *out = R0, const int *in = R1, int old = R2, int step, int prev): y = ((x * 7 >> 5) *
 * (old >> 9)) >> 15 clamped to +-0x4000, out[2i] = (prev + y) >> 1, out[2i + 1] = y. A sample's two stores go with
 * the next sample's first packets; the outputs take turns in R6 / R7 (sample 0 and 63 outside the loop). R1 x (the
 * next one loaded early: in[64] is read), R2 old, R3 step, R4 / R5 the clamp, R0 work. 11 packets a sample. */
.macro OUTS yp, yn, st, end
.ifnb \st
	R2 = R2 + R3 (NS) || W [P1++] = R0 || NOP;
	R0 = R1 << 3 || W [P1++] = \yp || NOP;
.else
	R2 = R2 + R3 (NS);
	R0 = R1 << 3;
.endif
	R0 = R0 - R1 (NS);
	R1 = R2 >>> 9;
	R0 = R0 >>> 5;
	R0 *= R1;
	R0 = R0 >>> 15 || R1 = [P0++] || NOP;
	R0 = MAX (R0, R4);
	\yn = MIN (R0, R5);
	R0 = \yp + \yn (NS);
.ifnb \end
\end:
.endif
	R0 = R0 >>> 1;
.endm
	.align 4
	.global _dx_out_block
	.type _dx_out_block, STT_FUNC
_dx_out_block:
	[--SP] = (R7:4);
	P1 = R0;
	P0 = R1;
	R3 = [SP + 28];
	R6 = [SP + 32];
	R4 = -0x4000 (X);
	R5 = 0x4000 (Z);
	P2 = 31;
	R1 = [P0++];
	OUTS R6, R7
	LSETUP (.L9s, .L9e) LC0 = P2;
.L9s:	OUTS R7, R6, 1
	OUTS R6, R7, 1, .L9e
	OUTS R7, R6, 1
	W [P1++] = R0;
	W [P1++] = R6;
	R0 = R6;
	(R7:4) = [SP++];
	RTS;
	.size _dx_out_block, .-_dx_out_block

#endif
