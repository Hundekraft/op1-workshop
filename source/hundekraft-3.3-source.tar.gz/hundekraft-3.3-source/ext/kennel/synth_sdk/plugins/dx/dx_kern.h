/* dx: the FM kernels (dx_kern.c in C, dx_kasm.S for the Blackfin, bit for bit the same: test/kern_check.py).
 * DX_KERN_ASM: the Blackfin build takes dx_kasm.S; a host build, or DX_KERN_C (kern_check's reference), the C.
 * Included by dx_kern.c and dx_kasm.S. Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1
 * firmware permission (see LICENSE and NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well. */
#ifndef DX_KERN_H
#define DX_KERN_H

#if defined(__bfin__) && !defined(DX_KERN_C)
#define DX_KERN_ASM 1
#endif

#ifndef __ASSEMBLER__
/* One operator with its own feedback (the algorithm's feedback operator, alone): phase 0 + ((fb[0] + fb[1]) << fs). */
struct fm_fb1_args {
    int *out;               /* 0x00 */
    int *fb;                /* 0x04 fb[0], fb[1]: read and written */
    int phase;              /* 0x08 */
    int freq;               /* 0x0c */
    int gain;               /* 0x10 scaled as fm_args' */
    int dgain;              /* 0x14 */
    int shift;              /* 0x18 */
    const short *sin;       /* 0x1c */
    int fs;                 /* 0x20 the feedback's shift (17 - fb_shift) */
};

/* struct fm_args, struct fm_fb_args: dx.h */
struct fm_args;
struct fm_fb_args;
void fm_op_compute(const struct fm_args *a, int flags);   /* flags bit 1 an input (phase modulation), bit 0 add */
void fm_op_compute_fb(struct fm_fb_args *a);
void fm_op_compute_fb1(struct fm_fb1_args *a, int add);
/* The voice's 64 FM samples to its 128 output samples (88.2 kHz: each one, and the mean with the one before),
 * gain ramping by step from old; returns the last sample. */
int dx_out_block(short *out, const int *in, int old, int step, int prev);
#endif

#endif
