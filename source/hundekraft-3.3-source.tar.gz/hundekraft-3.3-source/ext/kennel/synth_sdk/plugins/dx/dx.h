/* dx: a voice player for DX7 voices. Ported 1:1 from another creator's plugin with the author's permission (per the owner,
 * 2026-11-14; PROVENANCE.md). The FM follows Google's Music Synthesizer for Android (MSFA, Copyright 2012 Google Inc.,
 * Apache License 2.0; NOTICE). Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission (see LICENSE and NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well. */
#ifndef DX_H
#define DX_H

#ifndef OP1_HOST
#define VOICE_ACTIVE(i) (*(volatile const unsigned char *)(0xFF80105C + (i)))   /* R246's voice i has a key down */
#define VOICE_VELOCITY(i) (*(volatile const short *)(0xFF801064 + 2 * (i)))     /* its velocity, 8.8 (OP1_VOICE_VEL) */
#else                                      /* a host build (golden.py's screen harness): op1_host.h's velocities */
#include "op1_plugin.h"
#define VOICE_ACTIVE(i) (OP1_VOICE_VEL[i] != 0)
#define VOICE_VELOCITY(i) (OP1_VOICE_VEL[i])
#endif

/* One MSFA envelope (Env), 0x20 bytes. */
struct env {
    int level;
    int target;
    int inc;
    unsigned char ix, rising, down, pad;
    unsigned char rates[4];
    unsigned char levels[4];
    int outlevel;
    int rate_scaling;
};

/* One operator's FM parameters, 16 bytes. */
struct fmop {
    int phase;
    int freq;
    int gain_in;
    int gain_out;
};

/* A voice's state (0x184 bytes: Dx7Note, the amplitude envelope, the flags). */
struct voice {
    struct env env[6];                     /* 0x000 */
    struct fmop op[6];                     /* 0x0c0 */
    int pe_level, pe_target, pe_inc;       /* 0x120 the pitch envelope */
    unsigned char pe_ix, pe_rising, pe_down, pe_pad;   /* 0x12c */
    unsigned char pe_rates[4];             /* 0x130 */
    unsigned char pe_levels[4];            /* 0x134 */
    int basepitch[6];                      /* 0x138 */
    int fb[2];                             /* 0x150 */
    unsigned char fixmode[6];               /* 0x158 */
    unsigned char ampmodsens[6];           /* 0x15e */
    unsigned char algorithm;               /* 0x164 */
    unsigned char fb_shift;                /* 0x165 */
    unsigned char pitchmodsens;            /* 0x166 */
    unsigned char opmask;                  /* 0x167 */
    int pitchmoddepth;                     /* 0x168 */
    int ampmoddepth;                       /* 0x16c */
    int last_out;                          /* 0x170 the last output sample */
    int amp_level;                         /* 0x174 the amplitude envelope's level */
    int amp_gain;                          /* 0x178 its gain now */
    short hold;                            /* 0x17c the hold counter */
    unsigned char stage;                   /* 0x17e */
    volatile unsigned char first;          /* 0x17f a note starts */
    volatile unsigned char releasing;      /* 0x180 */
    unsigned char index;                   /* 0x181 the voice's number */
};

struct lfo {
    int phase;
    int delta;
    int delay_state;
    int delay_inc1;
    int delay_inc2;
    unsigned char wave;
    unsigned char sync;
    unsigned char sh_rand;
    unsigned char pad;
};

/* The kept sound (182 bytes saved with the sound): flags (1 edited patch kept, 2 own amplitude envelope), name, the amplitude
 * envelope, an unpacked 156-byte patch. */
struct sound {
    unsigned char kind;
    unsigned char flags;
    char name[16];
    unsigned char amp[8];                  /* attack, decay, sustain, release, peak, hold */
    unsigned char patch[156];
};

struct bank {
    unsigned short id;
    unsigned char count;
    char name[14];
    unsigned char voices[32][128];
};

struct fm_args {
    int *out;
    const int *in;
    int phase;
    int freq;
    int gain;
    int dgain;
    int shift;
    const short *sin;
};

struct fm_fb_op {
    int phase, freq, gain, dgain, shift;
};
struct fm_fb_args {
    int *out;
    int n;
    int shift;
    int pad;
    int fb0, fb1;
    const short *sin;
    struct fm_fb_op op[3];
};

/* ---- the host side (dx_glue.c on the OP-1; the oracle guest has its own) ---- */
#define DX_BANK_DIR "/yaffs2/user/dx"
#define DX_SOUND_BYTES 0xb6
int dx_data_get(void *buf, int max);       /* the current sound's kept data: its length (0: none) */
int dx_data_set(const void *buf, int n);   /* keep it in the sound (0 bytes: remove); 1 done */
int dx_sound_name(char *buf, int max);     /* the current sound's name */
const short *dx_sin_fast(void);            /* this block's L1 copy of the sine table, or 0 */
void *dx_dir_open(const char *path);
const char *dx_dir_next(void *dir);        /* the next entry's name, or 0 */
void dx_dir_close(void *dir);
int dx_file_read(const char *path, void *buf, int max);   /* bytes read, or -1 */

/* dx.c */
void dx_voice_init(struct voice *v, int index);
void dx_note_on(struct voice *v);
void dx_render(struct voice *v, short *out, const short *par, const unsigned *pitch);
void dx_release(struct voice *v);
int dx_finished(struct voice *v);
void dx_block(void);
void dx_sync_data(void);
void dx_start(void);
void voice_get_patch(int bank, int index, unsigned char *patch);
int voice_count_total(void);
int voice_number_from_bank(int bank, int index);
void voice_number_to_bank(int number, int *bank, int *index);
void current_patch_get(int bank, int index, unsigned char *patch);
int sound_name_get(char *buf, int max);
int sound_name_differs(void);
int sound_name_matches(void);
void patch_param_set(int bank, int index, int param, int value);
void amp_env_param_set(int param, int value);
void sound_data_reset(void);
int amp_peak_gain(int v);
int amp_hold_page_lookup(int v);
void lfo_state_get(int *sample, int *delay);
extern struct sound sound_data;
extern struct voice *last_note_voice;
extern int loaded_voice_index, loaded_voice_bank;
extern const unsigned char default_amp_env[8];

/* dx_bank.c */
int bank_count(void);
int bank_id(int i);
int bank_voice_count(int i);
int bank_index_of_id(int id);
const char *bank_name_of_id(int id);
const unsigned char *bank_voice_ptr(int id, int voice);
void bank_scan(void);                     /* reads DX_BANK_DIR (main loop / UI thread) */

/* dx_msfa.c */
int msfa_exp2_lookup(int x);
int msfa_log2_lookup(int x);
int msfa_freq_lookup(int x);
void msfa_env_advance(struct env *e, int newix);
void msfa_note_init(struct voice *v, const unsigned char *patch, int midinote, int velocity);
int note_is_silent(const struct voice *v);
void msfa_note_keyup(struct voice *v);
void msfa_note_compute(struct voice *v, int *buf, int base_pitch, int lfo_val, int lfo_delay, int *scratch);
void msfa_lfo_reset(struct lfo *l, const unsigned char *patch);
void msfa_lfo_keydown(struct lfo *l);
int msfa_lfo_getsample(struct lfo *l);
int msfa_lfo_getdelay(struct lfo *l);
void patch_pack(const unsigned char *patch, unsigned char *packed);
void patch_unpack(const unsigned char *packed, unsigned char *patch);
void sin_table_use(const short *p);
void sin_table_install(short *dst);
void fm_op_compute_scaled(int *out, const int *in, int phase, int freq, int gain1, int gain2, int flags);
void fm_op_compute(const struct fm_args *a, int flags);
void fm_op_compute_fb(struct fm_fb_args *a);
void *memcpy_bytes(void *dst, const void *src, unsigned n);

/* dx_page.c */
int stroke_text_width(const char *s, int scale);
void stroke_text_draw(int x, int y, int scale, int colour, const char *s);
void stroke_text_draw_right(int x, int y, int scale, int colour, const char *s);
void engine_page_t1(void);
void engine_page_t2(void);
void engine_page_t4(void);
int engine_turn(int encoder, int detents, int page);
int engine_key(int key, int pressed, int page);

#endif
