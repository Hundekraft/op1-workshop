/* dx: the FM kernels in C (the host build's, and test/kern_check.py's reference for dx_kasm.S). The FM follows
 * Google's Music Synthesizer for Android (MSFA, Copyright 2012 Google Inc., Apache License 2.0; NOTICE); ported 1:1
 * from another creator's plugin with the author's permission (per the owner, 2026-11-14; PROVENANCE.md).
 * Kennel port Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and
 * NOTICE); the MSFA-derived parts stay under the Apache License 2.0 as well. */
#include "dx.h"
#include "dx_kern.h"

#ifndef DX_KERN_ASM

/* One operator's 64 samples: flags bit 1 an input (phase modulation), bit 0 add. */
void fm_op_compute(const struct fm_args *a, int flags)
{
    int *out = a->out;
    const int *in = a->in;
    int phase = a->phase, gain = a->gain, i;
    for (i = 0; i < 64; i++) {
        unsigned ph = phase;
        int y;
        if (flags & 2)
            ph += (unsigned)*in++ << 18;
        gain += a->dgain;
        y = (a->sin[ph >> 20] * (short)(gain >> 16)) >> -a->shift;
        if (flags & 1)
            y += out[i];
        out[i] = y;
        phase += a->freq;
    }
}

/* A feedback loop of a->n operators (algorithms 4 and 6). */
void fm_op_compute_fb(struct fm_fb_args *a)
{
    int *out = a->out;
    int fb0 = a->fb0, fb1 = a->fb1, i, k, y = 0;
    for (i = 0; i < 64; i++) {
        unsigned ph = (unsigned)(fb0 + fb1) << a->shift;
        for (k = 0; k < a->n; k++) {
            struct fm_fb_op *o = &a->op[k];
            unsigned idx = (o->phase + ph) >> 20;
            o->phase += o->freq;
            o->gain += o->dgain;
            y = (a->sin[idx] * (short)(o->gain >> 16)) >> -o->shift;
            ph = y << 18;
        }
        fb0 = fb1;
        fb1 = y;
        out[i] = y;
    }
    a->fb0 = fb0;
    a->fb1 = fb1;
}

/* The algorithm's feedback operator on its own (msfa_note_compute's loop, the gain scaled as fm_op_compute's). */
void fm_op_compute_fb1(struct fm_fb1_args *a, int add)
{
    int *p = a->out;
    int fb0 = a->fb[0], fb1 = a->fb[1], g = a->gain, k;
    unsigned ph = a->phase;
    for (k = 0; k < 64; k++) {
        int y;
        unsigned x = ((unsigned)(fb0 + fb1) << a->fs) + ph;
        g += a->dgain;
        y = (a->sin[x >> 20] * (short)(g >> 16)) >> -a->shift;
        fb0 = fb1;
        fb1 = y;
        *p = add ? *p + y : y;
        p++;
        ph += a->freq;
    }
    a->fb[0] = fb0;
    a->fb[1] = fb1;
}

int dx_out_block(short *out, const int *s, int old, int step, int prev)
{
    int i;
    for (i = 0; i < 64; i++) {
        int x = *s++;
        int y;
        old += step;
        y = (((x * 7) >> 5) * (old >> 9)) >> 15;
        if (y < -0x4000)
            y = -0x4000;
        if (y > 0x4000)
            y = 0x4000;
        out[2 * i] = (prev + y) >> 1;
        out[2 * i + 1] = y;
        prev = y;
    }
    return prev;
}

#endif
