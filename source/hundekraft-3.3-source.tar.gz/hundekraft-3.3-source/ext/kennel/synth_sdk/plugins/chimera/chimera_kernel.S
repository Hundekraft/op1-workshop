/* chimera's Kelly-Lochbaum lattice on Blackfin: chimera_dsp.h's ch_lattice_c, bit for bit (chimera_kern_cmp.py runs
 * both on bcore over random states; the demo renders compare the whole engine with the host's C).
 *
 * int16_t ch_lattice_asm(int16_t *R, int16_t *L, const int16_t *k, int16_t rp, int n)
 *   R0 = &R[a], R1 = &L[a], R2 = &k[a], [SP + 12] rp (old R[a - 1]), [SP + 16] n = b - a >= 1.
 *   For i = a .. b - 1: w = k[i] (R[i-1] + L[i]) (fractional, T); R[i] = R[i-1] - w; L[i-1] = L[i] + w, all saturating,
 *   R[i-1] the value before this step. Returns old R[b - 1]. Reads L[b], R / k one past the end (harmless: the
 *   neighbouring fields), writes only R[a .. b-1] and L[a-1 .. b-2].
 *
 * Three packets a section (the C took seven): X = (L[i] : R[i-1]) is loaded into a register's halves, then
 *   S.L = X.L + X.H (S);  W = (S k : S k) (T, both MACs);  Y = X +|- W (S) -> Y.H = L'[i-1], Y.L = R'[i]
 * with the next section's loads and the previous section's two 16-bit stores in the parallel slots. Two register
 * sets alternate (X R4 / R7, k R5 / R2, Y R0 / R1), so the loop body is two sections; the first section is peeled and an
 * odd last one follows the loop. Pointers: I0 L reads, I3 R reads, I1 k reads, P0 R writes, I2 L writes (one behind).
 * M registers are not touched (amp.c keeps a frame pointer in M1). L0..L3 are set to 0 (linear addressing).
 * Host builds assemble it empty: chimera_dsp.h runs ch_lattice_c there.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#ifdef __bfin__
	.text
	.align 4
	.global _ch_lattice_asm;
	.type _ch_lattice_asm, STT_FUNC;
_ch_lattice_asm:
	[--SP] = (R7:4);
	[--SP] = RETS;
	R3 = [SP + 32];                 /* rp (20 bytes of saved registers + 12) */
	P2 = [SP + 36];                 /* n */
	L0 = 0; L1 = 0; L2 = 0; L3 = 0;
	CALL .Lch_core;
	RETS = [SP++];
	(R7:4) = [SP++];
	RTS;
	.size _ch_lattice_asm, .-_ch_lattice_asm

/* the core, register interface (no stack): R0 &R[a], R1 &L[a], R2 &k[a], R3 rp, P2 n >= 1, L0..L3 = 0.
 * Returns old R[b-1] in R0 (sign-extended). Clobbers R0..R7, P0..P2, I0..I3, LC0 / LT0 / LB0. */
.Lch_core:
	I3 = R0;                        /* R reads from R[a] */
	P0 = R0;                        /* R writes from R[a] */
	I0 = R1;                        /* L reads from L[a] */
	R1 += -2;
	I2 = R1;                        /* L writes from L[a - 1] */
	I1 = R2;                        /* k from k[a] */
	/* ---- section a (set A), peeled: X = R4 = (L[a] : rp), k = R5 ---- */
	R4 = R3;
	R4.H = W[I0++];                 /* L[a] */
	R5.L = W[I1++];                 /* k[a] */
	R3.L = R4.L + R4.H (S) || R7.H = W[I0++];                       /* L[a+1] */
	R6.H = R3.L * R5.L, R6.L = R3.L * R5.L (T) || R7.L = W[I3++] || R2.L = W[I1++];   /* R[a] old, k[a+1] */
	R0 = R4 +|- R6 (S);             /* Y_a: (L'[a-1] : R'[a]) */
	P2 += -1;                       /* sections after the first */
	P1 = P2 >> 1;                   /* pairs */
	CC = P1 == 0;
	IF CC JUMP .Lch_nopairs;
	LSETUP(.Lch_s, .Lch_e) LC0 = P1;
.Lch_s:
	/* set B: X = R7, k = R2, Y -> R1; stores the previous Y (R0) */
	R3.L = R7.L + R7.H (S) || W[P0++] = R0 || R4.H = W[I0++];
	R6.H = R3.L * R2.L, R6.L = R3.L * R2.L (T) || R4.L = W[I3++] || R5.L = W[I1++];
	R1 = R7 +|- R6 (S) || W[I2++] = R0.H;
	/* set A: X = R4, k = R5, Y -> R0; stores the previous Y (R1) */
	R3.L = R4.L + R4.H (S) || W[P0++] = R1 || R7.H = W[I0++];
	R6.H = R3.L * R5.L, R6.L = R3.L * R5.L (T) || R7.L = W[I3++] || R2.L = W[I1++];
.Lch_e:
	R0 = R4 +|- R6 (S) || W[I2++] = R1.H;
.Lch_nopairs:
	R3 = P2;                        /* not R2: it holds k for an odd last section */
	CC = BITTST(R3, 0);
	IF CC JUMP .Lch_odd;
	/* the last Y is R0, the next rp R7.L */
	W[P0] = R0;
	W[I2] = R0.H;
	R0 = R7.L (X);
	RTS;
.Lch_odd:
	/* one more section (set B), then the last Y is R1, the next rp R4.L */
	R3.L = R7.L + R7.H (S) || W[P0++] = R0 || R4.H = W[I0++];
	R6.H = R3.L * R2.L, R6.L = R3.L * R2.L (T) || R4.L = W[I3++] || R5.L = W[I1++];
	R1 = R7 +|- R6 (S) || W[I2++] = R0.H;
	W[P0] = R1;
	W[I2] = R1.H;
	R0 = R4.L (X);
	RTS;

/* ---- pass 2 of chimera_dsp.h's ch_tract_body: the tract for the block's 64 samples (ch_tract_pass_c, bit for bit) ----
 * void ch_tract_pass_asm(ch_pass_t *x): per sample s, with rec[s] = { src, rg, fz, y }:
 *   rp = R[0]; R[0] = add(mul(L[0], rg), src); rp = lattice 1 .. n-1 (with the velum's three-port junction and the
 *   nose when x->nose), lip += mul(LIPA, sub(rp, lip)); L[n-1] = mul(lip, rl); R[im] += fz; L[im-1] -= fz;
 *   rec[s].y = R[n-1] (+ nR[NN-1] >> 1 with the nose).
 * The lattice runs in .Lch_core (no call frame); P5 = x, P4 = rec, P3 = x->R, LC1 the samples. */
	.align 4
	.global _ch_tract_pass_asm;
	.type _ch_tract_pass_asm, STT_FUNC;
_ch_tract_pass_asm:
	[--SP] = (R7:4, P5:3);
	[--SP] = RETS;
	L0 = 0; L1 = 0; L2 = 0; L3 = 0;
	P5 = R0;
	P4 = [P5 + 12];                 /* rec */
	P3 = [P5 + 0];                  /* R */
	P1 = 64;
	LSETUP(.Lps_s, .Lps_e) LC1 = P1;
.Lps_s:
	R1 = W[P4] (X);                 /* src */
	R2 = W[P4 + 2] (X);             /* rg */
	P1 = [P5 + 4];                  /* L */
	R3 = W[P3] (X);                 /* rp = old R[0] */
	R0 = W[P1] (X);
	R0.L = R0.L * R2.L (T);
	R0.L = R0.L + R1.L (S);
	W[P3] = R0;
	R0 = P3;
	R0 += 2;                        /* &R[1] */
	R1 = P1;
	R1 += 2;                        /* &L[1] */
	R2 = [P5 + 8];
	R2 += 2;                        /* &k[1] */
	P2 = [P5 + 16];                 /* sections before the velum (v - 1), or n - 1 without the nose */
	CALL .Lch_core;
	R1 = [P5 + 48];
	CC = R1 == 0;
	IF CC JUMP .Lps_lip;
	/* ---- the velum's three-port junction (rp1 = R0), the nose, the mouth's rest ---- */
	P0 = [P5 + 52];                 /* &R[v] */
	P1 = [P5 + 56];                 /* &L[v] */
	P2 = [P5 + 60];                 /* nL */
	R7 = W[P0] (X);                 /* ri = old R[v] */
	[P5 + 80] = R7;
	R1 = W[P1] (X);                 /* li */
	R2 = W[P2] (X);                 /* ni = nL[0] */
	R3 = [P5 + 64];                 /* g0 | g1 << 16 */
	R4 = [P5 + 68];                 /* g2 */
	R6 = R0.L * R3.L (IS);
	R5 = R1.L * R3.H (IS);
	R6 = R6 + R5;
	R5 = R2.L * R4.L (IS);
	R6 = R6 + R5;
	R6 >>>= 13;                     /* p */
	R4 = -32768 (X);
	R5 = 32767 (X);
	R3 = R6 - R1;                   /* R[v] = s16(p - li) */
	R3 = MAX(R3, R4);
	R3 = MIN(R3, R5);
	W[P0] = R3;
	R3 = R6 - R0;                   /* L[v-1] = s16(p - rp1) */
	R3 = MAX(R3, R4);
	R3 = MIN(R3, R5);
	W[P1 + -2] = R3;
	P0 = [P5 + 84];                 /* nR */
	R3 = R6 - R2;                   /* nR[0] = s16(p - ni) */
	R3 = MAX(R3, R4);
	R3 = MIN(R3, R5);
	R7 = W[P0] (X);                 /* nrp = old nR[0] */
	W[P0] = R3;
	R0 = P0;
	R0 += 2;
	R1 = P2;
	R1 += 2;
	R2 = [P5 + 76];
	R2 += 2;                        /* &nose_k[1] */
	R3 = R7;
	P2 = 7;                         /* CH_NN - 1 */
	CALL .Lch_core;
	R1 = W[P5 + 72] (X);            /* nlip */
	R2.L = R0.L - R1.L (S);
	R3 = 14746 (X);                 /* CH_LIPA */
	R2.L = R3.L * R2.L (T);
	R1.L = R1.L + R2.L (S);
	W[P5 + 72] = R1;
	R3 = -19661 (X);                /* CH_RN */
	R1.L = R1.L * R3.L (T);
	P2 = [P5 + 60];
	W[P2 + 14] = R1;                /* nL[CH_NN - 1] */
	P0 = [P5 + 52];
	R0 = P0;
	R0 += 2;                        /* &R[v+1] */
	P1 = [P5 + 56];
	R1 = P1;
	R1 += 2;                        /* &L[v+1] */
	R2 = [P5 + 88];                 /* &k[v+1] */
	R3 = [P5 + 80];                 /* ri */
	P2 = [P5 + 92];                 /* n - 1 - v */
	CALL .Lch_core;
.Lps_lip:
	R1 = W[P5 + 36] (X);            /* lip */
	R2.L = R0.L - R1.L (S);
	R3 = 14746 (X);                 /* CH_LIPA */
	R2.L = R3.L * R2.L (T);
	R1.L = R1.L + R2.L (S);
	W[P5 + 36] = R1;
	R3 = W[P5 + 40] (X);            /* rl */
	R1.L = R1.L * R3.L (T);
	P1 = [P5 + 24];                 /* &L[n-1] */
	W[P1] = R1;
	R0 = W[P4 + 4] (X);             /* fz (0 without frication: adding 0 changes nothing) */
	P0 = [P5 + 28];                 /* &R[im] */
	P1 = [P5 + 32];                 /* &L[im-1] */
	R1 = W[P0] (X);
	R1.L = R1.L + R0.L (S);
	W[P0] = R1;
	R1 = W[P1] (X);
	R1.L = R1.L - R0.L (S);
	W[P1] = R1;
	P0 = [P5 + 20];                 /* &R[n-1] */
	R0 = W[P0] (X);
	R1 = [P5 + 48];
	CC = R1 == 0;
	IF CC JUMP .Lps_y;
	P2 = [P5 + 84];
	R1 = W[P2 + 14] (X);            /* nR[CH_NN - 1] */
	R1 >>>= 1;
	R0.L = R0.L + R1.L (S);
.Lps_y:
	W[P4 + 6] = R0;
.Lps_e:
	P4 += 8;
	RETS = [SP++];
	(R7:4, P5:3) = [SP++];
	RTS;
	.size _ch_tract_pass_asm, .-_ch_tract_pass_asm

/* ---- the whole block: chimera_dsp.h's ch_block_c, bit for bit ----
 * void ch_block_asm(ch_blk_t *x): per tract sample, the glottis (phase, a new period's jitter / shimmer / fry, the pulse
 * or the sine, xorshift noise, aspiration), R[0], the lattice (.Lch_core; with the nose: the three-port junction, the
 * nose, the rest of the mouth), the lip reflection, frication, gain / envelope / peak and the 2x doubling.
 * Registers kept over .Lch_core: P5 = x, P4 = out, P3 = x->R, B0 = this sample's noise; LC1 counts the samples.
 * ch_blk_t offsets: see chimera_dsp.h (the static assert there keeps them). */
	.align 4
	.global _ch_block_asm;
	.type _ch_block_asm, STT_FUNC;
_ch_block_asm:
	[--SP] = (R7:4, P5:3);
	[--SP] = RETS;
	L0 = 0; L1 = 0; L2 = 0; L3 = 0;
	P5 = R0;
	P4 = [P5 + 12];                 /* out */
	P3 = [P5 + 0];                  /* R */
	P1 = 64;
	LSETUP(.Lbk_s, .Lbk_e) LC1 = P1;
.Lbk_s:
	/* ---- glottis ---- */
	R0 = [P5 + 96];                 /* ph */
	R1 = [P5 + 100];                /* step */
	R2 = R0 + R1;                   /* nph */
	CC = R2 < R0 (IU);
	IF CC JUMP .Lbk_period;
.Lbk_post:
	[P5 + 96] = R2;
	R3 = [P5 + 108];                /* iq */
	R4 = R2 >> 16;
	R4 = R4.L * R3.L (FU);
	R4 >>= 17;                      /* idx */
	R5 = [P5 + 148];
	CC = R5 == 0;
	IF !CC JUMP .Lbk_sine;
	R5 = 0;
	R6 = 255;
	CC = R4 <= R6 (IU);
	IF !CC JUMP .Lbk_g;
	P0 = [P5 + 192];                /* glot */
	P1 = R4;
	P0 = P0 + (P1 << 1);
	R5 = W[P0] (X);
	JUMP.S .Lbk_g;
.Lbk_sine:
	P0 = [P5 + 188];                /* sine table */
	R5 = R2 >> 19;
	P1 = R5;
	P0 = P0 + (P1 << 1);
	R5 = W[P0] (X);
	R6 = R5 >>> 3;
	R5 = R5 - R6;                   /* g = v - v / 8 */
.Lbk_g:
	R0 = [P5 + 104];                /* rng: xorshift */
	R1 = R0 << 13;
	R0 = R0 ^ R1;
	R1 = R0 >> 17;
	R0 = R0 ^ R1;
	R1 = R0 << 5;
	R0 = R0 ^ R1;
	[P5 + 104] = R0;
	R6 = R0 >>> 16;                 /* nz */
	B0 = R6;
	R1 = [P5 + 128];                /* gamp16 */
	R5.L = R5.L * R1.L (T);
	R5 = R5.L (X);
	R5 >>>= 4;
	R3 = 255;
	CC = R4 <= R3 (IU);             /* the open phase */
	R1 = [P5 + 136];                /* asp_c */
	R0 = [P5 + 132];                /* asp_o */
	IF CC R1 = R0;
	R7 = 24576 (X);                 /* CH_RG */
	R0 = 16384 (X);                 /* CH_RGO */
	IF CC R7 = R0;
	R1.L = R6.L * R1.L (T);
	R1 = R1.L (X);
	R1 >>>= 3;
	R5.L = R5.L + R1.L (S);         /* src */
	/* ---- tract ---- */
	P1 = [P5 + 4];                  /* L */
	R3 = W[P3] (X);                 /* rp = old R[0] */
	R0 = W[P1] (X);
	R0.L = R0.L * R7.L (T);
	R0.L = R0.L + R5.L (S);
	W[P3] = R0;
	R0 = P3;
	R0 += 2;
	R1 = P1;
	R1 += 2;
	R2 = [P5 + 8];
	R2 += 2;
	P2 = [P5 + 16];
	CALL .Lch_core;
	R1 = [P5 + 48];
	CC = R1 == 0;
	IF CC JUMP .Lbk_lip;
	/* the velum's three-port junction (rp1 = R0), the nose, the mouth's rest */
	P0 = [P5 + 52];                 /* &R[v] */
	P1 = [P5 + 56];                 /* &L[v] */
	P2 = [P5 + 60];                 /* nL */
	R7 = W[P0] (X);                 /* ri */
	[P5 + 80] = R7;
	R1 = W[P1] (X);                 /* li */
	R2 = W[P2] (X);                 /* ni */
	R3 = [P5 + 64];                 /* g0 | g1 << 16 */
	R4 = [P5 + 68];                 /* g2 */
	R6 = R0.L * R3.L (IS);
	R5 = R1.L * R3.H (IS);
	R6 = R6 + R5;
	R5 = R2.L * R4.L (IS);
	R6 = R6 + R5;
	R6 >>>= 13;                     /* p */
	R4 = -32768 (X);
	R5 = 32767 (X);
	R3 = R6 - R1;
	R3 = MAX(R3, R4);
	R3 = MIN(R3, R5);
	W[P0] = R3;                     /* R[v] */
	R3 = R6 - R0;
	R3 = MAX(R3, R4);
	R3 = MIN(R3, R5);
	W[P1 + -2] = R3;                /* L[v-1] */
	P0 = [P5 + 84];                 /* nR */
	R3 = R6 - R2;
	R3 = MAX(R3, R4);
	R3 = MIN(R3, R5);
	R7 = W[P0] (X);                 /* nrp */
	W[P0] = R3;                     /* nR[0] */
	R0 = P0;
	R0 += 2;
	R1 = P2;
	R1 += 2;
	R2 = [P5 + 76];
	R2 += 2;
	R3 = R7;
	P2 = 7;
	CALL .Lch_core;
	R1 = W[P5 + 72] (X);            /* nlip */
	R2.L = R0.L - R1.L (S);
	R3 = 14746 (X);
	R2.L = R3.L * R2.L (T);
	R1.L = R1.L + R2.L (S);
	W[P5 + 72] = R1;
	R3 = -19661 (X);
	R1.L = R1.L * R3.L (T);
	P2 = [P5 + 60];
	W[P2 + 14] = R1;                /* nL[7] */
	P0 = [P5 + 52];
	R0 = P0;
	R0 += 2;
	P1 = [P5 + 56];
	R1 = P1;
	R1 += 2;
	R2 = [P5 + 88];
	R3 = [P5 + 80];
	P2 = [P5 + 92];
	CALL .Lch_core;
.Lbk_lip:
	R1 = W[P5 + 36] (X);            /* lip */
	R2.L = R0.L - R1.L (S);
	R3 = 14746 (X);
	R2.L = R3.L * R2.L (T);
	R1.L = R1.L + R2.L (S);
	W[P5 + 36] = R1;
	R3 = W[P5 + 40] (X);            /* rl */
	R1.L = R1.L * R3.L (T);
	P1 = [P5 + 24];
	W[P1] = R1;                     /* L[n-1] */
	/* frication */
	R0 = 0;
	R1 = [P5 + 44];
	CC = R1 == 0;
	IF CC JUMP .Lbk_f;
	R6 = B0;
	R6 >>>= 2;                      /* nz >> 2 */
	R1 = [P5 + 144];                /* nlp */
	R1 = R1 + R6;
	R1 >>>= 1;
	R1 = R1.L (X);
	[P5 + 144] = R1;
	R0.L = R6.L - R1.L (S);
	R2 = [P5 + 140];                /* fric */
	R0.L = R0.L * R2.L (T);
.Lbk_f:
	P0 = [P5 + 28];
	P1 = [P5 + 32];
	R1 = W[P0] (X);
	R1.L = R1.L + R0.L (S);
	W[P0] = R1;
	R1 = W[P1] (X);
	R1.L = R1.L - R0.L (S);
	W[P1] = R1;
	P0 = [P5 + 20];
	R0 = W[P0] (X);                 /* y0 = R[n-1] */
	R1 = [P5 + 48];
	CC = R1 == 0;
	IF CC JUMP .Lbk_out;
	P2 = [P5 + 84];
	R1 = W[P2 + 14] (X);
	R1 >>>= 1;
	R0.L = R0.L + R1.L (S);
	R0 = R0.L (X);
.Lbk_out:
	/* gain, envelope, peak, doubling */
	R1 = [P5 + 152];                /* gv */
	R0 *= R1;
	R0 >>>= 12;
	R1 = [P5 + 160];                /* e */
	R2 = R1 >>> 3;
	R0 *= R2;
	R0 >>>= 12;
	R2 = [P5 + 156];                /* de */
	R1 = R1 + R2;
	[P5 + 160] = R1;
	R1 = 32767 (X);
	R0 = MIN(R0, R1);
	R1 = -32767 (X);
	R0 = MAX(R0, R1);
	R1 = ABS R0;
	R2 = [P5 + 164];
	R2 = MAX(R2, R1);
	[P5 + 164] = R2;
	R1 = [P5 + 168];                /* last */
	R1 = R1 + R0;
	R1 >>>= 1;
	W[P4++] = R1;
	W[P4++] = R0;
.Lbk_e:
	[P5 + 168] = R0;
	RETS = [SP++];
	(R7:4, P5:3) = [SP++];
	RTS;

/* a new glottal period (out of line; keeps R2 = nph): jitter, shimmer, fry, gamp, gamp16 and the step */
.Lbk_period:
	R0 = [P5 + 104];
	R1 = R0 << 13;
	R0 = R0 ^ R1;
	R1 = R0 >> 17;
	R0 = R0 ^ R1;
	R1 = R0 << 5;
	R0 = R0 ^ R1;
	[P5 + 104] = R0;
	R1 = R0 >> 20;
	R3 = 2048;
	R1 = R1 - R3;                   /* r */
	R3 = [P5 + 172];                /* jitter */
	R1 *= R3;
	R1 >>>= 11;
	R4 = 4096;
	R1 = R1 + R4;                   /* gfac */
	R5 = [P5 + 184];
	R6 = 1;
	R5 = R5 ^ R6;
	[P5 + 184] = R5;                /* odd */
	R6 = 2047;
	R6 = R0 & R6;
	R7 = 1024;
	R6 = R6 - R7;
	R6 *= R3;
	R6 >>>= 10;
	R6 = R6 + R4;                   /* a */
	R7 = [P5 + 176];                /* fry */
	CC = R5 == 0;
	IF CC JUMP .Lbk_nofry;
	CC = R7 == 0;
	IF CC JUMP .Lbk_nofry;
	R3 = R6;
	R3 *= R7;
	R3 >>>= 13;
	R6 = R6 - R3;
	R3 = R7 >>> 2;
	R1 = R1 - R3;
.Lbk_nofry:
	[P5 + 120] = R1;                /* gfac */
	R3 = [P5 + 180];                /* voice */
	R6 *= R3;
	R6 >>>= 12;
	[P5 + 124] = R6;                /* gamp */
	R3 = R6 << 2;
	R3 = R3.L (X);
	R7 = 32767 (X);
	R4 = 8191 (X);
	CC = R6 <= R4;
	IF CC R7 = R3;
	[P5 + 128] = R7;                /* gamp16 */
	R3 = [P5 + 112];                /* base */
	R4 = R3 >> 12;
	R5 = [P5 + 116];                /* dev */
	R5 = R5 + R1;
	R6 = 4096;
	R5 = R5 - R6;
	R4 *= R5;
	R3 = R3 + R4;
	[P5 + 100] = R3;                /* step */
	JUMP .Lbk_post;
	.size _ch_block_asm, .-_ch_block_asm
#endif
