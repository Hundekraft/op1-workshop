#!/usr/bin/env python3
"""Generate chimera.svg + chimera_geom.h: chimera's engine screen, still art (vector line art on black, OP-1 style).

    python3 gen_svg.py            (run from anywhere; writes next to this file)

The screen is a midsagittal cutaway of a head facing right (like CHIMERA's vector display): the fixed anatomy is here,
the moving parts (tongue, jaw, lips, velum, vocal folds, airflow, sound arcs) are drawn live by chimera_screen.h from
the articulators the audio side publishes. Anatomy is written in CHIMERA's template cm (x toward the face, y up; the
glottis at 0,0 and the pharynx's back wall at x = 0) and mapped to the screen by one uniform scale, so the code and
this file share every number (chimera_geom.h).

Groups (the code shows one at a time): g_head (PLAY / SING / SPEAK), g_beat (a smaller head and the 12 pads),
g_bird, g_trunk. Colours: lilac #DFD9FF outline, #AEB1DC inner anatomy, #6F7173 dim detail (the fmbell / stock lines).
Placement (screen-art.md "Placement and OLED bottom margin"): all still ink inside x 2..318, y 3..124; the labels take
y 127..137. main() refuses ink outside that.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
LIL, MID, DIM = '#DFD9FF', '#AEB1DC', '#6F7173'

# ---- anatomy, template cm ----
FACE_UP = [(6.4, 14.8), (7.2, 13.7), (8.0, 12.5), (8.8, 11.75), (9.05, 11.35), (8.65, 10.95), (8.38, 10.6), (8.35, 10.0)]
NECK_FRONT = [(3.3, 3.1), (2.95, 2.2), (2.75, 0.8), (2.65, -1.5), (2.6, -3.6)]
NECK_BACK = [(-2.5, -3.6), (-2.5, 0.0), (-2.7, 3.0), (-3.6, 5.2), (-4.5, 8.0), (-4.7, 11.0), (-4.2, 13.6), (-3.4, 14.8)]
BACK_WALL = [(0.0, -3.6), (0.0, 11.6)]
TRACHEA_FRONT = [(1.75, -3.6), (1.75, 0.9)]
EPIGLOTTIS = [(1.75, 0.9), (1.55, 1.6), (1.35, 2.5), (1.42, 3.2)]
THYROID = [(1.75, 2.6), (2.5, 2.1), (2.65, 1.0), (2.3, -0.1), (1.75, -0.3)]
NASAL_ROOF = [(8.35, 11.1), (7.3, 11.75), (5.6, 12.15), (3.4, 12.4), (1.4, 12.3), (0.0, 11.6)]
PALATE = [(7.0, 9.55), (6.4, 9.9), (5.4, 10.08), (4.2, 10.17), (3.3, 10.15), (2.8, 10.05)]
UPPER_TOOTH = [(6.95, 9.6), (7.45, 9.45), (7.55, 8.7), (7.2, 8.6), (7.0, 9.1)]
VERTEBRAE = [(-2.1, -0.9, y, y + 0.9) for y in (-3.0, -1.6, -0.2, 1.2, 2.6, 4.0, 5.4)]   # x0, x1, y0, y1
CRANIUM = [(-3.9, 14.0), (-1.5, 14.6), (1.5, 14.3), (4.2, 14.7)]                          # a hint of the brain's lower edge
BRAIN = [(-3.7, 10.0), (-2.2, 12.2), (0.4, 12.9), (3.0, 12.7), (5.0, 13.0)]
JAW_ANGLE = [(2.95, 2.2), (2.2, 3.4)]                                                     # hyoid hint

HEAD_FULL = dict(S=7.0, OX=130.0, OY=118.0, w=1.25)
HEAD_BEAT = dict(S=4.2, OX=72.0, OY=84.0, w=1.0)
PAD = dict(x0=146.0, y0=30.0, w=36.0, h=26.0, gx=6.0, gy=6.0)         # 4 x 3 pads, row 0 (bottom) = pads 0..3


def fmt(v):
    s = f'{v:.2f}'.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s


def cr(pts, closed=False):
    """Catmull-Rom through pts as an SVG path (M C ...), 2 decimals"""
    p = list(pts)
    n = len(p)
    d = f'M{fmt(p[0][0])},{fmt(p[0][1])}'
    for i in range(n - 1 if not closed else n):
        p0 = p[i - 1] if (i > 0 or closed) else p[0]
        p1 = p[i]
        p2 = p[(i + 1) % n]
        p3 = p[(i + 2) % n] if (i + 2 < n or closed) else p[-1]
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        d += f'C{fmt(c1[0])},{fmt(c1[1])} {fmt(c2[0])},{fmt(c2[1])} {fmt(p2[0])},{fmt(p2[1])}'
    return d + ('Z' if closed else '')


def poly(pts, closed=False):
    d = 'M' + ' L'.join(f'{fmt(x)},{fmt(y)}' for x, y in pts)
    return d + ('Z' if closed else '')


class Svg:
    def __init__(self):
        self.out = []
        self.ink = [1e9, 1e9, -1e9, -1e9]

    def note(self, pts, w=0.0):
        for x, y in pts:
            self.ink[0] = min(self.ink[0], x - w / 2); self.ink[1] = min(self.ink[1], y - w / 2)
            self.ink[2] = max(self.ink[2], x + w / 2); self.ink[3] = max(self.ink[3], y + w / 2)

    def path(self, d, col, w, pts, fill='none'):
        self.out.append(f'<path fill="{fill}" stroke="{col}" stroke-width="{fmt(w)}" stroke-linecap="round" '
                        f'stroke-linejoin="round" d="{d}"/>')
        self.note(pts, w)

    def line(self, a, b, col, w):
        self.out.append(f'<line fill="none" stroke="{col}" stroke-width="{fmt(w)}" stroke-linecap="round" '
                        f'x1="{fmt(a[0])}" y1="{fmt(a[1])}" x2="{fmt(b[0])}" y2="{fmt(b[1])}"/>')
        self.note([a, b], w)

    def circle(self, c, r, col, w, fill='none'):
        self.out.append(f'<circle fill="{fill}" stroke="{col}" stroke-width="{fmt(w)}" cx="{fmt(c[0])}" cy="{fmt(c[1])}" r="{fmt(r)}"/>')
        self.note([(c[0] - r, c[1] - r), (c[0] + r, c[1] + r)], w)

    def group(self, gid, items):
        return f'<g id="{gid}">\n' + '\n'.join(items) + '\n</g>'


def head(svg, S, OX, OY, w):
    """the still head at scale S px/cm, origin OX, OY (the glottis' x = 0, y = 0 of the template)"""
    ymin = -(122.8 - OY) / S                                 # the neck is cut here (labels below y 124)
    P = lambda pts: [(OX + S * x, OY - S * max(y, ymin)) for x, y in pts]
    items = []

    def add(d_pts, col, ww, smooth=True, closed=False):
        pts = P(d_pts)
        d = cr(pts, closed) if smooth else poly(pts, closed)
        svg.path(d, col, ww, pts)
        items.append(svg.out.pop())

    add(FACE_UP, LIL, w)
    add(NECK_FRONT, LIL, w)
    add(NECK_BACK, LIL, w)
    add(BACK_WALL, MID, w, smooth=False)
    add(TRACHEA_FRONT, MID, w, smooth=False)
    add(EPIGLOTTIS, MID, w * 0.9)
    add(THYROID, DIM, w * 0.9)
    add(NASAL_ROOF, DIM, w * 0.9)
    add(PALATE, MID, w * 1.1)
    add(UPPER_TOOTH, LIL, w * 0.9, smooth=False, closed=True)
    add(BRAIN, DIM, w * 0.8)
    add(JAW_ANGLE, DIM, w * 0.8, smooth=False)
    for x0, x1, y0, y1 in VERTEBRAE:                      # the spine behind the pharynx
        if y0 < ymin: continue
        add([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], DIM, w * 0.8, smooth=False, closed=True)
    for y in (-3.0, -2.2, -1.4):                          # tracheal rings
        if y < ymin: continue
        add([(0.0, y), (1.75, y)], DIM, w * 0.7, smooth=False)
    return items


def pads(svg):
    items = []
    for i in range(12):
        c, r = i % 4, i // 4
        x = PAD['x0'] + c * (PAD['w'] + PAD['gx'])
        y = PAD['y0'] + (2 - r) * (PAD['h'] + PAD['gy'])
        pts = [(x, y), (x + PAD['w'], y), (x + PAD['w'], y + PAD['h']), (x, y + PAD['h'])]
        svg.path(poly(pts, True), DIM, 1.0, pts)
        items.append(svg.out.pop())
    return items


def bird(svg):
    items = []

    def add(pts, col, w, smooth=True, closed=False):
        d = cr(pts, closed) if smooth else poly(pts, closed)
        svg.path(d, col, w, pts)
        items.append(svg.out.pop())
    add([(213, 46), (206, 37), (194, 33), (183, 39), (170, 52), (150, 70), (124, 92), (96, 108), (84, 116)], LIL, 1.25)   # head, back, tail top
    add([(84, 116), (96, 120), (124, 107), (150, 101), (172, 96), (190, 86), (203, 72), (210, 61)], LIL, 1.25)           # tail tip, belly, breast, throat
    add([(213, 46), (236, 52), (214, 53)], LIL, 1.25, smooth=False)                                                  # the upper beak
    add([(136, 76), (160, 80), (176, 92), (160, 96), (140, 88), (136, 76)], MID, 1.0)                                  # the wing
    add([(148, 84), (130, 98)], DIM, 0.9, smooth=False)
    add([(156, 88), (140, 106)], DIM, 0.9, smooth=False)
    add([(160, 100), (158, 109)], LIL, 1.1, smooth=False)
    add([(172, 97), (170, 108)], LIL, 1.1, smooth=False)
    add([(70, 112), (110, 110), (170, 109), (240, 104)], DIM, 1.5)                                                     # the branch
    add([(232, 103), (246, 96), (258, 98)], DIM, 1.2)
    svg.circle((201, 47), 2.4, '#FFFFFF', 1.0, '#FFFFFF')
    items.append(svg.out.pop())
    return items


def trunk(svg):
    items = []

    def add(pts, col, w, smooth=True, closed=False):
        d = cr(pts, closed) if smooth else poly(pts, closed)
        svg.path(d, col, w, pts)
        items.append(svg.out.pop())
    add([(207, 62), (205, 46), (196, 32), (178, 24), (158, 24), (142, 34)], LIL, 1.25)                 # the skull, forehead to crown
    add([(201, 84), (188, 98), (170, 108), (152, 108), (142, 98)], LIL, 1.25)                           # the cheek and jaw
    add([(142, 36), (124, 36), (110, 52), (106, 80), (114, 102), (130, 106), (144, 96)], MID, 1.25)         # the ear
    add([(128, 52), (118, 66), (118, 86), (128, 96)], DIM, 0.9)                                           # its fold
    add([(196, 86), (210, 97), (220, 108), (221, 118)], LIL, 1.1)                                          # the tusk
    add([(168, 50), (182, 48)], MID, 1.0, smooth=False)                                                    # the brow
    add([(160, 36), (172, 34)], DIM, 0.8, smooth=False)
    add([(164, 40), (178, 38)], DIM, 0.8, smooth=False)
    svg.circle((177, 56), 2.2, '#FFFFFF', 1.0, '#FFFFFF')
    items.append(svg.out.pop())
    return items


def geom_h(sections):
    out = ['/* chimera_geom.h: generated by gen_svg.py, do not edit. The still anatomy in CHIMERA template cm x 256. */',
           '#ifndef CHIMERA_GEOM_H', '#define CHIMERA_GEOM_H']
    for name, v in sections:
        if isinstance(v, list):
            flat = ', '.join(str(int(round(x * 256))) for pt in v for x in pt)
            out.append(f'static const int16_t CG_{name}[{2 * len(v)}] = {{ {flat} }};')
            out.append(f'#define CG_{name}_N {len(v)}')
        else:
            out.append(f'#define CG_{name} {v}')
    out.append('#endif')
    return '\n'.join(out) + '\n'


def main():
    svg = Svg()
    g_head = svg.group('g_head', head(svg, **HEAD_FULL))
    g_beat = svg.group('g_beat', head(svg, **HEAD_BEAT) + pads(svg))
    g_bird = svg.group('g_bird', bird(svg))
    g_trunk = svg.group('g_trunk', trunk(svg))
    x0, y0, x1, y1 = svg.ink
    bad = [f'ink {x0:.1f},{y0:.1f} .. {x1:.1f},{y1:.1f} outside x 2..318, y 3..124']
    if x0 >= 2 and y0 >= 3 and x1 <= 318 and y1 <= 124:
        bad = []
    if bad:
        raise SystemExit('gen_svg: ' + '; '.join(bad))
    doc = ('<?xml version="1.0" encoding="utf-8"?>\n<svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" '
           'width="320px" height="160px" viewBox="0 0 320 160">\n'
           '<!-- chimera: still anatomy (generated by gen_svg.py); the moving parts are drawn by chimera_screen.h -->\n'
           + '\n'.join([g_head, g_beat, g_bird, g_trunk]) + '\n</svg>\n')
    (HERE / 'chimera.svg').write_text(doc)
    q = lambda v: int(round(v * 1024))
    secs = [('PALATE', PALATE),
            ('FULL_S_Q8', int(round(HEAD_FULL['S'] * 256))), ('FULL_OX_Q10', q(HEAD_FULL['OX'])), ('FULL_OY_Q10', q(HEAD_FULL['OY'])),
            ('BEAT_S_Q8', int(round(HEAD_BEAT['S'] * 256))), ('BEAT_OX_Q10', q(HEAD_BEAT['OX'])), ('BEAT_OY_Q10', q(HEAD_BEAT['OY'])),
            ('PAD_X0', int(PAD['x0'])), ('PAD_Y0', int(PAD['y0'])), ('PAD_W', int(PAD['w'])), ('PAD_H', int(PAD['h'])),
            ('PAD_GX', int(PAD['gx'])), ('PAD_GY', int(PAD['gy']))]
    (HERE / 'chimera_geom.h').write_text(geom_h(secs))
    print(f'chimera.svg: {len(doc)} bytes, ink {x0:.1f},{y0:.1f} .. {x1:.1f},{y1:.1f}')


if __name__ == '__main__':
    main()
