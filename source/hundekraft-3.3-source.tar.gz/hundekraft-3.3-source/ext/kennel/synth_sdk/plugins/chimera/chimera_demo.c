/* chimera's demo renders and block costs, the same code on the host (-DOP1_HOST, cc) and bare metal on bcore
 * (chimera_bench.py: bfin-elf-gcc, tier2's crt.S / guest.ld). The engine as built for the OP-1 (chimera.c) renders voice
 * calls of 128 samples at 88.2 kHz with OP1_PITCH_INC in 88.2 kHz steps, as R246 calls it, six voices summed as R246
 * sums them. chimera shapes its own level (own_envelope), so no R246 envelope is involved; not modelled: R246's 2:1
 * decimator (demo_wavs.py uses a polyphase low-pass), its mixer and FX.
 *   CH_MODE_AUDIO: each demo as 88.2 kHz int16, hex on stdout: "WAV name\n" then lines of hex words, "END\n"
 *   CH_MODE_COST : CYCLES per block for 1, 2, 4 and 6 voices in several regimes, "T2 ..." lines
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdint.h>
#ifdef OP1_HOST
#include <stdio.h>
#include <math.h>
int16_t host_sine[8192]; int32_t host_pitch_inc[128]; uint8_t host_voice_mem[6 * 0x24]; int16_t host_voice_vel[6];
int16_t host_voice_env[128];
#define PITCH host_pitch_inc
static void t2_write(const char *b, int n) { fwrite(b, 1, (size_t)n, stdout); }
static inline uint32_t cyc(void) { return 0; }
#else
void t2_write(const char *, int);
uint32_t t2_r246_calls[2];
volatile uint8_t op1_eng_page[4];
static inline uint32_t cyc(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
#define PITCH ((int32_t *)0xFF801950)
#endif
#define CH_NO_SCREEN
#ifdef CH_PROFILE                                   /* cycle stamps per render stage (chimera_bench.py cost, CH_PROFILE=1) */
uint32_t ch_prof[8], ch_pt;
static inline uint32_t ch_cyc0(void) { uint32_t c; __asm__ volatile ("%0 = CYCLES;" : "=d"(c)); return c; }
#define CH_PROF(n) do { uint32_t c_ = ch_cyc0(); if (n) ch_prof[n] += c_ - ch_pt; ch_pt = c_; } while (0)
#define CH_PROF_PASS(n) CH_PROF(n)
#endif
#include "chimera.c"

static char txt[256];
static int tn;
static void put(const char *p) { while (*p) txt[tn++] = *p++; }
static void flush(void) { t2_write(txt, tn); tn = 0; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = (char)('0' + v % 10); while (v /= 10); put(b + i); }
static void kv(const char *k, uint32_t v) { put(" "); put(k); put("="); num(v); }

/* 2^32 f / 88200 for MIDI 108..119; lower octaves by shifts */
static const uint32_t inc9[12] = { 203840952, 215961966, 228803732, 242409110, 256823506, 272095026, 288274639,
                                   305416341, 323577341, 342818251, 363203285, 384800477 };
static uint32_t inc_of(int midi) { int o = (119 - midi) / 12; int k = midi - (108 - 12 * o); return inc9[k] >> o; }
static void set_pitch(uint32_t inc) { for (int i = 0; i < 128; i++) PITCH[i] = (int32_t)inc; }

static void make_sine(int16_t *t)
{
    int64_t c = (int64_t)1 << 30, s = 0;
    const int64_t cd = 1073741508, sd = 823550;
    for (int k = 0; k < 8192; k++) {
        t[k] = (int16_t)((s * 32767) >> 30);
        int64_t c2 = (c * cd - s * sd) >> 30, s2 = (s * cd + c * sd) >> 30;
        c = c2; s = s2;
    }
}
#define PROG(p) ((int16_t)((2 * (p) + 1) * 1024))      /* word 5 for program p (16 steps) */

/* a tiny sequencer: notes on six voices, round robin over the voices that are done, summed as R246 sums them */
typedef struct { uint16_t at, len; int8_t midi; } ch_ev;
static int16_t vb[6][128];
static uint8_t busy[6], held[6];
static int8_t vnote[6];
static uint16_t voff[6];

#ifdef CH_MODE_AUDIO
static const char hx[] = "0123456789abcdef";
static void emit(const int16_t *b, int n)
{
    for (int i = 0; i < n; i++) {
        uint16_t u = (uint16_t)b[i];
        txt[tn++] = hx[u >> 12]; txt[tn++] = hx[(u >> 8) & 15]; txt[tn++] = hx[(u >> 4) & 15]; txt[tn++] = hx[u & 15];
        if (tn > 200) { txt[tn++] = '\n'; flush(); }
    }
}

/* play events (times in blocks of 1.45 ms) with knobs k; knob sweep: k1 reached at the last event's end */
static void seq(const char *name, const ch_ev *ev, int n, const int16_t *k0, const int16_t *k1)
{
    put("WAV "); put(name); put("\n"); flush();
    for (int v = 0; v < 6; v++) { busy[v] = 0; held[v] = 0; ch_v[v].live = 0; ch_v[v].done = 1; }
    uint32_t end = 0;
    for (int i = 0; i < n; i++) if ((uint32_t)ev[i].at + ev[i].len > end) end = ev[i].at + ev[i].len;
    int next = 0, rr = 0;
    int16_t p[8];
    if (ch_progs[ch_prog_of(k0)].mode == M_SING || ch_progs[ch_prog_of(k0)].mode == M_SPEAK)
        ch_lyr_update(ch_genre_of(k0), ch_seed_of(k0));      /* what the screen does on the GUI thread */
    for (uint32_t b = 0; ; b++) {
        for (int k = 0; k < 8; k++) p[k] = (int16_t)(k0[k] + (int32_t)(k1[k] - k0[k]) * (int32_t)(b < end ? b : end) / (int32_t)end);
        while (next < n && ev[next].at == b) {                  /* note on: the next free voice */
            int v = -1;
            for (int j = 0; j < 6; j++) { int c = (rr + j) % 6; if (!busy[c]) { v = c; break; } }
            if (v < 0) v = rr % 6;
            rr = v + 1;
            set_pitch(inc_of(ev[next].midi));
            ch_note_on(OP1_VOICE(v), p);
            busy[v] = 1; held[v] = 1; vnote[v] = ev[next].midi; voff[v] = (uint16_t)(b + ev[next].len);
            next++;
        }
        int any = 0;
        for (int v = 0; v < 6; v++) {
            if (held[v] && b >= voff[v]) { ch_note_off(OP1_VOICE(v)); held[v] = 0; }
            if (busy[v] && ch_finished(OP1_VOICE(v))) busy[v] = 0;
            any |= busy[v];
        }
        if (!any && next >= n) break;
        int32_t mix[128];
        for (int i = 0; i < 128; i++) ((volatile int32_t *)mix)[i] = 0;
        for (int v = 0; v < 6; v++) if (busy[v]) {
            set_pitch(inc_of(vnote[v]));
            ch_render(OP1_VOICE(v), vb[v], p);
            for (int i = 0; i < 128; i++) mix[i] += vb[v][i];
        }
        int16_t o[128];
        for (int i = 0; i < 128; i++) o[i] = (int16_t)(mix[i] > 32767 ? 32767 : mix[i] < -32767 ? -32767 : mix[i]);
        emit(o, 128);
        if (b > 40000) break;
    }
    put("\nEND\n"); flush();
}

#define K(b, g, w, o, prog, nas, grit) { b, g, w, o, OP1_ENGINE_MAGIC, PROG(prog), nas, grit }
int main(void)
{
#ifdef OP1_HOST
    make_sine(host_sine);                                /* the same table as on bcore: host and bcore renders equal */
#else
    make_sine((int16_t *)0x0101E5E8);
#endif
    for (unsigned i = 0; i < sizeof ch_v / 4; i++) ((volatile uint32_t *)(void *)ch_v)[i] = 0;   /* bare-metal .bss */
    static const int16_t vpos[5] = { 0, 8192, 16384, 24575, 32767 };      /* u o a e i on blue */
    static const char *vname[5] = { "u", "o", "a", "e", "i" };
    static const char *bname[3] = { "male", "female", "child" };
    static const int8_t root[3] = { 48, 57, 64 };                       /* C3, A3, E4 */
    static const int8_t low[3] = { 43, 50, 55 };                        /* G2, D3, G3: the formant takes */
    char nm[48];
    for (int b = 0; b < 3; b++)
        for (int v = 0; v < 5; v++) {
            ch_ev e = { 0, 900, root[b] };
            int16_t k[8] = K(vpos[v], 16384, 2500, 6000, b, 0, 0);
            int i = 0; const char *q = "vowel-"; while (*q) nm[i++] = *q++;
            for (q = bname[b]; *q; ) nm[i++] = *q++;
            nm[i++] = '-'; for (q = vname[v]; *q; ) nm[i++] = *q++; nm[i] = 0;
            seq(nm, &e, 1, k, k);
        }
    for (int b = 0; b < 3; b++)                                          /* whispered and low: formant measurement */
        for (int v = 0; v < 5; v++) {
            ch_ev e = { 0, 700, low[b] };
            int16_t k[8] = K(vpos[v], 16384, 32767, 0, b, 0, 0);
            int i = 0; const char *q = "whisper-"; while (*q) nm[i++] = *q++;
            for (q = bname[b]; *q; ) nm[i++] = *q++;
            nm[i++] = '-'; for (q = vname[v]; *q; ) nm[i++] = *q++; nm[i] = 0;
            seq(nm, &e, 1, k, k);
        }
    for (int b = 0; b < 3; b++)                                          /* modal, low and plain: the formant takes */
        for (int v = 0; v < 5; v++) {
            ch_ev e = { 0, 700, (int8_t)(low[b] - 7) };
            int16_t k[8] = K(vpos[v], 16384, 2500, 0, b, 0, 0);
            int i = 0; const char *q = "low-"; while (*q) nm[i++] = *q++;
            for (q = bname[b]; *q; ) nm[i++] = *q++;
            nm[i++] = '-'; for (q = vname[v]; *q; ) nm[i++] = *q++; nm[i] = 0;
            seq(nm, &e, 1, k, k);
        }
    for (int b = 0; b < 3; b++) {                                        /* vowel glide u -> i, mouth opening */
        ch_ev e = { 0, 2800, root[b] };
        int16_t k0[8] = K(0, 12000, 2500, 9000, b, 0, 0), k1[8] = K(32767, 28000, 2500, 9000, b, 0, 0);
        int i = 0; const char *q = "glide-"; while (*q) nm[i++] = *q++;
        for (q = bname[b]; *q; ) nm[i++] = *q++; nm[i] = 0;
        seq(nm, &e, 1, k0, k1);
    }
    {                                                                     /* a melody with vibrato: PLAY woman, man */
        static const int8_t mel[8] = { 57, 60, 64, 62, 60, 59, 60, 57 };
        static const uint16_t len[8] = { 480, 280, 680, 280, 280, 280, 380, 1000 };
        ch_ev ev[8]; uint16_t t = 0;
        for (int i = 0; i < 8; i++) { ev[i].at = t; ev[i].len = len[i]; ev[i].midi = mel[i]; t = (uint16_t)(t + len[i] + 20); }
        int16_t k[8] = K(16384, 18000, 3000, 22000, 1, 0, 0);
        seq("melody-woman-vibrato", ev, 8, k, k);
        for (int i = 0; i < 8; i++) ev[i].midi = (int8_t)(mel[i] - 12);
        int16_t km[8] = K(16384, 18000, 3000, 22000, 0, 0, 0);
        seq("melody-man-vibrato", ev, 8, km, km);
        /* SING: three genres' phrases, one syllable a key (blue genre zone, green phrase number) */
        static const int16_t genres[3][2] = { { 1000, 5000 }, { 9700, 12000 }, { 21000, 300 } };
        static const char *gn[3] = { "sing-woman-synthwave", "sing-man-gospel", "sing-child-nursery" };
        static const int8_t smel[12] = { 57, 57, 60, 62, 64, 62, 60, 57, 55, 57, 60, 57 };
        for (int g = 0; g < 3; g++) {
            ch_ev sv[12]; uint16_t ts = 0;
            for (int i = 0; i < 12; i++) { sv[i].at = ts; sv[i].len = (uint16_t)(i % 4 == 3 ? 420 : 200); sv[i].midi = (int8_t)(smel[i] - (g == 1 ? 12 : 0) + (g == 2 ? 7 : 0)); ts = (uint16_t)(ts + sv[i].len + 60); }
            int16_t ks[8] = K(genres[g][0], genres[g][1], 3000, 14000, g == 0 ? 4 : g == 1 ? 3 : 5, 0, 0);
            seq(gn[g], sv, 12, ks, ks);
        }
        /* SPEAK: a phrase per key, man / woman / robot */
        static const char *sn[3] = { "speak-man-robotgenre", "speak-woman-lovesong", "speak-robot-space" };
        static const int16_t sg[3][2] = { { 9000, 4000 }, { 5000, 20000 }, { 26000, 9000 } };
        for (int g = 0; g < 3; g++) {
            ch_ev sp[2] = { { 0, 200, (int8_t)(g == 1 ? 57 : 48) }, { 1700, 200, (int8_t)(g == 1 ? 60 : 50) } };
            int16_t ks[8] = K(sg[g][0], sg[g][1], 14000, 18000, 6 + g, 0, 0);
            seq(sn[g], sp, 2, ks, ks);
        }
    }
    {                                                                     /* BEATBOX: two bars of a beat at 100 BPM */
        /* sixteenths of 150 ms = 103 blocks: kick C, hat E, snare D, open hat F#, toms F / G, bass hum A */
        static const int8_t pat[32] = { 48, 52, 52, 52, 50, 52, 48, 52, 48, 52, 52, 48, 50, 52, 54, 52,
                                        48, 52, 52, 52, 50, 52, 48, 52, 48, 52, 53, 55, 50, 49, 54, 58 };
        ch_ev ev[32];
        for (int i = 0; i < 32; i++) { ev[i].at = (uint16_t)(i * 103); ev[i].len = 60; ev[i].midi = pat[i]; }
        int16_t k[8] = K(16384, 16384, 16384, 0, 9, 0, 0);
        seq("beatbox", ev, 32, k, k);
    }
    {                                                                     /* BIRD: a little song */
        static const int8_t bm[10] = { 72, 76, 79, 76, 84, 79, 76, 72, 74, 72 };
        ch_ev ev[10]; uint16_t t = 0;
        for (int i = 0; i < 10; i++) { ev[i].at = t; ev[i].len = (uint16_t)(i == 4 ? 500 : 140); ev[i].midi = (int8_t)(bm[i] - 12); t = (uint16_t)(t + ev[i].len + 50); }
        int16_t k0[8] = K(6000, 12000, 3000, 24000, 10, 0, 0), k1[8] = K(30000, 20000, 3000, 24000, 10, 0, 0);
        seq("bird", ev, 10, k0, k1);
    }
    {                                                                     /* ELEPHANT: two trumpets */
        ch_ev ev[2] = { { 0, 900, 50 }, { 1200, 1300, 55 } };
        int16_t k[8] = K(4000, 22000, 6000, 30000, 11, 0, 0);
        seq("elephant", ev, 2, k, k);
    }
    {                                                                     /* breath up, nasal up, grit up (PLAY man) */
        ch_ev e = { 0, 2800, 50 };
        int16_t k0[8] = K(16384, 16384, 0, 4000, 0, 0, 0), k1[8] = K(16384, 16384, 32767, 4000, 0, 0, 0);
        seq("breath-up-man", &e, 1, k0, k1);
        int16_t n0[8] = K(16384, 16384, 2500, 4000, 0, 0, 0), n1[8] = K(16384, 16384, 2500, 4000, 0, 32767, 0);
        seq("nasal-up-man", &e, 1, n0, n1);
        ch_ev eg = { 0, 2400, 45 };
        int16_t g0[8] = K(16384, 16384, 2500, 0, 0, 0, 0), g1[8] = K(16384, 16384, 2500, 0, 0, 0, 32767);
        seq("grit-up-man", &eg, 1, g0, g1);
    }
    return 0;
}
#endif

#ifdef CH_MODE_COST
int16_t out[6][128];                             /* the render buffers: free in the memmodel, as on the unit */
__attribute__((noinline)) void blk_end(uint32_t r) { __asm__ volatile ("" : : "r"(r) : "memory"); }   /* cold: flush */
int main(void)
{
    make_sine((int16_t *)0x0101E5E8);
    static const int8_t notes[6] = { 48, 52, 55, 60, 64, 72 };
    /* regimes: PLAY default; PLAY nasal; PLAY breath + fry + nasal; PLAY sweep; all max at C6..; SING (a phrase,
     * retriggered); SPEAK; BEATBOX; BIRD */
#define R(b, g, w, o, prog, nas, grit) { b, g, w, o, OP1_ENGINE_MAGIC, PROG(prog), nas, grit }
    static const int16_t kn[9][8] = {
        R(16384, 16384, 2500, 9000, 0, 0, 0), R(16384, 16384, 2500, 9000, 0, 30000, 0),
        R(8192, 30000, 32767, 32767, 0, 30000, 32767), R(-1, -1, 9000, 20000, 0, 20000, 8000),
        R(32767, 0, 32767, 32767, 0, 32767, 32767), R(1000, 5000, 9000, 20000, 4, 20000, 0),
        R(9000, 4000, 14000, 18000, 6, 0, 0), R(16384, 16384, 32767, 0, 9, 0, 0), R(16384, 16384, 9000, 32767, 10, 0, 0) };
    static const int nv[4] = { 1, 2, 4, 6 };
    for (int r = 0; r < 9; r++)
        for (int q = 0; q < 4; q++) {
            int16_t p[8];
            for (int k = 0; k < 8; k++) p[k] = kn[r][k] < 0 ? 0 : kn[r][k];
            int hi = r == 4 ? 36 : 0;
            if (ch_progs[ch_prog_of(p)].mode == M_SING || ch_progs[ch_prog_of(p)].mode == M_SPEAK)
                ch_lyr_update(ch_genre_of(p), ch_seed_of(p));    /* a real phrase (the screen's job), outside the timing */
            for (int v = 0; v < nv[q]; v++) { set_pitch(inc_of(notes[v] + hi)); ch_note_on(OP1_VOICE(v), p); }
            uint32_t mx = 0, sum = 0, nb = 0;
            for (uint32_t b = 0; b < 400; b++) {
                if (kn[r][0] < 0) { uint32_t w = (b * 300) % 65536; p[0] = (int16_t)(w < 32768 ? w : 65535 - w); p[1] = (int16_t)((b * 700) & 32767); }
                uint32_t tv = 0;
                for (int v = 0; v < nv[q]; v++) {
                    set_pitch(inc_of(notes[v] + hi));
                    if (r >= 5 && (b % 64) == (uint32_t)v * 9) { ch_note_off(OP1_VOICE(v)); }
                    if (ch_finished(OP1_VOICE(v)) || (r >= 5 && (b % 64) == (uint32_t)v * 9 + 4)) ch_note_on(OP1_VOICE(v), p);
                    uint32_t t = cyc(); ch_render(OP1_VOICE(v), out[v], p); tv += cyc() - t;
                }
                if (b >= 8) { if (tv > mx) mx = tv; sum += tv; nb++; }
                blk_end(b);
            }
            put("T2"); kv("regime", (uint32_t)r); kv("voices", (uint32_t)nv[q]); kv("max", mx); kv("avg", sum / nb);
#ifdef CH_PROFILE
            for (int z = 1; z < 8; z++) { kv("st", ch_prof[z] / nb / (uint32_t)nv[q]); ch_prof[z] = 0; }
#endif
            put("\n"); flush();
        }
    return 0;
}
#endif
