/* chimera's lattice kernel (chimera_kernel.S) against the C (chimera_dsp.h ch_lattice_c) on bcore (chimera_bench.py
 * kern): random states from silence to full scale (every saturation reached), random coefficients including +-32767
 * and -32768, every length 1..CH_NMAX and start 1..3, four steps in a row so states carry. Every R / L word, the
 * returned rp and the words around the arrays (nothing else written) are compared. Prints "KERN ok cases=N" or the
 * first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdint.h>
#include "op1_plugin.h"
#include "chimera_dsp.h"
void t2_write(const char *, int);
uint32_t t2_r246_calls[2];
static char line[160];
static int n_;
static void put(const char *p) { while (*p) line[n_++] = *p++; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = (char)('0' + v % 10); while (v /= 10); put(b + i); }
static uint32_t rng = 0x2545F491u;
static int memcmp_(const void *a, const void *b, unsigned n) { const uint8_t *x = a, *y = b; for (unsigned i = 0; i < n; i++) if (x[i] != y[i]) return 1; return 0; }
static uint32_t rnd(void) { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng; }
static int16_t val(int wild)
{
    uint32_t r = rnd();
    if (wild == 0) return (int16_t)((int32_t)(r >> 16) >> (r & 7));           /* any size */
    if (wild == 1) return (r & 1) ? 32767 : -32768;                           /* rails */
    return (int16_t)((int32_t)(r >> 20) - 2048);                             /* small */
}
#define G 4                                                                    /* guard words */
static int16_t Ra[CH_NMAX + 2 * G], La[CH_NMAX + 2 * G], Rb[CH_NMAX + 2 * G], Lb[CH_NMAX + 2 * G], K[CH_NMAX + 2 * G];
int main(void)
{
    uint32_t cases = 0, bad = 0;
    for (int it = 0; it < 4000 && !bad; it++) {
        int wild = (int)(rnd() % 3), kw = (int)(rnd() % 4);
        int a = 1 + (int)(rnd() % 3), b = a + 1 + (int)(rnd() % (CH_NMAX - a));
        for (int i = 0; i < CH_NMAX + 2 * G; i++) {
            Ra[i] = Rb[i] = val(wild); La[i] = Lb[i] = val(wild);
            K[i] = kw == 0 ? val(0) : kw == 1 ? (int16_t)((rnd() & 1) ? 32767 : -32768) : kw == 2 ? (int16_t)(rnd() % 3 == 0 ? -32768 : 32767 - (rnd() & 255)) : (int16_t)((int32_t)(rnd() >> 17) - 16384);
        }
        int16_t rp = val(wild), rpa = rp, rpb = rp;
        for (int step = 0; step < 4 && !bad; step++) {
            rpa = ch_lattice_c(Ra + G, La + G, K + G, a, b, rpa);
            rpb = ch_lattice_asm(Rb + G + a, Lb + G + a, K + G + a, rpb, b - a);
            cases++;
            if (rpa != rpb) { bad = 1; put("KERN differ rp case "); num(cases); put("\n"); }
            for (int i = 0; i < CH_NMAX + 2 * G && !bad; i++)
                if (Ra[i] != Rb[i] || La[i] != Lb[i]) { bad = 1; put("KERN differ word "); num((uint32_t)i); put(Ra[i] != Rb[i] ? " R " : " L "); num((uint16_t)(Ra[i] != Rb[i] ? Ra[i] : La[i])); put(" vs "); num((uint16_t)(Ra[i] != Rb[i] ? Rb[i] : Lb[i])); put(" a "); num((uint32_t)a); put(" b "); num((uint32_t)b); put(" step "); num((uint32_t)step); put(" kw "); num((uint32_t)kw); put(" wild "); num((uint32_t)wild); put("\n"); }
        }
    }
    /* the whole block (ch_block_asm against ch_block_c): random tract / nose states and controls, every body, nose on
     * and off, frication on and off, the pulse and the sine, short periods (many period events), extreme gains */
    static ch_tract_t ta, tb;
    static int16_t oa[128], ob[128], sinet[8192];
    for (int i = 0; i < 8192; i++) sinet[i] = (int16_t)((int32_t)(rnd() >> 16));
    uint32_t passes = 0;
    for (int it = 0; it < 800 && !bad; it++) {
        int wild = (int)(rnd() % 3), n = (int)ch_body_n[rnd() % 3], v = CH_VEL_OF(n), nose = (int)(rnd() & 1);
        int16_t *pa = (int16_t *)(void *)&ta, *pb = (int16_t *)(void *)&tb;
        for (unsigned i = 0; i < sizeof ta / 2; i++) pa[i] = pb[i] = val(wild);
        for (int i = 0; i < CH_NMAX; i++) ta.k[i] = tb.k[i] = (int16_t)((int32_t)(rnd() >> 17) - 16384);
        int im = 2 + (int)(rnd() % (uint32_t)(n - 2));
        ch_tract_t *tt[2] = { &ta, &tb };
        int16_t *oo[2] = { oa, ob };
        ch_blk_t x[2];
        uint32_t seed = rnd();
        for (int q = 0; q < 2; q++) {
            ch_tract_t *t = tt[q]; ch_blk_t *b = &x[q];
            uint32_t r0 = rng; rng = seed;
            b->R = t->R; b->L = t->L; b->k = t->k; b->out = oo[q]; b->n1 = nose ? v - 1 : n - 1;
            b->Rl = &t->R[n - 1]; b->Ll = &t->L[n - 1]; b->Rim = &t->R[im]; b->Lim1 = &t->L[im - 1];
            b->lip = val(wild); b->rl = -(int32_t)(26000 + (rnd() & 4095)); b->fr = (int32_t)(rnd() & 1); b->nose = nose;
            b->Rv = &t->R[v]; b->Lv = &t->L[v]; b->nL = t->nL; b->nR = t->nR; b->nk = ch_nose_k; b->kv1 = &t->k[v + 1];
            b->g01 = (int32_t)((rnd() & 16383) | ((rnd() & 16383) << 16)); b->g2 = (int32_t)(rnd() & 8191); b->nlip = val(wild);
            b->n2 = n - 1 - v; b->ri = 0;
            b->ph = rnd(); b->base = (rnd() >> (rnd() % 8 + 2)) | 1; b->step = rnd() >> 3; b->rng = rnd() | 1;
            b->iq = 1u + (rnd() % 1800u); b->dev = (int32_t)(rnd() % 4096) - 2048; b->gfac = 4096 + (int32_t)(rnd() % 400) - 200;
            b->gamp = (int32_t)(rnd() % 9000); b->gamp16 = b->gamp > 8191 ? 32767 : (int16_t)(b->gamp << 2);
            b->asp_o = (int32_t)(rnd() % 32768); b->asp_c = (int32_t)(rnd() % 8000); b->fric = (int32_t)(rnd() % 1024);
            b->nlp = val(2); b->sine = (int32_t)((rnd() & 3) == 0);
            b->gv = (int32_t)(rnd() % 30000); b->e = (int32_t)(rnd() % 32768); b->de = (int32_t)(rnd() % 1024) - 512;
            b->pk = 0; b->last = val(wild);
            b->jitter = (int32_t)(rnd() % 1200); b->fry = (rnd() & 1) ? (int32_t)(rnd() % 4097) : 0; b->voice = (int32_t)(rnd() % 4097);
            b->odd = (int32_t)(rnd() & 1); b->sintab = sinet; b->glot = ch_glot;
            rng = r0;
        }
        ch_block_c(&x[0]);
        ch_block_asm(&x[1]);
        passes++;
        if (memcmp_(pa, pb, sizeof ta) || memcmp_(oa, ob, sizeof oa) || memcmp_(&x[0].ph, &x[1].ph, sizeof x[0] - __builtin_offsetof(ch_blk_t, ph))
            || (int16_t)x[0].lip != (int16_t)x[1].lip || (int16_t)x[0].nlip != (int16_t)x[1].nlip) {
            bad = 1; put("BLOCK differ it "); num((uint32_t)it); put(" nose "); num((uint32_t)nose); put(" sine "); num((uint32_t)x[0].sine);
            put(memcmp_(pa, pb, sizeof ta) ? " state" : ""); put(memcmp_(oa, ob, sizeof oa) ? " out" : ""); put("\n");
        }
    }
    if (!bad) { put("BLOCK ok blocks="); num(passes); put(" "); }
    if (!bad) { put("KERN ok cases="); num(cases); put("\n"); }
    t2_write(line, n_);
    return 0;
}
