/* chimera_text.h: chimera's text side. English letter-to-sound rules, syllabifier and stress, producing the phrase
 * format of chimera_phon.h. Integers only, no libc; everything is static, so chimera.c can #include it.
 *
 *   int ch_g2p_text(const char *text, uint8_t *out, int max)   text -> codes, PH_END-terminated (see below)
 *   int ch_syllables(const uint8_t *ph)                        vowels in a code string
 *
 * ch_g2p_text: case-insensitive; letters and apostrophes make words (apostrophes are dropped), anything else
 * except , . ! ? is a word break. PH_WORD between words, PH_SYL between the syllables of a word, PH_STRESS right
 * before the vowel of the stressed syllable, PH_COMMA / PH_QUEST / PH_STOP (. and !) after the word they follow
 * (once per word). Returns the number of codes (PH_END not counted), or -1 if they did not fit in max bytes; then
 * out holds the codes that did fit plus PH_END. Never writes past max.
 *
 * Rules: "left[match]right=out|" in the style of the NRL / Elovitz rules, first match wins. Context symbols:
 *   ' ' word edge   # one or more vowels (a e i o u y)   : zero or more consonants   ^ one consonant
 *   . one voiced consonant (b d g j l m n r v w z)   + one front vowel (e i y)   @ one of t s r d l z n j
 *   % a suffix at the word end (e, er, es, ed, ely, ing)
 * Output letters are one phoneme each: vowels  a AA  @ AE  u AH  o AO  W AW  Y AY  e EH  E ER  A EY  i IH  I IY
 * O OW  Q OY  U UH  X UW  x AX;  consonants  b CH(C) d DH(D) f g h JH(J) k l m n NG(N) p r s SH(S) t TH(T) v w y
 * z ZH(Z);  '-' before a vowel marks it unstressed (a prefix such as be-, re-). Double consonant letters count
 * once. A word may also come from the exception table (explicit pronunciation, ' before the stressed vowel).
 * Stress: the first syllable of content words (not an AX or a '-' vowel); -tion/-sion/-ic take the one before
 * the ending, -oon/-eer the last; the monosyllabic function words in ch_func get none.
 * Syllables: split by vowel nuclei, the longest legal English onset goes to the next syllable, except that a
 * single consonant after a short vowel (AE EH IH AH UH) stays with it (lem-on, pump-kin).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef CHIMERA_TEXT_H
#define CHIMERA_TEXT_H
#include <stdint.h>
#include "chimera_phon.h"

#define CH_MAXW 20   /* letters of a word that are used */
#define CH_MAXP 40   /* phonemes of a word that are used */

static const char ch_rules[] =
    /* a */
    "[again]=xgen|" " [are] =ar|" " [a] =x|" " [a]^e =A|" "#:[al] =xl|" "[alk]=ok|" "[al]^=ol|" "[able]=Abxl|" " [a]^#=x|"
    "[any] =enI|" "[ah] =a|" " :[a] =a|" "#:[a] =x|" "[air]=er|" "[ay]=A|" "[ai]=A|" "[aw]=o|" "[au]=o|"
    "#:[ar] =E|" "[ar]#=er|" "[ar]=ar|" "[a]^+#=A|" "[a]^%=A|" "[a]^y =A|" "[a]=@|"
    /* b c d */
    " [be]^#=b-i|" "m[b] =|" "[b]=b|"
    "[ch]^=k|" "[ch]=C|" "[ci]a=S|" "[ci]o=S|" "[come]=kum|" "[c]+=s|" "[ck]=k|" "[c]=k|"
    "[dg]=J|" "[d]=d|"
    /* e */
    "#:[e] =|" " :[e] =I|" "#:t[ed] =xd|" "#:d[ed] =xd|" "#:.[ed] =d|" "#:p[ed] =t|" "#:k[ed] =t|" "#:s[ed] =t|" "#:f[ed] =t|"
    "#:[e]s =|" "[ever]=evE|" "#:^[en] =xn|" "[earn]=Ern|" " [ear]^=E|" "b[ear]=er|" "w[ear]=er|" "p[ear]=er|"
    "[ear]=Ir|" "[ely] =lI|" "[engine]=enJxn|" "[e]o=I|" "[ea]d=e|" "[ea]th=e|" "[ea]=I|" " [eye]=Y|" "[eigh]=A|" "[ei]=I|" "[ey]=I|" "[eu]=yX|"
    "@[ew]=X|" "[ew]=yX|" "[ee]=I|" "[e]^%=I|" "[er]#=er|" "[er]=E|" "[e]=e|"
    /* f g h */
    "[f]=f|"
    "[giv]=giv|" " [g]i^=g|" "[ge]t=ge|" "[g]+=J|" "[great]=grAt|" "[gh]=g|" "[g]=g|"
    " [here]=hIr|" "[have]=h@v|" " [hour]=Wr|" "[how]=hW|" "#[h] =|" "[h]=h|"
    /* i j k l m n */
    "[iver]=ivE|" "[ie]nd=e|" " [i] =Y|" "[ie] =Y|" "[ie]=I|" "[igh]=Y|" "[ild]=Yld|" "k[ind]=Ynd|" "f[ind]=Ynd|" "m[ind]=Ynd|"
    "h[ind]=Ynd|" "[ir]#=Yr|" "[ir]=E|" "[i]^%=Y|" "[i]=i|"
    "[j]=J|" " [kn]=n|" "[k]=k|" "#:^[l]%=xl|" "[less] =lxs|" "[l]=l|" "[mov]=mXv|" "[m]=m|"
    "[ness] =nxs|" "[ng]e =nJ|" "[ng]r=Ng|" "[ng]l=Ng|" "[ng]=N|" "[nk]=Nk|" "[n]=n|"
    /* o */
    "[oh] =O|" "[ocean]=OSxn|" "[oor]=or|" "[oo]ky=X|" "[oo]k=U|" "g[oo]d=U|" "[oo]=X|" "[oa]=O|" "[oi]=Q|" "[oy]=Q|" "[oe]=O|"
    "[our]=or|" "[ous] =xs|" "[ou]=W|"
    " n[ow] =W|" " h[ow] =W|" " c[ow] =W|" " w[ow] =W|" "[ow]er=W|" "[ow]l=W|" "d[ow]n=W|" "t[ow]n=W|"
    "r[ow]n =W|" "l[ow]n =W|" "[ow]d =W|" "[ow]=O|"
    "[old]=Old|" "r[ol]l=Ol|" "[o]st =O|" "[over]=OvE|" "[ov]=uv|" "[o]ther=u|" "[o]ng=o|" "#:^[on] =xn|"
    "#:[or] =E|" "[or]#=or|" "[o]^en=O|" "[o]^%=O|" "[o]^y =O|" "[or]=or|" "[o] =O|" "[o]=a|"
    /* p q r s */
    "[ph]=f|" "[peop]=pIp|" "[pow]=pW|" "[p]=p|" "[qu]=kw|" "[q]=k|" " [re]^#=r-i|" "[rh]=r|" "[r]=r|"
    "[sh]=S|" "#[sion]=Zxn|" "[sion]=Sxn|" "[some]=sum|" "i[s]e =z|" "o[s]e =z|" "e[s]e =z|" "[s]e =s|"
    ".e[s] =z|" "ee[s] =z|" "ie[s] =z|" "oe[s] =z|" "ue[s] =z|" "ye[s] =z|" "y[s] =z|" ".[s] =z|" "#[s]#=z|" "[s]=s|"
    /* t u v w x y z */
    "[they]=DA|" " [th]e=D|" " [th]is=D|" " [th]at=D|" " [th]an=D|" " [th]ose=D|" "[th]er=D|" "[tion]=Sxn|"
    "[ture]=CE|" "[tch]=C|" "[th]=T|" "[t]=t|"
    "p[u]ll=U|" "[ure]=yUr|" "[ur]=E|" "[uy]=Y|" "[ui]=X|" "[ue]=X|" "@[u]^%=X|" "@[u]^#=X|" "[u]^%=yX|" "[u]^#=yX|" "[u]=u|"
    "[v]=v|"
    " [were]=wE|" "[war]=wor|" "[wa]ter=wo|" "[wa]nt=wa|" "[wa]sh=wa|" "[wa]tch=wa|" "[wh]o=h|" "[wh]=w|"
    "[wr]=r|" "[wor]^=wE|" "[w]=w|"
    " [x]=z|" "[x]=ks|"
    " [you] =yX|" " [y]=y|" "[y]ing=Y|" " :[y] =Y|" "#:[y] =I|" "[y]^%=Y|" "[y]=i|"
    "[z]=z|";

/* whole words whose spelling the rules get wrong: "word=pronunciation|" (' marks the stressed vowel; none = no stress) */
static const char ch_exc[] =
    "the=Dx|to=tx|of=xv|do=dX|was=wuz|is=iz|his=hiz|as=@z|has=h@z|one=w'un|once=w'uns|two=t'X|who=h'X|"
    "said=s'ed|done=d'un|heart=h'art|sugar=S'UgE|what=w'ut|gone=g'on|none=n'un|been=b'in|from=frum|"
    "could=kUd|would=wUd|should=SUd|does=duz|put=p'Ut|";

/* monosyllabic function words: no stress */
static const char ch_func[] =
    " a an the to of and in on at for or as but you your we he she me be by my i so are is it was were do can will"
    " with from that this if our us them his her its am has had they there where could would should been does ";

static int ch_lc(int c) { return c >= 'A' && c <= 'Z' ? c + 32 : c; }
static int ch_isl(int c) { return c >= 'a' && c <= 'z'; }
static int ch_isv(int c) { return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'y'; }
static int ch_isc(int c) { return ch_isl(c) && !ch_isv(c); }
static int ch_isvd(int c)
{ return c == 'b' || c == 'd' || c == 'g' || c == 'j' || c == 'l' || c == 'm' || c == 'n' || c == 'r' || c == 'v' || c == 'w' || c == 'z'; }
static int ch_isat(int c)
{ return c == 't' || c == 's' || c == 'r' || c == 'd' || c == 'l' || c == 'z' || c == 'n' || c == 'j'; }

/* right context, forward from p */
static int ch_mr(const char *w, int p, const char *c, const char *ce)
{
    for (; c < ce; c++) {
        int k = *c, x = w[p];
        if (k == '#') { if (!ch_isv(x)) return 0; p++; while (ch_isv(w[p])) p++; }
        else if (k == ':') { while (ch_isc(w[p])) p++; }
        else if (k == '^') { if (!ch_isc(x)) return 0; p++; }
        else if (k == '.') { if (!ch_isvd(x)) return 0; p++; }
        else if (k == '+') { if (x != 'e' && x != 'i' && x != 'y') return 0; p++; }
        else if (k == '@') { if (!ch_isat(x)) return 0; p++; }
        else if (k == '%') {
            if (x == 'e' && w[p + 1] == 'l' && w[p + 2] == 'y') p += 3;
            else if (x == 'i' && w[p + 1] == 'n' && w[p + 2] == 'g') p += 3;
            else if (x == 'e' && (w[p + 1] == 'r' || w[p + 1] == 's' || w[p + 1] == 'd')) p += 2;
            else if (x == 'e') p += 1;
            else return 0;
            if (w[p] != ' ') return 0;
        }
        else { if (x != k) return 0; p++; }
    }
    return 1;
}

/* left context, backward from p (the char before the match); c..ce is the context text, read from its end */
static int ch_ml(const char *w, int p, const char *c, const char *ce)
{
    while (ce > c) {
        int k = *--ce;
        if (p < 0) return 0;
        if (k == '#') { if (!ch_isv(w[p])) return 0; p--; while (p >= 0 && ch_isv(w[p])) p--; }
        else if (k == ':') { while (p >= 0 && ch_isc(w[p])) p--; }
        else if (k == '^') { if (!ch_isc(w[p])) return 0; p--; }
        else if (k == '.') { if (!ch_isvd(w[p])) return 0; p--; }
        else if (k == '+') { if (w[p] != 'e' && w[p] != 'i' && w[p] != 'y') return 0; p--; }
        else if (k == '@') { if (!ch_isat(w[p])) return 0; p--; }
        else { if (w[p] != k) return 0; p--; }
    }
    return 1;
}

static int ch_oc(int c)
{
    static const char v[] = "a@uoWYeEAiIOQUXx";
    static const char k[] = "bCdDfghJklmnNprsStTvwyzZ";
    int i;
    for (i = 0; v[i]; i++) if (v[i] == c) return PH_VOWEL0 + i;
    for (i = 0; k[i]; i++) if (k[i] == c) return PH_B + i;
    return 0;
}

/* append the phonemes of an output string (rule or exception); '-' flags the next vowel (0x80), ' sets *st to
 * the index of the next vowel. Returns the new count. */
static int ch_addout(uint8_t *pr, int n, const char *o, const char *oe, int *nv, int *st)
{
    int flag = 0, mark = 0;
    for (; o < oe; o++) {
        int p;
        if (*o == '-') { flag = 0x80; continue; }
        if (*o == '\'') { mark = 1; continue; }
        p = ch_oc(*o);
        if (!p || n >= CH_MAXP) continue;
        if (ph_is_vowel(p)) {
            if (mark && st) *st = *nv;
            mark = 0;
            (*nv)++;
            p |= flag; flag = 0;
        }
        pr[n++] = (uint8_t)p;
    }
    return n;
}

static int ch_wordeq(const char *a, const char *w, int n)
{
    int i;
    for (i = 0; i < n; i++) if (a[i] != w[i]) return 0;
    return 1;
}

static int ch_isfunc(const char *w, int n)   /* w: letters (no edge spaces) */
{
    const char *s = ch_func;
    while (*s) {
        const char *e;
        while (*s == ' ') s++;
        e = s;
        while (*e && *e != ' ') e++;
        if (e - s == n && ch_wordeq(s, w, n)) return 1;
        s = e;
    }
    return 0;
}

/* wb: ' ' + letters + ' ' (n letters). Fills pr (codes, 0x80 = reduced); returns phoneme count. *st = stressed
 * vowel from an exception (-1 none), *fixed = 1 if the stress came from the exception table. */
static int ch_g2w(const char *wb, int n, uint8_t *pr, int *nvp, int *st, int *fixed)
{
    const char *s = ch_exc;
    int np = 0, nv = 0, i;
    *st = -1; *fixed = 0;
    while (*s) {
        const char *e = s, *q;
        while (*e != '=') e++;
        q = e + 1;
        while (*q != '|') q++;
        if (e - s == n && ch_wordeq(s, wb + 1, n)) {
            *fixed = 1;
            np = ch_addout(pr, 0, e + 1, q, &nv, st);
            *nvp = nv;
            return np;
        }
        s = q + 1;
    }
    for (i = 1; i <= n;) {
        const char *r = ch_rules;
        int used = 0;
        if (i > 1 && wb[i] == wb[i - 1] && ch_isc(wb[i])) { i++; continue; }
        while (*r) {
            const char *lb = r, *mb, *me, *eq, *ot, *oe;
            int k = 0;
            while (*lb != '[') lb++;
            mb = lb + 1; me = mb;
            while (*me != ']') me++;
            eq = me + 1;
            while (*eq != '=') eq++;
            ot = eq + 1; oe = ot;
            while (*oe != '|') oe++;
            while (mb + k < me && wb[i + k] == mb[k]) k++;
            if (mb + k == me && ch_ml(wb, i - 1, r, lb) && ch_mr(wb, i + k, me + 1, eq)) {
                np = ch_addout(pr, np, ot, oe, &nv, 0);
                used = k;
                break;
            }
            r = oe + 1;
        }
        i += used ? used : 1;
    }
    *nvp = nv;
    return np;
}

static int ch_ends(const char *w, int n, const char *suf)
{
    int m = 0;
    while (suf[m]) m++;
    return n >= m && ch_wordeq(suf, w + n - m, m);
}

static int ch_legal2(int a, int b)
{
    switch (b) {
    case PH_Y: return a == PH_P || a == PH_B || a == PH_T || a == PH_D || a == PH_K || a == PH_G || a == PH_F || a == PH_V ||
                      a == PH_M || a == PH_N || a == PH_HH || a == PH_S || a == PH_L || a == PH_TH || a == PH_Z;
    case PH_W: return a == PH_S || a == PH_T || a == PH_K || a == PH_G || a == PH_D || a == PH_TH;
    case PH_L: return a == PH_P || a == PH_B || a == PH_K || a == PH_G || a == PH_F || a == PH_S;
    case PH_R: return a == PH_P || a == PH_B || a == PH_T || a == PH_D || a == PH_K || a == PH_G || a == PH_F || a == PH_TH || a == PH_SH;
    case PH_P: case PH_T: case PH_K: case PH_M: case PH_N: return a == PH_S;
    }
    return 0;
}

static int ch_onset_ok(const uint8_t *c, int o)
{
    if (o == 1) return c[0] != PH_NG;
    if (o == 2) return ch_legal2(c[0], c[1]);
    if (o == 3)
        return c[0] == PH_S && (c[1] == PH_P || c[1] == PH_T || c[1] == PH_K) && ch_legal2(c[1], c[2]) &&
               (c[2] == PH_L || c[2] == PH_R || c[2] == PH_W || c[2] == PH_Y);
    return 0;
}

static int ch_lax(int v) { return v == PH_AE || v == PH_EH || v == PH_IH || v == PH_AH || v == PH_UH; }

static int ch_put(uint8_t *o, int *n, int cap, int v)
{
    if (*n >= cap) return 0;
    o[(*n)++] = (uint8_t)v;
    return 1;
}

/* one word: wb/n as for ch_g2w; appends its codes (syllables, stress). Returns 0 if it did not fit, 1 if it did,
 * 2 if the word has no sounds (nothing appended). */
static int ch_emit_word(const char *wb, int n, uint8_t *out, int *on, int cap, int sep)
{
    uint8_t pr[CH_MAXP + 2];
    int vp[CH_MAXP + 2], start[CH_MAXP + 2];
    int np, nv, st, fixed, k = 0, i, j, ok = 1;
    np = ch_g2w(wb, n, pr, &nv, &st, &fixed);
    if (np == 0) return 2;
    if (nv == 0) {                      /* no vowel at all (hmm, shh): put a schwa after the first sound */
        for (i = np; i > 1; i--) pr[i] = pr[i - 1];
        pr[1] = PH_AX;
        np++;
        nv = 1;
        fixed = 1; st = -1;
    }
    for (i = 0; i < np; i++) if (ph_is_vowel(pr[i] & 0x7f)) vp[k++] = i;
    if (!fixed) {                       /* stress */
        int s = 0, t;
        if (ch_isfunc(wb + 1, n)) s = -1;
        else {
            if (k >= 2) {
                if (ch_ends(wb + 1, n, "tion") || ch_ends(wb + 1, n, "sion") ||
                    (k >= 3 && (ch_ends(wb + 1, n, "ic") || ch_ends(wb + 1, n, "ics")))) s = k - 2;
                else if (ch_ends(wb + 1, n, "oon") || ch_ends(wb + 1, n, "eer") || ch_ends(wb + 1, n, "ique")) s = k - 1;
            }
            t = s;
            while (t < k && ((pr[vp[t]] & 0x80) || (pr[vp[t]] & 0x7f) == PH_AX)) t++;
            if (t >= k) {
                t = 0;
                while (t < k && ((pr[vp[t]] & 0x80) || (pr[vp[t]] & 0x7f) == PH_AX)) t++;
            }
            s = t < k ? t : -1;
        }
        st = s;
    }
    start[0] = 0;
    for (j = 1; j < k; j++) {
        int prev = vp[j - 1], cur = vp[j], c = cur - prev - 1, o = 0, t;
        for (t = c < 3 ? c : 3; t >= 1; t--)
            if (ch_onset_ok(pr + cur - t, t)) { o = t; break; }
        if (o == c && c >= 1 && ch_lax(pr[prev] & 0x7f) && !(pr[prev] & 0x80)) o = c - 1;
        start[j] = cur - o;
    }
    if (sep && !ch_put(out, on, cap, PH_WORD)) ok = 0;
    for (j = 0; j < k; j++) {
        int from = start[j], to = j + 1 < k ? start[j + 1] : np, q;
        if (j > 0 && !ch_put(out, on, cap, PH_SYL)) ok = 0;
        for (q = from; q < to; q++) {
            if (q == vp[j] && j == st && !ch_put(out, on, cap, PH_STRESS)) ok = 0;
            if (!ch_put(out, on, cap, pr[q] & 0x7f)) ok = 0;
        }
    }
    return ok;
}

static int ch_g2p_text(const char *text, uint8_t *out, int max)
{
    char wb[CH_MAXW + 4];
    int n = 0, cap = max - 1, ok = 1, sep = 0, pdone = 0, p = 0;
    if (max < 1) return -1;
    while (text[p]) {
        int c = ch_lc((unsigned char)text[p]);
        if (ch_isl(c) || c == '\'') {
            int nl = 0, r, mark = n;
            wb[0] = ' ';
            while (text[p]) {
                c = ch_lc((unsigned char)text[p]);
                if (ch_isl(c)) { if (nl < CH_MAXW) wb[1 + nl++] = (char)c; }
                else if (c != '\'') break;
                p++;
            }
            wb[1 + nl] = ' ';
            wb[2 + nl] = 0;
            if (nl == 0) continue;
            r = ch_emit_word(wb, nl, out, &n, cap, sep);
            if (r == 0) { n = mark; ok = 0; break; }   /* keep only whole words */
            if (r == 1) { sep = 1; pdone = 0; }
            continue;
        }
        if ((c == ',' || c == '.' || c == '!' || c == '?') && sep && !pdone) {
            if (!ch_put(out, &n, cap, c == ',' ? PH_COMMA : c == '?' ? PH_QUEST : PH_STOP)) ok = 0;
            pdone = 1;
        }
        p++;
    }
    out[n] = PH_END;
    return ok ? n : -1;
}

static int ch_syllables(const uint8_t *ph)
{
    int n = 0;
    for (; *ph != PH_END; ph++) if (ph_is_vowel(*ph)) n++;
    return n;
}
#endif
