/* chimera_screen.h: chimera's engine screen (GUI thread), #included at the very end of chimera.c so it sees its statics.
 *
 * An animated midsagittal cutaway of a head in thin vector lines (after CHIMERA's vector display). The still anatomy is
 * chimera.svg (gen_svg.py, groups g_head / g_beat / g_bird / g_trunk, one shown at a time); everything that moves is
 * drawn here with op1_raster_line from what the audio side publishes (ch_view, chimera_view.h): the tongue (body and
 * tip), jaw, lips, velum, vocal folds (vibrating with the glottal phase), the airway as a ladder of cross-sections
 * from the tract's log areas with particles flowing glottis -> lips (faster through constrictions), sparks at a
 * fricative's constriction, a nasal stream when the velum opens, and sound arcs leaving the mouth.
 *   PLAY / SING / SPEAK  the head (SING and SPEAK: the phoneme, genre, phrase, NEXT word / phrase with a marker)
 *   BEATBOX              a smaller head and 12 pads (the drum that played lights its pad)
 *   BIRD                 a songbird: the beak opens with green, the throat pulses, whistle arcs
 *   ELEPHANT             a head with a trunk (the nasal tube) that lifts and glows with the sound
 * Bottom row: the four knob names (page 2 of a knob shows PROGRAM / NASAL / GRIT). The program shown follows the
 * knob words, so it changes before a key is played; the moving parts show the knob pose until a voice sounds.
 * Typed text (SING / SPEAK, blue in the typed zone): a text entry "LYRICS" opens when the zone is entered and when green
 * turns there; the result is stored as setting chimera.text.
 * No float, no libc, no division in loops. All drawing goes through R246's calls (the core hashes the frame).
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "op1_synth.h"
#include "chimera_geom.h"
#ifndef OP1_HOST
#include "op1_feature.h"
#endif

/* ---------------- colours ---------------- */
static const uint8_t SC_BLUE[4] = { 0x69, 0x8E, 0xFF, 0xFF }, SC_GREEN[4] = { 0x00, 0xED, 0x95, 0xFF },
                     SC_WHITE[4] = { 0xFF, 0xFF, 0xFF, 0xFF }, SC_RED[4] = { 0xFF, 0x3A, 0x5D, 0xFF },
                     SC_LIL[4] = { 0xDF, 0xD9, 0xFF, 0xFF }, SC_MID[4] = { 0xAE, 0xB1, 0xDC, 0xFF },
                     SC_DIM[4] = { 0x6F, 0x71, 0x73, 0xFF };
static const uint8_t *const SC_KNOB[4] = { SC_BLUE, SC_GREEN, SC_WHITE, SC_RED };

static const uint8_t *scr_shade(const uint8_t *c, int32_t f)          /* c x f/256, rotating buffer */
{
    static uint8_t b[16][4];
    static int n;
    uint8_t *o = b[n++ & 15];
    if (f < 0) f = 0; else if (f > 256) f = 256;
    o[0] = (uint8_t)((c[0] * f) >> 8); o[1] = (uint8_t)((c[1] * f) >> 8); o[2] = (uint8_t)((c[2] * f) >> 8); o[3] = 0xFF;
    return o;
}

/* ---------------- text objects ---------------- */
enum { T_TAG, T_PHON, T_GEN, T_PHR, T_NEXT, T_WORD, T_SYL, T_V0, T_L0 = T_V0 + 5, T_PAD = T_L0 + 5, T_LAB = T_PAD + 1,
       T_N = T_LAB + 4 };
static uint32_t sc_tx[T_N][OP1_TEXT_SIZE / 4];
static char sc_shown[T_N][18];
static int sc_made;

/* the stock font draws capitals as icons: everything is shown in lower case */
static void scr_text(int i, const char *src, void *r, int32_t x, int32_t y)
{
    char s[18];
    int n = 0;
    for (; src[n] && n < 17; n++) s[n] = (src[n] >= 'A' && src[n] <= 'Z') ? (char)(src[n] + 32) : src[n];
    s[n] = 0;
    char *sh = sc_shown[i];
    int j = 0;
    for (; s[j] && sh[j]; j++) if (s[j] != sh[j]) break;
    if (s[j] != sh[j]) {                                                /* changed */
        op1_text_set(sc_tx[i], s);
        for (j = 0; s[j]; j++) sh[j] = s[j];
        sh[j] = 0;
    }
    (void)x; (void)y;
    static const int32_t ident[9] = { 1024, 0, 0, 0, 1024, 0, 0, 0, 1024 };
    if (s[0]) op1_text_draw(sc_tx[i], r, ident);
}

/* ---------------- scene transform: cm x 256 -> Q10 px ---------------- */
static int32_t sc_ox, sc_oy, sc_s;                                       /* origin Q10, px per cm Q8 */
static int32_t sc_w;                                                    /* line width scale (Q10 px) */
static inline int32_t SX(int32_t xq8) { return sc_ox + ((xq8 * sc_s) >> 6); }
static inline int32_t SY(int32_t yq8) { return sc_oy - ((yq8 * sc_s) >> 6); }
static int sc_lines;

static void scr_ln(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, const uint8_t *c, int32_t w)   /* Q10 px */
{
    op1_pt a = { x0, y0 }, b = { x1, y1 };
    op1_raster_line(r, &a, &b, w, c);
    sc_lines++;
}
static void scr_lcm(void *r, int32_t x0, int32_t y0, int32_t x1, int32_t y1, const uint8_t *c, int32_t w)   /* cm x 256 */
{
    scr_ln(r, SX(x0), SY(y0), SX(x1), SY(y1), c, w);
}

/* Catmull-Rom through n points (x, y pairs, cm x 256), `ns` segments between points */
static void scr_curve(void *r, const int32_t *p, int n, int ns, const uint8_t *c, int32_t w)
{
    int32_t px = p[0], py = p[1];
    for (int i = 0; i < n - 1; i++) {
        const int32_t *p0 = p + 2 * (i > 0 ? i - 1 : 0), *p1 = p + 2 * i, *p2 = p + 2 * (i + 1),
                      *p3 = p + 2 * (i + 2 < n ? i + 2 : n - 1);
        int32_t ax[4], ay[4];
        for (int k = 0; k < 2; k++) {
            int32_t *a = k ? ay : ax;
            a[0] = p1[k]; a[1] = (p2[k] - p0[k]) >> 1;
            a[2] = (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) >> 1;
            a[3] = (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) >> 1;
        }
        for (int s = 1; s <= ns; s++) {
            const int32_t t = (s << 8) / ns;
            const int32_t x = ((((ax[3] * t >> 8) + ax[2]) * t >> 8) + ax[1]) * t / 256 + ax[0];
            const int32_t y = ((((ay[3] * t >> 8) + ay[2]) * t >> 8) + ay[1]) * t / 256 + ay[0];
            scr_lcm(r, px, py, x, y, c, w);
            px = x; py = y;
        }
    }
}

static inline int32_t scr_sin(int32_t a) { return OP1_SINE_TABLE[a & 8191]; }      /* a: 8192 per turn, Q15 */
static inline int32_t scr_cos(int32_t a) { return OP1_SINE_TABLE[(a + 2048) & 8191]; }
static inline int32_t scr_clamp(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }
static inline int32_t scr_abs(int32_t v) { return v < 0 ? -v : v; }
static uint32_t sc_rng = 0x2545F491u;
static inline uint32_t scr_rnd(void) { sc_rng ^= sc_rng << 13; sc_rng ^= sc_rng >> 17; sc_rng ^= sc_rng << 5; return sc_rng; }

/* ---------------- a polyline path with arc length (cm x 256) ---------------- */
typedef struct { int32_t p[8][2]; int n; int32_t cum[8], inv[8], tx[8], ty[8]; int32_t total; } sc_path_t;
static int32_t scr_len(int32_t dx, int32_t dy)                                  /* |(dx,dy)| within ~4 % */
{
    dx = scr_abs(dx); dy = scr_abs(dy);
    return dx > dy ? dx + ((dy * 3) >> 3) : dy + ((dx * 3) >> 3);
}
static void scr_path_build(sc_path_t *q)
{
    int32_t c = 0;
    for (int i = 0; i + 1 < q->n; i++) {
        const int32_t dx = q->p[i + 1][0] - q->p[i][0], dy = q->p[i + 1][1] - q->p[i][1];
        int32_t l = scr_len(dx, dy);
        if (l < 8) l = 8;
        q->cum[i] = c;
        q->inv[i] = 65536 / l;
        q->tx[i] = (dx * q->inv[i]) >> 8;                                      /* unit tangent, Q8 */
        q->ty[i] = (dy * q->inv[i]) >> 8;
        c += l;
    }
    q->cum[q->n - 1] = c;
    q->total = c;
}
/* the point at distance d: x, y, tangent (tx, ty Q8); returns the segment */
static int scr_path_at(const sc_path_t *q, int32_t d, int32_t *x, int32_t *y, int32_t *tx, int32_t *ty)
{
    int j = 0;
    while (j + 2 < q->n && d >= q->cum[j + 1]) j++;
    int32_t t = ((d - q->cum[j]) * q->inv[j]) >> 0;                            /* Q16 */
    t = scr_clamp(t, 0, 65535);
    *x = q->p[j][0] + (((q->p[j + 1][0] - q->p[j][0]) * t) >> 16);
    *y = q->p[j][1] + (((q->p[j + 1][1] - q->p[j][1]) * t) >> 16);
    *tx = q->tx[j]; *ty = q->ty[j];
    return j;
}

/* half width in px x 16 of a section of log area la (Q8 ln cm2): ~ 1.4 x area, clamped */
static const uint16_t sc_hw_tab[16] = { 6, 10, 16, 26, 43, 70, 90, 128, 128, 128, 128, 128, 128, 128, 128, 128 };
static int32_t scr_half(int32_t la)
{
    const int32_t v = la + 1024;
    if (v <= 0) return sc_hw_tab[0];
    int32_t i = v >> 7;
    if (i > 14) return 128;
    return sc_hw_tab[i] + (((sc_hw_tab[i + 1] - sc_hw_tab[i]) * (v & 127)) >> 7);
}

/* the hard palate's height at x (cm x 256), from the still anatomy (CG_PALATE runs from x = 7.0 back to 2.8) */
static int32_t scr_palate_y(int32_t x)
{
    for (int i = 0; i + 1 < CG_PALATE_N; i++) {
        const int32_t x0 = CG_PALATE[2 * i], x1 = CG_PALATE[2 * i + 2];
        if (x <= x0 && x >= x1) {
            const int32_t y0 = CG_PALATE[2 * i + 1], y1 = CG_PALATE[2 * i + 3];
            return y0 + ((y1 - y0) * (x0 - x)) / (x0 - x1);
        }
    }
    return x > CG_PALATE[0] ? CG_PALATE[1] : CG_PALATE[2 * CG_PALATE_N - 1];
}

/* ---------------- state ---------------- */
#define SC_NP 14
typedef struct {
    uint16_t s; int8_t lane; uint8_t spd;
} sc_part_t;
static sc_part_t sc_part[SC_NP], sc_npart[6];
static int32_t sc_art[7];                                                    /* eased articulators */
static int32_t sc_vel, sc_voice, sc_flow, sc_asp, sc_fric, sc_la[CH_NMAX];
static int sc_n = 22;
static uint32_t sc_seq, sc_arc, sc_trill;
static int sc_hold, sc_mode = -1, sc_prog = -1, sc_prev_genre = -1, sc_prev_seed = -1, sc_first = 1, sc_idle;
static uint8_t sc_ph;
static int32_t sc_pad[12], sc_lastlv;
static int32_t sc_pitch;
static uint16_t sc_glot;
static void *sc_node[4];
static char sc_cache_text[24];

static const char *const sc_ph_names[PH_COUNT] = {
    [PH_AA] = "AA", [PH_AE] = "AE", [PH_AH] = "AH", [PH_AO] = "AO", [PH_AW] = "AW", [PH_AY] = "AY", [PH_EH] = "EH", [PH_ER] = "ER",
    [PH_EY] = "EY", [PH_IH] = "IH", [PH_IY] = "IY", [PH_OW] = "OW", [PH_OY] = "OY", [PH_UH] = "UH", [PH_UW] = "UW", [PH_AX] = "AX",
    [PH_B] = "B", [PH_CH] = "CH", [PH_D] = "D", [PH_DH] = "DH", [PH_F] = "F", [PH_G] = "G", [PH_HH] = "HH", [PH_JH] = "JH",
    [PH_K] = "K", [PH_L] = "L", [PH_M] = "M", [PH_N] = "N", [PH_NG] = "NG", [PH_P] = "P", [PH_R] = "R", [PH_S] = "S",
    [PH_SH] = "SH", [PH_T] = "T", [PH_TH] = "TH", [PH_V] = "V", [PH_W] = "W", [PH_Y] = "Y", [PH_Z] = "Z", [PH_ZH] = "ZH",
};
static const char *const sc_drum[12] = { "KICK", "RIM", "SNARE", "CLAP", "HAT", "TOM LO", "OPEN HAT", "TOM HI", "SHAKER",
                                         "HUM", "DOUBLE", "WAH" };

/* ---------------- phrase helpers ---------------- */
static int scr_is_bound(int c) { return c == PH_WORD || (c >= PH_COMMA && c <= PH_STOP); }

/* syllable `syl` of a phrase: its word number, its place in the word and the word's syllable count */
static void scr_syl_word(const uint8_t *ph, int syl, int *word, int *sinw, int *nsinw)
{
    int w = 0, v = 0, content = 0, wv0 = 0, found = -1, fw = 0, fs = 0;
    for (int p = 0;; p++) {
        const int c = ph[p];
        if (c == PH_END || scr_is_bound(c)) {
            if (found >= 0) { *word = fw; *sinw = fs; *nsinw = v - wv0; return; }
            if (c == PH_END) break;
            if (content) { w++; content = 0; wv0 = v; }
            continue;
        }
        if (c == PH_SYL || c == PH_STRESS) continue;
        content = 1;
        if (ph_is_vowel(c)) {
            if (v == syl) { found = v; fw = w; fs = v - wv0; }
            v++;
        }
    }
    *word = 0; *sinw = 0; *nsinw = 1;
}
static int scr_word_at(const uint8_t *ph, int pos)                               /* the word the code at pos is in */
{
    int w = 0, content = 0;
    for (int p = 0; p < pos && ph[p] != PH_END; p++) {
        if (scr_is_bound(ph[p])) { if (content) { w++; content = 0; } }
        else content = 1;
    }
    return w;
}
/* word number idx of a text (letter runs), upper case, into out */
static int scr_text_word(const char *t, int idx, char *out, int max)
{
    int w = -1, n = 0, in = 0;
    for (int i = 0; t[i]; i++) {
        const char c = t[i];
        const int l = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '\'';
        if (l && !in) { w++; in = 1; }
        else if (!l) in = 0;
        if (l && w == idx && n < max - 1) out[n++] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : c;
    }
    out[n] = 0;
    return n;
}
/* wrap a text into up to `maxl` lines of `cols` characters (upper case); first word number of each line */
static int scr_wrap(const char *t, char lines[][18], int *first, int maxl, int cols)
{
    int nl = 0, n = 0, w = -1, in = 0;
    char word[18]; int wl = 0;
    lines[0][0] = 0; first[0] = 0;
    for (int i = 0;; i++) {
        const char c = t[i];
        const int l = c && c != ' ' && c != ',' && c != '.' && c != '!' && c != '?' && c != '-';
        if (l && wl < 17) word[wl++] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : c;
        if (!l) {
            if (wl) {
                w++;
                if (n && n + 1 + wl > cols) { if (nl + 1 >= maxl) return nl + 1; nl++; lines[nl][0] = 0; n = 0; first[nl] = w; }
                if (!n) first[nl] = w;
                if (n) lines[nl][n++] = ' ';
                for (int k = 0; k < wl && n < cols; k++) lines[nl][n++] = word[k];
                lines[nl][n] = 0;
                wl = 0;
            }
            if (!c) break;
        }
    }
    (void)in;
    return nl + 1;
}

/* ---------------- text entry (firmware only) ---------------- */
#ifndef OP1_HOST
static void scr_te_done(const char *t, int ok)                                   /* main loop */
{
    if (!ok) return;
    int i = 0;
    for (; t[i] && i < OP1_TEXT_MAX && i < CH_TEXT_MAX - 1; i++) {
        char c = t[i];
        if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
        ch_typed[i] = c;
    }
    ch_typed[i] = 0;
    op1_setting_set_str("chimera", "text", ch_typed);
    ch_typed_gen++;
}
static void scr_te_open(void)
{
    static const op1_text_entry_t te = { "LYRICS", ch_typed, "abcdefghijklmnopqrstuvwxyz .,-", OP1_TEXT_MAX, 10, scr_te_done, 0 };
    op1_text_entry(&te);
}
#endif

/* ---------------- poses ---------------- */
/* PLAY / ELEPHANT: what ch_play_shape asks for (articulators only) */
static void scr_play_pose(const int16_t *k, int32_t *art)
{
    int32_t pos = ((int32_t)(k[0] < 0 ? 0 : k[0]) * 4 * 256) >> 15;
    if (pos > 1023) pos = 1023;
    const int s = pos >> 8, mix = pos & 255;
    const int16_t *a = ch_art[ch_path[s]], *b = ch_art[ch_path[s + 1 > 4 ? 4 : s + 1]];
    for (int i = 0; i < 7; i++) art[i] = a[i] + (((b[i] - a[i]) * mix) >> 8);
    const int32_t mouth = ((int32_t)k[1] - 16384) >> 4;
    art[2] += (mouth * 128) >> 10;
    art[3] += (mouth * 192) >> 10;
}

/* ---------------- the head ---------------- */
static void scr_head(void *r, int full, int32_t flow, int32_t pitch_hint)
{
    (void)pitch_hint;
    const int32_t tbX = sc_art[0], tbY = sc_art[1], jaw = scr_clamp(sc_art[2], 0, 480), lipAp = scr_clamp(sc_art[3], 50, 520),
                  prot = scr_clamp(sc_art[4], 0, 400), ttX = sc_art[5], ttY = sc_art[6];
    const int32_t w1 = sc_w, w2 = sc_w * 3 / 4;
    const int32_t p = prot >> 1;
    const int32_t ly = 2266 - lipAp, cy = 1510 - ((jaw * 230) >> 8), ty = 2189 - ((jaw * 243) >> 8);
    int32_t pt[26];

    /* tongue: the dorsum (root, the body's circle of 2 cm, then the blade to the tip) and the underside */
    static const int16_t csn[7][2] = { { -362, -362 }, { -504, -89 }, { -481, 175 }, { -329, 392 }, { -89, 504 }, { 175, 481 }, { 392, 329 } };
    int n = 0;
    pt[n++] = 538; pt[n++] = 590;                                               /* the root, 2.1 cm, 2.3 cm */
    for (int i = 0; i < 7; i++) { pt[n++] = tbX + csn[i][0]; pt[n++] = tbY + csn[i][1]; }
    pt[n++] = (tbX + 392 + ttX) >> 1; pt[n++] = ((tbY + 329 + ttY) >> 1) + 28;
    pt[n++] = ttX; pt[n++] = ttY;
    scr_curve(r, pt, n / 2, 2, SC_RED, w1);
    n = 0;
    pt[n++] = ttX; pt[n++] = ttY;
    pt[n++] = ttX - 115; pt[n++] = ttY - 165;
    pt[n++] = ttX - 460; pt[n++] = scr_clamp(ttY - 330, 1126 - ((jaw * 150) >> 8), 4000);
    pt[n++] = 870; pt[n++] = 947;
    pt[n++] = 627; pt[n++] = 691;
    pt[n++] = 538; pt[n++] = 590;
    scr_curve(r, pt, n / 2, 2, scr_shade(SC_RED, 170), w2);

    /* the lips, chin and jaw line (the jaw lowers the chin and lower lip) */
    n = 0;
    pt[n++] = 2138; pt[n++] = 2560;
    pt[n++] = 2176 + p; pt[n++] = 2445;
    pt[n++] = 2253 + p; pt[n++] = 2342;
    pt[n++] = 2189 + p; pt[n++] = 2278;
    pt[n++] = 2048 + ((p * 4) >> 3) * 1; pt[n++] = 2266;
    scr_curve(r, pt, n / 2, 2, SC_LIL, w1);                                      /* the upper lip */
    n = 0;
    pt[n++] = 2048 + ((p * 4) >> 3); pt[n++] = ly;
    pt[n++] = 2189 + p; pt[n++] = ly - 13;
    pt[n++] = 2253 + p; pt[n++] = ly - 100;
    pt[n++] = 2176 + p; pt[n++] = ly - 218;
    pt[n++] = 2048 + (p >> 2); pt[n++] = ly - 295;
    pt[n++] = 2060; pt[n++] = ((ly - 295 + cy) >> 1);
    pt[n++] = 1990; pt[n++] = cy + 40;
    pt[n++] = 1700; pt[n++] = cy - 60;
    pt[n++] = 1250; pt[n++] = cy - 190;
    pt[n++] = 845; pt[n++] = 794;
    scr_curve(r, pt, n / 2, 2, SC_LIL, w1);                                      /* the lower lip, chin, under the jaw */
    scr_lcm(r, 1920, ty - 205, 1912, ty, SC_LIL, w2);                           /* the lower teeth */
    scr_lcm(r, 1912, ty, 1800, ty, SC_LIL, w2);

    /* the velum: hinged at the palate's rear, drooping to open the nose */
    {
        const int32_t o = scr_clamp(sc_vel, 0, 256);
        const int32_t tx = 38 + (((282 - 38) * o) >> 8), tyv = 2406 + (((1971 - 2406) * o) >> 8);
        pt[0] = 717; pt[1] = 2573;
        pt[2] = (717 + tx) >> 1; pt[3] = ((2573 + tyv) >> 1) - 55;
        pt[4] = tx; pt[5] = tyv;
        pt[6] = tx + 20; pt[7] = tyv - 55;
        scr_curve(r, pt, 4, 2, SC_LIL, w1);
    }

    /* the vocal folds: they open and close with the glottal phase while voiced */
    {
        const int32_t osc = ((32768 + scr_sin((int32_t)sc_glot >> 3)) * 120) >> 16;       /* 0 .. 120 */
        const int32_t vf = scr_clamp(sc_voice >> 4, 0, 256);
        const int32_t gap = 140 - (((140 - (20 + osc)) * vf) >> 8);
        scr_lcm(r, 0, 128, 224 - (gap >> 1), 128, SC_WHITE, w1);
        scr_lcm(r, 448, 128, 224 + (gap >> 1), 128, SC_WHITE, w1);
        if (vf > 40) {                                                          /* pressure over the folds */
            const int32_t a = scr_clamp(vf, 0, 256);
            scr_lcm(r, 140, 190, 308, 190, scr_shade(SC_GREEN, a), w2);
            scr_lcm(r, 170, 250, 278, 250, scr_shade(SC_GREEN, a >> 1), w2);
        }
    }
    if (!full) return;
    (void)flow;
}

/* ---------------- the airway: ladder, particles, sparks, nasal stream, arcs ---------------- */
static void scr_air(void *r, int heavy, int32_t dt)
{
    const int32_t flow = sc_flow;
    if (flow < 250) return;
    const int32_t tbX = sc_art[0], tbY = sc_art[1], ttX = sc_art[5], ttY = sc_art[6];
    const int32_t lipAp = scr_clamp(sc_art[3], 50, 520), ly = 2266 - lipAp;
    sc_path_t q;
    int32_t e = tbX - 512;
    q.n = 6;
    q.p[0][0] = 218; q.p[0][1] = 150;
    int32_t bx = (538 + tbX - 362) >> 2; if (bx < 40) bx = 40;
    q.p[1][0] = bx; q.p[1][1] = 768;
    q.p[2][0] = e > 80 ? e >> 1 : 40; q.p[2][1] = tbY + 90;
    q.p[3][0] = tbX + 60; q.p[3][1] = (tbY + 512 + scr_palate_y(tbX + 60)) >> 1;
    q.p[4][0] = ttX - 90; q.p[4][1] = (ttY + scr_palate_y(ttX - 90)) >> 1;
    q.p[5][0] = 2090; q.p[5][1] = (ly + 2266) >> 1;
    scr_path_build(&q);

    const int n = sc_n > 1 ? sc_n : 22;
    const int32_t step = q.total / (n - 1);
    const int32_t lvl = flow >> 7;                                              /* 0 .. 255 */
    const int32_t pscale = (sc_s * 37) >> 10;                                   /* Q10 px per (px x 16) at this scale */
    int imin = 1;
    int32_t amin = 9999;
    for (int i = 0; i < n; i++) if (i > 0 && i < n - 1 && sc_la[i] < amin) { amin = sc_la[i]; imin = i; }

    /* the ladder: each section's width, brightest where the voice rings */
    if (!heavy) {
        const uint8_t *lc = scr_shade(SC_GREEN, 30 + (lvl >> 2));
        for (int i = 1; i < n; i++) {
            int32_t x, y, tx, ty;
            scr_path_at(&q, i * step - (i == n - 1 ? 8 : 0), &x, &y, &tx, &ty);
            const int32_t hw = scr_clamp(scr_half(sc_la[i]) >> 1, 6, 40);          /* px x 16: ticks of at most 2.5 px */
            const int32_t o = hw * pscale;                                       /* Q10 px */
            const int32_t px = SX(x), py = SY(y);
            const int32_t ox = (-ty * o) >> 8, oy = (tx * o) >> 8;
            scr_ln(r, px - ox, py + oy, px + ox, py - oy, lc, sc_w / 2);
        }
    }
    /* particles through the tract, faster in a narrow section */
    if (!heavy) {
        for (int k = 0; k < SC_NP; k++) {
            sc_part_t *s = &sc_part[k];
            const int sec = scr_clamp(((int32_t)s->s * (n - 1)) >> 16, 0, n - 1);
            const int32_t hw = scr_half(sc_la[sec]);
            const int32_t boost = hw < 24 ? 3 : hw < 48 ? 2 : 1;
            const int32_t adv = (((flow >> 6) + 40) * s->spd >> 8) * dt * boost >> 3;
            s->s = (uint16_t)(s->s + adv);
            int32_t x, y, tx, ty;
            scr_path_at(&q, (int32_t)(((uint32_t)s->s * (uint32_t)q.total) >> 16), &x, &y, &tx, &ty);
            const int32_t off = (s->lane * scr_clamp(hw, 8, 100) * pscale) >> 7;   /* Q10 px */
            const int32_t px = SX(x) + ((-ty * off) >> 8), py = SY(y) - ((tx * off) >> 8);
            const int32_t len = (boost > 1 ? 4 : 2) * 1024;
            const int32_t dx = (tx * len) >> 9, dy = -((ty * len) >> 9);
            scr_ln(r, px - dx, py - dy, px + dx, py + dy, scr_shade(SC_GREEN, 170 + (lvl >> 2) + boost * 20), 0x780);
        }
    }
    /* the constriction: two white ticks and, when it hisses, sparks */
    if (amin < -200 && !heavy) {
        int32_t x, y, tx, ty;
        scr_path_at(&q, imin * step, &x, &y, &tx, &ty);
        const int32_t px = SX(x), py = SY(y);
        const int32_t hw = scr_clamp(scr_half(amin), 8, 60) * 40 + 3000;
        if (sc_fric > 500) {
            const int ns = sc_fric > 2000 ? 6 : 4;
            for (int k = 0; k < ns; k++) {
                const uint32_t rv = scr_rnd();
                const int32_t a = (int32_t)(rv & 8191), l0 = 2000 + (int32_t)((rv >> 13) & 2047), l1 = l0 + 1500 + (int32_t)((rv >> 24) & 1023);
                scr_ln(r, px + ((scr_cos(a) * l0) >> 15), py + ((scr_sin(a) * l0) >> 15), px + ((scr_cos(a) * l1) >> 15),
                       py + ((scr_sin(a) * l1) >> 15), SC_WHITE, 0x480);
            }
        }
        (void)hw;
    }
    /* the nose: a stream of dots through the nasal passage while the velum is open */
    {
        const int32_t o = scr_clamp(sc_vel, 0, 256);
        if (o > 24 && !heavy) {
            sc_path_t nq;
            nq.n = 5;
            static const int16_t np[5][2] = { { 154, 2380 }, { 150, 2830 }, { 1000, 2900 }, { 2000, 2890 }, { 2150, 2830 } };
            for (int i = 0; i < 5; i++) { nq.p[i][0] = np[i][0]; nq.p[i][1] = np[i][1]; }
            scr_path_build(&nq);
            for (int k = 0; k < 6; k++) {
                sc_part_t *s = &sc_npart[k];
                s->s = (uint16_t)(s->s + ((((flow >> 6) + 60) * s->spd >> 8) * dt >> 3));
                int32_t x, y, tx, ty;
                scr_path_at(&nq, (int32_t)(((uint32_t)s->s * (uint32_t)nq.total) >> 16), &x, &y, &tx, &ty);
                const int32_t px = SX(x), py = SY(y) + s->lane * 3;
                scr_ln(r, px - 600, py, px + 600, py, scr_shade(SC_BLUE, (o >> 1) + (lvl >> 1)), 0x500);
            }
        }
    }
    /* sound arcs leaving the lips */
    if (!heavy && sc_s >= 1500) {
        const int32_t cx = SX(2330 + (sc_art[4] >> 1)), cy = SY((ly + 2266) >> 1);
        for (int k = 0; k < 3; k++) {
            const int32_t ph = ((int32_t)sc_arc + k * 85) & 255;
            const int32_t rad = (6 + ((ph * 22) >> 8)) << 10;
            const int32_t f = ((256 - ph) * (flow >> 6)) >> 8;                  /* fades with the radius */
            const uint8_t *c = scr_shade(SC_BLUE, f);
            int32_t px = cx + ((rad * scr_cos(-700)) >> 15), py = cy + ((rad * scr_sin(-700)) >> 15);
            for (int a = -700 + 175; a <= 700; a += 175) {
                const int32_t qx = cx + ((rad * scr_cos(a)) >> 15), qy = cy + ((rad * scr_sin(a)) >> 15);
                scr_ln(r, px, py, qx, qy, c, 0x500);
                px = qx; py = qy;
            }
        }
    }
}

/* ---------------- BIRD ---------------- */
static void scr_bird(void *r, const int16_t *k, int32_t flow)
{
    const int32_t beak = (k[1] < 0 ? 0 : k[1]);
    const int32_t a = 380 + ((beak * 900) >> 15);                               /* 8192 per turn: 16 .. 55 degrees down */
    const int32_t hx = 213 << 10, hy = 55 << 10;
    const int32_t tx = hx + 22 * scr_cos(a - 300) / 32, ty = hy + 22 * scr_sin(a - 300) / 32;
    scr_ln(r, hx, hy, tx, ty, SC_GREEN, 0x680);
    scr_ln(r, tx, ty, 209 << 10, 63 << 10, SC_GREEN, 0x680);
    scr_ln(r, hx, hy, 236 << 10, 53 << 10, scr_shade(SC_LIL, 100), 0x400);          /* the closed seam */
    /* the throat pulses with the voice */
    const int32_t pulse = ((int32_t)sc_glot >> 11);                          /* 0 .. 31 */
    const int32_t lv = flow >> 8;
    for (int ring = 0; ring < 2; ring++) {
        const int32_t rad = (3 + ring * 3) * 1024 + ((lv * (ring ? 6 : 10) * (pulse & 15)) >> 4);
        const uint8_t *c = scr_shade(ring ? SC_GREEN : SC_WHITE, 60 + lv);
        int32_t px = (204 << 10) + rad, py = 64 << 10;
        for (int s = 1; s <= 8; s++) {
            const int32_t ang = s * 1024;
            const int32_t qx = (204 << 10) + ((rad * scr_cos(ang)) >> 15), qy = (64 << 10) + ((rad * scr_sin(ang)) >> 15);
            scr_ln(r, px, py, qx, qy, c, 0x500);
            px = qx; py = qy;
        }
    }
    if (flow > 250) {                                                           /* whistle arcs from the beak */
        const int32_t cx = tx + 2048, cy = ty - 1024;
        for (int j = 0; j < 3; j++) {
            const int32_t ph = ((int32_t)sc_arc + j * 85) & 255;
            const int32_t rad = (5 + ((ph * 20) >> 8)) << 10;
            const uint8_t *c = scr_shade(SC_GREEN, ((256 - ph) * (flow >> 6)) >> 8);
            int32_t px = cx + ((rad * scr_cos(-600)) >> 15), py = cy + ((rad * scr_sin(-600)) >> 15);
            for (int a = -600 + 200; a <= 600; a += 200) {
                const int32_t qx = cx + ((rad * scr_cos(a)) >> 15), qy = cy + ((rad * scr_sin(a)) >> 15);
                scr_ln(r, px, py, qx, qy, c, 0x500);
                px = qx; py = qy;
            }
        }
    }
}

/* ---------------- ELEPHANT: a trunk of two outlines with the airstream through it ---------------- */
static void scr_trunk(void *r, int32_t flow, int32_t dt)
{
    const int32_t lift = (flow * 26) >> 15;
    /* centre line: cubic Bezier (Q10 px) from the root, down, forward and up to the tip */
    const int32_t x0 = 204 << 10, y0 = 73 << 10, x1 = 216 << 10, y1 = 102 << 10, x2 = 240 << 10, y2 = (114 - lift) << 10,
                  x3 = 258 << 10, y3 = (94 - lift * 2) << 10;
    int32_t cxv[9], cyv[9];
    for (int i = 0; i <= 8; i++) {
        const int32_t t = i << 5, u = 256 - t;                                  /* Q8 */
        const int32_t b0 = (u * u >> 8) * u >> 8, b1 = (3 * t * (u * u >> 8)) >> 8, b2 = (3 * u * (t * t >> 8)) >> 8, b3 = (t * t >> 8) * t >> 8;
        cxv[i] = (x0 * b0 + x1 * b1 + x2 * b2 + x3 * b3) >> 8;
        cyv[i] = (y0 * b0 + y1 * b1 + y2 * b2 + y3 * b3) >> 8;
    }
    int32_t lx[9], ly_[9], rx[9], ry[9];
    for (int i = 0; i <= 8; i++) {
        const int j0 = i > 0 ? i - 1 : 0, j1 = i < 8 ? i + 1 : 8;
        int32_t dx = cxv[j1] - cxv[j0], dy = cyv[j1] - cyv[j0];
        const int32_t l = scr_len(dx, dy) | 1;
        dx = (dx * 256) / l; dy = (dy * 256) / l;                                    /* unit, Q8 (9 divisions a frame) */
        int32_t wd = 11 - (i * 7) / 8;                                          /* tapers 11 .. 4 px */
        if (i >= 7) wd += (flow * 5) >> 15;                                      /* the bell of the trumpet */
        const int32_t o = wd * 1024;
        lx[i] = cxv[i] - ((dy * o) >> 8); ly_[i] = cyv[i] + ((dx * o) >> 8);
        rx[i] = cxv[i] + ((dy * o) >> 8); ry[i] = cyv[i] - ((dx * o) >> 8);
    }
    const uint8_t *c = scr_shade(SC_LIL, 230);
    for (int i = 0; i < 8; i++) {
        scr_ln(r, lx[i], ly_[i], lx[i + 1], ly_[i + 1], c, 0x680);
        scr_ln(r, rx[i], ry[i], rx[i + 1], ry[i + 1], c, 0x680);
    }
    scr_ln(r, lx[8], ly_[8], rx[8], ry[8], c, 0x580);                           /* the tip */
    for (int i = 2; i < 8; i += 2) scr_ln(r, lx[i], ly_[i], rx[i], ry[i], scr_shade(SC_DIM, 200), 0x400);   /* skin folds */
    if (flow > 250) {                                                           /* the glow: dots along the tube */
        for (int k = 0; k < 6; k++) {
            sc_part_t *s = &sc_npart[k];
            s->s = (uint16_t)(s->s + ((((flow >> 6) + 60) * s->spd >> 8) * dt >> 3));
            const int32_t t = ((int32_t)s->s * 8) >> 4;                            /* 0 .. 32760 */
            const int i = scr_clamp(t >> 12, 0, 7), f = t & 4095;
            const int32_t px = cxv[i] + (((cxv[i + 1] - cxv[i]) * f) >> 12), py = cyv[i] + (((cyv[i + 1] - cyv[i]) * f) >> 12);
            scr_ln(r, px - 700, py, px + 700, py, scr_shade(SC_GREEN, 140 + (flow >> 8)), 0x680);
        }
        for (int j = 0; j < 3; j++) {                                           /* the call */
            const int32_t ph = ((int32_t)sc_arc + j * 85) & 255;
            const int32_t rad = (6 + ((ph * 24) >> 8)) << 10;
            const uint8_t *cc = scr_shade(SC_BLUE, ((256 - ph) * (flow >> 6)) >> 8);
            int32_t px = cxv[8] + ((rad * scr_cos(-1000)) >> 15), py = cyv[8] + ((rad * scr_sin(-1000)) >> 15);
            for (int a = -1000 + 250; a <= 1000; a += 250) {
                const int32_t qx = cxv[8] + ((rad * scr_cos(a)) >> 15), qy = cyv[8] + ((rad * scr_sin(a)) >> 15);
                scr_ln(r, px, py, qx, qy, cc, 0x500);
                px = qx; py = qy;
            }
        }
    }
}

/* ---------------- BEATBOX pads ---------------- */
static void scr_pads(void *r)
{
    for (int i = 0; i < 12; i++) {
        const int32_t lit = sc_pad[i];
        if (lit < 8) continue;
        const int c = i & 3, rw = i >> 2;
        const int32_t x = (CG_PAD_X0 + c * (CG_PAD_W + CG_PAD_GX)) << 10, y = (CG_PAD_Y0 + (2 - rw) * (CG_PAD_H + CG_PAD_GY)) << 10;
        const int32_t w = CG_PAD_W << 10, h = CG_PAD_H << 10;
        const uint8_t *col = scr_shade(i == 0 || i == 5 ? SC_BLUE : (i & 1) ? SC_GREEN : SC_WHITE, lit);
        scr_ln(r, x, y, x + w, y, col, 0x700); scr_ln(r, x + w, y, x + w, y + h, col, 0x700);
        scr_ln(r, x + w, y + h, x, y + h, col, 0x700); scr_ln(r, x, y + h, x, y, col, 0x700);
        const uint8_t *hc = scr_shade(col, lit >> 1);
        for (int j = 1; j <= 4; j++) {                                           /* the pad fills with hatching */
            const int32_t yy = y + ((h * j) / 5);
            scr_ln(r, x + 3072, yy, x + w - 3072, yy, hc, 0x500);
        }
    }
}

/* ---------------- init / update ---------------- */
static void ch_scr_init(void *scr)
{
    static const char *const ids[4] = { "g_head", "g_beat", "g_bird", "g_trunk" };
    for (int i = 0; i < 4; i++) sc_node[i] = op1_find_node(scr, ids[i]);
    for (int i = 0; i < SC_NP; i++) { sc_part[i].s = (uint16_t)(i * 4681); sc_part[i].lane = (int8_t)(((i * 53) % 255) - 127); sc_part[i].spd = (uint8_t)(150 + (i * 37) % 105); }
    for (int i = 0; i < 6; i++) { sc_npart[i].s = (uint16_t)(i * 10922); sc_npart[i].lane = (int8_t)((i % 3) - 1); sc_npart[i].spd = (uint8_t)(170 + (i * 29) % 85); }
    for (int i = 0; i < 7; i++) sc_art[i] = ch_art[CH_V_SCHWA][i] << 0;
    sc_vel = 0; sc_mode = -1; sc_first = 1;
#ifndef OP1_HOST
    {
        char b[OP1_TEXT_MAX + 1];
        const int n = op1_setting_get_str("chimera", "text", b, (int)sizeof b);
        if (n > 0) {
            int i = 0;
            for (; b[i] && i < CH_TEXT_MAX - 1; i++) ch_typed[i] = b[i];
            ch_typed[i] = 0;
            ch_typed_gen++;
        }
    }
#endif
}

static void ch_scr_update(void *scr, int dt)
{
    const int slot = OP1_SCREEN_SLOT & 7;
    int16_t kk[4];
    op1_synth_knobs_live(slot, kk);
    for (int i = 0; i < 4; i++) if (kk[i] < 0) kk[i] = 0;
    const int16_t *wd = op1_synth_knobs(slot);
    const int prog = ch_prog_of(wd), mode = ch_progs[prog].mode;
    const int heavy = op1_gfx_heavy();
    if (dt < 1) dt = 1; else if (dt > 100) dt = 100;
    int32_t dtn = dt > 64 ? 4 : (dt >> 4) + 1;                                   /* ~1 per 16 ms */

    /* the view: a copy; live while the audio side keeps publishing for this program's mode */
    ch_view_t v;
    {
        const volatile ch_view_t *src = &ch_view;
        v = *(const ch_view_t *)src;
    }
    if (v.seq != sc_seq) { sc_seq = v.seq; sc_hold = 12; } else if (sc_hold) sc_hold--;
    const int live = sc_hold > 0 && v.mode == mode;
    if (live) {
        sc_n = v.n > 0 && v.n <= CH_NMAX ? v.n : 22;
        for (int i = 0; i < sc_n; i++) sc_la[i] += (v.la[i] - sc_la[i]) >> 1;
    }

    /* targets */
    int32_t tgt[7];
    int32_t vel_t, voice_t = 4096, lev_t = 0;
    const int32_t nasal = wd[6] < 0 ? 0 : wd[6];
    vel_t = nasal > 600 ? -800 + ((nasal * 900) >> 15) : -2000;
    if (mode == M_PLAY || mode == M_TRUNK) {
        scr_play_pose(kk, tgt);
        if (mode == M_TRUNK) vel_t = 40;
    } else if (live && (mode == M_SING || mode == M_SPEAK || mode == M_BEAT)) {
        for (int i = 0; i < 7; i++) tgt[i] = v.art[i];
    } else {
        for (int i = 0; i < 7; i++) tgt[i] = ch_art[CH_V_SCHWA][i];
        tgt[2] = 60; tgt[3] = 70;                                               /* a closed mouth at rest */
    }
    if (live) { vel_t = v.velum > -1000 ? v.velum : -2000; voice_t = v.voice; lev_t = v.level * 2; }
    if (lev_t > 32767) lev_t = 32767;
    if (mode == M_BIRD) { if (live) lev_t = v.level * 2 > 32767 ? 32767 : v.level * 2; }
    const int32_t o_t = scr_clamp(((vel_t + 1000) * 262) >> 10, 0, 256);
    const int sh = live ? 1 : 2;
    for (int i = 0; i < 7; i++) sc_art[i] += (tgt[i] - sc_art[i]) >> sh;
    sc_vel += (o_t - sc_vel) >> 1;
    sc_voice += ((live ? voice_t : 0) - sc_voice) >> 1;
    sc_flow += (lev_t - sc_flow) >> 2;
    sc_fric += ((live ? v.fric : 0) - sc_fric) >> 1;
    sc_glot = live ? v.glot : sc_glot;
    sc_arc += (uint32_t)(((sc_flow >> 10) + 3) * dtn);
    if (live) { sc_ph = v.ph; sc_idle = 0; } else if (++sc_idle > 14) sc_ph = 0;
    sc_pitch = live ? v.pitch : 0;

    /* BEATBOX pads: the pad that played lights up and fades */
    for (int i = 0; i < 12; i++) { const int32_t d = (sc_pad[i] >> 2) + 3; sc_pad[i] -= d > sc_pad[i] ? sc_pad[i] : d; }
    if (live && mode == M_BEAT && (v.level > sc_lastlv + 2500 || sc_pad[v.beat % 12] < 8) && v.level > 800) sc_pad[v.beat % 12] = 256;
    sc_lastlv = live ? v.level : 0;

    /* lyrics (SING / SPEAK) and the typed-text entry */
    int genre = 0, seed = 0;
    const ch_lyr_t *ly = &ch_lyr[ch_lyr_cur];
    if (mode == M_SING || mode == M_SPEAK) {
        genre = ch_genre_of(kk); seed = (int)ch_seed_of(kk);
        ch_lyr_update(genre, (uint32_t)seed);
        ly = &ch_lyr[ch_lyr_cur];
#ifndef OP1_HOST
        const int rg = ch_genre_of(wd), rs = (int)ch_seed_of(wd);              /* the raw words: an LFO must not open it */
        if (mode == sc_mode && !sc_first && rg == CH_TYPED_GENRE && (sc_prev_genre != CH_TYPED_GENRE || rs != sc_prev_seed)) scr_te_open();
        sc_prev_genre = rg; sc_prev_seed = rs;
#endif
    } else sc_prev_genre = -1;

    /* the scene: which still group shows */
    if (mode != sc_mode) {
        static const uint8_t grp[M_MODES] = { 0, 0, 0, 1, 2, 3 };
        for (int i = 0; i < 4; i++) if (sc_node[i]) op1_node_set_visible(sc_node[i], i == grp[mode]);
        sc_mode = mode;
    }
    sc_prog = prog;
    sc_first = 0;
    sc_lines = 0;

    op1_screen_draw(scr, dt);
    void *r = op1_raster();
    static const int32_t TXT[T_N][4] = {                                         /* x, y, size, colour (0 mid 1 white 2 blue 3 green 4 dim 5 lil) */
        [T_TAG] = { 6, 14, 9, 0 }, [T_PHON] = { 6, 30, 20, 1 }, [T_GEN] = { 6, 62, 10, 2 }, [T_PHR] = { 6, 75, 10, 3 },
        [T_NEXT] = { 226, 14, 9, 4 }, [T_WORD] = { 226, 26, 12, 3 }, [T_SYL] = { 226, 40, 9, 1 },
        [T_V0] = { 8, 32, 12, 0 }, [T_V0 + 1] = { 24, 32, 12, 0 }, [T_V0 + 2] = { 40, 32, 12, 0 }, [T_V0 + 3] = { 56, 32, 12, 0 },
        [T_V0 + 4] = { 72, 32, 12, 0 },
        [T_L0] = { 226, 52, 9, 5 }, [T_L0 + 1] = { 226, 63, 9, 5 }, [T_L0 + 2] = { 226, 74, 9, 5 }, [T_L0 + 3] = { 226, 85, 9, 5 },
        [T_L0 + 4] = { 226, 96, 9, 5 },
        [T_PAD] = { 146, 14, 12, 1 },
        [T_LAB] = { 8, 127, 10, 2 }, [T_LAB + 1] = { 88, 127, 10, 3 }, [T_LAB + 2] = { 168, 127, 10, 1 }, [T_LAB + 3] = { 248, 127, 10, 6 },
    };
    if (!sc_made) {
        static const uint8_t *const cols[7] = { SC_MID, SC_WHITE, SC_BLUE, SC_GREEN, SC_DIM, SC_LIL, SC_RED };
        for (int i = 0; i < T_N; i++) { op1_text_ctor(sc_tx[i], TXT[i][0] << 10, TXT[i][1], TXT[i][2], cols[TXT[i][3]]); sc_shown[i][0] = 0; }
        sc_made = 1;
    }

    /* ---- the scene ---- */
    sc_w = 0x680;
    if (mode == M_PLAY || mode == M_SING || mode == M_SPEAK || mode == M_BEAT) {
        const int full = mode != M_BEAT;
        if (full) { sc_ox = CG_FULL_OX_Q10; sc_oy = CG_FULL_OY_Q10; sc_s = CG_FULL_S_Q8; }
        else { sc_ox = CG_BEAT_OX_Q10; sc_oy = CG_BEAT_OY_Q10; sc_s = CG_BEAT_S_Q8; sc_w = 0x560; }
        scr_head(r, full, sc_flow, 0);
        scr_air(r, heavy, dtn);
        if (mode == M_BEAT) scr_pads(r);
    } else if (mode == M_BIRD) {
        scr_bird(r, kk, sc_flow);
    } else {
        scr_trunk(r, sc_flow, dtn);
    }

    /* ---- text ---- */
    char b[24];
    scr_text(T_TAG, ch_progs[prog].name, r, 0, 0);
    if (mode == M_PLAY || mode == M_TRUNK) {
        static const char *const vl[5] = { "u", "o", "a", "e", "i" };
        for (int i = 0; i < 5; i++) scr_text(T_V0 + i, vl[i], r, 0, 0);
        const int32_t pos = scr_clamp(((int32_t)kk[0] * 4 * 256) >> 15, 0, 1023);
        const int32_t mx = (11 << 10) + (pos << 6);
        scr_ln(r, mx - 3072, 49 << 10, mx + 3072, 49 << 10, SC_WHITE, 0x800);
    } else if (mode == M_SING || mode == M_SPEAK) {
        scr_text(T_PHON, sc_ph && sc_ph < PH_COUNT && sc_ph_names[sc_ph] ? sc_ph_names[sc_ph] : "", r, 0, 0);
        scr_text(T_GEN, genre == CH_TYPED_GENRE ? "TYPED" : ch_genre_name(genre), r, 0, 0);
        { int n = 0; b[n++] = '#'; int s1 = seed + 1; if (s1 >= 100) b[n++] = (char)('0' + s1 / 100); if (s1 >= 10) b[n++] = (char)('0' + (s1 / 10) % 10); b[n++] = (char)('0' + s1 % 10); b[n] = 0; }
        scr_text(T_PHR, b, r, 0, 0);
        /* the word: SING the next syllable's, SPEAK the one being said */
        int word = 0, sinw = 0, nsinw = 1;
        if (mode == M_SING) {
            int p = ch_sing_pos; if (p >= ly->nsyl) p = 0;
            scr_syl_word(ly->ph, p, &word, &sinw, &nsinw);
        } else {
            int bestage = 0x7fffffff, pos = 0;
            for (int i = 0; i < OP1_VOICES; i++)
                if (ch_v[i].live && !ch_v[i].done && ch_v[i].mode == M_SPEAK && (int)ch_v[i].age < bestage) { bestage = (int)ch_v[i].age; pos = ch_v[i].art.pos; }
            word = live || bestage != 0x7fffffff ? scr_word_at(ly->ph, pos) : 0;
        }
        char wbuf[14];
        scr_text_word(ly->text, word, wbuf, sizeof wbuf - 2);
        const int showing = mode == M_SING || live || sc_hold;
        scr_text(T_NEXT, mode == M_SING ? "NEXT" : (showing ? "SAYING" : "PHRASE"), r, 0, 0);
        scr_text(T_WORD, mode == M_SING || showing ? wbuf : "", r, 0, 0);
        if (mode == M_SING && nsinw > 1) { b[0] = (char)('0' + sinw + 1); b[1] = '/'; b[2] = (char)('0' + nsinw); b[3] = 0; scr_text(T_SYL, b, r, 0, 0); }
        else scr_text(T_SYL, "", r, 0, 0);
        char lines[5][18]; int first[5];
        const int nl = scr_wrap(ly->text, lines, first, 5, 15);
        int mline = 0;
        for (int i = 0; i < nl; i++) if (first[i] <= word) mline = i;
        for (int i = 0; i < 5; i++) scr_text(T_L0 + i, i < nl ? lines[i] : "", r, 0, 0);
        if (nl) {                                                               /* a marker at the word's line */
            const int32_t my = (52 + 11 * mline + 4) << 10;
            scr_ln(r, 219 << 10, my - 2048, 222 << 10, my, SC_GREEN, 0x600);
            scr_ln(r, 222 << 10, my, 219 << 10, my + 2048, SC_GREEN, 0x600);
        }
    } else if (mode == M_BEAT) {
        int pad = live ? v.beat % 12 : -1;
        int best = 0;
        for (int i = 0; i < 12; i++) if (sc_pad[i] > sc_pad[best]) best = i;
        if (sc_pad[best] > 40) pad = best;
        scr_text(T_PAD, pad >= 0 ? sc_drum[pad] : "", r, 0, 0);
    }
    static const char *const p2n[3] = { "PROGRAM", "NASAL", "GRIT" };
    for (int i = 0; i < 4; i++) {
        const char *nm = i < 3 && op1_eng_page[i] ? p2n[i] : ch_knob_names[mode][i];
        scr_text(T_LAB + i, nm, r, 0, 0);
    }
}

const op1_screen_t SCREEN_chimera = { ch_scr_init, ch_scr_update };
