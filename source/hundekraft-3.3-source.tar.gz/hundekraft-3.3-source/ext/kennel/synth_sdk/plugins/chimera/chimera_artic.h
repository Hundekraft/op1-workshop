/* chimera_artic.h: chimera's articulation scheduler. A voice plays a string of phoneme codes (chimera_phon.h): each
 * phoneme is a gesture of a few blocks that sets the tract's target areas (a vowel's shape, with a consonant's
 * constriction laid over the vowel next to it, so the tongue keeps moving toward the vowel through the consonant),
 * the voicing, aspiration, frication, the velum and a pitch offset (speech prosody). SING, SPEAK and BEATBOX use it;
 * PLAY sets its targets from the knobs instead. Per block, on the audio thread: no division, small loops.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef CHIMERA_ARTIC_H
#define CHIMERA_ARTIC_H
#include <stdint.h>
#include "chimera_phon.h"
#include "chimera_tables.h"

/* vowel code -> table vowel (start, end: diphthongs glide from one to the other) */
static const uint8_t ch_vmap[PH_NVOWEL][2] = {
    { CH_V_A, CH_V_A },   /* AA */  { CH_V_AE, CH_V_AE }, /* AE */  { CH_V_UH, CH_V_UH }, /* AH */
    { CH_V_OH, CH_V_OH }, /* AO */  { CH_V_A, CH_V_UU },  /* AW */  { CH_V_A, CH_V_IH },  /* AY */
    { CH_V_EH, CH_V_EH }, /* EH */  { CH_V_ER, CH_V_ER }, /* ER */  { CH_V_E, CH_V_IH },  /* EY */
    { CH_V_IH, CH_V_IH }, /* IH */  { CH_V_I, CH_V_I },   /* IY */  { CH_V_O, CH_V_UU },  /* OW */
    { CH_V_OH, CH_V_IH }, /* OY */  { CH_V_UU, CH_V_UU }, /* UH */  { CH_V_U, CH_V_U },   /* UW */
    { CH_V_SCHWA, CH_V_SCHWA },                                                              /* AX */
};

/* consonants: place along the tract (0 glottis .. 255 lips), constriction log area (Q8 ln cm2; <= -700 a closure),
 * duration (blocks of 1.45 ms), flags, frication level (Q12 of the noise), voicing during the gesture (Q12) */
enum { CF_STOP = 1, CF_NASAL = 2, CF_ROUND = 4, CF_ASP = 8, CF_AFFR = 16, CF_GLIDE = 32, CF_SPREAD = 64 };
typedef struct { uint8_t place; int16_t area; uint8_t dur, flags; uint16_t fric, voice; uint8_t vow; } ch_cons_t;
#define CV_NONE 0xFF
static const ch_cons_t ch_cons[PH_COUNT - PH_B] = {
    /* B  */ { 255, -800, 40, CF_STOP,               300,  1600, CV_NONE },
    /* CH */ { 205, -800, 70, CF_STOP | CF_AFFR | CF_ROUND, 3000, 0, CV_NONE },
    /* D  */ { 222, -800, 36, CF_STOP,               500,  1600, CV_NONE },
    /* DH */ { 236, -380, 40, 0,                     900,  1600, CV_NONE },
    /* F  */ { 255, -560, 70, 0,                    2600,     0, CV_NONE },
    /* G  */ { 160, -800, 40, CF_STOP,               500,  1600, CV_NONE },
    /* HH */ { 255,  999, 55, CF_ASP,                  0,     0, CV_NONE },
    /* JH */ { 205, -800, 60, CF_STOP | CF_AFFR | CF_ROUND, 2000, 2400, CV_NONE },
    /* K  */ { 160, -800, 55, CF_STOP | CF_ASP,     1500,     0, CV_NONE },
    /* L  */ { 222, -260, 45, CF_GLIDE,                0,  4096, CV_NONE },
    /* M  */ { 255, -800, 55, CF_NASAL,                0,  4096, CV_NONE },
    /* N  */ { 222, -800, 50, CF_NASAL,                0,  4096, CV_NONE },
    /* NG */ { 160, -800, 55, CF_NASAL,                0,  4096, CV_NONE },
    /* P  */ { 255, -800, 55, CF_STOP | CF_ASP,      800,     0, CV_NONE },
    /* R  */ { 195, -230, 45, CF_GLIDE | CF_ROUND,     0,  4096, CH_V_ER },
    /* S  */ { 225, -640, 80, CF_SPREAD,            4096,     0, CV_NONE },
    /* SH */ { 205, -420, 80, CF_ROUND,             3600,     0, CV_NONE },
    /* T  */ { 222, -800, 50, CF_STOP | CF_ASP,     1800,     0, CV_NONE },
    /* TH */ { 236, -420, 70, 0,                    1200,     0, CV_NONE },
    /* V  */ { 255, -520, 45, 0,                    1300,  1600, CV_NONE },
    /* W  */ { 255, -380, 40, CF_GLIDE | CF_ROUND,     0,  4096, CH_V_U },
    /* Y  */ { 190, -300, 35, CF_GLIDE,                0,  4096, CH_V_I },
    /* Z  */ { 225, -640, 60, CF_SPREAD,            2600,  1400, CV_NONE },
    /* ZH */ { 205, -420, 60, CF_ROUND,             2400,  1400, CV_NONE },
};

/* the voice's articulation state (one per voice; the phoneme string is the voice's own copy) */
enum { AP_RUN, AP_HOLD, AP_CODA, AP_REL, AP_DONE };
typedef struct {
    uint8_t seq[CH_PHRASE_MAX];
    uint8_t len, pos, phase, cur;            /* codes, the gesture being played, AP_*, its code */
    uint8_t stress, final, hold_vowel, nv;   /* stressed vowel now, final contour (PH_QUEST / PH_STOP), SING */
    uint16_t tmr, dur;                       /* blocks left / total of the gesture */
    uint8_t vow0, vow1, prev_vow, next_vow;  /* vowel targets: this gesture's (start / end), neighbours */
    int16_t pitch, pitch_tgt;                /* prosody, Q8 semitones */
    uint8_t syl, nsyl, speed;                /* syllable number for prosody, count, speed Q4 (16 = normal) */
    uint8_t intone;                          /* intonation depth Q4 (16 = normal, 0 = monotone) */
} ch_art_t;

/* what a gesture asks of the tract this block */
typedef struct {
    uint8_t v0, v1;                          /* vowel shape (blend v0 -> v1 by mix, Q8) */
    int16_t mix;
    int16_t place, area;                     /* constriction section (-1 none) and its log area */
    int16_t voice, asp, fric;                /* Q12 */
    int16_t velum;                           /* log area Q8, <= -1000 closed */
    int16_t rate;                            /* area glide per block, Q8 */
    uint8_t round, spread;
} ch_gest_t;

static int ch_next_vowel(const ch_art_t *a, int from)
{
    for (int i = from; i < a->len; i++) if (ph_is_vowel(a->seq[i])) return a->seq[i] - PH_VOWEL0;
    return -1;
}

/* the next real gesture from a->pos (markers set flags); 0 when the string is done */
static int ch_art_advance(ch_art_t *a)
{
    while (a->pos < a->len) {
        int c = a->seq[a->pos++];
        if (c == PH_STRESS) { a->stress = 1; continue; }
        if (c == PH_QUEST || c == PH_STOP) { a->final = (uint8_t)c; continue; }
        if (c == PH_SYL || c == PH_WORD) continue;
        if (c == PH_COMMA) { a->cur = PH_COMMA; a->dur = a->tmr = (uint16_t)((120u * 16u) / a->speed); return 1; }
        a->cur = (uint8_t)c;
        int nv = ch_next_vowel(a, a->pos);
        if (ph_is_vowel(c)) {
            int v = c - PH_VOWEL0;
            a->vow0 = ch_vmap[v][0]; a->vow1 = ch_vmap[v][1];
            a->prev_vow = a->vow1;
            int base = a->stress ? 125 : (v == PH_AX - PH_VOWEL0 ? 55 : 85);   /* blocks: 180 / 80 / 120 ms */
            if (ch_vmap[v][0] != ch_vmap[v][1]) base += 30;
            if (nv < 0) base += 50;                                          /* phrase-final lengthening */
            a->dur = a->tmr = (uint16_t)((uint32_t)base * 16u / a->speed);
            /* prosody: a stressed syllable starts high; declination over the phrase; the final contour */
            int st = (a->stress ? 3 * 256 : 0) - (int)a->syl * 256 * 2 / (a->nsyl ? a->nsyl : 1);
            if (nv < 0) st += a->final == PH_QUEST ? 5 * 256 : -3 * 256;
            a->pitch_tgt = (int16_t)((st * a->intone) >> 4);
            a->syl++; a->stress = 0;
        } else {
            const ch_cons_t *k = &ch_cons[c - PH_B];
            a->dur = a->tmr = (uint16_t)((uint32_t)k->dur * 16u / a->speed);
            a->next_vow = nv >= 0 ? ch_vmap[nv][0] : a->prev_vow;
        }
        return 1;
    }
    return 0;
}

static void ch_art_start(ch_art_t *a, const uint8_t *seq, int len, int speed, int intone, int hold)
{
    int n = len < CH_PHRASE_MAX ? len : CH_PHRASE_MAX - 1;
    for (int i = 0; i < n; i++) a->seq[i] = seq[i];
    a->seq[n] = PH_END;
    a->len = (uint8_t)n; a->pos = 0; a->phase = AP_RUN; a->stress = 0; a->final = 0; a->syl = 0;
    a->nsyl = 0;
    for (int i = 0; i < n; i++) a->nsyl += ph_is_vowel(seq[i]);
    a->speed = (uint8_t)(speed < 4 ? 4 : speed > 64 ? 64 : speed);
    a->intone = (uint8_t)intone; a->hold_vowel = (uint8_t)hold;
    a->pitch = 0; a->pitch_tgt = 0;
    int v = ch_next_vowel(a, 0);
    a->prev_vow = a->next_vow = v >= 0 ? ch_vmap[v][0] : CH_V_SCHWA;
    a->tmr = 0;
    if (!ch_art_advance(a)) a->phase = AP_DONE;
}

/* one block: the gesture's targets in g; gate = the key is held (SING holds its vowel while it is) */
static void ch_art_block(ch_art_t *a, int gate, ch_gest_t *g)
{
    g->place = -1; g->area = 0; g->velum = -2000; g->round = 0; g->spread = 0; g->rate = 40;
    g->voice = 4096; g->asp = 0; g->fric = 0; g->mix = 0;
    a->pitch += (a->pitch_tgt - a->pitch) >> 3;
    if (a->phase == AP_DONE) { g->v0 = g->v1 = a->prev_vow; g->voice = 0; return; }
    int c = a->cur;
    uint32_t el = (uint32_t)(a->dur - a->tmr);              /* blocks into the gesture */
    if (c == PH_COMMA) {
        g->v0 = g->v1 = a->prev_vow; g->voice = 0;
    } else if (ph_is_vowel(c)) {
        g->v0 = a->vow0; g->v1 = a->vow1;
        if (a->vow0 != a->vow1) {                          /* a diphthong glides over its first 75 % (one division a block) */
            uint32_t m = (el * 340u) / (a->dur ? a->dur : 1u);
            g->mix = (int16_t)(m > 256 ? 256 : m);
        }
        /* SING: the vowel holds while the key is down, after its glide */
        if (a->hold_vowel && gate && a->tmr <= 1) { a->tmr = 1; a->phase = AP_HOLD; if (a->vow0 != a->vow1) g->mix = 256; }
    } else {
        const ch_cons_t *k = &ch_cons[c - PH_B];
        int vow = k->vow != CV_NONE ? k->vow : (a->next_vow != CV_NONE ? a->next_vow : a->prev_vow);
        g->v0 = g->v1 = (uint8_t)vow;
        g->place = k->place; g->area = k->area;
        g->round = (k->flags & CF_ROUND) != 0; g->spread = (k->flags & CF_SPREAD) != 0;
        g->voice = (int16_t)k->voice; g->fric = (int16_t)k->fric;
        g->rate = 110;
        if (k->flags & CF_NASAL) g->velum = -150;
        if (k->flags & CF_GLIDE) g->rate = 70;
        if (c == PH_HH) { g->place = -1; g->voice = 0; g->asp = 2600; }
        if (k->flags & CF_STOP) {
            /* closure for the first 70 %, then the release: the burst (frication) and, for /p t k/, aspiration */
            uint32_t rel = (uint32_t)a->dur * 7u / 10u;
            if (el < rel) { g->fric = 0; if (!(k->flags & CF_AFFR)) g->voice = (int16_t)(k->voice >> 1); }
            else {
                g->area = (int16_t)(k->flags & CF_AFFR ? -420 : -200); g->rate = 200;
                if (k->flags & CF_ASP) { g->asp = 2000; g->voice = 0; }
                if (!(k->flags & CF_AFFR) && el > rel + 6) g->fric = 0;
            }
        }
    }
    if (a->tmr) a->tmr--;
    if (a->tmr == 0 && a->phase != AP_HOLD) {
        if (!ch_art_advance(a)) a->phase = gate && a->hold_vowel ? AP_HOLD : AP_DONE;
    }
    if (a->phase == AP_HOLD && !gate) {                    /* SING: the key is up, sing the coda */
        a->phase = AP_CODA; a->tmr = 0;
        if (!ch_art_advance(a)) a->phase = AP_DONE;
    }
}
#endif
