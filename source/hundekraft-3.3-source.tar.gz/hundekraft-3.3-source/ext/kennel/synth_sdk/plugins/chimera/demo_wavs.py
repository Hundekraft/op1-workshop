#!/usr/bin/env python3
"""Turn chimera_demo's hex stream (88.2 kHz int16 per demo) into 44.1 kHz WAV files and measure the vowel formants.

    python3 demo_wavs.py STREAM.txt OUTDIR [--label host|bcore]

The 2:1 step is scipy's polyphase low-pass (resample_poly), a stand-in for R246's decimator, not it.
Formants: LPC (order 2 + fs/1000 on the 11.025 kHz-resampled middle 0.5 s, pre-emphasised, Hamming), the roots'
frequencies above 90 Hz with bandwidth under 600 Hz; written to OUTDIR/formants.json for the vowel-* demos.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import json
import sys
import wave
from pathlib import Path

import numpy as np
from scipy.signal import resample_poly, lfilter


def parse(path):
    demos, name, buf = {}, None, []
    for line in open(path):
        line = line.strip()
        if line.startswith('WAV '):
            name, buf = line[4:], []
        elif line == 'END':
            demos[name] = ''.join(buf); name = None
        elif name is not None and line:
            buf.append(line)
    out = {}
    for k, h in demos.items():
        a = np.frombuffer(bytes.fromhex(h), dtype='>u2').astype(np.int32)
        a = np.where(a >= 32768, a - 65536, a)
        out[k] = a.astype(np.float64)
    return out


def write_wav(path, x44):
    y = np.clip(np.round(x44), -32768, 32767).astype('<i2')
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(44100); w.writeframes(y.tobytes())


def lpc_formants(x, fs):
    x = resample_poly(x, 1, 8) if fs == 88200 else x
    fs2 = fs / 8
    mid = len(x) // 2
    seg = x[mid - int(0.25 * fs2): mid + int(0.25 * fs2)]
    seg = lfilter([1, -0.9], [1], seg) * np.hamming(len(seg))
    order = 2 + int(fs2 / 1000)
    r = np.correlate(seg, seg, 'full')[len(seg) - 1: len(seg) + order]
    # Levinson
    a = np.zeros(order + 1); a[0] = 1; e = r[0]
    for i in range(1, order + 1):
        k = -(r[i] + np.dot(a[1:i], r[i - 1:0:-1])) / e
        a[1:i + 1] = a[1:i + 1] + k * np.r_[a[i - 1:0:-1], 1]
        e *= 1 - k * k
    roots = [z for z in np.roots(a) if z.imag > 0]
    fb = sorted((np.angle(z) * fs2 / (2 * np.pi), -np.log(abs(z)) * fs2 / np.pi) for z in roots)
    return [round(f) for f, b in fb if f > 90 and b < 600][:4]


def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    demos = parse(src)
    form = {}
    for k, x in demos.items():
        y = resample_poly(x, 1, 2)
        write_wav(out / f'{k}.wav', y)
        pk = np.max(np.abs(y)) if len(y) else 0
        print(f'{k:28s} {len(y) / 44100:5.2f} s peak {pk:6.0f} rms {np.sqrt(np.mean(y * y)):6.0f}')
        if k.startswith(('vowel-', 'whisper-', 'low-')):
            form[k] = lpc_formants(x, 88200)
    (out / 'formants.json').write_text(json.dumps(form, indent=1))
    for k, v in form.items():
        print(k, v)


if __name__ == '__main__':
    main()
