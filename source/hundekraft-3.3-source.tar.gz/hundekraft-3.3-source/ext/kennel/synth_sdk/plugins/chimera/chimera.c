/* chimera: a singing vocal tract for the OP-1 (kennel synth engine). A physically modelled voice after CHIMERA
 * (github.com/jamesondh/chimera-vocal-synth, MIT): a glottal pulse through a Kelly-Lochbaum tract with a nose
 * (chimera_dsp.h); vowel shapes fitted to CHIMERA's calibrated formant targets (gen_tables.py); consonants as gestures
 * laid over the vowels (chimera_artic.h); English text to phonemes on the device (chimera_text.h) and a phrase
 * generator in 16 genres (chimera_lyrics.h).
 *
 * Programs (blue, page 2, 16 steps; chimera_view.h): PLAY / SING / SPEAK in a man's, woman's or child's tract (SPEAK's
 * third is a robot), BEATBOX, BIRD, ELEPHANT.
 *   PLAY     blue vowel u-o-a-e-i, green mouth, white breath, orange vibrato
 *   SING     blue genre (top: typed text), green phrase; each key sings the phrase's next syllable at its pitch, the
 *            vowel held while the key is down, the closing consonants after it is let go; white breath, orange vibrato
 *   SPEAK    blue genre, green phrase; each key speaks the whole phrase at its pitch; white speed, orange melody
 *   BEATBOX  the twelve keys of an octave are twelve mouth drums; blue size, green punch, white noise, orange tune
 *   BIRD     a syrinx's whistle through a beak two octaves up: blue trill, green beak, white breath, orange chirp
 *   ELEPHANT a lip buzz through the nose an octave down: PLAY's knobs, orange the trumpet's swoop
 * Page 2 (encoder press): blue program, green nasal (velum), white grit (pressed voice .. vocal fry).
 * The engine shapes its own level (plugin.json own_envelope): a SING coda or a SPEAK phrase goes on after the key.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 * Vowel data: CHIMERA, Copyright (c) 2026 Jameson Hodge, MIT licence (PROVENANCE.md). */
#include "op1_plugin.h"
#ifndef CH_PROF
#define CH_PROF(n) ((void)0)                  /* chimera_demo.c CH_MODE_PROF: cycle stamps per stage */
#endif
#include "chimera_dsp.h"
#include "chimera_artic.h"
#include "chimera_view.h"
#include "chimera_text.h"
#include "chimera_lyrics.h"

typedef struct {
    ch_tract_t tr;
    ch_art_t art;
    int32_t env, env_prev;            /* own envelope, Q15 */
    int32_t voice_s, asp_s, fric_s, vel_s;   /* smoothed source controls (Q12, velum Q8) */
    uint32_t age;                     /* blocks since note on */
    uint32_t base;                    /* fixed glottal step (BEATBOX drums), 0 = the key's pitch */
    uint32_t trph;                    /* the bird's trill phase */
    int16_t pitch;                    /* onset pitch offset (chirp, swoop, kick drop), Q8 semitones, decays */
    int32_t lim;                      /* a soft limiter's gain, Q12: loud resonances (nasals, low voices) duck */
    uint8_t prog, mode, body, gate, live, done, pad_no, rel, pad_pending;
} ch_vs_t;
static ch_vs_t ch_v[OP1_VOICES];
static volatile ch_view_t ch_view;

/* ---------------- lyrics: the phrase for (genre, seed), two buffers published by index ---------------- */
typedef struct { uint8_t ph[CH_PHRASE_MAX]; char text[CH_TEXT_MAX]; uint8_t nsyl; uint32_t key; } ch_lyr_t;
#define CH_LA PH_L, PH_STRESS, PH_AA, PH_WORD
static ch_lyr_t ch_lyr[2] = {                   /* until a screen has made the phrase: "la" eight times */
    { { CH_LA, CH_LA, CH_LA, CH_LA, CH_LA, CH_LA, CH_LA, PH_L, PH_STRESS, PH_AA, PH_END }, "la la la la la la la la", 8, 0 },
};
static volatile uint8_t ch_lyr_cur, ch_lyr_busy;
static volatile uint8_t ch_sing_pos;           /* SING: the syllable the next key sings */

static char ch_typed[CH_TEXT_MAX] = "hello from the op one";
static volatile uint32_t ch_typed_gen = 1;      /* bumps when the typed text changes */

static int ch_genre_of(const int16_t *params)  { int g = (int)(((int32_t)(params[0] < 0 ? 0 : params[0]) * 17) >> 15); return g > 16 ? 16 : g; }
static uint32_t ch_seed_of(const int16_t *params) { return (uint32_t)(params[1] < 0 ? 0 : params[1]) >> 8; }   /* 128 phrases */

/* make the phrase current (key thread or GUI thread; never the audio thread): 1 if it changed */
static int ch_lyr_update(int genre, uint32_t seed)
{
    uint32_t key = (uint32_t)genre << 24 | seed << 8 | (genre == CH_TYPED_GENRE ? (ch_typed_gen & 255) : 0) | 0x80000000u;
    if (ch_lyr[ch_lyr_cur].key == key || ch_lyr_busy) return 0;
    ch_lyr_busy = 1;
    ch_lyr_t *l = &ch_lyr[ch_lyr_cur ^ 1];
    if (genre == CH_TYPED_GENRE) {
        int i = 0;
        for (; i < CH_TEXT_MAX - 1 && ch_typed[i]; i++) l->text[i] = ch_typed[i];
        l->text[i] = 0;
    } else {
        ch_phrase(genre, seed * 2654435761u + (uint32_t)genre, l->text, CH_TEXT_MAX);
    }
    if (ch_g2p_text(l->text, l->ph, CH_PHRASE_MAX) < 0) l->ph[CH_PHRASE_MAX - 1] = PH_END;
    l->nsyl = (uint8_t)ch_syllables(l->ph);
    if (!l->nsyl) {                                   /* nothing singable (typed digits only): "la" */
        l->ph[0] = PH_L; l->ph[1] = PH_AA; l->ph[2] = PH_END; l->nsyl = 1;
    }
    l->key = key;
    ch_lyr_cur ^= 1;
    ch_sing_pos = 0;
    ch_lyr_busy = 0;
    return 1;
}

static int ch_is_mark(int c) { return c == PH_SYL || c == PH_WORD || (c >= PH_COMMA && c <= PH_STOP); }

/* syllable i (0 = the first) of a phrase into out: its codes and PH_STRESS, no boundaries; returns the count */
static int ch_syllable(const uint8_t *ph, int i, uint8_t *out, int max)
{
    int p = 0, k = 0, n = 0;
    while (k < i && ph[p] != PH_END) {                /* skip i syllables: past the i-th vowel and its coda */
        if (ph_is_vowel(ph[p])) {
            k++; p++;
            while (ph[p] != PH_END && !ch_is_mark(ph[p])) p++;
        } else p++;
    }
    while (ch_is_mark(ph[p])) p++;
    int seen = 0;
    for (; ph[p] != PH_END && n < max - 1; p++) {
        int c = ph[p];
        if (ch_is_mark(c)) break;
        if (ph_is_vowel(c)) { if (seen) break; seen = 1; }
        out[n++] = (uint8_t)c;
    }
    out[n] = PH_END;
    return n;
}

/* ---------------- BEATBOX: twelve mouth drums (phoneme strings, fixed pitch in Hz, speed Q4, start pitch) ------- */
typedef struct { uint8_t ph[4]; uint16_t hz; uint8_t speed; int8_t drop; } ch_drum_t;
static const ch_drum_t ch_drums[12] = {
    { { PH_B, PH_UW, PH_END }, 62, 40, 14 },          /* C  kick: "bu" with a falling pitch */
    { { PH_K, PH_END }, 0, 48, 0 },                   /* C# rim: a "k" click */
    { { PH_P, PH_SH, PH_END }, 0, 36, 0 },            /* D  snare: "psh" */
    { { PH_P, PH_F, PH_END }, 0, 40, 0 },             /* D# clap: "pf" */
    { { PH_T, PH_S, PH_END }, 0, 64, 0 },             /* E  closed hat: "ts" */
    { { PH_D, PH_UW, PH_M, PH_END }, 98, 28, 7 },     /* F  low tom: "doom" */
    { { PH_T, PH_S, PH_S, PH_END }, 0, 24, 0 },       /* F# open hat: "tss" */
    { { PH_D, PH_OW, PH_END }, 165, 32, 7 },          /* G  high tom: "doh" */
    { { PH_CH, PH_END }, 0, 40, 0 },                  /* G# shaker: "ch" */
    { { PH_M, PH_M, PH_M, PH_END }, 0, 12, 0 },       /* A  bass hum: "mmm" at the key's pitch */
    { { PH_K, PH_T, PH_END }, 0, 64, 0 },             /* A# double click */
    { { PH_W, PH_AA, PH_END }, 0, 24, 3 },            /* B  "wah" at the key's pitch */
};

/* 2^(s/12) - 1 in Q12 for s = -12 .. +12 semitones */
static const int16_t ch_semi[25] = { -2048, -1926, -1797, -1661, -1516, -1362, -1200, -1027, -845, -652, -447,
                                     -230, 0, 244, 502, 775, 1065, 1372, 1697, 2041, 2406, 2793, 3202, 3636, 4096 };
/* pitch offset Q8 semitones -> deviation of the glottal step, Q12 (linear between semitones) */
static int32_t ch_semi_dev(int32_t q8)
{
    if (q8 > 12 * 256 - 1) q8 = 12 * 256 - 1; else if (q8 < -12 * 256) q8 = -12 * 256;
    int32_t s = (q8 >> 8) + 12, f = q8 & 255;
    int32_t a = ch_semi[s], b = ch_semi[s + 1];
    return a + (((b - a) * f) >> 8);
}

static const int16_t *ch_vrow(int body, int v)
{
    return body == 0 ? ch_vow_male[v] : body == 1 ? ch_vow_female[v] : ch_vow_child[v];
}

/* the vowel path u o a e i for PLAY's blue knob */
static const uint8_t ch_path[5] = { CH_V_U, CH_V_O, CH_V_A, CH_V_E, CH_V_I };

/* the tract's target areas: vowel v0 -> v1 (mix Q8), the mouth (-1024 .. 1023), a gesture's constriction; the
 * screen's articulators; returns the vowel's level correction (Q12) */
static int32_t ch_shape(int body, int v0, int v1, int32_t mix, int32_t mouth, const ch_gest_t *g, int16_t *tgt, int16_t *art)
{
    const int n = ch_body_n[body];
    const int16_t *a = ch_vrow(body, v0), *b = ch_vrow(body, v1);
    const int lipn = n - 2, jaw0 = n * 11 / 20;
    static const uint8_t inv[12] = { 255, 255, 128, 85, 64, 51, 43, 37, 32, 28, 26, 23 };   /* 256 / d */
    const int32_t jr = ((mouth * 90) >> 10) * inv[lipn - jaw0];
    for (int i = 0; i < n; i++) {
        int32_t x = a[i] + (((b[i] - a[i]) * mix) >> 8);
        if (i >= lipn) x += (mouth * 300) >> 10;                 /* lips: ln area +-1.2 */
        else if (i >= jaw0) x += (jr * (i - jaw0)) >> 8;           /* jaw: a ramp toward the lips */
        tgt[i] = (int16_t)x;
    }
    if (art) {
        const int16_t *aa = ch_art[v0], *ab = ch_art[v1];
        for (int k = 0; k < 7; k++) art[k] = (int16_t)(aa[k] + (((ab[k] - aa[k]) * mix) >> 8));
        art[2] += (int16_t)((mouth * 128) >> 10);
        art[3] += (int16_t)((mouth * 192) >> 10);
    }
    if (g && g->round) {                                         /* rounded lips */
        if (tgt[n - 1] > -60) tgt[n - 1] = -60;
        if (tgt[n - 2] > 0) tgt[n - 2] = 0;
        if (art) { art[3] = 80; art[4] = 300; }
    }
    if (g && g->place >= 0) {
        int c = (g->place * (n - 1) + 128) >> 8;
        if (g->place >= 250) {                                   /* lips: the last two sections */
            for (int i = n - 2; i < n; i++) if (tgt[i] > g->area) tgt[i] = (int16_t)g->area;
            if (art) art[3] = (int16_t)(g->area < -700 ? 0 : 40);
        } else {
            for (int d = -1; d <= 1; d++) {
                int i = c + d; if (i < 1 || i >= n) continue;
                int32_t lim = g->area + (d ? 140 : 0);
                if (tgt[i] > lim) tgt[i] = (int16_t)lim;
            }
            if (art) {                                           /* tongue tip (front) or body (back) to the palate */
                if (g->place >= 200) { art[5] = 6 * 256 + 80; art[6] = 9 * 256 + 140; }
                else { art[0] = (int16_t)(g->place >= 175 ? 3 * 256 + 190 : 2 * 256 + 80); art[1] = 8 * 256 + 60; }
            }
        }
    }
    for (int i = 0; i < n; i++) { if (tgt[i] < -900) tgt[i] = -900; else if (tgt[i] > 636) tgt[i] = 636; }
    return ch_vgain[body][v0] + (((ch_vgain[body][v1] - ch_vgain[body][v0]) * mix) >> 8);
}

static void ch_play_shape(int body, const int16_t *params, int16_t *tgt, int16_t *art, int32_t *vg)
{
    int32_t pos = ((int32_t)(params[0] < 0 ? 0 : params[0]) * 4 * 256) >> 15; if (pos > 1023) pos = 1023;
    int s = pos >> 8;
    int32_t r = ch_shape(body, ch_path[s], ch_path[s + 1 > 4 ? 4 : s + 1], pos & 255, ((int32_t)params[1] - 16384) >> 4,
                         0, tgt, art);
    if (vg) *vg = r;
}

/* BEATBOX: the key's place in its octave, 0 = C (from the 88.2 kHz pitch increment; no division) */
static int ch_pad_of(uint32_t inc)
{
    static const uint16_t mid[11] = { 4216, 4467, 4732, 5014, 5312, 5628, 5962, 6317, 6693, 7090, 7512 };   /* Q12 */
    uint32_t c = 6366016u >> 3;                                  /* C0 at 88.2 kHz */
    if (inc < c) return 0;
    while ((c << 1) <= inc && c < 0x40000000u) c <<= 1;         /* the C at or below the note */
    int pad = 0;
    while (pad < 11 && inc > (c >> 12) * mid[pad]) pad++;
    return pad;
}

/* ---------------- engine ---------------- */
static void ch_note_on(void *self, const int16_t *params)
{
    const int vi = op1_voice_index(self);
    if (vi < 0 || vi >= OP1_VOICES) return;
    ch_vs_t *s = &ch_v[vi];
    int prog = ch_prog_of(params);
    const ch_prog_t *p = &ch_progs[prog];
    s->prog = (uint8_t)prog; s->mode = p->mode; s->body = p->body;
    s->age = 0; s->gate = 1; s->live = 1; s->done = 0; s->rel = 0;
    s->base = 0; s->pitch = 0; s->pad_no = 0;
    s->env = s->env_prev = 0; s->lim = 4096;
    s->voice_s = 0; s->asp_s = 0; s->fric_s = 0; s->vel_s = -2000;
    int body = s->body;
    int16_t tgt[CH_NMAX];
    if (s->mode == M_SING || s->mode == M_SPEAK) {
        /* The phrase is made by the screen (GUI thread): the generator and the letter-to-sound rules take up to ~400k
         * packets, and note_on also runs inside R246's audio callback. Until the engine screen has been shown, the
         * phrase is "la" x 8. */
        const ch_lyr_t *l = &ch_lyr[ch_lyr_cur];
        if (s->mode == M_SING) {
            uint8_t syl[24];
            int pos = ch_sing_pos;
            if (pos >= l->nsyl) pos = 0;
            int n = ch_syllable(l->ph, pos, syl, (int)sizeof syl);
            ch_sing_pos = (uint8_t)(pos + 1 >= l->nsyl ? 0 : pos + 1);
            ch_art_start(&s->art, syl, n, 32, 0, 1);              /* onsets at double speed: on the beat */
        } else {
            int speed = 8 + (((int32_t)params[2] * 32) >> 15);    /* 0.5x .. 2.5x */
            int intone = prog == 8 ? 0 : (((int32_t)params[3] * 32) >> 15);
            int n = 0; while (n < CH_PHRASE_MAX - 1 && l->ph[n] != PH_END) n++;
            ch_art_start(&s->art, l->ph, n, speed, intone, 0);
        }
    } else if (s->mode == M_BEAT) {
        s->pad_pending = 1;                                          /* the pad needs this voice's pitch: first render */
    } else if (s->mode == M_BIRD) {
        s->pitch = (int16_t)(((int32_t)params[3] * 9) >> 7);          /* chirp: up to +9 semitones, falling */
    } else if (s->mode == M_TRUNK) {
        s->pitch = (int16_t)-(((int32_t)params[3] * 7) >> 7);         /* swoop: up to -7 semitones, rising */
    }
    if (s->mode == M_BEAT) { }
    else if (s->mode == M_PLAY || s->mode == M_TRUNK) ch_play_shape(body, params, tgt, 0, 0);
    else if (s->mode == M_BIRD) ch_shape(2, CH_V_UH, CH_V_A, params[1] >> 7, 0, 0, tgt, 0);
    else ch_shape(body, s->art.next_vow, s->art.next_vow, 0, 0, 0, tgt, 0);
    if (s->mode != M_BEAT) {
        ch_tract_reset(&s->tr, ch_body_n[body], tgt);
        s->tr.rng ^= (uint32_t)(vi + 1) * 0x9E3779B9u;
        if (!s->tr.rng) s->tr.rng = 0x1234567u;
    } else s->tr.n = ch_body_n[0];
}

/* BEATBOX: the pad from this voice's key (OP1_PITCH_INC is this voice's only in render: R246 calls note_on before it
 * writes the voice's pitch, as strum notes), then the drum's gesture string and the tract */
static void ch_beat_start(ch_vs_t *s, int vi, const int16_t *params)
{
    int body;
    int16_t tgt[CH_NMAX];
    {
        int pad = ch_pad_of((uint32_t)OP1_PITCH_INC[0]);
        const ch_drum_t *d = &ch_drums[pad];
        s->pad_no = (uint8_t)pad;
        int n = 0; while (n < 4 && d->ph[n] != PH_END) n++;
        int punch = 8 + (((int32_t)params[1] * 24) >> 15);           /* green: shorter .. longer */
        static const uint8_t rcp[33] = { 0, 0, 0, 0, 0, 0, 0, 0, 32, 28, 25, 23, 21, 19, 18, 17, 16, 15, 14, 13, 12, 12,
                                         11, 11, 10, 10, 9, 9, 9, 8, 8, 8, 8 };     /* 256 / punch */
        ch_art_start(&s->art, d->ph, n, (d->speed * rcp[punch > 32 ? 32 : punch]) >> 4, 0, 0);
        if (d->hz) s->base = (uint32_t)d->hz * 97392u;               /* 2^32 / 44100 per Hz */
        if (d->hz) s->base += (s->base >> 12) * (uint32_t)(((int32_t)params[3] * 2048) >> 15);   /* tune: up to +50 % */
        s->pitch = (int16_t)(d->drop * 256);
        int size = (((int32_t)params[0] * 3) >> 15); body = size > 2 ? 2 : size;
        s->body = (uint8_t)body;
    }
    ch_shape(body, s->art.next_vow, s->art.next_vow, 0, 0, 0, tgt, 0);
    ch_tract_reset(&s->tr, ch_body_n[body], tgt);
    s->tr.rng ^= (uint32_t)(vi + 1) * 0x9E3779B9u;
    if (!s->tr.rng) s->tr.rng = 0x1234567u;
    s->pad_pending = 0;
}

static void ch_note_off(void *self)
{
    const int vi = op1_voice_index(self);
    if (vi >= 0 && vi < OP1_VOICES) ch_v[vi].gate = 0;
}

static int ch_finished(void *self)
{
    const int vi = op1_voice_index(self);
    if (vi < 0 || vi >= OP1_VOICES) return 1;
    /* 1 once: the core frees the voice then. A later ask before the next note_on (a reused voice whose envelope runs
     * first) must not free the new note with the old note's flag. */
    if (ch_v[vi].done == 1) { ch_v[vi].done = 2; return 1; }
    return 0;
}

static void ch_render(void *self, int16_t *out, const int16_t *params)
{
    const int vi = op1_voice_index(self);
    if (vi < 0 || vi >= OP1_VOICES) { for (int i = 0; i < OP1_BLOCK; i++) out[i] = 0; return; }
    CH_PROF(0);
    ch_vs_t *s = &ch_v[vi];
    if (!s->live || s->tr.n == 0 || s->tr.n > CH_NMAX || s->body > 2) ch_note_on(self, params);
    if (s->pad_pending) ch_beat_start(s, vi, params);
    ch_tract_t *t = &s->tr;
    const int mode = s->mode, body = s->body;
    int16_t tgt[CH_NMAX], art[7];
    ch_gest_t g;
    int32_t vg;                                                   /* the vowel's level correction, Q12 */
    int32_t breath = params[2], nasal = params[6], grit = params[7], vib = params[3];
    int32_t env_tgt = 32767, env_up = 4096, env_dn = 330;        /* own envelope: attack ~12 ms, release ~140 ms */
    int ph_now = 0;

    if (mode == M_PLAY || mode == M_TRUNK || mode == M_BIRD) {
        g.voice = 4096; g.asp = 0; g.fric = 0; g.velum = -2000; g.place = -1; g.round = 0; g.spread = 0;
        if (mode == M_BIRD) { vg = ch_shape(2, CH_V_UH, CH_V_A, params[1] >> 7, 0, 0, tgt, art); vib = 0; }
        else ch_play_shape(body, params, tgt, art, &vg);
        if (mode == M_TRUNK) { g.velum = 40; grit = grit > 12000 ? grit : 12000; vib = 0; }
        if (!s->gate) env_tgt = 0;
        ch_glide(t, tgt, 24);
    } else {
        ch_art_block(&s->art, s->gate, &g);
        ph_now = s->art.cur;
        vg = ch_shape(body, g.v0, g.v1, g.mix, 0, &g, tgt, art);
        ch_glide(t, tgt, g.rate);
        if (mode == M_BEAT) {
            env_up = 16384; env_dn = 1200; breath = 0; vib = 0;
            g.fric = (int16_t)(((int32_t)g.fric * (8192 + params[2])) >> 14);
        }
        if (s->art.phase == AP_DONE) env_tgt = 0;
        if (mode == M_SPEAK) { vib = 2000; breath = 1500; }     /* white and orange are speed and melody there */
    }
    /* source controls: the gesture's, smoothed, with the knobs on top */
    int32_t voice = g.voice - ((g.voice * ((breath * breath) >> 15)) >> 15);
    s->voice_s += (voice - s->voice_s) >> 2;
    int32_t asp = g.asp + 40 + (breath >> 4);
    s->asp_s += (asp - s->asp_s) >> 2;
    s->fric_s += (g.fric - s->fric_s) >> 1;
    int32_t vel = g.velum;
    if (nasal > 600) { int32_t vn = -800 + ((nasal * 900) >> 15); if (vn > vel) vel = vn; }
    s->vel_s += (vel - s->vel_s) >> 2;

    ch_ctl_t c;
    int32_t press = grit < 16384 ? grit : 16383;
    c.oq = 20316 - ((press * 7208) >> 14) + ((breath * 6553) >> 15);
    if (mode == M_TRUNK) c.oq = 11000;
    c.fry = grit > 16384 ? ((grit - 16384) >> 2) : 0;
    c.jitter = (s->prog == 8) ? 0 : 40 + (c.fry >> 3) + (press >> 9);
    c.voice = s->voice_s; c.asp = s->asp_s; c.fric = s->fric_s > 4095 ? 4095 : s->fric_s;
    c.velum = s->vel_s > -1000 ? s->vel_s : -2000;
    c.sine = mode == M_BIRD;
    /* pitch: vibrato (fades in over 0.4 s), prosody, the onset chirp / swoop / drop, the bird's trill */
    int32_t rate_mhz = 5000 + ((vib * 1500) >> 15);
    t->vph += (uint32_t)(rate_mhz * 6233);                        /* 2^32 / (689.06 * 1000) per mHz */
    int32_t fade = s->age > 276 ? 4096 : (int32_t)s->age * 15;
    int32_t dev = (((OP1_SINE_TABLE[t->vph >> 19] * ((vib * 220) >> 15)) >> 15) * fade) >> 12;
    int32_t semis = s->pitch + (mode == M_SING || mode == M_SPEAK ? s->art.pitch : 0);
    s->pitch = (int16_t)(s->pitch - (s->pitch >> (mode == M_BEAT ? 3 : 5)));
    if (mode == M_BIRD) {                                         /* trill: 6 .. 30 Hz amplitude and pitch flutter */
        s->trph += (uint32_t)(6000 + ((params[0] * 24000) >> 15)) * 6233u;
        int32_t tw = OP1_SINE_TABLE[s->trph >> 19];
        c.voice = (c.voice * (24576 + (tw >> 2))) >> 15;
        semis += tw >> 9;
    }
    dev += ch_semi_dev(semis);
    c.vib_depth = dev;
    CH_PROF(1);
    ch_coefs(t, c.velum);
    CH_PROF(2);
    uint32_t base = s->base ? s->base : (uint32_t)OP1_PITCH_INC[0] + (uint32_t)OP1_PITCH_INC[1];
    if (mode == M_BIRD) base <<= 2;                               /* two octaves up */
    else if (mode == M_TRUNK) base >>= 1;                         /* an octave down */
    else if (mode == M_BEAT && !s->base) base >>= 1;              /* the hum and the "wah" an octave down */
    /* own envelope (interpolated over the block), velocity, the vowel's level: applied in the tract loop */
    s->env_prev = s->env;
    if (s->env < env_tgt) { s->env += env_up; if (s->env > env_tgt) s->env = env_tgt; }
    else { s->env -= env_dn; if (s->env < env_tgt) s->env = env_tgt; }
    if (s->env <= 0 && env_tgt == 0 && s->age > 2 && !s->done) s->done = 1;
    c.gain = (((op1_voice_vel_gain(self) * vg) >> 13) * s->lim) >> 12;   /* Q14: x4 at full velocity, vowel-corrected */
    c.e0 = s->env_prev; c.de = (s->env - s->env_prev) >> 6;
    CH_PROF(3);
    ch_tract_run(t, &c, base, out);
    CH_PROF(4);
    int32_t pk = t->pk;
    if (pk > 20000) s->lim -= s->lim >> 3; else s->lim += (4096 - s->lim) >> 6;
    s->age++;
#ifdef CH_TRACE
    fprintf(stderr, "v%d m%d ph%d ph2 %d pk %d voice %d asp %d fric %d vel %d n %d imin %d\n", vi, mode, ph_now, s->art.phase, (int)pk, (int)c.voice, (int)c.asp, (int)c.fric, (int)c.velum, t->n, t->imin);
#endif
    CH_PROF(5);
    if (!s->done) {                                               /* publish for the screen */
        for (int k = 0; k < 7; k++) ch_view.art[k] = art[k];
        for (int k = 0; k < t->n; k++) ch_view.la[k] = t->la[k];
        ch_view.n = t->n; ch_view.velum = (int16_t)c.velum; ch_view.voice = (int16_t)c.voice;
        ch_view.asp = (int16_t)c.asp; ch_view.fric = (int16_t)c.fric; ch_view.level = (int16_t)pk;
        ch_view.glot = (uint16_t)(t->gph >> 16); ch_view.pitch = (int16_t)semis;
        ch_view.prog = s->prog; ch_view.mode = (uint8_t)mode; ch_view.body = (uint8_t)body;
        ch_view.ph = (uint8_t)ph_now; ch_view.gate = s->gate; ch_view.beat = s->pad_no;
        ch_view.seq++;
    }
}

const op1_engine_env_t ENGINE_chimera = {
    { ch_note_on, ch_render, ch_note_off,
      { OP1_PRESS_PAGE_STEPS(CH_PROGS), OP1_PRESS_PAGE, OP1_PRESS_PAGE, OP1_PRESS_NONE } },
    ch_finished
};
#ifndef CH_NO_SCREEN                 /* chimera_demo.c renders sound only */
#include "chimera_screen.h"
#endif
