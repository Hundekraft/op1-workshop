/* chimera_view.h: what chimera's audio side publishes for its screen (chimera_screen.c), and the program list.
 * The audio thread writes ch_view once a block for the newest sounding voice; the GUI thread reads it (a torn read
 * shows one odd frame at worst). Lyrics live in ch_lyr (chimera.c), published by index.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef CHIMERA_VIEW_H
#define CHIMERA_VIEW_H
#include <stdint.h>
#include "chimera_phon.h"
#include "chimera_tables.h"

enum { M_PLAY, M_SING, M_SPEAK, M_BEAT, M_BIRD, M_TRUNK, M_MODES };
#define CH_PROGS 16              /* blue page 2 turns in 16 steps (fixed: a saved word 5 keeps its program) */
typedef struct { char name[12]; uint8_t mode, body; } ch_prog_t;
static const ch_prog_t ch_progs[CH_PROGS] = {
    { "PLAY MAN", M_PLAY, 0 },   { "PLAY WOMAN", M_PLAY, 1 },   { "PLAY CHILD", M_PLAY, 2 },
    { "SING MAN", M_SING, 0 },   { "SING WOMAN", M_SING, 1 },   { "SING CHILD", M_SING, 2 },
    { "SPEAK MAN", M_SPEAK, 0 }, { "SPEAK WOMAN", M_SPEAK, 1 }, { "SPEAK ROBOT", M_SPEAK, 2 },
    { "BEATBOX", M_BEAT, 0 },    { "BIRD", M_BIRD, 2 },         { "ELEPHANT", M_TRUNK, 0 },
    { "PLAY MAN", M_PLAY, 0 },   { "PLAY MAN", M_PLAY, 0 },     { "PLAY MAN", M_PLAY, 0 },   { "PLAY MAN", M_PLAY, 0 },
};
static inline int ch_prog_of(const int16_t *params)
{
    int32_t w = params[5] < 0 ? 0 : params[5];
    int p = (int)((w * CH_PROGS) >> 15);
    return p > CH_PROGS - 1 ? CH_PROGS - 1 : p;
}
/* page-1 knob names per mode (the screen's labels) */
static const char ch_knob_names[M_MODES][4][8] = {
    { "VOWEL", "MOUTH", "BREATH", "VIBRATO" },
    { "GENRE", "PHRASE", "BREATH", "VIBRATO" },
    { "GENRE", "PHRASE", "SPEED", "MELODY" },
    { "SIZE", "PUNCH", "NOISE", "TUNE" },
    { "TRILL", "BEAK", "BREATH", "CHIRP" },
    { "VOWEL", "MOUTH", "BREATH", "SWOOP" },
};
#define CH_TYPED_GENRE 16        /* blue's top zone in SING / SPEAK: the typed text */

typedef struct {
    int16_t art[7];              /* tbX tbY jaw lipAp lipProt ttX ttY (CHIMERA's template cm x 256) */
    int16_t la[CH_NMAX];         /* the tract's current log areas, Q8 ln cm2, glottis first */
    int16_t velum;               /* velum log area Q8 (<= -1000 closed) */
    int16_t voice, asp, fric;    /* Q12 now */
    int16_t level;               /* output peak this block */
    uint16_t glot;               /* glottal phase, 65536 = one period */
    int16_t pitch;               /* prosody / chirp offset, Q8 semitones */
    uint8_t n, prog, mode, body;
    uint8_t ph;                  /* the phoneme now (PH_*; 0 = PLAY's knob vowel) */
    uint8_t gate, beat;          /* a key is down; BEATBOX: the pad that played last (0..11) */
    uint8_t pad;
    uint32_t seq;                /* +1 per published block */
} ch_view_t;
#endif
