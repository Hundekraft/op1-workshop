"""chimera's vocal tract as a float model: the same Kelly-Lochbaum lattice chimera.c runs in fixed point, its transfer
function in closed form (for fitting area functions to formant targets) and a direct simulation (to check the closed
form and the C). Used by gen_tables.py and formant_check.py; never runs on the OP-1.

Lattice (one sample of delay per section and direction, N sections, section 0 at the glottis, N-1 at the lips):
    R0' = rg * L0 + source                                     (rg: 0.75 closed, 0.5 open glottis)
    w_i = k_i (R_{i-1} + L_i);  R_i' = R_{i-1} - w_i;  L_{i-1}' = L_i + w_i        i = 1 .. N-1
    lip = lip + a (R_{N-1} - lip);  L_{N-1}' = rl * lip       (radiation: lows reflect; rl from the lip area)
    out = R_{N-1}' (the wave arriving at the lips)
k_i = (A_{i-1} - A_i) / (A_{i-1} + A_i) = tanh((ln A_{i-1} - ln A_i) / 2).
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import numpy as np

RG_CLOSED, RG_OPEN = 0.75, 0.50   # glottal end reflection; chimera.c switches with the glottal phase
RG = 0.6 * RG_OPEN + 0.4 * RG_CLOSED   # the fit's constant: the mean over a modal period (open quotient ~0.6)
LIP_A = 0.45        # one-pole in the lip reflection: highs radiate, lows reflect


def rl_of(la_lips):
    """lip end reflection at low frequencies from the lip section's area (cm2): a small opening radiates less
    (chimera.c: ch_rl, the same law in Q15)"""
    a = float(np.exp(la_lips))
    return -min(0.97, max(0.80, 0.97 - 0.035 * a))


def refl(logA):
    """k_i for i = 1..N-1 from natural-log areas"""
    return np.tanh((logA[:-1] - logA[1:]) / 2.0)


def transfer(logA, freqs, fs, rg=RG, rl=None, a=LIP_A):
    """complex H(f) = out / source of the lattice above (with chimera.c's output tap)"""
    z = np.exp(2j * np.pi * np.asarray(freqs) / fs)
    k = refl(logA)
    rl = rl_of(logA[-1]) if rl is None else rl
    # at the lips: R_{N-1}' (= z R) arrives; lip LP state follows R; L_{N-1}' = rl * lp
    R = np.ones_like(z)                       # z-transforms of the states; out = R_{N-1}
    L = rl * a * R / (z - (1 - a))            # lp[n+1] = (1-a) lp[n] + a R[n];  L[n+1] = rl lp[n+1]
    out = R
    for ki in k[::-1]:                        # junction i between i-1 and i: (R_i, L_i) -> (R_{i-1}, L_{i-1})
        Rm = (z * R + ki * L) / (1 - ki)
        Lm = (L + ki * z * R) / ((1 - ki) * z)
        R, L = Rm, Lm
    S = z * R - rg * L
    return out / S


def formants(logA, fs, fmax=5500.0, n=4096, **kw):
    f = np.linspace(50, fmax, n)
    h = np.abs(transfer(logA, f, fs, **kw))
    db = 20 * np.log10(h + 1e-12)
    pk = []
    for i in range(1, n - 1):
        if db[i] > db[i - 1] and db[i] >= db[i + 1]:
            y0, y1, y2 = db[i - 1], db[i], db[i + 1]
            d = 0.5 * (y0 - y2) / (y0 - 2 * y1 + y2) if (y0 - 2 * y1 + y2) != 0 else 0
            pk.append(f[i] + d * (f[1] - f[0]))
    return pk, f, db


def sim(logA, src, rg=RG, rl=None, a=LIP_A):
    """direct float simulation of the lattice for a source signal (numpy, slow: checks only)"""
    N = len(logA)
    k = refl(logA)
    rl = rl_of(logA[-1]) if rl is None else rl
    R = np.zeros(N); L = np.zeros(N); lp = 0.0
    out = np.zeros(len(src))
    for n, s in enumerate(src):
        jR = np.empty(N); jL = np.empty(N)
        jR[0] = rg * L[0] + s
        w = k * (R[:-1] + L[1:])
        jR[1:] = R[:-1] - w
        jL[:-1] = L[1:] + w
        lp += a * (R[-1] - lp)
        jL[-1] = rl * lp
        R, L = jR, jL
        out[n] = R[-1]
    return out
