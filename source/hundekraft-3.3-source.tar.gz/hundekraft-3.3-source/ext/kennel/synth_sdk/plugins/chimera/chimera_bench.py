#!/usr/bin/env python3
"""chimera on bcore: block costs at 1, 2, 4 and 6 voices, and the demo renders made by the Blackfin code.

    python3 synth_sdk/plugins/chimera/chimera_bench.py cost            packets (--cycles) and modelled warm / cold cycles
    python3 synth_sdk/plugins/chimera/chimera_bench.py audio OUTDIR    demo WAVs (88.2 kHz render -> 44.1 kHz) + formants
    python3 synth_sdk/plugins/chimera/chimera_bench.py kern            chimera_kernel.S against the C lattice, bit for bit
    CH_LATTICE_C=1 ... cost / audio: the engine with the C lattice (the before of the kernel)
    CH_BLOCK=1 ...: the whole-sample assembly loop (ch_block_asm; CH_SAMPLE_C=1 with it: its C reference)

chimera_demo.c is built as the plugin is (bfin-elf-gcc -O2 -mcpu=bf524) and linked bare metal with tier2's crt.S and
guest.ld. Cold cycles: bcore --memmodel=cold-noalloc, both caches flushed at blk_end after every block (tier2.py
memmodel_args); unit estimate = cold cycles / 580,525 x 100 x 0.98 (root docs/calibration/unit-readings.md, the
2026-11-11 fit of the unit's worst INST against modelled cold cycles: median 0.98, range 0.80..1.34).
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import re
import subprocess
import sys
import tempfile
from pathlib import Path

P = Path(__file__).resolve().parent
SDK = P.parents[1]
sys.path.insert(0, str(SDK / 'harness'))
import tier2 as T                                     # noqa: E402

BLOCK = 580525
FIT = (0.98, 0.80, 1.34)
REGIMES = ['PLAY default', 'PLAY nasal open', 'PLAY breath+fry+nasal', 'PLAY vowel/mouth sweep', 'PLAY all max, C6..C7', 'SING phrase, retrig', 'SPEAK phrase, retrig', 'BEATBOX, retrig', 'BIRD']


def build(tmp, mode, t, env, extra=()):
    o = tmp / f'demo_{mode}.o'
    T.sh([t['gcc'], '-O2', '-mcpu=bf524', '-ffreestanding', '-fno-builtin', '-nostdlib', '-fno-common', '-Wall',
          '-Wno-unused-function', f'-DCH_MODE_{mode.upper()}', *extra, f'-I{P}', f'-I{SDK}', '-c', str(P / 'chimera_demo.c'),
          '-o', str(o)], env=env)
    k = tmp / 'kernel.o'
    T.sh([t['gcc'], '-O2', '-mcpu=bf524', '-c', str(P / 'chimera_kernel.S'), '-o', str(k)], env=env)
    c = tmp / 'crt.o'
    T.sh([t['as'], '-mcpu=bf524', str(T.HERE / 'tier2/crt.S'), '-o', str(c)])
    libgcc = T.sh([t['gcc'], '-mcpu=bf524', '-print-libgcc-file-name'], env=env).strip()
    elf = tmp / f'{mode}.elf'
    T.sh([t['ld'], '--no-warn-rwx-segments', '--defsym=T2_STAGE=0x02000000', '-T', str(T.HERE / 'tier2/guest.ld'),
          str(c), str(o), str(k), libgcc, '-o', str(elf)])
    return elf


def rows(text):
    return [{k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', l)} for l in text.splitlines() if l.startswith('T2')]


def main():
    found = T.setup_env()
    if 'toolchain' not in found or 'emu_cycles' not in found:
        print('chimera bench: SKIP (toolchain or bcore emu with --cycles missing)')
        return 0
    t = T.tools(found['toolchain'])
    env = dict(T.os.environ, PATH=t['path'])
    what = sys.argv[1] if len(sys.argv) > 1 else 'cost'
    extra = (('-DCH_LATTICE_C',) if T.os.environ.get('CH_LATTICE_C') else ()) + \
            (('-DCH_PROF_NOTRACT',) if T.os.environ.get('CH_PROF_NOTRACT') else ()) + \
            (('-DCH_PROFILE',) if T.os.environ.get('CH_PROFILE') else ()) + \
            (('-DCH_SAMPLE_C',) if T.os.environ.get('CH_SAMPLE_C') else ()) + \
            (('-DCH_BLOCK',) if T.os.environ.get('CH_BLOCK') else ())
    with tempfile.TemporaryDirectory(prefix='chimera-') as tmp:
        tmp = Path(tmp)
        if what == 'kern':                              # the kernel against the C, bit for bit
            o = tmp / 'kg.o'
            T.sh([t['gcc'], '-O2', '-mcpu=bf524', '-ffreestanding', '-fno-builtin', '-nostdlib', '-fno-common', '-Wall',
                  '-Wno-unused-function', '-DCH_BLOCK', f'-I{P}', f'-I{SDK}', '-c', str(P / 'chimera_kern_guest.c'), '-o', str(o)], env=env)
            k = tmp / 'kernel.o'
            T.sh([t['gcc'], '-O2', '-mcpu=bf524', '-c', str(P / 'chimera_kernel.S'), '-o', str(k)], env=env)
            c = tmp / 'crt.o'
            T.sh([t['as'], '-mcpu=bf524', str(T.HERE / 'tier2/crt.S'), '-o', str(c)])
            libgcc = T.sh([t['gcc'], '-mcpu=bf524', '-print-libgcc-file-name'], env=env).strip()
            elf = tmp / 'kern.elf'
            T.sh([t['ld'], '--no-warn-rwx-segments', '--defsym=T2_STAGE=0x02000000', '-T', str(T.HERE / 'tier2/guest.ld'),
                  str(c), str(o), str(k), libgcc, '-o', str(elf)])
            r = subprocess.run([found['emu'], '--fastmem', str(elf)], capture_output=True, text=True, timeout=600)
            print(r.stdout.strip() or r.stderr[-400:])
            return 0 if 'KERN ok' in r.stdout else 1
        if what == 'audio':
            elf = build(tmp, 'audio', t, env, extra)
            r = subprocess.run([found['emu'], '--fastmem', str(elf)], capture_output=True, text=True, timeout=3000)
            out = Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
            (out / 'bcore_stream.txt').write_text(r.stdout)
            subprocess.run([sys.executable, str(P / 'demo_wavs.py'), str(out / 'bcore_stream.txt'), str(out)], check=True)
            (out / 'bcore_stream.txt').unlink()
            return 0
        elf = build(tmp, 'cost', t, env, extra)
        res = {}
        r = subprocess.run([found['emu_cycles'], '--fastmem', '--cycles', str(elf)], capture_output=True, text=True,
                           timeout=3000)
        res['packets'] = rows(r.stdout)
        if found.get('emu_memmodel'):
            for v in ('warm-noalloc', 'cold-noalloc'):
                r = subprocess.run([found['emu_memmodel'], '--fastmem', '--cycles',
                                    *T.memmodel_args(elf, t['nm'], v), str(elf)], capture_output=True, text=True,
                                   timeout=3000)
                res[v] = rows(r.stdout)
    print(f'{"regime":24s} {"voices":>6} {"packets max":>11} {"warm max":>9} {"cold max":>9} {"cold/voice":>10} '
          f'{"unit est. %":>12}')
    for i, p in enumerate(res['packets']):
        w = res.get('warm-noalloc', [{}] * 99)[i].get('max', 0)
        c = res.get('cold-noalloc', [{}] * 99)[i].get('max', 0)
        pct = c * 100 / BLOCK
        print(f'{REGIMES[p["regime"]]:24s} {p["voices"]:6} {p["max"]:11,} {w:9,} {c:9,} {c // p["voices"]:10,} '
              f'{pct * FIT[0]:6.1f} ({pct * FIT[1]:.1f}..{pct * FIT[2]:.1f})')
    return 0


if __name__ == '__main__':
    sys.exit(main())
