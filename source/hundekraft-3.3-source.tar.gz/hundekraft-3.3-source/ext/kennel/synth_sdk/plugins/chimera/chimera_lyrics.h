/* chimera_lyrics.h: chimera's phrase generator. Sixteen genres, each with sentence templates and four word lists;
 * a phrase is picked from (genre, seed) with a small xorshift, so the same pair always gives the same text.
 *
 *   #define CH_GENRES 16,  const char *ch_genre_name(int g)   names of at most 8 upper-case letters
 *   int ch_phrase(int genre, uint32_t seed, char *text, int max)
 *       writes the phrase (lower case ASCII, at most 47 characters) and returns its syllable count, 4..12, as
 *       ch_g2p_text + ch_syllables count it. Needs chimera_text.h first (the syllable count comes from it).
 *
 * Data: per genre five '\n'-ended segments: templates ('/' between them), then the word lists N, A, V, X ('|'
 * between items; an item may be several words). In a template an upper-case N, A, V or X is replaced by a random
 * item of that list, everything else is copied (lower case words, spaces, , . ! ?). A lone "a" before a vowel
 * becomes "an". A phrase that is not 4..12 syllables or longer than 47 characters is redrawn (up to 24 times), then
 * "la la la la" is used. Every word is checked against hand-written pronunciations in harness/chimera_text_test.c.
 * No libc, no float. Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission. */
#ifndef CHIMERA_LYRICS_H
#define CHIMERA_LYRICS_H
#include <stdint.h>
#include "chimera_phon.h"

#define CH_GENRES 16

static const char ch_gnames[CH_GENRES][9] = {
    "SYNTHWAV", "HIPHOP", "LOVESONG", "SHANTY", "ROBOT", "GOSPEL", "PUNK", "NURSERY",
    "SPOOKY", "TECHNO", "SCAT", "LULLABY", "DISCO", "COUNTRY", "SPACE", "BLUES"
};

static const char *ch_genre_name(int g)
{
    return ch_gnames[g >= 0 && g < CH_GENRES ? g : 0];
}

static const char ch_data[] =
    /* 0 SYNTHWAV */
    "A N, A N/we V in the A N/the N will V/I V X/V me to the N/N, N, N/A N and A N\n"
    "night|neon|city|chrome|laser|ocean|moon|highway\n"
    "golden|silver|midnight|lonely|burning|endless|shining|pink\n"
    "drive|fly|glide|dream|shine|race|run|fade\n"
    "alone|away|again|now\n"
    /* 1 HIPHOP */
    "the N is A/I V the N and the N/we V like the N/A N, A N/turn up the N/N, N, X/we V all night/get up, V\n"
    "beat|street|flow|rhyme|crown|block|mike|dream|city\n"
    "fresh|cold|loud|real|sleek|bold|deep|tight\n"
    "rise|roll|drop|ride|spin|rock|shake|move\n"
    "all night|on fire|uptown|downtown\n"
    /* 2 LOVESONG */
    "my N, my N/I V you, my A N/so A, my N/V me, my N/A N, A N/oh my N, X\n"
    "heart|love|kiss|rose|dream|star|eyes|arms|tears|smile|voice\n"
    "sweet|tender|gentle|true|warm|soft\n"
    "hold|kiss|love|miss|need\n"
    "for you|to me|all night|by my side\n"
    /* 3 SHANTY */
    "we V the A N/V, my boys, V/the A N will V the N/oh, the N/X, my boys/N and N/the N is A\n"
    "sea|ship|sail|wind|wave|storm|crew|gold|harbor|sailor\n"
    "old|brave|salty|wild|deep|blue|strong|bold\n"
    "sail|pull|row|sing|haul|roll|steer\n"
    "home|to shore|over the sea|at sea\n"
    /* 4 ROBOT */
    "I am a A N/I can V the N/V, V, V/the N is A/A N, A N/we V the A N/X, X, N\n"
    "power|code|data|star|laser|space|metal|moon|beam\n"
    "cold|bright|strong|fast|silver|clear\n"
    "run|scan|beam|glow|move|work|hum|stop|go\n"
    "beep|boop|zap|ping\n"
    /* 5 GOSPEL */
    "A N, A N/oh, the N of the N/rise up, my N/we V for joy/the N is in the N/V the N/N, N, N\n"
    "light|glory|grace|joy|hope|river|morning|hand|love\n"
    "holy|mighty|happy|free|high|bright|sweet\n"
    "shine|sing|clap|praise|shout|lift|raise\n"
    "all day|on high|all night|to the sky\n"
    /* 6 PUNK */
    "we V all night/A N, A N/N, N, N!/no N, no N/V, V, V!/the N is A/turn it up/X, X!\n"
    "noise|fire|speed|thunder|wall|city|engine|street\n"
    "loud|fast|wild|mad|bad|raw\n"
    "scream|jump|crash|kick|smash|shout|run\n"
    "right now|no way|out loud|all night\n"
    /* 7 NURSERY */
    "A N, A N/the N can V/V, V, V/I see the N/see the A N/N in the N/the A N can V X\n"
    "star|moon|bunny|duck|bird|sheep|cat|bear|frog|tree|bee\n"
    "little|sleepy|happy|soft|warm|yellow|sweet\n"
    "hop|jump|sing|sleep|play|hide|dance\n"
    "up high|in the sky|all day|by the sea\n"
    /* 8 SPOOKY */
    "the A N will V/we V X/boo, said the N/N, N, boo!/the N is A/I see the A N/V, V, V\n"
    "ghost|moon|bat|cat|witch|pumpkin|candy|spider|night|owl\n"
    "spooky|creepy|dark|silly|scary|friendly|cute\n"
    "haunt|howl|dance|hide|creep|float|fly|shake\n"
    "in the dark|on the hill|at midnight|all night\n"
    /* 9 TECHNO */
    "N, N, N, N/V now, V now/V, V, V, V!/hands up, hands up/feel the N, feel the N/V it up, V it up/go, go, go, go/A N, A N, A N/V X, V X\n"
    "bass|beat|drop|night|sound|light|pulse|floor|dance\n"
    "loud|deep|hard|high|fast|dark|bright|hot\n"
    "move|jump|pump|drop|rise|feel|spin|run|shake|bounce|dance|go\n"
    "now|up|down|all night|again|right now\n"
    /* 10 SCAT */
    "N A N A/A N, A N/N N A, N N A/A A N A/N A N A N A/A N A N, A N A N/N, N, A A\n"
    "bop|dah|bah|la|zip|bam|zing|dip|pop|hop|skee\n"
    "doo|bee|dee|boo|shoo|wah|doot|shah|da|ba\n"
    "\n"
    "\n"
    /* 11 LULLABY */
    "hush, my N/sleep, my N, sleep/close your eyes/the N will V X/V, V, my N/rock, rock, my N/the N is A\n"
    "moon|star|dream|cloud|pillow|wind|breeze|whisper|bed|baby\n"
    "soft|sleepy|gentle|warm|sweet|still|slow|golden|silver\n"
    "sleep|rest|dream|hush|rock|sway|drift\n"
    "all night|till dawn|my dear|my love\n"
    /* 12 DISCO */
    "we V all night/A N, A N/N, N, N/V with me/the N is A/V, V, V/dance on the floor/we V X\n"
    "dance|floor|night|groove|lights|party|glitter|star|heart\n"
    "shining|golden|funky|hot|bright|wild\n"
    "dance|move|shake|spin|shine|clap|sway|groove\n"
    "all night|on the floor|right now|under the lights\n"
    /* 13 COUNTRY */
    "I V my N/the N is A/A N, A N/we V down the road/take me home/my N and my N/V me home/we V X\n"
    "road|truck|river|hat|boots|barn|farm|horse|sunset|moon|dog|home\n"
    "dusty|old|lonely|sweet|golden|broken\n"
    "ride|drive|sing|roll|dance\n"
    "down the road|all day|on the farm|all night\n"
    /* 14 SPACE */
    "we V to the N/the N is A/A N, A N/N, N, N/V far, far away/we V in the A N/I V X\n"
    "star|moon|space|orbit|beam|sun|light|sky|ship\n"
    "far|bright|cold|endless|deep|lonely\n"
    "fly|float|drift|glow|shine|race|sail\n"
    "up high|far away|in space|alone\n"
    /* 15 BLUES */
    "I got the N/the N is A/A N, A N/I V all night/I V all day/N, N, oh, N/V, V, V/no more N/I V X\n"
    "blues|rain|train|road|river|midnight|town|moon\n"
    "lonely|cold|long|sad|blue|gray\n"
    "walk|cry|ride|wait|sing|roll|run\n"
    "again|alone|down the road|all night\n";

static uint32_t ch_rnd(uint32_t *s)
{
    uint32_t x = *s;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    return *s = x;
}

static const char *ch_seg(const char *d, int idx)
{
    while (idx-- > 0) {
        while (*d != '\n') d++;
        d++;
    }
    return d;
}

/* pick an item (by r) of the list at s (items end at sep, the segment at '\n'); returns its start, *len its length */
static const char *ch_item(const char *s, int sep, uint32_t r, int *len, int *idx)
{
    int n = 1, i;
    const char *e;
    if (*s == '\n') { *len = 0; if (idx) *idx = 0; return s; }
    for (e = s; *e != '\n'; e++) if (*e == sep) n++;
    i = (int)((r >> 8) % (uint32_t)n);
    if (idx) *idx = i;
    for (e = s; i > 0; e++) if (*e == sep) i--;
    s = e;
    while (*e != sep && *e != '\n') e++;
    *len = (int)(e - s);
    return s;
}

static int ch_isvowelc(int c) { return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u'; }

static int ch_phrase(int genre, uint32_t seed, char *text, int max)
{
    uint32_t s;
    const char *base;
    int tr;
    if (max < 1) return 0;
    text[0] = 0;
    genre %= CH_GENRES;
    if (genre < 0) genre += CH_GENRES;
    s = seed * 2654435761u + (uint32_t)genre * 40503u + 0x9E3779B9u;
    if (!s) s = 1;
    ch_rnd(&s); ch_rnd(&s);
    base = ch_seg(ch_data, genre * 5);
    for (tr = 0; tr < 24; tr++) {
        char tmp[88], fin[CH_TEXT_MAX + 8];
        uint8_t ph[CH_PHRASE_MAX];
        int last[4], n = 0, ok = 1, i, nf = 0, syl, len;
        const char *t;
        last[0] = last[1] = last[2] = last[3] = -1;
        t = ch_item(base, '/', ch_rnd(&s), &len, 0);
        for (i = 0; i < len; i++) {
            int c = t[i];
            const char *w = 0;
            int wl = 0, slot = c == 'N' ? 1 : c == 'A' ? 2 : c == 'V' ? 3 : c == 'X' ? 4 : 0, k;
            if (slot) {
                int ix = 0, att;
                for (att = 0; att < 3; att++) {
                    w = ch_item(ch_seg(base, slot), '|', ch_rnd(&s), &wl, &ix);
                    if (ix != last[slot - 1]) break;
                }
                last[slot - 1] = ix;
                for (k = 0; k < wl; k++) { if (n < 80) tmp[n] = w[k]; n++; }
            } else {
                if (n < 80) tmp[n] = (char)c;
                n++;
            }
        }
        if (n > 80) continue;
        tmp[n] = 0;
        for (i = 0; i < n && ok; i++) {   /* "a" before a vowel -> "an" */
            if (tmp[i] == 'a' && (i == 0 || tmp[i - 1] == ' ') && tmp[i + 1] == ' ' && ch_isvowelc(tmp[i + 2])) {
                if (nf + 2 >= CH_TEXT_MAX) { ok = 0; break; }
                fin[nf++] = 'a'; fin[nf++] = 'n';
            } else {
                if (nf + 1 >= CH_TEXT_MAX) { ok = 0; break; }
                fin[nf++] = tmp[i];
            }
        }
        if (!ok) continue;
        fin[nf] = 0;
        if (nf > CH_TEXT_MAX - 1 || nf >= max) continue;
        if (ch_g2p_text(fin, ph, CH_PHRASE_MAX) < 0) continue;
        syl = ch_syllables(ph);
        if (syl < 4 || syl > 12) continue;
        for (i = 0; i <= nf; i++) text[i] = fin[i];
        return syl;
    }
    {
        static const char fb[] = "la la la la";
        int i;
        for (i = 0; fb[i] && i < max - 1; i++) text[i] = fb[i];
        text[i] = 0;
    }
    return 4;
}
#endif
