/* chimera_phon.h: chimera's phoneme codes, shared by the text side (chimera_text.h: letter-to-sound rules, the
 * syllabifier, chimera_lyrics.h: the phrase generator) and the voice side (chimera.c's articulation scheduler).
 *
 * A phrase is a byte string of these codes, ended by PH_END:
 *   - PH_WORD between words, PH_SYL between the syllables of a word (never at the start or the end of a word),
 *   - PH_STRESS right before the vowel of a stressed syllable (one per content word; monosyllabic function words
 *     such as "the", "a", "to", "and" get none),
 *   - PH_COMMA / PH_QUEST / PH_STOP for punctuation (a phrase pause, a question rise, a final fall),
 *   - every syllable has exactly one vowel code (PH_AA .. PH_AX); diphthongs are one code (AY, EY, OW, AW, OY).
 * Codes follow ARPAbet (CMUdict's set), with AX for the unstressed schwa.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifndef CHIMERA_PHON_H
#define CHIMERA_PHON_H
#include <stdint.h>

enum {
    PH_END = 0, PH_SYL = 1, PH_WORD = 2, PH_STRESS = 3, PH_COMMA = 4, PH_QUEST = 5, PH_STOP = 6,
    /* vowels: PH_VOWEL0 .. PH_VOWEL0 + 15 */
    PH_AA = 8,   /* f-a-ther  (ɑ) */
    PH_AE,       /* c-a-t     (æ) */
    PH_AH,       /* c-u-t     (ʌ) */
    PH_AO,       /* c-au-ght  (ɔ) */
    PH_AW,       /* c-ow      (a -> ʊ) */
    PH_AY,       /* b-i-te    (a -> ɪ) */
    PH_EH,       /* b-e-d     (ɛ) */
    PH_ER,       /* b-ir-d    (ɝ) */
    PH_EY,       /* b-ai-t    (e -> ɪ) */
    PH_IH,       /* b-i-t     (ɪ) */
    PH_IY,       /* b-ee-t    (i) */
    PH_OW,       /* b-oa-t    (o -> ʊ) */
    PH_OY,       /* b-oy      (ɔ -> ɪ) */
    PH_UH,       /* b-oo-k    (ʊ) */
    PH_UW,       /* b-oo-t    (u) */
    PH_AX,       /* a-bout    (ə, unstressed) */
    /* consonants */
    PH_B = 32, PH_CH, PH_D, PH_DH, PH_F, PH_G, PH_HH, PH_JH, PH_K, PH_L, PH_M, PH_N, PH_NG, PH_P, PH_R, PH_S, PH_SH,
    PH_T, PH_TH, PH_V, PH_W, PH_Y, PH_Z, PH_ZH,
    PH_COUNT
};
#define PH_VOWEL0 PH_AA
#define PH_NVOWEL 16
static inline int ph_is_vowel(int p) { return p >= PH_AA && p <= PH_AX; }
static inline int ph_is_cons(int p) { return p >= PH_B && p < PH_COUNT; }
#define CH_PHRASE_MAX 96          /* bytes of a phrase's codes, PH_END included */
#define CH_TEXT_MAX 48            /* characters of a phrase's text, NUL included */
#endif
