#!/usr/bin/env python3
"""Make chimera_tables.h: chimera's vowel area functions per body, the reflection-coefficient table, the glottal pulse
and the consonant gestures, from CHIMERA's calibrated vowel data (chimera_data.json, an excerpt of CHIMERA's
vowelTargets.generated.json / consonantTargets.generated.json, MIT; PROVENANCE.md).

    python3 gen_tables.py [--report]        (writes chimera_tables.h and fit_report.json next to this file)

How a vowel's area function is made (offline; nothing of this runs on the OP-1):
  1. A seed from CHIMERA's articulator targets for that vowel and body (tongue body x / y, jaw, lip aperture,
     protrusion, width): a tongue constriction whose place follows the tongue body's x (back = pharynx, front =
     palate) and whose narrowness follows its height, a wider pharynx behind a front tongue, and a lip section from
     the lip aperture and width. This is chimera's own simple articulatory model, not CHIMERA's geometry.
  2. The seed's log areas plus eight cosine modes are fitted so that chimera's own lattice (tract_model.transfer: the
     exact recursion chimera.c runs, at its section count and the 88.2 kHz voice rate) has F1..F3 at CHIMERA's
     targets for that body (Hillenbrand et al. 1995 means for the English vowels), with a small penalty that keeps
     the shape near the seed and areas within 0.05 .. 12 cm2. A vowel that misses (F1 / F2 off by more than 3 %)
     is tried again from related vowels' fitted shapes and their blends (RELATED); the best fit is kept.
The tract runs at 44.1 kHz (chimera.c renders 64 samples a call and doubles them to R246's 128 at 88.2 kHz): one
section is c / 44,100 = 0.794 cm; bodies are tract lengths, male 22 sections (17.5 cm), female 19 (15.1 cm), child 16
(12.7 cm), as CHIMERA's body scales (1.0 / 0.9 / 0.74 with a shorter pharynx) give them.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
Data: CHIMERA (github.com/jamesondh/chimera-vocal-synth), Copyright (c) 2026 Jameson Hodge, MIT licence.
"""
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import tract_model as T  # noqa: E402

FS = 44100
BODIES = [('male', 22), ('female', 19), ('child', 16)]
# vowel order in the tables (index = what chimera.c's paths and the lyric rules use)
VOWELS = ['u', 'o', 'ɑ', 'ɔ', 'ʌ', 'æ', 'ɛ', 'e', 'ɪ', 'i', 'ʊ', 'ə', 'ɝ']
RELATED = {'ɔ': ['o', 'ɑ'], 'ɝ': ['ə', 'ʊ']}   # retry seeds when a fit misses (fit order = VOWELS)
LOGQ = 256           # log areas in Q8 natural log (ln cm2 * 256)
NMODES = 8
KTAB_SHIFT = 2       # reflection table index = clamp(dlogA, -1024, 1023) >> 2  (512 entries)


def seed(art, n):
    s = (np.arange(n) + 0.5) / n
    la = np.full(n, math.log(2.6))
    la[s < 0.09] = math.log(1.3)                                        # epilarynx tube
    front = min(1.0, max(0.0, (art['tbX'] - 1.6) / 2.2))
    high = min(1.0, max(0.0, (art['tbY'] - 5.6) / 2.2))
    sc = 0.32 + 0.48 * front                                            # constriction place along the tract
    lc = math.log(3.2) - high * (math.log(3.2) - math.log(0.30))        # constriction area
    g = np.exp(-((s - sc) / 0.11) ** 2)
    la = la + g * (lc - la)
    back = np.exp(-((s - 0.28) / 0.12) ** 2) * front                    # pharynx opens behind a front tongue
    la += back * math.log(2.2)
    lipa = 0.12 + 1.6 * art['lipAp'] * (0.3 + 0.7 * art['lipWidth'])
    lipa = min(5.0, max(0.1, lipa))
    nl = 2 + int(round(art.get('lipProt', 0.0) * 1.5))                  # protrusion: a longer narrow lip tube
    la[-nl:] = math.log(lipa)
    return la


def modes(n):
    s = (np.arange(n) + 0.5) / n
    return np.array([np.cos(math.pi * (j + 1) * s) for j in range(NMODES)])


def f123(la):
    pk, _, _ = T.formants(la, FS, fmax=5000, n=1500)
    return pk[:3]


def fit(art, target, n, alt=()):
    la0 = seed(art, n)
    M = modes(n)
    tgt = np.log(np.array(target, float))
    w = np.array([1.0, 1.0, 0.4])

    def cost(c):
        la = la0 + c @ M
        pk = f123(la)
        if len(pk) < 3:
            return 10.0
        e = np.log(np.array(pk)) - tgt
        pen = np.sum(np.maximum(0, np.log(0.05) - la) ** 2 + np.maximum(0, la - np.log(12)) ** 2)
        return float(np.sum(w * e * e) + 0.0015 * np.sum(c * c) + 4 * pen)

    best = None
    for start in (np.zeros(NMODES), 0.2 * np.random.default_rng(1).standard_normal(NMODES)):
        r = minimize(cost, start, method='Powell', options={'xtol': 1e-3, 'ftol': 1e-7, 'maxfev': 6000})
        if best is None or r.fun < best.fun:
            best = r
    la = la0 + best.x @ M
    cf = cost_for(target)
    cands = [la]
    if alt:                                           # related vowels' fitted shapes as seeds, and blends of two
        cands += [fit_from(np.array(a0, float), cf, n)[0] for a0 in alt]
        if len(alt) >= 2:
            bl = [(1 - t) * np.array(alt[0]) + t * np.array(alt[1]) for t in np.linspace(0.1, 0.9, 17)]
            cands.append(fit_from(min(bl, key=cf), cf, n)[0])
    la = min(cands, key=cf)
    la = np.clip(la, math.log(0.05), math.log(12))
    return la, f123(la)


def cost_for(target):
    tgt = np.log(np.array(target, float))
    w = np.array([1.0, 1.0, 0.4])

    def c(la):
        pk = f123(la)
        if len(pk) < 3:
            return 10.0
        e = np.log(np.array(pk)) - tgt
        return float(np.sum(w * e * e))
    return c


def fit_from(la0, cf, n):
    M = modes(n)

    def cost(c):
        la = la0 + c @ M
        pen = np.sum(np.maximum(0, np.log(0.05) - la) ** 2 + np.maximum(0, la - np.log(12)) ** 2)
        return cf(la) + 0.0015 * np.sum(c * c) + 4 * pen
    r = minimize(cost, np.zeros(NMODES), method='Powell', options={'xtol': 1e-3, 'ftol': 1e-7, 'maxfev': 6000})
    la = la0 + r.x @ M
    return la, f123(la)


def q_logA(la):
    return [int(round(v * LOGQ)) for v in la]


def main():
    data = json.loads((HERE / 'chimera_data.json').read_text())
    report = {'fs': FS, 'bodies': {}}
    tables = {}
    for body, n in BODIES:
        rows = []
        rep = {}
        done = {}
        for v in VOWELS:
            d = data['vowels'][body][v]
            alt = [done[a] for a in RELATED.get(v, []) if a in done]
            la, pk = fit(d['artic'], d['target'], n, alt)
            done[v] = la
            q = q_logA(la)
            pkq = f123(np.array(q) / LOGQ)
            rows.append(q)
            rep[v] = {'target': d['target'], 'model': [round(x) for x in pkq],
                      'err_pct': [round(100 * (a / b - 1), 1) for a, b in zip(pkq, d['target'])],
                      'areas_cm2': [round(math.exp(x / LOGQ), 3) for x in q]}
            print(f'{body:6s} {v}: target {d["target"]} model {[round(x) for x in pkq]}', file=sys.stderr)
        tables[body] = rows
        report['bodies'][body] = {'sections': n, 'vowels': rep}
    (HERE / 'fit_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1))

    # articulator targets per vowel (for the screen): male body, CHIMERA's template-space cm
    art_keys = ['tbX', 'tbY', 'jaw', 'lipAp', 'lipProt', 'ttX', 'ttY']
    arts = [[int(round(data['vowels']['male'][v]['artic'][k] * 256)) for k in art_keys] for v in VOWELS]

    # reflection table: k = tanh(d / 2), d = (lnA_{i-1} - lnA_i), index (d_q8 >> 2) + 256, Q15
    ktab = []
    for i in range(512):
        d = ((i - 256) << KTAB_SHIFT) / LOGQ
        ktab.append(max(-32767, min(32767, int(round(32767 * math.tanh(d / 2))))))

    # glottal flow derivative over the open phase (LF-like, Rosenberg opening + sharp closing), 256 points + 1
    # t in 0..1 of the open phase: rising flow 0..tp (cosine), falling tp..1 (cosine to a hard closure)
    tp = 0.68
    flow = []
    for i in range(257):
        t = i / 256
        if t < tp:
            u = 0.5 * (1 - math.cos(math.pi * t / tp))
        else:
            u = math.cos(0.5 * math.pi * (t - tp) / (1 - tp))
        flow.append(u)
    dflow = [flow[i + 1] - flow[i] if i < 256 else flow[256] - flow[255] for i in range(257)]
    m = max(abs(x) for x in dflow)
    gtab = [int(round(30000 * x / m)) for x in dflow]

    out = ['/* chimera_tables.h: generated by gen_tables.py, do not edit.',
           ' * Vowel area functions fitted to CHIMERA\'s calibrated formant targets (Hillenbrand et al. 1995 means),',
           ' * seeded from CHIMERA\'s articulator targets. CHIMERA: github.com/jamesondh/chimera-vocal-synth, commit',
           ' * 1d3ea496cad0fbe3e73361515aec187e868fbd47, Copyright (c) 2026 Jameson Hodge, MIT licence (PROVENANCE.md).',
           ' * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */',
           '#ifndef CHIMERA_TABLES_H', '#define CHIMERA_TABLES_H', '#include <stdint.h>',
           f'#define CH_NV {len(VOWELS)}', f'#define CH_NMAX {BODIES[0][1]}', f'#define CH_LOGQ {LOGQ}',
           '/* vowels: ' + ' '.join(f'{i}={v}' for i, v in enumerate(VOWELS)) + ' */']
    for i, v in enumerate(VOWELS):
        name = {'u': 'U', 'o': 'O', 'ɔ': 'OH', 'ɑ': 'A', 'ʌ': 'UH', 'æ': 'AE', 'ɛ': 'EH', 'e': 'E', 'ɪ': 'IH', 'i': 'I',
                'ʊ': 'UU', 'ə': 'SCHWA', 'ɝ': 'ER'}[v]
        out.append(f'#define CH_V_{name} {i}')
    out.append(f'static const uint8_t ch_body_n[3] = {{ {", ".join(str(n) for _, n in BODIES)} }};')
    for body, n in BODIES:
        out.append(f'static const int16_t ch_vow_{body}[CH_NV][{n}] = {{')
        for v, r in zip(VOWELS, tables[body]):
            out.append('    { ' + ', '.join(str(x) for x in r) + ' },')
        out.append('};')
    out.append('/* articulators per vowel (male body, CHIMERA template cm x 256): tbX tbY jaw lipAp lipProt ttX ttY */')
    out.append('static const int16_t ch_art[CH_NV][7] = {')
    for r in arts:
        out.append('    { ' + ', '.join(str(x) for x in r) + ' },')
    out.append('};')
    # per-vowel level: half of each vowel's peak gain difference to the body's mean is taken out (vowels keep some
    # of their natural loudness order; female i no longer rings 10 dB over the rest)
    out.append('/* per-vowel output gain, Q12 */')
    out.append('static const int16_t ch_vgain[3][CH_NV] = {')
    for body, n in BODIES:
        pks = []
        for r in tables[body]:
            f = np.linspace(80, 4000, 2000)
            pks.append(20 * np.log10(np.max(np.abs(T.transfer(np.array(r) / LOGQ, f, FS)))))
        m = float(np.mean(pks))
        out.append('    { ' + ', '.join(str(int(round(4096 * 10 ** (-(p - m) / 2 / 20)))) for p in pks) + ' },')
        report['bodies'][body]['peak_db'] = [round(p, 1) for p in pks]
    out.append('};')
    (HERE / 'fit_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1))
    out.append(f'/* k = tanh(dlnA / 2) Q15, index (dlnA_q8 >> {KTAB_SHIFT}) + 256 */')
    out.append('static const int16_t ch_ktab[512] = {')
    for i in range(0, 512, 16):
        out.append('    ' + ', '.join(str(x) for x in ktab[i:i + 16]) + ',')
    out.append('};')
    out.append('/* glottal flow derivative over the open phase, 257 points */')
    out.append('static const int16_t ch_glot[257] = {')
    for i in range(0, 257, 16):
        out.append('    ' + ', '.join(str(x) for x in gtab[i:i + 16]) + ',')
    out.append('};')
    out.append('#endif')
    (HERE / 'chimera_tables.h').write_text('\n'.join(out) + '\n')


if __name__ == '__main__':
    main()
