/* chimera_dsp.h: chimera's voice DSP. A Kelly-Lochbaum vocal tract driven by a glottal pulse, with a nasal side branch
 * at the velum, a frequency-dependent lip reflection, aspiration at the glottis and turbulence noise at the narrowest
 * place. The tract runs at 44.1 kHz (one section = one sample = c / 44,100 = 0.794 cm; male 22, female 19, child 16
 * sections): 64 samples a call, doubled to R246's 128 at 88.2 kHz by chimera.c. At the voice rate it would cost 4x
 * (twice the sections, twice the samples) for content above 22 kHz that R246's 2:1 decimator removes anyway.
 * Integers only, no division per sample (one or two per block), no libc. Included by chimera.c and the host tests.
 *
 * Per sample (tract_model.py is the same recursion in float, and its closed-form transfer is what the vowel areas
 * were fitted with); waves are int16 with saturating fractional arithmetic (Blackfin's 16-bit ALU / MAC):
 *     R0' = rg L0 + glottis
 *     w_i = k_i (R_{i-1} + L_i);  R_i' = R_{i-1} - w_i;  L_{i-1}' = L_i + w_i      i = 1 .. N-1 (k Q15)
 *     lip += a (R_{N-1} - lip);  L_{N-1}' = rl lip;  out = R_{N-1}' (+ the nose's end)
 * At the velum junction (CH_VEL_OF) a three-port junction joins the nose while the velum is open.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 * Vowel data: CHIMERA (github.com/jamesondh/chimera-vocal-synth), Copyright (c) 2026 Jameson Hodge, MIT licence. */
#ifndef CHIMERA_DSP_H
#define CHIMERA_DSP_H
#include <stdint.h>
#include "chimera_tables.h"

#define CH_NN       8           /* nose sections (6.4 cm: velum port to nostrils, shortened) */
#define CH_RG       24576       /* glottal end reflection, closed phase, Q15 (0.75) */
#define CH_RGO      16384       /* ... open phase (0.50): damps F1 as a real open glottis does */
#define CH_LIPA     14746       /* lip one-pole, Q15 (0.45) */
#define CH_RN       (-19661)    /* nostril reflection, Q15 (-0.60): the nose's soft walls lose more than the mouth */
#define CH_SUB      64          /* tract samples per call (44.1 kHz) */

/* saturating fractional 16-bit arithmetic: Blackfin builtins on the target, the same in C on the host */
#if defined(__bfin__)
#define ch_add(a, b) __builtin_bfin_add_fr1x16((a), (b))
#define ch_sub(a, b) __builtin_bfin_sub_fr1x16((a), (b))
#define ch_mul(a, b) __builtin_bfin_mult_fr1x16((a), (b))
#else
static inline int16_t ch_sat(int32_t x) { return (int16_t)(x > 32767 ? 32767 : x < -32768 ? -32768 : x); }
static inline int16_t ch_add(int16_t a, int16_t b) { return ch_sat((int32_t)a + b); }
static inline int16_t ch_sub(int16_t a, int16_t b) { return ch_sat((int32_t)a - b); }
static inline int16_t ch_mul(int16_t a, int16_t b) { return ch_sat(((int32_t)a * b) >> 15); }   /* (T): truncates */
#endif
static inline int16_t ch_s16(int32_t x) { return (int16_t)(x > 32767 ? 32767 : x < -32768 ? -32768 : x); }

typedef struct {
    int16_t R[CH_NMAX], L[CH_NMAX];       /* travelling waves (Q15 signal; the glottal pulse peaks near 3000) */
    int16_t nR[CH_NN], nL[CH_NN];         /* nose */
    int16_t k[CH_NMAX];                   /* k[i]: junction between i-1 and i, Q15 (k[0] unused) */
    int16_t la[CH_NMAX];                  /* current log areas, Q8 ln cm2 */
    int32_t lip, nlip;                    /* lip / nostril reflection low-pass states */
    uint32_t gph;                         /* glottal phase, 2^32 = one period */
    uint32_t rng;
    int32_t gfac;                         /* jitter / fry factor for the current period, Q12 (4096 = 1) */
    int32_t gamp;                         /* amplitude of the current period, Q12 */
    uint32_t vph;                         /* vibrato phase */
    int16_t g3[3];                        /* three-port junction weights Q13: pharynx, mouth, nose (2A/sum) */
    int16_t pk;                           /* the block's output peak (after gain) */
    int32_t noise_lp;                     /* frication noise colour */
    int16_t last;                         /* previous output sample (the 2x interpolation) */
    int16_t nose_tail;                    /* blocks to keep the nose running after the velum closes */
    int16_t rl;                           /* lip end reflection, Q15 (from the lip area, ch_coefs) */
    uint8_t n, nose_on, imin, odd;        /* sections, nose running, narrowest section, fry period parity */
} ch_tract_t;

/* per-block controls, already in engine units */
typedef struct {
    int32_t oq;                           /* open quotient Q15 (0.3 .. 0.85) */
    int32_t voice;                        /* voicing amplitude Q12 (0 = whisper) */
    int32_t asp;                          /* aspiration noise level Q12 */
    int32_t fric;                         /* frication noise level at the narrowest place Q12 */
    int32_t vib_inc, vib_depth;           /* vibrato phase step per block; pitch deviation Q12 of the increment */
    int32_t jitter;                       /* jitter depth Q12 */
    int32_t fry;                          /* 0 .. 4096: alternate-period damping and subharmonic */
    int32_t velum;                        /* velum port log area Q8 (<= -1000: closed) */
    int32_t gain;                         /* output gain Q12 (velocity, the vowel's level, the limiter) */
    int32_t e0, de;                       /* own envelope at the block's start and its step per tract sample, Q15 */
    uint8_t sine;                         /* source: 0 the glottal pulse, 1 a sine (the bird's syrinx) */
} ch_ctl_t;

#define CH_VEL_OF(n) (((n) * 17 + 22) / 44)   /* velum place: 17 of 44 parts from the glottis (8 / 7 / 6) */


/* exp(x / 256) * 1024 for x = -1024 .. 1023 (the three-port weights; per block only) */
static inline int32_t ch_exp_q8(int32_t x)
{
    int32_t y = (x * 369) >> 8;                         /* x * log2(e) in Q8 (369 / 256 = 1.4414) */
    int32_t ip = y >> 8, fr = y & 255;                  /* 2^ip * 2^(fr/256) */
    int32_t m = 1024 + ((fr * (710 + ((fr * 245) >> 8))) >> 8);   /* 2^f ~ 1 + 0.693 f + 0.24 f^2, Q10 */
    if (ip >= 0) return ip > 10 ? (m << 10) : (m << ip);
    return ip < -10 ? 1 : (m >> -ip);
}

/* areas -> reflection coefficients and the three-port weights; once a block */
static inline void ch_coefs(ch_tract_t *t, int32_t velum)
{
    const int n = t->n;
    int32_t mn = 32767; int im = n - 1;
    for (int i = 1; i < n; i++) {
        int32_t d = t->la[i - 1] - t->la[i];
        if (d > 1023) d = 1023; else if (d < -1024) d = -1024;
        t->k[i] = ch_ktab[(d >> 2) + 256];
        if (t->la[i] < mn && i > 1) { mn = t->la[i]; im = i; }
    }
    t->imin = (uint8_t)im;
    {                                                   /* lips: a small opening radiates less (tract_model.rl_of) */
        int32_t al = ch_exp_q8(t->la[n - 1]);           /* cm2 Q10 */
        int32_t r = 31785 - ((al * 1147) >> 10);        /* 0.97 - 0.035 A */
        t->rl = (int16_t)-(r < 26214 ? 26214 : r > 31785 ? 31785 : r);
    }
    const int v = CH_VEL_OF(n);
    if (velum > -1000) {
        int32_t ap = ch_exp_q8(t->la[v - 1]), am = ch_exp_q8(t->la[v]), an = ch_exp_q8(velum);
        int32_t inv = (int32_t)((1u << 30) / (uint32_t)(ap + am + an));   /* 2^30 / sum: one division a block */
        t->g3[0] = (int16_t)((ap * inv) >> 16); t->g3[1] = (int16_t)((am * inv) >> 16); t->g3[2] = (int16_t)((an * inv) >> 16);
        t->nose_on = 1; t->nose_tail = 300;
    } else if (t->nose_on) {                           /* closing: run the junction without the nose until it rings out */
        int32_t ap = ch_exp_q8(t->la[v - 1]), am = ch_exp_q8(t->la[v]);
        int32_t inv = (int32_t)((1u << 30) / (uint32_t)(ap + am));
        t->g3[0] = (int16_t)((ap * inv) >> 16); t->g3[1] = (int16_t)((am * inv) >> 16); t->g3[2] = 0;
        if (--t->nose_tail <= 0) t->nose_on = 0;
    }
}

/* the nose's fixed shape: Q15 reflections at its junctions 1..CH_NN-1 (a widening cavity, then the nostrils) */
static const int16_t ch_nose_k[CH_NN] = { 0, -4800, -2800, -600, 0, 1200, 2400, 3000 };

/* the lattice from junction a to b-1 (rp = R[a-1] before the step); returns R[b-1] before the step. The C reference;
 * Blackfin builds run chimera_kernel.S's ch_lattice_asm (bit-exact, 3 packets a section instead of 7) */
static inline int16_t ch_lattice_c(int16_t *R, int16_t *L, const int16_t *k, int a, int b, int16_t rp)
{
    for (int i = a; i < b; i++) {
        int16_t ri = R[i], li = L[i];
        int16_t w = ch_mul(k[i], ch_add(rp, li));
        R[i] = ch_sub(rp, w);
        L[i - 1] = ch_add(li, w);
        rp = ri;
    }
    return rp;
}
#if defined(__bfin__) && !defined(CH_LATTICE_C)
int16_t ch_lattice_asm(int16_t *R, int16_t *L, const int16_t *k, int16_t rp, int n);   /* n = b - a >= 1 */
#define ch_lattice(R, L, k, a, b, rp) ch_lattice_asm((R) + (a), (L) + (a), (k) + (a), (rp), (b) - (a))
#else
#define ch_lattice ch_lattice_c
#endif

/* a new glottal period: jitter, shimmer, fry (rare: out of the sample loop so it keeps its registers) */
static __attribute__((noinline)) uint32_t ch_period(ch_tract_t *t, const ch_ctl_t *c, uint32_t rng)
{
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    int32_t r = (int32_t)(rng >> 20) - 2048;
    t->gfac = 4096 + ((r * c->jitter) >> 11);
    t->odd ^= 1;
    int32_t a = 4096 + ((((int32_t)(rng & 2047)) - 1024) * c->jitter >> 10);
    if (t->odd && c->fry) { a -= (a * c->fry) >> 13; t->gfac -= c->fry >> 2; }
    t->gamp = (a * c->voice) >> 12;
    return rng;
}

/* pass 2's inputs (chimera_kernel.S ch_tract_pass_asm reads them at these offsets: keep the layout) */
typedef struct {
    int16_t *R, *L; const int16_t *k;       /*  0,  4,  8 */
    int16_t *rec;                            /* 12: 64 x { src, rg, fz, y } */
    int32_t n1;                              /* 16: sections before the velum (v - 1), or n - 1 without the nose */
    int16_t *Rl, *Ll, *Rim, *Lim1;           /* 20 &R[n-1], 24 &L[n-1], 28 &R[im], 32 &L[im-1] */
    int32_t lip, rl, fr, nose;               /* 36, 40, 44 (unused), 48 */
    int16_t *Rv, *Lv, *nL;                   /* 52 &R[v], 56 &L[v], 60 */
    int32_t g01, g2, nlip;                   /* 64 g0 | g1 << 16, 68, 72 */
    const int16_t *nk;                       /* 76 */
    int32_t ri;                              /* 80 scratch */
    int16_t *nR; const int16_t *kv1;         /* 84, 88 &k[v+1] */
    int32_t n2;                              /* 92 n - 1 - v */
} ch_pass_t;
typedef char ch_pass_layout_ok[(sizeof(void *) != 4 || __builtin_offsetof(ch_pass_t, n2) == 92) ? 1 : -1];

/* pass 2 in C: the reference for ch_tract_pass_asm (and the host's) */
static void ch_tract_pass_c(ch_pass_t *x)
{
    int16_t *R = x->R, *L = x->L, *rec = x->rec;
    int16_t lip = (int16_t)x->lip, nlip = (int16_t)x->nlip;
    const int16_t g0 = (int16_t)x->g01, g1 = (int16_t)(x->g01 >> 16), g2 = (int16_t)x->g2;
    for (int s = 0; s < CH_SUB; s++, rec += 4) {
        int16_t rp = R[0];
        R[0] = ch_add(ch_mul(L[0], rec[1]), rec[0]);
        rp = ch_lattice_c(R + 1, L + 1, x->k + 1, 0, x->n1, rp);
        if (x->nose) {                            /* three-port at the velum: p = sum g_j in_j; out_j = p - in_j */
            int16_t ri = x->Rv[0], li = x->Lv[0], ni = x->nL[0];
            int32_t p = (g0 * rp + g1 * li + g2 * ni) >> 13;               /* 16 x 16 products */
            x->Rv[0] = ch_s16(p - li); x->Lv[-1] = ch_s16(p - rp);
            int16_t nrp = x->nR[0];
            x->nR[0] = ch_s16(p - ni);
            nrp = ch_lattice_c(x->nR + 1, x->nL + 1, x->nk + 1, 0, CH_NN - 1, nrp);
            nlip = ch_add(nlip, ch_mul(CH_LIPA, ch_sub(nrp, nlip)));
            x->nL[CH_NN - 1] = ch_mul(nlip, CH_RN);
            rp = ch_lattice_c(x->Rv + 1, x->Lv + 1, x->kv1, 0, x->n2, ri);
        }
        lip = ch_add(lip, ch_mul(CH_LIPA, ch_sub(rp, lip)));
        *x->Ll = ch_mul(lip, (int16_t)x->rl);
        *x->Rim = ch_add(*x->Rim, rec[2]); x->Lim1[0] = ch_sub(x->Lim1[0], rec[2]);
        rec[3] = x->nose ? ch_add(*x->Rl, x->nR[CH_NN - 1] >> 1) : *x->Rl;   /* the murmur is quieter */
    }
    x->lip = lip; x->nlip = nlip;
}
#if defined(__bfin__) && !defined(CH_LATTICE_C)
void ch_tract_pass_asm(ch_pass_t *x);
#define ch_tract_pass ch_tract_pass_asm
#else
#define ch_tract_pass ch_tract_pass_c
#endif

static int16_t ch_rec[CH_SUB * 4] __attribute__((aligned(32)));   /* the passes' samples (one voice at a time) */

/* the block in three passes, so the tract pass (the lattice calls) keeps few values alive: (1) the glottis, aspiration
 * and frication noise for all 64 samples (no state from the tract), (2) the tract, (3) gain, envelope, peak and the 2x
 * doubling. Specialised per (nose, sine source, frication). */
static inline __attribute__((always_inline)) void ch_tract_body(ch_tract_t *t, const ch_ctl_t *c, uint32_t base,
                                                               int16_t *out, const int nose, const int sine, const int fr)
{
    const int n = t->n, v = CH_VEL_OF(n);
    int16_t *R = t->R, *L = t->L;
    const int16_t *k = t->k;
    int16_t *rec = ch_rec;                           /* per sample: src, rg, fz, y */
    /* ---- pass 1: the glottis (a pulse of flow derivative over the open phase), aspiration, frication noise ---- */
    {
        uint32_t ph = t->gph, rng = t->rng;
        /* glottal pulse index: ((ph >> 16) * iq) >> 17 runs 0..256 over the open phase (iq < 2^11) */
        const uint32_t iq = (1u << 24) / (uint32_t)c->oq;
        const int32_t dev = c->vib_depth;
        uint32_t step = base + (uint32_t)((int32_t)(base >> 12) * (dev + t->gfac - 4096));
        int16_t gamp = (int16_t)(t->gamp > 8191 ? 32767 : t->gamp << 2);   /* Q15 */
        const int16_t asp_o = (int16_t)(c->asp * 3 < 32767 ? c->asp * 3 : 32767), asp_c = (int16_t)c->asp;
        const int16_t fric = (int16_t)((c->fric > 4095 ? 4095 : c->fric) >> 2);   /* Q15: up to 1/32 of the noise */
        int16_t nlp = (int16_t)t->noise_lp;
        for (int s = 0; s < CH_SUB; s++) {
            uint32_t nph = ph + step;
            if (nph < ph) {                               /* a new period */
                rng = ch_period(t, c, rng);
                gamp = (int16_t)(t->gamp > 8191 ? 32767 : t->gamp << 2);
                step = base + (uint32_t)((int32_t)(base >> 12) * (dev + t->gfac - 4096));
            }
            ph = nph;
            uint32_t idx = ((uint32_t)(uint16_t)(ph >> 16) * (uint32_t)(uint16_t)iq) >> 17;
            int16_t g = sine ? (int16_t)(OP1_SINE_TABLE[ph >> 19] - (OP1_SINE_TABLE[ph >> 19] >> 3))
                             : idx < 256 ? ch_glot[idx] : 0;                    /* +-30000 */
            rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
            int16_t nz = (int16_t)(rng >> 16);                               /* white, full scale */
            rec[4 * s] = ch_add(ch_mul(g, gamp) >> 4, ch_mul(nz, idx < 256 ? asp_o : asp_c) >> 3);
            rec[4 * s + 1] = idx < 256 ? CH_RGO : CH_RG;                             /* an open glottis absorbs more */
            if (fr) {                                    /* high-passed noise for the narrowest place */
                nlp = (int16_t)((nlp + (nz >> 2)) >> 1);
                rec[4 * s + 2] = ch_mul(ch_sub(nz >> 2, nlp), fric);
            } else rec[4 * s + 2] = 0;
        }
        t->gph = ph; t->rng = rng; t->noise_lp = nlp;
    }
#ifdef CH_PROF_PASS
    CH_PROF_PASS(6);
#endif
    /* ---- pass 2: the tract (chimera_kernel.S on the unit) ---- */
    {
        ch_pass_t x;
        x.R = R; x.L = L; x.k = k; x.rec = rec;
        x.n1 = nose ? v - 1 : n - 1;
        x.Rl = &R[n - 1]; x.Ll = &L[n - 1]; x.Rim = &R[t->imin]; x.Lim1 = &L[t->imin - 1];
        x.lip = t->lip; x.rl = t->rl; x.fr = fr; x.nose = nose;
        x.Rv = &R[v]; x.Lv = &L[v]; x.nL = t->nL; x.nR = t->nR; x.nk = ch_nose_k; x.kv1 = &k[v + 1];
        x.g01 = (uint16_t)t->g3[0] | (int32_t)((uint32_t)(uint16_t)t->g3[1] << 16); x.g2 = t->g3[2]; x.nlip = t->nlip;
        x.n2 = n - 1 - v; x.ri = 0;
        ch_tract_pass(&x);
        t->lip = (int16_t)x.lip; t->nlip = (int16_t)x.nlip;
    }
#ifdef CH_PROF_PASS
    CH_PROF_PASS(7);
#endif
    /* ---- pass 3: gain and envelope on the 44.1 kHz samples, the peak, the doubling to 88.2 kHz ---- */
    {
        const int32_t gv = c->gain, de = c->de;
        int32_t e = c->e0, pk = 0;
        int16_t last = t->last;
        for (int s = 0; s < CH_SUB; s++) {
            int32_t x = ((int32_t)rec[4 * s + 3] * gv) >> 12;
            x = (x * (e >> 3)) >> 12;
            e += de;
            x = x > 32767 ? 32767 : x < -32767 ? -32767 : x;
            int16_t y = (int16_t)x;
            int32_t ax = x < 0 ? -x : x; pk = ax > pk ? ax : pk;
            out[2 * s] = (int16_t)(((int32_t)last + y) >> 1);
            out[2 * s + 1] = y;
            last = y;
        }
        t->last = last; t->pk = (int16_t)pk;
    }
}

/* the block in one pass (no nose): the lattice through ch_lattice (the kernel on the unit), the rest in C. Without
 * the nose this is cheaper in the cache model than the three passes; with it the three passes win. */
static inline __attribute__((always_inline)) void ch_tract_body1(ch_tract_t *t, const ch_ctl_t *c, uint32_t base,
                                                                int16_t *out, const int sine, const int fr)
{
    const int n = t->n;
    int16_t *R = t->R, *L = t->L;
    const int16_t *k = t->k;
    uint32_t ph = t->gph, rng = t->rng;
    int16_t lip = (int16_t)t->lip;
    const int16_t rl = t->rl;
    const uint32_t iq = (1u << 24) / (uint32_t)c->oq;
    const int32_t dev = c->vib_depth;
    uint32_t step = base + (uint32_t)((int32_t)(base >> 12) * (dev + t->gfac - 4096));
    int16_t gamp = (int16_t)(t->gamp > 8191 ? 32767 : t->gamp << 2);
    const int16_t asp_o = (int16_t)(c->asp * 3 < 32767 ? c->asp * 3 : 32767), asp_c = (int16_t)c->asp;
    const int16_t fric = (int16_t)((c->fric > 4095 ? 4095 : c->fric) >> 2);
    const int im = t->imin;
    int16_t nlp = (int16_t)t->noise_lp;
    int16_t last = t->last;
    const int32_t gv = c->gain, de = c->de;
    int32_t e = c->e0, pk = 0;
    for (int s = 0; s < CH_SUB; s++) {
        uint32_t nph = ph + step;
        if (nph < ph) {
            rng = ch_period(t, c, rng);
            gamp = (int16_t)(t->gamp > 8191 ? 32767 : t->gamp << 2);
            step = base + (uint32_t)((int32_t)(base >> 12) * (dev + t->gfac - 4096));
        }
        ph = nph;
        uint32_t idx = ((uint32_t)(uint16_t)(ph >> 16) * (uint32_t)(uint16_t)iq) >> 17;
        int16_t g = sine ? (int16_t)(OP1_SINE_TABLE[ph >> 19] - (OP1_SINE_TABLE[ph >> 19] >> 3))
                         : idx < 256 ? ch_glot[idx] : 0;
        rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
        int16_t nz = (int16_t)(rng >> 16);
        int16_t src = ch_add(ch_mul(g, gamp) >> 4, ch_mul(nz, idx < 256 ? asp_o : asp_c) >> 3);
        int16_t rp = R[0];
        R[0] = ch_add(ch_mul(L[0], idx < 256 ? CH_RGO : CH_RG), src);
        rp = ch_lattice(R, L, k, 1, n, rp);
        lip = ch_add(lip, ch_mul(CH_LIPA, ch_sub(rp, lip)));
        L[n - 1] = ch_mul(lip, rl);
        int16_t f = 0;
        if (fr) { nlp = (int16_t)((nlp + (nz >> 2)) >> 1); f = ch_mul(ch_sub(nz >> 2, nlp), fric); }
        R[im] = ch_add(R[im], f); L[im - 1] = ch_sub(L[im - 1], f);
        int32_t x = ((int32_t)R[n - 1] * gv) >> 12;
        x = (x * (e >> 3)) >> 12;
        e += de;
        x = x > 32767 ? 32767 : x < -32767 ? -32767 : x;
        int16_t y = (int16_t)x;
        int32_t ax = x < 0 ? -x : x; pk = ax > pk ? ax : pk;
        out[2 * s] = (int16_t)(((int32_t)last + y) >> 1);
        out[2 * s + 1] = y;
        last = y;
    }
    t->gph = ph; t->rng = rng; t->lip = lip; t->noise_lp = nlp; t->last = last; t->pk = (int16_t)pk;
}

/* ---- the whole-sample loop (2026-11-12, -DCH_BLOCK; not the default) ----
 * Everything a tract sample needs in one assembly loop (chimera_kernel.S ch_block_asm), bit-exact with ch_block_c
 * (chimera_bench.py kern: 800 random blocks; the 62 demos). Measured on bcore it is slower than the default below (6
 * voices, packets / cold cycles: PLAY 94.4k / 133.6k against 87.3k / 122.4k; nose 144.2k / 184.7k against 141.9k /
 * 182.8k): GCC's scheduling of the specialised C glue beats this straight assembly, whose scalar glue cannot use the
 * parallel slots. Kept for the next step (the state in registers, the lattice inlined). */
#ifdef CH_BLOCK
/* The block: one loop over the 64 tract samples doing everything a sample needs, in this order (ch_block_c; on the
 * unit chimera_kernel.S ch_block_asm, bit for bit):
 *   glottis: ph += step (a new period: jitter, shimmer, fry and a new step); the pulse (or a sine) at the phase;
 *   white noise (xorshift); src = pulse * gamp / 16 + noise * aspiration / 8 (more aspiration in the open phase);
 *   tract: R0 = L0 rg + src (rg lower in the open phase); the lattice 1 .. n-1, with the velum's three-port junction
 *   and the nose while it is open; the lip reflection; frication: high-passed noise into R[im] / L[im-1];
 *   out: R[n-1] (+ the nose / 2) times gain and the interpolated envelope, the peak, doubled to 88.2 kHz.
 * The context's layout is the assembly's: keep the offsets. */
typedef struct {
    int16_t *R, *L; const int16_t *k;       /*  0,  4,  8 */
    int16_t *out;                            /* 12: 128 samples */
    int32_t n1;                              /* 16: sections before the velum (v - 1), or n - 1 without the nose */
    int16_t *Rl, *Ll, *Rim, *Lim1;           /* 20 &R[n-1], 24 &L[n-1], 28 &R[im], 32 &L[im-1] */
    int32_t lip, rl, fr, nose;               /* 36, 40, 44, 48 */
    int16_t *Rv, *Lv, *nL;                   /* 52 &R[v], 56 &L[v], 60 */
    int32_t g01, g2, nlip;                   /* 64 g0 | g1 << 16, 68, 72 */
    const int16_t *nk;                       /* 76 */
    int32_t ri;                              /* 80 scratch */
    int16_t *nR; const int16_t *kv1;         /* 84, 88 &k[v+1] */
    int32_t n2;                              /* 92 n - 1 - v */
    uint32_t ph, step, rng, iq, base;        /* 96, 100, 104, 108, 112 */
    int32_t dev, gfac, gamp, gamp16;         /* 116, 120, 124, 128 */
    int32_t asp_o, asp_c, fric, nlp;         /* 132, 136, 140, 144 */
    int32_t sine;                            /* 148 */
    int32_t gv, de, e, pk, last;             /* 152, 156, 160, 164, 168 */
    int32_t jitter, fry, voice, odd;         /* 172, 176, 180, 184 */
    const int16_t *sintab, *glot;            /* 188, 192 */
} ch_blk_t;
typedef char ch_blk_layout_ok[(sizeof(void *) != 4 || __builtin_offsetof(ch_blk_t, glot) == 192) ? 1 : -1];

static void ch_block_c(ch_blk_t *x)
{
    int16_t *R = x->R, *L = x->L, *out = x->out;
    const int16_t g0 = (int16_t)x->g01, g1 = (int16_t)(x->g01 >> 16), g2 = (int16_t)x->g2;
    for (int s = 0; s < CH_SUB; s++) {
        /* ---- glottis ---- */
        uint32_t nph = x->ph + x->step;
        if (nph < x->ph) {                            /* a new period: jitter, shimmer, fry */
            uint32_t rng = x->rng;
            rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
            x->rng = rng;
            int32_t r = (int32_t)(rng >> 20) - 2048;
            x->gfac = 4096 + ((r * x->jitter) >> 11);
            x->odd ^= 1;
            int32_t a = 4096 + ((((int32_t)(rng & 2047)) - 1024) * x->jitter >> 10);
            if (x->odd && x->fry) { a -= (a * x->fry) >> 13; x->gfac -= x->fry >> 2; }
            x->gamp = (a * x->voice) >> 12;
            x->gamp16 = x->gamp > 8191 ? 32767 : (int16_t)(x->gamp << 2);
            x->step = x->base + (uint32_t)((int32_t)(x->base >> 12) * (x->dev + x->gfac - 4096));
        }
        x->ph = nph;
        uint32_t idx = ((uint32_t)(uint16_t)(nph >> 16) * (uint32_t)(uint16_t)x->iq) >> 17;
        int16_t g = x->sine ? (int16_t)(x->sintab[nph >> 19] - (x->sintab[nph >> 19] >> 3))
                            : idx < 256 ? x->glot[idx] : 0;                  /* +-30000 */
        uint32_t rng = x->rng;
        rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
        x->rng = rng;
        int16_t nz = (int16_t)(rng >> 16);                                   /* white, full scale */
        int16_t src = ch_add(ch_mul(g, (int16_t)x->gamp16) >> 4, ch_mul(nz, (int16_t)(idx < 256 ? x->asp_o : x->asp_c)) >> 3);
        /* ---- tract ---- */
        int16_t rp = R[0];
        R[0] = ch_add(ch_mul(L[0], idx < 256 ? CH_RGO : CH_RG), src);       /* an open glottis absorbs more */
        rp = ch_lattice(R + 1, L + 1, x->k + 1, 0, x->n1, rp);
        if (x->nose) {                                /* three-port at the velum: p = sum g_j in_j; out_j = p - in_j */
            int16_t ri = x->Rv[0], li = x->Lv[0], ni = x->nL[0];
            int32_t p = (g0 * rp + g1 * li + g2 * ni) >> 13;                 /* 16 x 16 products */
            x->Rv[0] = ch_s16(p - li); x->Lv[-1] = ch_s16(p - rp);
            int16_t nrp = x->nR[0];
            x->nR[0] = ch_s16(p - ni);
            nrp = ch_lattice(x->nR + 1, x->nL + 1, x->nk + 1, 0, CH_NN - 1, nrp);
            x->nlip = ch_add((int16_t)x->nlip, ch_mul(CH_LIPA, ch_sub(nrp, (int16_t)x->nlip)));
            x->nL[CH_NN - 1] = ch_mul((int16_t)x->nlip, CH_RN);
            rp = ch_lattice(x->Rv + 1, x->Lv + 1, x->kv1, 0, x->n2, ri);
        }
        x->lip = ch_add((int16_t)x->lip, ch_mul(CH_LIPA, ch_sub(rp, (int16_t)x->lip)));
        *x->Ll = ch_mul((int16_t)x->lip, (int16_t)x->rl);
        int16_t f = 0;                                /* frication: high-passed noise at the narrowest place */
        if (x->fr) { x->nlp = (int16_t)((x->nlp + (nz >> 2)) >> 1); f = ch_mul(ch_sub(nz >> 2, (int16_t)x->nlp), (int16_t)x->fric); }
        *x->Rim = ch_add(*x->Rim, f); x->Lim1[0] = ch_sub(x->Lim1[0], f);
        int16_t y0 = x->nose ? ch_add(*x->Rl, x->nR[CH_NN - 1] >> 1) : *x->Rl;  /* the murmur is quieter */
        /* ---- out: gain, envelope, peak, the 2x doubling ---- */
        int32_t v = ((int32_t)y0 * x->gv) >> 12;
        v = (v * (x->e >> 3)) >> 12;
        x->e += x->de;
        v = v > 32767 ? 32767 : v < -32767 ? -32767 : v;
        int32_t av = v < 0 ? -v : v; if (av > x->pk) x->pk = av;
        out[2 * s] = (int16_t)((x->last + v) >> 1);
        out[2 * s + 1] = (int16_t)v;
        x->last = v;
    }
}
#if defined(__bfin__)
void ch_block_asm(ch_blk_t *x);
#endif

static void ch_tract_run_block(ch_tract_t *t, const ch_ctl_t *c, uint32_t base, int16_t *out)
{
    const int n = t->n, v = CH_VEL_OF(n), nose = t->nose_on;
    int16_t *R = t->R, *L = t->L;
    ch_blk_t x;
    x.R = R; x.L = L; x.k = t->k; x.out = out;
    x.n1 = nose ? v - 1 : n - 1;
    x.Rl = &R[n - 1]; x.Ll = &L[n - 1]; x.Rim = &R[t->imin]; x.Lim1 = &L[t->imin - 1];
    x.lip = (int16_t)t->lip; x.rl = t->rl; x.fr = c->fric > 3; x.nose = nose;
    x.Rv = &R[v]; x.Lv = &L[v]; x.nL = t->nL; x.nR = t->nR; x.nk = ch_nose_k; x.kv1 = &t->k[v + 1];
    x.g01 = (uint16_t)t->g3[0] | (int32_t)((uint32_t)(uint16_t)t->g3[1] << 16); x.g2 = t->g3[2]; x.nlip = (int16_t)t->nlip;
    x.n2 = n - 1 - v; x.ri = 0;
    x.ph = t->gph; x.rng = t->rng; x.iq = (1u << 24) / (uint32_t)c->oq; x.base = base; x.dev = c->vib_depth;
    x.gfac = t->gfac; x.gamp = t->gamp; x.gamp16 = t->gamp > 8191 ? 32767 : (int16_t)(t->gamp << 2);
    x.step = base + (uint32_t)((int32_t)(base >> 12) * (x.dev + t->gfac - 4096));
    x.asp_o = (int16_t)(c->asp * 3 < 32767 ? c->asp * 3 : 32767); x.asp_c = (int16_t)c->asp;
    x.fric = (int16_t)((c->fric > 4095 ? 4095 : c->fric) >> 2);   /* Q15: up to 1/32 of the noise */
    x.nlp = (int16_t)t->noise_lp; x.sine = c->sine;
    x.gv = c->gain; x.de = c->de; x.e = c->e0; x.pk = 0; x.last = t->last;
    x.jitter = c->jitter; x.fry = c->fry; x.voice = c->voice; x.odd = t->odd;
    x.sintab = OP1_SINE_TABLE; x.glot = ch_glot;
#if defined(__bfin__) && !defined(CH_SAMPLE_C)
    ch_block_asm(&x);
#else
    ch_block_c(&x);
#endif
    t->gph = x.ph; t->rng = x.rng; t->gfac = x.gfac; t->gamp = x.gamp; t->odd = (uint8_t)x.odd;
    t->lip = (int16_t)x.lip; t->nlip = (int16_t)x.nlip; t->noise_lp = (int16_t)x.nlp; t->last = (int16_t)x.last; t->pk = (int16_t)x.pk;
}

#endif

/* render CH_SUB tract samples and double them to 2 * CH_SUB output samples (int16, before the engine's gain); base =
 * the glottal phase step per tract sample (two of R246's 88.2 kHz increments, or a fixed pitch), read once a block and
 * at each new period (a pitch bend moves within 1.45 ms). Per sample only 16-bit multiplies and shifts. */
static void ch_tract_run(ch_tract_t *t, const ch_ctl_t *c, uint32_t base, int16_t *out)
{
#ifdef CH_PROF_NOTRACT
    (void)c; (void)base; for (int i = 0; i < 128; i++) out[i] = 0; t->pk = 0; return;
#endif
#ifdef CH_BLOCK
    ch_tract_run_block(t, c, base, out); return;
#endif
    const int fr = c->fric > 3;                       /* (fric >> 2) is 0 below 4 */
    if (t->nose_on) { if (c->sine) ch_tract_body(t, c, base, out, 1, 1, fr); else if (fr) ch_tract_body(t, c, base, out, 1, 0, 1); else ch_tract_body(t, c, base, out, 1, 0, 0); }
    else if (c->sine) ch_tract_body1(t, c, base, out, 1, fr);
    else if (fr) ch_tract_body1(t, c, base, out, 0, 1);
    else ch_tract_body1(t, c, base, out, 0, 0);
}

/* move the current areas toward a target (one-pole per block, rate Q8: 256 = jump) */
static inline void ch_glide(ch_tract_t *t, const int16_t *target, int32_t rate)
{
    for (int i = 0; i < t->n; i++) t->la[i] = (int16_t)(t->la[i] + (((int32_t)target[i] - t->la[i]) * rate >> 8));
}

static inline void ch_tract_reset(ch_tract_t *t, int n, const int16_t *la)
{
    volatile uint32_t *p = (volatile uint32_t *)t;      /* volatile: no memset call (no libc) */
    uint32_t keep = t->rng;
    for (unsigned b = 0; b < sizeof *t / 4; b++) p[b] = 0;
    t->n = (uint8_t)n; t->rng = keep ? keep : 0x1234567u;
    t->gfac = 4096; t->gamp = 0;
    for (int i = 0; i < n; i++) t->la[i] = la[i];
}
#endif
