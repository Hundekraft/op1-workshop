/*
 * Gin's factory kits from the packed bank (gin_factory_packed.h, made by pack_factory_bank.py): the same three
 * functions as vendor/src/tonic/presets/gin_factory.c (SquareWave Studio) and the same gin_preset_owned_t bytes, from
 * 12-bit value indices instead of the 38 KB float bank. Built in place of gin_factory.c and gin_factory_bank.c.
 * Copyright (C) 2026 Hundekraft. Logic follows gin_factory.c, Copyright (c) 2026 SquareWave Studio, SDK-derived
 * portions (c) 2026 pcppcp. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "gin_factory.h"
#include "factory_bank/gin_factory_bank.h"
#include "gin_factory_packed.h"

static float value(unsigned kit, unsigned n)
{
    const uint8_t *b = gin_fb_kits[kit].index + (n >> 1) * 3;
    unsigned i = n & 1 ? (unsigned)(b[1] >> 4) | (unsigned)b[2] << 4 : (unsigned)b[0] | (unsigned)(b[1] & 15) << 8;
    union { uint32_t u; float f; } v;
    v.u = gin_fb_values[i];
    return v.f;
}

int gin_factory_load_index(unsigned index, gin_preset_owned_t *out)
{
    unsigned i, j, side, k; unsigned char *zero;
    if (!out || index >= GIN_FACTORY_BANK_COUNT) return -1;
    zero = (unsigned char *)out;
    for (i = 0; i < sizeof(*out); ++i) zero[i] = 0;
    out->count = GIN_PRESET_MAX_SOUNDS;
    for (i = 0; i < GIN_PRESET_NAME_BYTES - 1 && gin_fb_kits[index].name[i]; ++i) out->name[i] = gin_fb_kits[index].name[i];
    for (i = 0; i < GIN_PRESET_MAX_SOUNDS; ++i) {
        const char *name = gin_fb_names[gin_fb_kits[index].sound_name[i]];
        out->sounds[i].id = 1000u + i;
        for (j = 0; j < GIN_PRESET_NAME_BYTES; ++j) out->sounds[i].name[j] = name[j];
        for (side = 0; side < 2; ++side) {
            po32_patch_params_t patch;
            float *p = (float *)&patch;
            for (j = 0; j < 21; ++j) p[j] = value(index, (i * 2 + side) * 21 + j);
            k = 0;
#define COPY_PARAMETER(name) out->sounds[i].endpoint[side][k++] = patch.name;
            TONIC_PARAMETERS(COPY_PARAMETER)
#undef COPY_PARAMETER
        }
    }
    for (i = 0; i < GIN_PRESET_KEY_COUNT; ++i) out->key_map[i] = gin_fb_kits[index].key_map[i];
    return 0;
}

void gin_factory_load(gin_preset_owned_t *out) { (void)gin_factory_load_index(0, out); }

float gin_factory_duration(unsigned index, unsigned sound)
{
    return index < GIN_FACTORY_BANK_COUNT && sound < GIN_PRESET_MAX_SOUNDS
        ? value(index, GIN_FACTORY_SOUND_COUNT * 2 * 21 + sound) : 0.f;
}
