/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#ifndef KN_SEQ_ROWS_H
#define KN_SEQ_ROWS_H
/* Only explicitly owned loadable rows are removable; foreign rows stay untouched.
 * Keep SQL callback helpers out of the large loader translation-unit body: the
 * Observed Blackfin GCC 13.3 inlined output dropped this cleanup tail as
 * unreachable. This boundary avoids that optimizer anomaly; its cause is open. */
static char *kn_sr_cat(char *d,const char *s){while(*s)*d++=*s++;*d=0;return d;}
static int kn_sr_name(const char *s){unsigned n=0;if(!s)return 0;for(;s[n];n++)if(n>=15||!((s[n]>='a'&&s[n]<='z')||(s[n]>='0'&&s[n]<='9')||s[n]=='_'||s[n]=='-'))return 0;return n>0;}
/* has(db, select): 1 when the SELECT returns a row (op1_db_has). Both run their writes only when something would
 * change, so a boot with the same sequencers writes nothing (op1r 46 3f733a8's pattern). */
static __attribute__((noinline)) void kn_seq_row_ensure(void *db,const char *name,void (*exec)(void *,const char *),int (*has)(void *,const char *)){
 if(!kn_sr_name(name))return;
 char sql[256],*o;
 o=kn_sr_cat(sql,"SELECT id FROM seq_types WHERE type='");kn_sr_cat(kn_sr_cat(o,name),"'");
 if(has(db,sql))return;                                 /* there (stock, build row or ours from an earlier boot) */
 exec(db,"CREATE TABLE IF NOT EXISTS kennel_seq_owned (type TEXT PRIMARY KEY)");
 o=kn_sr_cat(sql,"INSERT OR IGNORE INTO kennel_seq_owned SELECT '");o=kn_sr_cat(kn_sr_cat(o,name),"' WHERE NOT EXISTS (SELECT 1 FROM seq_types WHERE type='");kn_sr_cat(kn_sr_cat(o,name),"')");exec(db,sql);
 o=kn_sr_cat(sql,"INSERT INTO seq_types SELECT (SELECT COALESCE(MAX(id),0)+1 FROM seq_types),'");o=kn_sr_cat(kn_sr_cat(o,name),"' WHERE NOT EXISTS (SELECT 1 FROM seq_types WHERE type='");kn_sr_cat(kn_sr_cat(o,name),"')");exec(db,sql);
}
static __attribute__((noinline)) void kn_seq_rows_cleanup(void *db,const char *const *names,unsigned count,void (*exec)(void *,const char *),int (*has)(void *,const char *)){
 char list[48*18+8],sql[1100],*o;exec(db,"CREATE TABLE IF NOT EXISTS kennel_seq_owned (type TEXT PRIMARY KEY)");
 o=kn_sr_cat(list,"('");
 for(unsigned i=0;i<count&&i<48;i++)if(kn_sr_name(names[i]))o=kn_sr_cat(kn_sr_cat(o,names[i]),"','");
 kn_sr_cat(o,"')");
 /* nothing to do unless an owned type is no longer registered or lost its row */
 o=kn_sr_cat(kn_sr_cat(sql,"SELECT type FROM kennel_seq_owned WHERE type NOT IN "),list);
 kn_sr_cat(o," OR type NOT IN (SELECT type FROM seq_types)");
 if(!has(db,sql))return;
 o=kn_sr_cat(kn_sr_cat(sql,"DELETE FROM seq_types WHERE type IN (SELECT type FROM kennel_seq_owned) AND type NOT IN "),list);exec(db,sql);
 /* Remove ownership only after its corresponding row is gone. */
 exec(db,"DELETE FROM kennel_seq_owned WHERE type NOT IN (SELECT type FROM seq_types)");
}
#endif
