/*
 * Clock pages (docs/feature-hooks.md): in clock mode T1..T4 toggle the feature page registered for that key; Shift+Help
 * toggles the clock view (op1_feature_t.view, e.g. Oblique Strategies), which replaces the stock clock as the base
 * view. While a T page is shown its encoder pushes and turns go to it (if it has push / turn; without them they go to
 * the stock clock). The view gets no controls (the stock clock keeps them). When the core shows a page or the view it
 * calls its push(-1) once (Oblique Strategies: a new card). Each page gets its own screen object in the clock slot (0x2A), built at screen
 * construction on the page's svg; dispatcher.c calls kn_pages_ctor / _load / _key / _knob.
 * The COM view (op1_feature_t.com, claim "view:com") works the same way in COM (Shift+COM, mode 11, screen 0x26,
 * docs/firmware/ui.md): Shift+COM again toggles it against the stock COM screen (ours: R246's COM has no further
 * tab), which is always what COM opens with. The view takes Shift+COM only on the stock COM's OP-1 tab with nothing
 * running there, where the stock Shift+COM changes nothing: R246's Shift+COM sets mode 11 again, and the COM
 * controller then (key 0x3F, FUN_01963DBC) leaves CTRL mode and disk mode and goes back to the OP-1 tab. On the CTRL,
 * DISK or OPT tab it stays R246's (the way out of CTRL mode). While it is shown it takes every key press but Shift (the encoder pushes
 * go to its push), mode keys and T1..T4 first bring the stock COM back and then act as usual, and every encoder turn
 * goes to its turn; so the stock COM controller never runs while its slot holds the view.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 */
#include "../op1_feature.h"

#ifdef OP1_HOST                                                 /* harness/com_view_test.c */
extern void *host_screen_table[0x44];
extern uint32_t host_iter_vt[10];
extern int host_mode;
extern uint8_t host_shift;
void *host_screen_ctor(void *obj, int id, const char *svg);
void *host_svg_load(void *doc);
#define SCREEN_TABLE    host_screen_table
#define SCREEN_CTOR     host_screen_ctor
#define ITER_SCREEN_VT  host_iter_vt
#define SVG_LOAD        host_svg_load
#define CUR_MODE_ID     host_mode
#define SHIFT_HELD      host_shift
extern int32_t host_com_page;
extern uint8_t host_com_ctrl, host_com_midi, host_com_disk;
#define COM_PAGE        host_com_page
#define COM_CTRL        host_com_ctrl
#define COM_MIDI        host_com_midi
#define COM_DISK        host_com_disk
#else
#define SCREEN_TABLE    ((void **)0x01DF4E54)
#define SCREEN_CTOR     ((void *(*)(void *, int, const char *))0x01A3BAB0)
#define ITER_SCREEN_VT  ((const uint32_t *)0x019103FC)
#define SVG_LOAD        ((void *(*)(void *))0x01A503D8)
#define CUR_MODE_ID     (*(volatile int *)0xFF907D58)          /* ModeSwitcher: active mode, clock = 0x0C */
#define SHIFT_HELD      (*(volatile uint8_t *)0x01DD7F78)
#define COM_PAGE        (*(volatile int32_t *)0x01AAA784)      /* COM tab: 0 OP-1, 1 CTRL, 2 DISK, 3 OPT */
#define COM_CTRL        (*(volatile uint8_t *)0x01AAA788)      /* CTRL (MIDI controller) mode entered with T2 */
#define COM_MIDI        (*(volatile uint8_t *)0x018B6074)      /* the controller running (speaker off) */
#define COM_DISK        (*(volatile uint8_t *)0xFF906EF9)      /* disk_mode_active */
#endif
#define CLOCK_SCREEN_ID 0x2A
#define COM_SCREEN_ID   0x26
#define COM_MODE        11

extern int kn_feature_count(void);
extern const op1_feature_t *kn_feature_at(int i);
extern void kn_features_key_sync(void);

#define COM_VIEW 5
static const op1_page_t *pages[6];                              /* 0 the clock view (Shift+Help), 1..4 T1..T4, 5 COM */
static uint32_t objs[6][32], vts[6][10];
static uint8_t ready[6];
static const uint8_t slot_id[6] = { CLOCK_SCREEN_ID, CLOCK_SCREEN_ID, CLOCK_SCREEN_ID, CLOCK_SCREEN_ID, CLOCK_SCREEN_ID,
                                    COM_SCREEN_ID };
static int com_shown;
static void *com_screen;                                        /* the stock COM object of slot 0x26 */
static uint64_t com_swallow;                                    /* presses the view took: their releases too */
static int shown;                                               /* 0 base view, 1..4 that T page */
static int view_on = 1;                                         /* base view: 1 the clock view, 0 stock clock (remembered) */
static void *clock_screen;                                      /* the stock clock object of slot 0x2A */

/* kn_features_finish: features in priority order; the first page for a key (and the first view) wins */
void kn_pages_finish(void)
{
    for (int i = 0; i < kn_feature_count(); i++) {
        const op1_feature_t *f = kn_feature_at(i);
        const op1_page_t *p = f->page;
        if (p && p->tkey >= 1 && p->tkey <= 4 && p->screen && p->svg && !pages[p->tkey]) pages[p->tkey] = p;
        if (f->view && f->view->screen && f->view->svg && !pages[0]) pages[0] = f->view;
        if (f->com && f->com->screen && f->com->svg && !pages[COM_VIEW]) pages[COM_VIEW] = f->com;
    }
}

/* screen construction (screens_ctor_hook): one object per page, the stock clock keeps the slot */
void kn_pages_ctor(void)
{
    for (int i = 0; i < 6; i++) {
        if (!pages[i]) continue;
        void *saved = SCREEN_TABLE[slot_id[i]];
        SCREEN_CTOR(objs[i], slot_id[i], pages[i]->svg);
        SCREEN_TABLE[slot_id[i]] = saved;
        for (int k = 0; k < 10; k++) vts[i][k] = ITER_SCREEN_VT[k];   /* is_visible: id == the object's id */
        vts[i][3 * 2 + 1] = (uint32_t)pages[i]->screen->update;
        vts[i][4 * 2 + 1] = (uint32_t)pages[i]->screen->init;
        objs[i][3] = (uint32_t)vts[i];
    }
}

/* screen load (screens_load_hook, after the stock screens): svg + init */
void kn_pages_load(void)
{
    clock_screen = SCREEN_TABLE[CLOCK_SCREEN_ID];
    com_screen = SCREEN_TABLE[COM_SCREEN_ID];
    for (int i = 0; i < 6; i++) {
        if (!pages[i] || !objs[i][2] || !(i == COM_VIEW ? com_screen : clock_screen)) continue;
        objs[i][0] = (uint32_t)SVG_LOAD((void *)objs[i][2]);
        if (objs[i][0]) { pages[i]->screen->init(objs[i]); ready[i] = 1; }
    }
}

static void *base(void) { return view_on && ready[0] ? (void *)objs[0] : clock_screen; }
static const op1_page_t *active(void)                           /* the T page whose controls are live, or 0 */
{
    return shown && CUR_MODE_ID == 0x0C ? pages[shown] : 0;
}
static void show(int t)                                         /* t 0: base view */
{
    shown = t;
    SCREEN_TABLE[CLOCK_SCREEN_ID] = t ? (void *)objs[t] : base();
    const op1_page_t *p = t ? pages[t] : view_on && ready[0] ? pages[0] : 0;
    if (p && p->push) p->push(-1);
}

static void com_set(int on)                                     /* the COM view or the stock COM in slot 0x26 */
{
    com_shown = on;
    SCREEN_TABLE[COM_SCREEN_ID] = on ? (void *)objs[COM_VIEW] : com_screen;
    if (on && pages[COM_VIEW]->push) pages[COM_VIEW]->push(-1);
}

int kn_pages_com_up(void) { return com_shown && CUR_MODE_ID == COM_MODE; }   /* kn_flash.c: the check is only seen there */

static int com_key(int code, int pressed)                       /* 1 = consumed */
{
    if (!ready[COM_VIEW]) return 0;
    if (com_shown && CUR_MODE_ID != COM_MODE) com_set(0);       /* COM was left: it opens with the stock screen */
    uint64_t bit = (uint64_t)1 << (code & 63);
    if (code == 0x2C && SHIFT_HELD && CUR_MODE_ID == COM_MODE &&   /* Shift+COM in COM: toggle, from the OP-1 tab */
        (com_shown || (COM_PAGE == 0 && !COM_CTRL && !COM_MIDI && !COM_DISK))) {
        if (pressed) { com_set(!com_shown); com_swallow |= bit; }
        else com_swallow &= ~bit;
        return 1;
    }
    if (!pressed) {                                             /* a release: taken only if its press was */
        int mine = (com_swallow & bit) != 0;
        com_swallow &= ~bit;
        return mine;
    }
    if (!com_shown || code == 0x26) return 0;                   /* Shift goes on */
    if (code == 0x38 || code == 0x39 || code == 0x3F) return 0; /* R246's own events (jacks 0x019EFE40, eject 0x019EFE6C) */
    if (code <= 0x09 || code == 0x15 || code == 0x2B || code == 0x2C) {   /* mode keys, T1..T4: stock COM, then on */
        com_set(0);
        return 0;
    }
    com_swallow |= bit;
    if (code >= 0x3B && code <= 0x3E && pages[COM_VIEW]->push) pages[COM_VIEW]->push(code - 0x3B);
    return 1;
}

/* key_event_hook: 1 = consumed */
int kn_pages_key(int code, int pressed)
{
    if (com_key(code, pressed)) return 1;
    if (code >= 0x06 && code <= 0x09 && ready[code - 0x05] && CUR_MODE_ID == 0x0C) {   /* clock + T1..T4 */
        if (pressed) {                                          /* page on, again: base view */
            int t = code - 0x05;
            show(shown == t ? 0 : t);
            kn_features_key_sync();
        }
        return 1;
    }
    if (code >= 0x3B && code <= 0x3E) {                         /* the encoder pushes */
        const op1_page_t *p = active();
        if (p && p->push) { if (pressed) p->push(code - 0x3B); return 1; }
    }
    if (code == 0x00 && ready[0] && SHIFT_HELD) {               /* Shift+Help: clock view / stock clock */
        if (!pressed) return 0;
        if (CUR_MODE_ID == 0x0C) {                              /* in clock mode: toggle (stock would do nothing) */
            view_on ^= 1;
            show(0);
            return 1;
        }
        show(0);                                                /* entering clock mode: the remembered view */
    }
    return 0;
}

/* knob_event_hook: 1 = consumed */
int kn_pages_knob(int knob, int delta)
{
    if (com_shown && CUR_MODE_ID != COM_MODE) com_set(0);
    if (com_shown) {                                            /* every turn to the COM view */
        if (knob >= 0 && knob <= 3 && pages[COM_VIEW]->turn) pages[COM_VIEW]->turn(knob, delta);
        return 1;
    }
    const op1_page_t *p = active();
    if (knob < 0 || knob > 3 || !p || !p->turn) return 0;
    p->turn(knob, delta);
    return 1;
}
