/*
 * R246 resets only documents reachable in the table passed to screens_update. Kennel shares slots between
 * engines, effects and feature pages, so a displaced document's drawing buffers otherwise escape that reset.
 *
 * Keep the exact table drawn by the Gfx thread stable for the whole frame. At the next frame boundary, reset
 * documents removed from that table, before allocating the next screen's drawing buffers. Merely comparing
 * live table pointers once per frame is insufficient: KeyHandler can replace them again during drawing.
 * A fixed frame snapshot means intermediate requests never draw, so no retirement queue/registry can overflow.
 * Parsed documents/screen objects remain alive until reboot; reset frees drawing caches, not the SVG tree.
 *
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (LICENSE, NOTICE).
 */
#pragma GCC optimize("no-tree-loop-distribute-patterns")
#include <stdint.h>
#include "kn_screens.h"

static void *frame[KN_SCREEN_SLOTS];
static void *previous_docs[KN_SCREEN_SLOTS];

#ifdef OP1_HOST
void host_screens_update(void *table);
void host_screen_document_reset(void *doc);
#define SCREENS_UPDATE host_screens_update
#define reset_document host_screen_document_reset
#else
#define SCREENS_UPDATE ((void (*)(void *))0x01A3BB20)
static void reset_document(void *doc)
{
    uint8_t *vt = *(uint8_t **)((uint8_t *)doc + 0x54);
    void (*reset)(void *) = *(void (**)(void *))(vt + 0x7C);
    reset((uint8_t *)doc + *(int16_t *)(vt + 0x78));
}
#endif

static void *document(void *screen) { return screen ? *(void **)screen : 0; }

void kn_screens_frame(void *requested)
{
    void *volatile *live = requested;
    /* Only Gfx draws. Each aligned pointer load is atomic; requests may change during this copy, but every
     * captured object is fully constructed and remains alive. No IRQ masking across copies or SVG resets. */
    for (int i = 0; i < KN_SCREEN_SLOTS; i++) frame[i] = live[i];
    for (int i = 0; i < KN_SCREEN_SLOTS; i++) {
        void *old = previous_docs[i];
        if (!old || old == document(frame[i])) continue;
        int present = 0;
        for (int j = 0; j < KN_SCREEN_SLOTS; j++)
            if (document(frame[j]) == old) { present = 1; break; }
        if (present) continue;                                 /* aliases/moves retain their cache */
        int duplicate = 0;
        for (int j = 0; j < i; j++)
            if (previous_docs[j] == old) { duplicate = 1; break; }
        if (!duplicate) reset_document(old);                   /* Gfx boundary, never in an input/audio handler */
    }
    for (int i = 0; i < KN_SCREEN_SLOTS; i++) previous_docs[i] = document(frame[i]);
#ifndef OP1_HOST
    extern volatile uint32_t kn_te_ext;
    extern void kn_te_heap_extend(void);
    if (!kn_te_ext) kn_te_heap_extend();                       /* the fixed range as TE heap, once (kn_boot.c) */
#endif
    SCREENS_UPDATE(frame);                                     /* stock ID/heap-pressure resets and overlays intact */
}
