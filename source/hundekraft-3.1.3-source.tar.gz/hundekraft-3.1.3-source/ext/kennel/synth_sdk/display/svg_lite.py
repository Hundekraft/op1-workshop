#!/usr/bin/env python3
"""Lighter R246 screen SVGs: same-colour fills bridged into one contour (docs/screen-art.md, "Lighter screens").

Every parsed screen stays in R246's TE drawing heap while the firmware runs. Measured on the emulator (OP1-Emulator
run/svg-lite-2026-11-01): about 200 bytes per element and 30 per vertex, so a screen of many small shapes pays mostly
for the shapes. This tool joins filled shapes of one colour into one <path>; generators call `lighten()` on their
output, and it runs on a finished SVG from the command line:

    python3 synth_sdk/display/svg_lite.py IN.svg OUT.svg [--tol 0.15] [--report]

- Fills (one closed M/L contour, no stroke, no id, no transform/style/opacity) of one colour become one contour:
  each ring is walked from a start vertex back to it, the starts are joined by steps, and the path walks the steps
  back at the end, so the steps enclose nothing. R246's fill walker (0x01A25240) treats every later M as an L, so a
  filled path never gets a second M. A walked-back step still leaves a faint trace natively (one or two LSBs along
  it, whatever the coordinates: two decimals, the 1/40 or 1/16 grid, steps along the axes or off the screen; C64arp,
  2026-11-01), so steps run along the axes (one corner) and `step` (units, lighten()) limits how far apart two ring
  starts may be. At most FILL_VERTICES_MAX vertices a path: 268 drew natively (Warble), a 1,446-vertex path hung
  R246's GUI thread on entering the screen (C64arp). Rings that overlap each other (more than a shared edge) stay
  apart.
- --tol: fill contours lose points within tol screen units of their neighbours' chord (Douglas-Peucker; 0 keeps
  every point). A contour whose simplified points would turn back keeps its points.
- A fill joins an earlier group only when nothing drawn between them touches it (footprints rasterized at 4 cells a
  unit, grown by half the stroke width plus 1 unit for antialiasing) or that thing draws in the same single colour.
  Anything with an id, a group, a transform or a shape the tool doesn't read is a barrier: nothing moves past it, so
  animated, hidden or recoloured nodes and the static-art cache boundary keep their place.
Strokes are left as they are. R246 draws a stroked path's later M as an L too: strokes merged into one path drew
connector lines and spikes across Stutter, Hail, Mbira and the rest (native 2026-11-01), and Pew's hung. Strokes
rewritten as filled outlines cost more than they save (three times the vertices). Kept everywhere: coordinate strings
of kept points, colours, ids, groups and the draw order of everything that touches. The output passes svg_check's
rules (4 decimals, turn-backs, one M per filled path) or lighten() raises.
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import argparse
import json
import math
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'harness'))
import svg_check   # noqa: E402

NS = 'http://www.w3.org/2000/svg'
ET.register_namespace('', NS)
NUMBER = r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)'
RES = 4                     # footprint raster: cells per screen unit
AA = 1.0                    # footprint margin for antialiasing, screen units
STEP_MAX = 1e9             # longest step between ring starts (units); set by lighten
FILL_VERTICES_MAX = 256     # vertices in one bridged fill (268 drew natively, 1,446 hung R246's GUI)


def tag(el):
    return el.tag.rsplit('}', 1)[-1] if isinstance(el.tag, str) else 'comment'


def parse(text):
    return ET.fromstring(text, ET.XMLParser(target=ET.TreeBuilder(insert_comments=True)))


def pts_of(strings):
    return [(float(x), float(y)) for x, y in strings]


def parse_ml(d):
    """-> [(points as (x, y) strings, closed)] for an absolute M/L/Z path, else None"""
    if re.sub(r'[MLZ\s,]|' + NUMBER, '', d):
        return None
    out = []
    for cmd, args in re.findall(r'([MLZ])([^MLZ]*)', d):
        n = re.findall(NUMBER, args)
        if len(n) % 2:
            return None
        pairs = list(zip(n[0::2], n[1::2]))
        if cmd == 'M':
            if not pairs:
                return None
            out.append([pairs, False])
        elif cmd == 'L':
            if not out:
                return None
            out[-1][0] += pairs
        elif not out or pairs:
            return None
        else:
            out[-1][1] = True
    return [(p, c) for p, c in out]


def dp(points, tol):
    """Douglas-Peucker on string pairs: keep the ends, drop points within tol of the chord."""
    if tol <= 0 or len(points) < 3:
        return points
    xy = pts_of(points)
    keep = [False] * len(points)
    keep[0] = keep[-1] = True
    stack = [(0, len(points) - 1)]
    while stack:
        a, b = stack.pop()
        (ax, ay), (bx, by) = xy[a], xy[b]
        dx, dy = bx - ax, by - ay
        length = math.hypot(dx, dy)
        best, bi = -1.0, None
        for i in range(a + 1, b):
            px, py = xy[i]
            dist = abs(dx * (ay - py) - dy * (ax - px)) / length if length > 1e-12 else math.hypot(px - ax, py - ay)
            if dist > best:
                best, bi = dist, i
        if bi is not None and best > tol:
            keep[bi] = True
            stack += [(a, bi), (bi, b)]
    return [p for p, k in zip(points, keep) if k]


def dp_ring(points, tol):
    """DP on a closed ring (no repeated end point), split at the vertex farthest from the first."""
    if tol <= 0 or len(points) < 5:
        return points
    xy = pts_of(points)
    j = max(range(len(xy)), key=lambda i: (xy[i][0] - xy[0][0]) ** 2 + (xy[i][1] - xy[0][1]) ** 2)
    out = dp(points[:j + 1], tol) + dp(points[j:] + points[:1], tol)[1:-1]
    return out if len(out) >= 3 else points


def turns(points, closed=False):
    xy = pts_of(points)
    return svg_check.turn_backs(xy + xy[:2] if closed else xy) is not None


class Shape:
    """One child: kind 'fill' (mergeable) or 'other'; mask None = barrier."""
    def __init__(self, el, kind, colour=None, ring=None):
        self.el, self.kind, self.colour, self.ring = el, kind, colour, ring
        self.mask = None      # (x0, y0, bool array): footprint in RES cells, grown for antialiasing
        self.core = None      # fills: footprint shrunk by one cell (overlap between rings)


def footprint(runs, closed, width, grow):
    xy = [pts_of(r) for r in runs]
    allx = [p[0] for r in xy for p in r]
    ally = [p[1] for r in xy for p in r]
    m = width / 2 + grow + 1.0 / RES
    x0, y0 = math.floor((min(allx) - m) * RES) - 1, math.floor((min(ally) - m) * RES) - 1
    x1, y1 = math.ceil((max(allx) + m) * RES) + 1, math.ceil((max(ally) + m) * RES) + 1
    img = Image.new('1', (max(1, x1 - x0), max(1, y1 - y0)), 0)
    d = ImageDraw.Draw(img)
    rad = (width / 2 + grow) * RES
    for r in xy:
        q = [(x * RES - x0, y * RES - y0) for x, y in r]
        if closed and len(q) >= 3:
            d.polygon(q, fill=1)
        if rad > 0:
            for a, b in zip(q, q[1:] + (q[:1] if closed else [])):
                d.line([a, b], fill=1, width=max(1, int(round(2 * rad))))
            for x, y in q:
                d.ellipse([x - rad, y - rad, x + rad, y + rad], fill=1)
    return (x0, y0, np.asarray(img, bool))


def overlap(a, b):
    ax, ay, am = a
    bx, by, bm = b
    x0, y0 = max(ax, bx), max(ay, by)
    x1, y1 = min(ax + am.shape[1], bx + bm.shape[1]), min(ay + am.shape[0], by + bm.shape[0])
    if x0 >= x1 or y0 >= y1:
        return False
    return bool(np.any(am[y0 - ay:y1 - ay, x0 - ax:x1 - ax] & bm[y0 - by:y1 - by, x0 - bx:x1 - bx]))


def classify(el, tol):
    t = tag(el)
    if t == 'comment':                                   # draws nothing: everything may pass it
        s = Shape(el, 'other')
        s.mask = (0, 0, np.zeros((1, 1), bool))
        return s
    if el.get('id') is not None or el.get('transform') or el.get('style') or el.get('opacity') or t not in (
            'line', 'polyline', 'path', 'circle'):
        return Shape(el, 'other')
    stroke = el.get('stroke')
    stroked = bool(stroke) and stroke != 'none'
    width = float(el.get('stroke-width', '1')) if stroked else 0.0
    if t == 'circle':
        cx, cy, r = (float(el.get(k, '0')) for k in ('cx', 'cy', 'r'))
        s = Shape(el, 'other')
        s.mask = footprint([[(str(cx - r), str(cy - r)), (str(cx + r), str(cy - r)), (str(cx + r), str(cy + r)),
                             (str(cx - r), str(cy + r))]], True, width, AA)
        return s
    if t == 'line':
        runs, fill = [([(el.get('x1'), el.get('y1')), (el.get('x2'), el.get('y2'))], False)], 'none'
    elif t == 'polyline':
        n = re.findall(NUMBER, el.get('points', ''))
        runs, fill = [(list(zip(n[0::2], n[1::2])), False)], el.get('fill', 'black')
    else:
        runs, fill = parse_ml(el.get('d', '')), el.get('fill', 'black')
        if runs is None:
            return Shape(el, 'other')
    if any(len(r) < 2 for r, _ in runs):
        return Shape(el, 'other')
    filled = fill != 'none'
    if filled and not stroked and len(runs) == 1 and t == 'path':
        r = list(runs[0][0])
        if r[0] == r[-1]:
            r = r[:-1]
        if len(r) >= 3:
            q = dp_ring(r, tol)
            if q != r and turns(q, True):
                q = r
            s = Shape(el, 'fill', fill, q)
            s.original, s.simple = r, q
            s.mask = footprint([q], True, 0.0, AA)
            ox, oy, m = footprint([q], True, 0.0, 0.0)
            core = np.zeros_like(m)
            core[1:-1, 1:-1] = m[1:-1, 1:-1] & m[:-2, 1:-1] & m[2:, 1:-1] & m[1:-1, :-2] & m[1:-1, 2:]
            s.core = (ox, oy, core)
            return s
    s = Shape(el, 'other')                               # read but not merged: a footprint others may pass
    s.mask = footprint([r for r, _ in runs], any(c for _, c in runs) and filled, width, AA)
    s.colour = stroke if stroked and not filled else (fill if filled and not stroked else None)
    return s


def bridge(rings):
    """One contour through every ring (see the module doc). -> points, or None when no choice of starts and corners
    avoids a turn-back or a repeated point (svg_check's rule, which pack.py applies to every path)."""
    out, starts, corners, prev = [], [], [], None
    for ring in rings:
        xy = pts_of(ring)
        order = range(len(ring)) if prev is None else sorted(
            range(len(ring)), key=lambda i: (ring[i][0] != starts[-1][0] and ring[i][1] != starts[-1][1],
                                             abs(xy[i][0] - prev[0]) + abs(xy[i][1] - prev[1])))
        found = None
        for k in order:
            rot = ring[k:] + ring[:k] + [ring[k]]
            if rot[0] in starts:
                continue
            if not starts:
                found = (rot, None)
                break
            s0, s1 = starts[-1], rot[0]
            if abs(float(s0[0]) - float(s1[0])) + abs(float(s0[1]) - float(s1[1])) > STEP_MAX:
                continue
            options = [[]] if s0[0] == s1[0] or s0[1] == s1[1] else [[(s1[0], s0[1])], [(s0[0], s1[1])]]
            for c in options:
                back = [s1] + c + [s0] + (corners[-1][::-1][:1] if corners and corners[-1] else starts[-2:-1])
                if not turns(out[-2:] + c + rot) and not turns(back) and not turns(rot[-2:] + c[::-1] + [s0]):
                    found = (rot, c)
                    break
            if found:
                break
        if found is None:
            return None
        rot, c = found
        if c is not None:
            out += c
            corners.append(c)
        out += rot
        starts.append(rot[0])
        prev = pts_of([rot[0]])[0]           # next ring: a start in line with this one needs no corner
    for k in range(len(starts) - 1, 0, -1):
        out += corners[k - 1][::-1]
        if k > 1:
            out.append(starts[k - 1])
    if len(starts) == 1:
        out = out[:-1]                                   # one ring: the closing Z returns to its start
    return None if turns(out) or out[0] == out[-1] else out


def passable(g, s):
    """May s move to before the members of group g (so to an earlier group)?"""
    for m in g:
        if m.mask is None:
            return False
        if m.colour is not None and m.colour == s.colour:
            continue
        if overlap(m.mask, s.mask):
            return False
    return True


def tour(rings):
    """Ring order with little sideways travel between starts: a walked-back step across the screen (x) still left
    faint one-LSB lines natively (C64arp, 2026-11-01); steps up and down (y) left none."""
    xy = [pts_of(r) for r in rings]
    left = list(range(1, len(rings)))
    order = [0]
    while left:
        cur = xy[order[-1]]
        nxt = min(left, key=lambda j: min(10 * abs(a[0] - b[0]) + abs(a[1] - b[1]) for a in cur for b in xy[j]))
        left.remove(nxt)
        order.append(nxt)
    return [rings[i] for i in order]


def sideways(points):
    xy = pts_of(points)
    return sum(abs(a[0] - b[0]) for a, b in zip(xy, xy[1:]) if a[1] == b[1])


def fill_path(g):
    ring = g[0].ring
    if len(g) > 1:
        rings = [m.ring for m in g]
        ring = bridge(rings)
        t = bridge(tour(rings))
        if t is not None and sideways(t) < sideways(ring):
            ring = t
    el = ET.Element('{%s}path' % NS, {'fill': g[0].colour})
    el.set('d', 'M' + ' '.join(ring[0]) + ''.join('L' + ' '.join(p) for p in ring[1:]) + 'Z')
    return el


def lighten_children(parent, tol, stats):
    kids = list(parent)
    groups = []                          # each a list of Shapes, drawn at the first member's place
    for s in (classify(el, tol) for el in kids):
        target = None
        if s.kind == 'fill':
            for gi in range(len(groups) - 1, -1, -1):
                g = groups[gi]
                if (g[0].kind == 'fill' and g[0].colour == s.colour
                        and sum(len(m.ring) + 4 for m in g) + len(s.ring) + 4 <= FILL_VERTICES_MAX
                        and not any(overlap(s.core, m.core) for m in g)
                        and bridge([m.ring for m in g + [s]]) is not None):
                    target = gi
                    break
                if not passable(g, s):
                    break
        if target is None:
            groups.append([s])
        else:
            groups[target].append(s)
            stats['merged'] += 1
    for el in kids:
        parent.remove(el)
    for g in groups:
        s = g[0]
        if s.kind == 'fill' and len(g) == 1:
            if s.simple != s.original:
                s.ring = s.simple
                parent.append(fill_path(g))
            else:
                parent.append(s.el)
        else:
            parent.append(fill_path(g) if s.kind == 'fill' else s.el)
    for el in parent:
        if tag(el) == 'g' and el.get('transform') is None:
            lighten_children(el, tol, stats)


def stats_of(root):
    els = [e for e in root.iter() if tag(e) in ('line', 'polyline', 'path', 'circle', 'rect', 'g')]
    verts = 0
    for e in els:
        t = tag(e)
        if t == 'line':
            verts += 2
        elif t == 'polyline':
            verts += len(re.findall(NUMBER, e.get('points', ''))) // 2
        elif t == 'path':
            verts += len(re.findall(NUMBER, e.get('d', ''))) // 2
    shapes = sum(1 for e in els if tag(e) != 'g')
    return {'elements': shapes, 'groups': len(els) - shapes, 'vertices': verts}


def lighten(text, tol=0.0, note=None, step=1e9):
    """-> (lighter SVG text, report). note: a comment put first in the output (how it was made)."""
    global STEP_MAX
    STEP_MAX = step
    root = parse(text)
    before = stats_of(root)
    if note:
        root.insert(0, ET.Comment(' ' + note.replace('--', '-') + ' '))
    stats = {'merged': 0}
    lighten_children(root, tol, stats)
    for node in root.iter():
        if tag(node) != 'comment' and node.text is not None and not node.text.strip():
            node.text = None
        node.tail = None
    out = ET.tostring(root, encoding='unicode').replace(' />', '/>') + '\n'
    data = out.encode()
    problems = (svg_check.turn_backs_in(data) + [m.group().decode() for m in svg_check.LONG.finditer(data)]
                + svg_check.filled_subpaths_in(data))
    if problems:
        raise ValueError('lightened SVG breaks R246 rules: ' + '; '.join(problems[:5]))
    return out, {'before': before, 'after': stats_of(parse(out)), 'tol': tol, **stats}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('src', type=Path)
    ap.add_argument('out', type=Path)
    ap.add_argument('--tol', type=float, default=0.0)
    ap.add_argument('--report', action='store_true')
    a = ap.parse_args(argv)
    out, rep = lighten(a.src.read_text(), a.tol, f'{a.src.name} made lighter by display/svg_lite.py --tol {a.tol:g}')
    a.out.write_text(out)
    if a.report:
        print(json.dumps(rep))


if __name__ == '__main__':
    main()
