/* Mixtur's Blackfin kernels against the C loops on bcore (kern_check.py): mx_pass1 / mx_pass2 (mixtur_dsp.S) and
 * mx_pass1_c / mx_pass2_c (mixtur_dsp.h) on the same blocks, every output sample and the state compared, over
 * random blocks the exact_check regimes do not reach: any phase and pitch (sub-audio to far above the keyboard,
 * steady and moving), any n / c / gain / fade per divider, full-range filter words and states; and recip29 for every
 * divisor it is used with. Prints "KERN ok blocks=N" or the first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdint.h>
#include "mixtur_dsp.h"
#include "mixtur_tables.h"
void t2_write(const char *, int);
uint32_t t2_r246_calls[2];
static char line[120];
static int n;
static unsigned blocks, bad;
static void put(const char *p) { while (*p) line[n++] = *p++; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = (char)('0' + v % 10); while (v /= 10); put(b + i); }
static uint32_t rng = 0x12345678u;
static uint32_t rnd(void) { rng = rng * 1664525u + 1013904223u; return rng ^ (rng >> 15); }
static void fail(const char *what, unsigned a, unsigned b)
{
    if (bad) return;
    bad = 1; put("KERN differ "); put(what); put(" "); num(a); put(" "); num(b); put("\n");
}

static mx_p1_t s1, t1;
static int32_t inc[MX_BLOCK + 1];
static int16_t xa[MX_BLOCK], xb[MX_BLOCK];
static void pass1_case(unsigned scen)
{
    uint32_t c[4], nn[4], gq[4], dg[4], bh[4], R[4];
    int fade = rnd() & 1;
    for (int k = 0; k < 4; k++) {
        uint32_t r = rnd();
        nn[k] = (r & 7) == 0 ? 0 : (r & 7) == 1 ? 1 : (r >> 3) % 25;
        c[k] = nn[k] ? (r >> 9) % nn[k] : 0;
        uint32_t g = (r >> 16) % (scen & 1 ? 256u : 197u), gn = g;
        if (fade) { int32_t d = (int32_t)((r >> 24) & 127) - 64; gn = (uint32_t)((int32_t)g + d); if ((int32_t)gn < 0) gn = 0; if (gn > 255) gn = 255; }
        gq[k] = g << 7; dg[k] = (gn - g) * 16u;
        s1.d[k] = DIV_D[nn[k]]; bh[k] = (c[k] * DIV_D[nn[k]]) >> 17; R[k] = DIV_R[nn[k]];
    }
#define PR(a, k) ((a)[k + 1] << 16 | ((a)[k] & 0xFFFFu))
    s1.c01 = PR(c, 0); s1.c23 = PR(c, 2); s1.n01 = PR(nn, 0); s1.n23 = PR(nn, 2); s1.gq01 = PR(gq, 0); s1.gq23 = PR(gq, 2);
    s1.dg01 = PR(dg, 0); s1.dg23 = PR(dg, 2); s1.bh01 = PR(bh, 0); s1.bh23 = PR(bh, 2); s1.r01 = PR(R, 0); s1.r23 = PR(R, 2);
    s1.fade = (dg[0] | dg[1] | dg[2] | dg[3]) != 0;
    s1.one2 = 0x00010001u;
    s1.p = scen % 5 == 0 ? 0xFFFFFFFFu - (rnd() & 0xFFFFF) : rnd();
    /* pitch: an exponent over 2^10 .. 2^31 (sub-audio .. far above the keyboard), steady, vibrato or a random walk */
    uint32_t e = 10 + rnd() % 21, base = (1u << e) | (rnd() & ((1u << e) - 1));
    int mode = rnd() % 3;
    for (int i = 0; i <= MX_BLOCK; i++) {
        uint32_t v = base;
        if (mode == 1) v = base + (base >> 7) * (uint32_t)(i & 31) - (base >> 3);
        if (mode == 2) v = base ^ (rnd() & ((1u << (e - 3)) - 1));
        inc[i] = (int32_t)v;
    }
    uint32_t inc0 = (uint32_t)inc[0] | 1u; int sh = 0;
    while ((inc0 >> sh) >= 32768u) sh++;
    uint32_t dd = inc0 >> sh;
    s1.rinv = dd > 16384u ? recip29(dd) : dd == 16384u ? 32768u : (1u << 29) / dd;
    s1.nsh = -sh; s1.inc = inc;
    t1 = s1;
    mx_pass1(&s1, xa);
    mx_pass1_c(&t1, xb);
    blocks++;
    for (int i = 0; i < MX_BLOCK; i++) if (xa[i] != xb[i]) { fail("pass1 sample", scen, (unsigned)i); return; }
    if (s1.p != t1.p) fail("pass1 p", scen, s1.p);
    if (s1.c01 != t1.c01 || s1.c23 != t1.c23) fail("pass1 c", scen, s1.c01);
}

static mx_p2_t s2, t2;
static int16_t xin[MX_BLOCK], oa[MX_BLOCK], ob[MX_BLOCK];
static void pass2_case(unsigned scen)
{
    int wild = scen & 1;
    uint32_t f1 = wild ? rnd() & 0xFFFF : F1_COEF[rnd() % 33], f2 = wild ? rnd() & 0xFFFF : F2_COEF[rnd() % 33];
    uint32_t q = wild ? rnd() & 0xFFFF : RES_Q[rnd() % 33], gain = wild ? rnd() & 0xFFFF : rnd() % 32768;
    s2.f = f2 << 16 | f1; s2.qg = gain << 16 | q;
    s2.f2l = MX_F2_LEVEL; s2.cm = MX_KNEE + MX_KNEE_T; s2.kn = MX_KNEE; s2.zero = 0; s2.ka = MX_KNEE_A;
    int32_t m = wild ? 0xFFFFF : 131071;
    s2.lp1 = (int32_t)(rnd() & (uint32_t)m) - m / 2; s2.lp2 = (int32_t)(rnd() & (uint32_t)m) - m / 2;
    s2.bp1 = (int32_t)(rnd() & (uint32_t)m) - m / 2; s2.bp2 = (int32_t)(rnd() & (uint32_t)m) - m / 2;
    t2 = s2;
    for (unsigned b = 0; b < 4 && !bad; b++) {               /* four blocks on: the states carry */
        int amp = (int)(rnd() % 16);
        for (int i = 0; i < MX_BLOCK; i++) xin[i] = (int16_t)((int32_t)(rnd() >> 16) >> (amp > 12 ? 0 : amp & 3));
        if (scen % 7 == 0) for (int i = 0; i < MX_BLOCK; i++) xin[i] = i & 16 ? 25088 : -25088;
        mx_pass2(&s2, xin, oa);
        mx_pass2_c(&t2, xin, ob);
        blocks++;
        for (int i = 0; i < MX_BLOCK; i++) if (oa[i] != ob[i]) { fail("pass2 sample", scen, (unsigned)i); return; }
        if (s2.lp1 != t2.lp1 || s2.lp2 != t2.lp2 || s2.bp1 != t2.bp1 || s2.bp2 != t2.bp2) { fail("pass2 state", scen, b); return; }
    }
}

int main(void)
{
    for (uint32_t d = 16385; d < 32768 && !bad; d++)
        if (recip29(d) != (1u << 29) / d) fail("recip29", d, recip29(d));
    for (unsigned k = 0; k < 6000 && !bad; k++) pass1_case(k);
    for (unsigned k = 0; k < 3000 && !bad; k++) pass2_case(k);
    if (!bad) { put("KERN ok blocks="); num(blocks); put("\n"); }
    t2_write(line, n);
    return 0;
}
