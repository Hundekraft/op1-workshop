blot: a TB-303 style bass synth (kennel synth plugin for the original OP-1). By pcppcp, from op1r 48.

A saw .. square oscillator into a resonant four-pole ladder low-pass, a decaying filter envelope and accent. Notes with
velocity 100 or more are accented: the filter sweeps two octaves further, decays fast and plays louder. Slide is the
OP-1's own portamento (mono / legato play mode). The screen is an acid house smiley in lines.

| knob | page 1 | page 2 (press the encoder) |
|---|---|---|
| blue | cutoff, 30 Hz .. 15 kHz (eyes) | waveform, saw .. square |
| green | resonance (smile) | accent amount |
| white | env mod, 0 .. 5 octaves (mouth) | drive, x1 .. x3 (wiggly outline) |
| red | decay, 40 .. 640 ms (drips) | none |

op1r 48 reaches the second values with Shift + turn (`OP1_PRESS_SHIFT`, `op1_shift_held()`). Kennel has no Shift API, so
they sit on the usual press page of blue / green / white. They are the same words (5, 6, 7) with the same meaning, and
the DSP is op1r's unchanged, so sounds map one to one. Page-2 defaults are word 0 (saw, accent 61 %, drive x1): the
engine reads 0 as "a new sound", and kennel's core does not apply `page2_defaults` to synths.

`blot_dsp.S` is the sample loop on the Blackfin, bit for bit `bl_loop` in blot.c (which host builds use). No presets
upstream. Check: `make -C synth_sdk/harness build/blot_test && synth_sdk/harness/build/blot_test`. Pack:
`python3 tools/kennel/pack.py synth_sdk/plugins/blot -o build/blot.knl`. Loadable without an order number; saved sounds
find it by the name "blot". GPL-3.0-or-later with the OP-1 firmware permission.
