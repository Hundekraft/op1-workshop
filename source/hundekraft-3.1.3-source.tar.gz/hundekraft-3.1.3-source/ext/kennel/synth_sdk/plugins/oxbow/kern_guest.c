/* Oxbow's Blackfin passes (obv_dsp.S) against its C passes on bcore (kern_check.py). Two parts:
 * 1. pass by pass: this file includes oxbow.c (the asm build), so it reaches the C passes (osc_pass, drive_pass,
 *    filter_pass, lp2_pass, amp_up) and runs each against its asm pass on random inputs within the ranges the C keeps
 *    (phases and steps over the whole range, steps below 2^15 and up to 2^31 - 1, pulse widths, reciprocals tracked
 *    as rcp_track leaves them; filter states, inputs and every coefficient svf_coef makes; the amp window and ramps);
 * 2. the engine: oxbow.c built again with OXBOW_C_LOOP (symbols renamed ref_*), both driven with the same calls
 *    (random knob words, velocities, notes struck and released, pitch words steady, gliding, random) and compared
 *    sample by sample.
 * Prints "KERN ok passes=N blocks=M" or the first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "plugins/oxbow/oxbow.c"

extern const op1_engine_t ref_ENGINE_oxbow;
void t2_write(const char *, int);
uint32_t t2_r246_calls[2];
volatile uint8_t op1_eng_page[4];
void *op1_l1_claim_state(int part, void *home, uint32_t state_bytes, uint32_t bytes, int *fresh)
{ (void)part; (void)home; (void)state_bytes; (void)bytes; if (fresh) *fresh = 0; return 0; }
void *op1_l1_claim(int part, const void *owner, uint32_t bytes, int *fresh)
{ (void)part; (void)owner; (void)bytes; if (fresh) *fresh = 0; return 0; }
const int16_t *op1_l1_sine_quarter(void) { return 0; }
static unsigned blocks, passes, bad;
static char line[120];
static int n;
static void put(const char *p) { while (*p) line[n++] = *p++; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = '0' + v % 10; while (v /= 10); put(b + i); }
static uint32_t rng = 12345;
static uint32_t rnd(void) { rng = rng * 1664525u + 1013904223u; return rng ^ (rng >> 15); }
static int32_t rsign(uint32_t lim) { return (int32_t)(rnd() % (2 * lim + 1)) - (int32_t)lim; }
static void *voice(int v) { return (void *)(uintptr_t)(0xFFB00000u + 0x24u * (uint32_t)v); }
#define PITCH ((volatile uint32_t *)0xFF801950)
#define VEL ((volatile int16_t *)0xFF801064)

static void fail(const char *what, unsigned i)
{
    if (bad) return;
    bad = 1;
    put("KERN differ "); put(what); put(" pass="); num(passes); put(" block="); num(blocks); put(" i="); num(i); put("\n");
}

/* ---- 1. pass by pass */
static uint32_t any_inc(void)
{
    switch (rnd() & 7) {
    case 0: return rnd() & 0x7fff;                                   /* below 2^15: no corrections */
    case 1: return 0x7fffffffu - (rnd() & 0xffff);                   /* the cap */
    case 2: return rnd() >> 1;
    default: return rnd() >> (1 + rnd() % 20);
    }
}

static void test_osc(void)
{
    static int32_t ma[OBV_SAMPLES], mb[OBV_SAMPLES];
    for (unsigned it = 0; it < 6000 && !bad; it++, passes++) {
        const int pulse = (int)(rnd() & 1), first = (int)(rnd() & 1), nt = (rnd() & 3) ? NT : 1;
        const int32_t lvl = (int32_t)(rnd() % 90);
        osc_t a, b;
        otick_t tk[NT];
        rcp_t rc = { 0, 0, 0 };
        uint32_t inc = any_inc();
        a.ph = rnd();
        a.prev = rsign(rnd() & 1 ? 98303 : 32768);
        b = a;
        for (int t = 0; t < NT; t++) {
            if (rnd() & 1) inc += (uint32_t)rsign(inc >> 9);             /* drifting (a reciprocal kept within 1/256) */
            if (inc > 0x7fffffffu) inc = 0x7fffffffu;
            if (rnd() % 5 == 0) inc = any_inc();
            if (t == 0 || (rnd() & 3) == 0) rcp_make(&rc, inc); else rcp_track(&rc, inc);
            tk[t].inc = inc; tk[t].sh = rc.sh; tk[t].r = rc.r;
            tk[t].pw = rnd() & 3 ? pw_mod(0x80000000u - (rnd() % 0x40000000u), rsign(1 << 22)) : rnd();
        }
        for (int i = 0; i < OBV_SAMPLES; i++) ma[i] = mb[i] = rsign(1 << 24);
        {
            const int32_t prm[4] = { lvl, first ? 0 : 4, pulse, nt };
            ox_osc(&a, tk, ma, prm);
        }
        if (first) {
            if (nt == NT) osc_pass(&b, tk, pulse ? W_PLS : W_SAW, -65536, lvl, mb, 1, NT);
            else osc_pass(&b, tk, pulse ? W_PLS : W_SAW, -65536, lvl, mb, 1, 1);
        } else {
            if (nt == NT) osc_pass(&b, tk, pulse ? W_PLS : W_SAW, -65536, lvl, mb, 0, NT);
            else osc_pass(&b, tk, pulse ? W_PLS : W_SAW, -65536, lvl, mb, 0, 1);
        }
        for (int i = 0; i < OBV_SAMPLES; i++) if (ma[i] != mb[i]) { fail(pulse ? "osc pulse" : "osc saw", (unsigned)i); break; }
        if (a.ph != b.ph || a.prev != b.prev) fail("osc state", 0);
    }
}

static void test_drive(void)
{
    static int32_t ma[OBV_SAMPLES], mb[OBV_SAMPLES];
    for (unsigned it = 0; it < 3000 && !bad; it++, passes++) {
        const int32_t d = (int32_t)(rnd() % 128);
        G.drive_q12 = rnd() % 3 == 0 ? 0 : d ? 4096 + (d * d * 7 * 4096 / 16129) : 0;
        for (int i = 0; i < OBV_SAMPLES; i++) ma[i] = mb[i] = rnd() & 1 ? rsign(1 << 24) : (int32_t)(rnd() >> (rnd() & 7));
        ox_drive(ma, G.drive_q12, tanh_at);
        drive_pass(mb);
        for (int i = 0; i < OBV_SAMPLES; i++) if (ma[i] != mb[i]) { fail("drive", (unsigned)i); break; }
    }
}

static void test_svf(void)
{
    static int32_t ma[OBV_SAMPLES], mb[OBV_SAMPLES];
    for (unsigned it = 0; it < 6000 && !bad; it++, passes++) {
        const int mode = (int)(rnd() % 3);
        int32_t k = mode == 2 ? 5793 : (int32_t)(rnd() % 8400) - 207;
        svf_state_t fa, fb;
        int32_t cut = (int32_t)(rnd() % (137 << 8));
        for (int t = 0; t < NA; t++) {
            if (rnd() & 1) cut += rsign(400);
            svf_coef(mode == 2 ? &tc2[t] : &tc1[t], cut, k);
        }
        if (mode == 2) { fa.ic1 = rsign(131071); fa.ic2 = rsign(131071); }
        else { fa.ic1 = rnd() & 1 ? rsign(24576) : rsign(63176); fa.ic2 = rsign(131071); }
        fb = fa;
        for (int i = 0; i < OBV_SAMPLES; i++) ma[i] = mb[i] = rsign(rnd() & 1 ? 65535 : 4000);
        ox_svf(ma, &fa, mode == 2 ? tc2 : tc1, tanh_at, mode);
        if (mode == 2) lp2_pass(&fb, mb);
        else if (mode == 1) filter_pass(&fb, mb, F_BP12);
        else filter_pass(&fb, mb, F_LP12);
        for (int i = 0; i < OBV_SAMPLES; i++) if (ma[i] != mb[i]) { fail(mode == 2 ? "svf stage 2" : mode ? "svf bp" : "svf lp", (unsigned)i); break; }
        if (fa.ic1 != fb.ic1 || fa.ic2 != fb.ic2) fail("svf state", 0);
    }
}

static void test_amp(void)
{
    static int32_t m[OBV_SAMPLES];
    static voice_t va, vb;
    int16_t oa[OP1_BLOCK], ob[OP1_BLOCK];
    for (unsigned it = 0; it < 3000 && !bad; it++, passes++) {
        va.up3 = rsign(19836); va.up2 = rsign(19836); va.up1 = rsign(19836);
        vb = va;
        for (int t = 0; t <= NA; t++) tamp[t] = (int32_t)(rnd() % 32767);
        for (int i = 0; i < OBV_SAMPLES; i++) m[i] = rsign(rnd() & 1 ? 140000 : 65000);
        ox_amp(m, oa, &va.up3, tamp);
        amp_up(&vb, m, ob);
        for (int i = 0; i < OP1_BLOCK; i++) if (oa[i] != ob[i]) { fail("amp", (unsigned)i); break; }
        if (va.up3 != vb.up3 || va.up2 != vb.up2 || va.up1 != vb.up1) fail("amp window", 0);
    }
}

/* ---- 2. the engine */
static void render_both(int v, const int16_t *k)
{
    int16_t a[OP1_BLOCK], b[OP1_BLOCK];
    ENGINE_oxbow.render(voice(v), a, k);
    ref_ENGINE_oxbow.render(voice(v), b, k);
    blocks++;
    for (int i = 0; i < OP1_BLOCK; i++) if (a[i] != b[i]) { fail("render", (unsigned)i); break; }
}

static int16_t gknob(void)
{
    uint32_t r = rnd() >> 16;
    switch (r & 7) {
    case 0: return 0;
    case 1: return 32767;
    case 2: return (int16_t)-(int32_t)(r >> 4);
    default: return (int16_t)(r >> 1);
    }
}

static uint32_t pitch_word(unsigned mode, uint32_t base, int i)
{
    switch (mode) {
    case 0: return base;
    case 1: return base + (base >> 10) * (uint32_t)(i & 127);
    case 2: return base - (base >> 9) * (uint32_t)i;
    case 3: return rnd();
    case 4: return 0xFFFFFFFFu - (rnd() >> 8);
    default: return rnd() >> (rnd() & 31);
    }
}

static void scenarios(void)
{
    int16_t k[8] = { 17000, 13653, 19000, 12000, 0x5300, 0, 0, 0 };
    for (unsigned s = 0; s < 200 && !bad; s++) {
        const unsigned mode = s % 6;
        uint32_t base = rnd() >> (2 + (rnd() % 10));
        for (int v = 0; v < 6; v++) VEL[v] = (int16_t)(s % 5 == 4 ? rnd() : (rnd() % 128) << 8);
        for (int j = 0; j < 8; j++) if (j != 4 && (s > 0 || j > 3)) k[j] = gknob();
        if (s % 3 == 0) k[6] = (int16_t)((rnd() % 6) << 9);   /* every filter type */
        for (int v = 0; v < 6; v++) if (rnd() & 1) { ENGINE_oxbow.note_on(voice(v), k); ref_ENGINE_oxbow.note_on(voice(v), k); }
        for (unsigned r = 0; r < 24 && !bad; r++) {
            for (int i = 0; i < OP1_BLOCK; i++) PITCH[i] = pitch_word(mode, base, i);
            if ((rnd() & 3) == 0) { const int j = (int)(rnd() & 7); if (j != 4) k[j] = gknob(); }
            if ((rnd() & 7) == 0) { const int v = (int)(rnd() % 6); ENGINE_oxbow.note_on(voice(v), k); ref_ENGINE_oxbow.note_on(voice(v), k); }
            if ((rnd() & 7) == 0) { const int v = (int)(rnd() % 6); ENGINE_oxbow.note_off(voice(v)); ref_ENGINE_oxbow.note_off(voice(v)); }
            if (s & 8) {
                for (int t = 0; t < 6 && !bad; t++) if (rnd() & 1) render_both((int)(rnd() % 6), k);
            } else
                for (int v = 0; v < 6 && !bad; v++) render_both(v, k);
        }
    }
}

int main(void)
{
    obv_claim();
    test_osc();
    test_drive();
    test_svf();
    test_amp();
    scenarios();
    if (!bad) { put("KERN ok passes="); num(passes); put(" blocks="); num(blocks); put("\n"); }
    t2_write(line, n);
    return 0;
}
