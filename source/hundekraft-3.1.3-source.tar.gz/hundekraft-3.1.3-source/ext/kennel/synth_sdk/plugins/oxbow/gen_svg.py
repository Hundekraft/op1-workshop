#!/usr/bin/env python3
"""Output passes through display/compact_svg.py: equivalent explicit M/L paths,
unchanged coordinate strings, per-shape paint and animation IDs; no simplification.
Writes oxbow.svg and oxbow_geom.h, the Oxbow screen: the owner's highland ox (oxbow-reference.png, ox4-fringe) in
firmware primitives.

    python3 synth_sdk/plugins/oxbow/gen_svg.py [-o FILE]        (needs numpy, scipy, PIL; -o: the SVG only)

Layout (owner 2026-11-01, Oxbow v2): the 3.0.3 raised fit, with the readout strip below. Horizontally the
whole-scene fit, SX = 160/852 (reference x 0..1536 is 288 px, centred: about 16 px of black at each side);
vertically reference y 89..941 maps to y 2..114 (SY = 112/852), so every ink pixel (stroke widths and the moving
parts at their extremes included) stays above the strip (names from y 113, the page-2 line ending at y 142;
oxbow.c ox_controls, docs/screen-art.md). Round details stay circular (SR), animation pivots and the bird travel
use the same axis maps. No extra translation. Do not reintroduce the 80 % shrink (S = 128/852).
Tracing as EVA's gen_svg.py: each pixel takes the colour of the brightest pixel next to it, a colour group's pixels are
thinned to one-pixel centre lines (Zhang-Suen), followed into polylines and simplified (Douglas-Peucker). Then:
thinning spurs at joins are dropped, chains that lie on a circle become exact arcs, free ends are lengthened to the
stroke's real tip and acute corners (beaks, tails, peaks) pushed out to theirs, and each stroke gets the width the
reference has there (distance transform). Fur strands change colour along their length (ochre, cream, plum), so the
fur, face, mountains and grass are thinned as one mask and each centre line is cut into runs of one palette colour.
Stars are filled polygons fitted to the reference (tip and waist lengths in 16 directions); the moon, the birds' eyes,
the bell's ring (with its gap) and rivet, and the nostril's thick end are fitted circles.
Only line, circle, path (M/L/Z), polyline and g; at most two decimals per number.
Moving parts (ids oxbow.c's screen code looks up; their numbers go to oxbow_geom.h):
  hornl, hornr  the blue horns (CUTOFF): stretched out from their roots (HORN_PIVOT), drooping below the default
  birdl, birdr  the red birds (DETUNE): walk along their horn's top edge (BIRD_* path under the feet), riding the horn
  bell          the green bell (RESONANCE): swings about its ring's centre
  breath        the white breath streaks and clouds (ENV AMOUNT, the filter envelope): scale from the nostril
  s0..s5        the six stars, lit per playing voice (a dim copy under each)
  bar0..3       iter's hidden bars (the firmware's own screen code looks them up)
Previews of the moving parts come from the screen code itself: harness/oxbow_check.py (screen).
Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / 'display'))
from compact_svg import compact_svg
from svgart import shape as native_stroke
REF = HERE / 'oxbow-reference.png'
Y_TOP, Y_BOT = 89, 941                       # reference rows on the screen: the whole scene, fur tips included
SX = 160 / (Y_BOT - Y_TOP)                   # the whole-scene width (~288px reference span)
Y0, SY = 2, 112 / (Y_BOT - Y_TOP)            # reference y 89..941 -> y 2..114: the art above the readout strip
SR = min(SX, SY)                            # circles stay round
OX = (320 - 1536 * SX) / 2
BLUE, GREEN, WHITE, RED = '#698EFF', '#00ED95', '#FFFFFF', '#FF3A5D'
LAV, LAV_DIM, GREEN_DIM, BLACK = '#D6CCF3', '#3C384F', '#1D7A5A', '#010101'
# the reference's other colours (k-means centres of its stroke pixels)
FUR = {'ochre_l': '#D6A259', 'ochre': '#CB9347', 'ochre_d': '#B68241', 'brown': '#8C6C51', 'tan': '#D1B898',
       'cream': '#E2D8C9', 'white': '#F3EEE5', 'plum': '#4E3A49', 'plum_l': '#604B56', 'navy': '#615579'}
KEY = {'blue': '#5485F3', 'red': '#F23452', 'green': '#28E9A2', 'lav': '#D6CCF3'}
WIDTH = {'fur': 1.35, 'navy': 1.15, 'white': 1.2, 'blue': 1.3, 'red': 1.15, 'green': 1.25}
# reference px
BREATH_BOX = (1105, 520, 1500, 800)          # white streaks and clouds
BREATH_PIVOT = (1085, 655)                   # the nostril end of the streaks: the clouds grow from here
BELL_PIVOT = (683, 722)                      # the bell's ring
HORN_PIVOT = {'l': (650, 345), 'r': (1012, 365)}   # where each horn goes under the fur
BIRD_D0, BIRD_STEP, BIRD_N = -60, 5, 13       # bird travel along its horn's top edge: -60 .. 0 reference px
MOON_BOX = (90, 240, 200, 345)
RING_BOX = (655, 700, 722, 752)                # the bell's ring (the link below it left out)
RIVET = (682, 728)                           # the dim dot inside the ring
NOSTRIL_BOX = (995, 630, 1025, 660)          # the top of the nostril curl


def sx(x):
    return OX + x * SX


def sy(y):
    return Y0 + (y - Y_TOP) * SY


def f2(v):
    s = f'{v:.2f}'.rstrip('0').rstrip('.')
    return '0' if s == '-0' else s


def pt(x, y):
    return f'{f2(sx(x))},{f2(sy(y))}'


def polyline(pts, color, w):
    """Round after layout and remove reversal joins that R246 turns into spikes."""
    return native_stroke([(sx(x), sy(y)) for x, y in pts], color, w)


def polygon(pts, color, w, center):
    # Keep stars round about their new centres: widening their long rays makes
    # nearly reversed stroke joins that R246 renders as spikes.
    cx, cy = center
    mapped = [(sx(cx)+(x-cx)*SR, sy(cy)+(y-cy)*SR) for x, y in pts]
    return native_stroke(mapped, color, w, closed=True, fill=color)


def circle(cx, cy, r, color, w, fill='none'):
    return (f'<circle cx="{f2(sx(cx))}" cy="{f2(sy(cy))}" r="{f2(r * SR)}" fill="{fill}" stroke="{color}" '
            f'stroke-width="{w}"/>')


# ---- the reference ----

def hexrgb(h):
    return np.array([int(h[i:i + 2], 16) for i in (1, 3, 5)], float)


def load():
    a = np.asarray(Image.open(REF).convert('RGB')).astype(float)
    lum = a.max(2)
    # each pixel's colour = its brightest 3x3 neighbour's (an antialiased edge takes its stroke's colour)
    pad = np.pad(lum, 1, constant_values=-1)
    apad = np.pad(a, ((1, 1), (1, 1), (0, 0)))
    best = np.zeros(lum.shape, int)
    bl = np.full(lum.shape, -2.0)
    k = 0
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            v = pad[1 + dy:1 + dy + lum.shape[0], 1 + dx:1 + dx + lum.shape[1]]
            sel = v > bl
            bl[sel] = v[sel]
            best[sel] = k
            k += 1
    core = np.zeros_like(a)
    k = 0
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            sel = best == k
            core[sel] = apad[1 + dy:1 + dy + lum.shape[0], 1 + dx:1 + dx + lum.shape[1]][sel]
            k += 1
    # lit: brighter than half the brightest pixel within 2 px (keeps a dark gap between two close strands)
    mx = lum.copy()
    for _ in range(2):
        p = np.pad(mx, 1)
        mx = np.max([p[1 + dy:1 + dy + lum.shape[0], 1 + dx:1 + dx + lum.shape[1]]
                     for dy in (-1, 0, 1) for dx in (-1, 0, 1)], axis=0)
    lit = (lum > 34) & (lum >= 0.5 * mx)
    names = list(FUR) + list(KEY)
    cols = np.array([hexrgb(h) for h in list(FUR.values()) + list(KEY.values())])
    d = ((core[..., None, :] - cols[None, None]) ** 2).sum(-1)
    cls = np.argmin(d, -1)
    return a, lit, cls, names


# ---- tracing (as EVA's gen_svg.py) ----

def thin(img):
    """Zhang-Suen thinning, vectorised"""
    img = np.pad(img.astype(np.uint8), 1)
    while True:
        changed = False
        for step in (0, 1):
            p = img
            P2, P3, P4 = p[:-2, 1:-1], p[:-2, 2:], p[1:-1, 2:]
            P5, P6, P7 = p[2:, 2:], p[2:, 1:-1], p[2:, :-2]
            P8, P9 = p[1:-1, :-2], p[:-2, :-2]
            nb = [P2, P3, P4, P5, P6, P7, P8, P9]
            B = sum(n.astype(int) for n in nb)
            A = sum(((nb[i] == 0) & (nb[(i + 1) % 8] == 1)).astype(int) for i in range(8))
            if step == 0:
                c = (P2 * P4 * P6 == 0) & (P4 * P6 * P8 == 0)
            else:
                c = (P2 * P4 * P8 == 0) & (P2 * P6 * P8 == 0)
            rm = (p[1:-1, 1:-1] == 1) & (B >= 2) & (B <= 6) & (A == 1) & c
            if rm.any():
                img[1:-1, 1:-1][rm] = 0
                changed = True
        if not changed:
            return img[1:-1, 1:-1].astype(bool)


NB = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


def chains(sk):
    """skeleton -> list of pixel paths [(x, y)...], split at junctions"""
    pix = set(zip(*np.nonzero(sk)))

    def linked(q, dy, dx):   # m-connectivity: a diagonal step only where no orthogonal pixel already links the two
        if (q[0] + dy, q[1] + dx) not in pix:
            return False
        return not (dy and dx and ((q[0] + dy, q[1]) in pix or (q[0], q[1] + dx) in pix))
    nbrs = {q: [(q[0] + dy, q[1] + dx) for dy, dx in NB if linked(q, dy, dx)] for q in pix}
    nodes = {q for q, n in nbrs.items() if len(n) != 2}
    seen, out = set(), []

    def walk(a, b):
        path = [a, b]
        seen.add(frozenset((a, b)))
        while path[-1] not in nodes:
            nxt = [n for n in nbrs[path[-1]] if n != path[-2] and frozenset((path[-1], n)) not in seen]
            if not nxt:
                break
            seen.add(frozenset((path[-1], nxt[0])))
            path.append(nxt[0])
        return path

    for a in sorted(nodes):
        for b in nbrs[a]:
            if frozenset((a, b)) not in seen:
                out.append(walk(a, b))
    for a in sorted(pix):                 # loops without nodes
        for b in nbrs[a]:
            if frozenset((a, b)) not in seen:
                out.append(walk(a, b))
    return [[(x, y) for y, x in c] for c in out]


def rdp(pts, eps):
    if len(pts) < 3:
        return pts
    (ax, ay), (bx, by) = pts[0], pts[-1]
    dx, dy = bx - ax, by - ay
    n = math.hypot(dx, dy)
    d = [abs(dy * (x - ax) - dx * (y - ay)) / n if n else math.hypot(x - ax, y - ay) for x, y in pts]
    i = int(np.argmax(d))
    if d[i] <= eps:
        return [pts[0], pts[-1]]
    return rdp(pts[:i + 1], eps)[:-1] + rdp(pts[i:], eps)


def length(c):
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(c, c[1:]))


def merge(cs, tol=1.5, cos_min=0.5):
    """join chains whose ends meet in a nearly straight line (the thinning splits lines at every junction)"""
    cs = [list(c) for c in cs if len(c) > 1]
    while True:
        ends = {}
        for i, c in enumerate(cs):
            for e in (0, -1):
                ends.setdefault((round(c[e][0] / 3), round(c[e][1] / 3)), []).append(i)
        best = None
        for i in range(len(cs)):
            cand = set()
            for e in (0, -1):
                kx, ky = round(cs[i][e][0] / 3), round(cs[i][e][1] / 3)
                for ox in (-1, 0, 1):
                    for oy in (-1, 0, 1):
                        cand.update(ends.get((kx + ox, ky + oy), []))
            for j in cand:
                if j <= i:
                    continue
                for ci in (cs[i], cs[i][::-1]):
                    for cj in (cs[j], cs[j][::-1]):
                        if math.hypot(ci[-1][0] - cj[0][0], ci[-1][1] - cj[0][1]) > tol:
                            continue
                        a, b = ci[max(0, len(ci) - 4)], cj[min(len(cj) - 1, 3)]
                        v1 = (ci[-1][0] - a[0], ci[-1][1] - a[1])
                        v2 = (b[0] - cj[0][0], b[1] - cj[0][1])
                        cos = (v1[0] * v2[0] + v1[1] * v2[1]) / ((math.hypot(*v1) or 1) * (math.hypot(*v2) or 1))
                        if cos > cos_min and (best is None or cos > best[0]):
                            best = (cos, i, j, ci + cj[1:])
        if best is None:
            return cs
        _, i, j, c = best
        cs = [x for k, x in enumerate(cs) if k not in (i, j)] + [c]


def smooth(c, n=2):
    """moving average over 2n+1 pixels, ends kept: takes out the pixel staircase of the centre line"""
    if len(c) < 2 * n + 2:
        return [(float(x), float(y)) for x, y in c]
    out = [(float(x), float(y)) for x, y in c[:n]]
    for i in range(n, len(c) - n):
        w = c[i - n:i + n + 1]
        out.append((sum(p[0] for p in w) / len(w), sum(p[1] for p in w) / len(w)))
    return out + [(float(x), float(y)) for x, y in c[len(c) - n:]]


def extend(c, n, ends=(True, True)):
    """lengthen a chain at its free ends by n px along its end directions (thinning eats a little of each tip)"""
    if len(c) < 2 or n <= 0:
        return c
    out = list(c)
    for rev, free in zip((True, False), ends):
        out = out[::-1]
        if not free:
            continue
        a, b = out[-1], out[max(0, len(out) - 5)]
        d = math.hypot(a[0] - b[0], a[1] - b[1]) or 1
        ux, uy = (a[0] - b[0]) / d, (a[1] - b[1]) / d
        if DT is not None:              # to the stroke's tip: the last lit pixel ahead, less the half width
            h = DT[int(round(a[1])), int(round(a[0]))]
            t = 0.0
            while t < 12:
                xi, yi = int(round(a[0] + ux * (t + 0.5))), int(round(a[1] + uy * (t + 0.5)))
                if not (0 <= xi < LIT.shape[1] and 0 <= yi < LIT.shape[0] and LIT[yi, xi]):
                    break
                t += 0.5
            n = max(0.0, t - max(h - 1, 0.5))
        if n > 0:
            out.append((a[0] + ux * n, a[1] + uy * n))
    return out


def arc_snap(c, tol=0.7, r_max=60):
    """a chain that lies on a circle (within tol px RMS, at least 50 degrees of it) -> points on the exact arc"""
    if len(c) < 8:
        return c
    xs, ys = np.array([p[0] for p in c]), np.array([p[1] for p in c])
    A = np.c_[2 * xs, 2 * ys, np.ones(len(xs))]
    cx, cy, k = np.linalg.lstsq(A, xs ** 2 + ys ** 2, rcond=None)[0]
    r2 = k + cx * cx + cy * cy
    if r2 <= 0:
        return c
    r = math.sqrt(r2)
    res = np.sqrt(((np.hypot(xs - cx, ys - cy) - r) ** 2).mean())
    ang = np.unwrap(np.arctan2(ys - cy, xs - cx))
    span = ang[-1] - ang[0]
    if res > tol or r > r_max or abs(span) < math.radians(50) or np.any(np.diff(ang) * np.sign(span) < -0.2):
        return c
    n = max(4, int(abs(span) / math.radians(6)))
    return [(cx + r * math.cos(ang[0] + span * i / n), cy + r * math.sin(ang[0] + span * i / n)) for i in range(n + 1)]


def sharpen(pts, max_deg=80):
    """push acute corners (beaks, tails, peaks) out along their bisector to the stroke's tip, less the half width:
    thinning rounds a sharp corner off by about a stroke width"""
    if LIT is None or len(pts) < 3:
        return pts
    out = list(pts)
    for i in range(1, len(pts) - 1):
        (ax, ay), (vx, vy), (bx, by) = pts[i - 1], pts[i], pts[i + 1]
        u1 = np.array([ax - vx, ay - vy]); u2 = np.array([bx - vx, by - vy])
        n1, n2 = np.hypot(*u1), np.hypot(*u2)
        if not n1 or not n2:
            continue
        cos = float(u1 @ u2) / (n1 * n2)
        if cos < math.cos(math.radians(max_deg)):
            continue
        d = -(u1 / n1 + u2 / n2)
        d /= np.hypot(*d)
        h = DT[int(round(vy)), int(round(vx))]
        t = 0.0
        while t < 14:
            xi, yi = int(round(vx + d[0] * (t + 0.5))), int(round(vy + d[1] * (t + 0.5)))
            if not (0 <= xi < LIT.shape[1] and 0 <= yi < LIT.shape[0] and LIT[yi, xi]):
                break
            t += 0.5
        k = max(0.0, t - max(h - 1, 0.5))
        out[i] = (vx + d[0] * k, vy + d[1] * k)
    return out


def despur(cs, spur):
    """drop short chains with one free end that hang off a junction (thinning spurs at corners and joins)"""
    while True:
        deg = {}
        for c in cs:
            for e in (c[0], c[-1]):
                deg[e] = deg.get(e, 0) + 1
        keep = [c for c in cs if not (len(c) < spur and c[0] != c[-1] and
                                      sorted((deg[c[0]], deg[c[-1]])) [0] == 1 and max(deg[c[0]], deg[c[-1]]) >= 3)]
        if len(keep) == len(cs):
            return cs
        cs = keep


def trace_chains(mask, min_len=6.0, spur=9):
    sk = thin(mask)
    cs = merge([smooth(c) for c in despur(chains(sk), spur)])
    return [arc_snap(c) for c in cs if length(c) >= min_len]


def free_ends(cs, tol=4.0):
    """per chain: (start free, end free): no other chain passes within tol px of that end"""
    pts = [np.array(c) for c in cs]
    out = []
    for i, c in enumerate(cs):
        fl = []
        for e in (c[0], c[-1]):
            free = True
            for j, q in enumerate(pts):
                if j != i and len(q) and (((q - e) ** 2).sum(1) < tol * tol).any():
                    free = False
                    break
            fl.append(free)
        out.append(fl)
    return out


DT = LIT = None


def width(c, scale=1.0):
    """stroke width in screen units: twice the median distance from the centre line to the stroke's edge"""
    d = [DT[int(round(y)), int(round(x))] for x, y in c[2:-2] or c]
    return round(max(0.7, (2 * float(np.median(d)) - 0.6) * SR * scale), 2)


# ---- parts ----

def runs(c, cls, names, win=7, min_run=14):
    """cut a pixel chain into runs of one colour: (colour name, points)"""
    lab = [names[cls[int(round(y)), int(round(x))]] for x, y in c]
    n = len(lab)
    sm = []
    for i in range(n):
        w = lab[max(0, i - win):i + win + 1]
        sm.append(max(sorted(set(w)), key=w.count))   # sorted: ties break the same way every run
    seg = []
    for i, l in enumerate(sm):
        if seg and seg[-1][0] == l:
            seg[-1][1].append(i)
        else:
            seg.append([l, [i]])
    while len(seg) > 1:                      # short runs join their longer neighbour
        k = min(range(len(seg)), key=lambda s: len(seg[s][1]))
        if len(seg[k][1]) >= min_run:
            break
        nb = [j for j in (k - 1, k + 1) if 0 <= j < len(seg)]
        j = max(nb, key=lambda s: len(seg[s][1]))
        seg[j][1] = sorted(seg[j][1] + seg[k][1])
        del seg[k]
        m = []
        for s in seg:
            if m and m[-1][0] == s[0]:
                m[-1][1] += s[1]
            else:
                m.append(s)
        seg = m
    out = []
    for i, (l, idx) in enumerate(seg):
        a, b = idx[0], idx[-1] + (1 if i + 1 < len(seg) else 0)
        out.append((l, c[a:b + 1]))
    return out


def fit_circle(mask):
    ys, xs = np.nonzero(mask)
    A = np.c_[2 * xs, 2 * ys, np.ones(len(xs))]
    bb = xs ** 2 + ys ** 2
    cx, cy, k = np.linalg.lstsq(A, bb, rcond=None)[0]
    return cx, cy, math.sqrt(k + cx * cx + cy * cy)


def blobs(mask):
    """connected components (8-connected) -> list of boolean masks, by x"""
    lab = np.zeros(mask.shape, int)
    n = 0
    for y, x in zip(*np.nonzero(mask)):
        if lab[y, x]:
            continue
        n += 1
        st = [(y, x)]
        lab[y, x] = n
        while st:
            cy, cx = st.pop()
            for dy, dx in NB:
                yy, xx = cy + dy, cx + dx
                if 0 <= yy < mask.shape[0] and 0 <= xx < mask.shape[1] and mask[yy, xx] and not lab[yy, xx]:
                    lab[yy, xx] = n
                    st.append((yy, xx))
    out = [lab == i for i in range(1, n + 1)]
    return sorted(out, key=lambda m: np.nonzero(m)[1].mean())


def star_poly(m, a):
    """a filled star polygon fitted to one star: tip lengths in 8 directions, waists between them (glow left out)"""
    ys, xs = np.nonzero(m)
    lum = a.max(2)
    w = lum[ys, xs] ** 2
    cx, cy = (xs * w).sum() / w.sum(), (ys * w).sum() / w.sum()
    thr = 0.4 * lum[ys, xs].max()
    pts = []
    for k in range(16):
        ang = math.radians(-90 + k * 22.5)
        r = 0.0
        for t in np.arange(0, 60, 0.25):
            x, y = cx + t * math.cos(ang), cy + t * math.sin(ang)
            xi, yi = int(round(x)), int(round(y))
            if not (0 <= yi < m.shape[0] and 0 <= xi < m.shape[1]) or lum[yi, xi] < thr:
                break
            r = t
        pts.append((cx + r * math.cos(ang), cy + r * math.sin(ang)))
    return (cx, cy), pts


def bird_path(blue_chains, side, bird_mask):
    """offsets (reference px) of a point sliding along the horn's top edge under the bird's feet, outward (towards
    the tip) by BIRD_D0 + i BIRD_STEP px of path length"""
    ys, xs = np.nonzero(bird_mask)
    fy = ys.max()
    fx = np.median(xs[ys > fy - 12])                        # the feet: the bird's lowest pixels
    best = None
    for c in blue_chains:
        for i, (x, y) in enumerate(c):
            if y < fy - 2:
                continue
            d = math.hypot(x - fx, y - fy)
            if best is None or d < best[0]:
                best = (d, c, i)
    _, c, i = best
    tip = min(c, key=lambda q: q[0]) if side == 'l' else max(c, key=lambda q: q[0])
    j = c.index(tip)
    step = 1 if j > i else -1                                # outward = towards the tip along the chain
    def at(d):
        k, left = i, abs(d)
        st = step if d >= 0 else -step
        x, y = c[k]
        while left > 0 and 0 <= k + st < len(c):
            nx, ny = c[k + st]
            seg = math.hypot(nx - x, ny - y)
            if seg >= left:
                return x + (nx - x) * left / seg, y + (ny - y) * left / seg
            left -= seg
            k += st
            x, y = nx, ny
        return x, y
    x0, y0 = at(0)
    return (x0, y0), [(at(BIRD_D0 + n * BIRD_STEP)[0] - x0, at(BIRD_D0 + n * BIRD_STEP)[1] - y0) for n in range(BIRD_N)]


STAR_BOX = (470, 120, 1160, 230)
GEN_W = 1.08          # fur, face, mountains, grass: touching strands narrow the measured width (screen brightness matched)


def parts():
    global DT, LIT
    from scipy.ndimage import distance_transform_edt
    a, lit, cls, names = load()
    DT = distance_transform_edt(lit)
    LIT = lit
    H, W = lit.shape
    ys, xs = np.mgrid[0:H, 0:W]
    name = np.array(names)[cls]
    key = {k: lit & (name == k) for k in KEY}
    bx0, by0, bx1, by1 = BREATH_BOX
    in_breath = (xs >= bx0) & (xs <= bx1) & (ys >= by0) & (ys <= by1)
    breath_m = lit & in_breath & np.isin(name, ['white', 'cream', 'tan'])
    sx0, sy0, sx1, sy1 = STAR_BOX
    in_stars = (xs >= sx0) & (xs <= sx1) & (ys >= sy0) & (ys <= sy1)
    star_m = lit & in_stars & ~np.isin(name, ['red', 'blue'])
    mx0, my0, mx1, my1 = MOON_BOX
    in_moon = (xs >= mx0) & (xs <= mx1) & (ys >= my0) & (ys <= my1)
    general = lit & ~np.isin(name, list(KEY)) & ~breath_m & ~star_m & ~in_moon
    P = {}
    # stars and the moon
    mx0, my0, mx1, my1 = MOON_BOX
    moon_m = lit & in_moon
    P['moon'] = fit_circle(thin(moon_m)) + (width(list(zip(*np.nonzero(thin(moon_m))[::-1]))),)
    P['stars'] = [star_poly(m, a) for m in blobs(star_m) if m.sum() > 150]
    assert len(P['stars']) == 6, len(P['stars'])
    # horns, birds, bell, breath
    blue = trace_chains(key['blue'])
    P['horn'] = {s: [c for c in blue if (np.mean([p[0] for p in c]) < 768) == (s == 'l')] for s in 'lr'}
    red = key['red']
    P['bird'] = {}
    for s in 'lr':
        m = red & ((xs < 768) if s == 'l' else (xs >= 768))
        bl = blobs(m)
        eye = min(bl, key=lambda b: b.sum())
        ys_, xs_ = np.nonzero(m & (ys < np.nonzero(eye)[0].mean() + 12))     # the head band: the beak's extreme pixel
        k = np.argmax(xs_) if s == 'l' else np.argmin(xs_)
        P['bird'][s] = {'lines': trace_chains(m & ~eye, 4.0), 'eye': fit_circle(eye),
                        'beak': (xs_[k] + (-3 if s == 'l' else 3), ys_[k]),
                        'path': bird_path(P['horn'][s], s, m)}
    bell = trace_chains(key['green'], 3.0, spur=6)
    # the ring at the top: a fitted circle, drawn over the angles the reference covers (it has a gap), and its rivet
    rx0, ry0, rx1, ry1 = RING_BOX
    rm = key['green'] & (xs >= rx0) & (xs <= rx1) & (ys >= ry0) & (ys <= ry1)
    rcx, rcy, rr = fit_circle(thin(rm))
    ys_, xs_ = np.nonzero(key['green'] & (np.abs(xs - rcx) < 40) & (np.abs(ys - rcy) < 40))
    on = np.abs(np.hypot(xs_ - rcx, ys_ - rcy) - rr) < 3
    deg = np.degrees(np.arctan2(ys_[on] - rcy, xs_[on] - rcx)) % 360
    cover = np.repeat(np.histogram(deg, bins=72, range=(0, 360))[0] >= 4, 5)   # 5-degree bins
    best = (0, 0)                                     # the longest run of uncovered degrees: the gap
    for i in range(360):
        if cover[i] or not cover[(i - 1) % 360]:
            continue
        k = 0
        while k < 360 and not cover[(i + k) % 360]:
            k += 1
        best = max(best, (k, i))
    glen, g0 = best
    a0, a1 = g0 + glen, g0 + 359                      # covered from the gap's end round to its start
    arc = [(rcx + rr * math.cos(math.radians(t)), rcy + rr * math.sin(math.radians(t)))
           for t in np.linspace(a0 - 2, a1 + 2, max(4, int((a1 - a0) / 6)))]
    bell = [c for c in bell if np.mean([abs(math.hypot(x - rcx, y - rcy) - rr) < 5 for x, y in c]) < 0.7]
    P['bell'] = bell
    P['ring'] = (arc, (rcx, rcy, rr))
    dm = (np.hypot(xs - RIVET[0], ys - RIVET[1]) < 8) & (a[..., 1] > 50)
    P['rivet'] = (*fit_circle(dm)[:2], math.sqrt(dm.sum() / math.pi)) if dm.sum() > 6 else None
    # the nostril's teardrop end: a filled dot where the stroke is thickest
    nx0, ny0, nx1, ny1 = NOSTRIL_BOX
    box = DT[ny0:ny1, nx0:nx1]
    yy, xx = np.unravel_index(np.argmax(box), box.shape)
    P['nostril'] = (nx0 + xx, ny0 + yy, box.max())
    P['breath'] = trace_chains(breath_m)
    # everything else: fur, face, mountains, grass, in colour runs
    gen = []
    for c in trace_chains(general):
        gen += [(l, r, c) for l, r in runs(c, cls, names)]
    P['general'] = gen
    return P


# ---- the screen ----

def defaults():
    return json.loads((HERE / 'plugin.json').read_text())['defaults']


def strokes(cs, color, eps=0.9, ext=1.5, scale=1.0, parents=None, tip=None):
    """polylines for traced chains: free ends lengthened, each with its own measured width; tip: a point (a beak's
    end, less half a stroke) that the nearest vertex within 14 px is moved to (thinning rounds the beak off)"""
    fe = free_ends(parents or cs)
    pts = [sharpen(rdp(extend(c, ext, fe[i] if parents is None else (True, True)), eps)) for i, c in enumerate(cs)]
    if tip:
        d, i, j = min((math.hypot(x - tip[0], y - tip[1]), i, j) for i, p in enumerate(pts) for j, (x, y) in enumerate(p))
        if d < 14:
            pts[i][j] = tip
    return [polyline(p, color, width(c, scale)) for p, c in zip(pts, cs)]


def svg():
    P = parts()
    out = ['<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="320px" '
           'height="160px" viewBox="0 0 320 160">']
    gen = P['general']
    whole = []                                # the run's parent chains, for the free-end test
    seen = {}
    for l, r, c in gen:
        seen.setdefault(id(c), c)
    whole = list(seen.values())
    fe = dict(zip(seen, free_ends(whole)))

    def run_line(l, r, c):
        s0, s1 = fe[id(c)]
        ends = (s0 and r[0] == c[0], s1 and r[-1] == c[-1])
        return polyline(sharpen(rdp(extend(r, 1.5, ends), 0.9)), FUR[l], width(r, GEN_W))
    # mountains and grass behind
    out += [run_line(l, r, c) for l, r, c in gen if l == 'navy']
    cx, cy, rr, w = P['moon']
    out.append(circle(cx, cy, rr, LAV, w))
    for i, ((scx, scy), poly) in enumerate(P['stars']):
        out.append(polygon(poly, LAV_DIM, 0.3, (scx, scy)))
    for i, ((scx, scy), poly) in enumerate(P['stars']):
        out.append(f'<g id="s{i}">' + polygon(poly, LAV, 0.3, (scx, scy)) + '</g>')
    for s in 'lr':
        out.append(f'<g id="horn{s}">' + ''.join(strokes(P['horn'][s], BLUE)) + '</g>')
    out += [run_line(l, r, c) for l, r, c in gen if l != 'navy']
    arc, _ = P['ring']
    ring = polyline(arc, GREEN, width(arc))
    rivet = ''
    if P['rivet']:
        vx, vy, vr = P['rivet']
        rivet = circle(vx, vy, vr * 0.8, GREEN_DIM, 0.3, GREEN_DIM)
    out.append('<g id="bell">' + ''.join(strokes(P['bell'], GREEN, 0.6, 1.0)) + ring + rivet + '</g>')
    nx, ny, nr = P['nostril']
    out.append(circle(nx, ny, nr * 0.95, FUR['white'], 0.3, FUR['white']))
    for s in 'lr':
        b = P['bird'][s]
        ex, ey, er = b['eye']
        out.append(f'<g id="bird{s}">' + ''.join(strokes(b['lines'], RED, 0.6, 1.0, tip=b['beak']))
                   + circle(ex, ey, er * 0.75, RED, 0.6, RED) + '</g>')
    out.append('<g id="breath">' + ''.join(strokes(P['breath'], WHITE)) + '</g>')
    out += [f'<line id="bar{i}" x1="{1.5 + 2 * i}" y1="2" x2="{1.5 + 2 * i}" y2="1" stroke="{BLACK}" stroke-width="1"/>'
            for i in range(4)]
    out.append('</svg>')
    return compact_svg('\n'.join(out) + '\n'), P


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('-o', '--output', type=Path)
    a = ap.parse_args()
    out = a.output or HERE / 'oxbow.svg'
    text, P = svg()
    out.write_text(text)
    if a.output is None:
        q = lambda v: round(v * 1024)
        g = ['/* generated by gen_svg.py: oxbow.svg geometry for the screen code, Q10 screen px */']
        for s in 'lr':
            hx, hy = HORN_PIVOT[s]
            g.append(f'#define OX_HORN_{s.upper()}_X {q(sx(hx))}\n#define OX_HORN_{s.upper()}_Y {q(sy(hy))}')
        g.append(f'#define OX_BELL_X {q(sx(P["ring"][1][0]))}\n#define OX_BELL_Y {q(sy(P["ring"][1][1]))}')
        g.append(f'#define OX_BREATH_X {q(sx(BREATH_PIVOT[0]))}\n#define OX_BREATH_Y {q(sy(BREATH_PIVOT[1]))}')
        g.append(f'#define OX_BIRD_N {BIRD_N}            /* bird path points, {BIRD_STEP} reference px apart from {BIRD_D0}; the last is the reference */')
        for s in 'lr':
            (fx, fy), path = P['bird'][s]['path']
            g.append(f'#define OX_FEET_{s.upper()}_X {q(sx(fx))}\n#define OX_FEET_{s.upper()}_Y {q(sy(fy))}')
            pts = ', '.join(f'{{{q(dx * SX)}, {q(dy * SY)}}}' for dx, dy in path)
            g.append(f'static const int32_t OX_BIRD_{s.upper()}[OX_BIRD_N][2] = {{ {pts} }};')
        (HERE / 'oxbow_geom.h').write_text('\n'.join(g) + '\n')
    n = sum(text.count(t) for t in ('<polyline', '<line', '<path', '<circle'))
    print(f'{out}: {out.stat().st_size} bytes, {n} strokes, SX {SX:.5f}, SY {SY:.5f}, OX {OX:.2f}')
