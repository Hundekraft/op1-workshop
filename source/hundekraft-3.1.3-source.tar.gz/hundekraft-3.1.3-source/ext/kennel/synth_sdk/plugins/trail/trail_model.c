/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "trail_model.h"
const uint8_t trail_rates[8]={96,48,32,24,16,12,8,6}; /* 96 ticks/beat */
const uint16_t trail_masks[8]={0xab5,0x5ad,0x6ad,0x6b5,0xad5,0x295,0x4a9,0xfff};
static uint32_t random32(uint32_t *r){*r=*r*1664525u+1013904223u;return *r;}
static void copy(void *out,const void *in,unsigned n){for(unsigned i=0;i<n;i++)((uint8_t *)out)[i]=((const uint8_t *)in)[i];}
void trail_checkpoint(trail_state *s){copy(&s->undo,&s->cfg,sizeof s->cfg);s->undo_valid=1;}
static int bound(int x,int lo,int hi){return x<lo?lo:x>hi?hi:x;}
int trail_degree_count(uint16_t mask){int n=0;for(int i=0;i<12;i++)n+=(mask>>i)&1;return n?n:12;}
static void reshape(trail_state *s){
 uint32_t r=s->cfg.phrase.seed;int d=0,max=s->cfg.range*trail_degree_count(trail_masks[s->cfg.scale])-1;
 for(int i=0;i<32;i++){
  int leap=1+(int)(random32(&r)>>24)*s->cfg.motion/6400;
  d+=(random32(&r)&0x10000)?leap:-leap;d=bound(d,0,max);
  if(!(i&7))d=0;
  s->cfg.phrase.degree[i]=(uint8_t)d;
  s->cfg.phrase.chance[i]=(uint8_t)(((random32(&r)>>16)*100u)>>16);
 }
 s->changed=1;
}
void trail_init(trail_state *s){
 for(unsigned i=0;i<sizeof *s;i++)((uint8_t *)s)[i]=0;
 s->cfg.length=16;s->cfg.rate=3;s->cfg.density=75;s->cfg.motion=35;s->cfg.range=2;s->cfg.gate=65;s->cfg.scale=1;
 s->cfg.phrase.seed=0x74726169u;s->rng=0x6c536565u;s->sounding=-1;
 for(int k=0;k<24;k++)s->notes[k]=-1;
 reshape(s);s->changed=0;
}
void trail_new(trail_state *s){trail_checkpoint(s);s->cfg.phrase.seed=random32(&s->rng);reshape(s);}
void trail_remake(trail_state *s){reshape(s);}
void trail_undo(trail_state *s){if(!s->undo_valid)return;uint8_t frozen=s->cfg.frozen;trail_config t;copy(&t,&s->cfg,sizeof t);copy(&s->cfg,&s->undo,sizeof t);copy(&s->undo,&t,sizeof t);s->cfg.frozen=frozen;s->undo.frozen=frozen;s->changed=1;}
static void release(trail_state *s){if(s->sounding>=0)trail_note_off(s->sounding);s->sounding=-1;s->gate_left=0;}
void trail_release(trail_state *s){release(s);}
void trail_stop(trail_state *s){release(s);s->running=s->latched=s->started=0;s->held=0;s->transpose=0;s->elapsed=0;for(int i=0;i<24;i++)s->notes[i]=-1;}
void trail_restart(trail_state *s){release(s);s->started=0;s->step=0;s->elapsed=0;}
void trail_key(trail_state *s,int key,int note,int down,int shift){
 if((unsigned)key>=24)return;
 if(down){s->notes[key]=(int16_t)note;s->held|=1u<<key;s->key=(uint8_t)key;
  s->transpose=(int16_t)(note-60);s->latched=(uint8_t)(shift!=0);
  if(!s->running){s->running=1;trail_restart(s);}
 }else{
  s->held&=~(1u<<key);s->notes[key]=-1;if(shift)s->latched=1;
  if(!s->held&&!s->latched){trail_stop(s);return;}
  if(s->held&&key==s->key)for(int i=23;i>=0;i--)if(s->held&(1u<<i)){s->key=(uint8_t)i;s->transpose=(int16_t)(s->notes[i]-60);break;}
 }
}
int trail_pitch(const trail_state *s,int step,int root,uint16_t mask){
 int degrees[12],n=0;mask&=0xfff;if(!mask)mask=0xfff;
 for(int i=0;i<12;i++)if(mask&(1u<<i))degrees[n++]=i;
 int d=s->cfg.phrase.degree[step&31]%(n*s->cfg.range),pitch=60+root+s->transpose+(d/n)*12+degrees[d%n];
 /* Fold by octaves rather than clipping several notes onto MIDI 127. */
 if(pitch>127)pitch-=((pitch-116)/12)*12;
 if(pitch<0)pitch+=((-pitch+11)/12)*12;
 return pitch;
}
void trail_tick(trail_state *s,int mode,int root,uint16_t mask){
 if(!s->running)return;
 if(s->gate_left&&!--s->gate_left)release(s);
 if(s->started&&++s->elapsed<trail_rates[s->cfg.rate])return;
 release(s);s->elapsed=0;
 if(s->started){s->step=(uint8_t)((s->step+1)%s->cfg.length);
  if(!s->step&&!s->cfg.frozen&&s->cfg.evolution&&(((random32(&s->rng)>>16)*100u)>>16)<s->cfg.evolution){
   trail_checkpoint(s);int i=(int)((random32(&s->rng)>>24)%s->cfg.length);
   int old=s->cfg.phrase.degree[i];
   int max=s->cfg.range*trail_degree_count(trail_masks[s->cfg.scale])-1;
   int d=old==0?1:old==max?old-1:old+((random32(&s->rng)&0x10000)?1:-1);
   s->cfg.phrase.degree[i]=(uint8_t)bound(d,0,max);s->changed=1;
  }
 }else{s->step=0;s->started=1;}
 if(s->cfg.phrase.chance[s->step]>=s->cfg.density)return;
 s->sounding=(int16_t)trail_note_on(mode,trail_pitch(s,s->step,root,mask),s->key,(!s->step?112:96));
 s->gate_left=(uint16_t)(trail_rates[s->cfg.rate]*s->cfg.gate/100);if(!s->gate_left)s->gate_left=1;
}
/* Settings and phrase only. Playback always starts stopped after loading. */
int trail_serialize(const trail_state *s,int *v,int cap){
 if(cap<TRAIL_WORDS)return 0;
 const trail_config *c=&s->cfg;
 /* The shared text codec accepts only 0..9999: split RNG words into bytes. */
 int head[20]={1,c->length,c->rate,c->density,c->motion,c->evolution,c->root,c->scale,c->range,c->gate,c->follow,c->frozen,(int)(c->phrase.seed>>24),(int)((c->phrase.seed>>16)&255),(int)((c->phrase.seed>>8)&255),(int)(c->phrase.seed&255),(int)(s->rng>>24),(int)((s->rng>>16)&255),(int)((s->rng>>8)&255),(int)(s->rng&255)};
 for(int i=0;i<20;i++)v[i]=head[i];
 /* A concurrent range/scale edit may precede its degree rewrite. Keep the
  * captured row valid even if the saver observes that intermediate phrase. */
 int max=head[8]*trail_degree_count(trail_masks[head[7]])-1;
 for(int i=0;i<32;i++){v[20+i*2]=bound(c->phrase.degree[i],0,max);v[21+i*2]=bound(c->phrase.chance[i],0,99);}return TRAIL_WORDS;
}
int trail_parse(trail_state *s,const int *v,int n){
 if(n!=TRAIL_WORDS||v[0]!=1)return 0;
 for(int i=1;i<n;i++)if(v[i]<0)return 0;
 if((v[1]!=8&&v[1]!=16&&v[1]!=32)||v[2]>7||v[3]>100||v[4]>100||v[5]>100||v[6]>11||v[7]>=TRAIL_SCALES||v[8]<1||v[8]>3||v[9]<5||v[9]>100||v[10]>1||v[11]>1)return 0;
 for(int i=12;i<20;i++)if(v[i]>255)return 0;
 for(int i=0;i<32;i++)if(v[20+2*i]>=v[8]*trail_degree_count(trail_masks[v[7]])||v[21+2*i]>99)return 0;
 trail_stop(s);trail_config *c=&s->cfg;c->length=v[1];c->rate=v[2];c->density=v[3];c->motion=v[4];c->evolution=v[5];c->root=v[6];c->scale=v[7];c->range=v[8];c->gate=v[9];c->follow=v[10];c->frozen=v[11];c->phrase.seed=((uint32_t)v[12]<<24)|((uint32_t)v[13]<<16)|((uint32_t)v[14]<<8)|(uint32_t)v[15];s->rng=((uint32_t)v[16]<<24)|((uint32_t)v[17]<<16)|((uint32_t)v[18]<<8)|(uint32_t)v[19];for(int i=0;i<32;i++){c->phrase.degree[i]=v[20+2*i];c->phrase.chance[i]=v[21+2*i];}s->undo_valid=s->changed=0;return 1;
}
