/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#ifndef TRAIL_MODEL_H
#define TRAIL_MODEL_H
#include <stdint.h>
#define TRAIL_STEPS 32
#define TRAIL_WORDS 84
#define TRAIL_SCALES 8
/* Phrase entries are stable scale degrees and independent rhythmic thresholds. */
typedef struct { uint8_t degree[32], chance[32]; uint32_t seed; } trail_phrase;
typedef struct {
 uint8_t length,rate,density,motion,evolution,root,scale,range,gate,follow,frozen;
 trail_phrase phrase;
} trail_config;
typedef struct {
 trail_config cfg,undo;
 uint8_t undo_valid,running,latched,key,step,changed,started;
 int16_t sounding,transpose;
 uint16_t elapsed,gate_left;
 uint32_t held,rng;
 int16_t notes[24];
} trail_state;
extern const uint16_t trail_masks[TRAIL_SCALES];
extern const uint8_t trail_rates[8];
int trail_degree_count(uint16_t mask);
void trail_init(trail_state *s);
void trail_new(trail_state *s);
void trail_checkpoint(trail_state *s);
void trail_remake(trail_state *s); /* Motion / range reshape the same seed. */
void trail_undo(trail_state *s);
void trail_stop(trail_state *s);
/* Note off for the owned note, play state (running / latched / held keys) kept: a stock voice reset, or leaving
 * the part's mode (R246 ticks only the current mode's player). */
void trail_release(trail_state *s);
void trail_restart(trail_state *s);
void trail_key(trail_state *s,int key,int note,int down,int shift);
void trail_tick(trail_state *s,int mode,int root,uint16_t mask);
int trail_pitch(const trail_state *s,int step,int root,uint16_t mask);
int trail_serialize(const trail_state *s,int *v,int cap);
int trail_parse(trail_state *s,const int *v,int n);
int trail_note_on(int mode,int note,int key,int velocity);
void trail_note_off(int id);
#endif
