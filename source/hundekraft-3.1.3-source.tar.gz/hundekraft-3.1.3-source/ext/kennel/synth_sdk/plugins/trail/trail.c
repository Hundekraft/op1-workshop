/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with OP-1 firmware permission. */
#include "../../op1_feature_seq.h"
#include "../../op1_synth.h"
#include "../../seq/seq_text.h"
#include "trail_model.h"
static trail_state bank[2];
static uint8_t page[2],loaded;
static int accum[2][4];
static sq_store_t store;
#ifdef OP1_HOST /* harness/trail_fc_test.c: R246's bank, Shift and keyboard octaves as host data */
extern int32_t host_bank,host_drum_oct,host_synth_oct;extern uint8_t host_shift;
#define MODE() (host_bank==1)
#define SHIFT() (host_shift)
#define OCTAVE(m) ((m)?host_drum_oct:host_synth_oct)
#else
#define MODE() (*(volatile int *)0x01DE4C40==1)
#define SHIFT() (*(volatile uint8_t *)0x01DD7F78)
/* keyboard octave of the mode's current slot (synth 0x01DFE4E0 / drum 0x01DFE500 per slot) */
#define OCTAVE(m) (((const int *)((m)?0x01DFE500:0x01DFE4E0))[*(volatile int *)((m)?0xFF8016D8:0xFF8016D4)&7])
#endif
static int clamp(int x,int lo,int hi){return x<lo?lo:x>hi?hi:x;}
int trail_note_on(int mode,int note,int key,int vel){return op1_seq_note_on_quantized(mode,note,key,vel);}
void trail_note_off(int id){op1_seq_note_off(id);}
static void dirty(void){sq_store_dirty(&store);}
static int serialize(int m,char *out,int n){int v[TRAIL_WORDS];return sq_join(out,n,v,trail_serialize(&bank[m],v,TRAIL_WORDS));}
static int parse(int m,const char *text,int len){int v[TRAIL_WORDS];int n=sq_split(text,len,v,TRAIL_WORDS);return trail_parse(&bank[m],v,n);}
static char sql[680];
static sq_store_t store={.name="trailseq",.ser=serialize,.parse=parse,.sql=sql,.cap=sizeof sql,.maxlen=520};
static void initialize(void){if(loaded)return;trail_init(&bank[0]);trail_init(&bank[1]);loaded=1;sq_store_load(&store);}
static void turn(int m,int knob,int delta,int shift){
 if((unsigned)m>1||(unsigned)knob>3)return;
 initialize();trail_state *s=&bank[m];trail_config *c=&s->cfg;
 int *a=&accum[m][knob];*a+=delta;int d=*a/1024;*a-=d*1024;if(!d)return;
 if(!shift&&page[m]&&knob<2&&c->follow){int32_t h[4];if(op1_harmony_context(h)){op1_toast("use local to edit");return;}}
 trail_config before;for(unsigned i=0;i<sizeof before;i++)((uint8_t *)&before)[i]=((const uint8_t *)c)[i];
 if(shift){
  if(knob==0){int n=c->length==8?0:c->length==16?1:2;c->length=(uint8_t)(8<<clamp(n+d,0,2));if(s->step>=c->length)trail_restart(s);}
  else if(knob==1)c->follow=d>0;
 }else if(!page[m]){
  if(knob==0){int v=clamp(c->rate+d,0,7);if(v!=c->rate){c->rate=v;trail_restart(s);}}
  if(knob==1)c->density=clamp(c->density+d*5,0,100);
  if(knob==2){int v=clamp(c->motion+d*5,0,100);if(v!=c->motion){c->motion=v;trail_remake(s);}}
  if(knob==3)c->evolution=clamp(c->evolution+d*5,0,100);
 }else{
  if(knob==0)c->root=(uint8_t)((c->root+d%12+12)%12);
  if(knob==1){int v=clamp(c->scale+d,0,TRAIL_SCALES-1);if(v!=c->scale){c->scale=v;trail_remake(s);}}
  if(knob==2){int v=clamp(c->range+d,1,3);if(v!=c->range){c->range=v;trail_remake(s);}}
  if(knob==3)c->gate=clamp(c->gate+d*5,5,100);
 }
 int changed=0;for(unsigned i=0;i<sizeof before;i++)if(((const uint8_t *)&before)[i]!=((const uint8_t *)c)[i])changed=1;
 if(changed){for(unsigned i=0;i<sizeof before;i++)((uint8_t *)&s->undo)[i]=((const uint8_t *)&before)[i];s->undo_valid=1;s->changed=1;}
}
static void press(int m,int knob,int shift){
 (void)shift;if((unsigned)m>1||(unsigned)knob>3)return;
 initialize();trail_state *s=&bank[m];
 if(knob==0)page[m]^=1;
 if(knob==1)trail_new(s);
 if(knob==2){s->cfg.frozen^=1;s->changed=1;}
 if(knob==3){trail_undo(s);trail_restart(s);}
}
static int down(void *self,int key){
 (void)self;if((unsigned)key>=24)return 0;int m=MODE();initialize();
 trail_key(&bank[m],key,key+53+12*OCTAVE(m),1,SHIFT());return 1;
}
static int up(void *self,int key){(void)self;for(int m=0;m<2;m++)if(bank[m].held&(1u<<(key&31)))trail_key(&bank[m],key,0,0,SHIFT());return 1;}
static int nop(void *self){(void)self;return 0;}
/* STOP and disk mode: both parts stop. */
static void halt(void){trail_stop(&bank[0]);trail_stop(&bank[1]);}
/* R246 calls the player's stop and reset on every synth <-> drum switch (traced natively) and on SEQ off. A latched
 * part only goes silent (notes off, latch kept, as oracle's), so it goes on when its mode / SEQ is back; a part
 * played by held keys stops, so no key state outlives a key_up R246 may not deliver (stop: both parts, reset: the
 * current mode's). */
static void quiet(trail_state *s){if(s->latched)trail_release(s);else trail_stop(s);}
static void stop(void *self){(void)self;quiet(&bank[0]);quiet(&bank[1]);}
static void reset(void *self){(void)self;quiet(&bank[MODE()]);}
static void tick(void *self,int counter){
 (void)self;(void)counter;int m=MODE();trail_state *s=&bank[m];int root=s->cfg.root;uint16_t mask=trail_masks[s->cfg.scale];
 if(s->cfg.follow){int32_t h[4];if(op1_harmony_context(h)){root=h[0];mask=(uint16_t)h[1];}}
 trail_tick(s,m,root,mask);
}
/* uintptr_t: 32-bit words on the OP-1, host-sized in harness/trail_fc_test.c */
static const uintptr_t vt[16]={0,0,0,(uintptr_t)nop,0,(uintptr_t)down,0,(uintptr_t)up,0,(uintptr_t)reset,0,(uintptr_t)tick,0,(uintptr_t)nop,0,(uintptr_t)stop};
static struct {const uintptr_t *vt;uint32_t pad[7];} player={vt,{0}};
static void *get_player(void){initialize();return &player;}
static void midi_start(void){for(int m=0;m<2;m++)trail_restart(&bank[m]);}
static int input(const op1_input *in){if(loaded&&in->type==OP1_IN_KEY&&in->pressed&&in->code==0x23)halt();return 0;}
static void event(int id,int32_t arg){
 (void)arg;if(!loaded)return;
 /* Each mode's part keeps its play state across a synth <-> drum switch, like oracle's: R246 resets the voices
  * (NOTES_RESET: owned notes off, as before) and then ticks only the new mode's player, so a latched part pauses and goes on when its mode is
  * back (the player's stop / reset on the switch only silence). The synth slot belongs to the synth part only; disk
  * mode stops both. */
 if(id==OP1_EV_NOTES_RESET){trail_release(&bank[0]);trail_release(&bank[1]);}
 if(id==OP1_EV_MODE)trail_release(&bank[!MODE()]);
 if(id==OP1_EV_SLOT)trail_stop(&bank[0]);
 if(id==OP1_EV_DISK)halt();
 /* Only the main loop notifies the background saver; evolution never calls DB/saver from tick. */
 if(id==OP1_EV_SERVICE){int changed=0;for(int m=0;m<2;m++)if(bank[m].changed){bank[m].changed=0;changed=1;}if(changed)dirty();}
}
static const uint8_t white[4]={232,232,232,255},blue[4]={105,142,255,255},green[4]={0,223,160,255},orange[4]={255,91,55,255},dim[4]={88,100,94,255};
/* Stroke text (4 x 6 grid, 6 units per char, '1' 4): sizes as Peal / Oracle's, stroke width with the size. Layout
 * inside the OLED-safe y 14..138 (docs/screen-art.md): header 14..24, phrase 28..70, labels 76, values 89, pushes 106,
 * Shift line 124..131; values up to 66 px at 1.4 (CHROMATIC a little smaller), and push (PUSH FREEZE at 1.0) fit the 79 px columns. */
#define T_TITLE 1536
#define T_HEAD 1126
#define T_LABEL 1331
#define T_VALUE 1434
#define T_PUSH 1024
#define T_HINT 1126
static void text(void *r,int x,int y,int scale,const char *s,const uint8_t *c){sq_text(r,OP1_Q10(x),OP1_Q10(y),scale,s,scale*3/4,c);}
static int width(const char *s,int scale){int u=0;for(;*s;s++)u+=*s=='1'||*s=='.'?4:6;return u?(u-2)*scale/1024:0;}
static void number(char *out,int value,const char *suffix){char *p=sq_num(out,(uint32_t)value,1);sq_cat(p,suffix);}
static void screen_init(void *scr){(void)scr;}
static void screen_update(void *scr,int dt){
 op1_screen_draw_cached(scr,dt,0);void *r=op1_raster();int m=MODE();trail_state *s=&bank[m];trail_config *c=&s->cfg;
 const uint8_t *colors[4]={blue,green,white,orange};
 const char *roots[12]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
 const char *scales[8]={"MAJOR","MINOR","DORIAN","MIXOLYD","LYDIAN","MAJ PENT","MIN PENT","CHROMATIC"};
 const char *rates[8]={"1/4","1/8","1/8T","1/16","1/16T","1/32","1/32T","1/64"};
 int follow=0;int32_t h[4];if(c->follow)follow=op1_harmony_context(h);
 text(r,12,14,T_TITLE,"TRAIL",white);text(r,64,16,T_HEAD,page[m]?"TUNE":"PLAY",green);
 text(r,98,16,T_HEAD,c->frozen?"FROZEN":s->latched?"LATCH":s->running?"HOLD":"STOP",orange);
 text(r,146,16,T_HEAD,c->follow?(follow?"FOLLOW":"FOLLOW LOCAL"):"LOCAL",white);
 char val[24];number(val,c->length," STEPS");text(r,308-width(val,T_HEAD),16,T_HEAD,val,dim);
 /* The trail is a bounded 8/16/32-point degree path. Rests retain a dim position. */
 int prevx=0,prevy=0;
 for(int i=0;i<c->length;i++){
  int max=c->range*trail_degree_count(trail_masks[c->scale])-1;
  int x=14+i*290/(c->length-1),y=68-(int)c->phrase.degree[i]*38/max;
  if(i)sq_line(r,OP1_Q10(prevx),OP1_Q10(prevy),OP1_Q10(x),OP1_Q10(y),650,dim);
  const uint8_t *col=s->started&&s->step==i?orange:c->phrase.chance[i]<c->density?green:dim;
  sq_dot(r,OP1_Q10(x),OP1_Q10(y),OP1_Q10(s->started&&s->step==i?3:2),col);prevx=x;prevy=y;
 }
 const char *names[4]={"RATE","DENSITY","MOTION","EVOLVE"};
 const char *tune[4]={"ROOT","SCALE","RANGE","GATE"};
 for(int i=0;i<4;i++){
  int x=12+i*79;text(r,x,76,T_LABEL,page[m]?tune[i]:names[i],colors[i]);
  if(!page[m]){if(i==0)sq_cat(val,rates[c->rate]);else number(val,i==1?c->density:i==2?c->motion:c->evolution,"%");}
  else{if(i==0)sq_cat(val,roots[follow?h[0]:c->root]);else if(i==1)sq_cat(val,follow?"GLOBAL":scales[c->scale]);else number(val,i==2?c->range:c->gate,i==2?" OCT":"%");}
  int vs=T_VALUE,w=width(val,vs);if(w>66)vs=vs*66/w; /* CHROMATIC: keep a gap to the next column */
  text(r,x,89,vs,val,white);
  text(r,x,106,T_PUSH,i==0?"PUSH PAGE":i==1?"PUSH NEW":i==2?"PUSH FREEZE":"PUSH UNDO",colors[i]);
 }
 text(r,12,124,T_HINT,"SHIFT: BLUE LENGTH   GREEN LOCAL/FOLLOW",dim);
}
const op1_screen_t SCREEN_trail={screen_init,screen_update};
static const op1_seq_type_t type={.name="trail",.player=get_player,.svg="trail.svg",.screen=&SCREEN_trail,.press=press,.turn=turn,.midi_start=midi_start};
const op1_feature_t FEATURE_trail={.api=OP1_FEATURE_API,.priority=1000,.name="trail",.seq=&type,.input=input,.event=event};
