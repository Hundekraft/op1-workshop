/* Focused production-model tests; build: cc -fsanitize=address,undefined trail_test.c trail_model.c -o trail_test */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "trail_model.h"
#define OP1_HOST
#include "../../op1_synth.h"
#include "../../seq/seq_text.h"
static int active=-1,ons,offs,lowest=128,highest=-1;
int trail_note_on(int m,int n,int k,int v){(void)m;(void)k;assert(v>0);assert(active<0);assert(n>=0&&n<128);active=n;ons++;if(n<lowest)lowest=n;if(n>highest)highest=n;return n;}
void trail_note_off(int n){assert(n==active);active=-1;offs++;}
static void ticks(trail_state *s,int n){while(n--)trail_tick(s,0,s->cfg.root,trail_masks[s->cfg.scale]);}
int main(void){trail_state s,t;trail_init(&s);trail_init(&t);assert(!memcmp(&s.cfg,&t.cfg,sizeof s.cfg));
 int v[TRAIL_WORDS];assert(trail_serialize(&s,v,TRAIL_WORDS)==TRAIL_WORDS);assert(trail_parse(&t,v,TRAIL_WORDS));assert(!memcmp(&s.cfg,&t.cfg,sizeof s.cfg));
 char row[520];int decoded[TRAIL_WORDS];int len=sq_join(row,sizeof row,v,TRAIL_WORDS);assert(sq_split(row,len,decoded,TRAIL_WORDS)==TRAIL_WORDS);assert(trail_parse(&t,decoded,TRAIL_WORDS));assert(!memcmp(&s.cfg,&t.cfg,sizeof s.cfg)&&s.rng==t.rng);
 for(int i=0;i<TRAIL_WORDS;i++){int old=v[i];v[i]=-1;assert(!trail_parse(&t,v,TRAIL_WORDS));v[i]=old;}
 trail_phrase phrase=s.cfg.phrase;trail_key(&s,7,60,1,0);ticks(&s,16000);assert(!memcmp(&phrase,&s.cfg.phrase,sizeof phrase));trail_key(&s,7,60,0,0);assert(!s.running&&active<0);
 s.cfg.evolution=100;trail_key(&s,7,60,1,1);ticks(&s,16*24);phrase=s.cfg.phrase;ticks(&s,16*24);int changed=0;for(int i=0;i<32;i++)changed+=phrase.degree[i]!=s.cfg.phrase.degree[i];assert(changed==1);assert(!memcmp(phrase.chance,s.cfg.phrase.chance,32));
 s.cfg.frozen=1;trail_undo(&s);assert(s.cfg.frozen);trail_undo(&s);assert(s.cfg.frozen);phrase=s.cfg.phrase;ticks(&s,32000);assert(!memcmp(&phrase,&s.cfg.phrase,sizeof phrase));trail_stop(&s);assert(active<0);assert(ons==offs);
 trail_config before=s.cfg;trail_new(&s);assert(memcmp(&before.phrase,&s.cfg.phrase,sizeof phrase));trail_undo(&s);assert(!memcmp(&before,&s.cfg,sizeof before));
 trail_key(&s,7,60,1,0);trail_key(&s,9,62,1,0);trail_key(&s,9,62,0,0);assert(s.transpose==0);trail_key(&s,7,60,0,0);assert(!s.running);
 trail_key(&s,7,60,1,0);trail_key(&s,7,60,0,1);assert(s.running&&s.latched);trail_restart(&s);ticks(&s,1);assert(s.step==0);trail_stop(&s);
 for(int sc=0;sc<8;sc++)for(int root=0;root<12;root++)for(int tr=-100;tr<=100;tr+=10){s.transpose=tr;for(int i=0;i<32;i++){int p=trail_pitch(&s,i,root,trail_masks[sc]);assert(p>=0&&p<128);assert(trail_masks[sc]&(1<<((p-root-tr+1200)%12)));}}
 for(int sc=0;sc<8;sc++){trail_init(&t);t.cfg.scale=sc;t.cfg.motion=100;t.cfg.range=3;trail_remake(&t);trail_serialize(&t,v,TRAIL_WORDS);assert(trail_parse(&s,v,TRAIL_WORDS));for(int i=0;i<32;i++)assert(s.cfg.phrase.degree[i]<3*trail_degree_count(trail_masks[sc]));}
 trail_init(&t);t.cfg.scale=6;t.cfg.range=1;t.cfg.phrase.degree[3]=35;assert(trail_serialize(&t,v,TRAIL_WORDS)==TRAIL_WORDS);assert(trail_parse(&s,v,TRAIL_WORDS)&&s.cfg.phrase.degree[3]==4);
 assert(ons==offs);printf("TRAIL model passed: %d note on/off pairs; deterministic phrase, repeat/freeze, one-step evolution, undo, held/latch, restart, save validation, scale bounds\n",ons);return 0;}
