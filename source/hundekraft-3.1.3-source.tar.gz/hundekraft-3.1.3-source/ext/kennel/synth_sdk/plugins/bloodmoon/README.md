bloodmoon: BLOODMOON, a dark organ with a haunted bell (kennel synth plugin for the original OP-1), by Nola Drift
(published as SammiBabe666, https://github.com/SammiBabe666/Project_Bloodmoon, commit 3cac835).

Blue BLOOD (harmonic richness), green ECLIPSE (bell strike level and ring), white HAUNTING (vibrato depth and pitch
wobble), red MOONRISE (vibrato speed). Eight presets in presets/ (the author's files, unchanged). Pack:
python3 tools/kennel/pack.py synth_sdk/plugins/bloodmoon -o build/bloodmoon.knl. GPL-3.0-or-later with the OP-1
firmware permission. Kennel changes: PROVENANCE.md.

Blackfin: bloodmoon_dsp.S runs the sample loop, bit-exact with the C (exact_check.py --sym), reading only the sine
table's first quadrant. Screen: python3 gen_svg.py writes bloodmoon.svg and bloodmoon_geom.h from bloodmoon-art.svg (the
author's scene); moon.c moves the parts and draws the knob names and values with the OP-1's own font.
