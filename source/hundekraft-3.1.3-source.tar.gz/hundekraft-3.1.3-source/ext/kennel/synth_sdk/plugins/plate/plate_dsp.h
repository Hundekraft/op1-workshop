/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission; project-maintainer-authorized Maiko #250 port. See README.md. */
#ifndef PLATE_DSP_H
#define PLATE_DSP_H
#include <stdint.h>
/* Logical ring length. Any length above the deepest tap (41585) and the widest writer spread (36897) reads the
 * same samples as the original 65536 ring (plate_dsp.c); 41600 lets the ring be stored twice in the scratch. */
#define PLATE_RING 41600u
typedef struct {
 uint32_t head,phase;
 int32_t input,damp[2],feedback[2],pre,dry,wet,peak;
 int16_t ring[2*PLATE_RING]; /* the ring twice: index i and i + PLATE_RING hold the same sample */
} plate_state;
void plate_init(plate_state *s);
void plate_init_fields(plate_state *s);   /* everything but the ring (FX_SPREAD_INIT clears it per block) */
void plate_process(plate_state *s,int16_t *l,int16_t *r,const int32_t q[4]);
int32_t plate_sine(uint32_t phase);
#endif
