/* Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware
 * permission; project-maintainer-authorized Maiko #250 port. See README.md. */
#include "plate_dsp.h"
#include "plate_tables.h"
static int32_t sat(int32_t x){return x>32767?32767:x< -32768?-32768:x;}
static int32_t mul(int32_t a,int32_t b){return (a*b)>>15;}
int32_t plate_sine(uint32_t p){unsigned i=p>>24;int32_t a=plate_sin[i];
 return a+(((plate_sin[i+1]-a)*(int32_t)((p>>8)&65535))>>16);}
void plate_init_fields(plate_state *s){
 s->head=s->phase=0;s->input=s->damp[0]=s->damp[1]=0;
 s->feedback[0]=s->feedback[1]=s->peak=0;s->pre=s->dry=-1;s->wet=0;
}
void plate_init(plate_state *s){
 plate_init_fields(s);
 uint32_t *w=(uint32_t *)(void *)s->ring;  /* init runs in the audio callback: 32-bit stores (ring at +44, 4-aligned) */
 for(unsigned i=0;i<PLATE_RING;i++)w[i]=0;
}
/* CPU (cpu-pass 2026-10-26, same samples as the 65536-sample masked ring it replaces; harness/exact_check.py):
 * the logical ring is PLATE_RING long and stored twice, so a read at head + offset (< 2 * PLATE_RING) needs no
 * index mask: every offset is an immediate from one base pointer. Each sample writes one copy (the input both);
 * the twins of the 64 x 12 samples written in a block are copied after it. No read in the block can see a stale
 * twin: every tap is at least 159 samples behind its writer, except the pre-delay read of the input, whose twin
 * is written at once. Ring length: a read at offset o returns the latest write to its slot; with the line's own
 * writer w <= o that is o - w samples ago (< 8192) and any later writer w2 > o wrote it RING - (w2 - o) ago, older
 * for RING > w2 - w (36897), and never before the own writer's first write, so the samples match. */
#define RN PLATE_RING
static const unsigned writers[12]={8192,8403,8563,9126,9537,10559,17158,19826,25339,26710,32960,36897};
static void twin_copy(int16_t *ring,unsigned from,unsigned n){  /* indices from .. from + n - 1, all < RN or all >= RN */
 int16_t *a=ring+from,*b=from<RN?a+RN:a-RN;
 for(unsigned i=0;i<n;i++)b[i]=a[i];
}
static void twin_run(int16_t *ring,unsigned lo,unsigned n){       /* written indices lo .. lo + n - 1 (< 2 RN) */
 if(lo<RN && lo+n>RN){unsigned k=RN-lo;twin_copy(ring,lo,k);twin_copy(ring,RN,n-k);}
 else twin_copy(ring,lo,n);
}
static inline int32_t ap2(int16_t *B,unsigned wr,unsigned rd,int32_t x,int32_t g){
 int32_t d=B[rd],v=sat(x-mul(d,g));B[wr]=(int16_t)v;return sat(d+mul(v,g));
}
static inline int32_t modap2(int16_t *B,unsigned wr,unsigned off,int32_t frac,int32_t x){
 int32_t d=B[off];d+=((B[off+1]-d)*frac)>>8;
 int32_t v=sat(x+mul(d,22938));B[wr]=(int16_t)v;return sat(d-mul(v,22938));
}
/* one block; st: right channel present (two copies of the loop: no per-sample branch on it) */
static inline __attribute__((always_inline)) void run(plate_state *s,int16_t *l,int16_t *r,const int st,
 int32_t gain,int32_t diff,int32_t damp,int32_t inp,int32_t dr,int32_t we,int32_t dd,int32_t dw,unsigned dl,unsigned rr){
 const unsigned h0=s->head,pr=(unsigned)s->pre,dlo=9537+(dl>>8),rro=25339+(rr>>8);
 const int32_t dlf=(int32_t)(dl&255),rrf=(int32_t)(rr&255);
 int32_t in=s->input,d0=s->damp[0],d1=s->damp[1],fb0=s->feedback[0],fb1=s->feedback[1],pk=0;
 int16_t *ring=s->ring;unsigned h=h0;
 for(unsigned n=0;n<64;n++){
  int16_t *B=ring+h,*C=B+32768;   /* C: taps past 32767 words stay immediates */
  int32_t a=l[n],b=st?r[n]:a,v=(a+b)>>1;B[0]=(int16_t)v;B[RN]=(int16_t)v;
  in+=(((B[pr]-in)>>1)*inp)>>14;
  int32_t x=ap2(B,8192,8402,in,24576);
  x=ap2(B,8403,8562,x,24576);x=ap2(B,8563,9125,x,20480);x=ap2(B,9126,9536,x,20480);
  int32_t y=modap2(B,9537,dlo,dlf,sat(x+mul(fb1,gain)));
  B[10559]=(int16_t)y;d0+=(((B[17157]-d0)>>1)*damp)>>14;
  y=ap2(B,17158,19825,mul(d0,gain),diff);B[19826]=(int16_t)y;
  y=modap2(B,25339,rro,rrf,sat(x+mul(fb0,gain)));
  B[26710]=(int16_t)y;d1+=(((C[32959-32768]-d1)>>1)*damp)>>14;
  y=ap2(C,32960-32768,36896-32768,mul(d1,gain),diff);C[36897-32768]=(int16_t)y;
  fb0=B[25338];fb1=C[41584-32768];
  int32_t wl=B[27104]+B[31117]-C[35795-32768]+C[39855-32768]-B[13508]-B[17435]-B[21406];
  int32_t wr=B[11082]+B[15934]-B[18978]+B[23787]-B[29838]-C[33456-32768]-C[37076-32768];
  wl=sat(((wl>>3)*19661)>>12);wr=sat(((wr>>3)*19661)>>12);
  int32_t p=wl<0?-wl:wl;if(p>pk)pk=p;
  dr+=dd;we+=dw;l[n]=(int16_t)sat((a*(dr>>6)+(st?wl:((wl+wr)>>1))*(we>>6))>>15);
  if(st)r[n]=(int16_t)sat((b*(dr>>6)+wr*(we>>6))>>15);
  h=h?h-1:RN-1;
 }
 s->head=h;s->input=in;s->damp[0]=d0;s->damp[1]=d1;s->feedback[0]=fb0;s->feedback[1]=fb1;s->peak=pk;
 /* the heads of this block: h0 down to h0 - 63, wrapping below 0 to RN - 1 */
 for(unsigned k=0;k<12;k++){
  unsigned w=writers[k];
  if(h0>=63)twin_run(ring,h0-63+w,64);
  else {twin_run(ring,w,h0+1);twin_run(ring,RN-(63-h0)+w,63-h0);}
 }
}
void plate_process(plate_state *s,int16_t *l,int16_t *r,const int32_t q[4]){
 int32_t dec=mul(q[0],27853),gain=dec+1638,diff=dec+6553;
 if(diff<8192)diff=8192;if(diff>16384)diff=16384;
 int32_t damp=32767-mul(32767-q[1],26214),input=32767-(((32767-q[1])*26214)>>16);
 int32_t pre=mul(mul(q[2],q[2]),8191);
 if(s->pre<0)s->pre=pre;else if(pre>s->pre+16)s->pre+=16;else if(pre<s->pre-16)s->pre-=16;else s->pre=pre;
 int32_t dry=q[3]<=16384?32768:(32768-q[3])*2,wet=q[3]<=16384?q[3]*2:32768;
 if(s->dry<0){s->dry=dry;s->wet=wet;}
 int32_t dr=s->dry*64,we=s->wet*64,dd=dry-s->dry,dw=wet-s->wet;
 unsigned dl=(unsigned)(((plate_sine(s->phase)*24)>>7)+254976);
 unsigned rr=(unsigned)(((plate_sine(s->phase+0x40000000u)*24)>>7)+344320);
 if(r)run(s,l,r,1,gain,diff,damp,input,dr,we,dd,dw,dl,rr);else run(s,l,0,0,gain,diff,damp,input,dr,we,dd,dw,dl,rr);
 s->dry=dry;s->wet=wet;s->phase+=0x60ae00u;
}
