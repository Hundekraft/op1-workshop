/* grids as a sequencer-type feature (op1_feature_seq.h): the pattern generator, page and player logic live in
 * grids/ (a port of Mutable Instruments Grids by Emilie Gillet, GPL-3.0-or-later; see NOTICE); this file is the
 * kennel glue: player vtable (ok_player layout), screen, controls and the feature entry. Loadable, opt-in.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "../../op1_feature_seq.h"
#include "../../op1_synth.h"
#include "../../grids/gr_ui.h"

#define GR_MODE()  (*(volatile int *)0x01DE4C40 == 1)
#define SHIFT_HELD (*(volatile uint8_t *)0x01DD7F78)

void gr_tick(int m);
void gr_all_off(int m);
void gr_restart(int m);
void gr_turn(int m, int knob, int delta, int shift);
void gr_press(int m, int knob);
int  gr_key_down(int m, int key);
void gr_key_up(int m, int key);
void gr_load(void);

static int gr_nop(void *self) { (void)self; return 0; }
static int gr_pkey_down(void *self, int key) { (void)self; return gr_key_down(GR_MODE(), key); }
static void gr_pkey_up(void *self, int key) { (void)self; gr_key_up(0, key); gr_key_up(1, key); }
static void gr_reset(void *self) { (void)self; gr_all_off(GR_MODE()); }
static void gr_ptick(void *self, int counter) { (void)self; (void)counter; gr_tick(GR_MODE()); }     /* 1/96 beat */
static void gr_pstop(void *self) { (void)self; gr_all_off(0); gr_all_off(1); }
static const uint32_t gr_vt[16] = {
    0, 0,  0, (uint32_t)gr_nop,  0, (uint32_t)gr_pkey_down,  0, (uint32_t)gr_pkey_up,
    0, (uint32_t)gr_reset,  0, (uint32_t)gr_ptick,  0, (uint32_t)gr_nop,  0, (uint32_t)gr_pstop };
static struct { const uint32_t *vt; uint32_t pad[7]; } gr_player = { gr_vt, { 0 } };
static void *gr_player_get(void) { gr_load(); return &gr_player; }

static void gr_scr_init(void *scr) { (void)scr; }
static void gr_scr_update(void *scr, int dt) { op1_screen_draw(scr, dt); gr_ui_draw(op1_raster(), GR_MODE(), SHIFT_HELD); }
const op1_screen_t SCREEN_grids = { gr_scr_init, gr_scr_update };

static int gr_key_ev(int mode, int code, int pressed, int shift)
{
    (void)mode; (void)pressed; (void)shift;
    return code >= 0x0A && code <= 0x0C;                       /* lift / drop / scissors: nothing */
}
static void gr_press_ev(int mode, int knob, int shift) { (void)shift; gr_press(mode, knob); }
static void gr_midi_start(void) { gr_restart(0); gr_restart(1); }
static const op1_seq_type_t gr_type = {
    .name = "grids", .player = gr_player_get, .svg = "gridsseq.svg", .screen = &SCREEN_grids,
    .key = gr_key_ev, .press = gr_press_ev, .turn = gr_turn, .midi_start = gr_midi_start };
const op1_feature_t FEATURE_grids = { .api = OP1_FEATURE_API, .priority = 1000, .name = "grids", .seq = &gr_type };
