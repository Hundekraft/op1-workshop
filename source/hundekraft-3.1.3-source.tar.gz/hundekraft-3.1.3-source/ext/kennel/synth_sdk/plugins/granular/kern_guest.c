/* Granular's Blackfin kernels against its C loops on bcore (kern_check.py): granular.c built twice (kern_wrap.c), with
 * granular_dsp.S and with GR_C_LOOP, driven with the same calls and compared sample by sample. Scenarios: recordings
 * of any length with full-range random, saw or silent data and peak tables around the threshold (96 / 97, negative,
 * stray buckets), the firmware-like sine table or a random one (with -32768), random knob, pitch and velocity words,
 * notes struck on random voices, voices rendered out of order. Then recorded_length alone on random peak tables
 * (also misaligned), gr_grain alone on random grain states and counts 1..128, and gr_out alone on full-range sums,
 * gains and sample gains (the products wrap, the output saturates). Prints "KERN ok ..." or the first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include <stdint.h>
#include "op1_plugin.h"
extern const op1_engine_t ENGINE_granular, ref_ENGINE_granular;
int32_t asm_reclen(const uint8_t *sb);
int32_t ref_reclen(const uint8_t *sb);
void ref_grain(int32_t *acc, const int16_t *data, void *g, int32_t cnt);
void gr_grain(int32_t *acc, const int16_t *data, void *g, int32_t cnt);
void gr_out(int16_t *out, int32_t *acc, int32_t gain, int32_t sg);
void t2_write(const char *, int);
uint32_t t2_r246_calls[2];
volatile uint8_t op1_eng_page[4];

static unsigned blocks, bad, scen;
static char line[120];
static int n;
static void put(const char *p) { while (*p) line[n++] = *p++; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = (char)('0' + v % 10); while (v /= 10); put(b + i); }
static uint32_t rng = 12345;
static uint32_t rnd(void) { rng = rng * 1664525u + 1013904223u; return rng; }
static void fail(const char *what, unsigned i)
{
    bad = 1;
    put("KERN differ "); put(what); put(" block="); num(blocks); put(" i="); num(i); put(" scenario="); num(scen); put("\n");
}

#define SINE ((int16_t *)0x0101E5E8)
#define PITCH ((volatile uint32_t *)0xFF801950)
#define VEL ((volatile int16_t *)0xFF801064)
static int16_t sample[OP1_SAMPLE_GUARD + OP1_SAMPLE_MAX + 8];
static uint32_t sbw[(8 + 2 * OP1_PEAK_BUCKETS + 8) / 4 + 2], obj[2];
static int16_t *peaks(uint8_t *sb) { return (int16_t *)(sb + 4); }

static void make_sine(int random)
{
    int64_t c = (int64_t)1 << 30, s = 0;
    const int64_t cd = 1073741508, sd = 823550;
    for (int k = 0; k < 8192; k++) {
        SINE[k] = random ? (int16_t)rnd() : (int16_t)((s * 32767) >> 30);
        int64_t c2 = (c * cd - s * sd) >> 30, s2 = (s * cd + c * sd) >> 30;
        c = c2; s = s2;
    }
    if (random) { SINE[6144] = -32768; SINE[4096 + (rnd() & 4095)] = -32768; }
}

static int16_t peak_word(void)
{
    uint32_t r = rnd() >> 16;
    switch (r & 7) {
    case 0: return 96;
    case 1: return 97;
    case 2: return (int16_t)-(int32_t)(r >> 3);
    case 3: return (int16_t)(r >> 5);
    default: return 0;
    }
}

/* a recording of len samples: data and the peak table up to len (stray words above it now and then) */
static void make_recording(uint8_t *sb, uint32_t s)
{
    static const int32_t lens[6] = { 300, 1000, 44100, 100000, OP1_SAMPLE_MAX, 0 };
    int32_t len = lens[s % 6];
    if (!len) len = (int32_t)(rnd() % OP1_SAMPLE_MAX);
    const int mode = (int)((s / 6) % 3);
    int16_t *d = sample + OP1_SAMPLE_GUARD;
    for (int32_t i = 0; i < OP1_SAMPLE_MAX + 8; i++)
        d[i] = mode == 0 ? (int16_t)(rnd() >> 16) : mode == 1 ? (int16_t)(((i * 440) % 44100) * 65535 / 44100 - 32768) : 0;
    if (s % 5 == 0) for (int i = 0; i < 64; i++) d[rnd() % OP1_SAMPLE_MAX] = (int16_t)(i & 1 ? 32767 : -32768);
    int16_t *pk = peaks(sb);
    const int nb = (len + 255) / 256;
    for (int b = 0; b < OP1_PEAK_BUCKETS; b++) pk[b] = b < nb ? (rnd() & 1 ? (int16_t)(rnd() >> 17) : peak_word()) : 0;
    if (s & 1) pk[rnd() % OP1_PEAK_BUCKETS] = peak_word();
    if (s % 7 == 3) for (int b = 0; b < OP1_PEAK_BUCKETS; b++) pk[b] = peak_word();
}

static int16_t knob(void)
{
    uint32_t r = rnd() >> 16;
    switch (r & 7) {
    case 0: return 0;
    case 1: return 32767;
    case 2: return (int16_t)-(int32_t)(r >> 4);
    default: return (int16_t)(r >> 1);
    }
}

static void render_both(int v, const int16_t *k)
{
    int16_t a[128], b[128];
    ENGINE_granular.render(OP1_VOICE(v), a, k);
    ref_ENGINE_granular.render(OP1_VOICE(v), b, k);
    blocks++;
    for (int i = 0; i < 128 && !bad; i++)
        if (a[i] != b[i]) fail("render", (unsigned)i);
}

static void scenarios(void)
{
    uint8_t *sb = (uint8_t *)sbw;
    int16_t k[8];
    for (unsigned s = 0; s < 60 && !bad; s++) {
        scen = s;
        make_recording(sb, s);
        make_sine(s % 4 == 3);
        for (int i = 0; i < 8; i++) k[i] = knob();
        k[4] = 0;
        for (int v = 0; v < 6; v++) VEL[v] = (int16_t)(s % 5 == 4 ? rnd() : (rnd() % 128) << 8);
        const uint32_t pitch = s % 3 == 0 ? rnd() : (rnd() >> (4 + (rnd() & 7)));
        for (int i = 0; i < 128; i++) PITCH[i] = pitch;
        for (int v = 0; v < 6; v++) if (s == 0 || (rnd() & 1)) {
            ENGINE_granular.note_on(OP1_VOICE(v), k);
            ref_ENGINE_granular.note_on(OP1_VOICE(v), k);
        }
        for (unsigned r = 0; r < 40 && !bad; r++) {
            if ((rnd() & 3) == 0) k[rnd() & 7] = knob();
            k[4] = 0;
            if ((rnd() & 7) == 0) {
                const int v = (int)(rnd() % 6);
                for (int i = 0; i < 128; i++) PITCH[i] = rnd() >> (rnd() & 15);
                ENGINE_granular.note_on(OP1_VOICE(v), k);
                ref_ENGINE_granular.note_on(OP1_VOICE(v), k);
            }
            if (s & 2) {
                for (int t = 0; t < 6 && !bad; t++) if (rnd() & 1) render_both((int)(rnd() % 6), k);
            } else
                for (int v = 0; v < 6 && !bad; v++) render_both(v, k);
        }
    }
}

static void reclen_alone(void)
{
    for (unsigned t = 0; t < 3000 && !bad; t++) {
        uint8_t *sb = (uint8_t *)sbw + (t % 5 == 4 ? 2 : 0);              /* misaligned peaks: the bucket loop */
        int16_t *pk = peaks(sb);
        const int top = (int)(rnd() % (OP1_PEAK_BUCKETS + 1));
        for (int b = 0; b < OP1_PEAK_BUCKETS; b++) pk[b] = b < top ? peak_word() : (t & 1) ? 0 : (int16_t)(peak_word() & ~0x7F);
        if (t % 3 == 0 && top) pk[top - 1] = 97;
        blocks++;
        if (asm_reclen(sb) != ref_reclen(sb)) fail("recorded_length", (unsigned)top);
    }
}

static uint32_t ga[4], gb[4];
static int32_t acc_a[130], acc_b[130];
static void grain_alone(void)
{
    make_sine(1);
    for (int32_t i = 0; i < OP1_SAMPLE_MAX + 8; i++) sample[OP1_SAMPLE_GUARD + i] = (int16_t)(rnd() >> 16);
    for (unsigned t = 0; t < 4000 && !bad; t++) {
        const int32_t cnt = 1 + (int32_t)(rnd() % 128), off = (int32_t)(rnd() % (129 - (uint32_t)cnt));
        const uint32_t rate = t & 1 ? rnd() >> 15 : rnd() >> 22;
        ga[1] = rate;
        ga[3] = 1 + (rnd() >> (9 + (rnd() & 15)));
        ga[2] = rnd() >> 1;
        if ((uint64_t)ga[2] + (uint64_t)(cnt - 1) * ga[3] > 0x7FFFFFFFu)  /* inside the window (the caller's range) */
            ga[3] = (0x7FFFFFFFu - ga[2]) / (uint32_t)cnt;
        ga[0] = (rnd() % (OP1_SAMPLE_MAX - 4 - (uint32_t)cnt * ((rate >> 10) + 1))) << 10 | (rnd() & 1023);
        for (int i = 0; i < 4; i++) gb[i] = ga[i];
        for (int i = 0; i < 130; i++) acc_a[i] = acc_b[i] = (int32_t)rnd();
        gr_grain(acc_a + 1 + off, sample + OP1_SAMPLE_GUARD, ga, cnt);
        ref_grain(acc_b + 1 + off, sample + OP1_SAMPLE_GUARD, gb, cnt);
        blocks++;
        for (int i = 0; i < 130 && !bad; i++) if (acc_a[i] != acc_b[i]) fail("gr_grain", (unsigned)i);
        for (int i = 0; i < 4 && !bad; i++) if (ga[i] != gb[i]) fail("gr_grain state", (unsigned)i);
    }
}

static int16_t sat(int32_t x) { return (int16_t)(x > 32767 ? 32767 : x < -32768 ? -32768 : x); }
static void out_alone(void)
{
    for (unsigned t = 0; t < 2000 && !bad; t++) {
        const int32_t gain = t & 1 ? (int32_t)(rnd() >> 17) : (int32_t)rnd(), sg = t & 2 ? (int32_t)(rnd() >> 17) : (int32_t)rnd();
        int32_t ref[128];
        int16_t out[130];
        for (int i = 0; i < 128; i++) acc_a[i] = ref[i] = t & 4 ? (int32_t)rnd() >> (rnd() & 31) : (int32_t)(rnd() >> 14) - 131072;
        out[0] = out[129] = 0x5A5A;
        gr_out(out + 1, acc_a, gain, sg);
        blocks++;
        if (out[0] != 0x5A5A || out[129] != 0x5A5A) fail("gr_out bounds", 0);
        for (int i = 0; i < 128 && !bad; i++) {
            if (acc_a[i]) fail("gr_out clear", (unsigned)i);
            const int32_t y = sat((int32_t)((uint32_t)((int32_t)((uint32_t)ref[i] * (uint32_t)gain) >> 15) * (uint32_t)sg) >> 13);
            if (out[1 + i] != y) fail("gr_out", (unsigned)i);
        }
    }
}

int main(void)
{
    sbw[0] = (uint32_t)sample;
    obj[0] = (uint32_t)sbw; obj[1] = 44100;
    *(volatile int *)0x01AAAC0C = 0;
    ((uint32_t **)0x01DF6F78)[0] = obj;
    scenarios();
    reclen_alone();
    grain_alone();
    out_alone();
    if (!bad) { put("KERN ok blocks="); num(blocks); put("\n"); }
    t2_write(line, n);
    return 0;
}
