/* granular.c for kern_check.py, built twice into one guest: with granular_dsp.S, and with KERN_REF (GR_C_LOOP, the C
 * loops; the plugin's symbols renamed ref_*). Exposes recorded_length (and the reference's gr_grain) to kern_guest.c.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#ifdef KERN_REF
#define GR_C_LOOP 1
#define ENGINE_granular ref_ENGINE_granular
#define SCREEN_granular ref_SCREEN_granular
#endif
#include "granular.c"
#ifdef KERN_REF
int32_t ref_reclen(const uint8_t *sb) { return recorded_length(sb); }
void ref_grain(int32_t *acc, const int16_t *data, void *g, int32_t cnt) { gr_grain(acc, data, (grain_t *)g, cnt); }
#else
int32_t asm_reclen(const uint8_t *sb) { return recorded_length(sb); }
#endif
