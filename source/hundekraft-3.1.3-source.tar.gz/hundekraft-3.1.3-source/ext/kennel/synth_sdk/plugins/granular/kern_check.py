#!/usr/bin/env python3
# Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""Granular's Blackfin kernels (granular_dsp.S) against its own C loops on bcore: builds kern_guest.c with granular.c
twice (kern_wrap.c: with granular_dsp.S, and with GR_C_LOOP and the symbols renamed ref_*), runs it, exit 1 on any
difference. Covers recordings, peak tables, sine words, pitches and velocities that exact_check.py's regimes do not
reach, and gr_out's wrapping products and saturation. Prints SKIP without the toolchain or bcore.

    python3 synth_sdk/plugins/granular/kern_check.py
"""
import subprocess
import sys
import tempfile
from pathlib import Path

P = Path(__file__).resolve().parent
SDK = P.parents[1]
sys.path.insert(0, str(SDK / 'harness'))
import tier2 as T                                     # noqa: E402


def main():
    found = T.setup_env()
    if 'toolchain' not in found or 'emu' not in found:
        print('granular kern: SKIP (toolchain or bcore missing)')
        return 0
    t = T.tools(found['toolchain'])
    env = dict(T.os.environ, PATH=t['path'])
    with tempfile.TemporaryDirectory(prefix='granular-kern-') as tmp:
        tmp = Path(tmp)
        objs = []
        for src, name, extra in (('kern_guest.c', 'guest', []), ('kern_wrap.c', 'asm', []), ('granular_dsp.S', 'dsp', []),
                                 ('kern_wrap.c', 'ref', ['-DKERN_REF'])):
            o = tmp / (name + '.o')
            T.sh([t['gcc'], '-O3', '-mcpu=bf524', '-ffreestanding', '-fno-builtin', '-nostdlib', '-fno-common', '-Wall',
                  *extra, f'-I{SDK}', f'-I{P}', '-c', str(P / src), '-o', str(o)], env=env)
            objs.append(str(o))
        o = tmp / 'crt.o'
        T.sh([t['as'], '-mcpu=bf524', str(T.HERE / 'tier2/crt.S'), '-o', str(o)])
        libgcc = T.sh([t['gcc'], '-mcpu=bf524', '-print-libgcc-file-name'], env=env).strip()
        elf = tmp / 'kern.elf'
        T.sh([t['ld'], '--no-warn-rwx-segments', '--defsym=T2_STAGE=0x02000000', '-T', str(T.HERE / 'tier2/guest.ld'),
              str(o), *objs, libgcc, '-o', str(elf)])
        r = subprocess.run([found['emu'], '--fastmem', str(elf)], capture_output=True, text=True, timeout=3000)
    out = r.stdout.strip()
    print('granular kern:', out or r.stderr[-300:])
    return 0 if out.startswith('KERN ok') else 1


if __name__ == '__main__':
    sys.exit(main())
