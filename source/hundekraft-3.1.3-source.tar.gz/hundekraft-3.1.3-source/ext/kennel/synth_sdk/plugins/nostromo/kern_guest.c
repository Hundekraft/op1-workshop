/* Nostromo's Blackfin kernels against the C on bcore (kern_check.py). This file includes nostromo.c with NT_C_REF
 * (the C loops: FX_nostromo is the reference); the build links nostromo.c again with the kernels as FX_nostromo_k.
 * Part 1: each kernel alone against its C loop on random full-range data (int32 x[] beyond the clamps, the whole
 * int16 ring, write pointers that wrap inside the block), which reaches saturating paths the regimes may not.
 * Part 2: the two FX side by side (each with its own scratch) on every clock x program, knob extremes and random
 * words, full-scale noise, silence and saw, all three positions; every output sample, the meter and the state
 * compared. Prints "KERN ok blocks=N" or the first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#define NT_C_REF 1
#include "nostromo.c"

void t2_write(const char *, int);
void *op1_l1_claim(int part, const void *owner, uint32_t bytes, int *fresh) { (void)part; (void)owner; (void)bytes; *fresh = 0; return 0; }   /* no pool here */
void *op1_l1_claim_state(int part, void *home, uint32_t st, uint32_t bytes, int *fresh) { (void)part; (void)home; (void)st; (void)bytes; *fresh = 0; return 0; }
uint32_t t2_r246_calls[2];
volatile uint8_t op1_fx_page[3][4];
void *read_fx_param_safe(int a, int b) { (void)a; (void)b; return 0; }
extern const op1_fx_t FX_nostromo_k;
void nt_k_filt(int32_t *x, int n, int32_t *k);
void nt_k_ap(int32_t *x, int n, const int32_t *a);
void nt_k_map(int32_t *x, int n, const int32_t *a);
void nt_k_taps(int32_t *sum, int n, const int32_t *a);
void nt_k_dl(int32_t *x, int n, const int32_t *a);
void nt_k_add(int32_t *x, int n, const int32_t *a);
void nt_k_wr(const int32_t *x, int n, const int32_t *a);
void nt_k_dec(int32_t *x, const int16_t *buf, const int32_t *a);
void nt_k_int(int32_t *wet, const int32_t *x, int32_t *a);

static unsigned blocks, bad;
static char line[128];
static int nl;
static void put(const char *p) { while (*p) line[nl++] = *p++; }
static void num(uint32_t v) { char b[11]; int i = 10; b[i] = 0; do b[--i] = (char)('0' + v % 10); while (v /= 10); put(b + i); }
static int same(const void *a, const void *b, unsigned len)
{
    const uint8_t *x = a, *y = b;
    for (unsigned i = 0; i < len; i++) if (x[i] != y[i]) return 0;
    return 1;
}
static void fail(const char *what, uint32_t k) { if (!bad) { bad = 1; put("KERN differ "); put(what); put(" case="); num(k); put("\n"); } }
static uint32_t rng = 12345;
static uint32_t rnd(void) { rng = rng * 1664525u + 1013904223u; return rng; }
static int32_t rwide(uint32_t mode)                   /* int32 test values: small, around the clamps, full range */
{
    uint32_t r = rnd();
    switch (mode % 4) {
    case 0: return (int16_t)(r >> 16);
    case 1: return (int32_t)(r >> 13) - 262144;       /* +-2^18: beyond c17 */
    case 2: return (r & 1) ? 65535 + (int32_t)((r >> 8) & 3) - 1 : -65535 - (int32_t)((r >> 8) & 3) + 1;
    default: return (int32_t)r >> (7 + (r & 15));    /* up to +-2^24 */
    }
}

static int32_t xa[64], xb[64];
static void t_filt(void)
{
    for (uint32_t k = 0; k < 3000 && !bad; k++) {
        int n = 1 + (int)(rnd() % 64);
        int32_t st[7], coef[4];
        for (int i = 0; i < 64; i++) xa[i] = xb[i] = rwide(k + (uint32_t)i / 16);
        for (int i = 0; i < 3; i++) st[i] = rwide(k >> 2);
        for (int i = 3; i < 7; i++) st[i] = (int32_t)(rnd() & 32767);
        coef[0] = k % 5 == 0 ? 32767 : (int32_t)(rnd() & 32767);
        coef[1] = k % 7 == 0 ? 0 : (int32_t)(rnd() & 32767);
        coef[2] = k % 3 == 0 ? NT_GMAX : (int32_t)(rnd() % (NT_GMAX + 1));
        coef[3] = (int32_t)(rnd() % (2 * NT_GMAX + 1)) - NT_GMAX;
        int32_t lp = st[0], xo = st[1], xo2 = st[2], ef[4] = { st[3], st[4], st[5], st[6] };
        nt_filt_b(xa, n, &lp, &xo, &xo2, ef, coef[0], coef[1], coef[2], coef[3]);
        int32_t kk[11] = { st[0], st[1], st[2], st[3], st[4], st[5], st[6], coef[0], coef[1], coef[2], coef[3] };
        nt_k_filt(xb, n, kk);
        int32_t want[7] = { lp, xo, xo2, ef[0], ef[1], ef[2], ef[3] };
        blocks++;
        if (!same(xa, xb, sizeof xa) || !same(kk, want, sizeof want)) fail("nt_k_filt", k);
    }
}

static int16_t ra[NT_RING], rb[NT_RING];
static void ring_fill(uint32_t k)
{
    for (int i = 0; i < NT_RING; i++) {
        uint32_t r = rnd();
        ra[i] = rb[i] = k & 1 ? (int16_t)((r & 1) ? 32767 : -32768) : (int16_t)(r >> 16);
    }
}
static int32_t w_of(uint32_t k) { return k % 4 == 0 ? (int32_t)(rnd() % 70) - 1 : (int32_t)(rnd() & NT_MASK); }   /* often wrapping */
static void t_ap(void)
{
    for (uint32_t k = 0; k < 400 && !bad; k++) {
        if (k % 8 == 0) ring_fill(k / 8);
        int n = 1 + (int)(rnd() % 64), soft = (int)(k & 1);
        int32_t sz = k & 2 ? NT_DR : NT_RING;                    /* the tank's ring, or the input allpasses' (at its start) */
        int32_t w = (w_of(k >> 1) & NT_MASK) % sz, kh = (int32_t)(rnd() % (sz == NT_RING ? 3000 : 1000)), kt = kh + 1 + (int32_t)(rnd() % (sz == NT_RING ? 3000 : 1000));
        int32_t ih = (w + kh) % sz, it = (w + kt) % sz;
        int32_t g = k % 6 == 0 ? 32767 : k % 6 == 1 ? 0 : (int32_t)(rnd() & 32767);
        for (int i = 0; i < 64; i++) xa[i] = xb[i] = rwide(k + (uint32_t)i / 16);
        nt_ap_b(ra, sz, ih, it, xa, n, g, soft);
        const int32_t a[6] = { (int32_t)rb, ih, it, g, soft, sz * 2 };
        nt_k_ap(xb, n, a);
        blocks++;
        if (!same(xa, xb, sizeof xa) || !same(ra, rb, sizeof ra)) fail("nt_k_ap", k);
    }
}

static int32_t lfo[64];
static void t_map(void)
{
    for (uint32_t k = 0; k < 400 && !bad; k++) {
        if (k % 8 == 0) ring_fill(k / 8 + 7);
        int n = 1 + (int)(rnd() % 64);
        int32_t w = w_of(k) & NT_MASK, kh = (int32_t)(rnd() % 3000), len = 50 + (int32_t)(rnd() % 1500);
        int32_t amp = k % 5 == 0 ? 30720 : (int32_t)(rnd() % 30721);
        for (int i = 0; i < 64; i++) {
            lfo[i] = k % 3 == 0 ? (i & 1) * 32767 : (int32_t)(rnd() & 32767);
            xa[i] = xb[i] = rwide(k + (uint32_t)i / 16);
        }
        nt_map_b(ra, w, kh, len, amp, lfo, xa, n);
        const int32_t a[5] = { (int32_t)rb, (w + kh) & NT_MASK, len << 15, amp, (int32_t)lfo };
        nt_k_map(xb, n, a);
        blocks++;
        if (!same(xa, xb, sizeof xa) || !same(ra, rb, sizeof ra)) fail("nt_k_map", k);
    }
}

static void t_lines(void)                             /* taps, delay, add, write */
{
    for (uint32_t k = 0; k < 800 && !bad; k++) {
        if (k % 8 == 0) ring_fill(k / 8 + 99);
        int n = 1 + (int)(rnd() % 64), what = (int)(k % 4);
        int32_t w = w_of(k >> 2) & NT_MASK;
        for (int i = 0; i < 64; i++) xa[i] = xb[i] = rwide(k + (uint32_t)i / 16);
        if (what == 0) {
            int32_t ka[25], off[14];
            ka[0] = (int32_t)rb;
            for (int t = 0; t < 14; t++) off[t] = (int32_t)(rnd() % 60000);
            for (int t = 0; t < 14; t++) nt_tap_b(ra, w, off[t], xa, n, nt_tap_sign[t] < 0);
            for (int p = 0; p < 4; p++) {
                int32_t *q = ka + 1 + 6 * p;
                for (int i = 0; i < 4; i++) q[i] = 4 * p + i < 14 ? (w + off[4 * p + i]) & NT_MASK : (int32_t)(rnd() & NT_MASK);
                for (int i = 0; i < 2; i++) {
                    int t = 4 * p + 2 * i;
                    int32_t s0 = t < 14 ? nt_tap_sign[t] : 0, s1 = t + 1 < 14 ? nt_tap_sign[t + 1] : 0;
                    q[4 + i] = (int32_t)((uint32_t)(uint16_t)s1 << 16 | (uint16_t)s0);
                }
            }
            nt_k_taps(xb, n, ka);
        } else {
            int32_t kh = (int32_t)(rnd() % 3000), kr = kh + 1 + (int32_t)(rnd() % 3000);
            const int32_t a[3] = { (int32_t)rb, (w + kh) & NT_MASK, (w + kr) & NT_MASK };
            if (what == 1) { nt_dl_b(ra, w, kh, kr, xa, n); nt_k_dl(xb, n, a); }
            else if (what == 2) { nt_add_b(ra, w, kh, xa, n); nt_k_add(xb, n, a); }
            else { nt_wr_b(ra, w, kh, xa, n); nt_k_wr(xb, n, a); }
        }
        blocks++;
        if (!same(xa, xb, sizeof xa) || !same(ra, rb, sizeof ra)) fail(what == 0 ? "nt_k_taps" : what == 1 ? "nt_k_dl" : what == 2 ? "nt_k_add" : "nt_k_wr", k);
    }
}

static int16_t hx[2][32];
static int32_t hw[2][16], wa[64], wb[64], kd[96];
static void t_halfband(void)                           /* STD's decimator and interpolator, as nt_run's C */
{
    for (uint32_t k = 0; k < 600 && !bad; k++) {
        int16_t buf[64];
        int32_t hbi = (int32_t)(rnd() & 0x3FFE), hbj = (int32_t)(rnd() & 0x3FFF), hbo = rwide(k);
        for (int i = 0; i < 32; i++) hx[0][i] = hx[1][i] = k & 1 ? (int16_t)((rnd() & 1) ? 32767 : -32768) : (int16_t)(rnd() >> 16);
        for (int i = 0; i < 16; i++) hw[0][i] = hw[1][i] = k & 2 ? ((rnd() & 1) ? NT_HW : -NT_HW) : (int32_t)(rnd() % (2 * NT_HW + 1)) - NT_HW;
        for (int i = 0; i < 64; i++) buf[i] = k & 1 ? (int16_t)((rnd() & 1) ? 32767 : -32768) : (int16_t)(rnd() >> 16);
        int n = 0, ii = hbi;
        for (int t = 0, h = 0; t < 64; t++) {                     /* nt_run's decimation */
            hx[0][ii++ & 31] = buf[t];
            if (!(h ^= 1)) {
                int32_t c = ii - 16, a = 16384 * hx[0][c & 31];
                for (int j = 0; j < 8; j++) a += nt_hb[j] * (hx[0][(c - 2 * j - 1) & 31] + hx[0][(c + 2 * j + 1) & 31]);
                xa[n++] = nt_shr(a, 15);
            }
        }
        const int32_t da[2] = { (int32_t)hx[1], hbi };
        nt_k_dec(xb, buf, da);
        if (!same(xa, xb, 32 * sizeof xa[0]) || !same(hx[0], hx[1], sizeof hx[0])) fail("nt_k_dec", k);
        for (int j = 0; j < 32; j++) xa[j] = xb[j] = k & 4 ? rwide(k + (uint32_t)j) * 8 : xa[j];
        int32_t jj = hbj, ho = hbo;
        for (int t = 0, j = 0, half = 0; t < 64; t++) {           /* nt_run's interpolation */
            if ((half ^= 1)) wa[t] = ho;
            else {
                int32_t v = xa[j++];
                hw[0][jj++ & 15] = v < -NT_HW ? -NT_HW : (v > NT_HW ? NT_HW : v);
                int32_t m = jj - 9;
                int64_t b = nt_hbi(hw[0], m);
                wa[t] = hw[0][m & 15]; ho = (int32_t)(b >= 0 ? b >> 14 : -(-b >> 14));
            }
        }
        int32_t ia[4] = { (int32_t)hw[1], hbj, hbo, (int32_t)kd };
        nt_k_int(wb, xb, ia);
        blocks++;
        if (!same(wa, wb, sizeof wa) || !same(hw[0], hw[1], sizeof hw[0]) || ia[2] != ho) fail("nt_k_int", k);
    }
}

/* part 2: the FX side by side */
static uint32_t scr[2][3][(OP1_FX_SCRATCH_BYTES + 3) / 4];
static nt_t *const ref_state = nt;
static void make_sine(int16_t *t)
{
    int64_t c = (int64_t)1 << 30, s = 0;
    const int64_t cd = 1073741508, sd = 823550;
    for (int k = 0; k < 8192; k++) {
        t[k] = (int16_t)((s * 32767) >> 30);
        int64_t c2 = (c * cd - s * sd) >> 30, s2 = (s * cd + c * sd) >> 30;
        c = c2; s = s2;
    }
}
static void init_both(int pos)
{
    ((void **)0x01AB8BA0)[pos] = scr[0][pos]; FX_nostromo.init(pos);
    ((void **)0x01AB8BA0)[pos] = scr[1][pos]; FX_nostromo_k.init(pos);
}
static void fx_run(uint32_t sc, uint32_t renders)
{
    int16_t q[8], a[64], b[64];
    uint32_t c = sc % 3, p = (sc / 3) % 27, v = sc / 81;            /* clock, program, knob style */
    for (int pos = 0; pos < 3; pos++) init_both(pos);
    for (uint32_t r = 0; r < renders && !bad; r++) {
        if (r % 37 == 0) {
            for (int i = 0; i < 8; i++) {
                uint32_t x = rnd();
                q[i] = v == 0 ? (int16_t)(x >> 17) : v == 1 ? ((x & 1) ? 32767 : 0) : (int16_t)((x >> 17) & 0x7C00);
            }
            q[6] = (int16_t)(2048 * c + 1024);
            q[7] = (int16_t)((2 * p + 1) * 32768 / 54);
        }
        int pos = (int)(r % 3);
        uint32_t ph = (r / 3 + sc) % 120;
        for (int i = 0; i < 64; i++) {
            uint32_t x = rnd();
            a[i] = ph < 30 ? (int16_t)((x & 1) ? 32767 : -32768) : ph < 60 ? (int16_t)(x >> 16) : ph < 80 ?
                   (int16_t)(((int)(r * 64 + (uint32_t)i) & 31) * 2048 - 32767) : 0;
            b[i] = a[i];
        }
        volatile int16_t *m = op1_fx_meter(pos);
        int16_t m0 = *m;
        FX_nostromo.render(pos, a, q);
        int16_t ma = *m;
        *m = m0;
        FX_nostromo_k.render(pos, b, q);
        blocks++;
        if (!same(a, b, sizeof a) || *m != ma) fail("FX output", sc * 100000 + r);
    }
}

int main(void)
{
    make_sine((int16_t *)0x0101E5E8);
    (void)ref_state;
    t_filt();
    t_ap();
    t_map();
    t_lines();
    t_halfband();
    for (uint32_t sc = 0; sc < 243 && !bad; sc++) fx_run(sc, 420);
    if (!bad) { put("KERN ok blocks="); num(blocks); put("\n"); }
    t2_write(line, nl);
    return 0;
}
