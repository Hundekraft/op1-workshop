#!/usr/bin/env python3
# Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
"""Nostromo's Blackfin kernels (nostromo_kern.S) against nostromo.c's C loops on bcore: builds kern_guest.c (which
includes nostromo.c with NT_C_REF, the reference) with nostromo.c again (the kernels, as FX_nostromo_k) and
nostromo_kern.S (pack.py's flags), runs it, exit 1 on any difference. Covers the clamps, saturation and wrapping
pointers that exact_check.py's regimes may not reach. Prints SKIP without the toolchain or bcore.

    python3 synth_sdk/plugins/nostromo/kern_check.py
"""
import subprocess
import sys
import tempfile
from pathlib import Path

P = Path(__file__).resolve().parent
SDK = P.parents[1]
sys.path.insert(0, str(SDK / 'harness'))
import tier2 as T                                     # noqa: E402


def main():
    found = T.setup_env()
    if 'toolchain' not in found or 'emu' not in found:
        print('nostromo kern: SKIP (toolchain or bcore missing)')
        return 0
    t = T.tools(found['toolchain'])
    env = dict(T.os.environ, PATH=t['path'])
    with tempfile.TemporaryDirectory(prefix='nostromo-kern-') as tmp:
        tmp = Path(tmp)
        objs = []
        for src, extra in (('kern_guest.c', []), ('nostromo_kern.S', []),
                           ('nostromo.c', ['-DFX_nostromo=FX_nostromo_k', '-DSCREEN_nostromo=SCREEN_nostromo_k'])):
            o = tmp / (src.replace('.', '_') + '.o')
            T.sh([t['gcc'], '-O2', '-mcpu=bf524', '-ffreestanding', '-fno-builtin', '-nostdlib', '-fno-common', '-Wall',
                  f'-I{SDK}', f'-I{P}', *extra, '-c', str(P / src), '-o', str(o)], env=env)
            objs.append(str(o))
        o = tmp / 'crt.o'
        T.sh([t['as'], '-mcpu=bf524', str(T.HERE / 'tier2/crt.S'), '-o', str(o)])
        libgcc = T.sh([t['gcc'], '-mcpu=bf524', '-print-libgcc-file-name'], env=env).strip()
        elf = tmp / 'kern.elf'
        T.sh([t['ld'], '--no-warn-rwx-segments', '--defsym=T2_STAGE=0x02000000', '-T', str(T.HERE / 'tier2/guest.ld'),
              str(o), *objs, libgcc, '-o', str(elf)])
        r = subprocess.run([found['emu'], '--fastmem', str(elf)], capture_output=True, text=True, timeout=3000)
        o = tmp / 'kern_front_c.o'                    # the front: kernels and glue against the C front
        T.sh([t['gcc'], '-O2', '-mcpu=bf524', '-ffreestanding', '-fno-builtin', '-nostdlib', '-fno-common', '-Wall',
              '-Wno-unused-function', f'-I{SDK}', f'-I{P}', '-c', str(P / 'kern_front.c'), '-o', str(o)], env=env)
        elf2 = tmp / 'front.elf'
        T.sh([t['ld'], '--no-warn-rwx-segments', '--defsym=T2_STAGE=0x02000000', '-T', str(T.HERE / 'tier2/guest.ld'),
              str(tmp / 'crt.o'), str(o), objs[1], libgcc, '-o', str(elf2)])
        r2 = subprocess.run([found['emu'], '--fastmem', str(elf2)], capture_output=True, text=True, timeout=3000)
    out, out2 = r.stdout.strip(), r2.stdout.strip()
    print('nostromo kern:', out or r.stderr[-300:])
    print('nostromo kern:', out2 or r2.stderr[-300:])
    return 0 if out.startswith('KERN ok') and out2.startswith('FRONT ok') else 1


if __name__ == '__main__':
    sys.exit(main())
