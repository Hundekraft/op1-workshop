/* Nostromo's front kernels (nt_k_front, nt_k_er) against the C front on bcore (kern_check.py): this file includes
 * nostromo.c as the Blackfin builds it (with the kernels), so nt_front_k (the kernels and their glue) and nt_front_c
 * (the C: the fallback and the host's loop) run side by side on copies of one random state: pre-delay positions,
 * fades (also ending inside the block), regeneration, every clock (sh, ADC), room / hall sparse / none, the clear's
 * fade-in; ticks, reflections, pre-delay line and state compared. Prints "FRONT ok" or the first difference.
 * Copyright (C) 2026 Hundekraft. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE). */
#include "nostromo.c"
void t2_write(const char *, int);
void *op1_l1_claim(int part, const void *owner, uint32_t bytes, int *fresh) { (void)part; (void)owner; (void)bytes; *fresh = 0; return 0; }   /* no pool here */
void *op1_l1_claim_state(int part, void *home, uint32_t st, uint32_t bytes, int *fresh) { (void)part; (void)home; (void)st; (void)bytes; *fresh = 0; return 0; }
uint32_t t2_r246_calls[2];
volatile uint8_t op1_fx_page[3][4];
void *read_fx_param_safe(int a, int b) { (void)a; (void)b; return 0; }
static char line[400]; static int nl;
static void put(const char *p) { while (*p) line[nl++] = *p++; }
static void num(int32_t v) { char b[12]; int i = 11; int neg = v < 0; uint32_t u = neg ? -(uint32_t)v : (uint32_t)v; b[i] = 0; do b[--i] = (char)('0' + u % 10); while (u /= 10); if (neg) b[--i] = '-'; put(b + i); }
static uint32_t rng = 777;
static uint32_t rnd(void) { rng = rng * 1664525u + 1013904223u; return rng; }
static int16_t pa[NT_PD], pb[NT_PD];
static nt_t A, B;
static nt_ws WA, WB;                                             /* each side its own workspace */
static int32_t xa[64], xb[64];
int main(void)
{
    int bad = 0;
    for (uint32_t k = 0; k < 20000 && !bad; k++) {
        nt_t *s = &A;
        for (unsigned i = 0; i < sizeof A; i++) ((uint8_t *)&A)[i] = 0;
        for (int i = 0; i < NT_PD; i++) pa[i] = pb[i] = (int16_t)(k & 1 ? ((rnd() & 1) ? 32767 : -32768) : (int16_t)(rnd() >> 16));
        int r = (int)(k % 3 == 0 ? 0 : 1), sh = (int)(k % 3 == 1), ty = (int)(rnd() % 3), n = 1 + (int)(rnd() % 64);
        s->pw = (int32_t)(rnd() % NT_PD);
        uint32_t mode = rnd() % 4;
        s->pd_cur = mode == 0 ? (int32_t)(rnd() % 100) : (int32_t)(rnd() % 22049);
        s->pd_next = (int32_t)(rnd() % 22049);
        s->pd_fade = (k / 3) % 2 ? 0 : 1 + (int32_t)(rnd() % 1024);
        if (k % 7 == 0) s->pd_fade = 1024 - (int32_t)(rnd() % 8);
        s->spg = (k / 5) % 2 ? 0 : (int32_t)(rnd() & 32767);
        s->rgg = (k / 11) % 2 ? 0 : (int32_t)(rnd() % 16385);
        s->rgn = (int32_t)(rnd() % 65);
        s->ein = (k % 13 == 0) ? (int32_t)(rnd() % 257) : 0;
        s->cvn = (int32_t)(rnd() % 32); s->ask = (int32_t)(rnd() % 5); s->apk = (int32_t)(rnd() % 30000);
        for (int j = 0; j < 64; j++) { s->rg[j] = (int32_t)(rnd() >> 14) - 131072; xa[j] = (int32_t)(rnd() >> 14) - 131072; if (!sh) xa[j] = (int16_t)xa[j]; xb[j] = xa[j]; }
        nt_fill(s, r, ty);                                        /* the layout's reflection taps */
        for (unsigned i = 0; i < sizeof A; i++) ((volatile uint8_t *)&B)[i] = ((uint8_t *)&A)[i];
        A.pd = pa; B.pd = pb; A.w = &WA; B.w = &WB;
        nt_front_k(&A, r, ty, sh, xa, n);
        nt_front_c(&B, r, ty, sh, xb, n, 0);
        int dx = -1, dt = -1, dp = -1;
        for (int j = 0; j < n; j++) { if (xa[j] != xb[j] && dx < 0) dx = j; if (A.w->te[j] != B.w->te[j] && dt < 0) dt = j; }
        for (int i = 0; i < NT_PD; i++) if (pa[i] != pb[i]) { dp = i; break; }
        int st = A.pw != B.pw || A.pd_fade != B.pd_fade || A.pd_cur != B.pd_cur || A.apk != B.apk || A.ask != B.ask || A.ein != B.ein;
        if (dx >= 0 || dt >= 0 || dp >= 0 || st) {
            bad = 1;
            put("FRONT differ k="); num((int32_t)k); put(" r="); num(r); put(" sh="); num(sh); put(" ty="); num(ty); put(" n="); num(n);
            put(" fade="); num(s == &A ? B.pd_fade : 0); put(" x@"); num(dx); put(" te@"); num(dt); put(" pd@"); num(dp); put(" st="); num(st);
            if (dt >= 0) { put(" te "); num(A.w->te[dt]); put(" vs "); num(B.w->te[dt]); }
            if (dx >= 0) { put(" x "); num(xa[dx]); put(" vs "); num(xb[dx]); }
        }
    }
    if (!bad) put("FRONT ok");
    put("\n"); t2_write(line, nl);
    return 0;
}
