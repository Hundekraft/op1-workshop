# Clouds exact optimization

This change fuses full-rate grain envelope/read work, caches grain setup by its
control inputs, hoists invariant seeding comparisons and specializes delay-line
addressing. Grain count, audio rate, RNG sequence and per-sample mix remain intact.
Both `clouds_dsp.c` and its header must be rebuilt together.

Kennel note (imported from op1r 44, `bf808cf`): `clouds_exact_verify.py` is not carried here, since it needs
upstream's unoptimized base commit. Kennel locks the same captures instead: `harness/clouds_cap_check.py` builds
`harness/clouds_exact_test.c` under ASan/UBSan and compares the op1 hashes in the table below, plus four locked
4 s controls sets. The opt-in modes in `clouds_dsp.c` (`CLOUDS_FAST_GRAINS`, `CLOUDS_GRAIN_BUDGET`,
`CLOUDS_BLOCK_MIX`, `CLOUDS_QUARTER_REVERB`) are kennel-only, off by default and not sample-exact.

## Reproduce the output comparison (upstream)

From the repository root:

```sh
python3 synth_sdk/harness/clouds_exact_verify.py .
```

Requires Python 3, Git and a C compiler with ASan and UBSan. Set `CC` to select the
compiler. The base revision defaults to
`358d7e6d0460318e1108784fe14acfbfd3850ab4`; `--base` selects another unoptimized
revision. The script builds in a temporary directory without changing the tree.

Six paired granular-mode captures pass sample-for-sample with ASan, UBSan and
`CLOUDS_CHECK`: each of the OP-1 (44.1 kHz, 24 grains, linear reads, idle skipping)
and reference (32 kHz, 40 grains, Hermite reads) configurations runs:

- 12,000 changing-control blocks, lengths 1–64, across three instances, with
  freeze/trigger, reinitialization and pitch changes.
- 24,000 sustained positive/negative/alternating/saw rail blocks, full reverb,
  freeze transitions and pitch at ±24 semitones.
- 100 blocks starting near `INT32_MAX`, comparing both audio and phasor state.

The baseline uses `-fwrapv` to define the inherited signed phasor overflow;
the patch uses unsigned addition and runs without `-fwrapv`. Feedback stays zero
as in the OP-1 wrapper. These checks do not replace the broader existing
float-reference/looping-delay harness. Hashes below are from little-endian captures.

## Blackfin instruction-work measurements

Compiler: BF524 GCC 13.3, `-O2`. The same loader, mono wrapper, input and raw control
words are used before/after. Work is the difference between cumulative runs of
2,756 and 3,012 renders, divided by 256 (64 samples per render). Thus initialization
and early grain buildup are excluded from the measured interval.

These are executed instruction packets, **not physical cycles or sysmon CPU
percentages**. Cache/SDRAM stalls are absent. This is a controlled probe
using an equivalent mono wrapper, not a comparison of complete firmware.
Physical OP-1 acceptance is still needed; no deadline guarantee is claimed.

| Probe case | Upstream packets/render | Patched | Reduction |
|---|---:|---:|---:|
| A: baseline texture | 32,293.4 | 28,828.2 | 10.7% |
| B: maximum controls | 147,397.5 | 122,065.9 | 17.2% |
| C: diffuse texture | 111,517.9 | 89,133.2 | 20.1% |
| D: dense + reverb | 143,598.6 | 117,706.8 | 18.0% |

The case names are probe identifiers, not factory presets. These are the exact
input parameter words **before** the wrapper's ordinary parameter normalization
and clamping. Word 4 is the plugin marker and is not a DSP control.

| Case | p0 | p1 | p2 | p3 | p5 | p6 | p7 |
|---|---:|---:|---:|---:|---:|---:|---:|
| A | 16384 | 16384 | 24576 | 16384 | 16384 | 22938 | 0 |
| B | 32767 | 32767 | 32767 | 32767 | 32767 | 32767 | 32767 |
| C | 20000 | 30000 | 2000 | 30000 | 4000 | 32767 | 0 |
| D | 8000 | 32767 | 0 | 0 | 32767 | 32767 | 32767 |

## Capture hashes at the time of the change

For reference only: they change with any later edit of the clouds DSP. `clouds_exact_verify.py` does not use
them; it compares the patched tree with the base revision directly.

| Configuration | Scenario | Bytes | SHA-256 |
|---|---|---:|---|
| op1 | dynamic | 790680 | `b6181e7578bd0f1865c665ac0a4c82c62afa2e5930eb3d28f9d275db248c4452` |
| op1 | rails | 3072000 | `f9b8bcf561c2b35754a6bef72cbd2b053c882f5ef5e9349b16da66d8690bbc8f` |
| op1 | edge | 13200 | `784e6df1b4ff4afa9b57407c74c03b14c523a3b92c2fe6b3b542b7f126dc0555` |
| reference | dynamic | 790680 | `3f83b142b6a36036783f465d00849a560def7f399a87ef1c9d09530fc414069b` |
| reference | rails | 3072000 | `3d01158fec803fbbed8ed771ec78d6f60468bc6ea651dde1864fbe654ba590fb` |
| reference | edge | 13200 | `784e6df1b4ff4afa9b57407c74c03b14c523a3b92c2fe6b3b542b7f126dc0555` |

## Blackfin kernels (kennel, 2026-10-28)

On the Blackfin the shipping build's sample loops run in `clouds_dsp.S` (grain chunks, gain normalization, dry / wet
mix, diffuser, quarter-rate reverb, seeding tests, recording write), bit-exact against the C loops, which stay for host
builds and as the reference. `kern_check.py` runs each kernel against a copy of its C loop on bcore with random
inputs over the full range; `harness/exact_check.py clouds` (46 regimes) compares whole renders. The per-block 64-bit
work (two seeding divisions, the normalization's square root, (a * b) >> 15 products) is 32-bit C now, in all builds,
with the same values; the capture hashes above and `clouds_cap_check.py`'s locked hashes are unchanged. Packets per FX
call at all knobs maximum: 66.7k -> 33.3k; numbers and the kernels' design in kennel ARCHITECTURE.md "Clouds Blackfin
kernels".

## L1 state lease and per-block code (kennel, 2026-10-30, branch opt-clouds)

With the kennel core's L1 pool the whole `clouds_t` of a playing instance is a state lease in its position's partition
(`op1_l1_claim_state`, clouds.c `cl_claim`), with the soft-limit centre after it. init and render reach the state only
through what `cl_claim` returns, for that call. The screen must never read `cl[]`: it reads `cl_scr`, which render writes.
The per-block values that follow from the knobs, the grain-size hint, the grain count and dry/wet are computed once per
change in cold out-of-line functions (`gr_setup`, `sd_setup`, `gn_setup`, `xf_setup`), and the free-grain scan reads the
packed `gact[]`. All bit-exact (exact_check 46 regimes, pool off / on / poison / evict); numbers in OP1-Emulator
`run/l1-opt-2026-10-30/clouds/`.
