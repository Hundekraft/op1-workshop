/* Fixed-point port of Mutable Instruments Clouds (granular processor), mono.
 * Original: https://github.com/pichenettes/eurorack/tree/master/clouds, (c) 2014 Emilie Gillet, MIT license.
 * Port: no floating point (Blackfin has no FPU). Modes: granular, looping delay. Stretch / spectral are not
 * ported. Reference build + comparison: harness/clouds_compare.py (original vendored in third_party/).
 *
 * Audio: Q15 (int16 / int32 with headroom). Parameters: Q15 0..32767 = 0.0..1.0, pitch in 1/256 semitones.
 * CLOUDS_SR: 32000 = identical timing to the original (used for verification), 44100 on the OP-1.
 * OP-1 speed options (off in the verification build): CLOUDS_LINEAR_READ (grains read with linear instead of
 * Hermite interpolation: no 64-bit multiplies per grain sample), CLOUDS_SKIP_IDLE (diffuser / reverb /
 * feedback filter not run while their amount is 0), CLOUDS_MAX_GRAINS (default 40). */
#ifndef CLOUDS_DSP_H
#define CLOUDS_DSP_H
#include <stdint.h>
#include <stddef.h>

#ifndef CLOUDS_SR
#define CLOUDS_SR 44100
#endif
#define CLOUDS_MAX_BLOCK   64
#ifndef CLOUDS_MAX_GRAINS
#define CLOUDS_MAX_GRAINS  40          /* original: 40 in mono hi-fi mode */
#endif
#define CLOUDS_BUFFER_BYTES 118784     /* recording buffer (as the original's large buffer) */
#define CLOUDS_FX_BYTES    ((2048 * 4) + (16384 * 2) + (4096 * 2))   /* diffuser + reverb + pitch shifter */
#define CLOUDS_MEM_BYTES   (CLOUDS_BUFFER_BYTES + CLOUDS_FX_BYTES)    /* 167936, fits the OP-1 FX scratch */

enum { CLOUDS_GRANULAR = 0, CLOUDS_LOOPING = 1 };

typedef struct {
    int32_t position, size, density, texture, dry_wet, feedback, reverb;   /* Q15 0..32767 */
    int32_t pitch;                                                         /* semitones * 256 */
    uint8_t freeze, trigger;
} clouds_params_t;

typedef struct {                                /* 32 bytes: one cache line (the width the original keeps is never read) */
    int32_t first_sample, phase, phase_increment;
    uint32_t env_phase, env_increment;          /* Q30: 2.0 = 2^31 */
    int32_t env_slope;                          /* Q12, up to 204,600 */
    uint16_t env_smoothness;                    /* Q15, 0 .. 32768 */
    uint16_t env_slope_limit;                   /* gain above which gain * slope clips (no per-sample divide), <= 33,428 */
    uint8_t pre_delay, active, quality;         /* pre_delay: the start's sample in its block, 0 .. 63 */
} clouds_grain_t;
_Static_assert(sizeof(clouds_grain_t) == 32, "clouds_grain_t: one cache line");

typedef struct { int32_t g, r, h, s1, s2; } clouds_svf_t;   /* coefficients Q24, state Q15 */

/* what schedule_grain works out from the parameters alone (clouds_dsp.c grain_tpl), kept per block */
typedef struct {
    int64_t gs;                                         /* grain size, Q8 samples */
    int32_t width, offset, inc;                         /* samples; start = head - offset; Q16 */
    uint32_t env_increment;
    int32_t env_smoothness, env_slope, env_slope_limit;
} clouds_tpl_t;

typedef struct clouds {
    /* hot first (each block reads these: the fewest cache lines when the state is not in the L1 pool) */
    int16_t *s16;                                       /* recording buffer */
    int32_t size, head, crossfade;
    int mode;
    int32_t num_grains_q16, gain_norm_q15, hint_q8, phasor;
    uint32_t rng;
    int32_t freeze_lp_q30, dry_wet_q15;
    /* play_granular's per-block values that follow from the knobs and the grain-size hint alone (gr_setup, run when one
     * of its inputs moves): the seeding thresholds (the two 64-bit divisions), the grain set-up, the window's gain */
    int32_t gk[6];                                      /* inputs: density, texture, size, pitch, position, hint */
    int32_t g_target, g_space32, g_wfac;                /* target count Q16, deterministic spacing, window gain */
    uint32_t g_thr;                                     /* random seeding threshold (p_q32 below 2^32) */
    int32_t gn_key, gn_val;                             /* the normalization gain for num_grains_q16 = gn_key */
    int32_t xf_key, xf_fi, xf_fo;                       /* the dry / wet curves at dry_wet = xf_key (CLOUDS_BLOCK_MIX) */
    const int32_t *sl_l1; int32_t sl_n;                  /* L1 copy of cl_soft_limit's centre +-sl_n entries (clouds.c), or 0; set per block */
    uint8_t g_ok, g_det, g_pok, g_pall, g_never;        /* valid, DENSITY < 50 %, p_q32 >= 0, p_q32 >= 2^32, no spacing */
    uint8_t gn_ok, xf_ok, tpl_ok;
    uint8_t gact[CLOUDS_MAX_GRAINS];                    /* grains[i].active, packed: the per-block scan reads these */
    clouds_tpl_t tpl;                                   /* the grain set-up of the last block and its inputs (grain starts) */
    int32_t tpl_key[4];
    /* fx engines */
    int32_t *diff_buf;  int32_t diff_wp;
    int16_t *rev_buf;   int32_t rev_wp, rev_lp1, rev_lp2, rev_wo;  int32_t rev_lfo[2], lfo_y0[2], lfo_y1[2], lfo_iir[2];
    /* granular player: a grain per cache line */
    clouds_grain_t grains[CLOUDS_MAX_GRAINS] __attribute__((aligned(32)));
    /* cold: the looping player (Q12 sample positions), the pitch shifter, the filters, the freeze crossfade */
    int64_t lp_current_delay;                           /* Q28 */
    int32_t lp_phase, lp_loop_point, lp_loop_duration, lp_tail_start, lp_tail_duration,
            lp_loop_reset, lp_inv_tail;
    int16_t *ps_buf;    int32_t ps_wp;  uint32_t ps_phase; int32_t ps_size_q16;
    clouds_svf_t fb_filter, lp_filter, hp_filter;
#ifndef CLOUDS_NO_FEEDBACK                              /* clouds.c: FEEDBACK is fixed at 0 there, so the fed-back block is never read */
    int32_t fb[CLOUDS_MAX_BLOCK];
#endif
    int prev_mode;
    int16_t tail[257];
} clouds_t;

void clouds_init(clouds_t *c, void *mem, int mode);            /* mem: CLOUDS_MEM_BYTES */
void clouds_process(clouds_t *c, const clouds_params_t *p, const int16_t *in, int16_t *out, int n);
#endif
