#!/usr/bin/env python3
"""VAPORA's 15 factory sounds as OP-1 patch files.
    python3 presets.py [OUT_DIR]      -> OUT_DIR/*.aif (default: presets/ next to this script)

The sounds are AiAAAA's op1r 47 factory bank (data/recipes.json: the final patch JSON of each, written by upstream's
tools/gen_presets.py; data/presets.json and core_set.json define them, see README.md). This script writes them in
kennel's pattern (hollowsaint/presets.py): an AIFC file (16-bit mono, 44.1 kHz, 'sowt') with an APPL chunk holding
"op-1" + JSON and an empty SSND chunk (the firmware renders its own preview when it syncs). Saved sounds find the
engine by its saved type name, "vapora" (the plugin id; kennel docs/preset-identity.md); knobs[4] holds 0x5300
(OP1_ENGINE_MAGIC alone): a file plugin has no fixed number, kennel finds it by name, and without the plugin the sound
falls back to the stock iter and keeps its name. The words are the same as upstream's, so the files load on op1r 47 too.
Deep Pressure saves the Reverb effect (fx_type "reverb", selector by name); the other fourteen are dry.
Every value stays inside the ranges the factory presets use (measured by Hundekraft, tools/op1r_presets.py): values
outside them make the firmware import the file as a plain sample.
Install: copy the presets folder to the OP-1's synth/ folder in disk mode (Shift + COM, T3), e.g. as synth/vapora/.
Container code adapted from Hundekraft's MBIRA presets.py (GPL-3.0-or-later with the OP-1 firmware permission);
the sounds and this version copyright (C) 2026 the VAPORA contributors, same licence.
"""
import json
import math
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
RANGE_ADSR = [(64, 16320), (64, 16320), (0, 32767), (64, 16320)]
SELECTOR = 0x5300                 # OP1_ENGINE_MAGIC: no fixed number (see above)


def ieee_extended(x):
    exp = int(math.floor(math.log2(x)))
    return struct.pack(">HQ", exp + 16383, int(x / 2 ** exp * 2 ** 63))


def chunk(cid, body):
    return cid + struct.pack(">I", len(body)) + body + (b"\0" if len(body) & 1 else b"")


def aifc(meta):
    comm = struct.pack(">hIh", 1, 0, 16) + ieee_extended(44100) + b"sowt" + b")Signed integer (little-endian) linear PCM"
    js = json.dumps(meta, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    if len(js) & 1:
        js += b" "
    body = (chunk(b"FVER", bytes.fromhex("a2805140")) + chunk(b"COMM", comm) + chunk(b"APPL", b"op-1" + js)
            + chunk(b"SSND", struct.pack(">II", 0, 0)))
    return b"FORM" + struct.pack(">I", len(body) + 4) + b"AIFC" + body


def check(meta):
    name = meta["name"]
    assert meta["type"] == "vapora" and meta["knobs"][4] == SELECTOR, name
    assert all(0 <= x <= 32767 for x in meta["knobs"]) and all(x >= 1 for x in meta["knobs"][5:]), name
    for i, (lo, hi) in enumerate(RANGE_ADSR):
        assert lo <= meta["adsr"][i] <= hi, f"{name}: adsr[{i}]"


def main():
    if len(sys.argv) > 2:
        sys.exit(__doc__)
    out = Path(sys.argv[1]) if len(sys.argv) == 2 else HERE / "presets"
    out.mkdir(parents=True, exist_ok=True)
    recipes = json.loads((HERE / "data" / "recipes.json").read_text())
    for meta in recipes:
        check(meta)
        (out / (meta["name"] + ".aif")).write_bytes(aifc(meta))
    print(f"{len(recipes)} presets in {out}")


if __name__ == "__main__":
    main()
