"""Plugin discovery: every plugins/<folder>/plugin.json is one synth engine or FX.

plugin.json fields (paths relative to the plugin folder):
  name           the id: [a-z0-9_-], <= 15 chars, = the folder (docs/plugin-format.md "Names"); load() returns it as
                 "id" and the saved name derived from it ('_' -> ' ', or "saved_name") as "name"
  saved_name     only for the frozen exceptions (pack.SAVED_NAMES: drumplus -> "drum+")
  kind           "synth" or "fx"
  order          the number stored in saved sounds (knobs[4] = 0x5300 + order), unique per kind, 1..31; never
                 change it once released. Gaps are fine. Taken numbers: plugins/ORDERS.md. Optional for a
                 "loadable" plugin: without it the file has no fixed number and the loader gives it one of 32..63
                 at boot (op1rplugins map, docs/preset-identity.md); saved sounds find it by type name
  symbol         the op1_engine_t / op1_fx_t object in the sources
  sources        C files; the first one defines `symbol`
  defaults       initial 4 knob positions (0..32767)
  page2_defaults (fx, optional) initial page-2 knob positions
  stereo         (FX, optional boolean) extended op1_fx_stereo_t entry with direct master L/R rendering
  coarse         (synth, optional) knob numbers 0..3 turned in 8 steps over the range (both pages), e.g. a selector
                 (op1r 44's field; header flag bits 16..19, kn_load.h KN_FLAG_COARSE_MASK)
  uses_sample    (synth, optional) engine reads the slot's sampler recording (synth_<slot>.raw loaded at boot)
  screen         (optional) {"svg": file name, must not clash with stock content/display, "symbol": op1_screen_t}
  loadable       true: not compiled in; make_firmware packs it into content/<name>.knl (the default for every plugin)
  builtin        (instead of loadable) why the plugin must stay compiled in; harness/matrix.py fails on a plugin that
                 has neither. Today only settings.
  claims         (feature) the exclusive resources it claims, exactly its op1_feature_t claims list in the same order;
                 packed into the file's extension table so the workshop resolves conflicts before installing
                 (harness/matrix.py checks it against what the feature registers at boot)
Orders 1..31 per kind (OP1_MAX_ORDER in op1_plugin.h).
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
DIR = os.path.join(HERE, 'plugins')


def _pack():                                     # the naming rule lives in tools/kennel/pack.py (check_id)
    import sys
    sys.path.insert(0, os.path.join(os.environ.get('KENNEL_ROOT', os.path.dirname(HERE)), 'tools', 'kennel'))
    import pack
    return pack


def load(kinds=('synth', 'fx')):
    """-> (engines, effects) sorted by order; paths relative to the SDK root (as make_firmware expects).
    Features (kind "feature", kennel op1_feature.h) are left out here: load_features()."""
    engs, fxs, feats = [], [], []
    for d in sorted(os.listdir(DIR)):
        pj = os.path.join(DIR, d, 'plugin.json')
        if not os.path.isfile(pj):
            continue
        p = json.load(open(pj))
        rel = lambda f: os.path.join('plugins', d, f)
        e = {k: v for k, v in p.items() if k not in ('kind', 'sources')}
        e['id'], e['name'] = p['name'], _pack().check_id(p, d)   # name: the saved name (type name, DB rows, tables)
        e['source'], e['extra_sources'] = rel(p['sources'][0]), [rel(s) for s in p['sources'][1:]]
        if p.get('screen'):
            e['screen'] = dict(p['screen'], svg=rel(p['screen']['svg']))
        assert 'stereo' not in p or isinstance(p['stereo'], bool), f'{pj}: stereo must be a boolean'
        assert not p.get('stereo') or p['kind'] == 'fx', f'{pj}: stereo is FX-only'
        assert not p.get('coarse') or (p['kind'] == 'synth' and isinstance(p['coarse'], list) and
                                        all(type(k) is int and 0 <= k <= 3 for k in p['coarse']) and
                                        len(set(p['coarse'])) == len(p['coarse'])), f'{pj}: coarse: synth knobs 0..3'
        assert not p.get('input_engine') or (p['kind']=='synth' and p.get('loadable') and not p.get('uses_sample')), f'{pj}: input engines must be nonsampler loadable synths'
        assert p['kind'] in ('synth', 'fx', 'feature'), pj
        assert p['kind'] == 'feature' or 'order' in p or p.get('loadable'), f'{pj}: "order" (or "loadable": true)'
        (engs if p['kind'] == 'synth' else fxs if p['kind'] == 'fx' else feats).append(e)
    for lst in (engs, fxs):
        lst.sort(key=lambda e: e.get('order', 0))
        orders = [e['order'] for e in lst if 'order' in e]
        assert len(set(orders)) == len(orders), f'duplicate plugin order: {orders}'
    return feats if kinds == ('feature',) else (engs, fxs)


def load_features():
    """-> features (plugin.json kind \"feature\"): compiled into the core, or shipped as files when \"loadable\"."""
    return load(('feature',))


if __name__ == '__main__':
    for e in sum(load(), []):
        print(e.get('order', '-'), e['name'], e['source'], e.get('screen', {}).get('svg', '-'))
